/**
 * Production Analytics & Conversion Tracking Service
 * Implements multi-platform analytics with real-time conversion funnel tracking
 */

interface ConversionEvent {
  category: 'acquisition' | 'conversion' | 'engagement' | 'abandonment' | 'recovery';
  priority: 'low' | 'medium' | 'high' | 'critical';
  value?: number;
  properties?: Record<string, any>;
}

interface UserProperties {
  userId?: string;
  userType: 'parent' | 'sitter';
  signupDate?: string;
  totalBookings?: number;
  averageRating?: number;
  city?: string;
  referralSource?: string;
}

export class AnalyticsService {
  private static instance: AnalyticsService;
  private providers: string[] = [];
  private userId: string | null = null;
  private userProperties: UserProperties | null = null;

  // Core conversion events to track
  private readonly CONVERSION_EVENTS: Record<string, ConversionEvent> = {
    // User Acquisition
    'signup_start': { category: 'acquisition', priority: 'high' },
    'signup_complete': { category: 'acquisition', priority: 'high' },
    'social_login_attempt': { category: 'acquisition', priority: 'medium' },
    'email_verification_complete': { category: 'acquisition', priority: 'medium' },
    
    // Booking Conversion
    'booking_start': { category: 'conversion', priority: 'high' },
    'sitter_selected': { category: 'conversion', priority: 'high' },
    'booking_details_completed': { category: 'conversion', priority: 'high' },
    'payment_initiated': { category: 'conversion', priority: 'critical' },
    'booking_paid': { category: 'conversion', priority: 'critical' },
    'booking_success': { category: 'conversion', priority: 'critical' },
    
    // Engagement
    'sitter_profile_viewed': { category: 'engagement', priority: 'medium' },
    'availability_checked': { category: 'engagement', priority: 'medium' },
    'search_performed': { category: 'engagement', priority: 'medium' },
    'message_sent': { category: 'engagement', priority: 'medium' },
    'review_submitted': { category: 'engagement', priority: 'medium' },
    'profile_updated': { category: 'engagement', priority: 'low' },
    
    // Abandonment & Recovery
    'booking_abandoned': { category: 'abandonment', priority: 'high' },
    'payment_failed': { category: 'abandonment', priority: 'critical' },
    'signup_abandoned': { category: 'abandonment', priority: 'medium' },
    'push_notification_sent': { category: 'recovery', priority: 'medium' },
    'email_followup_sent': { category: 'recovery', priority: 'medium' },
    'abandonment_recovered': { category: 'recovery', priority: 'high' }
  };

  public static getInstance(): AnalyticsService {
    if (!AnalyticsService.instance) {
      AnalyticsService.instance = new AnalyticsService();
    }
    return AnalyticsService.instance;
  }

  async initialize(providers: string[] = ['google-analytics']) {
    this.providers = providers;
    
    for (const provider of providers) {
      await this.initializeProvider(provider);
    }

    console.log(`Analytics initialized with providers: ${providers.join(', ')}`);
  }

  private async initializeProvider(provider: string) {
    switch (provider) {
      case 'google-analytics':
        await this.initializeGoogleAnalytics();
        break;
      case 'posthog':
        await this.initializePostHog();
        break;
      case 'mixpanel':
        await this.initializeMixpanel();
        break;
    }
  }

  private async initializeGoogleAnalytics() {
    const measurementId = import.meta.env.VITE_GA_MEASUREMENT_ID;
    if (!measurementId) {
      console.warn('Google Analytics Measurement ID not found');
      return;
    }

    // Load GA4 script
    const script = document.createElement('script');
    script.async = true;
    script.src = `https://www.googletagmanager.com/gtag/js?id=${measurementId}`;
    document.head.appendChild(script);

    // Initialize gtag
    const configScript = document.createElement('script');
    configScript.innerHTML = `
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', '${measurementId}', {
        page_title: document.title,
        page_location: window.location.href,
        custom_map: {
          'custom_parameter_1': 'user_type',
          'custom_parameter_2': 'conversion_value'
        }
      });
    `;
    document.head.appendChild(configScript);
  }

  private async initializePostHog() {
    const apiKey = import.meta.env.VITE_POSTHOG_API_KEY;
    if (!apiKey) return;

    const script = document.createElement('script');
    script.innerHTML = `
      !function(t,e){var o,n,p,r;e.__SV||(window.posthog=e,e._i=[],e.init=function(i,s,a){function g(t,e){var o=e.split(".");2==o.length&&(t=t[o[0]],e=o[1]);var n=t;if("undefined"!=typeof e)try{n=t[e]}catch(t){}return n}(p=t.createElement("script")).type="text/javascript",p.async=!0,p.src=s.api_host+"/static/array.js",(r=t.getElementsByTagName("script")[0]).parentNode.insertBefore(p,r);var u=e;for(void 0!==a?u=e[a]=[]:a="posthog",u.people=u.people||[],u.toString=function(t){var e="posthog";return"posthog"!==a&&(e+="."+a),t||(e+=" (stub)"),e},u.people.toString=function(){return u.toString(1)+".people (stub)"},o="capture identify alias people.set people.set_once set_config register register_once unregister opt_out_capturing has_opted_out_capturing opt_in_capturing reset isFeatureEnabled onFeatureFlags".split(" "),n=0;n<o.length;n++)g(u,o[n]);e._i.push([i,s,a])},e.__SV=1)}(document,window.posthog||[]);
      posthog.init('${apiKey}', {api_host:'https://app.posthog.com'});
    `;
    document.head.appendChild(script);
  }

  private async initializeMixpanel() {
    const token = import.meta.env.VITE_MIXPANEL_TOKEN;
    if (!token) return;

    const script = document.createElement('script');
    script.innerHTML = `
      (function(c,a){if(!a.__SV){var b=window;try{var d,m,j,k=b.location,f=k.hash;d=function(a,b){return(m=a.match(RegExp(b+"=([^&]*)")))?m[1]:null};f&&d(f,"state")&&(j=JSON.parse(decodeURIComponent(d(f,"state"))),"mpeditor"===j.action&&(b.sessionStorage.setItem("_mpcehash",f),history.replaceState(j.desiredHash||"",c.title,k.pathname+k.search)))}catch(n){}var l,h;window.mixpanel=a;a._i=[];a.init=function(b,d,g){function c(b,i){var a=i.split(".");2==a.length&&(b=b[a[0]],i=a[1]);var f=b;if("undefined"!=typeof i)try{f=b[i]}catch(j){}return f}var e=a;"undefined"!==typeof g?e=a[g]=[]:g="mixpanel";e.people=e.people||[];e.toString=function(b){var a="mixpanel";"mixpanel"!==g&&(a+="."+g);b||(a+=" (stub)");return a};e.people.toString=function(){return e.toString(1)+".people (stub)"};l="disable time_event track track_pageview track_links track_forms track_with_groups add_group set_group remove_group register register_once alias unregister identify name_tag set_config reset opt_in_tracking opt_out_tracking has_opted_in_tracking has_opted_out_tracking clear_opt_in_out_tracking start_batch_senders people.set people.set_once people.unset people.increment people.append people.union people.track_charge people.clear_charges people.delete_user people.remove".split(" ");for(h=0;h<l.length;h++)c(e,l[h]);var f="set track_pageview track_links track_forms register register_once alias unregister identify".split(" ");for(h=0;h<f.length;h++)c(e.people,f[h]);a._i.push([b,d,g])};a.__SV=1.2;b=c.createElement("script");b.type="text/javascript";b.async=!0;b.src="undefined"!==typeof MIXPANEL_CUSTOM_LIB_URL?MIXPANEL_CUSTOM_LIB_URL:"file:"===c.location.protocol&&"//cdn.mxpnl.com/libs/mixpanel-2-latest.min.js".match(/^\\/\\//)?"https://cdn.mxpnl.com/libs/mixpanel-2-latest.min.js":"//cdn.mxpnl.com/libs/mixpanel-2-latest.min.js";d=c.getElementsByTagName("script")[0];d.parentNode.insertBefore(b,d)}})(document,window.mixpanel||[]);
      mixpanel.init('${token}');
    `;
    document.head.appendChild(script);
  }

  // Set user identification across all providers
  identifyUser(userId: string, properties: UserProperties) {
    this.userId = userId;
    this.userProperties = properties;

    if (this.providers.includes('google-analytics') && window.gtag) {
      window.gtag('config', import.meta.env.VITE_GA_MEASUREMENT_ID, {
        user_id: userId,
        custom_map: {
          user_type: properties.userType,
          signup_date: properties.signupDate,
          city: properties.city
        }
      });
    }

    if (this.providers.includes('posthog') && window.posthog) {
      window.posthog.identify(userId, properties);
    }

    if (this.providers.includes('mixpanel') && window.mixpanel) {
      window.mixpanel.identify(userId);
      window.mixpanel.people.set(properties);
    }
  }

  // Track conversion events across all providers
  trackEvent(eventName: string, properties: Record<string, any> = {}) {
    const eventConfig = this.CONVERSION_EVENTS[eventName];
    if (!eventConfig) {
      console.warn(`Unknown event: ${eventName}`);
      return;
    }

    const enrichedProperties = {
      ...properties,
      category: eventConfig.category,
      priority: eventConfig.priority,
      user_type: this.userProperties?.userType,
      timestamp: new Date().toISOString(),
      platform: this.getPlatform(),
      session_id: this.getSessionId()
    };

    // Google Analytics
    if (this.providers.includes('google-analytics') && window.gtag) {
      window.gtag('event', eventName, {
        event_category: eventConfig.category,
        event_label: properties.label,
        value: properties.value || eventConfig.value,
        custom_parameter_1: this.userProperties?.userType,
        custom_parameter_2: properties.value
      });
    }

    // PostHog
    if (this.providers.includes('posthog') && window.posthog) {
      window.posthog.capture(eventName, enrichedProperties);
    }

    // Mixpanel
    if (this.providers.includes('mixpanel') && window.mixpanel) {
      window.mixpanel.track(eventName, enrichedProperties);
    }

    // Store critical events locally for recovery
    if (eventConfig.priority === 'critical') {
      this.storeCriticalEvent(eventName, enrichedProperties);
    }

    console.log(`📊 Tracked: ${eventName}`, enrichedProperties);
  }

  // Specific tracking methods for common conversion events
  trackSignupStart(method: 'email' | 'google' | 'apple' | 'facebook') {
    this.trackEvent('signup_start', { method, source: document.referrer });
  }

  trackSignupComplete(userId: string, userType: 'parent' | 'sitter') {
    this.trackEvent('signup_complete', { user_id: userId, user_type: userType });
  }

  trackBookingStart(sitterId?: string) {
    this.trackEvent('booking_start', { sitter_id: sitterId });
  }

  trackSitterSelected(sitterId: string, hourlyRate: number) {
    this.trackEvent('sitter_selected', { 
      sitter_id: sitterId, 
      hourly_rate: hourlyRate,
      value: hourlyRate 
    });
  }

  trackPaymentInitiated(amount: number, paymentMethod: string) {
    this.trackEvent('payment_initiated', { 
      amount, 
      payment_method: paymentMethod,
      value: amount 
    });
  }

  trackBookingSuccess(bookingId: string, amount: number, sitterId: string) {
    this.trackEvent('booking_success', { 
      booking_id: bookingId, 
      amount, 
      sitter_id: sitterId,
      value: amount 
    });
  }

  trackAbandonment(step: string, reason?: string) {
    const eventMap = {
      'signup': 'signup_abandoned',
      'booking': 'booking_abandoned',
      'payment': 'payment_failed'
    };

    const eventName = eventMap[step as keyof typeof eventMap] || 'booking_abandoned';
    this.trackEvent(eventName, { step, reason });
  }

  // Track page views and navigation
  trackPageView(path: string, title?: string) {
    const properties = {
      page_path: path,
      page_title: title || document.title,
      page_location: window.location.href
    };

    if (this.providers.includes('google-analytics') && window.gtag) {
      window.gtag('config', import.meta.env.VITE_GA_MEASUREMENT_ID, {
        page_path: path,
        page_title: title
      });
    }

    if (this.providers.includes('posthog') && window.posthog) {
      window.posthog.capture('$pageview', properties);
    }

    if (this.providers.includes('mixpanel') && window.mixpanel) {
      window.mixpanel.track('Page View', properties);
    }
  }

  // Utility methods
  private getPlatform(): string {
    const userAgent = navigator.userAgent.toLowerCase();
    if (/iphone|ipad|ipod/.test(userAgent)) return 'ios';
    if (/android/.test(userAgent)) return 'android';
    if (/mobile/.test(userAgent)) return 'mobile_web';
    return 'desktop_web';
  }

  private getSessionId(): string {
    let sessionId = sessionStorage.getItem('analytics_session_id');
    if (!sessionId) {
      sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      sessionStorage.setItem('analytics_session_id', sessionId);
    }
    return sessionId;
  }

  private storeCriticalEvent(eventName: string, properties: Record<string, any>) {
    const criticalEvents = JSON.parse(localStorage.getItem('critical_events') || '[]');
    criticalEvents.push({ eventName, properties, timestamp: Date.now() });
    
    // Keep only last 50 critical events
    if (criticalEvents.length > 50) {
      criticalEvents.shift();
    }
    
    localStorage.setItem('critical_events', JSON.stringify(criticalEvents));
  }

  // Analytics health check
  getAnalyticsStatus() {
    return {
      providers: this.providers,
      userId: this.userId,
      sessionId: this.getSessionId(),
      platform: this.getPlatform(),
      googleAnalytics: !!(window.gtag && import.meta.env.VITE_GA_MEASUREMENT_ID),
      postHog: !!(window.posthog && import.meta.env.VITE_POSTHOG_API_KEY),
      mixpanel: !!(window.mixpanel && import.meta.env.VITE_MIXPANEL_TOKEN)
    };
  }
}

// Global analytics instance
export const analytics = AnalyticsService.getInstance();

// Global type declarations
declare global {
  interface Window {
    gtag: (...args: any[]) => void;
    posthog: any;
    mixpanel: any;
  }
}

export default analytics;