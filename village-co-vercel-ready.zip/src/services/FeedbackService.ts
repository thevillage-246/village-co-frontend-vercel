/**
 * Real Feedback Collection & Growth Engine Service
 * Implements post-booking feedback, retention campaigns, and referral system
 */

import { analytics } from './AnalyticsService';

interface FeedbackTrigger {
  delay: string;
  channel: 'push' | 'in-app' | 'email' | 'sms';
  message: string;
  priority: 'low' | 'medium' | 'high';
}

interface FeedbackSubmission {
  id: string;
  userId: string;
  bookingId?: string;
  type: 'booking_review' | 'sitter_rating' | 'platform_feedback' | 'feature_request';
  rating: number;
  feedback: string;
  categories: string[];
  anonymous: boolean;
  timestamp: string;
  platform: string;
}

interface RetentionCampaign {
  id: string;
  target: string;
  trigger: string;
  message: string;
  channel: 'push' | 'email' | 'sms';
  frequency: string;
  active: boolean;
}

interface ReferralProgram {
  referrerId: string;
  refereeId?: string;
  referralCode: string;
  type: 'parent_to_parent' | 'sitter_to_sitter';
  status: 'pending' | 'completed' | 'rewarded';
  rewardAmount: number;
  createdAt: string;
  completedAt?: string;
}

export class FeedbackService {
  private static instance: FeedbackService;
  private feedbackQueue: FeedbackSubmission[] = [];
  private retentionCampaigns: RetentionCampaign[] = [];

  // Automated feedback triggers
  private readonly FEEDBACK_TRIGGERS: Record<string, FeedbackTrigger> = {
    'booking_complete': {
      delay: '2 hours',
      channel: 'push',
      message: '✨ How did your evening go? Tap to review {sitterName}',
      priority: 'high'
    },
    'sitter_departed': {
      delay: '30 minutes',
      channel: 'in-app',
      message: 'Tell us how it went! Your feedback helps other parents',
      priority: 'medium'
    },
    'first_time_user': {
      delay: '24 hours',
      channel: 'email',
      message: 'Welcome to The Village! How was your first booking?',
      priority: 'high'
    },
    'multiple_bookings': {
      delay: '7 days',
      channel: 'in-app',
      message: 'You\'re becoming a regular! Mind sharing what you love?',
      priority: 'low'
    }
  };

  // Retention campaigns
  private readonly RETENTION_CAMPAIGNS: RetentionCampaign[] = [
    {
      id: 'weekly_availability_reminder',
      target: 'inactive_sitters',
      trigger: '7_days_no_availability_update',
      message: 'Parents are looking for sitters this week! Update your availability',
      channel: 'push',
      frequency: 'weekly',
      active: true
    },
    {
      id: 'booking_reminder',
      target: 'regular_parents',
      trigger: '30_days_no_booking',
      message: 'Missing date nights? {sitterName} is available this weekend',
      channel: 'email',
      frequency: 'monthly',
      active: true
    },
    {
      id: 'seasonal_promotions',
      target: 'all_users',
      trigger: 'school_holidays',
      message: 'School holidays sorted! Book your trusted sitter early',
      channel: 'push',
      frequency: 'seasonal',
      active: true
    },
    {
      id: 'favorite_sitter_available',
      target: 'previous_parents',
      trigger: 'sitter_posts_availability',
      message: '{sitterName} is available Friday night - book your favourite sitter',
      channel: 'push',
      frequency: 'immediate',
      active: true
    },
    {
      id: 'last_minute_opportunity',
      target: 'spontaneous_parents',
      trigger: '2_hours_before_availability',
      message: 'Tonight sorted! {sitterName} just became available 7-11pm',
      channel: 'push',
      frequency: 'immediate',
      active: true
    }
  ];

  public static getInstance(): FeedbackService {
    if (!FeedbackService.instance) {
      FeedbackService.instance = new FeedbackService();
    }
    return FeedbackService.instance;
  }

  // Initialize feedback system
  async initialize() {
    this.retentionCampaigns = [...this.RETENTION_CAMPAIGNS];
    this.setupAutomatedTriggers();
    this.loadPendingFeedback();
    console.log('Feedback & Growth Engine initialized');
  }

  // Post-booking feedback collection
  async triggerBookingFeedback(bookingId: string, sitterName: string, parentId: string) {
    const trigger = this.FEEDBACK_TRIGGERS['booking_complete'];
    const message = trigger.message.replace('{sitterName}', sitterName);

    // Schedule push notification
    setTimeout(async () => {
      await this.sendFeedbackRequest({
        bookingId,
        userId: parentId,
        message,
        channel: 'push',
        type: 'booking_review'
      });
    }, this.parseDelay(trigger.delay));

    // Track the trigger
    analytics.trackEvent('feedback_request_sent', {
      booking_id: bookingId,
      channel: trigger.channel,
      type: 'booking_review'
    });
  }

  // In-app feedback collection
  async collectFeedback(submission: {
    userId: string;
    bookingId?: string;
    type: FeedbackSubmission['type'];
    rating: number;
    feedback: string;
    categories: string[];
    anonymous?: boolean;
  }): Promise<string> {
    
    const feedbackId = `feedback_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const feedbackSubmission: FeedbackSubmission = {
      id: feedbackId,
      userId: submission.userId,
      bookingId: submission.bookingId,
      type: submission.type,
      rating: submission.rating,
      feedback: submission.feedback,
      categories: submission.categories,
      anonymous: submission.anonymous || false,
      timestamp: new Date().toISOString(),
      platform: this.getPlatform()
    };

    // Store feedback locally and sync to server
    this.feedbackQueue.push(feedbackSubmission);
    await this.syncFeedbackToServer(feedbackSubmission);

    // Track feedback submission
    analytics.trackEvent('feedback_submitted', {
      feedback_id: feedbackId,
      rating: submission.rating,
      type: submission.type,
      has_text: submission.feedback.length > 0,
      categories: submission.categories.join(',')
    });

    // Trigger automated responses based on rating
    await this.handleFeedbackResponse(feedbackSubmission);

    return feedbackId;
  }

  // Automated feedback response handling
  private async handleFeedbackResponse(feedback: FeedbackSubmission) {
    // Low ratings (1-3 stars) - immediate escalation
    if (feedback.rating <= 3) {
      await this.escalateNegativeFeedback(feedback);
    }
    
    // High ratings (5 stars) - encourage reviews/referrals
    if (feedback.rating === 5) {
      await this.encouragePositiveActions(feedback);
    }

    // Feature requests - categorize and track
    if (feedback.type === 'feature_request') {
      await this.categorizeFeatureRequest(feedback);
    }
  }

  // Retention campaign management
  async executeRetentionCampaign(campaignId: string, userId: string, context: Record<string, any> = {}) {
    const campaign = this.retentionCampaigns.find(c => c.id === campaignId);
    if (!campaign || !campaign.active) return;

    let message = campaign.message;
    
    // Replace context variables in message
    Object.keys(context).forEach(key => {
      message = message.replace(`{${key}}`, context[key]);
    });

    // Send retention message
    await this.sendRetentionMessage({
      userId,
      message,
      channel: campaign.channel,
      campaignId: campaign.id
    });

    // Track retention campaign
    analytics.trackEvent('retention_campaign_sent', {
      campaign_id: campaignId,
      user_id: userId,
      channel: campaign.channel,
      trigger: campaign.trigger
    });
  }

  // Referral system
  async generateReferralCode(userId: string, type: 'parent_to_parent' | 'sitter_to_sitter'): Promise<string> {
    const referralCode = `${type === 'parent_to_parent' ? 'P' : 'S'}${userId}${Date.now().toString().slice(-6)}`;
    
    const referral: ReferralProgram = {
      referrerId: userId,
      referralCode,
      type,
      status: 'pending',
      rewardAmount: type === 'parent_to_parent' ? 25 : 50,
      createdAt: new Date().toISOString()
    };

    await this.storeReferral(referral);
    
    analytics.trackEvent('referral_code_generated', {
      referrer_id: userId,
      referral_code: referralCode,
      type,
      reward_amount: referral.rewardAmount
    });

    return referralCode;
  }

  async processReferral(referralCode: string, newUserId: string): Promise<boolean> {
    const referral = await this.getReferralByCode(referralCode);
    if (!referral || referral.status !== 'pending') return false;

    // Update referral with referee information
    referral.refereeId = newUserId;
    referral.status = 'completed';
    referral.completedAt = new Date().toISOString();

    await this.updateReferral(referral);

    // Apply rewards (would integrate with credit system)
    await this.applyReferralRewards(referral);

    analytics.trackEvent('referral_completed', {
      referrer_id: referral.referrerId,
      referee_id: newUserId,
      referral_code: referralCode,
      reward_amount: referral.rewardAmount
    });

    return true;
  }

  // Growth metrics and insights
  async getGrowthMetrics(period: 'week' | 'month' | 'quarter' = 'month') {
    const metrics = {
      feedback: {
        totalSubmissions: this.feedbackQueue.length,
        averageRating: this.calculateAverageRating(),
        responseRate: await this.calculateResponseRate(period),
        sentimentBreakdown: await this.getSentimentBreakdown()
      },
      retention: {
        activeCampaigns: this.retentionCampaigns.filter(c => c.active).length,
        campaignEngagement: await this.getCampaignEngagement(period),
        userRetention: await this.getUserRetentionMetrics(period)
      },
      referrals: {
        totalGenerated: await this.getTotalReferrals(period),
        conversionRate: await this.getReferralConversionRate(period),
        rewardsPaid: await this.getTotalRewardsPaid(period)
      }
    };

    return metrics;
  }

  // Private helper methods
  private setupAutomatedTriggers() {
    // Set up event listeners for booking completions, user actions, etc.
    window.addEventListener('booking_completed', (event: any) => {
      const { bookingId, sitterName, parentId } = event.detail;
      this.triggerBookingFeedback(bookingId, sitterName, parentId);
    });

    window.addEventListener('first_booking_completed', (event: any) => {
      const { userId } = event.detail;
      setTimeout(() => {
        this.sendFeedbackRequest({
          userId,
          message: this.FEEDBACK_TRIGGERS['first_time_user'].message,
          channel: 'email',
          type: 'platform_feedback'
        });
      }, this.parseDelay('24 hours'));
    });
  }

  private async sendFeedbackRequest(params: {
    userId: string;
    bookingId?: string;
    message: string;
    channel: 'push' | 'email' | 'in-app';
    type: string;
  }) {
    const payload = {
      userId: params.userId,
      message: params.message,
      channel: params.channel,
      type: params.type,
      bookingId: params.bookingId
    };

    try {
      await fetch('/api/feedback/request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
    } catch (error) {
      console.error('Failed to send feedback request:', error);
    }
  }

  private async escalateNegativeFeedback(feedback: FeedbackSubmission) {
    // Immediate admin notification for low ratings
    await fetch('/api/admin/feedback/escalate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        feedbackId: feedback.id,
        rating: feedback.rating,
        feedback: feedback.feedback,
        urgent: feedback.rating <= 2
      })
    });

    // Send follow-up message to user
    await this.sendFeedbackRequest({
      userId: feedback.userId,
      message: 'Thanks for your feedback. Our team will review and get back to you within 24 hours.',
      channel: 'in-app',
      type: 'escalation_acknowledgment'
    });
  }

  private async encouragePositiveActions(feedback: FeedbackSubmission) {
    // Encourage app store review
    setTimeout(async () => {
      await this.sendFeedbackRequest({
        userId: feedback.userId,
        message: 'Loving The Village Co? Help other parents discover us with a quick app store review!',
        channel: 'in-app',
        type: 'review_encouragement'
      });
    }, 60000); // 1 minute delay

    // Suggest referral program
    setTimeout(async () => {
      const referralCode = await this.generateReferralCode(feedback.userId, 'parent_to_parent');
      await this.sendFeedbackRequest({
        userId: feedback.userId,
        message: `Share The Village Co with friends! You both get $25 credit. Code: ${referralCode}`,
        channel: 'push',
        type: 'referral_invitation'
      });
    }, 300000); // 5 minute delay
  }

  private async syncFeedbackToServer(feedback: FeedbackSubmission) {
    try {
      await fetch('/api/feedback/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(feedback)
      });
    } catch (error) {
      console.error('Failed to sync feedback to server:', error);
      // Keep in local queue for retry
    }
  }

  private parseDelay(delay: string): number {
    const [amount, unit] = delay.split(' ');
    const multipliers = {
      'minutes': 60 * 1000,
      'hours': 60 * 60 * 1000,
      'days': 24 * 60 * 60 * 1000
    };
    return parseInt(amount) * multipliers[unit as keyof typeof multipliers];
  }

  private getPlatform(): string {
    const userAgent = navigator.userAgent.toLowerCase();
    if (/iphone|ipad|ipod/.test(userAgent)) return 'ios';
    if (/android/.test(userAgent)) return 'android';
    return 'web';
  }

  private calculateAverageRating(): number {
    const ratings = this.feedbackQueue.map(f => f.rating);
    return ratings.length > 0 ? ratings.reduce((a, b) => a + b, 0) / ratings.length : 0;
  }

  // Data persistence methods (would integrate with backend)
  private loadPendingFeedback() {
    const stored = localStorage.getItem('pending_feedback');
    if (stored) {
      this.feedbackQueue = JSON.parse(stored);
    }
  }

  private async storeReferral(referral: ReferralProgram) {
    // Store to backend API
    await fetch('/api/referrals', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(referral)
    });
  }

  private async getReferralByCode(code: string): Promise<ReferralProgram | null> {
    try {
      const response = await fetch(`/api/referrals/code/${code}`);
      return response.ok ? await response.json() : null;
    } catch {
      return null;
    }
  }

  private async updateReferral(referral: ReferralProgram) {
    await fetch(`/api/referrals/${referral.referralCode}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(referral)
    });
  }

  private async applyReferralRewards(referral: ReferralProgram) {
    // Apply credit to both referrer and referee
    await fetch('/api/users/credits/apply', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        referrerId: referral.referrerId,
        refereeId: referral.refereeId,
        amount: referral.rewardAmount,
        type: 'referral_reward'
      })
    });
  }

  private async sendRetentionMessage(params: {
    userId: string;
    message: string;
    channel: string;
    campaignId: string;
  }) {
    await fetch('/api/retention/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params)
    });
  }

  // Placeholder methods for metrics (would implement with real data)
  private async calculateResponseRate(period: string): Promise<number> { return 0.15; }
  private async getSentimentBreakdown(): Promise<object> { return {}; }
  private async getCampaignEngagement(period: string): Promise<number> { return 0.12; }
  private async getUserRetentionMetrics(period: string): Promise<object> { return {}; }
  private async getTotalReferrals(period: string): Promise<number> { return 0; }
  private async getReferralConversionRate(period: string): Promise<number> { return 0.08; }
  private async getTotalRewardsPaid(period: string): Promise<number> { return 0; }
  private async categorizeFeatureRequest(feedback: FeedbackSubmission): Promise<void> {}
}

export const feedbackService = FeedbackService.getInstance();
export default feedbackService;