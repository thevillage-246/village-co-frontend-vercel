import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { ChevronDown, ChevronUp, Menu, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

const links = [
  { path: '/admin-dashboard', label: '🏠 Overview' },
  { path: '/admin/events', label: '📅 Event Management' },
  { path: '/admin/upload-sitters', label: '📤 Upload Sitters' },
  { path: '/admin/upload-parents', label: '👥 Upload Parents' },
  { path: '/admin/sitter-photos', label: '📷 Photo Manager' },
  { path: '/admin/security', label: '🔒 Security Dashboard' },
  { path: '/admin/auth-logs', label: '🔐 Authentication Logs' },
  { path: '/admin-notify', label: '📣 Notify Sitters' },
  { path: '/admin-inactive', label: '💤 Inactive Sitters' },
  { path: '/admin-inactive-parents', label: '💬 Inactive Parents' },
  { path: '/admin-at-risk', label: '⚠️ At-Risk Users' },

];

export default function AdminSidebar() {
  const [location] = useLocation();
  const [isExpanded, setIsExpanded] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleExpanded = () => {
    setIsExpanded(!isExpanded);
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <>
      {/* Mobile Menu Button */}
      <div className="lg:hidden bg-[#f9f5f0] border-b border-gray-200 p-3 flex justify-between items-center">
        <h2 className="text-lg font-bold text-[#6B3E4B]">Admin Tools</h2>
        <Button
          variant="ghost"
          size="sm"
          onClick={toggleMobileMenu}
          className="text-[#6B3E4B]"
        >
          {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>
      </div>

      {/* Mobile Dropdown Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-[#f9f5f0] border-b border-gray-200 p-3">
          <ul className="space-y-2">
            {links.map(link => (
              <li key={link.path}>
                <Link href={link.path}>
                  <span 
                    className={`block px-3 py-2 rounded text-sm hover:bg-[#EBD3CB]/10 cursor-pointer ${
                      location === link.path ? 'bg-[#EBD3CB]/20 font-semibold text-[#6B3E4B]' : 'text-gray-700'
                    }`}
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    {link.label}
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Desktop Sidebar - Collapsible */}
      <aside className="hidden lg:block bg-[#f9f5f0] border-r border-gray-200 h-full sticky top-0 transition-all duration-300 ease-in-out" 
             style={{ width: isExpanded ? '256px' : '60px' }}>
        <div className="p-4">
          <div className="flex items-center justify-between mb-6">
            {isExpanded && <h2 className="text-xl font-bold text-[#6B3E4B]">Admin Tools</h2>}
            <Button
              variant="ghost"
              size="sm"
              onClick={toggleExpanded}
              className="text-[#6B3E4B] hover:bg-[#EBD3CB]/10"
            >
              {isExpanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
            </Button>
          </div>
          
          <ul className="space-y-2">
            {links.map(link => (
              <li key={link.path}>
                <Link href={link.path}>
                  <span className={`block px-3 py-2 rounded hover:bg-[#EBD3CB]/10 cursor-pointer transition-all ${
                    location === link.path ? 'bg-[#EBD3CB]/20 font-semibold text-[#6B3E4B]' : 'text-gray-700'
                  }`}>
                    {isExpanded ? link.label : link.label.split(' ')[0]}
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </aside>
    </>
  );
}