import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Elements, PaymentElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Clock, User, MapPin, CreditCard, CheckCircle, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

// Initialize Stripe
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

interface BookingDetails {
  sitterId: number;
  sitterName: string;
  sitterRate: number;
  startTime: string;
  endTime: string;
  specialRequests?: string;
  sitNotes?: string;
  location?: string;
}

interface ChargeBreakdown {
  bookingHours: number;
  coveredHours: number;
  overageHours: number;
  subscriptionBalanceAfter: number;
  stripeChargeAmount: number;
  needsPayment: boolean;
  paymentIntentId?: string;
  clientSecret?: string;
}

interface BookingConfirmationProps {
  bookingDetails: BookingDetails;
  onSuccess: (bookingId: number) => void;
  onCancel: () => void;
}

// Payment form component
const PaymentForm: React.FC<{
  chargeDetails: ChargeBreakdown;
  onPaymentSuccess: () => void;
  onPaymentError: (error: string) => void;
}> = ({ chargeDetails, onPaymentSuccess, onPaymentError }) => {
  const stripe = useStripe();
  const elements = useElements();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    if (!stripe || !elements || !chargeDetails.clientSecret) {
      return;
    }

    setIsProcessing(true);

    try {
      const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: `${window.location.origin}/booking-success`,
        },
        redirect: 'if_required',
      });

      if (error) {
        onPaymentError(error.message || 'Payment failed');
      } else {
        onPaymentSuccess();
      }
    } catch (err) {
      onPaymentError('An unexpected error occurred');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="p-4 bg-gray-50 rounded-lg">
        <PaymentElement />
      </div>
      
      <Button 
        type="submit" 
        disabled={!stripe || isProcessing} 
        className="w-full"
        size="lg"
      >
        {isProcessing ? (
          <div className="flex items-center gap-2">
            <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
            Processing Payment...
          </div>
        ) : (
          `Pay $${chargeDetails.stripeChargeAmount}`
        )}
      </Button>
    </form>
  );
};

export const BookingConfirmation: React.FC<BookingConfirmationProps> = ({
  bookingDetails,
  onSuccess,
  onCancel
}) => {
  const [step, setStep] = useState<'review' | 'payment' | 'confirming'>('review');
  const [chargeDetails, setChargeDetails] = useState<ChargeBreakdown | null>(null);
  const [bookingId, setBookingId] = useState<number | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Create booking with overage billing
  const createBookingMutation = useMutation({
    mutationFn: async (data: BookingDetails) => {
      const response = await apiRequest('POST', '/api/bookings/with-overage-billing', data);
      return response.json();
    },
    onSuccess: (data) => {
      setChargeDetails(data.chargeDetails);
      setBookingId(data.booking.id);
      
      if (data.chargeDetails.needsPayment) {
        setStep('payment');
      } else {
        // No payment needed, booking confirmed
        handleBookingComplete(data.booking.id);
      }
    },
    onError: (error: any) => {
      toast({
        title: "Booking Failed",
        description: error.message || "Failed to create booking",
        variant: "destructive",
      });
    }
  });

  const handleBookingComplete = (completedBookingId: number) => {
    toast({
      title: "Booking Confirmed!",
      description: "Your booking has been successfully created.",
    });
    
    // Invalidate relevant queries
    queryClient.invalidateQueries({ queryKey: ['/api/bookings'] });
    queryClient.invalidateQueries({ queryKey: ['/api/me/subscription-balance'] });
    
    onSuccess(completedBookingId);
  };

  const handlePaymentSuccess = () => {
    if (bookingId) {
      handleBookingComplete(bookingId);
    }
  };

  const handlePaymentError = (error: string) => {
    toast({
      title: "Payment Failed",
      description: error,
      variant: "destructive",
    });
    setStep('review');
  };

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString('en-NZ', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-NZ', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  if (step === 'review') {
    return (
      <Card className="w-full max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-green-600" />
            Confirm Your Booking
          </CardTitle>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {/* Booking Details */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <User className="w-5 h-5 text-gray-400" />
              <div>
                <p className="font-medium">{bookingDetails.sitterName}</p>
                <p className="text-sm text-gray-600">${bookingDetails.sitterRate}/hour</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <Clock className="w-5 h-5 text-gray-400" />
              <div>
                <p className="font-medium">{formatDate(bookingDetails.startTime)}</p>
                <p className="text-sm text-gray-600">
                  {formatTime(bookingDetails.startTime)} - {formatTime(bookingDetails.endTime)}
                </p>
              </div>
            </div>
            
            {bookingDetails.location && (
              <div className="flex items-center gap-3">
                <MapPin className="w-5 h-5 text-gray-400" />
                <p className="text-sm text-gray-600">{bookingDetails.location}</p>
              </div>
            )}
          </div>

          <Separator />

          {/* Special Requests */}
          {bookingDetails.specialRequests && (
            <div>
              <h4 className="font-medium mb-2">Special Requests</h4>
              <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg">
                {bookingDetails.specialRequests}
              </p>
            </div>
          )}

          {/* Sit Notes */}
          {bookingDetails.sitNotes && (
            <div>
              <h4 className="font-medium mb-2">Additional Notes</h4>
              <p className="text-sm text-gray-600 bg-gray-50 p-3 rounded-lg">
                {bookingDetails.sitNotes}
              </p>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4">
            <Button 
              variant="outline" 
              onClick={onCancel}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button 
              onClick={() => createBookingMutation.mutate(bookingDetails)}
              disabled={createBookingMutation.isPending}
              className="flex-1"
            >
              {createBookingMutation.isPending ? (
                <div className="flex items-center gap-2">
                  <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                  Creating...
                </div>
              ) : (
                'Confirm Booking'
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (step === 'payment' && chargeDetails) {
    return (
      <Card className="w-full max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-blue-600" />
            Payment Required
          </CardTitle>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {/* Charge Breakdown */}
          <div className="bg-blue-50 p-4 rounded-lg space-y-3">
            <h4 className="font-medium text-blue-900">Booking Summary</h4>
            
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>Total Booking Hours:</span>
                <span className="font-medium">{chargeDetails.bookingHours} hours</span>
              </div>
              
              {chargeDetails.coveredHours > 0 && (
                <div className="flex justify-between text-green-700">
                  <span>Covered by Subscription:</span>
                  <span className="font-medium">-{chargeDetails.coveredHours} hours</span>
                </div>
              )}
              
              {chargeDetails.overageHours > 0 && (
                <div className="flex justify-between text-orange-700">
                  <span>Overage Hours:</span>
                  <span className="font-medium">{chargeDetails.overageHours} hours</span>
                </div>
              )}
              
              <Separator />
              
              <div className="flex justify-between text-lg font-semibold">
                <span>Amount to Pay:</span>
                <span>${chargeDetails.stripeChargeAmount}</span>
              </div>
              
              <div className="flex justify-between text-sm text-gray-600">
                <span>Subscription Balance After:</span>
                <span>{chargeDetails.subscriptionBalanceAfter} hours</span>
              </div>
            </div>
            
            {chargeDetails.overageHours > 0 && (
              <div className="flex items-start gap-2 mt-3 p-3 bg-orange-100 rounded-lg">
                <AlertCircle className="w-4 h-4 text-orange-600 mt-0.5 flex-shrink-0" />
                <p className="text-sm text-orange-800">
                  This booking exceeds your subscription hours. You'll be charged ${chargeDetails.stripeChargeAmount} for {chargeDetails.overageHours} additional hours.
                </p>
              </div>
            )}
          </div>

          {/* Payment Form */}
          {chargeDetails.clientSecret && (
            <Elements 
              stripe={stripePromise} 
              options={{ 
                clientSecret: chargeDetails.clientSecret,
                appearance: {
                  theme: 'stripe'
                }
              }}
            >
              <PaymentForm
                chargeDetails={chargeDetails}
                onPaymentSuccess={handlePaymentSuccess}
                onPaymentError={handlePaymentError}
              />
            </Elements>
          )}

          <div className="flex gap-3">
            <Button 
              variant="outline" 
              onClick={() => setStep('review')}
              className="flex-1"
            >
              Back to Review
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return null;
};

export default BookingConfirmation;