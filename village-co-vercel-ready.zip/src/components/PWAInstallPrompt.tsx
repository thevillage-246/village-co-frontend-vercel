import React, { useState } from 'react';
import { X, Download, Smartphone, Monitor, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { usePWA } from '@/hooks/usePWA';

interface PWAInstallPromptProps {
  onClose?: () => void;
  onInstall?: () => void;
}

export const PWAInstallPrompt: React.FC<PWAInstallPromptProps> = ({ 
  onClose, 
  onInstall 
}) => {
  const { promptInstall, capabilities } = usePWA();
  const [isInstalling, setIsInstalling] = useState(false);

  const handleInstall = async () => {
    setIsInstalling(true);
    try {
      const installed = await promptInstall();
      if (installed) {
        onInstall?.();
      }
    } catch (error) {
      console.error('Installation failed:', error);
    } finally {
      setIsInstalling(false);
    }
  };

  const handleClose = () => {
    onClose?.();
    // Store that user dismissed the prompt
    localStorage.setItem('pwa-install-dismissed', Date.now().toString());
  };

  if (!capabilities.isInstallable || capabilities.isInstalled) {
    return null;
  }

  return (
    <Card className="fixed bottom-4 left-4 right-4 md:left-auto md:right-4 md:w-96 z-50 border-village-wine shadow-lg">
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-village-wine rounded-lg flex items-center justify-center">
              <Download className="w-4 h-4 text-white" />
            </div>
            <h3 className="font-semibold text-village-wine">Install The Village Co.</h3>
          </div>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={handleClose}
            className="h-6 w-6 p-0"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>

        <p className="text-sm text-gray-600 mb-4">
          Get the full app experience with offline access, push notifications, and faster loading.
        </p>

        <div className="flex items-center gap-4 mb-4 text-xs text-gray-500">
          <div className="flex items-center gap-1">
            <Zap className="w-3 h-3" />
            <span>Faster</span>
          </div>
          <div className="flex items-center gap-1">
            <Smartphone className="w-3 h-3" />
            <span>Mobile-First</span>
          </div>
          <div className="flex items-center gap-1">
            <Monitor className="w-3 h-3" />
            <span>Works Offline</span>
          </div>
        </div>

        <div className="flex gap-2">
          <Button
            onClick={handleInstall}
            disabled={isInstalling}
            className="flex-1 bg-village-wine hover:bg-village-wine/90"
            size="sm"
          >
            {isInstalling ? (
              <div className="flex items-center gap-2">
                <div className="animate-spin w-3 h-3 border border-white border-t-transparent rounded-full" />
                Installing...
              </div>
            ) : (
              'Install App'
            )}
          </Button>
          <Button 
            variant="outline" 
            onClick={handleClose}
            size="sm"
          >
            Not Now
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default PWAInstallPrompt;