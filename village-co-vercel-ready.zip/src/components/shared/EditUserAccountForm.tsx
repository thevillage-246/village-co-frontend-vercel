import React, { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Save } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

const userAccountSchema = z.object({
  firstName: z.string().min(1, 'First name is required'),
  lastName: z.string().min(1, 'Last name is required'),
  email: z.string().email('Invalid email address'),
  phone: z.string().optional(),
});

type UserAccountData = z.infer<typeof userAccountSchema>;

interface EditUserAccountFormProps {
  userProfile: any;
  onSuccess: () => void;
}

export default function EditUserAccountForm({ userProfile, onSuccess }: EditUserAccountFormProps) {
  const { toast } = useToast();
  const { currentUser, getCurrentUser } = useAuth();
  
  console.log('EditUserAccountForm - userProfile:', userProfile);
  console.log('EditUserAccountForm - currentUser from auth:', currentUser);
  
  const form = useForm<UserAccountData>({
    resolver: zodResolver(userAccountSchema),
    defaultValues: {
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
    },
  });

  // Update form values when userProfile or currentUser changes
  useEffect(() => {
    if (userProfile || currentUser) {
      console.log('EditUserAccountForm - updating form with userProfile:', userProfile);
      console.log('EditUserAccountForm - currentUser for phone:', currentUser);
      
      // Handle both direct user object and nested user object
      const userData = userProfile?.user || userProfile || {};
      
      // Prioritize currentUser data over userProfile data since it's more up-to-date
      const formData = {
        firstName: currentUser?.firstName || userData.firstName || userData.first_name || '',
        lastName: currentUser?.lastName || userData.lastName || userData.last_name || '',
        email: currentUser?.email || userData.email || '',
        phone: currentUser?.phone || userData.phone || '',
      };
      
      console.log('EditUserAccountForm - final form data:', formData);
      
      form.reset(formData);
    }
  }, [userProfile, currentUser, form]);

  const updateAccountMutation = useMutation({
    mutationFn: (data: UserAccountData) => 
      apiRequest('PUT', '/api/auth/profile', data),
    onSuccess: async () => {
      // Refresh the current user data in auth context to include updated phone
      await getCurrentUser();
      onSuccess();
      toast({
        title: "Account Updated",
        description: "Your account information including phone number has been updated successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Update Failed",
        description: error.message || "Failed to update account information. Please try again.",
        variant: "destructive",
      });
    }
  });

  const onSubmit = (data: UserAccountData) => {
    updateAccountMutation.mutate(data);
  };

  return (
    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="firstName" className="text-sm font-medium text-[#6B3E4B]">
            First Name *
          </Label>
          <Input
            id="firstName"
            {...form.register('firstName')}
            className="rounded-xl border-gray-200 focus:border-[#6B3E4B]"
            placeholder="Enter your first name"
          />
          {form.formState.errors.firstName && (
            <p className="text-sm text-red-600">{form.formState.errors.firstName.message}</p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="lastName" className="text-sm font-medium text-[#6B3E4B]">
            Last Name *
          </Label>
          <Input
            id="lastName"
            {...form.register('lastName')}
            className="rounded-xl border-gray-200 focus:border-[#6B3E4B]"
            placeholder="Enter your last name"
          />
          {form.formState.errors.lastName && (
            <p className="text-sm text-red-600">{form.formState.errors.lastName.message}</p>
          )}
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="email" className="text-sm font-medium text-[#6B3E4B]">
          Email Address *
        </Label>
        <Input
          id="email"
          type="email"
          {...form.register('email')}
          className="rounded-xl border-gray-200 focus:border-[#6B3E4B]"
          placeholder="Enter your email address"
        />
        {form.formState.errors.email && (
          <p className="text-sm text-red-600">{form.formState.errors.email.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="phone" className="text-sm font-medium text-[#6B3E4B]">
          Phone Number
        </Label>
        <Input
          id="phone"
          {...form.register('phone')}
          className="rounded-xl border-gray-200 focus:border-[#6B3E4B]"
          placeholder="Enter your phone number"
        />
        {form.formState.errors.phone && (
          <p className="text-sm text-red-600">{form.formState.errors.phone.message}</p>
        )}
      </div>

      <Button
        type="submit"
        disabled={updateAccountMutation.isPending}
        className="w-full bg-[#6B3E4B] hover:bg-[#5A334A] text-white rounded-xl shadow-lg"
      >
        <Save className="h-4 w-4 mr-2" />
        {updateAccountMutation.isPending ? 'Saving...' : 'Save Changes'}
      </Button>
    </form>
  );
}