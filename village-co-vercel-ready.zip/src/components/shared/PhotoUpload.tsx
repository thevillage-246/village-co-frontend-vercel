import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Camera, Upload, X } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface PhotoUploadProps {
  currentPhotoUrl?: string | null;
  onPhotoUpdate: (photoUrl: string) => void;
  isLoading?: boolean;
}

export default function PhotoUpload({ currentPhotoUrl, onPhotoUpdate, isLoading }: PhotoUploadProps) {
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Invalid File",
        description: "Please select an image file.",
        variant: "destructive",
      });
      return;
    }

    // Validate file size (5MB limit)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File Too Large",
        description: "Please select an image smaller than 5MB.",
        variant: "destructive",
      });
      return;
    }

    // Create preview
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      setPreviewUrl(result);
    };
    reader.readAsDataURL(file);

    // Convert to base64 and update
    const formReader = new FileReader();
    formReader.onload = (e) => {
      const result = e.target?.result as string;
      onPhotoUpdate(result);
    };
    formReader.readAsDataURL(file);
  };

  const handleRemovePhoto = () => {
    setPreviewUrl(null);
    onPhotoUpdate('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const displayPhotoUrl = previewUrl || currentPhotoUrl;

  return (
    <div className="flex items-center gap-6">
      <Avatar className="h-24 w-24 border-4 border-white shadow-lg">
        <AvatarImage src={displayPhotoUrl || undefined} alt="Profile photo" />
        <AvatarFallback className="bg-[#F9F5F0] text-[#6B3E4B] text-xl font-semibold">
          <Camera className="h-8 w-8" />
        </AvatarFallback>
      </Avatar>

      <div className="flex-1 space-y-3">
        <div className="flex items-center gap-3">
          <Button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            disabled={isLoading}
            className="bg-[#6B3E4B] hover:bg-[#5A334A] text-white rounded-xl"
          >
            <Upload className="h-4 w-4 mr-2" />
            {displayPhotoUrl ? 'Change Photo' : 'Upload Photo'}
          </Button>

          {displayPhotoUrl && (
            <Button
              type="button"
              variant="outline"
              onClick={handleRemovePhoto}
              disabled={isLoading}
              className="border-red-200 text-red-600 hover:bg-red-50 rounded-xl"
            >
              <X className="h-4 w-4 mr-2" />
              Remove
            </Button>
          )}
        </div>

        <p className="text-sm text-gray-600 font-['DM_Sans']">
          Upload a clear photo of yourself. Accepted formats: JPG, PNG. Max size: 5MB.
        </p>

        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileSelect}
          className="hidden"
        />
      </div>
    </div>
  );
}