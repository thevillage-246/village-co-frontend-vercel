import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { Download, Database, AlertCircle, CheckCircle, Clock } from 'lucide-react';

interface MigrationStatus {
  migrationStatus: {
    [key: string]: {
      exists: boolean;
      count: number;
      error?: string;
    };
  };
  hasCredentials: {
    sharetribe: boolean;
    supabase: boolean;
  };
  timestamp: string;
}

interface MigrationResult {
  message: string;
  summary?: {
    users: number;
    listings: number;
    reviews: number;
    transactions: number;
  };
  error?: string;
  timestamp: string;
}

export default function SharetribeMigration() {
  const [isLoading, setIsLoading] = useState(false);
  const [status, setStatus] = useState<MigrationStatus | null>(null);
  const [lastMigration, setLastMigration] = useState<MigrationResult | null>(null);
  const { toast } = useToast();

  const checkMigrationStatus = async () => {
    try {
      const response = await fetch('/api/admin/migration-status', {
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error('Failed to check migration status');
      }

      const data = await response.json();
      setStatus(data);
    } catch (error) {
      toast({
        title: "Status Check Failed",
        description: "Could not retrieve migration status",
        variant: "destructive"
      });
    }
  };

  const testConnection = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/admin/test-sharetribe-migration', {
        method: 'POST',
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error('Connection test failed');
      }
      
      const result = await response.json();
      
      if (result.success && result.authenticated) {
        toast({
          title: "Connection Successful",
          description: "Successfully connected to It Takes a Village marketplace"
        });
      } else {
        toast({
          title: "Connection Issues",
          description: result.error || "Failed to authenticate with Sharetribe",
          variant: "destructive"
        });
      }
      
    } catch (error) {
      toast({
        title: "Test Failed",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const runMigration = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/admin/migrate-sharetribe', {
        method: 'POST',
        credentials: 'include'
      });

      const data = await response.json();
      setLastMigration(data);

      if (response.ok) {
        toast({
          title: "Migration Started",
          description: "Sharetribe data migration is running...",
        });
        
        // Refresh status after migration
        setTimeout(() => {
          checkMigrationStatus();
        }, 2000);
      } else {
        toast({
          title: "Migration Failed",
          description: data.message || "Migration could not be started",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Migration Error",
        description: "Failed to execute migration",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusIcon = (tableStatus: { exists: boolean; count: number; error?: string }) => {
    if (tableStatus.error) return <AlertCircle className="h-4 w-4 text-red-500" />;
    if (tableStatus.exists && tableStatus.count > 0) return <CheckCircle className="h-4 w-4 text-green-500" />;
    return <Clock className="h-4 w-4 text-yellow-500" />;
  };

  const getStatusBadge = (tableStatus: { exists: boolean; count: number; error?: string }) => {
    if (tableStatus.error) return <Badge variant="destructive">Error</Badge>;
    if (tableStatus.exists && tableStatus.count > 0) return <Badge variant="default">Complete ({tableStatus.count})</Badge>;
    if (tableStatus.exists) return <Badge variant="secondary">Empty</Badge>;
    return <Badge variant="outline">Not Created</Badge>;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="h-5 w-5" />
          Sharetribe Data Migration
        </CardTitle>
        <CardDescription>
          Import production data from existing Sharetribe marketplace
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Credentials Status */}
        <div className="grid grid-cols-2 gap-4">
          <div className="flex items-center justify-between p-3 border rounded-lg">
            <span className="text-sm font-medium">Sharetribe API</span>
            {status?.hasCredentials.sharetribe ? (
              <Badge variant="default">Connected</Badge>
            ) : (
              <Badge variant="destructive">Missing Keys</Badge>
            )}
          </div>
          <div className="flex items-center justify-between p-3 border rounded-lg">
            <span className="text-sm font-medium">Supabase DB</span>
            {status?.hasCredentials.supabase ? (
              <Badge variant="default">Connected</Badge>
            ) : (
              <Badge variant="destructive">Missing Config</Badge>
            )}
          </div>
        </div>

        {/* Migration Status Tables */}
        {status && (
          <div className="space-y-4">
            <h4 className="text-sm font-medium">Migration Tables Status</h4>
            <div className="space-y-2">
              {Object.entries(status.migrationStatus).map(([tableName, tableStatus]) => (
                <div key={tableName} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-2">
                    {getStatusIcon(tableStatus)}
                    <span className="text-sm font-medium capitalize">
                      {tableName.replace('sharetribe_', '').replace('_', ' ')}
                    </span>
                  </div>
                  {getStatusBadge(tableStatus)}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Last Migration Result */}
        {lastMigration && (
          <div className="p-4 border rounded-lg bg-muted/50">
            <h4 className="text-sm font-medium mb-2">Last Migration Result</h4>
            <p className="text-sm text-muted-foreground mb-2">{lastMigration.message}</p>
            {lastMigration.summary && (
              <div className="grid grid-cols-2 gap-2 text-xs">
                <span>Users: {lastMigration.summary.users}</span>
                <span>Sitters: {lastMigration.summary.listings}</span>
                <span>Reviews: {lastMigration.summary.reviews}</span>
                <span>Bookings: {lastMigration.summary.transactions}</span>
              </div>
            )}
            <p className="text-xs text-muted-foreground mt-2">
              {new Date(lastMigration.timestamp).toLocaleString()}
            </p>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex gap-2">
          <Button 
            onClick={checkMigrationStatus}
            variant="outline"
            disabled={isLoading}
          >
            <Database className="h-4 w-4 mr-2" />
            Check Status
          </Button>
          
          <Button 
            onClick={testConnection}
            variant="secondary"
            disabled={isLoading}
          >
            <AlertCircle className="h-4 w-4 mr-2" />
            Test Connection
          </Button>
          
          <Button 
            onClick={runMigration}
            disabled={isLoading || !status?.hasCredentials.sharetribe || !status?.hasCredentials.supabase}
            className="bg-gradient-to-r from-blue-600 to-purple-600 text-white"
          >
            <Download className="h-4 w-4 mr-2" />
            {isLoading ? 'Running Migration...' : 'Start Migration'}
          </Button>
        </div>

        {/* Instructions */}
        <div className="text-xs text-muted-foreground space-y-1">
          <p><strong>Prerequisites:</strong></p>
          <p>• SHARETRIBE_CLIENT_ID and SHARETRIBE_CLIENT_SECRET in environment</p>
          <p>• SUPABASE_URL and SUPABASE_ANON_KEY configured</p>
          <p>• Admin access to both Sharetribe and Supabase</p>
        </div>
      </CardContent>
    </Card>
  );
}