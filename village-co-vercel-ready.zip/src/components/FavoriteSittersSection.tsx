import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import SitterCard from '@/components/SitterCard';
import { Skeleton } from '@/components/ui/skeleton';
import { Heart } from 'lucide-react';

interface FavoriteSittersSectionProps {
  className?: string;
}

export default function FavoriteSittersSection({ className = "" }: FavoriteSittersSectionProps) {
  const { data: favoriteSitters = [], isLoading } = useQuery({
    queryKey: ['/api/favourites'],
    retry: false,
  });

  if (isLoading) {
    return (
      <Card className={`${className}`}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg" style={{ fontFamily: 'Satoshi, sans-serif', color: '#6B3E4B' }}>
            <Heart className="h-5 w-5 fill-red-500 text-red-500" />
            Favourite Sitters
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {Array.from({ length: 3 }).map((_, index) => (
            <div key={index} className="space-y-2">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-20 w-full" />
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }

  if (favoriteSitters.length === 0) {
    return (
      <Card className={`${className}`}>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg" style={{ fontFamily: 'Satoshi, sans-serif', color: '#6B3E4B' }}>
            <Heart className="h-5 w-5 text-gray-400" />
            Favourite Sitters
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-500 text-center py-8" style={{ fontFamily: 'DM Sans, sans-serif' }}>
            No favourite sitters yet. Click the heart icon on any sitter card to add them to your favourites!
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={`${className}`}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg" style={{ fontFamily: 'Satoshi, sans-serif', color: '#6B3E4B' }}>
          <Heart className="h-5 w-5 fill-red-500 text-red-500" />
          Favourite Sitters ({favoriteSitters.length})
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {favoriteSitters.map((sitter: any) => (
          <SitterCard 
            key={sitter.id} 
            sitter={{
              ...sitter,
              isFavorite: true
            }}
          />
        ))}
      </CardContent>
    </Card>
  );
}