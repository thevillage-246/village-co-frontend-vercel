import React, { useState } from 'react';
import { Share2, Copy, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { usePWA } from '@/hooks/usePWA';
import { useToast } from '@/hooks/use-toast';

interface PWAShareButtonProps {
  title?: string;
  text?: string;
  url?: string;
  className?: string;
  variant?: 'default' | 'outline' | 'ghost';
  size?: 'sm' | 'default' | 'lg';
}

export const PWAShareButton: React.FC<PWAShareButtonProps> = ({
  title = 'The Village Co. - Trusted Babysitting',
  text = 'Check out New Zealand\'s most trusted babysitting platform. Verified sitters, instant booking, secure payments.',
  url = window.location.href,
  className = '',
  variant = 'outline',
  size = 'default'
}) => {
  const { capabilities, shareContent } = usePWA();
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);

  const handleShare = async () => {
    const shareData = { title, text, url };

    if (capabilities.canShare) {
      try {
        await shareContent(shareData);
        toast({
          title: "Shared successfully!",
          description: "Thank you for spreading the word about The Village Co.",
        });
      } catch (error) {
        console.error('Share failed:', error);
        // Fallback to copy
        await handleCopyFallback();
      }
    } else {
      await handleCopyFallback();
    }
  };

  const handleCopyFallback = async () => {
    try {
      await navigator.clipboard.writeText(`${title}\n\n${text}\n\n${url}`);
      setCopied(true);
      toast({
        title: "Link copied!",
        description: "The link has been copied to your clipboard.",
      });
      
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error('Copy failed:', error);
      toast({
        title: "Copy failed",
        description: "Unable to copy link. Please try again.",
        variant: "destructive"
      });
    }
  };

  return (
    <Button
      onClick={handleShare}
      variant={variant}
      size={size}
      className={className}
    >
      {copied ? (
        <>
          <Check className="w-4 h-4 mr-2" />
          Copied!
        </>
      ) : capabilities.canShare ? (
        <>
          <Share2 className="w-4 h-4 mr-2" />
          Share
        </>
      ) : (
        <>
          <Copy className="w-4 h-4 mr-2" />
          Copy Link
        </>
      )}
    </Button>
  );
};

export default PWAShareButton;