import React from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CalendarDays, Clock, CheckCircle2 } from 'lucide-react';
import confetti from 'canvas-confetti';

interface BookingConfirmationProps {
  sitterName: string;
  rateLabel: string;
  startTime: string;
  bookingId: string | number;
}

export function BookingConfirmation({ 
  sitterName, 
  rateLabel, 
  startTime,
  bookingId 
}: BookingConfirmationProps) {
  
  // Trigger confetti on component mount
  React.useEffect(() => {
    const duration = 3 * 1000;
    const animationEnd = Date.now() + duration;
    
    const randomInRange = (min: number, max: number) => {
      return Math.random() * (max - min) + min;
    };
    
    const interval = setInterval(() => {
      const timeLeft = animationEnd - Date.now();
      
      if (timeLeft <= 0) {
        return clearInterval(interval);
      }
      
      const particleCount = 50 * (timeLeft / duration);
      
      // Since particles fall down, start a bit higher than random
      confetti({
        particleCount,
        startVelocity: 30,
        spread: 360,
        origin: {
          x: randomInRange(0.1, 0.9),
          y: randomInRange(0.1, 0.5) - 0.2,
        },
        colors: ['#6B3E4B', '#EBD3CB', '#C7D1C5', '#B8A89F', '#F9F5F0'],
        shapes: ['circle', 'square'],
        scalar: 0.8,
      });
    }, 250);
    
    return () => clearInterval(interval);
  }, []);
  
  return (
    <div className="container max-w-xl px-4 py-16 flex flex-col items-center">
      <Card className="w-full bg-white/95 backdrop-blur-sm shadow-lg border-rose/20">
        <CardHeader className="text-center pb-2 pt-6">
          <div className="mx-auto bg-wine/10 w-16 h-16 rounded-full flex items-center justify-center mb-4">
            <CheckCircle2 className="h-8 w-8 text-wine" />
          </div>
          <CardTitle className="text-2xl font-bold text-wine">
            Booking Confirmed!
          </CardTitle>
        </CardHeader>
        
        <CardContent className="text-center px-8 pb-4">
          <p className="mb-6 text-lg">
            You're all set for your sit with <span className="font-medium">{sitterName}</span>.
          </p>
          
          <div className="bg-linen rounded-lg p-6 space-y-3 mb-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <CalendarDays className="h-5 w-5 text-wine mr-2" />
                <span className="font-medium">Date:</span>
              </div>
              <span>
                {new Date(startTime).toLocaleDateString('en-NZ', {
                  weekday: 'long',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}
              </span>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Clock className="h-5 w-5 text-wine mr-2" />
                <span className="font-medium">Time:</span>
              </div>
              <span>
                {new Date(startTime).toLocaleTimeString('en-NZ', {
                  hour: '2-digit',
                  minute: '2-digit',
                  hour12: true
                })}
              </span>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  width="20" 
                  height="20" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  className="text-wine mr-2"
                >
                  <rect width="20" height="14" x="2" y="5" rx="2" />
                  <line x1="2" x2="22" y1="10" y2="10" />
                </svg>
                <span className="font-medium">Session:</span>
              </div>
              <Badge variant="outline" className="bg-rose/20 text-wine border-0">
                {rateLabel}
              </Badge>
            </div>
          </div>
          
          <p className="text-sm text-muted-foreground">
            You'll receive a reminder 2 hours before your sit.
          </p>
        </CardContent>
        
        <CardFooter className="flex flex-col gap-3 px-8 pb-6">
          <Button asChild className="w-full bg-wine hover:bg-wine/90">
            <Link to={`/bookings/${bookingId}`}>View Booking Details</Link>
          </Button>
          <Button asChild variant="outline" className="w-full">
            <Link to="/dashboard">Back to Dashboard</Link>
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}