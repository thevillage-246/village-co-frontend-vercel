import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Star, Clock, MessageSquare, Users, Sparkles, Flag } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { formatCurrency } from '@/lib/utils';

interface BookingFeedbackFormProps {
  booking: {
    id: number;
    sitterId: number;
    sitterName: string;
    sitterImage?: string;
    startTime: string;
    endTime: string;
    totalCost: number;
    children: string[];
  };
  onComplete: () => void;
}

interface FeedbackCategory {
  id: string;
  label: string;
  icon: React.ReactNode;
  rating: number;
}

export default function BookingFeedbackForm({ booking, onComplete }: BookingFeedbackFormProps) {
  const [overallRating, setOverallRating] = useState(5);
  const [categories, setCategories] = useState<FeedbackCategory[]>([
    { id: 'punctuality', label: 'Punctuality', icon: <Clock className="h-4 w-4" />, rating: 5 },
    { id: 'communication', label: 'Communication', icon: <MessageSquare className="h-4 w-4" />, rating: 5 },
    { id: 'childInteraction', label: 'Child Interaction', icon: <Users className="h-4 w-4" />, rating: 5 },
    { id: 'cleanliness', label: 'Cleanliness', icon: <Sparkles className="h-4 w-4" />, rating: 5 }
  ]);
  const [writtenFeedback, setWrittenFeedback] = useState('');
  const [wouldRecommend, setWouldRecommend] = useState(true);
  const [flaggedForReview, setFlaggedForReview] = useState(false);
  const [flagReason, setFlagReason] = useState('');

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const submitFeedbackMutation = useMutation({
    mutationFn: async (feedbackData: any) => {
      const response = await apiRequest('POST', '/api/bookings/feedback', feedbackData);
      if (!response.ok) throw new Error('Failed to submit feedback');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Feedback Submitted",
        description: "Thank you for your feedback! It helps us maintain quality service.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/bookings'] });
      onComplete();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to submit feedback. Please try again.",
        variant: "destructive"
      });
    }
  });

  const handleSubmit = () => {
    const feedbackData = {
      bookingId: booking.id,
      sitterId: booking.sitterId,
      overallRating,
      categoryRatings: categories.reduce((acc, cat) => {
        acc[cat.id] = cat.rating;
        return acc;
      }, {} as Record<string, number>),
      writtenFeedback: writtenFeedback.trim(),
      wouldRecommend,
      flaggedForReview,
      flagReason: flaggedForReview ? flagReason : null
    };

    submitFeedbackMutation.mutate(feedbackData);
  };

  const updateCategoryRating = (categoryId: string, rating: number) => {
    setCategories(prev => prev.map(cat => 
      cat.id === categoryId ? { ...cat, rating } : cat
    ));
  };

  const renderStarRating = (rating: number, onChange: (rating: number) => void, size = 'lg') => {
    const starSize = size === 'lg' ? 'h-8 w-8' : 'h-5 w-5';
    
    return (
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => onChange(star)}
            className={`${starSize} transition-colors ${
              star <= rating 
                ? 'text-amber-400 fill-amber-400' 
                : 'text-gray-300 hover:text-amber-200'
            }`}
          >
            <Star className="w-full h-full" />
          </button>
        ))}
      </div>
    );
  };

  return (
    <div className="max-w-2xl mx-auto p-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-rose flex items-center justify-center overflow-hidden">
              {booking.sitterImage ? (
                <img 
                  src={booking.sitterImage} 
                  alt={booking.sitterName}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="text-lg font-bold text-wine">
                  {booking.sitterName.split(' ').map(n => n[0]).join('')}
                </div>
              )}
            </div>
            <div>
              <h2 className="text-xl font-bold">Rate Your Experience</h2>
              <p className="text-sm text-gray-500">with {booking.sitterName}</p>
            </div>
          </CardTitle>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {/* Booking summary */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-500">Date & Time:</span>
                <div className="font-medium">
                  {new Date(booking.startTime).toLocaleDateString()} 
                  <br />
                  {new Date(booking.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} - 
                  {new Date(booking.endTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
              <div>
                <span className="text-gray-500">Total Cost:</span>
                <div className="font-medium text-wine">{formatCurrency(booking.totalCost)}</div>
              </div>
              <div className="col-span-2">
                <span className="text-gray-500">Children:</span>
                <div className="flex gap-1 mt-1">
                  {booking.children.map((child, index) => (
                    <Badge key={index} variant="outline">{child}</Badge>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Overall rating */}
          <div className="text-center">
            <Label className="text-lg font-semibold block mb-3">
              How was your overall experience?
            </Label>
            {renderStarRating(overallRating, setOverallRating)}
            <p className="text-sm text-gray-500 mt-2">
              {overallRating === 5 ? 'Outstanding!' :
               overallRating === 4 ? 'Great!' :
               overallRating === 3 ? 'Good' :
               overallRating === 2 ? 'Fair' : 'Needs Improvement'}
            </p>
          </div>

          {/* Category ratings */}
          <div>
            <Label className="text-lg font-semibold block mb-4">
              Rate specific aspects:
            </Label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {categories.map((category) => (
                <div key={category.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-2">
                    {category.icon}
                    <span className="font-medium">{category.label}</span>
                  </div>
                  {renderStarRating(category.rating, (rating) => updateCategoryRating(category.id, rating), 'sm')}
                </div>
              ))}
            </div>
          </div>

          {/* Written feedback */}
          <div>
            <Label htmlFor="feedback" className="text-lg font-semibold block mb-2">
              Share your experience (optional)
            </Label>
            <Textarea
              id="feedback"
              placeholder="Tell other parents about your experience with this sitter..."
              value={writtenFeedback}
              onChange={(e) => setWrittenFeedback(e.target.value)}
              className="min-h-[100px]"
              maxLength={500}
            />
            <p className="text-xs text-gray-500 mt-1">
              {writtenFeedback.length}/500 characters
            </p>
          </div>

          {/* Recommendation */}
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <span className="font-medium">Would you recommend {booking.sitterName.split(' ')[0]} to other families?</span>
            <div className="flex gap-2">
              <Button
                variant={wouldRecommend ? "default" : "outline"}
                size="sm"
                onClick={() => setWouldRecommend(true)}
                className={wouldRecommend ? "bg-green-600 hover:bg-green-700" : ""}
              >
                Yes
              </Button>
              <Button
                variant={!wouldRecommend ? "default" : "outline"}
                size="sm"
                onClick={() => setWouldRecommend(false)}
                className={!wouldRecommend ? "bg-red-600 hover:bg-red-700" : ""}
              >
                No
              </Button>
            </div>
          </div>

          {/* Flag for review */}
          <div className="border-t pt-4">
            <div className="flex items-center gap-3 mb-3">
              <button
                type="button"
                onClick={() => setFlaggedForReview(!flaggedForReview)}
                className={`flex items-center gap-2 px-3 py-2 rounded transition-colors ${
                  flaggedForReview 
                    ? 'bg-red-100 text-red-700 border border-red-200' 
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                <Flag className="h-4 w-4" />
                <span className="text-sm">Flag this booking for review</span>
              </button>
            </div>
            
            {flaggedForReview && (
              <Textarea
                placeholder="Please describe the issue that requires admin review..."
                value={flagReason}
                onChange={(e) => setFlagReason(e.target.value)}
                className="text-sm"
                rows={3}
              />
            )}
          </div>

          {/* Submit button */}
          <Button
            onClick={handleSubmit}
            disabled={submitFeedbackMutation.isPending || (flaggedForReview && !flagReason.trim())}
            className="w-full bg-wine hover:bg-wine/90 text-white py-3"
            size="lg"
          >
            {submitFeedbackMutation.isPending ? 'Submitting...' : 'Submit Feedback'}
          </Button>

          <p className="text-xs text-gray-500 text-center">
            Your feedback helps us maintain quality and safety standards for all families.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}