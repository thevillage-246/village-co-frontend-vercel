import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { CalendarDays } from 'lucide-react';

interface RebookPromptProps {
  sitterName: string;
  onRebook: () => void;
}

export function RebookPrompt({ sitterName, onRebook }: RebookPromptProps) {
  return (
    <Card className="border-rose/20 shadow-md">
      <CardHeader className="pb-2">
        <CardTitle className="text-xl flex items-center gap-2 text-wine">
          <CalendarDays className="h-5 w-5" />
          <span>Book with {sitterName} again?</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="pb-2">
        <p className="text-sm text-muted-foreground">
          It looks like your last session with {sitterName} went well! 
          Would you like to schedule another sit?
        </p>
      </CardContent>
      <CardFooter className="flex justify-between pt-2">
        <Button 
          variant="outline" 
          size="sm"
          className="text-muted-foreground border-muted"
        >
          Maybe Later
        </Button>
        <Button 
          onClick={onRebook}
          size="sm"
          className="bg-rose hover:bg-rose/90 text-white"
        >
          Book Now
        </Button>
      </CardFooter>
    </Card>
  );
}