/**
 * Personalized Dashboard - AI-powered home experience for Village Co users
 * Combines AI suggestions, streak tracking, and personalized insights
 */

import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Brain, Sparkles, TrendingUp } from 'lucide-react';
import AiSuggestionWidget from './AiSuggestionWidget';
import StreakTrackerWidget from './StreakTrackerWidget';

interface PersonalizedDashboardProps {
  className?: string;
}

export default function PersonalizedDashboard({ className }: PersonalizedDashboardProps) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className={`space-y-6 ${className}`}>
        <div className="animate-pulse space-y-4">
          <div className="h-32 bg-gray-200 rounded-lg"></div>
          <div className="h-48 bg-gray-200 rounded-lg"></div>
          <div className="h-24 bg-gray-200 rounded-lg"></div>
        </div>
      </div>
    );
  }

  if (!user || user.role !== 'parent') {
    return null; // Only show for parent users
  }

  return (
    <div className={`space-y-6 ${className}`}>
      {/* Welcome Header */}
      <Card className="bg-gradient-to-r from-wine/5 to-eucalyptus/5 border-wine/10">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-xl">
            <Brain className="w-6 h-6 text-wine" />
            Good {getTimeOfDay()}, {user.firstName}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600 leading-relaxed">
            Your personalised Village Co experience is ready. Here's what's happening in your world of self-care.
          </p>
        </CardContent>
      </Card>

      {/* AI Suggestions Section */}
      <div>
        <div className="flex items-center gap-2 mb-4">
          <Sparkles className="w-5 h-5 text-wine" />
          <h2 className="text-lg font-semibold text-gray-900">
            Personalised for You
          </h2>
        </div>
        <AiSuggestionWidget 
          userId={user.id} 
          maxSuggestions={3}
          className="mb-6"
        />
      </div>

      <Separator />

      {/* Streak Tracker Section */}
      <div>
        <div className="flex items-center gap-2 mb-4">
          <TrendingUp className="w-5 h-5 text-eucalyptus-600" />
          <h2 className="text-lg font-semibold text-gray-900">
            Your Progress
          </h2>
        </div>
        <StreakTrackerWidget 
          userId={user.id} 
          showDetails={true}
        />
      </div>

      {/* Quick Actions */}
      <Card className="border-2 border-dashed border-gray-200 bg-gray-50/50">
        <CardContent className="py-6">
          <div className="text-center space-y-2">
            <h3 className="font-medium text-gray-700">Need something specific?</h3>
            <p className="text-sm text-gray-500">
              Browse our sitters, book instantly, or chat with our team for personalized recommendations.
            </p>
            <div className="flex justify-center gap-3 mt-4">
              <a 
                href="/find-sitter" 
                className="inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-wine hover:bg-wine/90 rounded-lg transition-colors"
              >
                Find Sitters
              </a>
              <a 
                href="/messages" 
                className="inline-flex items-center px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 rounded-lg transition-colors"
              >
                Chat with Us
              </a>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Helper function to get time-based greeting
function getTimeOfDay(): string {
  const hour = new Date().getHours();
  
  if (hour < 12) return 'morning';
  if (hour < 17) return 'afternoon';
  if (hour < 21) return 'evening';
  return 'night';
}