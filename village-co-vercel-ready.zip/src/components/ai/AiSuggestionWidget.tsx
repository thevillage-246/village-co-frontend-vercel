/**
 * AI Suggestion Widget - Personalized nudges for Village Co users
 * Displays intelligent, emotionally persuasive suggestions based on user behavior
 */

import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, Clock, Heart, Sparkles, Star, Zap } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';

interface AiSuggestion {
  id: number;
  userId: number;
  suggestionType: string;
  triggerReason: string;
  messageContent: string;
  callToAction: string;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  isActive: boolean;
  displayedAt?: string;
  actionTaken?: string;
  actionTakenAt?: string;
  expiresAt?: string;
  metadata?: any;
  createdAt: string;
  updatedAt: string;
}

interface AiSuggestionWidgetProps {
  userId?: number;
  maxSuggestions?: number;
  className?: string;
}

export default function AiSuggestionWidget({ 
  userId, 
  maxSuggestions = 2, 
  className 
}: AiSuggestionWidgetProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [displayedSuggestions, setDisplayedSuggestions] = useState<Set<number>>(new Set());

  // Fetch AI suggestions for the user
  const { data: suggestionsData, isLoading } = useQuery({
    queryKey: ['/api/ai/suggestions'],
    enabled: !!userId,
    refetchInterval: 5 * 60 * 1000, // Refresh every 5 minutes
  });

  const suggestions: AiSuggestion[] = suggestionsData?.suggestions || [];

  // Mark suggestion as displayed
  const markDisplayedMutation = useMutation({
    mutationFn: async (suggestionId: number) => {
      const response = await fetch(`/api/ai/suggestions/${suggestionId}/displayed`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      
      if (!response.ok) {
        throw new Error('Failed to mark suggestion as displayed');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/ai/suggestions'] });
    },
  });

  // Take action on suggestion
  const takeActionMutation = useMutation({
    mutationFn: async ({ suggestionId, action }: { suggestionId: number; action: string }) => {
      const response = await fetch(`/api/ai/suggestions/${suggestionId}/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to record suggestion action');
      }
      
      return response.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['/api/ai/suggestions'] });
      toast({
        title: "Thanks for the feedback!",
        description: "We'll keep personalizing your experience.",
      });
    },
  });

  // Auto-mark suggestions as displayed when they appear
  useEffect(() => {
    suggestions.forEach(suggestion => {
      if (!suggestion.displayedAt && !displayedSuggestions.has(suggestion.id)) {
        setDisplayedSuggestions(prev => new Set(prev).add(suggestion.id));
        markDisplayedMutation.mutate(suggestion.id);
      }
    });
  }, [suggestions, displayedSuggestions]);

  // Handle action clicks
  const handleAction = (suggestion: AiSuggestion, action: string) => {
    takeActionMutation.mutate({ suggestionId: suggestion.id, action });
    
    // Route to appropriate page based on action
    switch (action) {
      case 'book_break':
        window.location.href = '/find-sitter';
        break;
      case 'plan_night':
        window.location.href = '/find-sitter?time=evening';
        break;
      case 'message_concierge':
        window.location.href = '/messages';
        break;
      default:
        break;
    }
  };

  const handleDismiss = (suggestion: AiSuggestion) => {
    takeActionMutation.mutate({ suggestionId: suggestion.id, action: 'dismissed' });
  };

  // Get priority styling
  const getPriorityStyle = (priority: string) => {
    switch (priority) {
      case 'urgent':
        return {
          border: 'border-red-200 bg-red-50',
          badge: 'bg-red-100 text-red-700',
          icon: Zap,
          iconColor: 'text-red-500'
        };
      case 'high':
        return {
          border: 'border-orange-200 bg-orange-50',
          badge: 'bg-orange-100 text-orange-700',
          icon: Star,
          iconColor: 'text-orange-500'
        };
      case 'medium':
        return {
          border: 'border-blue-200 bg-blue-50',
          badge: 'bg-blue-100 text-blue-700',
          icon: Sparkles,
          iconColor: 'text-blue-500'
        };
      default:
        return {
          border: 'border-eucalyptus-200 bg-eucalyptus-50',
          badge: 'bg-eucalyptus-100 text-eucalyptus-700',
          icon: Heart,
          iconColor: 'text-eucalyptus-500'
        };
    }
  };

  // Get action button text
  const getActionText = (callToAction: string) => {
    switch (callToAction) {
      case 'book_break':
        return 'Book My Break';
      case 'plan_night':
        return 'Plan Date Night';
      case 'message_concierge':
        return 'Chat with Us';
      default:
        return 'Explore';
    }
  };

  if (isLoading) {
    return (
      <div className={cn('space-y-4', className)}>
        <div className="animate-pulse">
          <div className="h-24 bg-gray-200 rounded-lg"></div>
        </div>
      </div>
    );
  }

  if (!suggestions.length) {
    return null; // Don't show widget if no suggestions
  }

  const activeSuggestions = suggestions
    .filter(s => s.isActive)
    .slice(0, maxSuggestions);

  if (!activeSuggestions.length) {
    return null;
  }

  return (
    <div className={cn('space-y-4', className)}>
      {activeSuggestions.map((suggestion) => {
        const priorityStyle = getPriorityStyle(suggestion.priority);
        const Icon = priorityStyle.icon;
        
        return (
          <Card 
            key={suggestion.id} 
            className={cn(
              'relative overflow-hidden transition-all duration-300 hover:shadow-md',
              priorityStyle.border
            )}
          >
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2">
                  <Icon className={cn('w-4 h-4', priorityStyle.iconColor)} />
                  <Badge variant="secondary" className={priorityStyle.badge}>
                    {suggestion.suggestionType.replace('_', ' ')}
                  </Badge>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleDismiss(suggestion)}
                  className="text-gray-400 hover:text-gray-600 p-1 h-auto"
                >
                  ✕
                </Button>
              </div>
            </CardHeader>
            
            <CardContent className="pt-0">
              <p className="text-gray-700 leading-relaxed mb-4">
                {suggestion.messageContent}
              </p>
              
              <div className="flex items-center gap-2">
                <Button
                  onClick={() => handleAction(suggestion, suggestion.callToAction)}
                  disabled={takeActionMutation.isPending}
                  className="bg-wine hover:bg-wine/90 text-white"
                >
                  {getActionText(suggestion.callToAction)}
                </Button>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleDismiss(suggestion)}
                  disabled={takeActionMutation.isPending}
                >
                  Not now
                </Button>
              </div>
              
              {suggestion.metadata?.daysSinceLastBooking && (
                <div className="mt-3 flex items-center gap-1 text-sm text-gray-500">
                  <Clock className="w-3 h-3" />
                  <span>{suggestion.metadata.daysSinceLastBooking} days since last booking</span>
                </div>
              )}
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}