/**
 * Streak Tracker Widget - Gamified achievements for Village Co users
 * Displays user streaks, milestones, and progress towards goals
 */

import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Trophy, Flame, Target, Calendar, Star } from 'lucide-react';
import { cn } from '@/lib/utils';

interface UserStreak {
  id: number;
  userId: number;
  streakType: string;
  currentStreak: number;
  longestStreak: number;
  lastActivityDate: string;
  nextMilestone: number;
  achievementsEarned: string[];
  streakBroken: boolean;
  createdAt: string;
  updatedAt: string;
}

interface StreakTrackerWidgetProps {
  userId?: number;
  className?: string;
  showDetails?: boolean;
}

export default function StreakTrackerWidget({ 
  userId, 
  className,
  showDetails = true 
}: StreakTrackerWidgetProps) {

  // Fetch user streaks
  const { data: streaksData, isLoading } = useQuery({
    queryKey: ['/api/ai/streaks'],
    enabled: !!userId,
    refetchInterval: 10 * 60 * 1000, // Refresh every 10 minutes
  });

  const streaks: UserStreak[] = streaksData?.streaks || [];

  // Get streak type display info
  const getStreakTypeInfo = (streakType: string) => {
    switch (streakType) {
      case 'booking_consistency':
        return {
          name: 'Booking Consistency',
          description: 'Regular self-care habits',
          icon: Calendar,
          color: 'text-blue-500',
          bgColor: 'bg-blue-50',
          borderColor: 'border-blue-200'
        };
      case 'weekly_break':
        return {
          name: 'Weekly Breaks',
          description: 'Taking time for yourself',
          icon: Star,
          color: 'text-wine',
          bgColor: 'bg-rose-50',
          borderColor: 'border-rose-200'
        };
      case 'date_night':
        return {
          name: 'Date Nights',
          description: 'Relationship investment',
          icon: Flame,
          color: 'text-red-500',
          bgColor: 'bg-red-50',
          borderColor: 'border-red-200'
        };
      default:
        return {
          name: streakType.replace('_', ' '),
          description: 'Achievement progress',
          icon: Target,
          color: 'text-eucalyptus-500',
          bgColor: 'bg-eucalyptus-50',
          borderColor: 'border-eucalyptus-200'
        };
    }
  };

  // Get milestone reward text
  const getMilestoneText = (streakType: string, milestone: number) => {
    if (milestone <= 5) return 'Getting started!';
    if (milestone <= 10) return 'Building momentum';
    if (milestone <= 20) return 'Self-care superstar';
    if (milestone <= 50) return 'Village Champion';
    return 'Legendary status';
  };

  // Calculate days since last activity
  const getDaysSinceActivity = (lastActivityDate: string) => {
    const today = new Date();
    const lastActivity = new Date(lastActivityDate);
    const diffTime = Math.abs(today.getTime() - lastActivity.getTime());
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  };

  if (isLoading) {
    return (
      <Card className={cn('animate-pulse', className)}>
        <CardHeader>
          <div className="h-6 bg-gray-200 rounded w-1/2"></div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="h-4 bg-gray-200 rounded"></div>
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!streaks.length) {
    return (
      <Card className={cn('border-dashed border-2 border-gray-200', className)}>
        <CardContent className="text-center py-8">
          <Trophy className="w-8 h-8 text-gray-400 mx-auto mb-2" />
          <p className="text-gray-500 text-sm">
            Start building your self-care streaks!<br />
            Book your first sitter to begin.
          </p>
        </CardContent>
      </Card>
    );
  }

  // Find the most impressive streak to highlight
  const featuredStreak = streaks.reduce((best, current) => 
    current.currentStreak > (best?.currentStreak || 0) ? current : best
  );

  return (
    <div className={cn('space-y-4', className)}>
      {/* Featured Streak */}
      {featuredStreak && (
        <Card className="bg-gradient-to-r from-wine/5 to-rose/5 border-wine/20">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg flex items-center gap-2">
                <Flame className="w-5 h-5 text-wine" />
                Your Longest Streak
              </CardTitle>
              <Badge variant="secondary" className="bg-wine/10 text-wine">
                {featuredStreak.currentStreak} days
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="space-y-3">
              <div>
                <p className="font-medium text-gray-700">
                  {getStreakTypeInfo(featuredStreak.streakType).name}
                </p>
                <p className="text-sm text-gray-500">
                  {getMilestoneText(featuredStreak.streakType, featuredStreak.currentStreak)}
                </p>
              </div>
              
              {showDetails && (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Progress to next milestone</span>
                    <span className="text-gray-900 font-medium">
                      {featuredStreak.currentStreak}/{featuredStreak.nextMilestone}
                    </span>
                  </div>
                  <Progress 
                    value={(featuredStreak.currentStreak / featuredStreak.nextMilestone) * 100} 
                    className="h-2"
                  />
                  
                  {featuredStreak.longestStreak > featuredStreak.currentStreak && (
                    <p className="text-xs text-gray-500">
                      Personal best: {featuredStreak.longestStreak} days
                    </p>
                  )}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* All Streaks */}
      {showDetails && streaks.length > 1 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Trophy className="w-4 h-4 text-eucalyptus-600" />
              All Achievements
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {streaks.map((streak) => {
              const typeInfo = getStreakTypeInfo(streak.streakType);
              const Icon = typeInfo.icon;
              const daysSince = getDaysSinceActivity(streak.lastActivityDate);
              
              return (
                <div key={streak.id} className="flex items-center justify-between p-3 rounded-lg bg-gray-50">
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      'p-2 rounded-full',
                      typeInfo.bgColor,
                      typeInfo.borderColor,
                      'border'
                    )}>
                      <Icon className={cn('w-4 h-4', typeInfo.color)} />
                    </div>
                    <div>
                      <p className="font-medium text-sm">{typeInfo.name}</p>
                      <p className="text-xs text-gray-500">
                        {daysSince === 0 ? 'Active today' : `${daysSince} days ago`}
                      </p>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <Badge variant="outline" className="text-xs">
                      {streak.currentStreak} days
                    </Badge>
                    {streak.achievementsEarned.length > 0 && (
                      <p className="text-xs text-eucalyptus-600 mt-1">
                        {streak.achievementsEarned.length} awards
                      </p>
                    )}
                  </div>
                </div>
              );
            })}
          </CardContent>
        </Card>
      )}
    </div>
  );
}