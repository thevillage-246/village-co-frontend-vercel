/**
 * AI Notification Badge - Dashboard notification system for Village Co users
 * Displays AI suggestions as notification badges with dismissible actions
 */

import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Bell, BellRing, X, Sparkles, Heart, Zap, Star } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';

interface AiNotificationBadgeProps {
  userId?: number;
  className?: string;
  maxNotifications?: number;
}

export default function AiNotificationBadge({ 
  userId, 
  className,
  maxNotifications = 3 
}: AiNotificationBadgeProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isExpanded, setIsExpanded] = useState(false);
  const [dismissedSuggestions, setDismissedSuggestions] = useState<Set<number>>(new Set());

  // Fetch AI suggestions for notifications
  const { data: suggestionsData, isLoading } = useQuery({
    queryKey: ['/api/ai/suggestions'],
    enabled: !!userId,
    refetchInterval: 5 * 60 * 1000, // Refresh every 5 minutes
  });

  const suggestions = suggestionsData?.suggestions || [];
  const activeNotifications = suggestions
    .filter(s => s.isActive && !dismissedSuggestions.has(s.id))
    .slice(0, maxNotifications);

  // Dismiss notification
  const dismissMutation = useMutation({
    mutationFn: async (suggestionId: number) => {
      const response = await fetch(`/api/ai/suggestions/${suggestionId}/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'dismissed' }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to dismiss notification');
      }
      
      return response.json();
    },
    onSuccess: (_, suggestionId) => {
      setDismissedSuggestions(prev => new Set(prev).add(suggestionId));
      queryClient.invalidateQueries({ queryKey: ['/api/ai/suggestions'] });
    },
  });

  // Take action on notification
  const actionMutation = useMutation({
    mutationFn: async ({ suggestionId, action }: { suggestionId: number; action: string }) => {
      const response = await fetch(`/api/ai/suggestions/${suggestionId}/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to record notification action');
      }
      
      return response.json();
    },
    onSuccess: (_, variables) => {
      setDismissedSuggestions(prev => new Set(prev).add(variables.suggestionId));
      queryClient.invalidateQueries({ queryKey: ['/api/ai/suggestions'] });
      toast({
        title: "Thanks!",
        description: "We'll keep personalizing your experience.",
      });
    },
  });

  const handleAction = (suggestion: any, action: string) => {
    actionMutation.mutate({ suggestionId: suggestion.id, action });
    
    // Navigate based on action
    switch (action) {
      case 'book_break':
        window.location.href = '/find-sitter';
        break;
      case 'plan_night':
        window.location.href = '/find-sitter?time=evening';
        break;
      case 'message_concierge':
        window.location.href = '/messages';
        break;
      default:
        break;
    }
  };

  const handleDismiss = (suggestionId: number) => {
    dismissMutation.mutate(suggestionId);
  };

  // Get priority styling
  const getPriorityStyle = (priority: string) => {
    switch (priority) {
      case 'urgent':
        return {
          bg: 'bg-red-50 border-red-200',
          text: 'text-red-800',
          icon: Zap,
          iconColor: 'text-red-500',
          pulse: true
        };
      case 'high':
        return {
          bg: 'bg-orange-50 border-orange-200',
          text: 'text-orange-800',
          icon: Star,
          iconColor: 'text-orange-500',
          pulse: false
        };
      case 'medium':
        return {
          bg: 'bg-blue-50 border-blue-200',
          text: 'text-blue-800',
          icon: Sparkles,
          iconColor: 'text-blue-500',
          pulse: false
        };
      default:
        return {
          bg: 'bg-wine/10 border-wine/20',
          text: 'text-wine',
          icon: Heart,
          iconColor: 'text-wine',
          pulse: false
        };
    }
  };

  if (isLoading || !activeNotifications.length) {
    return null;
  }

  return (
    <div className={cn('relative', className)}>
      {/* Notification Bell */}
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setIsExpanded(!isExpanded)}
        className="relative p-2 hover:bg-wine/10"
      >
        {activeNotifications.length > 0 ? (
          <BellRing className="w-5 h-5 text-wine" />
        ) : (
          <Bell className="w-5 h-5 text-gray-400" />
        )}
        
        {activeNotifications.length > 0 && (
          <span className="absolute -top-1 -right-1 w-5 h-5 bg-wine text-white text-xs font-medium rounded-full flex items-center justify-center animate-pulse">
            {activeNotifications.length}
          </span>
        )}
      </Button>

      {/* Notification Dropdown */}
      {isExpanded && (
        <Card className="absolute top-full right-0 mt-2 w-80 shadow-lg border-wine/20 z-50">
          <CardContent className="p-0">
            <div className="p-4 border-b border-gray-100">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-wine flex items-center gap-2">
                  <Sparkles className="w-4 h-4" />
                  Village Suggestions
                </h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsExpanded(false)}
                  className="p-1 h-auto"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>
            
            <div className="max-h-96 overflow-y-auto">
              {activeNotifications.map((suggestion) => {
                const style = getPriorityStyle(suggestion.priority);
                const Icon = style.icon;
                
                return (
                  <div
                    key={suggestion.id}
                    className={cn(
                      'p-4 border-b border-gray-100 last:border-b-0 transition-all duration-200',
                      style.bg,
                      style.pulse && 'animate-pulse'
                    )}
                  >
                    <div className="flex items-start gap-3">
                      <Icon className={cn('w-4 h-4 mt-1 flex-shrink-0', style.iconColor)} />
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1">
                            <Badge 
                              variant="secondary" 
                              className={cn('text-xs mb-2', style.text, 'bg-transparent')}
                            >
                              {suggestion.suggestionType.replace('_', ' ')}
                            </Badge>
                            <p className="text-sm text-gray-700 leading-relaxed mb-3">
                              {suggestion.messageContent}
                            </p>
                          </div>
                          
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDismiss(suggestion.id)}
                            disabled={dismissMutation.isPending}
                            className="p-1 h-auto text-gray-400 hover:text-gray-600"
                          >
                            <X className="w-3 h-3" />
                          </Button>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <Button
                            size="sm"
                            onClick={() => handleAction(suggestion, suggestion.callToAction)}
                            disabled={actionMutation.isPending}
                            className="bg-wine hover:bg-wine/90 text-white text-xs px-3 py-1 h-auto"
                          >
                            {getActionText(suggestion.callToAction)}
                          </Button>
                          
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDismiss(suggestion.id)}
                            disabled={dismissMutation.isPending}
                            className="text-xs text-gray-500 hover:text-gray-700 px-2 py-1 h-auto"
                          >
                            Not now
                          </Button>
                        </div>
                        
                        {suggestion.metadata?.daysSinceLastBooking && (
                          <p className="text-xs text-gray-500 mt-2">
                            {suggestion.metadata.daysSinceLastBooking} days since last booking
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
            
            {activeNotifications.length === 0 && (
              <div className="p-8 text-center">
                <Bell className="w-8 h-8 text-gray-300 mx-auto mb-2" />
                <p className="text-sm text-gray-500">All caught up!</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// Helper function for action text
function getActionText(callToAction: string): string {
  switch (callToAction) {
    case 'book_break': return 'Book Break';
    case 'plan_night': return 'Plan Night';
    case 'message_concierge': return 'Chat';
    default: return 'Explore';
  }
}