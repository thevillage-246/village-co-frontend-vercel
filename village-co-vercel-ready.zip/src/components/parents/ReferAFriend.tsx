import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';
import { Copy, Share2, DollarSign, Users, Gift, CheckCircle } from 'lucide-react';

interface ReferralData {
  referralCode: string;
  totalReferrals: number;
  pendingReferrals: number;
  creditBalance: number;
  recentReferrals: Array<{
    id: number;
    refereeEmail: string;
    status: string;
    createdAt: string;
    rewardAmount: string;
  }>;
}

export default function ReferAFriend() {
  const [email, setEmail] = useState('');
  const [isSharing, setIsSharing] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch referral data
  const { data: referralData, isLoading } = useQuery<ReferralData>({
    queryKey: ['/api/referrals/mine'],
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  // Apply referral code mutation
  const applyReferralMutation = useMutation({
    mutationFn: async (email: string) => {
      const response = await fetch('/api/referrals/apply', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to send referral');
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Referral sent!",
        description: "Your friend will receive an invitation to join The Village Co. You'll get $10 credit when they complete their first booking.",
      });
      setEmail('');
      queryClient.invalidateQueries({ queryKey: ['/api/referrals/mine'] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to send referral",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const copyReferralCode = async () => {
    if (referralData?.referralCode) {
      try {
        await navigator.clipboard.writeText(referralData.referralCode);
        toast({
          title: "Copied!",
          description: "Referral code copied to clipboard",
        });
      } catch (err) {
        // Fallback for older browsers
        const textArea = document.createElement('textarea');
        textArea.value = referralData.referralCode;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
        
        toast({
          title: "Copied!",
          description: "Referral code copied to clipboard",
        });
      }
    }
  };

  const shareReferral = async () => {
    if (!referralData?.referralCode) return;
    
    setIsSharing(true);
    
    const shareData = {
      title: 'Join The Village Co!',
      text: `Hey! I've been using The Village Co for trusted babysitting and thought you'd love it too. Use my referral code ${referralData.referralCode} when you sign up and we both get $10 credit! 🎉`,
      url: `${window.location.origin}/signup?ref=${referralData.referralCode}`,
    };

    try {
      if (navigator.share && navigator.canShare(shareData)) {
        await navigator.share(shareData);
      } else {
        // Fallback to copying URL
        await navigator.clipboard.writeText(`${shareData.text}\n\nSign up here: ${shareData.url}`);
        toast({
          title: "Copied to clipboard!",
          description: "Share this message with your friends",
        });
      }
    } catch (err) {
      console.error('Error sharing:', err);
    } finally {
      setIsSharing(false);
    }
  };

  const handleEmailReferral = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      applyReferralMutation.mutate(email.trim());
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="flex justify-center py-8">
          <div className="animate-spin h-8 w-8 border-4 border-village-wine border-t-transparent rounded-full"></div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-village-wine/20 shadow-lg">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2 text-village-wine">
              <Gift className="h-5 w-5" />
              Refer a Friend
            </CardTitle>
            <CardDescription>
              Share The Village Co. and both get $10 credit
            </CardDescription>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-village-wine">
              ${referralData?.creditBalance || 0}
            </p>
            <p className="text-sm text-muted-foreground">Available Credit</p>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Quick Stats */}
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center p-3 bg-village-wine/10 rounded-lg">
            <div className="flex items-center justify-center mb-1">
              <Users className="h-4 w-4 text-village-wine mr-1" />
              <span className="font-bold text-village-wine">{referralData?.totalReferrals || 0}</span>
            </div>
            <p className="text-sm text-muted-foreground">Friends Referred</p>
          </div>
          <div className="text-center p-3 bg-brushed-pink rounded-lg">
            <div className="flex items-center justify-center mb-1">
              <DollarSign className="h-4 w-4 text-village-wine mr-1" />
              <span className="font-bold text-village-wine">${(referralData?.totalReferrals || 0) * 10}</span>
            </div>
            <p className="text-sm text-muted-foreground">Total Earned</p>
          </div>
        </div>

        <Separator />

        {/* Referral Code Section */}
        <div className="space-y-3">
          <Label className="text-sm font-medium">Your Referral Code</Label>
          <div className="flex gap-2">
            <Input
              value={referralData?.referralCode || ''}
              readOnly
              className="font-mono bg-muted"
            />
            <Button
              variant="outline"
              size="icon"
              onClick={copyReferralCode}
              title="Copy referral code"
            >
              <Copy className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={shareReferral}
              disabled={isSharing}
              title="Share referral"
            >
              <Share2 className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <Separator />

        {/* Email Referral Form */}
        <form onSubmit={handleEmailReferral} className="space-y-3">
          <Label htmlFor="friend-email">Invite by Email</Label>
          <div className="flex gap-2">
            <Input
              id="friend-email"
              type="email"
              placeholder="friend@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="flex-1"
            />
            <Button
              type="submit"
              disabled={!email.trim() || applyReferralMutation.isPending}
              className="bg-village-wine hover:bg-village-wine/90"
            >
              {applyReferralMutation.isPending ? 'Sending...' : 'Send Invite'}
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">
            Your friend will receive an invitation email with your referral code
          </p>
        </form>

        {/* Recent Referrals */}
        {referralData?.recentReferrals && referralData.recentReferrals.length > 0 && (
          <>
            <Separator />
            <div className="space-y-3">
              <Label className="text-sm font-medium">Recent Referrals</Label>
              <div className="space-y-2 max-h-32 overflow-y-auto">
                {referralData.recentReferrals.map((referral) => (
                  <div key={referral.id} className="flex items-center justify-between p-2 bg-muted/50 rounded">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">
                        {referral.refereeEmail}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(referral.createdAt).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      {referral.status === 'completed' ? (
                        <>
                          <Badge variant="secondary" className="text-green-600">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            +$10
                          </Badge>
                        </>
                      ) : (
                        <Badge variant="outline">Pending</Badge>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {/* How it Works */}
        <div className="bg-village-wine/10 p-4 rounded-lg">
          <h4 className="font-medium text-village-wine mb-2">How it works:</h4>
          <ol className="text-sm text-muted-foreground space-y-1">
            <li>1. Share your referral code with friends</li>
            <li>2. They sign up and complete their first booking</li>
            <li>3. You both get $10 credit automatically</li>
            <li>4. Use your credit on any future bookings</li>
          </ol>
        </div>
      </CardContent>
    </Card>
  );
}