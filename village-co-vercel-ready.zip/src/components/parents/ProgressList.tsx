import { Check, AlertCircle, Clock, User, Shield, CreditCard, Users } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useLocation } from 'wouter';

interface ProgressItem {
  id: string;
  title: string;
  description: string;
  status: 'completed' | 'pending' | 'required';
  icon: React.ReactNode;
  action?: {
    label: string;
    path: string;
  };
}

interface ProgressListProps {
  user: any;
  parentProfile: any;
  verificationStatus?: string;
}

export function ProgressList({ user, parentProfile, verificationStatus }: ProgressListProps) {
  const [, setLocation] = useLocation();

  const getProgressItems = (): ProgressItem[] => {
    const items: ProgressItem[] = [
      {
        id: 'profile',
        title: 'Complete Your Profile',
        description: 'Add your bio, address, and children information',
        status: parentProfile?.bio && parentProfile?.address && parentProfile?.children?.length > 0 ? 'completed' : 'required',
        icon: <User className="w-5 h-5" />,
        action: {
          label: 'Complete Profile',
          path: '/parent/edit-profile'
        }
      },
      {
        id: 'verification',
        title: 'Verify Your Identity',
        description: 'Complete ID verification for account security',
        status: user?.isVerified || verificationStatus === 'approved' ? 'completed' : 'required',
        icon: <Shield className="w-5 h-5" />,
        action: {
          label: 'Start Verification',
          path: '/parent/verification'
        }
      },
      {
        id: 'payment',
        title: 'Add Payment Method',
        description: 'Add a payment method for booking sitters',
        status: user?.stripeCustomerId ? 'completed' : 'required',
        icon: <CreditCard className="w-5 h-5" />,
        action: {
          label: 'Add Payment',
          path: '/parent/payment'
        }
      },
      {
        id: 'first-booking',
        title: 'Make Your First Booking',
        description: 'Book a trusted sitter from our community',
        status: 'pending',
        icon: <Users className="w-5 h-5" />,
        action: {
          label: 'Find Sitters',
          path: '/find-sitter'
        }
      }
    ];

    return items;
  };

  const progressItems = getProgressItems();
  const completedItems = progressItems.filter(item => item.status === 'completed').length;
  const totalItems = progressItems.length;
  const progressPercentage = Math.round((completedItems / totalItems) * 100);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <Check className="w-5 h-5 text-green-600" />;
      case 'required':
        return <AlertCircle className="w-5 h-5 text-orange-500" />;
      case 'pending':
        return <Clock className="w-5 h-5 text-yellow-500" />;
      default:
        return <Clock className="w-5 h-5 text-gray-400" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge variant="default" className="bg-green-100 text-green-800 border-green-200">Complete</Badge>;
      case 'required':
        return <Badge variant="default" className="bg-orange-100 text-orange-800 border-orange-200">Required</Badge>;
      case 'pending':
        return null; // Remove optional badge
      default:
        return <Badge variant="outline">Pending</Badge>;
    }
  };

  return (
    <Card className="w-full">
      <CardHeader className="pb-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 sm:gap-0">
          <CardTitle className="text-village-wine text-lg sm:text-xl">Getting Started</CardTitle>
          <Badge variant="outline" className="text-village-wine border-village-wine text-xs sm:text-sm self-start sm:self-auto">
            {completedItems}/{totalItems} Complete ({progressPercentage}%)
          </Badge>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2 mt-3">
          <div 
            className="bg-village-wine h-2 rounded-full transition-all duration-300"
            style={{ width: `${progressPercentage}%` }}
          />
        </div>
      </CardHeader>
      
      <CardContent className="pt-2">
        <div className="space-y-3 sm:space-y-4">
          {progressItems.map((item) => (
            <div 
              key={item.id}
              className={`flex flex-col sm:flex-row sm:items-center sm:justify-between p-4 rounded-lg border transition-all duration-200 gap-3 ${
                item.status === 'completed' 
                  ? 'bg-green-50 border-green-200' 
                  : item.status === 'required'
                  ? 'bg-orange-50 border-orange-200'
                  : 'bg-gray-50 border-gray-200'
              }`}
            >
              <div className="flex items-center space-x-3 flex-1">
                <div className="flex items-center justify-center w-10 h-10 sm:w-8 sm:h-8 rounded-full bg-white border flex-shrink-0">
                  {item.status === 'completed' ? getStatusIcon(item.status) : item.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-2">
                    <h3 className="font-medium text-gray-900 text-base sm:text-sm">{item.title}</h3>
                    {getStatusBadge(item.status)}
                  </div>
                  <p className="text-sm text-gray-600 mt-1 leading-relaxed">{item.description}</p>
                </div>
              </div>
              
              <div className="flex items-center justify-between sm:justify-end space-x-2 mt-2 sm:mt-0">
                <div className="sm:hidden">
                  {getStatusIcon(item.status)}
                </div>
                <div className="hidden sm:flex items-center space-x-2">
                  {getStatusIcon(item.status)}
                </div>
                {item.status !== 'completed' && item.action && (
                  <Button
                    variant={item.status === 'required' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setLocation(item.action!.path)}
                    className={`${item.status === 'required' ? 'bg-village-wine hover:bg-village-wine/90' : ''} w-full sm:w-auto`}
                  >
                    {item.action.label}
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
        
        {progressPercentage === 100 && (
          <div className="mt-4 sm:mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
            <div className="flex items-center space-x-2">
              <Check className="w-5 h-5 text-green-600 flex-shrink-0" />
              <h3 className="font-medium text-green-800 text-base sm:text-lg">All Set!</h3>
            </div>
            <p className="text-sm text-green-700 mt-2 leading-relaxed">
              Your account is fully set up. You're ready to start booking trusted sitters!
            </p>
            <Button
              className="mt-3 w-full sm:w-auto bg-village-wine hover:bg-village-wine/90"
              onClick={() => setLocation('/find-sitter')}
            >
              Find Your Perfect Sitter
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}