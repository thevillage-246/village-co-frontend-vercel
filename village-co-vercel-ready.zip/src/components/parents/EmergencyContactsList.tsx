import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger
} from '@/components/ui/alert-dialog';
import { Trash2, Phone, Mail, AlertCircle, Loader2 } from 'lucide-react';

// Type for emergency contact from API
interface EmergencyContact {
  id: number;
  parentId: number;
  name: string;
  relationship: string;
  phone: string;
  email?: string;
  notes?: string;
  createdAt: string;
}

interface EmergencyContactsListProps {
  parentId: number;
}

export default function EmergencyContactsList({ parentId }: EmergencyContactsListProps) {
  const [deleteContactId, setDeleteContactId] = useState<number | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  // Fetch emergency contacts
  const { data: contacts, isLoading, isError, error } = useQuery({
    queryKey: ['emergency-contacts', parentId],
    queryFn: async () => {
      const response = await apiRequest('GET', `/api/parents/${parentId}/emergency-contacts`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch emergency contacts');
      }
      
      return response.json();
    }
  });
  
  // Delete contact mutation
  const deleteContactMutation = useMutation({
    mutationFn: async (contactId: number) => {
      const response = await apiRequest(
        'DELETE', 
        `/api/parents/${parentId}/emergency-contacts/${contactId}`
      );
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to delete emergency contact');
      }
      
      return response.json();
    },
    onSuccess: () => {
      // Invalidate and refetch contacts
      queryClient.invalidateQueries({ queryKey: ['emergency-contacts', parentId] });
      
      toast({
        title: 'Contact deleted',
        description: 'The emergency contact has been removed successfully.',
      });
      
      setDeleteContactId(null);
      setIsDeleting(false);
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to delete contact',
        description: error.message,
        variant: 'destructive',
      });
      setIsDeleting(false);
    },
  });
  
  const handleDeleteClick = (contact: EmergencyContact) => {
    setDeleteContactId(contact.id);
  };
  
  const confirmDelete = async () => {
    if (!deleteContactId) return;
    
    setIsDeleting(true);
    try {
      await deleteContactMutation.mutateAsync(deleteContactId);
    } catch (err) {
      // Error is handled in the mutation callbacks
    }
  };
  
  const cancelDelete = () => {
    setDeleteContactId(null);
  };
  
  // Loading state
  if (isLoading) {
    return (
      <Card className="bg-linen/30">
        <CardContent className="flex items-center justify-center py-8">
          <Loader2 className="h-8 w-8 animate-spin text-wine" />
          <span className="ml-2 text-wine">Loading emergency contacts...</span>
        </CardContent>
      </Card>
    );
  }
  
  // Error state
  if (isError) {
    return (
      <Card className="bg-linen/30 border-wine/20">
        <CardContent className="flex items-center justify-center py-8 text-wine">
          <AlertCircle className="h-6 w-6 mr-2" />
          <span>Error: {(error as Error).message}</span>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <>
      {contacts && contacts.length > 0 ? (
        <div className="space-y-4">
          {contacts.map((contact: EmergencyContact) => (
            <Card key={contact.id} className="bg-white border border-gray-200 shadow-sm">
              <CardContent className="p-4">
                <div className="flex justify-between items-start">
                  <div className="flex-1 space-y-3">
                    {/* Name and Relationship */}
                    <div>
                      <h3 className="font-semibold text-village-wine text-lg">{contact.name}</h3>
                      <p className="text-sm text-gray-600">{contact.relationship}</p>
                    </div>
                    
                    {/* Contact Information */}
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Phone className="h-4 w-4 text-village-wine flex-shrink-0" />
                        <a 
                          href={`tel:${contact.phone}`}
                          className="text-sm font-medium text-village-wine hover:underline"
                        >
                          {contact.phone}
                        </a>
                      </div>
                      {contact.email && (
                        <div className="flex items-center space-x-2">
                          <Mail className="h-4 w-4 text-village-wine flex-shrink-0" />
                          <a 
                            href={`mailto:${contact.email}`}
                            className="text-sm text-gray-600 hover:underline"
                          >
                            {contact.email}
                          </a>
                        </div>
                      )}
                    </div>
                    
                    {/* Notes */}
                    {contact.notes && (
                      <div className="bg-gray-50 rounded-lg p-3">
                        <p className="text-sm text-gray-700">{contact.notes}</p>
                      </div>
                    )}
                  </div>
                  
                  {/* Delete Button */}
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button 
                        variant="ghost" 
                        size="icon"
                        className="h-8 w-8 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-full flex-shrink-0 ml-4"
                        onClick={() => handleDeleteClick(contact)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete Emergency Contact</AlertDialogTitle>
                        <AlertDialogDescription>
                          Are you sure you want to remove {contact.name} from your emergency contacts?
                          This action cannot be undone.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel onClick={cancelDelete}>Cancel</AlertDialogCancel>
                        <AlertDialogAction 
                          onClick={confirmDelete}
                          className="bg-destructive text-destructive-foreground"
                          disabled={isDeleting}
                        >
                          {isDeleting ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Deleting...
                            </>
                          ) : (
                            'Delete'
                          )}
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card className="bg-gray-50 border-2 border-dashed border-gray-200">
          <CardContent className="p-8 text-center">
            <div className="flex flex-col items-center space-y-4">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center">
                <Phone className="h-8 w-8 text-gray-400" />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">No Emergency Contacts</h3>
                <p className="text-sm text-gray-600 leading-relaxed max-w-md">
                  Add emergency contacts so sitters know who to contact if anything comes up during a booking.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </>
  );
}