import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Shield, CheckCircle, Clock, AlertTriangle, ExternalLink } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface VerificationStatus {
  status: 'not_started' | 'pending' | 'approved' | 'declined' | 'expired' | 'resubmitted';
  startedAt?: string;
  completedAt?: string;
  failureReason?: string;
  message?: string;
}

export default function ParentVeriffVerification() {
  const [verificationStatus, setVerificationStatus] = useState<VerificationStatus | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isStarting, setIsStarting] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    checkVerificationStatus();
  }, []);

  const checkVerificationStatus = async () => {
    try {
      const response = await apiRequest('GET', '/api/veriff/parent-status');
      if (!response.ok) {
        if (response.status === 401) {
          toast({
            title: "Session Expired",
            description: "Please refresh the page and log in again.",
            variant: "destructive"
          });
          return;
        }
        throw new Error(`HTTP ${response.status}`);
      }
      const data = await response.json();
      setVerificationStatus(data);
    } catch (error) {
      console.error('Failed to check verification status:', error);
      setVerificationStatus({
        status: 'not_started',
        message: 'Identity verification not yet started'
      });
    } finally {
      setIsLoading(false);
    }
  };

  const startVerification = async () => {
    setIsStarting(true);
    try {
      const response = await apiRequest('POST', '/api/veriff/parent-start-verification');
      
      if (!response.ok) {
        if (response.status === 401) {
          toast({
            title: "Session Expired",
            description: "Please refresh the page and log in again.",
            variant: "destructive"
          });
          return;
        }
        throw new Error(`HTTP ${response.status}`);
      }
      
      const data = await response.json();

      if (data.verification && data.verification.url) {
        // Open verification in new tab for better user experience
        window.open(data.verification.url, '_blank');
        
        toast({
          title: "Verification Started",
          description: "Please complete the identity verification in the new tab."
        });

        // Update status to pending
        setVerificationStatus({
          status: 'pending',
          startedAt: new Date().toISOString(),
          message: 'Identity verification in progress'
        });
      } else {
        throw new Error(data.message || 'Failed to start verification');
      }
    } catch (error: any) {
      console.error('Failed to start verification:', error);
      toast({
        title: "Verification Failed",
        description: error.message || "Unable to start identity verification. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsStarting(false);
    }
  };

  const initializeVeriffSDK = (sessionToken: string) => {
    // Load Veriff SDK if not already loaded
    if (!(window as any).Veriff) {
      const script1 = document.createElement('script');
      script1.src = 'https://cdn.veriff.me/sdk/js/1.5/veriff.min.js';
      script1.onload = () => {
        const script2 = document.createElement('script');
        script2.src = 'https://cdn.veriff.me/incontext/js/v1/veriff.js';
        script2.onload = () => mountVeriff(sessionToken);
        document.head.appendChild(script2);
      };
      document.head.appendChild(script1);
    } else {
      mountVeriff(sessionToken);
    }
  };

  const mountVeriff = (sessionToken: string) => {
    // Show the verification container
    const container = document.getElementById('veriff-root-parent');
    if (container) {
      container.classList.remove('hidden');
    }

    const veriff = (window as any).Veriff({
      host: 'https://stationapi.veriff.com',
      apiKey: import.meta.env.VITE_VERIFF_API_KEY || '947b35eb-163b-4e36-8014-2ba498698b7f',
      parentId: 'veriff-root-parent',
      onSession: function(err: any, response: any) {
        if (err) {
          console.error('Veriff session error:', err);
          toast({
            title: "Verification Error",
            description: "Unable to start verification session. Please try again.",
            variant: "destructive"
          });
          return;
        }
        
        if ((window as any).veriffSDK) {
          (window as any).veriffSDK.createVeriffFrame({ 
            url: response.verification.url,
            onSuccess: () => {
              toast({
                title: "Verification Complete",
                description: "Your identity verification has been submitted for review."
              });
              setTimeout(() => checkVerificationStatus(), 2000);
            },
            onCancel: () => {
              toast({
                title: "Verification Cancelled",
                description: "Identity verification was cancelled. You can restart anytime."
              });
              if (container) {
                container.classList.add('hidden');
              }
            }
          });
        }
      }
    });
    
    veriff.setParams({
      vendorData: sessionToken
    });
    veriff.mount();
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
        return <Badge className="bg-green-100 text-green-800 border-green-200">Verified</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200">Pending</Badge>;
      case 'declined':
        return <Badge className="bg-red-100 text-red-800 border-red-200">Declined</Badge>;
      case 'expired':
        return <Badge className="bg-gray-100 text-gray-800 border-gray-200">Expired</Badge>;
      default:
        return <Badge className="bg-blue-100 text-blue-800 border-blue-200">Not Started</Badge>;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved':
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'pending':
        return <Clock className="h-5 w-5 text-yellow-600" />;
      case 'declined':
      case 'expired':
        return <AlertTriangle className="h-5 w-5 text-red-600" />;
      default:
        return <Shield className="h-5 w-5 text-village-wine" />;
    }
  };

  if (isLoading) {
    return (
      <Card className="border-village-wine/20 shadow-lg">
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            <div className="animate-spin w-6 h-6 border-4 border-village-wine border-t-transparent rounded-full" />
            <span className="ml-2 text-almond-frost">Checking verification status...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  const status = verificationStatus?.status || 'not_started';

  return (
    <div className="space-y-6">
      <Card className="border-village-wine/20 shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-village-wine">
            {getStatusIcon(status)}
            Identity Verification
          </CardTitle>
          <CardDescription>
            Complete your ID verification to book trusted sitters and ensure safety for your family.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium">Verification Status</h4>
              <p className="text-sm text-muted-foreground">
                {verificationStatus?.message || 'Complete identity verification to start booking sitters'}
              </p>
            </div>
            {getStatusBadge(status)}
          </div>

          {status === 'not_started' && (
            <div className="space-y-4">
              <Alert className="border-village-wine/20 bg-village-wine/5">
                <Shield className="h-4 w-4 text-village-wine" />
                <AlertDescription className="text-village-wine">
                  We use Veriff, a trusted identity verification service, to ensure the safety of all families and sitters on our platform.
                </AlertDescription>
              </Alert>
              
              <div className="bg-village-linen p-4 rounded-lg border border-village-wine/10">
                <h5 className="font-medium mb-2 text-village-wine">What you'll need:</h5>
                <ul className="text-sm text-almond-frost space-y-1">
                  <li>• A valid government-issued photo ID and passport</li>
                  <li>• A smartphone or computer with a camera</li>
                  <li>• 5-10 minutes of your time</li>
                </ul>
              </div>

              <Button 
                onClick={startVerification}
                disabled={isStarting}
                className="w-full bg-village-wine hover:bg-village-wine/90"
              >
                {isStarting ? (
                  <>
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                    Starting Verification...
                  </>
                ) : (
                  <>
                    <ExternalLink className="h-4 w-4 mr-2" />
                    Start Identity Verification
                  </>
                )}
              </Button>
              
              {/* Veriff SDK Container */}
              <div id="veriff-root-parent" className="mt-6 min-h-[400px] border rounded-lg bg-white hidden"></div>
            </div>
          )}

          {status === 'pending' && (
            <div className="space-y-4">
              <Alert className="border-yellow-200 bg-yellow-50">
                <Clock className="h-4 w-4 text-yellow-600" />
                <AlertDescription className="text-yellow-800">
                  Your identity verification is being processed. This usually takes a few minutes, but can take up to 24 hours during busy periods.
                </AlertDescription>
              </Alert>

              <div className="text-center py-4">
                <div className="animate-pulse text-yellow-600 mb-2">
                  <Clock className="h-8 w-8 mx-auto" />
                </div>
                <p className="text-sm text-muted-foreground">
                  Started: {verificationStatus?.startedAt ? new Date(verificationStatus.startedAt).toLocaleDateString() : 'Recently'}
                </p>
              </div>

              <Button 
                onClick={checkVerificationStatus}
                variant="outline"
                className="w-full border-village-wine text-village-wine hover:bg-village-wine hover:text-white"
              >
                Check Status
              </Button>
            </div>
          )}

          {status === 'approved' && (
            <div className="space-y-4">
              <Alert className="border-green-200 bg-green-50">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertDescription className="text-green-800">
                  Great! Your identity has been verified. You can now book trusted sitters for your family.
                </AlertDescription>
              </Alert>

              <div className="text-center py-4">
                <CheckCircle className="h-12 w-12 text-green-600 mx-auto mb-2" />
                <p className="font-medium text-green-800">Identity Verified</p>
                <p className="text-sm text-muted-foreground">
                  Completed: {verificationStatus?.completedAt ? new Date(verificationStatus.completedAt).toLocaleDateString() : 'Recently'}
                </p>
              </div>
            </div>
          )}

          {(status === 'declined' || status === 'expired') && (
            <div className="space-y-4">
              <Alert className="border-red-200 bg-red-50">
                <AlertTriangle className="h-4 w-4 text-red-600" />
                <AlertDescription className="text-red-800">
                  {status === 'declined' 
                    ? 'Identity verification was declined. Please try again with clearer photos.'
                    : 'Your verification session has expired. Please start a new verification.'
                  }
                </AlertDescription>
              </Alert>

              <Button 
                onClick={startVerification}
                disabled={isStarting}
                className="w-full bg-village-wine hover:bg-village-wine/90"
              >
                {isStarting ? (
                  <>
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                    Starting Verification...
                  </>
                ) : (
                  <>
                    <ExternalLink className="h-4 w-4 mr-2" />
                    Try Again
                  </>
                )}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}