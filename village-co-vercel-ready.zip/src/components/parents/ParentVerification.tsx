import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Shield, CheckCircle, XCircle, Clock, AlertTriangle } from 'lucide-react';

interface VerificationStatus {
  status: 'not_started' | 'pending' | 'approved' | 'declined' | 'expired' | 'resubmitted';
  startedAt?: string;
  completedAt?: string;
  failureReason?: string;
  message?: string;
}

export default function ParentVerification() {
  const [verificationStatus, setVerificationStatus] = useState<VerificationStatus | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isStarting, setIsStarting] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    checkVerificationStatus();
  }, []);

  const checkVerificationStatus = async () => {
    try {
      const response = await apiRequest('GET', '/api/veriff/parent-status');
      const data = await response.json();
      setVerificationStatus(data);
    } catch (error) {
      console.error('Failed to check verification status:', error);
      // Set default status if API fails
      setVerificationStatus({ status: 'not_started' });
    } finally {
      setIsLoading(false);
    }
  };

  const startVerification = async () => {
    setIsStarting(true);
    try {
      const response = await apiRequest('POST', '/api/veriff/parent-start-verification');
      const data = await response.json();

      if (data.verification?.url) {
        // Open Veriff in a new window
        const veriffWindow = window.open(data.verification.url, '_blank', 'width=800,height=600');
        
        if (!veriffWindow) {
          toast({
            variant: 'destructive',
            title: 'Popup Blocked',
            description: 'Please allow popups to continue with verification.',
          });
          return;
        }

        // Poll for completion
        const checkCompletion = setInterval(() => {
          if (veriffWindow.closed) {
            clearInterval(checkCompletion);
            // Refresh status after window closes
            setTimeout(() => {
              checkVerificationStatus();
            }, 2000);
          }
        }, 1000);

        toast({
          title: "Verification Started",
          description: "Complete the verification process in the new window.",
        });
      }
    } catch (error) {
      console.error('Failed to start verification:', error);
      toast({
        title: "Verification Failed",
        description: "Unable to start verification. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsStarting(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved':
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'declined':
        return <XCircle className="h-5 w-5 text-red-600" />;
      case 'pending':
        return <Clock className="h-5 w-5 text-yellow-600" />;
      case 'expired':
        return <AlertTriangle className="h-5 w-5 text-orange-600" />;
      default:
        return <Shield className="h-5 w-5 text-gray-400" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
        return <Badge className="bg-green-100 text-green-800">Verified</Badge>;
      case 'declined':
        return <Badge variant="destructive">Declined</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800">Under Review</Badge>;
      case 'expired':
        return <Badge className="bg-orange-100 text-orange-800">Expired</Badge>;
      case 'resubmitted':
        return <Badge className="bg-blue-100 text-blue-800">Resubmitted</Badge>;
      default:
        return <Badge variant="outline">Not Started</Badge>;
    }
  };

  const getStatusMessage = (status: string) => {
    switch (status) {
      case 'approved':
        return 'Your identity has been successfully verified. You can now book sitters with confidence.';
      case 'declined':
        return 'Your verification was declined. Please contact support or try again with different documents.';
      case 'pending':
        return 'Your verification is being reviewed. This usually takes 1-2 business days.';
      case 'expired':
        return 'Your verification session has expired. Please start a new verification process.';
      case 'resubmitted':
        return 'Your verification has been resubmitted and is under review.';
      default:
        return 'Verify your identity to build trust with sitters and access all platform features.';
    }
  };

  if (isLoading) {
    return (
      <Card className="border-village-wine/20">
        <CardContent className="flex items-center justify-center py-8">
          <div className="animate-spin h-6 w-6 border-2 border-village-wine border-t-transparent rounded-full"></div>
        </CardContent>
      </Card>
    );
  }

  const status = verificationStatus?.status || 'not_started';

  return (
    <Card className="border-village-wine/20 shadow-lg">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            {getStatusIcon(status)}
            <div>
              <CardTitle className="text-lg text-village-wine">Identity Verification</CardTitle>
              <CardDescription>Confirm your identity for platform safety</CardDescription>
            </div>
          </div>
          {getStatusBadge(status)}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-gray-600">
          {getStatusMessage(status)}
        </p>

        {verificationStatus?.failureReason && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
            <p className="text-sm text-red-700">
              <strong>Reason:</strong> {verificationStatus.failureReason}
            </p>
          </div>
        )}

        {status === 'approved' && verificationStatus?.completedAt && (
          <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
            <p className="text-sm text-green-700">
              <strong>Verified on:</strong> {new Date(verificationStatus.completedAt).toLocaleDateString()}
            </p>
          </div>
        )}

        {(status === 'not_started' || status === 'declined' || status === 'expired') && (
          <Button 
            onClick={startVerification}
            disabled={isStarting}
            className="w-full bg-village-wine hover:bg-village-wine/90 text-white"
          >
            {isStarting ? (
              <>
                <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full mr-2"></div>
                Starting Verification...
              </>
            ) : (
              <>
                <Shield className="h-4 w-4 mr-2" />
                {status === 'not_started' ? 'Start Verification' : 'Retry Verification'}
              </>
            )}
          </Button>
        )}

        {status === 'pending' && (
          <div className="text-center py-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={checkVerificationStatus}
              className="text-village-wine border-village-wine hover:bg-village-wine/10"
            >
              Refresh Status
            </Button>
          </div>
        )}

        <div className="text-xs text-gray-500 border-t pt-3">
          <p>
            <strong>What you'll need:</strong> A government-issued photo ID and passport
          </p>
          <p className="mt-1">
            Your information is processed securely by Veriff and is never stored on our servers.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}