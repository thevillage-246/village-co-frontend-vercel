import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Gift, Heart, Calendar, Clock, ExternalLink } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface GiftSitterProps {
  sitterId?: string;
  sitterName?: string;
}

export default function GiftSitter({ sitterId, sitterName }: GiftSitterProps) {
  const [recipientEmail, setRecipientEmail] = useState('');
  const [recipientName, setRecipientName] = useState('');
  const [giftMessage, setGiftMessage] = useState('');
  const [giftAmount, setGiftAmount] = useState('');
  const [occasion, setOccasion] = useState('');
  const [customAmount, setCustomAmount] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [cardivoLoaded, setCardivoLoaded] = useState(false);
  const { toast } = useToast();

  // Load Cardivo script
  useEffect(() => {
    const script = document.createElement('script');
    script.src = 'https://js.cardivo.com/v1/cardivo.js';
    script.async = true;
    script.onload = () => setCardivoLoaded(true);
    document.head.appendChild(script);

    return () => {
      const existingScript = document.querySelector('script[src="https://js.cardivo.com/v1/cardivo.js"]');
      if (existingScript) {
        document.head.removeChild(existingScript);
      }
    };
  }, []);

  const occasions = [
    { value: 'birthday', label: 'Birthday' },
    { value: 'new-baby', label: 'New Baby' },
    { value: 'anniversary', label: 'Anniversary' },
    { value: 'mothers-day', label: "Mother's Day" },
    { value: 'just-because', label: 'Just Because' },
    { value: 'thank-you', label: 'Thank You' },
    { value: 'girls-night', label: "Girls' Night Out" }
  ];

  const giftAmounts = [
    { value: '25', label: '$25 NZD - 1 hour of care' },
    { value: '50', label: '$50 NZD - 2 hours of care' },
    { value: '75', label: '$75 NZD - 3 hours of care' },
    { value: '100', label: '$100 NZD - 4 hours of care' },
    { value: 'custom', label: 'Custom amount' }
  ];

  const handleSendGift = async () => {
    if (!recipientEmail || !recipientName || !giftAmount || !occasion) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    if (!cardivoLoaded) {
      toast({
        title: "Gift Cards Loading",
        description: "Please wait for the gift card system to load",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      // Initialize Cardivo gift card
      const amount = giftAmount === 'custom' ? parseFloat(customAmount) : parseFloat(giftAmount);
      
      // Create gift card with Cardivo
      const cardivoConfig = {
        amount: amount,
        currency: 'NZD',
        recipientEmail: recipientEmail,
        recipientName: recipientName,
        senderMessage: giftMessage || `A gift of childcare from The Village Co for ${occasions.find(o => o.value === occasion)?.label.toLowerCase()}!`,
        businessName: 'The Village Co',
        brandColor: '#6B3E4B', // wine color
        logoUrl: window.location.origin + '/attached_assets/IMG_4964_1751883228689.png'
      };

      // @ts-ignore - Cardivo global object
      if (window.Cardivo) {
        // @ts-ignore
        const giftCard = await window.Cardivo.createGiftCard(cardivoConfig);
        
        toast({
          title: "Gift Card Created Successfully!",
          description: `${recipientName} will receive their digital gift card via email.`,
        });
        
        // Reset form
        setRecipientEmail('');
        setRecipientName('');
        setGiftMessage('');
        setGiftAmount('');
        setOccasion('');
      } else {
        throw new Error('Cardivo not loaded');
      }
      
    } catch (error) {
      toast({
        title: "Error Creating Gift Card",
        description: "Please try again later.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="max-w-2xl mx-auto">
      <CardHeader className="text-center">
        <div className="mx-auto w-16 h-16 bg-gradient-to-br from-wine to-rose rounded-full flex items-center justify-center mb-4">
          <Gift className="w-8 h-8 text-white" />
        </div>
        <CardTitle className="text-2xl text-wine">
          Gift the Perfect Break
        </CardTitle>
        <p className="text-muted-foreground">
          Give someone special the gift of time with trusted childcare
          {sitterName && ` from ${sitterName}`}
        </p>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Recipient Information */}
        <div className="space-y-4">
          <h3 className="font-semibold text-lg flex items-center">
            <Heart className="w-5 h-5 mr-2 text-wine" />
            Gift Recipient
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="recipientName">Recipient Name</Label>
              <Input
                id="recipientName"
                value={recipientName}
                onChange={(e) => setRecipientName(e.target.value)}
                placeholder="Sarah Johnson"
              />
            </div>
            <div>
              <Label htmlFor="recipientEmail">Recipient Email</Label>
              <Input
                id="recipientEmail"
                type="email"
                value={recipientEmail}
                onChange={(e) => setRecipientEmail(e.target.value)}
                placeholder="sarah@example.com"
              />
            </div>
          </div>
        </div>

        {/* Gift Details */}
        <div className="space-y-4">
          <h3 className="font-semibold text-lg flex items-center">
            <Calendar className="w-5 h-5 mr-2 text-wine" />
            Gift Details
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="occasion">Occasion</Label>
              <Select value={occasion} onValueChange={setOccasion}>
                <SelectTrigger>
                  <SelectValue placeholder="Select occasion" />
                </SelectTrigger>
                <SelectContent>
                  {occasions.map((occasion) => (
                    <SelectItem key={occasion.value} value={occasion.value}>
                      {occasion.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="giftAmount">Gift Amount</Label>
              <Select value={giftAmount} onValueChange={setGiftAmount}>
                <SelectTrigger>
                  <SelectValue placeholder="Select amount" />
                </SelectTrigger>
                <SelectContent>
                  {giftAmounts.map((amount) => (
                    <SelectItem key={amount.value} value={amount.value}>
                      {amount.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {/* Custom Amount Field */}
          {giftAmount === 'custom' && (
            <div className="mt-4">
              <Label htmlFor="customAmount">Custom Amount (NZD)</Label>
              <Input
                id="customAmount"
                type="number"
                value={customAmount}
                onChange={(e) => setCustomAmount(e.target.value)}
                placeholder="Enter amount"
                min="10"
                step="5"
              />
            </div>
          )}
        </div>

        {/* Personal Message */}
        <div className="space-y-2">
          <Label htmlFor="giftMessage">Personal Message (Optional)</Label>
          <Textarea
            id="giftMessage"
            value={giftMessage}
            onChange={(e) => setGiftMessage(e.target.value)}
            placeholder="Hope this gives you a chance to relax and enjoy some well-deserved me time! 💕"
            rows={3}
          />
        </div>

        {/* Gift Preview */}
        {recipientName && giftAmount && occasion && (
          <Card className="bg-gradient-to-r from-wine/10 to-rose/10 border-wine/20">
            <CardContent className="p-4">
              <h4 className="font-semibold mb-2 text-wine">Gift Preview:</h4>
              <p className="text-sm text-muted-foreground">
                "{recipientName} has received a ${giftAmounts.find(a => a.value === giftAmount)?.label.split(' - ')[0].replace('$', '').replace(' NZD', '')} NZD Village Co gift for {occasions.find(o => o.value === occasion)?.label.toLowerCase()}! 
                {giftMessage && ` "${giftMessage}"`}"
              </p>
            </CardContent>
          </Card>
        )}

        {/* Send Gift Button */}
        <Button 
          onClick={handleSendGift}
          disabled={isLoading || !recipientEmail || !recipientName || !giftAmount || !occasion}
          className="w-full bg-wine hover:bg-wine/90 text-white py-3"
          size="lg"
        >
          {isLoading ? (
            <div className="flex items-center">
              <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
              Sending Gift...
            </div>
          ) : (
            <div className="flex items-center">
              <Gift className="w-5 h-5 mr-2" />
              Send Gift of Care
            </div>
          )}
        </Button>

        {/* Cardivo Integration Info */}
        <Card className="bg-gradient-to-r from-eucalyptus/10 to-linen/20 border-eucalyptus/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-semibold text-eucalyptus mb-1">Powered by Cardivo</h4>
                <p className="text-xs text-muted-foreground">
                  Professional gift card platform for secure digital gifting
                </p>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => window.open('https://cardivo.com/', '_blank')}
                className="border-eucalyptus text-eucalyptus hover:bg-eucalyptus/10"
              >
                <ExternalLink className="w-3 h-3 mr-1" />
                Learn More
              </Button>
            </div>
          </CardContent>
        </Card>

        <p className="text-xs text-muted-foreground text-center">
          The recipient will receive a professional digital gift card via email.
          Gift cards never expire and can be used with any Village Co sitter.
          {!cardivoLoaded && (
            <span className="block mt-1 text-wine">
              Loading secure gift card system...
            </span>
          )}
        </p>
      </CardContent>
    </Card>
  );
}