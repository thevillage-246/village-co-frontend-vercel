import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Clock, Heart, TrendingUp, Gift, Calendar, Star } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';

interface FeedItem {
  id: string;
  type: 'reminder' | 'insight' | 'referral' | 'celebration' | 'suggestion';
  title: string;
  message: string;
  actionText?: string;
  actionUrl?: string;
  priority: 'low' | 'medium' | 'high';
  timestamp: Date;
  icon?: string;
}

interface SmartMumFeedProps {
  userId: string;
}

export default function SmartMumFeed({ userId }: SmartMumFeedProps) {
  const [dismissedItems, setDismissedItems] = useState<string[]>([]);

  // Mock smart feed data - in production this would come from API
  const { data: feedItems = [], isLoading } = useQuery({
    queryKey: ['smart-feed', userId],
    queryFn: async () => {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const items: FeedItem[] = [
        {
          id: '1',
          type: 'reminder',
          title: 'Perfect Timing',
          message: 'Sarah is available this Friday evening. Time for your next well-deserved break?',
          actionText: 'Book Sarah',
          actionUrl: '/book/sarah-id',
          priority: 'high',
          timestamp: new Date(),
          icon: '🌟'
        },
        {
          id: '2',
          type: 'insight',
          title: 'Monthly Recap',
          message: 'You reclaimed 6 hours last month! 💪',
          priority: 'medium',
          timestamp: new Date(Date.now() - 86400000),
          icon: '📊'
        },
        {
          id: '3',
          type: 'referral',
          title: 'Spread the Love',
          message: 'Gift a sitter session to a mum friend. Show her the village cares.',
          actionText: 'Gift Now',
          actionUrl: '/gift-sitter',
          priority: 'medium',
          timestamp: new Date(Date.now() - 172800000),
          icon: '🎁'
        },
        {
          id: '4',
          type: 'celebration',
          title: 'Milestone Reached!',
          message: 'Congratulations! You\'ve completed 10 successful bookings with Village Co.',
          priority: 'low',
          timestamp: new Date(Date.now() - 259200000),
          icon: '🎉'
        },
        {
          id: '5',
          type: 'suggestion',
          title: 'Date Night Idea',
          message: 'That new wine bar downtown? Perfect for your Plan My Night booking this weekend.',
          actionText: 'Plan Night',
          actionUrl: '/find-sitter?vibe=date-night',
          priority: 'low',
          timestamp: new Date(Date.now() - 345600000),
          icon: '🍷'
        }
      ];

      return items.filter(item => !dismissedItems.includes(item.id));
    }
  });

  const getIcon = (type: FeedItem['type'], priority: FeedItem['priority']) => {
    switch (type) {
      case 'reminder':
        return <Clock className={`w-4 h-4 ${priority === 'high' ? 'text-wine' : 'text-taupe'}`} />;
      case 'insight':
        return <TrendingUp className="w-4 h-4 text-eucalyptus" />;
      case 'referral':
        return <Gift className="w-4 h-4 text-rose" />;
      case 'celebration':
        return <Star className="w-4 h-4 text-wine" />;
      case 'suggestion':
        return <Sparkles className="w-4 h-4 text-taupe" />;
      default:
        return <Heart className="w-4 h-4 text-rose" />;
    }
  };

  const getPriorityColor = (priority: FeedItem['priority']) => {
    switch (priority) {
      case 'high':
        return 'border-l-wine bg-wine/5';
      case 'medium':
        return 'border-l-eucalyptus bg-eucalyptus/5';
      case 'low':
        return 'border-l-taupe bg-taupe/5';
      default:
        return 'border-l-rose bg-rose/5';
    }
  };

  const dismissItem = (itemId: string) => {
    setDismissedItems(prev => [...prev, itemId]);
  };

  const formatTimestamp = (timestamp: Date) => {
    const now = new Date();
    const diffInHours = (now.getTime() - timestamp.getTime()) / (1000 * 60 * 60);
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${Math.floor(diffInHours)}h ago`;
    if (diffInHours < 168) return `${Math.floor(diffInHours / 24)}d ago`;
    return `${Math.floor(diffInHours / 168)}w ago`;
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Sparkles className="w-5 h-5 mr-2 text-wine" />
            The Village Edit
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="h-16 bg-linen rounded-lg"></div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Sparkles className="w-5 h-5 mr-2 text-wine" />
          The Village Edit
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Personalised insights and suggestions just for you
        </p>
      </CardHeader>
      <CardContent>
        {feedItems.length === 0 ? (
          <div className="text-center py-8">
            <Sparkles className="w-12 h-12 mx-auto text-taupe mb-4" />
            <p className="text-muted-foreground">
              Your smart feed is all caught up! Check back later for personalised insights.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {feedItems.map((item) => (
              <Card 
                key={item.id} 
                className={`border-l-4 transition-all hover:shadow-sm ${getPriorityColor(item.priority)}`}
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3 flex-1">
                      <div className="flex-shrink-0 mt-1">
                        {getIcon(item.type, item.priority)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <h4 className="font-semibold text-sm">{item.title}</h4>
                          {item.icon && (
                            <span className="text-sm">{item.icon}</span>
                          )}
                          <Badge 
                            variant="secondary" 
                            className="text-xs bg-white/50"
                          >
                            {item.type}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">
                          {item.message}
                        </p>
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-muted-foreground">
                            {formatTimestamp(item.timestamp)}
                          </span>
                          {item.actionText && item.actionUrl && (
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => window.location.href = item.actionUrl!}
                              className="h-7 px-3 text-xs border-wine text-wine hover:bg-wine/10"
                            >
                              {item.actionText}
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => dismissItem(item.id)}
                      className="h-6 w-6 p-0 text-muted-foreground hover:text-wine"
                    >
                      ×
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}