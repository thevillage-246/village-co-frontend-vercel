import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Save } from 'lucide-react';

const parentProfileSchema = z.object({
  bio: z.string().max(500, 'Bio must be less than 500 characters'),
  address: z.string().min(1, 'Address is required'),
  city: z.string().min(1, 'City is required'),
  state: z.string().optional(),
  zipCode: z.string().optional(),
  emergencyContact: z.string().min(1, 'Emergency contact name is required'),
  emergencyPhone: z.string().min(1, 'Emergency contact phone is required'),
  childrenInfo: z.string().max(1000, 'Children info must be less than 1000 characters'),
  defaultSpecialInstructions: z.string().max(500, 'Instructions must be less than 500 characters'),
  schoolDaycare: z.string().optional(),
});

type ParentProfileData = z.infer<typeof parentProfileSchema>;

interface EditParentProfileFormProps {
  profile: any;
  onSuccess: () => void;
}

export default function EditParentProfileForm({ profile, onSuccess }: EditParentProfileFormProps) {
  const { toast } = useToast();
  
  const form = useForm<ParentProfileData>({
    resolver: zodResolver(parentProfileSchema),
    defaultValues: {
      bio: profile?.bio || '',
      address: profile?.address || '',
      city: profile?.city || '',
      state: profile?.state || '',
      zipCode: profile?.zipCode || '',
      emergencyContact: profile?.emergencyContact || '',
      emergencyPhone: profile?.emergencyPhone || '',
      childrenInfo: profile?.childrenInfo || '',
      defaultSpecialInstructions: profile?.defaultSpecialInstructions || '',
      schoolDaycare: profile?.schoolDaycare || '',
    },
  });

  const updateProfileMutation = useMutation({
    mutationFn: (data: ParentProfileData) => 
      apiRequest('PUT', '/api/parent/profile', data),
    onSuccess: () => {
      onSuccess();
      toast({
        title: "Profile Updated",
        description: "Your family profile has been updated successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Update Failed",
        description: error.message || "Failed to update profile. Please try again.",
        variant: "destructive",
      });
    }
  });

  const onSubmit = (data: ParentProfileData) => {
    updateProfileMutation.mutate(data);
  };

  return (
    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="bio" className="text-sm font-medium text-[#6B3E4B]">
          Family Bio
        </Label>
        <Textarea
          id="bio"
          {...form.register('bio')}
          className="rounded-xl border-gray-200 focus:border-[#6B3E4B] min-h-[100px]"
          placeholder="Tell sitters about your family..."
        />
        <p className="text-xs text-gray-500">
          {form.watch('bio')?.length || 0}/500 characters
        </p>
        {form.formState.errors.bio && (
          <p className="text-sm text-red-600">{form.formState.errors.bio.message}</p>
        )}
      </div>

      <div className="space-y-4">
        <h4 className="text-md font-semibold text-[#6B3E4B] font-['Satoshi']">
          Address Information
        </h4>
        
        <div className="space-y-2">
          <Label htmlFor="address" className="text-sm font-medium text-[#6B3E4B]">
            Street Address *
          </Label>
          <Input
            id="address"
            {...form.register('address')}
            className="rounded-xl border-gray-200 focus:border-[#6B3E4B]"
            placeholder="Enter your street address"
          />
          {form.formState.errors.address && (
            <p className="text-sm text-red-600">{form.formState.errors.address.message}</p>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="space-y-2">
            <Label htmlFor="city" className="text-sm font-medium text-[#6B3E4B]">
              City *
            </Label>
            <Input
              id="city"
              {...form.register('city')}
              className="rounded-xl border-gray-200 focus:border-[#6B3E4B]"
              placeholder="City"
            />
            {form.formState.errors.city && (
              <p className="text-sm text-red-600">{form.formState.errors.city.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="state" className="text-sm font-medium text-[#6B3E4B]">
              State/Region
            </Label>
            <Input
              id="state"
              {...form.register('state')}
              className="rounded-xl border-gray-200 focus:border-[#6B3E4B]"
              placeholder="State"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="zipCode" className="text-sm font-medium text-[#6B3E4B]">
              Postcode
            </Label>
            <Input
              id="zipCode"
              {...form.register('zipCode')}
              className="rounded-xl border-gray-200 focus:border-[#6B3E4B]"
              placeholder="Postcode"
            />
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <h4 className="text-md font-semibold text-[#6B3E4B] font-['Satoshi']">
          Emergency Contact
        </h4>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="emergencyContact" className="text-sm font-medium text-[#6B3E4B]">
              Emergency Contact Name *
            </Label>
            <Input
              id="emergencyContact"
              {...form.register('emergencyContact')}
              className="rounded-xl border-gray-200 focus:border-[#6B3E4B]"
              placeholder="Emergency contact name"
            />
            {form.formState.errors.emergencyContact && (
              <p className="text-sm text-red-600">{form.formState.errors.emergencyContact.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="emergencyPhone" className="text-sm font-medium text-[#6B3E4B]">
              Emergency Contact Phone *
            </Label>
            <Input
              id="emergencyPhone"
              {...form.register('emergencyPhone')}
              className="rounded-xl border-gray-200 focus:border-[#6B3E4B]"
              placeholder="Emergency contact phone"
            />
            {form.formState.errors.emergencyPhone && (
              <p className="text-sm text-red-600">{form.formState.errors.emergencyPhone.message}</p>
            )}
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="childrenInfo" className="text-sm font-medium text-[#6B3E4B]">
          Children Information
        </Label>
        <Textarea
          id="childrenInfo"
          {...form.register('childrenInfo')}
          className="rounded-xl border-gray-200 focus:border-[#6B3E4B] min-h-[120px]"
          placeholder="Tell sitters about your children (ages, personalities, interests, any special needs or allergies)..."
        />
        <p className="text-xs text-gray-500">
          {form.watch('childrenInfo')?.length || 0}/1000 characters
        </p>
        {form.formState.errors.childrenInfo && (
          <p className="text-sm text-red-600">{form.formState.errors.childrenInfo.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="defaultSpecialInstructions" className="text-sm font-medium text-[#6B3E4B]">
          Default Special Instructions
        </Label>
        <Textarea
          id="defaultSpecialInstructions"
          {...form.register('defaultSpecialInstructions')}
          className="rounded-xl border-gray-200 focus:border-[#6B3E4B] min-h-[100px]"
          placeholder="Any default instructions for sitters (bedtime routines, house rules, etc.)..."
        />
        <p className="text-xs text-gray-500">
          {form.watch('defaultSpecialInstructions')?.length || 0}/500 characters
        </p>
        {form.formState.errors.defaultSpecialInstructions && (
          <p className="text-sm text-red-600">{form.formState.errors.defaultSpecialInstructions.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="schoolDaycare" className="text-sm font-medium text-[#6B3E4B]">
          School/Daycare
        </Label>
        <Input
          id="schoolDaycare"
          {...form.register('schoolDaycare')}
          className="rounded-xl border-gray-200 focus:border-[#6B3E4B]"
          placeholder="School or daycare name"
        />
      </div>

      <Button
        type="submit"
        disabled={updateProfileMutation.isPending}
        className="w-full bg-[#6B3E4B] hover:bg-[#5A334A] text-white rounded-xl shadow-lg"
      >
        <Save className="h-4 w-4 mr-2" />
        {updateProfileMutation.isPending ? 'Saving...' : 'Save Profile Changes'}
      </Button>
    </form>
  );
}