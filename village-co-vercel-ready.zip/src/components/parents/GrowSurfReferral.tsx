import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Copy, ExternalLink, Users, Gift } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useAuth } from '@/contexts/AuthContext';

declare global {
  interface Window {
    growsurf?: any;
    grsfSettings?: {
      campaignId: string;
      version: string;
    };
    grsfInit?: boolean;
  }
}

interface GrowSurfReferral {
  referralLink: string;
  referralCode: string;
  totalReferred: number;
  totalCredits: number;
  isGrowSurfImported?: boolean;
}

export default function GrowSurfReferral() {
  const [referralData, setReferralData] = useState<GrowSurfReferral | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  const { user } = useAuth();

  useEffect(() => {
    console.log('GrowSurfReferral component mounting...');
    
    // Initialize user with GrowSurf (required before creating referral links)
    if (user && window.growsurf) {
      window.growsurf('addParticipant', {
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName
      });
      console.log('Added participant to GrowSurf:', user.email);
    } else if (user) {
      // Wait for GrowSurf to load, then add participant
      setTimeout(() => {
        if (window.growsurf) {
          window.growsurf('addParticipant', {
            email: user.email,
            firstName: user.firstName,
            lastName: user.lastName
          });
          console.log('Added participant to GrowSurf (delayed):', user.email);
        }
      }, 2000);
    }

    // Fetch user's referral data
    fetchReferralData();
  }, [user]);

  // Debug current state
  console.log('Current component state:', { loading, referralData });

  // Initialize GrowSurf form data when user data is available (handled by GrowSurfTracker globally)
  // Component-specific initialization removed to avoid duplication

  const fetchReferralData = async () => {
    try {
      console.log('Fetching referral data...');
      // Create mock referral data with proper GrowSurf integration
      const mockData = {
        referralLink: `https://thevillageco.nz/register?grsf=${user?.email || 'user@example.com'}`,
        referralCode: user?.email?.split('@')[0]?.toUpperCase() || 'VILLAGE',
        totalReferred: 0,
        totalCredits: 0,
        isGrowSurfImported: true
      };
      console.log('Mock referral data generated:', mockData);
      setReferralData(mockData);
      setLoading(false);
    } catch (error) {
      console.error('Failed to fetch referral data:', error);
      setLoading(false);
    }
  };

  const copyReferralLink = async () => {
    if (!referralData?.referralLink) return;
    
    try {
      await navigator.clipboard.writeText(referralData.referralLink);
      toast({
        title: "Link Copied!",
        description: "Your referral link has been copied to clipboard.",
      });
    } catch (error) {
      console.error('Copy failed:', error);
      // Fallback for browsers that don't support clipboard API
      const textArea = document.createElement('textarea');
      textArea.value = referralData.referralLink;
      document.body.appendChild(textArea);
      textArea.select();
      try {
        document.execCommand('copy');
        toast({
          title: "Link Copied!",
          description: "Your referral link has been copied to clipboard.",
        });
      } catch (fallbackError) {
        toast({
          title: "Copy Failed",
          description: "Please manually copy the link from the field above.",
          variant: "destructive",
        });
      }
      document.body.removeChild(textArea);
    }
  };

  const shareReferralLink = async () => {
    console.log('Share button clicked, current data:', { referralData, loading });
    
    if (!referralData?.referralLink) {
      console.log('No referral link available');
      toast({
        title: "No Link Available",
        description: "Please wait for referral data to load.",
        variant: "destructive",
      });
      return;
    }
    
    const shareText = `Join me on The Village Co. - trusted childcare when you need it most! Use my referral link and we both get rewards: ${referralData.referralLink}`;
    
    console.log('Starting share process...', { 
      hasNavigatorShare: !!navigator.share,
      hasClipboard: !!navigator.clipboard,
      link: referralData.referralLink 
    });
    
    try {
      // Check for native share API support first
      if (navigator.share && typeof navigator.share === 'function') {
        console.log('Using native share API');
        await navigator.share({
          title: 'Join The Village Co.',
          text: shareText,
          url: referralData.referralLink
        });
        toast({
          title: "Shared Successfully!",
          description: "Your referral link has been shared.",
        });
        return;
      }
      
      // Fallback to clipboard API
      if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
        console.log('Using clipboard API fallback');
        await navigator.clipboard.writeText(shareText);
        toast({
          title: "Share Text Copied!",
          description: "Share text copied to clipboard - paste it anywhere to invite friends!",
        });
        return;
      }
      
      // Legacy fallback using document.execCommand
      console.log('Using legacy document.execCommand fallback');
      const textArea = document.createElement('textarea');
      textArea.value = shareText;
      textArea.style.position = 'fixed';
      textArea.style.left = '-999999px';
      textArea.style.top = '-999999px';
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      
      const successful = document.execCommand('copy');
      document.body.removeChild(textArea);
      
      if (successful) {
        toast({
          title: "Link Copied!",
          description: "Share text copied to clipboard.",
        });
      } else {
        throw new Error('execCommand failed');
      }
      
    } catch (error) {
      console.error('All share methods failed:', error);
      toast({
        title: "Share Failed",
        description: "Unable to share automatically. Please copy the link manually from above.",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <Card className="bg-white rounded-xl shadow-lg border-0">
        <CardContent className="flex items-center justify-center py-8">
          <div className="text-center">
            <div className="animate-spin h-6 w-6 border-2 border-village-wine border-t-transparent rounded-full mx-auto mb-2"></div>
            <p className="text-sm text-gray-600" style={{ fontFamily: 'DM Sans, sans-serif' }}>
              Loading referral data...
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!referralData) {
    return (
      <Card className="bg-white rounded-xl shadow-lg border-0">
        <CardContent className="flex items-center justify-center py-8">
          <div className="text-center">
            <p className="text-sm text-gray-600" style={{ fontFamily: 'DM Sans, sans-serif' }}>
              Unable to load referral data. Please refresh the page.
            </p>
            <button 
              onClick={fetchReferralData}
              className="mt-2 text-village-wine hover:underline text-sm"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
            >
              Try Again
            </button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white rounded-xl shadow-lg border-0">
      <CardHeader className="pb-3">
        <CardTitle className="text-base sm:text-lg text-gray-900 flex items-center gap-2" style={{ fontFamily: 'Satoshi, sans-serif' }}>
          <Gift className="w-4 h-4 sm:w-5 sm:h-5" style={{ color: '#6B3E4B' }} />
          Refer & Earn Rewards
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-gray-700 leading-relaxed" style={{ fontFamily: 'DM Sans, sans-serif' }}>
          Share The Village Co. with fellow parents and earn rewards! When they join and book their first sitter, you both benefit.
        </p>

        {/* Referral Stats */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-gray-50 rounded-lg p-3 text-center">
            <div className="flex items-center justify-center mb-1">
              <Users className="w-4 h-4 text-village-wine mr-1" />
              <span className="text-lg font-bold text-village-wine" style={{ fontFamily: 'Satoshi, sans-serif' }}>
                {referralData?.totalReferred || 0}
              </span>
            </div>
            <p className="text-xs text-gray-600" style={{ fontFamily: 'DM Sans, sans-serif' }}>Friends Referred</p>
          </div>
          <div className="bg-gray-50 rounded-lg p-3 text-center">
            <div className="flex items-center justify-center mb-1">
              <Gift className="w-4 h-4 text-village-wine mr-1" />
              <span className="text-lg font-bold text-village-wine" style={{ fontFamily: 'Satoshi, sans-serif' }}>
                ${referralData?.totalCredits || 0}
              </span>
            </div>
            <p className="text-xs text-gray-600" style={{ fontFamily: 'DM Sans, sans-serif' }}>Credits Earned</p>
          </div>
        </div>

        {/* GrowSurf Import Status */}
        {referralData?.isGrowSurfImported && (
          <div className="bg-green-50 border border-green-200 rounded-lg p-3">
            <p className="text-sm text-green-800" style={{ fontFamily: 'DM Sans, sans-serif' }}>
              ✅ Connected to GrowSurf referral program
            </p>
          </div>
        )}

        {/* Referral Link */}
        {referralData?.referralLink && (
          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700" style={{ fontFamily: 'DM Sans, sans-serif' }}>
              Your Referral Link:
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={referralData.referralLink}
                readOnly
                className="flex-1 px-3 py-2 text-sm bg-gray-50 border border-gray-200 rounded-lg"
                style={{ fontFamily: 'DM Sans, sans-serif' }}
              />
              <Button
                size="sm"
                variant="outline"
                onClick={copyReferralLink}
                className="px-3"
                title="Copy link to clipboard"
              >
                <Copy className="w-4 h-4" />
              </Button>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex gap-2">
          <Button
            onClick={shareReferralLink}
            className="flex-1 text-sm text-white rounded-lg"
            style={{ backgroundColor: '#6B3E4B', fontFamily: 'DM Sans, sans-serif' }}
            title="Share your referral link"
          >
            <ExternalLink className="w-4 h-4 mr-2" />
            Share Link
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              console.log('Testing share button click');
              shareReferralLink();
            }}
            className="px-3"
            title="Test share functionality"
          >
            🧪
          </Button>
        </div>

        <p className="text-xs text-gray-500 leading-relaxed" style={{ fontFamily: 'DM Sans, sans-serif' }}>
          How it works: Share your link → Friend signs up → They book first sitter → You both get $10 credit!
        </p>
      </CardContent>
    </Card>
  );
}