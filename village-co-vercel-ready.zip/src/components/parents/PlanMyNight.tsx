import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Calendar, Sparkles, Heart, Mail } from 'lucide-react';

interface PlanMyNightProps {
  onComplete: (formData: any) => void;
}

export default function PlanMyNight({ onComplete }: PlanMyNightProps) {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    preferredDate: '',
    preferredTime: '',
    duration: '3',
    conciergeServices: '',
    specialRequests: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Basic validation
    if (!formData.name || !formData.email || !formData.preferredDate) {
      toast({
        title: "Missing Information",
        description: "Please fill in your name, email, and preferred date.",
        variant: "destructive"
      });
      setIsSubmitting(false);
      return;
    }

    // Create mailto URL with form data
    const subject = encodeURIComponent("Plan My Perfect Night Request");
    const body = encodeURIComponent(`
Hello The Village Co team,

I would like to plan my perfect night out with your concierge services.

Name: ${formData.name}
Email: ${formData.email}
Phone: ${formData.phone}
Preferred Date: ${formData.preferredDate}
Preferred Time: ${formData.preferredTime}
Duration: ${formData.duration} hours

Concierge Services Needed: ${formData.conciergeServices}

Special Requests: ${formData.specialRequests}

Please contact me to discuss the details and pricing.

Best regards,
${formData.name}
    `);

    const mailtoUrl = `mailto:info@thevillageco.nz?subject=${subject}&body=${body}`;
    
    // Open email client
    window.location.href = mailtoUrl;
    
    // Show success message
    toast({
      title: "Email Opened",
      description: "Your email client has opened with your request. Please send the email to complete your submission.",
    });

    // Reset form after short delay
    setTimeout(() => {
      setFormData({
        name: '',
        email: '',
        phone: '',
        preferredDate: '',
        preferredTime: '',
        duration: '3',
        conciergeServices: '',
        specialRequests: ''
      });
      setIsSubmitting(false);
      onComplete({ submitted: true });
    }, 2000);
  };

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-r from-wine/5 to-rose/5 border-wine/20">
        <CardHeader>
          <CardTitle className="flex items-center text-wine">
            <Heart className="w-6 h-6 mr-3" />
            Plan My Perfect Night
          </CardTitle>
          <p className="text-muted-foreground">
            Tell us what you need and we'll coordinate your perfect evening with our concierge team
          </p>
        </CardHeader>
      </Card>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Contact Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Mail className="w-5 h-5 mr-2" />
              Your Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Name *</Label>
                <Input
                  id="name"
                  type="text"
                  value={formData.name}
                  onChange={(e) => handleInputChange('name', e.target.value)}
                  placeholder="Your full name"
                  required
                />
              </div>
              <div>
                <Label htmlFor="email">Email *</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  placeholder="your@email.com"
                  required
                />
              </div>
            </div>
            <div>
              <Label htmlFor="phone">Phone</Label>
              <Input
                id="phone"
                type="tel"
                value={formData.phone}
                onChange={(e) => handleInputChange('phone', e.target.value)}
                placeholder="027 123 4567"
              />
            </div>
          </CardContent>
        </Card>

        {/* Evening Details */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Calendar className="w-5 h-5 mr-2" />
              Evening Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="preferredDate">Preferred Date *</Label>
                <Input
                  id="preferredDate"
                  type="date"
                  value={formData.preferredDate}
                  onChange={(e) => handleInputChange('preferredDate', e.target.value)}
                  min={new Date().toISOString().split('T')[0]}
                  required
                />
              </div>
              <div>
                <Label htmlFor="preferredTime">Preferred Start Time</Label>
                <Select value={formData.preferredTime} onValueChange={(value) => handleInputChange('preferredTime', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select time" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="17:00">5:00 PM</SelectItem>
                    <SelectItem value="17:30">5:30 PM</SelectItem>
                    <SelectItem value="18:00">6:00 PM</SelectItem>
                    <SelectItem value="18:30">6:30 PM</SelectItem>
                    <SelectItem value="19:00">7:00 PM</SelectItem>
                    <SelectItem value="19:30">7:30 PM</SelectItem>
                    <SelectItem value="20:00">8:00 PM</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="duration">Duration</Label>
                <Select value={formData.duration} onValueChange={(value) => handleInputChange('duration', value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="2">2 hours</SelectItem>
                    <SelectItem value="3">3 hours</SelectItem>
                    <SelectItem value="4">4 hours</SelectItem>
                    <SelectItem value="5">5 hours</SelectItem>
                    <SelectItem value="6">6 hours</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Concierge Services */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Sparkles className="w-5 h-5 mr-2" />
              Concierge Services Needed
            </CardTitle>
            <p className="text-sm text-muted-foreground">
              What would you like help with? (restaurant bookings, show tickets, etc.)
            </p>
          </CardHeader>
          <CardContent>
            <Textarea
              placeholder="e.g., Book a table at a nice restaurant, get tickets for a show..."
              value={formData.conciergeServices}
              onChange={(e) => handleInputChange('conciergeServices', e.target.value)}
              rows={3}
            />
          </CardContent>
        </Card>

        {/* Special Requests */}
        <Card>
          <CardHeader>
            <CardTitle>Special Requests</CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              placeholder="Any special requests, dietary restrictions, celebration details, or other preferences..."
              value={formData.specialRequests}
              onChange={(e) => handleInputChange('specialRequests', e.target.value)}
              rows={3}
            />
          </CardContent>
        </Card>

        {/* Submit Button */}
        <Card className="border-wine/20 bg-gradient-to-r from-wine/5 to-rose/5">
          <CardContent className="p-6">
            <div className="text-center mb-4">
              <h3 className="text-lg font-semibold text-wine mb-2">
                Ready to Plan Your Perfect Night?
              </h3>
              <p className="text-sm text-muted-foreground">
                We'll email you back within 2 hours with a personalised plan and pricing
              </p>
            </div>
            
            <Button 
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-wine hover:bg-wine/90 text-white"
              size="lg"
            >
              {isSubmitting ? 'Sending Request...' : 'Send My Request'}
            </Button>
          </CardContent>
        </Card>
      </form>
    </div>
  );
}