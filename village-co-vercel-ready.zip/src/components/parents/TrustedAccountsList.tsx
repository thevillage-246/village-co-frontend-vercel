import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Trash2, Mail, Phone, Eye, Edit } from "lucide-react";
import { format } from "date-fns";

interface TrustedAccount {
  id: string;
  parentId: number;
  invitedEmail?: string;
  invitedPhone?: string;
  role: string;
  accepted: boolean;
  createdAt: string;
}

export default function TrustedAccountsList() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: trustedAccounts, isLoading } = useQuery({
    queryKey: ["/api/trusted-accounts"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/trusted-accounts");
      if (!response.ok) {
        throw new Error("Failed to fetch trusted accounts");
      }
      return response.json();
    },
  });

  const revokeMutation = useMutation({
    mutationFn: async (inviteId: string) => {
      const response = await apiRequest("DELETE", `/api/trusted-accounts/${inviteId}`);
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Failed to revoke access");
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/trusted-accounts"] });
      toast({
        title: "Access revoked",
        description: "Trusted account access has been revoked successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to revoke access",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleRevoke = (invite: TrustedAccount) => {
    if (confirm(`Are you sure you want to revoke access for ${invite.invitedEmail || invite.invitedPhone}?`)) {
      revokeMutation.mutate(invite.id);
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Trusted Partners</CardTitle>
          <CardDescription>Loading...</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  if (!trustedAccounts || trustedAccounts.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Trusted Partners</CardTitle>
          <CardDescription>
            You haven't invited any trusted partners yet. Invite family members to help manage your account.
          </CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card className="border-village-wine/20 shadow-lg">
      <CardHeader className="pb-3">
        <CardTitle className="text-base sm:text-lg text-village-wine">Trusted Partners</CardTitle>
        <CardDescription className="text-xs sm:text-sm">
          Manage access for family members and trusted adults
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {trustedAccounts.map((account: TrustedAccount) => (
          <div
            key={account.id}
            className="flex flex-col sm:flex-row sm:items-center sm:justify-between p-3 border rounded-lg bg-white/50 space-y-2 sm:space-y-0"
          >
            <div className="flex-1 space-y-2 sm:space-y-1">
              <div className="flex items-center space-x-2">
                {account.invitedEmail ? (
                  <Mail className="w-4 h-4 text-muted-foreground" />
                ) : (
                  <Phone className="w-4 h-4 text-muted-foreground" />
                )}
                <span className="font-medium text-sm sm:text-base truncate">
                  {account.invitedEmail || account.invitedPhone}
                </span>
              </div>
              
              <div className="flex flex-wrap items-center gap-2">
                <Badge variant={account.accepted ? "default" : "secondary"} className="text-xs">
                  {account.accepted ? "Accepted" : "Pending"}
                </Badge>
                
                <Badge variant="outline" className="flex items-center space-x-1 text-xs">
                  {account.role === "viewer" ? (
                    <Eye className="w-3 h-3" />
                  ) : (
                    <Edit className="w-3 h-3" />
                  )}
                  <span className="capitalize">{account.role}</span>
                </Badge>
              </div>
              
              <p className="text-xs text-muted-foreground">
                Invited on {format(new Date(account.createdAt), "MMM d, yyyy")}
              </p>
            </div>
            
            <div className="flex justify-end sm:justify-start sm:ml-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleRevoke(account)}
                disabled={revokeMutation.isPending}
                className="text-red-600 hover:text-red-700 hover:bg-red-50 text-xs sm:text-sm w-full sm:w-auto"
              >
                <Trash2 className="w-4 h-4 mr-1 sm:mr-0" />
                <span className="sm:hidden">Remove Access</span>
              </Button>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}