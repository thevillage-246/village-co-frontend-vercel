import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { UserPlus, Copy } from "lucide-react";

interface InvitePartnerProps {
  onInviteSent?: () => void;
}

export default function InvitePartner({ onInviteSent }: InvitePartnerProps) {
  const [open, setOpen] = useState(false);
  const [invitedEmail, setInvitedEmail] = useState("");
  const [invitedPhone, setInvitedPhone] = useState("");
  const [role, setRole] = useState("viewer");
  const [inviteLink, setInviteLink] = useState("");
  const [showSuccess, setShowSuccess] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const inviteMutation = useMutation({
    mutationFn: async (data: { invitedEmail?: string; invitedPhone?: string; role: string }) => {
      const response = await apiRequest("POST", "/api/trusted-accounts/invite", data);
      if (!response.ok) {
        if (response.status === 401) {
          throw new Error("Session expired. Please refresh the page and log in again.");
        }
        const error = await response.json();
        throw new Error(error.message || "Failed to send invitation");
      }
      return response.json();
    },
    onSuccess: (data) => {
      setInviteLink(data.inviteLink);
      setShowSuccess(true);
      queryClient.invalidateQueries({ queryKey: ["/api/trusted-accounts"] });
      onInviteSent?.();
      toast({
        title: "Invitation sent successfully",
        description: `Invitation sent to ${invitedEmail || invitedPhone}`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to send invitation",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!invitedEmail && !invitedPhone) {
      toast({
        title: "Missing information",
        description: "Please provide either email or phone number",
        variant: "destructive",
      });
      return;
    }

    inviteMutation.mutate({
      invitedEmail: invitedEmail || undefined,
      invitedPhone: invitedPhone || undefined,
      role,
    });
  };

  const copyInviteLink = () => {
    navigator.clipboard.writeText(inviteLink);
    toast({
      title: "Link copied",
      description: "Invitation link copied to clipboard",
    });
  };

  const resetForm = () => {
    setInvitedEmail("");
    setInvitedPhone("");
    setRole("viewer");
    setInviteLink("");
    setShowSuccess(false);
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="w-full text-sm border-village-wine/30 hover:bg-village-wine/10">
          <UserPlus className="w-4 h-4 mr-2" />
          Invite Partner
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Invite a Trusted Partner</DialogTitle>
          <DialogDescription>
            Invite your spouse, grandparent, or trusted adult to help manage your Village Co. account.
          </DialogDescription>
        </DialogHeader>
        
        {!showSuccess ? (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email Address</Label>
              <Input
                id="email"
                type="email"
                placeholder="partner@example.com"
                value={invitedEmail}
                onChange={(e) => setInvitedEmail(e.target.value)}
              />
            </div>
            
            <div className="text-center text-sm text-muted-foreground">OR</div>
            
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input
                id="phone"
                type="tel"
                placeholder="+64 21 xxx xxxx"
                value={invitedPhone}
                onChange={(e) => setInvitedPhone(e.target.value)}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="role">Permission Level</Label>
              <Select value={role} onValueChange={setRole}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="viewer">
                    Viewer - Can view bookings and sitter information
                  </SelectItem>
                  <SelectItem value="editor">
                    Editor - Can book sitters and message them
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div className="flex justify-end space-x-2">
              <Button type="button" variant="outline" onClick={() => setOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={inviteMutation.isPending}>
                {inviteMutation.isPending ? "Sending..." : "Send Invitation"}
              </Button>
            </div>
          </form>
        ) : (
          <div className="text-center space-y-4">
            <div className="w-16 h-16 mx-auto bg-green-100 rounded-full flex items-center justify-center">
              <UserPlus className="w-8 h-8 text-green-600" />
            </div>
            
            <div>
              <h3 className="text-xl font-semibold text-green-700 mb-2">
                Perfect! Invitation sent 🎉
              </h3>
              <p className="text-gray-600">
                {invitedEmail || invitedPhone} will receive an invitation to join your Village Co. account.
              </p>
              <p className="text-sm text-gray-500 mt-2">
                They'll be able to help manage bookings and communicate with sitters once they accept.
              </p>
            </div>

            {inviteLink && (
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-sm text-gray-600 mb-3">Share this link directly:</p>
                <div className="space-y-3">
                  {/* Mobile-friendly text area for easy selection */}
                  <textarea
                    readOnly
                    value={inviteLink}
                    className="w-full h-20 text-xs bg-white p-3 rounded border font-mono text-gray-700 resize-none"
                    onClick={(e) => e.currentTarget.select()}
                    onFocus={(e) => e.currentTarget.select()}
                  />
                  
                  {/* Copy button with better mobile styling */}
                  <Button 
                    onClick={copyInviteLink}
                    className="w-full bg-village-wine hover:bg-village-wine/90 text-white"
                  >
                    <Copy className="w-4 h-4 mr-2" />
                    Copy Link to Clipboard
                  </Button>
                  
                  {/* Alternative sharing options for mobile */}
                  <div className="flex gap-2">
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="flex-1"
                      onClick={() => {
                        if (navigator.share) {
                          navigator.share({
                            title: 'Village Co. Invitation',
                            text: 'Join my Village Co. account to help manage childcare bookings',
                            url: inviteLink
                          });
                        } else {
                          // Fallback to SMS
                          window.open(`sms:?body=Join my Village Co. account: ${inviteLink}`);
                        }
                      }}
                    >
                      Share via SMS
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="flex-1"
                      onClick={() => {
                        window.open(`mailto:?subject=Village Co. Invitation&body=Join my Village Co. account to help manage childcare bookings:%0A%0A${inviteLink}`);
                      }}
                    >
                      Share via Email
                    </Button>
                  </div>
                </div>
              </div>
            )}
            
            <div className="flex space-x-2">
              <Button variant="outline" onClick={resetForm} className="flex-1">
                Invite Another
              </Button>
              <Button onClick={() => setOpen(false)} className="flex-1">
                Done
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}