import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Star, ThumbsUp, ThumbsDown, Smile, Frown, Meh } from "lucide-react";

interface BookingFeedbackProps {
  bookingId: number;
  sitterName: string;
  onComplete?: () => void;
}

// Simple emoji component for mood selection
const MoodButton = ({ 
  emoji, 
  label, 
  selected, 
  onClick 
}: { 
  emoji: React.ReactNode;
  label: string;
  selected: boolean;
  onClick: () => void;
}) => (
  <Button
    variant={selected ? "default" : "outline"}
    className={`flex flex-col items-center justify-center h-20 w-20 p-2 ${selected ? "bg-rose text-white" : ""}`}
    onClick={onClick}
  >
    <div className="text-2xl mb-1">{emoji}</div>
    <div className="text-xs">{label}</div>
  </Button>
);

// Star rating component
const StarRating = ({ 
  rating, 
  setRating 
}: { 
  rating: number; 
  setRating: (rating: number) => void;
}) => {
  return (
    <div className="flex items-center justify-center gap-2 my-4">
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          type="button"
          onClick={() => setRating(star)}
          className={`text-2xl focus:outline-none transition-all ${
            rating >= star ? "text-yellow-400" : "text-gray-300"
          }`}
        >
          <Star className={`h-8 w-8 ${rating >= star ? "fill-yellow-400" : ""}`} />
        </button>
      ))}
    </div>
  );
};

export default function BookingFeedback({ bookingId, sitterName, onComplete }: BookingFeedbackProps) {
  const [step, setStep] = useState<'mood' | 'rating' | 'feedback' | 'complete'>('mood');
  const [mood, setMood] = useState<'happy' | 'neutral' | 'sad' | null>(null);
  const [rating, setRating] = useState(0);
  const [feedback, setFeedback] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleMoodSelect = (selectedMood: 'happy' | 'neutral' | 'sad') => {
    setMood(selectedMood);
    setStep('rating');
  };

  const handleRatingComplete = () => {
    setStep('feedback');
  };

  const handleSubmitFeedback = async () => {
    if (!mood || rating === 0) {
      toast({
        title: "Missing information",
        description: "Please select a mood and provide a rating.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    try {
      await apiRequest("POST", "/api/reviews", {
        bookingId,
        rating,
        comment: feedback,
        mood
      });

      toast({
        title: "Feedback submitted",
        description: "Thank you for your feedback!",
      });

      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ['/api/bookings'] });
      queryClient.invalidateQueries({ queryKey: ['/api/reviews'] });
      
      setStep('complete');
      
      if (onComplete) {
        onComplete();
      }
    } catch (error) {
      console.error("Error submitting feedback:", error);
      toast({
        title: "Error",
        description: "There was an error submitting your feedback. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto bg-white shadow-md border-0">
      {step === 'mood' && (
        <>
          <CardHeader>
            <CardTitle className="text-xl font-semibold text-center">How was your experience?</CardTitle>
            <CardDescription className="text-center">
              Let us know how your babysitting experience with {sitterName} went
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex justify-center gap-4 my-6">
              <MoodButton 
                emoji={<Smile className="h-8 w-8 text-green-500" />} 
                label="Great" 
                selected={mood === 'happy'}
                onClick={() => handleMoodSelect('happy')}
              />
              <MoodButton 
                emoji={<Meh className="h-8 w-8 text-amber-500" />} 
                label="Okay" 
                selected={mood === 'neutral'}
                onClick={() => handleMoodSelect('neutral')} 
              />
              <MoodButton 
                emoji={<Frown className="h-8 w-8 text-red-500" />} 
                label="Poor" 
                selected={mood === 'sad'}
                onClick={() => handleMoodSelect('sad')} 
              />
            </div>
          </CardContent>
        </>
      )}

      {step === 'rating' && (
        <>
          <CardHeader>
            <CardTitle className="text-xl font-semibold text-center">Rate your experience</CardTitle>
            <CardDescription className="text-center">
              How would you rate {sitterName}?
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center">
            <StarRating rating={rating} setRating={setRating} />
            
            <div className="flex justify-between w-full mt-4 text-xs text-gray-500">
              <span>Poor</span>
              <span>Excellent</span>
            </div>
          </CardContent>
          <CardFooter className="flex justify-end">
            <Button 
              onClick={handleRatingComplete} 
              disabled={rating === 0}
              className="bg-wine hover:bg-wine/90 text-white"
            >
              Continue
            </Button>
          </CardFooter>
        </>
      )}

      {step === 'feedback' && (
        <>
          <CardHeader>
            <CardTitle className="text-xl font-semibold text-center">Additional Feedback</CardTitle>
            <CardDescription className="text-center">
              Would you like to leave a comment about your experience?
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Textarea
              placeholder="Share your thoughts about the babysitting session..."
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              className="min-h-[100px]"
            />
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button 
              variant="outline" 
              onClick={() => setStep('rating')}
            >
              Back
            </Button>
            <Button 
              onClick={handleSubmitFeedback} 
              disabled={isSubmitting}
              className="bg-wine hover:bg-wine/90 text-white"
            >
              {isSubmitting ? "Submitting..." : "Submit Feedback"}
            </Button>
          </CardFooter>
        </>
      )}

      {step === 'complete' && (
        <>
          <CardHeader>
            <CardTitle className="text-xl font-semibold text-center">Thank You!</CardTitle>
            <CardDescription className="text-center">
              Your feedback has been submitted successfully.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center py-6">
            <div className="bg-green-100 rounded-full p-4">
              <ThumbsUp className="h-12 w-12 text-green-500" />
            </div>
          </CardContent>
          <CardFooter className="flex justify-center">
            <p className="text-center text-sm text-gray-500">
              We really appreciate your feedback. It helps us improve our service!
            </p>
          </CardFooter>
        </>
      )}
    </Card>
  );
}