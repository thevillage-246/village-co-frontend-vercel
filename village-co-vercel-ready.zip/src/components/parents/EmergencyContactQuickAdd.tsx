import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';

// Form validation schema for emergency contacts
const emergencyContactFormSchema = z.object({
  name: z.string().min(2, { message: 'Name must be at least 2 characters' }),
  relationship: z.string().min(2, { message: 'Relationship must be specified' }),
  phone: z.string().min(8, { message: 'Please enter a valid phone number' }),
  email: z.string().email({ message: 'Please enter a valid email address' }).optional().or(z.literal('')),
  notes: z.string().optional(),
});

type EmergencyContactForm = z.infer<typeof emergencyContactFormSchema>;

interface EmergencyContactQuickAddProps {
  parentId: number;
  onSuccess?: () => void;
}

export default function EmergencyContactQuickAdd({ parentId, onSuccess }: EmergencyContactQuickAddProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const form = useForm<EmergencyContactForm>({
    resolver: zodResolver(emergencyContactFormSchema),
    defaultValues: {
      name: '',
      relationship: '',
      phone: '',
      email: '',
      notes: '',
    },
  });
  
  const addContactMutation = useMutation({
    mutationFn: async (data: EmergencyContactForm) => {
      const response = await apiRequest('POST', `/api/parents/${parentId}/emergency-contacts`, data);
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to add emergency contact');
      }
      
      return response.json();
    },
    onSuccess: () => {
      // Invalidate cached emergency contacts data to trigger a refetch
      queryClient.invalidateQueries({ queryKey: ['emergency-contacts', parentId] });
      
      toast({
        title: 'Emergency contact added',
        description: 'The emergency contact has been added successfully.',
      });
      
      // Reset the form
      form.reset();
      
      // Call the onSuccess callback if provided
      if (onSuccess) {
        onSuccess();
      }
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to add emergency contact',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  const onSubmit = async (data: EmergencyContactForm) => {
    setIsSubmitting(true);
    try {
      await addContactMutation.mutateAsync(data);
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <Card className="bg-linen/30 border-rose/20">
      <CardHeader className="pb-2">
        <CardTitle className="text-xl font-medium text-wine">Add Emergency Contact</CardTitle>
      </CardHeader>
      
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Name*</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Full name" 
                      {...field}
                      className="border-taupe/50 focus:border-eucalyptus" 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="relationship"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Relationship*</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="E.g. Grandparent, Neighbor, Friend" 
                      {...field}
                      className="border-taupe/50 focus:border-eucalyptus" 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="phone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Phone Number*</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Phone number" 
                      {...field}
                      className="border-taupe/50 focus:border-eucalyptus" 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email (Optional)</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Email address" 
                      {...field}
                      className="border-taupe/50 focus:border-eucalyptus" 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes (Optional)</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Any additional information" 
                      {...field}
                      className="border-taupe/50 focus:border-eucalyptus" 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Button 
              type="submit" 
              className="w-full bg-wine hover:bg-wine/90 mt-2"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                'Add Contact'
              )}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}