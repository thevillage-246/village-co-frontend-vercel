import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { SmartCard, RepeatBookingCard, FrequencyCard, TimePatternCard, DayPreferenceCard } from '@/components/ui/smart-card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { 
  Calendar, 
  Clock, 
  TrendingUp, 
  Heart,
  User,
  MapPin,
  Sparkles
} from 'lucide-react';
import { useLocation } from 'wouter';

interface CalendarInsight {
  type: 'repeat_booking' | 'time_pattern' | 'frequency_suggestion' | 'day_preference' | 'perfect_timing' | 'streak_saver' | 'parent_win' | 'referral_reminder' | 'trusted_user_tip' | 'availability_alert';
  message: string;
  actionText: string;
  data: any;
  priority: 'high' | 'medium' | 'low';
}

interface VillageEditCard {
  id: string;
  type: string;
  title: string;
  message: string;
  priority: 'high' | 'medium' | 'low';
  actionUrl?: string;
  data?: any;
}

export default function VillageEditIntelligent() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();

  // Fetch calendar insights for intelligent suggestions
  const { data: calendarInsights = [], isLoading: calendarLoading } = useQuery<CalendarInsight[]>({
    queryKey: ['/api/calendar-insights', user?.id],
    enabled: !!user?.id,
  });

  // Fetch general Village Edit cards
  const { data: villageEditCards = [], isLoading: villageLoading } = useQuery<VillageEditCard[]>({
    queryKey: ['/api/village-edit', user?.id],
    enabled: !!user?.id,
  });

  // Fetch AI suggestions for enhanced personalization
  const { data: aiSuggestionsData, isLoading: aiLoading } = useQuery({
    queryKey: ['/api/ai/suggestions'],
    enabled: !!user?.id,
    refetchInterval: 5 * 60 * 1000, // Refresh every 5 minutes
  });

  const aiSuggestions = aiSuggestionsData?.suggestions || [];
  const isLoading = calendarLoading || villageLoading || aiLoading;

  const handleCardAction = (insight: CalendarInsight | VillageEditCard) => {
    if ('actionUrl' in insight && insight.actionUrl) {
      setLocation(insight.actionUrl);
    } else if (insight.data?.sitterId) {
      setLocation(`/book?sitterId=${insight.data.sitterId}`);
    } else if (insight.type === 'referral_reminder') {
      setLocation('/parent-dashboard');
    } else {
      setLocation('/find-sitter');
    }
  };

  const renderCalendarInsight = (insight: CalendarInsight, index: number) => {
    const key = `calendar-${insight.type}-${index}`;

    // Specialized card components for better UX
    if (insight.type === 'repeat_booking' && insight.data?.sitterName && insight.data?.daysAgo) {
      return (
        <RepeatBookingCard
          key={key}
          sitterName={insight.data.sitterName}
          daysAgo={insight.data.daysAgo}
          onBook={() => handleCardAction(insight)}
          className="mb-4"
        />
      );
    }

    if (insight.type === 'frequency_suggestion' && insight.data?.sitterName && insight.data?.averageDays && insight.data?.overdueDays) {
      return (
        <FrequencyCard
          key={key}
          sitterName={insight.data.sitterName}
          averageDays={insight.data.averageDays}
          overdueDays={insight.data.overdueDays}
          onSchedule={() => handleCardAction(insight)}
          className="mb-4"
        />
      );
    }

    if (insight.type === 'time_pattern' && insight.data?.sitterName && insight.data?.timeSlot) {
      return (
        <TimePatternCard
          key={key}
          sitterName={insight.data.sitterName}
          timeSlot={insight.data.timeSlot}
          onBook={() => handleCardAction(insight)}
          className="mb-4"
        />
      );
    }

    if (insight.type === 'day_preference' && insight.data?.sitterName && insight.data?.dayName) {
      return (
        <DayPreferenceCard
          key={key}
          sitterName={insight.data.sitterName}
          dayName={insight.data.dayName}
          onBook={() => handleCardAction(insight)}
          className="mb-4"
        />
      );
    }

    // Default SmartCard for other insight types
    return (
      <SmartCard
        key={key}
        type={insight.type}
        title={insight.type.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}
        message={insight.message}
        actionText={insight.actionText}
        priority={insight.priority}
        data={insight.data}
        onAction={() => handleCardAction(insight)}
        className="mb-4"
      />
    );
  };

  const renderVillageEditCard = (card: VillageEditCard, index: number) => {
    return (
      <SmartCard
        key={`village-${card.id}-${index}`}
        type={card.type as any}
        title={card.title}
        message={card.message}
        actionText="Take Action"
        priority={card.priority}
        data={card.data}
        onAction={() => handleCardAction(card)}
        className="mb-4"
      />
    );
  };

  const renderAiSuggestion = (suggestion: any, index: number) => {
    return (
      <SmartCard
        key={`ai-${suggestion.id}-${index}`}
        type={suggestion.suggestionType}
        title={suggestion.suggestionType.replace('_', ' ').replace(/\b\w/g, (l: string) => l.toUpperCase())}
        message={suggestion.messageContent}
        actionText={getActionText(suggestion.callToAction)}
        priority={suggestion.priority}
        data={suggestion.metadata}
        onAction={() => handleAiSuggestionAction(suggestion)}
        className="mb-4 border-l-4 border-l-wine"
      />
    );
  };

  const getActionText = (callToAction: string) => {
    switch (callToAction) {
      case 'book_break': return 'Book My Break';
      case 'plan_night': return 'Plan Date Night';
      case 'message_concierge': return 'Chat with Us';
      default: return 'Explore';
    }
  };

  const handleAiSuggestionAction = async (suggestion: any) => {
    // Mark suggestion as actioned
    try {
      await fetch(`/api/ai/suggestions/${suggestion.id}/action`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: suggestion.callToAction }),
      });
    } catch (error) {
      console.error('Failed to record AI suggestion action:', error);
    }

    // Navigate based on action
    switch (suggestion.callToAction) {
      case 'book_break':
        setLocation('/find-sitter');
        break;
      case 'plan_night':
        setLocation('/find-sitter?time=evening');
        break;
      case 'message_concierge':
        setLocation('/messages');
        break;
      default:
        setLocation('/find-sitter');
        break;
    }
  };

  if (isLoading) {
    return (
      <Card className="border-village-wine/20">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-village-wine">
            <Sparkles className="w-5 h-5" />
            <span>The Village Edit</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="space-y-3">
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-8 w-full" />
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }

  // Filter active AI suggestions
  const activeAiSuggestions = aiSuggestions.filter(s => s.isActive);
  
  const totalCards = (calendarInsights?.length || 0) + (villageEditCards?.length || 0) + (activeAiSuggestions?.length || 0);

  if (totalCards === 0) {
    return (
      <Card className="border-village-wine/20">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-village-wine">
            <Sparkles className="w-5 h-5" />
            <span>The Village Edit</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center py-8">
          <Calendar className="w-12 h-12 mx-auto mb-4 text-village-wine/60" />
          <p className="text-village-wine/70 mb-4">
            Your personalised suggestions will appear here as you use The Village Co.
          </p>
          <p className="text-sm text-village-wine/50">
            Book your first sitter to unlock intelligent recommendations!
          </p>
        </CardContent>
      </Card>
    );
  }

  // Combine and sort cards by priority (AI suggestions get priority boost)
  const allCards = [
    ...calendarInsights.map((insight: CalendarInsight, index: number) => ({ ...insight, index, source: 'calendar' as const })),
    ...villageEditCards.map((card: VillageEditCard, index: number) => ({ ...card, index, source: 'village' as const })),
    ...activeAiSuggestions.map((suggestion: any, index: number) => ({ ...suggestion, index, source: 'ai' as const }))
  ].sort((a, b) => {
    const priorityOrder: Record<string, number> = { 
      urgent: 4, // AI urgent suggestions get highest priority
      high: 3, 
      medium: 2, 
      low: 1 
    };
    // AI suggestions get slight priority boost
    const aPriority = priorityOrder[a.priority] + (a.source === 'ai' ? 0.5 : 0);
    const bPriority = priorityOrder[b.priority] + (b.source === 'ai' ? 0.5 : 0);
    return bPriority - aPriority;
  });

  const highPriorityCount = allCards.filter(card => card.priority === 'high').length;
  const mediumPriorityCount = allCards.filter(card => card.priority === 'medium').length;

  return (
    <Card className="border-village-wine/20">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2 text-village-wine">
            <Sparkles className="w-5 h-5" />
            <span>The Village Edit</span>
          </CardTitle>
          <div className="flex space-x-2">
            {highPriorityCount > 0 && (
              <Badge variant="destructive" className="bg-village-wine">
                {highPriorityCount} urgent
              </Badge>
            )}
            {mediumPriorityCount > 0 && (
              <Badge variant="secondary" className="bg-brushed-pink/20 text-brushed-pink">
                {mediumPriorityCount} soon
              </Badge>
            )}
          </div>
        </div>
        <p className="text-sm text-village-wine/70">
          Personalised suggestions based on your booking patterns and preferences
        </p>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {allCards.map((card) => {
            if (card.source === 'calendar') {
              return renderCalendarInsight(card as CalendarInsight, card.index);
            } else if (card.source === 'ai') {
              return renderAiSuggestion(card, card.index);
            } else {
              return renderVillageEditCard(card as VillageEditCard, card.index);
            }
          })}
        </div>
        
        {totalCards > 3 && (
          <div className="mt-6 text-center">
            <p className="text-xs text-village-wine/50">
              Showing {Math.min(totalCards, 5)} of {totalCards} personalised suggestions
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}