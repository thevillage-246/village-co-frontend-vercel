import { useState } from 'react';
import { supabase } from '../../utils/supabaseClient';

export default function ParentCheckInPrompt({ checkInId }: { checkInId: string }) {
  const [status, setStatus] = useState<'pending' | 'all_good' | 'need_help' | 'submitted'>('pending');

  const handleResponse = async (response: 'all_good' | 'need_help') => {
    setStatus(response);
    const { error } = await supabase
      .from('safety_check_ins')
      .update({ parent_response: response, responded_at: new Date().toISOString(), status: 'responded' })
      .eq('id', checkInId);

    if (!error) setStatus('submitted');
  };

  if (status === 'submitted') {
    return <p className="text-green-600 font-semibold">Thanks — we're here if you need anything 💛</p>;
  }

  return (
    <div className="p-4 bg-[#fff5f5] border border-rose-200 rounded-lg max-w-md mx-auto">
      <p className="mb-3 font-semibold text-wine">Just checking in — is everything going okay?</p>
      <div className="flex space-x-4">
        <button
          onClick={() => handleResponse('all_good')}
          className="bg-eucalyptus text-white px-4 py-2 rounded hover:bg-eucalyptus/90"
        >
          👍 All Good
        </button>
        <button
          onClick={() => handleResponse('need_help')}
          className="bg-wine text-white px-4 py-2 rounded hover:bg-wine/90"
        >
          ❗ Need Help
        </button>
      </div>
    </div>
  );
}