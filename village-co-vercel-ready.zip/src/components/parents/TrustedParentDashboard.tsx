import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Users, Calendar, MessageCircle, Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Household {
  parent_id: number;
  parentName: string;
  childrenCount: number;
  status: string;
}

interface TrustedBooking {
  id: number;
  sitterName: string;
  startTime: string;
  endTime: string;
  status: string;
  specialRequests?: string;
}

interface TrustedMessage {
  id: number;
  fromName: string;
  content: string;
  timestamp: string;
  isRead: boolean;
}

export default function TrustedParentDashboard({ user }: { user: any }) {
  const [currentParent, setCurrentParent] = useState<string>("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get available households for this trusted parent
  const { data: households = [], isLoading: loadingHouseholds } = useQuery({
    queryKey: ["/api/trusted-accounts/households"],
    enabled: user?.role === 'trusted_parent'
  });

  // Set default household when data loads
  useEffect(() => {
    if (households.length > 0 && !currentParent) {
      setCurrentParent(households[0].parent_id.toString());
    }
  }, [households, currentParent]);

  // Get bookings for selected household
  const { data: bookings = [], isLoading: loadingBookings } = useQuery({
    queryKey: ["/api/bookings/household", currentParent],
    enabled: !!currentParent
  });

  // Get messages for current user
  const { data: messages = [], isLoading: loadingMessages } = useQuery({
    queryKey: ["/api/messages", user?.id],
    enabled: !!user?.id
  });

  const currentHousehold = households.find(h => h.parent_id.toString() === currentParent);

  if (user?.role !== 'trusted_parent') {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-linen-50 to-rose-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header with Household Switcher */}
        <div className="bg-white rounded-xl shadow-sm border border-taupe-200 p-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h1 className="text-3xl font-bold text-taupe-900">
                Welcome, you're now a trusted partner
              </h1>
              <p className="text-taupe-600 mt-2">
                You have access to help with childcare booking and management
              </p>
            </div>
            
            {households.length > 1 && (
              <div className="w-full sm:w-auto">
                <label className="block text-sm font-medium text-taupe-700 mb-2">
                  Switch Household
                </label>
                <Select value={currentParent} onValueChange={setCurrentParent}>
                  <SelectTrigger className="w-full sm:w-64">
                    <SelectValue placeholder="Select household..." />
                  </SelectTrigger>
                  <SelectContent>
                    {households.map((household: Household) => (
                      <SelectItem key={household.parent_id} value={household.parent_id.toString()}>
                        <div className="flex items-center gap-2">
                          <Users className="h-4 w-4" />
                          <span>{household.parentName}</span>
                          <Badge variant="secondary" className="ml-2">
                            {household.childrenCount} children
                          </Badge>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>
        </div>

        {currentHousehold && (
          <div className="bg-gradient-to-r from-village-wine-500 to-village-wine-600 rounded-xl text-white p-6">
            <h2 className="text-xl font-semibold mb-2">
              Managing {currentHousehold.parentName}'s Family
            </h2>
            <p className="text-village-wine-100">
              {currentHousehold.childrenCount} children • Access granted for booking and messaging
            </p>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Upcoming Bookings */}
          <Card className="lg:col-span-2">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-village-wine-600" />
                Upcoming Bookings
              </CardTitle>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => window.location.href = '/find-sitter'}
              >
                <Search className="h-4 w-4 mr-2" />
                Find a Sitter
              </Button>
            </CardHeader>
            <CardContent>
              {loadingBookings ? (
                <div className="space-y-3">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="animate-pulse">
                      <div className="h-4 bg-taupe-200 rounded w-3/4 mb-2"></div>
                      <div className="h-3 bg-taupe-100 rounded w-1/2"></div>
                    </div>
                  ))}
                </div>
              ) : bookings.length === 0 ? (
                <div className="text-center py-8">
                  <Calendar className="h-12 w-12 text-taupe-300 mx-auto mb-4" />
                  <p className="text-taupe-500 mb-4">No upcoming bookings</p>
                  <Button 
                    onClick={() => window.location.href = '/find-sitter'}
                    className="bg-village-wine-600 hover:bg-village-wine-700"
                  >
                    Book a Sitter
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {bookings.slice(0, 5).map((booking: TrustedBooking) => (
                    <div key={booking.id} className="border border-taupe-200 rounded-lg p-4">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-semibold text-taupe-900">
                          {booking.sitterName}
                        </h4>
                        <Badge 
                          variant={booking.status === 'confirmed' ? 'default' : 'secondary'}
                          className={booking.status === 'confirmed' ? 'bg-eucalyptus-600' : ''}
                        >
                          {booking.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-taupe-600 mb-2">
                        {new Date(booking.startTime).toLocaleDateString('en-NZ', { 
                          weekday: 'long', 
                          day: 'numeric', 
                          month: 'long' 
                        })} • {new Date(booking.startTime).toLocaleTimeString('en-NZ', { 
                          hour: '2-digit', 
                          minute: '2-digit' 
                        })} - {new Date(booking.endTime).toLocaleTimeString('en-NZ', { 
                          hour: '2-digit', 
                          minute: '2-digit' 
                        })}
                      </p>
                      {booking.specialRequests && (
                        <p className="text-xs text-taupe-500 bg-taupe-50 p-2 rounded">
                          {booking.specialRequests}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Messages */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageCircle className="h-5 w-5 text-village-wine-600" />
                Recent Messages
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loadingMessages ? (
                <div className="space-y-3">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="animate-pulse">
                      <div className="h-3 bg-taupe-200 rounded w-1/2 mb-1"></div>
                      <div className="h-4 bg-taupe-100 rounded w-full mb-2"></div>
                    </div>
                  ))}
                </div>
              ) : messages.length === 0 ? (
                <div className="text-center py-6">
                  <MessageCircle className="h-8 w-8 text-taupe-300 mx-auto mb-2" />
                  <p className="text-sm text-taupe-500">No messages yet</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {messages.slice(0, 5).map((message: TrustedMessage) => (
                    <div key={message.id} className={`p-3 rounded-lg border ${
                      message.isRead ? 'border-taupe-200 bg-white' : 'border-village-wine-200 bg-village-wine-50'
                    }`}>
                      <div className="flex justify-between items-start mb-1">
                        <span className="text-sm font-medium text-taupe-900">
                          {message.fromName}
                        </span>
                        <span className="text-xs text-taupe-500">
                          {new Date(message.timestamp).toLocaleDateString('en-NZ')}
                        </span>
                      </div>
                      <p className="text-sm text-taupe-700 line-clamp-2">
                        {message.content}
                      </p>
                    </div>
                  ))}
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full mt-3"
                    onClick={() => window.location.href = '/messages'}
                  >
                    View All Messages
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Button 
            onClick={() => window.location.href = '/find-sitter'}
            className="bg-village-wine-600 hover:bg-village-wine-700 h-16 text-lg"
          >
            <Search className="h-6 w-6 mr-3" />
            Find a Sitter
          </Button>
          
          <Button 
            variant="outline" 
            onClick={() => window.location.href = '/messages'}
            className="h-16 text-lg border-village-wine-200 hover:bg-village-wine-50"
          >
            <MessageCircle className="h-6 w-6 mr-3" />
            Messages
          </Button>
          
          <Button 
            variant="outline" 
            onClick={() => window.location.href = `/bookings${currentParent ? `?parentId=${currentParent}` : ''}`}
            className="h-16 text-lg border-village-wine-200 hover:bg-village-wine-50"
          >
            <Calendar className="h-6 w-6 mr-3" />
            View All Bookings
          </Button>
        </div>

        {/* Access Limitations Notice */}
        <Card className="border-amber-200 bg-amber-50">
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-amber-100 rounded-full">
                <Users className="h-4 w-4 text-amber-600" />
              </div>
              <div>
                <h4 className="font-medium text-amber-900 mb-1">Trusted Access</h4>
                <p className="text-sm text-amber-700">
                  You have access to booking sitters, viewing schedules, and messaging. 
                  Payment settings and account details remain private to the account owner.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}