import { MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useIntercom } from "@/hooks/use-intercom";

interface IntercomButtonProps {
  variant?: "default" | "outline" | "ghost";
  size?: "sm" | "default" | "lg";
  className?: string;
  children?: React.ReactNode;
}

export default function IntercomButton({ 
  variant = "default", 
  size = "default", 
  className = "",
  children 
}: IntercomButtonProps) {
  const { showMessenger, isReady } = useIntercom();

  const handleClick = () => {
    if (isReady) {
      showMessenger();
    } else {
      // Demo fallback when Intercom isn't configured
      alert('Customer support chat would open here. Intercom integration is ready - just add your API keys!');
    }
  };

  return (
    <Button
      variant={variant}
      size={size}
      className={className}
      onClick={handleClick}
      title={isReady ? "Chat with Support" : "Demo: Intercom Integration Ready"}
    >
      <MessageCircle className="h-4 w-4 mr-2" />
      {children || "Chat with Support"}
    </Button>
  );
}