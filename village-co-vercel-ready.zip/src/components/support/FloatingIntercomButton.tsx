import { MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useEffect } from "react";

export default function FloatingIntercomButton() {
  // Load Intercom script and initialize
  useEffect(() => {
    // Remove any existing Intercom elements first
    const existingFrame = document.getElementById('intercom-frame');
    if (existingFrame) {
      existingFrame.remove();
    }

    // Load Intercom script if not already loaded
    if (typeof window !== 'undefined' && !window.Intercom) {
      const script = document.createElement('script');
      script.type = 'text/javascript';
      script.async = true;
      script.src = 'https://widget.intercom.io/widget/y1niyht1';
      
      const firstScript = document.getElementsByTagName('script')[0];
      if (firstScript && firstScript.parentNode) {
        firstScript.parentNode.insertBefore(script, firstScript);
      }

      // Initialize Intercom when script loads
      script.onload = () => {
        if (window.Intercom) {
          window.Intercom('boot', {
            app_id: 'y1niyht1',
            hide_default_launcher: true, // Hide default launcher, use our custom button
            // Add error handling
            widget: {
              activator: '#custom-intercom-launcher'
            }
          });
          console.log('✅ Intercom initialized successfully');
        } else {
          console.error('❌ Intercom failed to load');
        }
      };
      
      script.onerror = () => {
        console.error('❌ Failed to load Intercom script');
      };
    } else if (window.Intercom) {
      // Intercom already loaded, just initialize
      window.Intercom('boot', {
        app_id: 'y1niyht1',
        hide_default_launcher: true
      });
      console.log('✅ Intercom re-initialized');
    }
  }, []);

  const handleClick = () => {
    if (window.Intercom) {
      window.Intercom('show');
    } else {
      // Fallback to email if Intercom fails to load
      window.location.href = 'mailto:info@thevillageco.nz?subject=Support Request';
    }
  };

  return (
    <Button
      onClick={handleClick}
      className="fixed bottom-6 right-6 z-50 h-14 w-14 rounded-full bg-village-wine hover:bg-village-wine/90 text-white shadow-lg hover:shadow-xl transition-all duration-200 hover:scale-105"
      size="lg"
      title="Chat with Support"
    >
      <MessageCircle className="h-6 w-6" />
      <span className="sr-only">Chat with Support</span>
    </Button>
  );
}