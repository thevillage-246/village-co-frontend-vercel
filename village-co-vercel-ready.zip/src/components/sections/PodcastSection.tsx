import React from 'react';
import { Headphones } from 'lucide-react';

const PodcastSection: React.FC = () => {
  return (
    <section className="bg-village-rose/10 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Headphones className="h-8 w-8 text-village-wine" />
            <h2 className="text-3xl font-bold text-village-wine">
              Hot Messes, Big Visions — The Podcast by The Village Co.
            </h2>
          </div>
          <p className="text-lg text-village-wine/80 max-w-2xl mx-auto mb-8">
            Because parenting was never meant to be done alone.<br />
            Smart mum energy, startup stories, and all the messy bits in between.
          </p>
          
          <div>
            <a 
              href="https://open.spotify.com/show/7yIicKUHL18oQb0jD4s57Y?si=ced76cbbfaec4b81" 
              target="_blank" 
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-village-wine text-white px-6 py-3 rounded-lg hover:bg-village-wine/90 transition-colors font-semibold"
            >
              <Headphones className="h-5 w-5" />
              Listen on Spotify
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PodcastSection;