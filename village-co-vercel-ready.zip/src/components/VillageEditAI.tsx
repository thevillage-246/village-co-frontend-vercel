import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { 
  Calendar, 
  MapPin, 
  Star, 
  Clock, 
  Heart, 
  Sparkles, 
  Loader2,
  User,
  TrendingUp
} from 'lucide-react';

interface VillageEditSuggestion {
  type: 'booking_reminder' | 'activity_suggestion' | 'sitter_recommendation' | 'local_event' | 'parenting_tip';
  title: string;
  description: string;
  actionText: string;
  priority: 'high' | 'medium' | 'low';
}

const getPriorityColor = (priority: string) => {
  switch (priority) {
    case 'high': return 'bg-red-100 text-red-800 border-red-200';
    case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
    case 'low': return 'bg-green-100 text-green-800 border-green-200';
    default: return 'bg-gray-100 text-gray-800 border-gray-200';
  }
};

const getTypeIcon = (type: string) => {
  switch (type) {
    case 'booking_reminder': return <Calendar className="h-5 w-5 text-village-wine" />;
    case 'activity_suggestion': return <Heart className="h-5 w-5 text-rose-500" />;
    case 'sitter_recommendation': return <User className="h-5 w-5 text-eucalyptus" />;
    case 'local_event': return <MapPin className="h-5 w-5 text-taupe" />;
    case 'parenting_tip': return <TrendingUp className="h-5 w-5 text-brushed-pink" />;
    default: return <Sparkles className="h-5 w-5 text-village-wine" />;
  }
};

const getTypeLabel = (type: string) => {
  switch (type) {
    case 'booking_reminder': return 'Booking Reminder';
    case 'activity_suggestion': return 'Activity Idea';
    case 'sitter_recommendation': return 'Sitter Match';
    case 'local_event': return 'Local Event';
    case 'parenting_tip': return 'Parenting Tip';
    default: return 'Suggestion';
  }
};

export default function VillageEditAI() {
  const [suggestions, setSuggestions] = useState<VillageEditSuggestion[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const { toast } = useToast();

  const fetchSuggestions = async () => {
    setIsLoading(true);
    try {
      const response = await apiRequest('POST', '/api/ai/village-edit', {});
      
      if (response.ok) {
        const data = await response.json();
        if (data.success && data.suggestions) {
          setSuggestions(data.suggestions);
          setLastUpdated(new Date());
        } else {
          toast({
            title: "No Suggestions Available",
            description: "We couldn't generate personalised suggestions right now. Please try again later.",
            variant: "default",
          });
        }
      } else {
        throw new Error('Failed to fetch suggestions');
      }
    } catch (error) {
      console.error('Error fetching Village Edit suggestions:', error);
      toast({
        title: "Error Loading Suggestions",
        description: "We couldn't load your personalised feed. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchSuggestions();
  }, []);

  const handleRefresh = () => {
    fetchSuggestions();
  };

  const handleActionClick = (suggestion: VillageEditSuggestion) => {
    // Handle different action types
    switch (suggestion.type) {
      case 'booking_reminder':
        // Navigate to find sitter page
        window.location.href = '/find-sitter';
        break;
      case 'sitter_recommendation':
        // Navigate to specific sitter or find sitter page
        window.location.href = '/find-sitter';
        break;
      case 'activity_suggestion':
        // Could open activity details or external links
        toast({
          title: "Activity Saved",
          description: "Great idea! We've noted your interest in this activity.",
        });
        break;
      case 'local_event':
        // Navigate to events page
        window.location.href = '/plans-events';
        break;
      case 'parenting_tip':
        // Mark as helpful or save tip
        toast({
          title: "Tip Saved",
          description: "We've saved this parenting tip to your favorites.",
        });
        break;
      default:
        break;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <Sparkles className="h-6 w-6 text-village-wine" />
          <div>
            <h2 className="text-2xl font-bold text-village-wine">Village Edit</h2>
            <p className="text-sm text-gray-600">Personalised suggestions just for you</p>
          </div>
        </div>
        <Button
          onClick={handleRefresh}
          disabled={isLoading}
          variant="outline"
          size="sm"
          className="border-village-wine text-village-wine hover:bg-village-wine hover:text-white"
        >
          {isLoading ? (
            <Loader2 className="h-4 w-4 animate-spin mr-2" />
          ) : (
            <Sparkles className="h-4 w-4 mr-2" />
          )}
          Refresh
        </Button>
      </div>

      {/* Last Updated */}
      {lastUpdated && (
        <p className="text-xs text-gray-500 flex items-center">
          <Clock className="h-3 w-3 mr-1" />
          Last updated: {lastUpdated.toLocaleDateString()} at {lastUpdated.toLocaleTimeString()}
        </p>
      )}

      {/* Loading State */}
      {isLoading && suggestions.length === 0 && (
        <Card className="border-2 border-dashed border-gray-200">
          <CardContent className="p-8 text-center">
            <Loader2 className="h-8 w-8 animate-spin text-village-wine mx-auto mb-4" />
            <p className="text-gray-600">Generating personalized suggestions...</p>
          </CardContent>
        </Card>
      )}

      {/* Suggestions Grid */}
      {suggestions.length > 0 && (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {suggestions.map((suggestion, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow duration-200 border-l-4 border-l-village-wine">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    {getTypeIcon(suggestion.type)}
                    <CardTitle className="text-lg font-semibold text-gray-900">
                      {suggestion.title}
                    </CardTitle>
                  </div>
                  <Badge 
                    variant="outline" 
                    className={`text-xs ${getPriorityColor(suggestion.priority)}`}
                  >
                    {getTypeLabel(suggestion.type)}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-gray-600 leading-relaxed">
                  {suggestion.description}
                </p>
                
                <Button
                  onClick={() => handleActionClick(suggestion)}
                  className="w-full bg-village-wine hover:bg-village-wine/90 text-white font-medium"
                  size="sm"
                >
                  {suggestion.actionText}
                </Button>
                
                {/* Priority indicator */}
                <div className="flex justify-end">
                  <div className="flex items-center space-x-1">
                    {Array.from({ length: 3 }).map((_, i) => (
                      <div
                        key={i}
                        className={`w-2 h-2 rounded-full ${
                          i < (suggestion.priority === 'high' ? 3 : suggestion.priority === 'medium' ? 2 : 1)
                            ? 'bg-village-wine'
                            : 'bg-gray-200'
                        }`}
                      />
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Empty State */}
      {!isLoading && suggestions.length === 0 && (
        <Card className="border-2 border-dashed border-gray-200">
          <CardContent className="p-8 text-center">
            <Sparkles className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No Suggestions Yet</h3>
            <p className="text-gray-600 mb-4">
              Complete your profile and book a few sits to get personalized recommendations.
            </p>
            <Button
              onClick={handleRefresh}
              variant="outline"
              className="border-village-wine text-village-wine hover:bg-village-wine hover:text-white"
            >
              Try Again
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}