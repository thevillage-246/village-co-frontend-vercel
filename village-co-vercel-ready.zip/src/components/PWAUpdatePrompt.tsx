import React from 'react';
import { RefreshCw, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { usePWAUpdate } from '@/hooks/usePWAUpdate';

export const PWAUpdatePrompt: React.FC = () => {
  const { updateAvailable, updateApp, skipUpdate } = usePWAUpdate();

  if (!updateAvailable) {
    return null;
  }

  const handleUpdate = async () => {
    await updateApp();
  };

  return (
    <Card className="fixed top-4 left-1/2 transform -translate-x-1/2 z-50 w-96 max-w-[calc(100vw-2rem)] border-village-wine shadow-lg">
      <CardContent className="p-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-village-wine rounded-lg flex items-center justify-center">
              <RefreshCw className="w-4 h-4 text-white" />
            </div>
            <h3 className="font-semibold text-village-wine">Update Available</h3>
          </div>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={skipUpdate}
            className="h-6 w-6 p-0"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>

        <p className="text-sm text-gray-600 mb-4">
          A new version of The Village Co. is available with improvements and bug fixes.
        </p>

        <div className="flex gap-2">
          <Button
            onClick={handleUpdate}
            className="flex-1 bg-village-wine hover:bg-village-wine/90"
            size="sm"
          >
            <RefreshCw className="w-3 h-3 mr-2" />
            Update Now
          </Button>
          <Button 
            variant="outline" 
            onClick={skipUpdate}
            size="sm"
          >
            Later
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default PWAUpdatePrompt;