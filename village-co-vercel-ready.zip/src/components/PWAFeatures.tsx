import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Smartphone, 
  Wifi, 
  Download, 
  Bell, 
  Share2, 
  Camera, 
  MapPin,
  Zap,
  Shield,
  Monitor
} from 'lucide-react';
import { usePWA } from '@/hooks/usePWA';

interface PWAFeaturesProps {
  showTitle?: boolean;
  compact?: boolean;
}

export const PWAFeatures: React.FC<PWAFeaturesProps> = ({ 
  showTitle = true, 
  compact = false 
}) => {
  const { capabilities } = usePWA();

  const features = [
    {
      icon: <Download className="w-5 h-5" />,
      title: 'Installable',
      description: 'Add to your home screen for native app experience',
      available: capabilities.isInstallable || capabilities.isInstalled,
      status: capabilities.isInstalled ? 'Installed' : capabilities.isInstallable ? 'Available' : 'Not Available'
    },
    {
      icon: <Wifi className="w-5 h-5" />,
      title: 'Offline Support',
      description: 'Access key features even without internet',
      available: true,
      status: capabilities.isOnline ? 'Online' : 'Offline'
    },
    {
      icon: <Bell className="w-5 h-5" />,
      title: 'Push Notifications',
      description: 'Get instant updates for bookings and messages',
      available: capabilities.canNotify,
      status: capabilities.canNotify ? 'Supported' : 'Not Supported'
    },
    {
      icon: <Share2 className="w-5 h-5" />,
      title: 'Native Sharing',
      description: 'Share content using your device\'s share menu',
      available: capabilities.canShare,
      status: capabilities.canShare ? 'Supported' : 'Not Supported'
    },
    {
      icon: <Camera className="w-5 h-5" />,
      title: 'Camera Access',
      description: 'Take photos for verification and profiles',
      available: capabilities.hasCamera,
      status: capabilities.hasCamera ? 'Supported' : 'Not Supported'
    },
    {
      icon: <MapPin className="w-5 h-5" />,
      title: 'Location Services',
      description: 'Find nearby sitters and track bookings',
      available: capabilities.hasGeolocation,
      status: capabilities.hasGeolocation ? 'Supported' : 'Not Supported'
    }
  ];

  if (compact) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {features.map((feature, index) => (
          <div key={index} className="flex items-center gap-2 p-2 rounded-lg bg-gray-50">
            <div className={`p-1 rounded ${feature.available ? 'text-green-600' : 'text-gray-400'}`}>
              {feature.icon}
            </div>
            <div>
              <p className="text-sm font-medium">{feature.title}</p>
              <Badge 
                variant={feature.available ? 'default' : 'secondary'}
                className="text-xs"
              >
                {feature.status}
              </Badge>
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {showTitle && (
        <div className="text-center">
          <h2 className="text-2xl font-bold text-village-wine mb-2">
            Progressive Web App Features
          </h2>
          <p className="text-gray-600">
            The Village Co. provides a modern, app-like experience right in your browser
          </p>
        </div>
      )}

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {features.map((feature, index) => (
          <Card key={index} className="relative">
            <CardHeader className="pb-2">
              <div className="flex items-start justify-between">
                <div className={`p-2 rounded-lg ${
                  feature.available 
                    ? 'bg-village-wine/10 text-village-wine' 
                    : 'bg-gray-100 text-gray-400'
                }`}>
                  {feature.icon}
                </div>
                <Badge 
                  variant={feature.available ? 'default' : 'secondary'}
                  className="text-xs"
                >
                  {feature.status}
                </Badge>
              </div>
              <CardTitle className="text-lg">{feature.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">{feature.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="bg-village-linen rounded-lg p-6 text-center">
        <div className="flex items-center justify-center gap-2 mb-4">
          <Zap className="w-6 h-6 text-village-wine" />
          <h3 className="text-xl font-semibold text-village-wine">Why Choose PWA?</h3>
        </div>
        <div className="grid md:grid-cols-3 gap-4 text-sm">
          <div className="flex items-center gap-2">
            <Monitor className="w-4 h-4 text-village-wine" />
            <span>Works on any device</span>
          </div>
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-village-wine" />
            <span>Lightning fast loading</span>
          </div>
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-village-wine" />
            <span>Secure and reliable</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PWAFeatures;