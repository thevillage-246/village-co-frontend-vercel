import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent } from "@/components/ui/card";
import { AlertTriangle, RefreshCw, Wifi, Clock } from "lucide-react";

// Session expiry handler
export function SessionExpiryHandler() {
  const { isAuthenticated, user } = useAuth();
  const [sessionWarning, setSessionWarning] = useState(false);
  
  useEffect(() => {
    let warningTimer: NodeJS.Timeout;
    let logoutTimer: NodeJS.Timeout;
    
    if (isAuthenticated && user) {
      // Show warning 10 minutes before expiry
      warningTimer = setTimeout(() => {
        setSessionWarning(true);
      }, 50 * 60 * 1000); // 50 minutes (assuming 1 hour session)
      
      // Auto logout after 1 hour
      logoutTimer = setTimeout(() => {
        localStorage.removeItem('authToken');
        window.location.href = '/auth?expired=true';
      }, 60 * 60 * 1000);
    }
    
    return () => {
      clearTimeout(warningTimer);
      clearTimeout(logoutTimer);
    };
  }, [isAuthenticated, user]);
  
  if (!sessionWarning) return null;
  
  return (
    <div className="fixed top-4 right-4 z-50 max-w-sm">
      <Card className="border-yellow-200 bg-yellow-50">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Clock className="h-5 w-5 text-yellow-600 mt-0.5" />
            <div>
              <h4 className="font-medium text-yellow-800">Session expiring soon</h4>
              <p className="text-sm text-yellow-700 mt-1">
                Your session will expire in 10 minutes. Save any changes and refresh to stay logged in.
              </p>
              <button 
                onClick={() => window.location.reload()}
                className="mt-2 text-sm font-medium text-yellow-800 hover:text-yellow-900"
              >
                Refresh now
              </button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Network status indicator
export function NetworkStatusIndicator() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [showOfflineMessage, setShowOfflineMessage] = useState(false);
  
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      setShowOfflineMessage(false);
    };
    
    const handleOffline = () => {
      setIsOnline(false);
      setShowOfflineMessage(true);
    };
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);
  
  if (isOnline && !showOfflineMessage) return null;
  
  return (
    <div className="fixed bottom-4 left-4 right-4 z-50 max-w-sm mx-auto">
      <Card className={`border-2 ${isOnline ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'}`}>
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <Wifi className={`h-5 w-5 ${isOnline ? 'text-green-600' : 'text-red-600'}`} />
            <div>
              <h4 className={`font-medium ${isOnline ? 'text-green-800' : 'text-red-800'}`}>
                {isOnline ? 'Back online!' : 'No internet connection'}
              </h4>
              <p className={`text-sm ${isOnline ? 'text-green-700' : 'text-red-700'}`}>
                {isOnline 
                  ? 'Your connection has been restored. All features are available.'
                  : 'Some features may not work properly. Check your connection.'
                }
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Last minute cancellation handler
export function CancellationNoticeHandler({ booking }: { booking?: any }) {
  const [showCancellationNotice, setShowCancellationNotice] = useState(false);
  
  useEffect(() => {
    if (booking?.status === 'cancelled' && booking?.cancelledAt) {
      const cancelTime = new Date(booking.cancelledAt);
      const bookingTime = new Date(booking.startTime);
      const hoursNotice = (bookingTime.getTime() - cancelTime.getTime()) / (1000 * 60 * 60);
      
      if (hoursNotice < 24) {
        setShowCancellationNotice(true);
      }
    }
  }, [booking]);
  
  if (!showCancellationNotice) return null;
  
  return (
    <Card className="border-red-200 bg-red-50 mb-4">
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 text-red-600 mt-0.5" />
          <div>
            <h4 className="font-medium text-red-800">Last-minute cancellation</h4>
            <p className="text-sm text-red-700 mt-1">
              This booking was cancelled with less than 24 hours notice. We understand emergencies happen.
              If you need support finding alternative care, please contact us immediately.
            </p>
            <div className="mt-3 space-x-3">
              <a 
                href="mailto:info@thevillageco.nz?subject=Emergency Care Needed"
                className="text-sm font-medium text-red-800 hover:text-red-900"
              >
                Get emergency support
              </a>
              <a 
                href="/find-sitter"
                className="text-sm font-medium text-red-800 hover:text-red-900"
              >
                Find backup sitter
              </a>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// Payment failure recovery
export function PaymentFailureHandler({ error }: { error?: string }) {
  if (!error || !error.includes('payment')) return null;
  
  return (
    <Card className="border-red-200 bg-red-50 mb-4">
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 text-red-600 mt-0.5" />
          <div>
            <h4 className="font-medium text-red-800">Payment issue detected</h4>
            <p className="text-sm text-red-700 mt-1">
              Don't worry—your booking details are saved. Let's resolve this payment issue 
              so your sitter can be confirmed.
            </p>
            <div className="mt-3 space-x-3">
              <button 
                onClick={() => window.location.reload()}
                className="inline-flex items-center gap-1 text-sm font-medium text-red-800 hover:text-red-900"
              >
                <RefreshCw className="h-4 w-4" />
                Try again
              </button>
              <a 
                href="mailto:info@thevillageco.nz?subject=Payment Support Needed"
                className="text-sm font-medium text-red-800 hover:text-red-900"
              >
                Contact support
              </a>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// Browser back button protection for booking flow
export function BookingFlowProtection() {
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      const isInBookingFlow = window.location.pathname.includes('/book') && 
                             !window.location.pathname.includes('/booking-confirmed');
      
      if (isInBookingFlow) {
        e.preventDefault();
        e.returnValue = 'Are you sure you want to leave? Your booking progress will be lost.';
        return e.returnValue;
      }
    };
    
    const handlePopState = () => {
      const isInBookingFlow = window.location.pathname.includes('/book');
      
      if (isInBookingFlow && window.confirm('Are you sure you want to go back? Your booking progress will be lost.')) {
        return true;
      } else if (isInBookingFlow) {
        window.history.pushState(null, '', window.location.pathname);
        return false;
      }
    };
    
    window.addEventListener('beforeunload', handleBeforeUnload);
    window.addEventListener('popstate', handlePopState);
    
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
      window.removeEventListener('popstate', handlePopState);
    };
  }, []);
  
  return null;
}