import { useState } from 'react';
import { useStripe, useElements, PaymentElement } from '@stripe/react-stripe-js';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { CreditCard, Shield, Loader2 } from 'lucide-react';

interface EmbeddedPaymentSetupProps {
  onSuccess?: () => void;
  onCancel?: () => void;
}

export default function EmbeddedPaymentSetup({ onSuccess, onCancel }: EmbeddedPaymentSetupProps) {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsProcessing(true);

    try {
      const { error } = await stripe.confirmSetup({
        elements,
        confirmParams: {
          return_url: `${window.location.origin}/payment-success`,
        },
      });

      if (error) {
        toast({
          title: "Setup Failed",
          description: error.message,
          variant: "destructive"
        });
      } else {
        toast({
          title: "Payment Method Added",
          description: "Your payment method has been securely saved.",
        });
        onSuccess?.();
      }
    } catch (err) {
      toast({
        title: "Setup Failed",
        description: "Something went wrong. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-village-wine flex items-center gap-2">
          <CreditCard className="w-5 h-5" />
          Add Payment Method
        </CardTitle>
        <p className="text-gray-600 text-sm">
          Securely save your payment details for quick and easy bookings
        </p>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Stripe Payment Element */}
          <div className="p-4 border rounded-lg bg-white">
            <PaymentElement 
              options={{
                layout: "tabs",
                paymentMethodOrder: ['card', 'apple_pay', 'google_pay', 'klarna']
              }}
            />
          </div>

          {/* Security Information */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <Shield className="w-5 h-5 text-blue-600 mt-0.5" />
              <div>
                <h4 className="font-medium text-blue-900">Secure & Protected</h4>
                <p className="text-sm text-blue-700 mt-1">
                  Your payment information is encrypted and securely processed by Stripe. 
                  We never store your card details on our servers.
                </p>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            {onCancel && (
              <Button
                type="button"
                variant="outline"
                onClick={onCancel}
                disabled={isProcessing}
                className="flex-1"
              >
                Cancel
              </Button>
            )}
            <Button
              type="submit"
              className={`${onCancel ? 'flex-1' : 'w-full'} bg-village-wine hover:bg-village-wine/90`}
              disabled={!stripe || isProcessing}
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Saving Payment Method...
                </>
              ) : (
                'Save Payment Method'
              )}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}