import React, { useEffect, useRef, useState } from 'react';
import { Input } from '@/components/ui/input';
import { initializeGoogleMaps } from '@/lib/googleMaps';
import { MapPin } from 'lucide-react';

interface GooglePlacesAutocompleteProps {
  onPlaceSelect: (place: google.maps.places.PlaceResult) => void;
  placeholder?: string;
  value?: string;
  onChange?: (value: string) => void;
  className?: string;
}

export const GooglePlacesAutocomplete: React.FC<GooglePlacesAutocompleteProps> = ({
  onPlaceSelect,
  placeholder = "Search location...",
  value = "",
  onChange,
  className
}) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const autocompleteRef = useRef<google.maps.places.Autocomplete | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const initAutocomplete = async () => {
      try {
        setIsLoading(true);
        await initializeGoogleMaps();
        
        if (inputRef.current && !autocompleteRef.current) {
          // Initialize the autocomplete with New Zealand bias for full addresses
          autocompleteRef.current = new google.maps.places.Autocomplete(inputRef.current, {
            types: ['address'],
            componentRestrictions: { country: 'nz' },
            fields: ['place_id', 'formatted_address', 'geometry', 'name', 'address_components']
          });

          autocompleteRef.current.addListener('place_changed', () => {
            const place = autocompleteRef.current?.getPlace();
            if (place && place.geometry) {
              onPlaceSelect(place);
            }
          });
        }
        setError(null);
      } catch (err) {
        console.error('Failed to initialize Google Places:', err);
        setError('Failed to load location search');
      } finally {
        setIsLoading(false);
      }
    };

    initAutocomplete();

    return () => {
      if (autocompleteRef.current) {
        google.maps.event.clearInstanceListeners(autocompleteRef.current);
      }
    };
  }, [onPlaceSelect]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onChange?.(e.target.value);
  };

  if (error) {
    return (
      <div className="relative">
        <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
        <Input
          placeholder="Location search unavailable"
          disabled
          className={`pl-10 ${className}`}
        />
      </div>
    );
  }

  return (
    <div className="relative">
      <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4 z-10" />
      <Input
        ref={inputRef}
        placeholder={isLoading ? "Loading location search..." : placeholder}
        value={value}
        onChange={handleInputChange}
        disabled={isLoading}
        className={`pl-10 ${className}`}
      />
    </div>
  );
};

export default GooglePlacesAutocomplete;