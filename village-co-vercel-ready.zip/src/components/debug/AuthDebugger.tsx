import { useAuth } from '@/contexts/AuthContext';

export default function AuthDebugger() {
  const { currentUser, isLoading, isAuthenticated } = useAuth();
  
  const checkTokens = () => {
    const authToken = localStorage.getItem('auth_token');
    const authTokenCompat = localStorage.getItem('authToken');
    const userData = localStorage.getItem('user_data');
    
    console.log('=== AUTH DEBUG ===');
    console.log('currentUser:', currentUser);
    console.log('isLoading:', isLoading);
    console.log('isAuthenticated:', isAuthenticated);
    console.log('auth_token in localStorage:', !!authToken);
    console.log('authToken in localStorage:', !!authTokenCompat);
    console.log('user_data in localStorage:', !!userData);
    console.log('Token value (first 50 chars):', authToken?.substring(0, 50));
    
    if (userData) {
      try {
        const parsedUser = JSON.parse(userData);
        console.log('Stored user data:', parsedUser);
      } catch (e) {
        console.log('Error parsing stored user data:', e);
      }
    }
  };

  return (
    <div className="fixed top-4 left-4 bg-black/80 text-white p-4 rounded text-xs z-50 max-w-xs">
      <div className="mb-2">
        <strong>Auth Status:</strong>
        <div>User: {currentUser?.email || 'None'}</div>
        <div>Loading: {isLoading ? 'Yes' : 'No'}</div>
        <div>Authenticated: {isAuthenticated ? 'Yes' : 'No'}</div>
      </div>
      <button 
        onClick={checkTokens}
        className="bg-blue-600 px-2 py-1 rounded text-xs"
      >
        Debug Tokens
      </button>
    </div>
  );
}