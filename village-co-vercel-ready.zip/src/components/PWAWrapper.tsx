import React, { useState, useEffect } from 'react';
import { PWAInstallPrompt } from './PWAInstallPrompt';
import { PWAUpdatePrompt } from './PWAUpdatePrompt';
import { OfflineIndicator } from './OfflineIndicator';
import { usePWA } from '@/hooks/usePWA';

interface PWAWrapperProps {
  children: React.ReactNode;
}

export const PWAWrapper: React.FC<PWAWrapperProps> = ({ children }) => {
  const { capabilities } = usePWA();
  const [showInstallPrompt, setShowInstallPrompt] = useState(false);

  useEffect(() => {
    // Show install prompt after user has been on site for 30 seconds
    // and if they haven't dismissed it in the last 7 days
    const lastDismissed = localStorage.getItem('pwa-install-dismissed');
    const sevenDaysAgo = Date.now() - (7 * 24 * 60 * 60 * 1000);
    
    if (capabilities.isInstallable && (!lastDismissed || parseInt(lastDismissed) < sevenDaysAgo)) {
      const timer = setTimeout(() => {
        setShowInstallPrompt(true);
      }, 30000); // 30 seconds

      return () => clearTimeout(timer);
    }
  }, [capabilities.isInstallable]);

  const handleInstallComplete = () => {
    setShowInstallPrompt(false);
  };

  const handlePromptClose = () => {
    setShowInstallPrompt(false);
  };

  return (
    <>
      {children}
      <OfflineIndicator />
      <PWAUpdatePrompt />
      {showInstallPrompt && (
        <PWAInstallPrompt
          onInstall={handleInstallComplete}
          onClose={handlePromptClose}
        />
      )}
    </>
  );
};

export default PWAWrapper;