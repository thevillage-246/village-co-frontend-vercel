import { useSitterOnboardingGuard } from "@/hooks/useSitterOnboardingGuard";

interface SitterOnboardingGuardProps {
  children: React.ReactNode;
}

export function SitterOnboardingGuard({ children }: SitterOnboardingGuardProps) {
  const { isLoading, shouldRedirect } = useSitterOnboardingGuard();

  // Show loading state while checking onboarding status
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-linen">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-4 border-wine border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-taupe text-sm">Checking your onboarding status...</p>
        </div>
      </div>
    );
  }

  // If redirect is needed, the hook handles it automatically
  // Just render children - the hook will handle redirects
  return <>{children}</>;
}