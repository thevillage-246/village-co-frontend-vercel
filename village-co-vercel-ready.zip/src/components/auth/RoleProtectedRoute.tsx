import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield, ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";

interface RoleProtectedRouteProps {
  allowedRoles: string[];
  children: React.ReactNode;
  fallbackMessage?: string;
}

const RoleProtectedRoute: React.FC<RoleProtectedRouteProps> = ({ 
  allowedRoles, 
  children, 
  fallbackMessage 
}) => {
  const { user } = useAuth();
  const [, navigate] = useLocation();

  if (!user) {
    return (
      <div className="min-h-screen bg-linen flex items-center justify-center">
        <Card className="max-w-md mx-auto">
          <CardContent className="p-8 text-center">
            <Shield className="h-12 w-12 text-village-wine mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">Access Restricted</h2>
            <p className="text-muted-foreground mb-4">
              Please log in to access this page.
            </p>
            <Button onClick={() => navigate('/login')} className="bg-village-wine hover:bg-village-wine/90">
              Log In
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!allowedRoles || !Array.isArray(allowedRoles) || !allowedRoles.includes(user.role)) {
    const getDashboardRoute = () => {
      switch (user.role) {
        case 'parent':
          return '/parent/dashboard';
        case 'sitter':
          return '/sitter/dashboard';
        case 'admin':
          return '/admin/dashboard';
        default:
          return '/dashboard';
      }
    };

    const getRoleDisplayName = (role: string) => {
      switch (role) {
        case 'parent':
          return 'parents';
        case 'sitter':
          return 'sitters';
        case 'admin':
          return 'administrators';
        default:
          return 'authorized users';
      }
    };

    return (
      <div className="min-h-screen bg-linen flex items-center justify-center">
        <Card className="max-w-md mx-auto">
          <CardContent className="p-8 text-center">
            <Shield className="h-12 w-12 text-village-wine mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">Access Restricted</h2>
            <p className="text-muted-foreground mb-4">
              {fallbackMessage || (allowedRoles && allowedRoles.length > 0 
                ? `This page is only available to ${getRoleDisplayName(allowedRoles[0])}.`
                : 'This page is restricted to authorized users.')}
            </p>
            <div className="flex flex-col gap-2">
              <Button 
                onClick={() => navigate(getDashboardRoute())} 
                className="bg-village-wine hover:bg-village-wine/90"
              >
                Go to My Dashboard
              </Button>
              <Button 
                variant="outline" 
                onClick={() => window.history.back()}
                className="flex items-center gap-2"
              >
                <ArrowLeft className="h-4 w-4" />
                Go Back
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return <>{children}</>;
};

export default RoleProtectedRoute;