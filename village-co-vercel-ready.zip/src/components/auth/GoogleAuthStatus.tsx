import { useState, useEffect } from 'react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, AlertCircle, Clock } from 'lucide-react';

export default function GoogleAuthStatus() {
  const [status, setStatus] = useState<'checking' | 'enabled' | 'disabled'>('checking');

  useEffect(() => {
    // Check if Firebase is properly configured and test domain authorization
    const checkFirebaseConfig = async () => {
      const hasApiKey = !!import.meta.env.VITE_FIREBASE_API_KEY;
      const hasProjectId = !!import.meta.env.VITE_FIREBASE_PROJECT_ID;
      const hasAppId = !!import.meta.env.VITE_FIREBASE_APP_ID;
      
      if (hasApiKey && hasProjectId && hasAppId) {
        // Additional check: try to initialize Firebase auth to verify domain authorization
        try {
          const { auth } = await import('@/lib/firebase');
          // If we can access auth without errors, domain is likely authorized
          if (auth) {
            setStatus('enabled');
          } else {
            setStatus('disabled');
          }
        } catch (error) {
          console.error('Firebase auth initialization error:', error);
          setStatus('disabled');
        }
      } else {
        setStatus('disabled');
      }
    };

    checkFirebaseConfig();
  }, []);

  if (status === 'checking') {
    return (
      <Alert className="border-blue-200 bg-blue-50">
        <Clock className="h-4 w-4 text-blue-500" />
        <AlertDescription className="text-blue-700">
          Checking Google authentication status...
        </AlertDescription>
      </Alert>
    );
  }

  if (status === 'disabled') {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          Google authentication is not configured. Please check your Firebase settings.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <Alert className="border-green-200 bg-green-50">
      <CheckCircle className="h-4 w-4 text-green-500" />
      <AlertDescription className="text-green-700 flex items-center justify-between">
        <span>Google authentication is configured and ready!</span>
        <Badge variant="secondary" className="bg-green-100 text-green-800">
          Ready
        </Badge>
      </AlertDescription>
    </Alert>
  );
}