import { Button } from '@/components/ui/button';
import { FcGoogle } from 'react-icons/fc';
import { useGoogleAuth } from '@/hooks/useGoogleAuth';

interface GoogleAuthButtonProps {
  mode?: 'signin' | 'signup';
  redirectTo?: string;
  onSuccess?: () => void;
  onError?: (error: Error) => void;
}

export default function GoogleAuthButton({
  mode = 'signin',
  redirectTo = window.location.origin,
  onSuccess,
  onError
}: GoogleAuthButtonProps) {
  const { handleGoogleSignIn, isLoading } = useGoogleAuth();

  const handleClick = async () => {
    try {
      await handleGoogleSignIn();
      if (onSuccess) {
        onSuccess();
      }
    } catch (error) {
      if (onError && error instanceof Error) {
        onError(error);
      }
    }
  };

  return (
    <Button
      variant="outline"
      onClick={handleClick}
      disabled={isLoading}
      className="w-full"
    >
      {isLoading ? (
        <div className="h-5 w-5 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      ) : (
        <>
          <FcGoogle className="mr-2 h-5 w-5" />
          {mode === 'signin' ? 'Sign in with Google' : 'Sign up with Google'}
        </>
      )}
    </Button>
  );
}