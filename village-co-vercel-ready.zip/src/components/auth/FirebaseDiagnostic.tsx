import { useState, useEffect } from 'react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle, XCircle, AlertTriangle } from 'lucide-react';

interface DiagnosticItem {
  name: string;
  status: 'pass' | 'fail' | 'warning';
  message: string;
}

export default function FirebaseDiagnostic() {
  const [diagnostics, setDiagnostics] = useState<DiagnosticItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const runDiagnostics = async () => {
      const results: DiagnosticItem[] = [];

      // Check environment variables
      const hasApiKey = !!import.meta.env.VITE_FIREBASE_API_KEY;
      const hasProjectId = !!import.meta.env.VITE_FIREBASE_PROJECT_ID;
      const hasAppId = !!import.meta.env.VITE_FIREBASE_APP_ID;

      results.push({
        name: 'Firebase API Key',
        status: hasApiKey ? 'pass' : 'fail',
        message: hasApiKey ? 'API key configured' : 'VITE_FIREBASE_API_KEY missing'
      });

      results.push({
        name: 'Firebase Project ID',
        status: hasProjectId ? 'pass' : 'fail',
        message: hasProjectId ? 'Project ID configured' : 'VITE_FIREBASE_PROJECT_ID missing'
      });

      results.push({
        name: 'Firebase App ID',
        status: hasAppId ? 'pass' : 'fail',
        message: hasAppId ? 'App ID configured' : 'VITE_FIREBASE_APP_ID missing'
      });

      // Test Firebase initialization
      if (hasApiKey && hasProjectId && hasAppId) {
        try {
          const { auth } = await import('@/lib/firebase');
          results.push({
            name: 'Firebase Auth',
            status: auth ? 'pass' : 'fail',
            message: auth ? 'Firebase Auth initialized' : 'Firebase Auth failed to initialize'
          });
        } catch (error: any) {
          results.push({
            name: 'Firebase Auth',
            status: 'fail',
            message: `Firebase initialization error: ${error.message}`
          });
        }
      }

      // Check if we've seen the operation-not-allowed error
      const hasOperationError = window.localStorage.getItem('firebase-operation-error');
      if (hasOperationError) {
        results.push({
          name: 'Google Sign-in Method',
          status: 'fail',
          message: 'Google sign-in method not enabled in Firebase Console'
        });
      }

      setDiagnostics(results);
      setIsLoading(false);
    };

    runDiagnostics();
  }, []);

  const getIcon = (status: string) => {
    switch (status) {
      case 'pass':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'fail':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-amber-500" />;
      default:
        return null;
    }
  };

  if (isLoading) {
    return (
      <Alert className="border-blue-200 bg-blue-50">
        <AlertDescription>Running Firebase diagnostics...</AlertDescription>
      </Alert>
    );
  }

  const failedChecks = diagnostics.filter(d => d.status === 'fail');
  const allPassed = failedChecks.length === 0;

  if (allPassed) {
    return (
      <Alert className="border-green-200 bg-green-50">
        <CheckCircle className="h-4 w-4 text-green-500" />
        <AlertDescription className="text-green-700">
          All Firebase checks passed! Google authentication should be working.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <Card className="border-red-200 bg-red-50">
      <CardHeader className="pb-3">
        <CardTitle className="text-red-800 flex items-center gap-2">
          <XCircle className="h-5 w-5" />
          Firebase Configuration Issues ({failedChecks.length})
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-2">
        {diagnostics.map((diagnostic, index) => (
          <div key={index} className="flex items-center gap-2 text-sm">
            {getIcon(diagnostic.status)}
            <span className={diagnostic.status === 'fail' ? 'text-red-700' : 'text-green-700'}>
              <strong>{diagnostic.name}:</strong> {diagnostic.message}
            </span>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}