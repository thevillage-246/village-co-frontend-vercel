import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Link } from "wouter";
import { Eye, EyeOff, Mail, Lock, LogIn } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

const loginSchema = z.object({
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(1, "Password is required")
});

type LoginFormData = z.infer<typeof loginSchema>;

interface LoginFormProps {
  onSuccess: (user: any, token: string) => void;
}

export default function LoginForm({ onSuccess }: LoginFormProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const form = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: ""
    }
  });

  const onSubmit = async (data: LoginFormData) => {
    setIsLoading(true);
    setError(null);

    // Debug logging to help troubleshoot login issues
    console.log('Login form data:', { email: data.email, passwordLength: data.password.length });

    try {
      const response = await apiRequest('POST', '/api/auth/login', data);
      console.log('Login response status:', response.status);
      console.log('Login response ok:', response.ok);
      
      if (!response.ok) {
        // Handle HTTP error status codes with user-friendly messages
        if (response.status === 401) {
          setError('The email or password you entered is incorrect. Please try again.');
        } else if (response.status === 403) {
          setError('Your account is not verified. Please check your email for a verification link.');
        } else if (response.status >= 500) {
          setError('We\'re having technical difficulties. Please try again in a moment.');
        } else {
          setError('Login failed. Please check your details and try again.');
        }
        return;
      }

      const result = await response.json();

      if (result.success) {
        // Store token in localStorage
        localStorage.setItem('auth_token', result.token);
        
        toast({
          title: "Welcome back!",
          description: "You have been successfully logged in."
        });

        onSuccess(result.user, result.token);
      } else {
        // Handle application-level errors with friendly messages
        const friendlyMessage = result.message?.includes('Invalid') 
          ? 'The email or password you entered is incorrect. Please try again.'
          : result.message?.includes('verify')
          ? 'Please verify your email address before signing in.'
          : 'Login failed. Please check your details and try again.';
        
        setError(friendlyMessage);
      }
    } catch (error: any) {
      console.error('Login error:', error);
      setError('We\'re having trouble connecting. Please check your internet connection and try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleResendVerification = async () => {
    const email = form.getValues('email');
    if (!email) {
      setError('Please enter your email address');
      return;
    }

    try {
      const response = await apiRequest('POST', '/api/auth/resend-verification', { email });
      const result = await response.json();
      
      toast({
        title: "Verification Email Sent",
        description: result.message || "Please check your email for the verification link."
      });
    } catch (error) {
      toast({
        title: "Failed to resend verification",
        description: "Please try again later.",
        variant: "destructive"
      });
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl font-bold text-wine">Welcome Back</CardTitle>
        <CardDescription>
          Sign in to your Village Co. account
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          {error && (
            <Alert variant="destructive">
              <AlertDescription className="text-sm">
                {error}
                {error.includes('verify your email') && (
                  <Button
                    type="button"
                    variant="link"
                    className="ml-2 p-0 h-auto text-sm underline"
                    onClick={handleResendVerification}
                  >
                    Resend verification email
                  </Button>
                )}
              </AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label htmlFor="email">Email Address</Label>
            <div className="relative">
              <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                id="email"
                type="email"
                placeholder="Enter your email"
                className="pl-10"
                {...form.register('email')}
              />
            </div>
            {form.formState.errors.email && (
              <p className="text-sm text-destructive">{form.formState.errors.email.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <div className="relative">
              <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                id="password"
                type={showPassword ? "text" : "password"}
                placeholder="Enter your password"
                className="pl-10 pr-10"
                {...form.register('password')}
              />
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? (
                  <EyeOff className="h-4 w-4 text-muted-foreground" />
                ) : (
                  <Eye className="h-4 w-4 text-muted-foreground" />
                )}
              </Button>
            </div>
            {form.formState.errors.password && (
              <p className="text-sm text-destructive">{form.formState.errors.password.message}</p>
            )}
          </div>

          <div className="flex items-center justify-between">
            <Link href="/forgot-password">
              <Button variant="link" className="p-0 h-auto text-sm text-wine">
                Forgot your password?
              </Button>
            </Link>
          </div>

          <Button
            type="submit"
            className="w-full bg-wine hover:bg-wine/90"
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                Signing in...
              </>
            ) : (
              <>
                <LogIn className="w-4 h-4 mr-2" />
                Sign In
              </>
            )}
          </Button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-sm text-muted-foreground">
            Don't have an account?{" "}
            <Link href="/register">
              <Button variant="link" className="p-0 h-auto text-wine font-medium">
                Sign up now
              </Button>
            </Link>
          </p>
        </div>
      </CardContent>
    </Card>
  );
}