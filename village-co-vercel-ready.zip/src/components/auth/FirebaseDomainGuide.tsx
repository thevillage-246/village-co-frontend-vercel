import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ExternalLink, Copy, CheckCircle, AlertTriangle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function FirebaseDomainGuide() {
  const [showGuide, setShowGuide] = useState(false);
  const [domainAdded, setDomainAdded] = useState(false);
  const { toast } = useToast();
  
  const currentDomain = window.location.hostname;
  
  const copyDomain = () => {
    navigator.clipboard.writeText(currentDomain);
    toast({
      title: "Copied!",
      description: "Domain copied to clipboard",
    });
  };

  if (domainAdded) {
    return (
      <Alert className="border-green-200 bg-green-50">
        <CheckCircle className="h-4 w-4 text-green-500" />
        <AlertDescription className="text-green-700">
          Domain authorized! Google authentication is ready to use.
        </AlertDescription>
      </Alert>
    );
  }

  if (!showGuide) {
    return (
      <Alert className="border-amber-200 bg-amber-50">
        <AlertTriangle className="h-4 w-4 text-amber-500" />
        <AlertDescription className="text-amber-700 flex items-center justify-between">
          <span>Google authentication requires domain authorization</span>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setShowGuide(true)}
            className="text-amber-700 border-amber-300 hover:bg-amber-100"
          >
            Setup Guide
          </Button>
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <Card className="border-amber-200 bg-amber-50">
      <CardHeader className="pb-3">
        <CardTitle className="text-amber-800 flex items-center gap-2">
          <AlertTriangle className="h-5 w-5" />
          Firebase Google Sign-in Setup Required
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert className="border-blue-200 bg-blue-50">
          <AlertDescription className="text-blue-700">
            <strong>Step 1:</strong> Copy your current domain
          </AlertDescription>
        </Alert>
        
        <div className="flex items-center gap-2 p-3 bg-white rounded-lg border">
          <Badge variant="secondary" className="font-mono text-xs">
            {currentDomain}
          </Badge>
          <Button
            variant="outline"
            size="sm"
            onClick={copyDomain}
            className="ml-auto"
          >
            <Copy className="h-4 w-4 mr-1" />
            Copy
          </Button>
        </div>

        <Alert className="border-green-200 bg-green-50">
          <AlertDescription className="text-green-700">
            <strong>Step 2:</strong> Add it to Firebase Console
          </AlertDescription>
        </Alert>

        <ol className="text-sm space-y-2 text-amber-800">
          <li className="flex items-start gap-2">
            <span className="font-bold text-amber-600">1.</span>
            Go to your{' '}
            <a 
              href="https://console.firebase.google.com/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-blue-600 hover:underline inline-flex items-center gap-1"
            >
              Firebase Console
              <ExternalLink className="h-3 w-3" />
            </a>
          </li>
          <li className="flex items-start gap-2">
            <span className="font-bold text-amber-600">2.</span>
            Navigate to <strong>Authentication → Sign-in method</strong>
          </li>
          <li className="flex items-start gap-2">
            <span className="font-bold text-amber-600">3.</span>
            Click <strong>"Google"</strong> and enable it
          </li>
          <li className="flex items-start gap-2">
            <span className="font-bold text-amber-600">4.</span>
            Go to <strong>Authentication → Settings → Authorized domains</strong>
          </li>
          <li className="flex items-start gap-2">
            <span className="font-bold text-amber-600">5.</span>
            Click <strong>"Add domain"</strong> and paste the copied domain
          </li>
          <li className="flex items-start gap-2">
            <span className="font-bold text-amber-600">6.</span>
            Save and refresh this page
          </li>
        </ol>

        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowGuide(false)}
            className="text-amber-700 border-amber-300 hover:bg-amber-100"
          >
            Hide Guide
          </Button>
          <Button
            variant="default"
            size="sm"
            onClick={() => {
              setDomainAdded(true);
              setShowGuide(false);
              toast({
                title: "Great!",
                description: "Domain added successfully. Google authentication should now work.",
              });
            }}
            className="bg-amber-600 hover:bg-amber-700"
          >
            <CheckCircle className="h-4 w-4 mr-1" />
            I've Added the Domain
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}