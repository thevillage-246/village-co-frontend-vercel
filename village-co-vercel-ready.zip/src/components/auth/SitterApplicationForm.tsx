import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { useAuth } from '@/contexts/AuthContext';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';

const experienceOptions = [
  { value: '0-1', label: 'Less than 1 year' },
  { value: '1-3', label: '1-3 years' },
  { value: '3-5', label: '3-5 years' },
  { value: '5+', label: '5+ years' },
];

const sitterApplicationSchema = z.object({
  bio: z.string().min(50, { message: 'Bio must be at least 50 characters' }).max(500, { message: 'Bio must not exceed 500 characters' }),
  experience: z.string(),
  hourlyRate: z.string().refine((val) => !isNaN(Number(val)) && Number(val) > 0, {
    message: 'Please enter a valid hourly rate',
  }),
  age: z.string().refine((val) => !isNaN(Number(val)) && Number(val) >= 18, {
    message: 'You must be at least 18 years old',
  }),
  certifications: z.array(z.string()).optional(),
  hasFirstAid: z.boolean(),
  hasBackground: z.boolean(),
});

type SitterApplicationValues = z.infer<typeof sitterApplicationSchema>;

interface SitterApplicationFormProps {
  userData: {
    firstName: string;
    lastName: string;
    email: string;
    password: string;
    role: string;
  };
}

const SitterApplicationForm: React.FC<SitterApplicationFormProps> = ({ userData }) => {
  const [, navigate] = useLocation();
  const { signUp } = useAuth();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<SitterApplicationValues>({
    resolver: zodResolver(sitterApplicationSchema),
    defaultValues: {
      bio: '',
      experience: '0-1',
      hourlyRate: '',
      age: '',
      certifications: [],
      hasFirstAid: false,
      hasBackground: false,
    },
  });

  const onSubmit = async (data: SitterApplicationValues) => {
    try {
      setIsSubmitting(true);
      
      // First register the user account
      const result = await signUp(userData.email, userData.password, {
        firstName: userData.firstName,
        lastName: userData.lastName,
        role: 'sitter'
      });
      
      if (result.error) {
        throw new Error(result.error.message || 'Registration failed');
      }
      
      // Then submit the sitter profile
      const response = await apiRequest('POST', '/api/sitters/apply', {
        userId: 0, // This will be filled by the backend based on auth
        bio: data.bio,
        experience: data.experience,
        hourlyRate: parseFloat(data.hourlyRate),
        age: parseInt(data.age),
        photoUrl: null, // Will be added later in the profile
        isApproved: false,
      });
      
      toast({
        title: 'Application Submitted',
        description: 'Your sitter application has been submitted for review.',
        variant: 'default',
      });
      
      navigate('/sitter-dashboard');
    } catch (error: any) {
      toast({
        title: 'Application Failed',
        description: error.message || 'Please check your information and try again.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const certificationOptions = [
    { id: 'firstAid', label: 'First Aid Certified' },
    { id: 'cpr', label: 'CPR Certified' },
    { id: 'earlyChildhood', label: 'Early Childhood Education' },
    { id: 'specialNeeds', label: 'Special Needs Care' },
  ];

  return (
    <div className="flex items-center justify-center min-h-[calc(100vh-4rem)] py-12 px-4 sm:px-6 lg:px-8">
      <Card className="w-full max-w-2xl">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold">Sitter Application</CardTitle>
          <CardDescription>Tell us about yourself and your babysitting experience</CardDescription>
        </CardHeader>
        
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="space-y-2">
                <h3 className="text-lg font-medium">Basic Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="age"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Age</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            placeholder="Enter your age" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="hourlyRate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Hourly Rate ($)</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            placeholder="e.g. 25" 
                            {...field} 
                          />
                        </FormControl>
                        <FormDescription>
                          Set your hourly rate in NZD
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <h3 className="text-lg font-medium">Experience & Qualifications</h3>
                <FormField
                  control={form.control}
                  name="experience"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Years of Experience</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select your experience level" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {experienceOptions.map((option) => (
                            <SelectItem key={option.value} value={option.value}>
                              {option.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="hasFirstAid"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>
                            First Aid Certified
                          </FormLabel>
                          <FormDescription>
                            I have a valid First Aid certification
                          </FormDescription>
                        </div>
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="hasBackground"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                        <FormControl>
                          <Checkbox
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                        <div className="space-y-1 leading-none">
                          <FormLabel>
                            Background Check
                          </FormLabel>
                          <FormDescription>
                            I consent to a background check
                          </FormDescription>
                        </div>
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              
              <FormField
                control={form.control}
                name="bio"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>About Me</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Tell us about yourself, your experience with children, and why you enjoy babysitting..."
                        className="resize-none min-h-[150px]"
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      This will be displayed on your profile to potential families
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="flex justify-between pt-2">
                <Button 
                  type="button" 
                  variant="outline"
                  onClick={() => navigate('/auth')}
                >
                  Back
                </Button>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? 'Submitting...' : 'Submit Application'}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
};

export default SitterApplicationForm;
