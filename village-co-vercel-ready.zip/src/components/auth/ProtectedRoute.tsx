import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/contexts/AuthContext';
import { USER_ROLES } from '@shared/schema';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredRoles?: string[];
}

export default function ProtectedRoute({ 
  children, 
  requiredRoles = [] 
}: ProtectedRouteProps) {
  const { currentUser, isLoading } = useAuth();
  const [location, setLocation] = useLocation();

  useEffect(() => {
    // If auth state is loaded and user is not authenticated, redirect to login
    if (!isLoading && !currentUser) {
      // Keep track of where the user was trying to go for redirecting after login
      const redirectPath = encodeURIComponent(location);
      setLocation(`/login?redirect=${redirectPath}`);
    }
    
    // Check if user has the required role
    if (!isLoading && currentUser && requiredRoles.length > 0) {
      const userRole = currentUser.role || '';
      
      if (!requiredRoles.includes(userRole)) {
        // User doesn't have the required role
        if (userRole === USER_ROLES.PARENT) {
          setLocation('/parent/dashboard');
        } else if (userRole === USER_ROLES.SITTER) {
          setLocation('/sitter/dashboard');
        } else if (userRole === USER_ROLES.ADMIN) {
          setLocation('/admin');
        } else {
          setLocation('/');
        }
      }
    }
  }, [currentUser, isLoading, location, setLocation, requiredRoles]);

  // Show loading state while checking authentication
  if (isLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-linen-50">
        <div className="flex flex-col items-center">
          <div className="h-16 w-16 animate-spin rounded-full border-b-2 border-t-2 border-rose-600"></div>
          <p className="mt-4 text-lg font-medium text-wine-700">Loading...</p>
        </div>
      </div>
    );
  }
  
  // If user is authenticated and has required role, render children
  if (currentUser) {
    if (requiredRoles.length === 0) {
      return <>{children}</>;
    }
    
    const userRole = currentUser.role || '';
    if (requiredRoles.includes(userRole)) {
      return <>{children}</>;
    }
  }
  
  // This should not be visible due to redirection in useEffect
  return null;
}