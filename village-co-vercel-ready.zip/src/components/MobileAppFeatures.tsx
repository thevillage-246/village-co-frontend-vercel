import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Camera, 
  MapPin, 
  Share2, 
  Bell, 
  Smartphone,
  Wifi,
  Battery,
  Settings
} from 'lucide-react';
import { useCapacitor } from '@/hooks/useCapacitor';
import { useToast } from '@/hooks/use-toast';

export const MobileAppFeatures: React.FC = () => {
  const { 
    isNative, 
    platform, 
    isReady, 
    deviceInfo, 
    networkStatus,
    appInfo,
    takePicture,
    getCurrentLocation,
    shareContent,
    scheduleNotification
  } = useCapacitor();
  
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState<string | null>(null);

  const handleTakePicture = async () => {
    setIsLoading('camera');
    try {
      const imageData = await takePicture();
      if (imageData) {
        toast({
          title: "Photo Captured",
          description: "Photo taken successfully!"
        });
      } else {
        toast({
          title: "Camera Not Available",
          description: "Camera functionality is only available in the mobile app.",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Camera Error",
        description: "Failed to take photo. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(null);
    }
  };

  const handleGetLocation = async () => {
    setIsLoading('location');
    try {
      const position = await getCurrentLocation();
      if (position) {
        toast({
          title: "Location Found",
          description: `Lat: ${position.lat.toFixed(4)}, Lng: ${position.lng.toFixed(4)}`
        });
      } else {
        toast({
          title: "Location Not Available",
          description: "Unable to get current location. Please check permissions.",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Location Error",
        description: "Failed to get location. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(null);
    }
  };

  const handleShare = async () => {
    setIsLoading('share');
    try {
      const shared = await shareContent(
        'The Village Co.',
        'Check out The Village Co. - New Zealand\'s most modern babysitting platform!',
        'https://www.thevillageco.nz'
      );
      if (shared) {
        toast({
          title: "Content Shared",
          description: "Thank you for sharing The Village Co.!"
        });
      } else {
        toast({
          title: "Share Not Available",
          description: "Sharing is not available on this device.",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Share Error",
        description: "Failed to share content. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(null);
    }
  };

  const handleScheduleNotification = async () => {
    setIsLoading('notification');
    try {
      const scheduled = await scheduleNotification(
        'Village Co Reminder',
        'Don\'t forget to check your bookings!',
        Date.now(),
        new Date(Date.now() + 10000) // 10 seconds from now
      );
      if (scheduled) {
        toast({
          title: "Notification Scheduled",
          description: "You'll receive a test notification in 10 seconds."
        });
      } else {
        toast({
          title: "Notifications Not Available",
          description: "Push notifications are only available in the mobile app.",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Notification Error",
        description: "Failed to schedule notification. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(null);
    }
  };

  if (!isReady) {
    return (
      <Card className="w-full max-w-4xl mx-auto">
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            <div className="animate-spin w-6 h-6 border-2 border-village-wine border-t-transparent rounded-full" />
            <span className="ml-3">Loading mobile features...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Platform Info */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Smartphone className="w-5 h-5" />
            Mobile App Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4">
            <div>
              <p className="text-sm font-medium">Platform</p>
              <Badge variant={isNative ? "default" : "secondary"}>
                {platform} {isNative ? "(Native App)" : "(Web Browser)"}
              </Badge>
            </div>
            {appInfo && (
              <div>
                <p className="text-sm font-medium">App Version</p>
                <p className="text-sm text-gray-600">{appInfo.version}</p>
              </div>
            )}
            {networkStatus && (
              <div>
                <p className="text-sm font-medium">Network Status</p>
                <Badge variant={networkStatus.connected ? "default" : "destructive"}>
                  {networkStatus.connected ? `Connected (${networkStatus.connectionType})` : "Offline"}
                </Badge>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Mobile Features */}
      <Card>
        <CardHeader>
          <CardTitle>Mobile Features</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4">
            <Button
              onClick={handleTakePicture}
              disabled={isLoading === 'camera'}
              className="flex items-center gap-2 h-12"
            >
              <Camera className="w-4 h-4" />
              {isLoading === 'camera' ? 'Taking Photo...' : 'Take Photo'}
            </Button>

            <Button
              onClick={handleGetLocation}
              disabled={isLoading === 'location'}
              variant="outline"
              className="flex items-center gap-2 h-12"
            >
              <MapPin className="w-4 h-4" />
              {isLoading === 'location' ? 'Getting Location...' : 'Get Location'}
            </Button>

            <Button
              onClick={handleShare}
              disabled={isLoading === 'share'}
              variant="outline"
              className="flex items-center gap-2 h-12"
            >
              <Share2 className="w-4 h-4" />
              {isLoading === 'share' ? 'Sharing...' : 'Share App'}
            </Button>

            <Button
              onClick={handleScheduleNotification}
              disabled={isLoading === 'notification'}
              variant="outline"
              className="flex items-center gap-2 h-12"
            >
              <Bell className="w-4 h-4" />
              {isLoading === 'notification' ? 'Scheduling...' : 'Test Notification'}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Device Info */}
      {deviceInfo && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="w-5 h-5" />
              Device Information
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <p className="text-sm font-medium">Model</p>
                <p className="text-sm text-gray-600">{deviceInfo.model}</p>
              </div>
              <div>
                <p className="text-sm font-medium">Platform</p>
                <p className="text-sm text-gray-600">{deviceInfo.platform} {deviceInfo.osVersion}</p>
              </div>
              <div>
                <p className="text-sm font-medium">Device ID</p>
                <p className="text-sm text-gray-600 font-mono text-xs">{deviceInfo.identifier?.substring(0, 16)}...</p>
              </div>
              <div>
                <p className="text-sm font-medium">Manufacturer</p>
                <p className="text-sm text-gray-600">{deviceInfo.manufacturer}</p>
              </div>
              <div>
                <p className="text-sm font-medium">Is Virtual</p>
                <Badge variant={deviceInfo.isVirtual ? "secondary" : "default"}>
                  {deviceInfo.isVirtual ? 'Simulator' : 'Real Device'}
                </Badge>
              </div>
              <div>
                <p className="text-sm font-medium">Memory</p>
                <p className="text-sm text-gray-600">{deviceInfo.memUsed ? `${Math.round(deviceInfo.memUsed / 1024 / 1024)}MB used` : 'N/A'}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default MobileAppFeatures;