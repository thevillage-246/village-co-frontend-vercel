import { useEffect, useRef } from 'react';

interface LocationMapProps {
  latitude: number;
  longitude: number;
  accuracy?: number;
  height?: string;
}

export default function LocationMap({ 
  latitude, 
  longitude, 
  accuracy, 
  height = '300px' 
}: LocationMapProps) {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInitialized = useRef<boolean>(false);

  useEffect(() => {
    if (!mapContainerRef.current || !latitude || !longitude) return;
    
    // Basic map implementation with a marker
    // In a production app, you would use a library like Leaflet or Google Maps
    
    const container = mapContainerRef.current;
    
    if (!mapInitialized.current) {
      // First time setup
      const mapElement = document.createElement('div');
      mapElement.style.width = '100%';
      mapElement.style.height = '100%';
      mapElement.style.position = 'relative';
      mapElement.style.backgroundColor = '#e8f4f8';
      mapElement.style.borderRadius = '8px';
      mapElement.style.overflow = 'hidden';
      
      // Add position text
      const posText = document.createElement('div');
      posText.style.position = 'absolute';
      posText.style.bottom = '10px';
      posText.style.left = '10px';
      posText.style.backgroundColor = 'rgba(255, 255, 255, 0.8)';
      posText.style.padding = '5px 10px';
      posText.style.borderRadius = '4px';
      posText.style.fontSize = '12px';
      posText.style.fontFamily = 'monospace';
      posText.id = 'pos-text';
      
      // Add marker
      const marker = document.createElement('div');
      marker.style.width = '20px';
      marker.style.height = '20px';
      marker.style.borderRadius = '50%';
      marker.style.backgroundColor = '#6B3E4B';
      marker.style.border = '3px solid white';
      marker.style.position = 'absolute';
      marker.style.top = '50%';
      marker.style.left = '50%';
      marker.style.transform = 'translate(-50%, -50%)';
      marker.style.zIndex = '2';
      marker.id = 'location-marker';
      
      // Add accuracy circle if accuracy is provided
      if (accuracy) {
        const accuracyCircle = document.createElement('div');
        accuracyCircle.style.width = '50px';
        accuracyCircle.style.height = '50px';
        accuracyCircle.style.borderRadius = '50%';
        accuracyCircle.style.backgroundColor = 'rgba(107, 62, 75, 0.2)';
        accuracyCircle.style.border = '2px solid rgba(107, 62, 75, 0.5)';
        accuracyCircle.style.position = 'absolute';
        accuracyCircle.style.top = '50%';
        accuracyCircle.style.left = '50%';
        accuracyCircle.style.transform = 'translate(-50%, -50%)';
        accuracyCircle.style.zIndex = '1';
        accuracyCircle.id = 'accuracy-circle';
        
        mapElement.appendChild(accuracyCircle);
      }
      
      mapElement.appendChild(marker);
      mapElement.appendChild(posText);
      
      // Add placeholders for map tiles
      for (let i = 0; i < 9; i++) {
        const tile = document.createElement('div');
        tile.style.position = 'absolute';
        tile.style.width = '33.33%';
        tile.style.height = '33.33%';
        tile.style.border = '1px solid rgba(0,0,0,0.1)';
        tile.style.left = `${(i % 3) * 33.33}%`;
        tile.style.top = `${Math.floor(i / 3) * 33.33}%`;
        
        // Add some grid lines to make it look more like a map
        for (let j = 0; j < 3; j++) {
          const line = document.createElement('div');
          line.style.position = 'absolute';
          line.style.backgroundColor = 'rgba(0,0,0,0.05)';
          
          if (j < 2) {
            // Horizontal lines
            line.style.height = '1px';
            line.style.width = '100%';
            line.style.top = `${(j + 1) * 33.33}%`;
            line.style.left = '0';
          } else {
            // Vertical lines
            line.style.width = '1px';
            line.style.height = '100%';
            line.style.top = '0';
            line.style.left = `${(j - 1) * 33.33}%`;
          }
          
          tile.appendChild(line);
        }
        
        mapElement.appendChild(tile);
      }
      
      // Clear container and add new map
      container.innerHTML = '';
      container.appendChild(mapElement);
      
      mapInitialized.current = true;
    }
    
    // Update position text
    const posText = container.querySelector('#pos-text') as HTMLDivElement;
    if (posText) {
      posText.textContent = `Lat: ${latitude.toFixed(6)}, Lng: ${longitude.toFixed(6)}` + 
        (accuracy ? `, Accuracy: ${Math.round(accuracy)}m` : '');
    }
    
    // Update accuracy circle if accuracy is provided
    const accuracyCircle = container.querySelector('#accuracy-circle') as HTMLDivElement;
    if (accuracyCircle && accuracy) {
      // Scale the circle based on accuracy (1m = 1px)
      // Clamped to reasonable values for display
      const size = Math.min(Math.max(accuracy * 2, 20), 200);
      accuracyCircle.style.width = `${size}px`;
      accuracyCircle.style.height = `${size}px`;
    }
    
  }, [latitude, longitude, accuracy]);

  return (
    <div 
      ref={mapContainerRef} 
      style={{ 
        width: '100%', 
        height, 
        position: 'relative',
        backgroundColor: '#f0f0f0',
        borderRadius: '8px',
        overflow: 'hidden'
      }}
    >
      <div className="flex items-center justify-center h-full text-muted-foreground">
        Loading map...
      </div>
    </div>
  );
}