import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { apiRequest } from '@/lib/queryClient';
import { toast } from '@/hooks/use-toast';
import LocationMap from './LocationMap';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertCircle, MapPin, Navigation, Share2 } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

interface LocationSharingProps {
  bookingId: number;
  parentId: number;
  sitterId: number;
  isSitter: boolean;
}

export default function LocationSharing({ bookingId, parentId, sitterId, isSitter }: LocationSharingProps) {
  const [isSharing, setIsSharing] = useState(false);
  const [trackingId, setTrackingId] = useState<number | null>(null);
  const [currentLocation, setCurrentLocation] = useState<{
    latitude: number;
    longitude: number;
    accuracy: number | null;
  } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [watchId, setWatchId] = useState<number | null>(null);

  // Check if there's already active location sharing for this booking
  useEffect(() => {
    async function checkActiveLocationSharing() {
      try {
        const response = await apiRequest('GET', `/api/location/active?bookingId=${bookingId}`);
        if (response.ok) {
          const data = await response.json();
          setTrackingId(data.id);
          setIsSharing(data.isSharing);
          setCurrentLocation({
            latitude: data.latitude,
            longitude: data.longitude,
            accuracy: data.accuracy
          });
        }
      } catch (error) {
        console.error('Error checking active location sharing:', error);
      }
    }

    if (bookingId) {
      checkActiveLocationSharing();
    }
  }, [bookingId]);

  // Start or stop watching location
  useEffect(() => {
    if (isSharing && !watchId && isSitter) {
      // Only sitters can share their location
      if (navigator.geolocation) {
        const id = navigator.geolocation.watchPosition(
          handlePositionSuccess,
          handlePositionError,
          {
            enableHighAccuracy: true,
            maximumAge: 30000,
            timeout: 27000
          }
        );
        setWatchId(id);
      } else {
        setError('Geolocation is not supported by this browser.');
      }
    } else if (!isSharing && watchId !== null) {
      navigator.geolocation.clearWatch(watchId);
      setWatchId(null);
    }

    return () => {
      if (watchId !== null) {
        navigator.geolocation.clearWatch(watchId);
      }
    };
  }, [isSharing, watchId, isSitter]);

  const handlePositionSuccess = async (position: GeolocationPosition) => {
    const { latitude, longitude, accuracy } = position.coords;
    
    setCurrentLocation({
      latitude,
      longitude,
      accuracy
    });
    
    if (trackingId) {
      try {
        await apiRequest('PUT', `/api/location/${trackingId}`, {
          latitude,
          longitude,
          accuracy
        });
      } catch (error) {
        console.error('Error updating location:', error);
      }
    }
  };

  const handlePositionError = (error: GeolocationPositionError) => {
    setError(
      error.code === 1
        ? 'Location permission denied. Please enable location services for this site.'
        : error.code === 2
        ? 'Location information is unavailable at this time.'
        : 'Location request timed out. Please try again.'
    );
  };

  const startLocationSharing = async () => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by this browser.');
      return;
    }

    try {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude, accuracy } = position.coords;
          
          const response = await apiRequest('POST', '/api/location/start', {
            bookingId,
            parentId,
            sitterId,
            latitude,
            longitude,
            accuracy,
            isSharing: true
          });

          if (response.ok) {
            const data = await response.json();
            setTrackingId(data.id);
            setIsSharing(true);
            toast({
              title: 'Location sharing started',
              description: 'Your location is now being shared with the parent.'
            });
          } else {
            const error = await response.json();
            setError(error.message || 'Failed to start location sharing');
          }
        },
        (error) => {
          handlePositionError(error);
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 0
        }
      );
    } catch (error) {
      console.error('Error starting location sharing:', error);
      setError('Failed to start location sharing');
    }
  };

  const stopLocationSharing = async () => {
    if (trackingId) {
      try {
        await apiRequest('PUT', `/api/location/${trackingId}/stop`, {});
        setIsSharing(false);
        toast({
          title: 'Location sharing stopped',
          description: 'Your location is no longer being shared.'
        });
      } catch (error) {
        console.error('Error stopping location sharing:', error);
        setError('Failed to stop location sharing');
      }
    }
  };

  if (!bookingId) {
    return null;
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MapPin className="h-5 w-5 text-rose-500" />
          Real-time Location Sharing
        </CardTitle>
        <CardDescription>
          {isSitter 
            ? "Share your location with parents during the sitting job for safety and peace of mind." 
            : "View the sitter's real-time location during the sitting job."}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {currentLocation && (
          <div className="mb-4">
            <LocationMap 
              latitude={currentLocation.latitude} 
              longitude={currentLocation.longitude}
              accuracy={currentLocation.accuracy || undefined}
            />
          </div>
        )}

        {isSitter ? (
          <div className="flex flex-col space-y-2">
            {isSharing ? (
              <Button 
                variant="destructive" 
                onClick={stopLocationSharing}
                className="w-full"
              >
                Stop Sharing Location
              </Button>
            ) : (
              <Button 
                variant="default" 
                onClick={startLocationSharing}
                className="w-full"
              >
                <Share2 className="mr-2 h-4 w-4" />
                Start Sharing Location
              </Button>
            )}
            {isSharing && (
              <p className="text-sm text-muted-foreground text-center">
                Your location is currently being shared with the parent
              </p>
            )}
          </div>
        ) : (
          <div>
            {isSharing ? (
              <div className="text-center p-2 bg-green-100 dark:bg-green-900 rounded-md">
                <p className="text-sm text-green-700 dark:text-green-300">
                  <Navigation className="inline-block mr-1 h-4 w-4" />
                  Sitter is currently sharing their location
                </p>
              </div>
            ) : (
              <div className="text-center p-2 bg-amber-100 dark:bg-amber-900 rounded-md">
                <p className="text-sm text-amber-700 dark:text-amber-300">
                  The sitter is not currently sharing their location
                </p>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}