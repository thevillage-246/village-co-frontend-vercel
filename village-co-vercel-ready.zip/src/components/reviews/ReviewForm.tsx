import React from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Star } from 'lucide-react';

const reviewSchema = z.object({
  rating: z.number().min(1, { message: 'Please select a rating' }).max(5),
  comment: z.string().min(10, { message: 'Comment must be at least 10 characters' }),
});

type ReviewFormValues = z.infer<typeof reviewSchema>;

interface ReviewFormProps {
  bookingId: number;
  revieweeId?: number;
  onComplete?: () => void;
}

const ReviewForm: React.FC<ReviewFormProps> = ({ bookingId, revieweeId, onComplete }) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Initialize form with react-hook-form
  const form = useForm<ReviewFormValues>({
    resolver: zodResolver(reviewSchema),
    defaultValues: {
      rating: 0,
      comment: '',
    },
  });

  // Create submit mutation
  const submitReview = useMutation({
    mutationFn: async (values: ReviewFormValues) => {
      if (!user || !revieweeId) {
        throw new Error('Missing user or reviewee information');
      }
      
      const response = await apiRequest('POST', `/api/bookings/${bookingId}/reviews`, {
        ...values,
        reviewerId: user.id,
        revieweeId: revieweeId,
      });
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: 'Review Submitted',
        description: 'Thank you for your feedback!',
      });
      
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: [`/api/bookings/${bookingId}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/sitters/${revieweeId}/reviews`] });
      
      // Call onComplete callback if provided
      if (onComplete) {
        onComplete();
      }
    },
    onError: (error: any) => {
      toast({
        title: 'Failed to Submit Review',
        description: error.message || 'Something went wrong. Please try again.',
        variant: 'destructive',
      });
    },
  });

  // Handle form submission
  const onSubmit = (values: ReviewFormValues) => {
    submitReview.mutate(values);
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="rating"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Rating</FormLabel>
              <FormControl>
                <div className="flex items-center">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <Star
                      key={star}
                      className={`h-8 w-8 cursor-pointer ${
                        star <= field.value
                          ? 'text-yellow-400 fill-current'
                          : 'text-gray-300'
                      }`}
                      onClick={() => field.onChange(star)}
                    />
                  ))}
                </div>
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="comment"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Comment</FormLabel>
              <FormControl>
                <Textarea
                  placeholder="Share your experience with this sitter..."
                  className="resize-none min-h-[120px]"
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex justify-end gap-2">
          {onComplete && (
            <Button type="button" variant="outline" onClick={onComplete}>
              Cancel
            </Button>
          )}
          <Button type="submit" disabled={submitReview.isPending}>
            {submitReview.isPending ? 'Submitting...' : 'Submit Review'}
          </Button>
        </div>
      </form>
    </Form>
  );
};

export default ReviewForm;
