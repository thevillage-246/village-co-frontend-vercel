import React from 'react';
import { format } from 'date-fns';
import { Star } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

interface Review {
  id: number;
  rating: number;
  comment: string;
  createdAt: string;
  reviewer?: {
    id: number;
    firstName: string;
    lastName: string;
  };
}

interface ReviewListProps {
  reviews: Review[];
}

const ReviewList: React.FC<ReviewListProps> = ({ reviews }) => {
  if (!reviews || reviews.length === 0) {
    return (
      <div className="py-4 text-center">
        <p className="text-muted-foreground">No reviews yet.</p>
      </div>
    );
  }

  // Sort reviews by date (newest first)
  const sortedReviews = [...reviews].sort(
    (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  );

  return (
    <div className="space-y-6">
      {sortedReviews.map((review) => (
        <div key={review.id} className="border-b pb-5 mb-5 last:border-0 last:mb-0 last:pb-0">
          <div className="flex items-start gap-4">
            <Avatar className="h-10 w-10">
              <AvatarFallback>
                {review.reviewer
                  ? `${review.reviewer.firstName[0]}${review.reviewer.lastName[0]}`
                  : 'UK'}
              </AvatarFallback>
            </Avatar>

            <div className="flex-1 space-y-1.5">
              <div className="flex items-center justify-between">
                <div>
                  {review.reviewer ? (
                    <p className="font-medium">
                      {review.reviewer.firstName} {review.reviewer.lastName}
                    </p>
                  ) : (
                    <p className="font-medium">Anonymous</p>
                  )}
                  <p className="text-sm text-muted-foreground">
                    {format(new Date(review.createdAt), 'MMMM d, yyyy')}
                  </p>
                </div>

                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className="h-4 w-4"
                      fill={i < review.rating ? "#FBBF24" : "none"}
                      stroke={i < review.rating ? "#FBBF24" : "currentColor"}
                    />
                  ))}
                </div>
              </div>

              <p className="text-sm leading-relaxed whitespace-pre-line">
                {review.comment}
              </p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ReviewList;
