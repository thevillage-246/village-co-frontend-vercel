import React from 'react';

// A simple navbar component for testing
const SimpleNavbar: React.FC = () => {
  return (
    <nav className="bg-white shadow-md">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          <div className="text-xl font-bold text-wine">
            The Village Co.
          </div>
          <div className="flex items-center space-x-4">
            <button 
              className="px-4 py-2 bg-rose text-wine rounded-md hover:bg-opacity-80"
            >
              Sign In
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default SimpleNavbar;