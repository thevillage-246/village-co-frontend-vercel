import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { MapPin, Shield, AlertTriangle, Clock } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

interface LocationData {
  latitude: number;
  longitude: number;
  accuracy: number;
  timestamp: number;
  address?: string;
}

interface GPSLocationSharingProps {
  bookingId: number;
  isActive: boolean;
  parentId: number;
  sitterId: number;
}

export default function GPSLocationSharing({ 
  bookingId, 
  isActive, 
  parentId, 
  sitterId 
}: GPSLocationSharingProps) {
  const [isSharing, setIsSharing] = useState(false);
  const [currentLocation, setCurrentLocation] = useState<LocationData | null>(null);
  const [watchId, setWatchId] = useState<number | null>(null);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [permissionStatus, setPermissionStatus] = useState<PermissionState>('prompt');

  // Check geolocation permission on mount
  useEffect(() => {
    if ('permissions' in navigator) {
      navigator.permissions.query({ name: 'geolocation' }).then((result) => {
        setPermissionStatus(result.state);
        
        result.addEventListener('change', () => {
          setPermissionStatus(result.state);
        });
      });
    }
  }, []);

  // Start location sharing when booking is active
  useEffect(() => {
    if (isActive && !isSharing) {
      startLocationSharing();
    } else if (!isActive && isSharing) {
      stopLocationSharing();
    }

    return () => {
      if (watchId) {
        navigator.geolocation.clearWatch(watchId);
      }
    };
  }, [isActive]);

  const startLocationSharing = async () => {
    if (!navigator.geolocation) {
      toast({
        title: "Location Not Supported",
        description: "Your device doesn't support location sharing",
        variant: "destructive"
      });
      return;
    }

    try {
      const position = await getCurrentPosition();
      const locationData: LocationData = {
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
        accuracy: position.coords.accuracy,
        timestamp: Date.now()
      };

      // Send initial location
      await sendLocationUpdate(locationData);
      setCurrentLocation(locationData);
      setLastUpdate(new Date());

      // Start watching position
      const id = navigator.geolocation.watchPosition(
        (position) => {
          const newLocationData: LocationData = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: position.coords.accuracy,
            timestamp: Date.now()
          };
          
          handleLocationUpdate(newLocationData);
        },
        (error) => {
          console.error('Location error:', error);
          handleLocationError(error);
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 30000 // 30 seconds
        }
      );

      setWatchId(id);
      setIsSharing(true);

      toast({
        title: "Location Sharing Started",
        description: "Your location is now being shared for safety"
      });

    } catch (error) {
      console.error('Failed to start location sharing:', error);
      toast({
        title: "Location Sharing Failed",
        description: "Could not start location sharing. Please check permissions.",
        variant: "destructive"
      });
    }
  };

  const stopLocationSharing = () => {
    if (watchId) {
      navigator.geolocation.clearWatch(watchId);
      setWatchId(null);
    }
    
    setIsSharing(false);
    setCurrentLocation(null);
    
    // Notify that location sharing stopped
    apiRequest('POST', `/api/location/stop-sharing`, { bookingId })
      .catch(error => console.error('Failed to stop location sharing:', error));

    toast({
      title: "Location Sharing Stopped",
      description: "Location sharing has been disabled"
    });
  };

  const getCurrentPosition = (): Promise<GeolocationPosition> => {
    return new Promise((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(resolve, reject, {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 60000
      });
    });
  };

  const handleLocationUpdate = async (locationData: LocationData) => {
    // Only update if location changed significantly (more than 10 meters)
    if (currentLocation) {
      const distance = calculateDistance(
        currentLocation.latitude,
        currentLocation.longitude,
        locationData.latitude,
        locationData.longitude
      );
      
      if (distance < 0.01) { // Less than 10 meters
        return;
      }
    }

    try {
      await sendLocationUpdate(locationData);
      setCurrentLocation(locationData);
      setLastUpdate(new Date());
    } catch (error) {
      console.error('Failed to send location update:', error);
    }
  };

  const sendLocationUpdate = async (locationData: LocationData) => {
    // Get address from coordinates
    const address = await reverseGeocode(locationData.latitude, locationData.longitude);
    
    const updateData = {
      bookingId,
      ...locationData,
      address
    };

    await apiRequest('POST', '/api/location/update', updateData);

    // Send alert if location seems unusual (far from expected location)
    checkForLocationAlerts(locationData);
  };

  const reverseGeocode = async (lat: number, lng: number): Promise<string> => {
    try {
      const response = await fetch(
        `https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=${import.meta.env.VITE_GOOGLE_MAPS_API_KEY}`
      );
      const data = await response.json();
      
      if (data.results && data.results.length > 0) {
        return data.results[0].formatted_address;
      }
    } catch (error) {
      console.error('Reverse geocoding failed:', error);
    }
    
    return `${lat.toFixed(6)}, ${lng.toFixed(6)}`;
  };

  const checkForLocationAlerts = async (locationData: LocationData) => {
    // Check if location is far from booking address
    try {
      const response = await apiRequest('POST', '/api/location/check-alerts', {
        bookingId,
        currentLocation: locationData
      });

      if (response.alert) {
        // Send notification to parent about location change
        await apiRequest('POST', '/api/notifications/location-alert', {
          parentId,
          sitterId,
          bookingId,
          location: locationData,
          alertType: response.alertType,
          message: response.message
        });
      }
    } catch (error) {
      console.error('Failed to check location alerts:', error);
    }
  };

  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371; // Earth's radius in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  };

  const handleLocationError = (error: GeolocationPositionError) => {
    let message = "Unknown location error";
    
    switch(error.code) {
      case error.PERMISSION_DENIED:
        message = "Location permission denied. Please enable location access.";
        break;
      case error.POSITION_UNAVAILABLE:
        message = "Location information unavailable.";
        break;
      case error.TIMEOUT:
        message = "Location request timed out.";
        break;
    }

    toast({
      title: "Location Error",
      description: message,
      variant: "destructive"
    });

    // Notify parent of location sharing issue
    apiRequest('POST', '/api/notifications/location-error', {
      parentId,
      sitterId,
      bookingId,
      error: message
    }).catch(console.error);
  };

  const toggleLocationSharing = () => {
    if (isSharing) {
      stopLocationSharing();
    } else {
      startLocationSharing();
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MapPin className="h-5 w-5" />
          GPS Location Sharing
          {isSharing && <Badge variant="default" className="bg-green-500">Active</Badge>}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="h-4 w-4 text-blue-500" />
            <span className="text-sm">Share location for safety</span>
          </div>
          <Switch 
            checked={isSharing} 
            onCheckedChange={toggleLocationSharing}
            disabled={!isActive}
          />
        </div>

        {permissionStatus === 'denied' && (
          <div className="flex items-center gap-2 p-3 bg-red-50 rounded-lg">
            <AlertTriangle className="h-4 w-4 text-red-500" />
            <span className="text-sm text-red-700">
              Location permission denied. Please enable in browser settings.
            </span>
          </div>
        )}

        {isSharing && currentLocation && (
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Clock className="h-4 w-4" />
              Last updated: {lastUpdate?.toLocaleTimeString()}
            </div>
            
            <div className="text-xs text-gray-500">
              Accuracy: ±{Math.round(currentLocation.accuracy)}m
            </div>

            {currentLocation.address && (
              <div className="text-sm text-gray-700 p-2 bg-gray-50 rounded">
                📍 {currentLocation.address}
              </div>
            )}
          </div>
        )}

        {!isActive && (
          <div className="text-sm text-gray-500 italic">
            Location sharing is only available during active bookings
          </div>
        )}
      </CardContent>
    </Card>
  );
}