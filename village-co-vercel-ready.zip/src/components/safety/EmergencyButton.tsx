import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AlertTriangle, Phone, MessageSquare, MapPin, Shield } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

interface EmergencyButtonProps {
  bookingId: number;
  parentId: number;
  sitterId: number;
  emergencyContacts?: Array<{
    id: number;
    name: string;
    phone: string;
    relationship: string;
  }>;
  currentLocation?: {
    latitude: number;
    longitude: number;
    address?: string;
  };
}

export default function EmergencyButton({ 
  bookingId, 
  parentId, 
  sitterId, 
  emergencyContacts = [],
  currentLocation 
}: EmergencyButtonProps) {
  const [isEmergencyActive, setIsEmergencyActive] = useState(false);
  const [emergencyType, setEmergencyType] = useState<string>('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [countdown, setCountdown] = useState<number | null>(null);
  const [countdownInterval, setCountdownInterval] = useState<NodeJS.Timeout | null>(null);

  const emergencyTypes = [
    { 
      id: 'medical', 
      label: 'Medical Emergency', 
      icon: '🚑',
      description: 'Child injury, illness, or medical concern',
      priority: 'critical'
    },
    { 
      id: 'safety', 
      label: 'Safety Concern', 
      icon: '⚠️',
      description: 'Immediate danger or security issue',
      priority: 'critical'
    },
    { 
      id: 'lost', 
      label: 'Child Missing', 
      icon: '🔍',
      description: 'Cannot locate child or child has wandered',
      priority: 'critical'
    },
    { 
      id: 'behavioral', 
      label: 'Behavioral Crisis', 
      icon: '😰',
      description: 'Child having severe behavioral episode',
      priority: 'high'
    },
    { 
      id: 'property', 
      label: 'Property Emergency', 
      icon: '🏠',
      description: 'Fire, flood, break-in, or property damage',
      priority: 'high'
    },
    { 
      id: 'other', 
      label: 'Other Emergency', 
      icon: '📞',
      description: 'Other urgent situation requiring immediate help',
      priority: 'medium'
    }
  ];

  const startEmergencyCountdown = (type: string) => {
    setEmergencyType(type);
    setCountdown(10); // 10 second countdown
    setIsDialogOpen(false);

    const interval = setInterval(() => {
      setCountdown(prev => {
        if (prev === null || prev <= 1) {
          clearInterval(interval);
          triggerEmergency(type);
          return null;
        }
        return prev - 1;
      });
    }, 1000);

    setCountdownInterval(interval);

    toast({
      title: "Emergency Alert Starting",
      description: `Emergency alert will be sent in 10 seconds. Tap to cancel.`,
      variant: "destructive",
      duration: 10000
    });
  };

  const cancelEmergency = () => {
    if (countdownInterval) {
      clearInterval(countdownInterval);
      setCountdownInterval(null);
    }
    setCountdown(null);
    setEmergencyType('');
    
    toast({
      title: "Emergency Alert Cancelled",
      description: "Emergency alert has been cancelled"
    });
  };

  const triggerEmergency = async (type: string) => {
    setIsEmergencyActive(true);
    setCountdown(null);

    try {
      // Get current location if available
      let location = currentLocation;
      if (!location && navigator.geolocation) {
        try {
          const position = await getCurrentPosition();
          location = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          };
        } catch (error) {
          console.error('Could not get current location:', error);
        }
      }

      // Send emergency notification
      await apiRequest('POST', '/api/emergency/trigger', {
        bookingId,
        emergencyType: type,
        location,
        timestamp: new Date().toISOString()
      });

      // Send push notifications to all emergency contacts
      await sendEmergencyNotifications(type, location);

      // Send SMS to emergency contacts
      await sendEmergencySMS(type, location);

      toast({
        title: "Emergency Alert Sent",
        description: "Emergency services and contacts have been notified",
        variant: "destructive"
      });

    } catch (error) {
      console.error('Failed to trigger emergency:', error);
      toast({
        title: "Emergency Alert Failed",
        description: "Could not send emergency alert. Please call emergency services directly.",
        variant: "destructive"
      });
    }
  };

  const sendEmergencyNotifications = async (type: string, location?: any) => {
    const emergencyData = {
      type: 'emergency',
      title: '🚨 EMERGENCY ALERT',
      body: `Emergency reported during babysitting session: ${emergencyTypes.find(t => t.id === type)?.label}`,
      urgent: true,
      data: {
        bookingId,
        emergencyType: type,
        location,
        emergencyNumber: '111', // New Zealand emergency number
        actions: [
          { action: 'call_emergency', title: 'Call 111' },
          { action: 'view_location', title: 'View Location' },
          { action: 'contact_sitter', title: 'Contact Sitter' }
        ]
      }
    };

    // Notify parent
    await apiRequest('POST', '/api/notifications/push', {
      userId: parentId,
      ...emergencyData
    });

    // Notify emergency contacts
    for (const contact of emergencyContacts) {
      await apiRequest('POST', '/api/notifications/emergency-contact', {
        contactId: contact.id,
        ...emergencyData
      });
    }
  };

  const sendEmergencySMS = async (type: string, location?: any) => {
    const emergencyInfo = emergencyTypes.find(t => t.id === type);
    const locationText = location?.address || 
      (location ? `${location.latitude}, ${location.longitude}` : 'Location unavailable');

    const message = `🚨 EMERGENCY ALERT: ${emergencyInfo?.label} reported during babysitting session. Location: ${locationText}. Contact sitter immediately or call 111.`;

    // Send to parent
    await apiRequest('POST', '/api/sms/emergency', {
      to: 'parent', // Will resolve to parent's phone
      message,
      bookingId,
      emergencyType: type
    });

    // Send to emergency contacts
    for (const contact of emergencyContacts) {
      await apiRequest('POST', '/api/sms/send', {
        to: contact.phone,
        message: `${message} - ${contact.name}, you're listed as emergency contact.`
      });
    }
  };

  const getCurrentPosition = (): Promise<GeolocationPosition> => {
    return new Promise((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(resolve, reject, {
        enableHighAccuracy: true,
        timeout: 5000,
        maximumAge: 30000
      });
    });
  };

  const callEmergencyServices = () => {
    // Open phone dialer with emergency number
    window.open('tel:111', '_self');
  };

  const contactParent = () => {
    // This would typically get parent's phone from the booking
    window.open('tel:', '_self'); // Will be populated with actual parent phone
  };

  return (
    <>
      {/* Emergency Button */}
      <Card className="w-full border-red-200 bg-red-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-red-700">
            <AlertTriangle className="h-5 w-5" />
            Emergency Assistance
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {!isEmergencyActive && countdown === null && (
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button 
                  variant="destructive" 
                  size="lg" 
                  className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-4"
                >
                  <AlertTriangle className="h-6 w-6 mr-2" />
                  EMERGENCY
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle className="text-red-700">Select Emergency Type</DialogTitle>
                </DialogHeader>
                <div className="grid gap-3">
                  {emergencyTypes.map((emergency) => (
                    <Button
                      key={emergency.id}
                      variant="outline"
                      className="justify-start h-auto p-4 text-left"
                      onClick={() => startEmergencyCountdown(emergency.id)}
                    >
                      <div className="flex items-start gap-3">
                        <span className="text-2xl">{emergency.icon}</span>
                        <div>
                          <div className="font-medium">{emergency.label}</div>
                          <div className="text-sm text-gray-600">{emergency.description}</div>
                        </div>
                      </div>
                    </Button>
                  ))}
                </div>
              </DialogContent>
            </Dialog>
          )}

          {countdown !== null && (
            <div className="text-center space-y-4">
              <div className="text-3xl font-bold text-red-600">{countdown}</div>
              <div className="text-red-700">
                Emergency alert will be sent in {countdown} seconds
              </div>
              <Button 
                variant="outline" 
                onClick={cancelEmergency}
                className="w-full"
              >
                Cancel Emergency Alert
              </Button>
            </div>
          )}

          {isEmergencyActive && (
            <div className="text-center space-y-4 p-4 bg-red-100 rounded-lg">
              <div className="text-red-700 font-bold">
                🚨 EMERGENCY ALERT ACTIVE
              </div>
              <div className="text-sm text-red-600">
                Emergency contacts have been notified
              </div>
            </div>
          )}

          {/* Quick Action Buttons */}
          <div className="grid grid-cols-2 gap-3">
            <Button 
              variant="outline" 
              onClick={callEmergencyServices}
              className="border-red-200 text-red-700 hover:bg-red-50"
            >
              <Phone className="h-4 w-4 mr-2" />
              Call 111
            </Button>
            <Button 
              variant="outline" 
              onClick={contactParent}
              className="border-red-200 text-red-700 hover:bg-red-50"
            >
              <MessageSquare className="h-4 w-4 mr-2" />
              Contact Parent
            </Button>
          </div>

          {/* Emergency Contacts */}
          {emergencyContacts.length > 0 && (
            <div className="space-y-2">
              <div className="text-sm font-medium text-gray-700">Emergency Contacts:</div>
              {emergencyContacts.slice(0, 2).map((contact) => (
                <div key={contact.id} className="flex items-center justify-between text-sm">
                  <span>{contact.name} ({contact.relationship})</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => window.open(`tel:${contact.phone}`, '_self')}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Phone className="h-3 w-3" />
                  </Button>
                </div>
              ))}
            </div>
          )}

          {/* Safety Tips */}
          <div className="text-xs text-gray-600 p-3 bg-gray-50 rounded">
            <div className="flex items-start gap-2">
              <Shield className="h-3 w-3 mt-0.5 text-blue-500" />
              <div>
                <strong>Emergency Guidelines:</strong> Call 111 for immediate life-threatening emergencies. 
                For non-urgent medical advice, call Healthline: 0800 611 116.
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </>
  );
}