import { useState, useEffect } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { MapPin, Shield, Clock, AlertTriangle, Phone, Navigation } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface LocationData {
  latitude: number;
  longitude: number;
  accuracy: number;
  timestamp: Date;
}

interface SafetyDashboardProps {
  bookingId: number;
  isActive: boolean;
  parentMode?: boolean;
}

export function SafetyDashboard({ bookingId, isActive, parentMode = false }: SafetyDashboardProps) {
  const [location, setLocation] = useState<LocationData | null>(null);
  const [isTracking, setIsTracking] = useState(false);
  const [checkInStatus, setCheckInStatus] = useState<'pending' | 'checked-in' | 'checked-out'>('pending');
  const [sosActive, setSosActive] = useState(false);
  const { toast } = useToast();

  // Get user location
  const getCurrentLocation = (): Promise<LocationData> => {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error('Geolocation not supported'));
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (position) => {
          resolve({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: position.coords.accuracy,
            timestamp: new Date()
          });
        },
        (error) => reject(error),
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 60000
        }
      );
    });
  };

  // Check-in mutation
  const checkInMutation = useMutation({
    mutationFn: async () => {
      const locationData = await getCurrentLocation();
      setLocation(locationData);
      
      return apiRequest('POST', `/api/bookings/${bookingId}/checkin`, {
        latitude: locationData.latitude,
        longitude: locationData.longitude,
        timestamp: locationData.timestamp.toISOString()
      }).then(res => res.json());
    },
    onSuccess: () => {
      setCheckInStatus('checked-in');
      setIsTracking(true);
      toast({
        title: "Check-in Successful",
        description: "Location confirmed and tracking started"
      });
    },
    onError: (error: any) => {
      toast({
        title: "Check-in Failed",
        description: error.message || "Unable to record location",
        variant: "destructive"
      });
    }
  });

  // Check-out mutation
  const checkOutMutation = useMutation({
    mutationFn: async () => {
      const locationData = await getCurrentLocation();
      
      return apiRequest('POST', `/api/bookings/${bookingId}/checkout`, {
        latitude: locationData.latitude,
        longitude: locationData.longitude,
        timestamp: locationData.timestamp.toISOString(),
        notes: 'Session completed successfully'
      }).then(res => res.json());
    },
    onSuccess: () => {
      setCheckInStatus('checked-out');
      setIsTracking(false);
      toast({
        title: "Check-out Successful",
        description: "Session completed and location tracking stopped"
      });
    }
  });

  // Emergency SOS mutation
  const sosMutation = useMutation({
    mutationFn: async (emergencyType: string) => {
      const locationData = await getCurrentLocation();
      
      return apiRequest('POST', '/api/emergency/sos', {
        bookingId,
        latitude: locationData.latitude,
        longitude: locationData.longitude,
        emergencyType,
        message: `Emergency assistance requested during booking ${bookingId}`
      }).then(res => res.json());
    },
    onSuccess: (data) => {
      setSosActive(true);
      toast({
        title: "Emergency Alert Sent",
        description: data.message,
        variant: "destructive"
      });
    }
  });

  // Start location tracking when checked in
  useEffect(() => {
    if (!isTracking) return;

    const trackingInterval = setInterval(async () => {
      try {
        const locationData = await getCurrentLocation();
        setLocation(locationData);
        console.log('Location updated:', locationData);
      } catch (error) {
        console.error('Location tracking error:', error);
      }
    }, 60000); // Update every minute

    return () => clearInterval(trackingInterval);
  }, [isTracking]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'checked-in': return 'bg-green-100 text-green-800 border-green-200';
      case 'checked-out': return 'bg-blue-100 text-blue-800 border-blue-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'checked-in': return 'Active Session';
      case 'checked-out': return 'Session Complete';
      default: return 'Ready to Start';
    }
  };

  return (
    <div className="space-y-4">
      {/* Safety Status Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-green-600" />
            Safety Dashboard
          </CardTitle>
          <CardDescription>
            {parentMode ? "Monitor your child's session in real-time" : "Check-in/out and emergency features"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Badge className={getStatusColor(checkInStatus)}>
                {getStatusText(checkInStatus)}
              </Badge>
              {isTracking && (
                <Badge variant="outline" className="text-green-700 border-green-200">
                  <Navigation className="w-3 h-3 mr-1" />
                  Location Tracking Active
                </Badge>
              )}
            </div>
            {location && (
              <div className="text-sm text-gray-600">
                <MapPin className="w-4 h-4 inline mr-1" />
                Last updated: {location.timestamp.toLocaleTimeString()}
              </div>
            )}
          </div>

          {/* Action Buttons */}
          {!parentMode && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <Button
                onClick={() => checkInMutation.mutate()}
                disabled={checkInStatus !== 'pending' || checkInMutation.isPending}
                className="bg-green-600 hover:bg-green-700 text-white"
              >
                <MapPin className="w-4 h-4 mr-2" />
                Check In
              </Button>

              <Button
                onClick={() => checkOutMutation.mutate()}
                disabled={checkInStatus !== 'checked-in' || checkOutMutation.isPending}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                <Clock className="w-4 h-4 mr-2" />
                Check Out
              </Button>

              <Button
                onClick={() => sosMutation.mutate('general')}
                disabled={sosActive || sosMutation.isPending}
                variant="destructive"
                className="bg-red-600 hover:bg-red-700"
              >
                <AlertTriangle className="w-4 h-4 mr-2" />
                Emergency SOS
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Emergency Contacts Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Phone className="w-5 h-5 text-blue-600" />
            Emergency Contacts
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-red-50 rounded-lg border border-red-200">
              <div>
                <p className="font-medium text-red-800">Emergency Services</p>
                <p className="text-sm text-red-600">Police, Fire, Ambulance</p>
              </div>
              <Button
                onClick={() => window.open('tel:111', '_self')}
                size="sm"
                variant="destructive"
              >
                Call 111
              </Button>
            </div>

            <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg border border-blue-200">
              <div>
                <p className="font-medium text-blue-800">Village Co. Support</p>
                <p className="text-sm text-blue-600">24/7 platform support</p>
              </div>
              <Button
                onClick={() => window.open('tel:+6478079114', '_self')}
                size="sm"
                className="bg-blue-600 hover:bg-blue-700"
              >
                Call Support
              </Button>
            </div>

            {!parentMode && (
              <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg border border-green-200">
                <div>
                  <p className="font-medium text-green-800">Parent Contact</p>
                  <p className="text-sm text-green-600">Primary emergency contact</p>
                </div>
                <Button
                  onClick={() => window.open('tel:+64123456789', '_self')}
                  size="sm"
                  className="bg-green-600 hover:bg-green-700"
                >
                  Call Parent
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* SOS Alert */}
      {sosActive && (
        <Alert className="border-red-200 bg-red-50">
          <AlertTriangle className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-800">
            <strong>Emergency Alert Active</strong> - Help has been notified and is on the way. 
            Estimated response time: 2-5 minutes.
          </AlertDescription>
        </Alert>
      )}

      {/* Location Info */}
      {location && parentMode && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="w-5 h-5 text-gray-600" />
              Current Location
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm">
              <p><strong>Coordinates:</strong> {location.latitude.toFixed(6)}, {location.longitude.toFixed(6)}</p>
              <p><strong>Accuracy:</strong> ±{Math.round(location.accuracy)}m</p>
              <p><strong>Last Update:</strong> {location.timestamp.toLocaleString()}</p>
              <Button
                size="sm"
                variant="outline"
                onClick={() => window.open(`https://maps.google.com?q=${location.latitude},${location.longitude}`, '_blank')}
              >
                View on Map
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}