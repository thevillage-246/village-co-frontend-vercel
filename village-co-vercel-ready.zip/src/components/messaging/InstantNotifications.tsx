import React, { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Bell, MessageCircle, Volume2, VolumeX } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';

interface InstantNotificationsProps {
  enabled?: boolean;
  onToggle?: (enabled: boolean) => void;
}

export default function InstantNotifications({ 
  enabled = true, 
  onToggle 
}: InstantNotificationsProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [notificationsEnabled, setNotificationsEnabled] = useState(enabled);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [permission, setPermission] = useState<NotificationPermission>('default');

  // Request notification permission on component mount
  useEffect(() => {
    if ('Notification' in window) {
      setPermission(Notification.permission);
      
      if (Notification.permission === 'default') {
        Notification.requestPermission().then(permission => {
          setPermission(permission);
          if (permission === 'granted') {
            toast({
              title: "Notifications Enabled",
              description: "You'll now receive instant notifications for new messages",
              variant: "default",
            });
          }
        });
      }
    }
  }, [toast]);

  // Show browser notification for new messages
  const showBrowserNotification = (title: string, body: string, icon?: string) => {
    if (permission === 'granted' && notificationsEnabled) {
      const notification = new Notification(title, {
        body,
        icon: icon || '/favicon.ico',
        badge: '/favicon.ico',
        requireInteraction: true,
        actions: [
          { action: 'reply', title: 'Reply' },
          { action: 'view', title: 'View Messages' }
        ]
      });

      // Auto-close after 5 seconds
      setTimeout(() => notification.close(), 5000);

      // Handle notification clicks
      notification.onclick = () => {
        window.focus();
        // Navigate to messages page
        window.location.href = '/messages';
        notification.close();
      };
    }
  };

  // Play notification sound
  const playNotificationSound = () => {
    if (soundEnabled) {
      // Create a subtle notification sound
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
      oscillator.frequency.setValueAtTime(600, audioContext.currentTime + 0.1);
      
      gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
      
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.5);
    }
  };

  // Handle new message notifications
  const handleNewMessage = (message: any) => {
    if (message.senderId !== user?.id) {
      const senderName = message.sender ? 
        `${message.sender.firstName} ${message.sender.lastName}` : 
        'Someone';
      
      // Show browser notification
      showBrowserNotification(
        `New message from ${senderName}`,
        message.content.substring(0, 100),
        message.sender?.photoUrl
      );
      
      // Play sound
      playNotificationSound();
      
      // Show toast notification
      toast({
        title: `💬 ${senderName}`,
        description: message.content.substring(0, 50) + (message.content.length > 50 ? '...' : ''),
        variant: "default",
      });
    }
  };

  // Listen for WebSocket messages
  useEffect(() => {
    if (!user) return;

    const handleMessage = (event: MessageEvent) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === 'new_message') {
          handleNewMessage(data.message);
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };

    // Listen for messages from the parent ChatContext
    window.addEventListener('message', handleMessage);
    
    return () => {
      window.removeEventListener('message', handleMessage);
    };
  }, [user, notificationsEnabled, soundEnabled]);

  const toggleNotifications = (enabled: boolean) => {
    setNotificationsEnabled(enabled);
    onToggle?.(enabled);
    
    if (enabled && permission !== 'granted') {
      Notification.requestPermission().then(permission => {
        setPermission(permission);
      });
    }
  };

  if (user?.role !== 'sitter') {
    return null; // Only show for sitters
  }

  return (
    <Card className="mb-4">
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <MessageCircle className="h-5 w-5 text-village-wine" />
            <div>
              <h3 className="font-medium">Instant Message Notifications</h3>
              <p className="text-sm text-muted-foreground">
                Get notified immediately when parents message you
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              {soundEnabled ? (
                <Volume2 className="h-4 w-4 text-village-wine" />
              ) : (
                <VolumeX className="h-4 w-4 text-muted-foreground" />
              )}
              <Switch
                checked={soundEnabled}
                onCheckedChange={setSoundEnabled}
                aria-label="Toggle sound notifications"
              />
            </div>
            <div className="flex items-center gap-2">
              <Bell className="h-4 w-4 text-village-wine" />
              <Switch
                checked={notificationsEnabled}
                onCheckedChange={toggleNotifications}
                aria-label="Toggle instant notifications"
              />
            </div>
          </div>
        </div>
        
        {permission === 'denied' && (
          <div className="mt-3 p-3 bg-orange-50 rounded-lg border border-orange-200">
            <p className="text-sm text-orange-800">
              Browser notifications are blocked. Please enable them in your browser settings to receive instant alerts.
            </p>
          </div>
        )}
        
        {permission === 'granted' && notificationsEnabled && (
          <div className="mt-3 p-3 bg-green-50 rounded-lg border border-green-200">
            <p className="text-sm text-green-800">
              ✓ Instant notifications enabled! You'll be alerted immediately when parents message you.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}