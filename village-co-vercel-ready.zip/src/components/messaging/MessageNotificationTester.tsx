import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useMutation, useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { MessageCircle, Send, TestTube } from 'lucide-react';

export default function MessageNotificationTester() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [testMessage, setTestMessage] = useState('Hey! I need a sitter for this weekend. Are you available?');
  const [selectedRecipientId, setSelectedRecipientId] = useState<string>('');

  // Fetch all users for testing
  const { data: allUsers } = useQuery({
    queryKey: ['/api/users'],
    enabled: user?.role === 'admin' || user?.role === 'sitter'
  });

  // Send test message mutation
  const sendTestMessage = useMutation({
    mutationFn: async ({ recipientId, content }: { recipientId: number; content: string }) => {
      const response = await apiRequest('POST', '/api/messages/direct', {
        senderId: user?.id,
        recipientId,
        content
      });
      
      if (!response.ok) {
        throw new Error('Failed to send test message');
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "✅ Test Message Sent",
        description: "Check if you received the instant notification!",
        variant: "default",
      });
      setTestMessage('');
    },
    onError: (error) => {
      toast({
        title: "❌ Test Failed",
        description: "Could not send test message. Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleSendTestMessage = () => {
    if (!selectedRecipientId || !testMessage.trim()) {
      toast({
        title: "Missing Information",
        description: "Please select a recipient and enter a message",
        variant: "destructive",
      });
      return;
    }

    sendTestMessage.mutate({
      recipientId: parseInt(selectedRecipientId),
      content: testMessage
    });
  };

  // Test browser notification
  const testBrowserNotification = () => {
    if ('Notification' in window) {
      if (Notification.permission === 'granted') {
        const notification = new Notification('Test Notification from The Village Co', {
          body: 'This is a test of the instant messaging notification system!',
          icon: '/favicon.ico',
          requireInteraction: true,
        });

        notification.onclick = () => {
          window.focus();
          notification.close();
        };

        setTimeout(() => notification.close(), 5000);

        toast({
          title: "🔔 Test Notification Sent",
          description: "Check if you saw the browser notification",
          variant: "default",
        });
      } else if (Notification.permission === 'denied') {
        toast({
          title: "❌ Notifications Blocked",
          description: "Please enable notifications in your browser settings",
          variant: "destructive",
        });
      } else {
        Notification.requestPermission().then(permission => {
          if (permission === 'granted') {
            testBrowserNotification(); // Retry after permission granted
          }
        });
      }
    } else {
      toast({
        title: "❌ Notifications Not Supported",
        description: "Your browser doesn't support notifications",
        variant: "destructive",
      });
    }
  };

  if (!user || (user.role !== 'admin' && user.role !== 'sitter')) {
    return null;
  }

  return (
    <Card className="mb-4 border-orange-200 bg-orange-50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-orange-800">
          <TestTube className="h-5 w-5" />
          Instant Messaging Test Center
        </CardTitle>
        <p className="text-sm text-orange-700">
          Test the instant notification system to ensure sitters receive immediate alerts
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-3">
            <label className="text-sm font-medium">Send Test Message</label>
            <Select value={selectedRecipientId} onValueChange={setSelectedRecipientId}>
              <SelectTrigger>
                <SelectValue placeholder="Select recipient..." />
              </SelectTrigger>
              <SelectContent>
                {allUsers?.filter((u: any) => u.id !== user.id).map((u: any) => (
                  <SelectItem key={u.id} value={u.id.toString()}>
                    {u.firstName} {u.lastName} ({u.role})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Textarea
              value={testMessage}
              onChange={(e) => setTestMessage(e.target.value)}
              placeholder="Enter test message..."
              rows={3}
            />
            
            <Button 
              onClick={handleSendTestMessage}
              disabled={sendTestMessage.isPending || !selectedRecipientId || !testMessage.trim()}
              className="w-full"
            >
              <Send className="h-4 w-4 mr-2" />
              {sendTestMessage.isPending ? 'Sending...' : 'Send Test Message'}
            </Button>
          </div>
          
          <div className="space-y-3">
            <label className="text-sm font-medium">Test Browser Notifications</label>
            <div className="p-4 bg-white rounded-lg border">
              <p className="text-sm text-gray-600 mb-3">
                Test if browser notifications are working properly on this device.
              </p>
              <Button 
                onClick={testBrowserNotification}
                variant="outline"
                className="w-full"
              >
                <MessageCircle className="h-4 w-4 mr-2" />
                Test Browser Notification
              </Button>
            </div>
            
            <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
              <p className="text-xs text-blue-800">
                <strong>Notification Permission:</strong> {
                  'Notification' in window ? Notification.permission : 'Not supported'
                }
              </p>
            </div>
          </div>
        </div>
        
        <div className="p-3 bg-yellow-50 rounded-lg border border-yellow-200">
          <p className="text-xs text-yellow-800">
            <strong>How to test:</strong> Send a message to a sitter account. They should receive:
            1) Toast notification in app, 2) Browser notification popup, 3) Notification sound
          </p>
        </div>
      </CardContent>
    </Card>
  );
}