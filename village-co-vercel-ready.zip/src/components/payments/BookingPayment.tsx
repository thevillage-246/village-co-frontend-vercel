import { useState, useEffect } from "react";
import { useStripe, useElements, PaymentElement } from "@stripe/react-stripe-js";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { CreditCard, Clock, Shield, AlertCircle, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface PaymentCalculation {
  subtotal: number;
  platformFee: number;
  totalAmount: number;
  sitterEarnings: number;
}

interface BookingPaymentProps {
  sitterId: number;
  sitterName: string;
  hourlyRate: number;
  hours: number;
  additionalFees?: number;
  bookingData: any;
  onPaymentSuccess: (bookingId: number) => void;
  onCancel: () => void;
}

export default function BookingPayment({
  sitterId,
  sitterName,
  hourlyRate,
  hours,
  additionalFees = 0,
  bookingData,
  onPaymentSuccess,
  onCancel
}: BookingPaymentProps) {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  
  const [isLoading, setIsLoading] = useState(false);
  const [clientSecret, setClientSecret] = useState<string>("");
  const [calculation, setCalculation] = useState<PaymentCalculation | null>(null);
  const [paymentIntentId, setPaymentIntentId] = useState<string>("");

  useEffect(() => {
    createPaymentIntent();
  }, []);

  const createPaymentIntent = async () => {
    try {
      setIsLoading(true);
      
      const response = await apiRequest('POST', '/api/payments/create-booking-intent', {
        sitterId,
        hourlyRate,
        hours,
        additionalFees
      });
      
      const data = await response.json();
      
      if (data.success) {
        setClientSecret(data.clientSecret);
        setCalculation(data.calculation);
        setPaymentIntentId(data.paymentIntentId);
      } else {
        throw new Error(data.message || 'Failed to create payment intent');
      }
    } catch (error: any) {
      console.error('Payment intent creation failed:', error);
      toast({
        title: "Payment Setup Failed",
        description: error.message || "Unable to setup payment. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = async (event: React.FormEvent) => {
    event.preventDefault();

    if (!stripe || !elements || !clientSecret) {
      return;
    }

    setIsLoading(true);

    try {
      // Confirm payment with Stripe
      const { error, paymentIntent } = await stripe.confirmPayment({
        elements,
        redirect: "if_required"
      });

      if (error) {
        throw new Error(error.message || 'Payment confirmation failed');
      }

      if (paymentIntent.status === 'succeeded') {
        // Process successful payment and create booking
        const response = await apiRequest('POST', '/api/payments/confirm-booking', {
          paymentIntentId: paymentIntent.id,
          bookingData
        });
        
        const data = await response.json();
        
        if (data.success) {
          toast({
            title: "Payment Successful",
            description: "Your booking has been confirmed and payment processed."
          });
          onPaymentSuccess(data.bookingId);
        } else {
          throw new Error(data.message || 'Failed to create booking');
        }
      }
    } catch (error: any) {
      console.error('Payment processing failed:', error);
      toast({
        title: "Payment Failed",
        description: error.message || "Payment could not be processed. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  if (!clientSecret || !calculation) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center space-x-2">
            <div className="animate-spin w-6 h-6 border-4 border-wine border-t-transparent rounded-full" />
            <span className="text-taupe">Setting up payment...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Booking Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CreditCard className="h-5 w-5 text-wine" />
            Booking Payment
          </CardTitle>
          <CardDescription>
            Complete your payment to confirm booking with {sitterName}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Booking Details */}
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Sitter</span>
              <span className="font-medium">{sitterName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Rate</span>
              <span>${hourlyRate}/hour</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Duration</span>
              <span>{hours} hours</span>
            </div>
            {additionalFees > 0 && (
              <div className="flex justify-between">
                <span className="text-muted-foreground">Additional fees</span>
                <span>${additionalFees.toFixed(2)}</span>
              </div>
            )}
          </div>

          <Separator />

          {/* Payment Breakdown */}
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Subtotal</span>
              <span>${calculation.subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Platform fee</span>
              <span>${calculation.platformFee.toFixed(2)}</span>
            </div>
            <div className="flex justify-between font-semibold text-lg">
              <span>Total</span>
              <span>${calculation.totalAmount.toFixed(2)} NZD</span>
            </div>
          </div>

          {/* Trust Indicators */}
          <Alert>
            <Shield className="h-4 w-4" />
            <AlertDescription>
              Secure payment processing by Stripe. Your payment information is encrypted and protected.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      {/* Payment Form */}
      <Card>
        <CardHeader>
          <CardTitle>Payment Details</CardTitle>
          <CardDescription>
            Enter your payment information to complete the booking
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <PaymentElement />
            
            {/* Cancellation Policy */}
            <div className="bg-linen p-4 rounded-lg">
              <h4 className="font-medium mb-2 flex items-center gap-2">
                <Clock className="h-4 w-4 text-wine" />
                Cancellation Policy
              </h4>
              <div className="text-sm text-taupe space-y-1">
                <p>• Full refund: 24+ hours before booking start</p>
                <p>• 50% refund: 4-24 hours before booking start</p>
                <p>• No refund: Less than 4 hours before booking start</p>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={onCancel}
                disabled={isLoading}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={!stripe || isLoading}
                className="flex-1 bg-wine hover:bg-wine/90"
              >
                {isLoading ? (
                  <>
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2" />
                    Processing...
                  </>
                ) : (
                  <>
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Pay ${calculation.totalAmount.toFixed(2)}
                  </>
                )}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Additional Information */}
      <div className="text-center text-sm text-muted-foreground">
        <p>By completing this payment, you agree to our Terms of Service and confirm this booking.</p>
        <p className="mt-1">Questions? Contact support at support@ittakesavillage.nz</p>
      </div>
    </div>
  );
}