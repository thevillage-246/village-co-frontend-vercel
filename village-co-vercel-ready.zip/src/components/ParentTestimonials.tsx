import React, { useState, useRef, useEffect } from 'react';

const testimonials = [
  {
    quote: "Nicci was absolutely amazing! We will definitely book her again. The boys had a great time and we had a great break!",
    name: "Ellen",
    image: "/images/testimonials/parent1.avif",
  },
  {
    quote: "Niamh was excellent. Quickly built a rapport with the kids and put them at ease. Communicated perfectly both before and during the night. We had a great night out and look forward to using the service again soon.",
    name: "Jamie",
    image: "/images/testimonials/parent2.avif",
  },
  {
    quote: "Shavaughn was punctual, had an instant easy rapport with our tama and even though he had never been babysat by someone he had not met before, he was happy to stay with her (no clinging as we left) and has asked when he can have Shavaughn babysit again. A total success! Thank you Shavaughn.",
    name: "Angela",
    image: "/images/testimonials/parent3.avif",
  },
];

export default function ParentTestimonials() {
  const [current, setCurrent] = useState(0);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [isPaused, setIsPaused] = useState(false);

  // Auto-scroll every 5 seconds
  useEffect(() => {
    if (isPaused) return;
    
    const interval = setInterval(() => {
      setCurrent((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    
    return () => clearInterval(interval);
  }, [isPaused]);

  // Update scroll position when current changes
  useEffect(() => {
    if (scrollRef.current) {
      const cardWidth = scrollRef.current.scrollWidth / testimonials.length;
      scrollRef.current.scrollTo({
        left: cardWidth * current,
        behavior: 'smooth',
      });
    }
  }, [current]);

  // Function to detect which testimonial is most visible
  const updateCurrentTestimonial = () => {
    if (!scrollRef.current) return;
    
    const scrollContainer = scrollRef.current;
    const scrollLeft = scrollContainer.scrollLeft;
    
    // Calculate which testimonial is most visible based on scroll position
    const itemWidth = scrollContainer.scrollWidth / testimonials.length;
    const newIndex = Math.round(scrollLeft / itemWidth);
    
    // Ensure index is within bounds
    if (newIndex >= 0 && newIndex < testimonials.length && newIndex !== current) {
      setCurrent(newIndex);
    }
  };

  useEffect(() => {
    const scrollContainer = scrollRef.current;
    if (!scrollContainer) return;
    
    let timeoutId: ReturnType<typeof setTimeout>;
    
    // Add scroll event listener
    const handleScroll = () => {
      updateCurrentTestimonial();
      // Pause auto-scroll when user is manually scrolling
      setIsPaused(true);
      
      // Clear previous timeout to prevent multiple timeouts
      clearTimeout(timeoutId);
      
      // Resume auto-scroll after 10 seconds of inactivity
      timeoutId = setTimeout(() => {
        setIsPaused(false);
      }, 10000);
    };
    
    scrollContainer.addEventListener('scroll', handleScroll);
    
    // Clean up
    return () => {
      scrollContainer.removeEventListener('scroll', handleScroll);
      clearTimeout(timeoutId);
    };
  }, [current]);

  // For managing timeout in click handler
  const resumeTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  
  // Scroll to a specific testimonial when clicking on an indicator
  const scrollToTestimonial = (index: number) => {
    if (!scrollRef.current) return;
    
    setIsPaused(true); // Pause auto-scroll when clicking
    
    const itemWidth = scrollRef.current.scrollWidth / testimonials.length;
    scrollRef.current.scrollTo({
      left: itemWidth * index,
      behavior: 'smooth'
    });
    setCurrent(index);
    
    // Clear any existing timeout
    if (resumeTimeoutRef.current) {
      clearTimeout(resumeTimeoutRef.current);
    }
    
    // Resume auto-scroll after 10 seconds
    resumeTimeoutRef.current = setTimeout(() => {
      setIsPaused(false);
      resumeTimeoutRef.current = null;
    }, 10000);
  };

  return (
    <section className="bg-[#fff8f6] py-12 px-6 text-center">
      <h2 className="text-3xl font-bold text-[#6B3E4B] mb-6">Real Parents, Real Relief</h2>
      <p className="text-lg text-gray-700 mb-10">What mums say after getting their time back:</p>

      <div 
        ref={scrollRef}
        className="flex overflow-x-auto space-x-6 snap-x scroll-smooth"
      >
        {testimonials.map((t, idx) => (
          <div key={idx} className="snap-center min-w-[300px] max-w-[300px] bg-white p-6 rounded shadow">
            <img
              src={t.image}
              alt={t.name}
              className="w-20 h-20 rounded-full mx-auto mb-4 object-cover"
            />
            <p className="text-gray-700 italic mb-3">"{t.quote}"</p>
            <p className="text-sm font-medium text-[#6B3E4B]">{t.name}</p>
          </div>
        ))}
      </div>

      <div className="flex justify-center mt-4 space-x-2">
        {testimonials.map((_, i) => (
          <button
            key={i}
            onClick={() => scrollToTestimonial(i)}
            className={`h-2 w-2 rounded-full ${i === current ? 'bg-[#6B3E4B]' : 'bg-gray-300'}`}
            aria-label={`View testimonial ${i + 1}`}
          />
        ))}
      </div>
    </section>
  );
}