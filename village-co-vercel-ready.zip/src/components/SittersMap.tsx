import React, { useEffect, useRef, useState } from 'react';
import { initializeGoogleMaps, calculateDistance } from '@/lib/googleMaps';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Star, User, MapPin } from 'lucide-react';

interface SitterWithLocation {
  id: number;
  firstName?: string;
  lastName?: string;
  full_name?: string;
  bio: string;
  hourlyRate: number;
  rating: number;
  reviewCount: number;
  photoUrl?: string;
  skills?: Array<{ name: string }>;
  lat?: number;
  lng?: number;
  address?: string;
}

interface SittersMapProps {
  sitters: SitterWithLocation[];
  center?: { lat: number; lng: number };
  onSitterSelect?: (sitter: SitterWithLocation) => void;
  className?: string;
}

export const SittersMap: React.FC<SittersMapProps> = ({
  sitters,
  center = { lat: -37.7870, lng: 175.2793 }, // Hamilton, NZ default
  onSitterSelect,
  className = "h-96"
}) => {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<google.maps.Marker[]>([]);
  const infoWindowRef = useRef<google.maps.InfoWindow | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Generate realistic New Zealand locations for sitters
  const generateSitterLocations = (sitters: SitterWithLocation[]): SitterWithLocation[] => {
    const nzLocations = [
      { lat: -37.7870, lng: 175.2793, address: "Hamilton Central, Hamilton" },
      { lat: -37.7749, lng: 175.2834, address: "Frankton, Hamilton" },
      { lat: -37.8014, lng: 175.2680, address: "Hillcrest, Hamilton" },
      { lat: -37.7692, lng: 175.2889, address: "The Base, Hamilton" },
      { lat: -37.7956, lng: 175.3089, address: "Rototuna, Hamilton" },
      { lat: -37.7445, lng: 175.3123, address: "Chartwell, Hamilton" },
      { lat: -37.8245, lng: 175.2456, address: "Dinsdale, Hamilton" },
      { lat: -37.7634, lng: 175.2567, address: "Hamilton Lake, Hamilton" },
      { lat: -37.7589, lng: 175.2945, address: "Glenview, Hamilton" },
      { lat: -37.8125, lng: 175.2834, address: "Temple View, Hamilton" },
      { lat: -37.7723, lng: 175.3156, address: "Fairview Downs, Hamilton" },
      { lat: -37.8056, lng: 175.2511, address: "Melville, Hamilton" },
      { lat: -37.7834, lng: 175.2612, address: "Forest Lake, Hamilton" },
      { lat: -37.7912, lng: 175.2945, address: "Claudelands, Hamilton" },
      { lat: -37.7723, lng: 175.2689, address: "Enderley, Hamilton" },
    ];

    return sitters.map((sitter, index) => ({
      ...sitter,
      ...nzLocations[index % nzLocations.length]
    }));
  };

  useEffect(() => {
    const initMap = async () => {
      try {
        setIsLoading(true);
        await initializeGoogleMaps();

        if (mapRef.current && !mapInstanceRef.current) {
          // Initialize map centered on Hamilton, NZ
          mapInstanceRef.current = new google.maps.Map(mapRef.current, {
            center,
            zoom: 12,
            styles: [
              {
                featureType: "poi",
                elementType: "labels",
                stylers: [{ visibility: "off" }]
              }
            ],
            mapTypeControl: false,
            streetViewControl: false,
            fullscreenControl: false,
          });

          infoWindowRef.current = new google.maps.InfoWindow();
        }
        setError(null);
      } catch (err) {
        console.error('Failed to initialize map:', err);
        setError('Failed to load map');
      } finally {
        setIsLoading(false);
      }
    };

    initMap();
  }, [center]);

  useEffect(() => {
    // Wait for both map and sitters to be ready
    if (!mapInstanceRef.current || !sitters.length || isLoading) {
      console.log('Map not ready or no sitters:', { 
        mapReady: !!mapInstanceRef.current, 
        sittersCount: sitters.length,
        isLoading: isLoading
      });
      return;
    }

    // Add a small delay to ensure the map is fully rendered
    const createMarkersTimer = setTimeout(() => {
      if (!mapInstanceRef.current) return;

      // Clear existing markers
      markersRef.current.forEach(marker => marker.setMap(null));
      markersRef.current = [];

      // Add sitter locations if not provided
      const sittersWithLocations = generateSitterLocations(sitters);
      console.log('Creating markers for sitters:', sittersWithLocations.length);

      // Create markers for each sitter
      sittersWithLocations.forEach((sitter, index) => {
      if (!sitter.lat || !sitter.lng) {
        console.log('Skipping sitter without location:', sitter.id, sitter.firstName);
        return;
      }

      const firstName = sitter.full_name ? sitter.full_name.split(' ')[0] : sitter.firstName || 'Sitter';
      console.log(`Creating marker ${index + 1} for ${firstName} at`, sitter.lat, sitter.lng);

      const marker = new google.maps.Marker({
        position: { lat: sitter.lat, lng: sitter.lng },
        map: mapInstanceRef.current,
        title: firstName,
        icon: sitter.photoUrl ? {
          url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
            <svg width="50" height="50" viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <clipPath id="circle-${sitter.id}">
                  <circle cx="25" cy="25" r="20"/>
                </clipPath>
              </defs>
              <circle cx="25" cy="25" r="23" fill="#8B4B5C" stroke="white" stroke-width="4"/>
              <image href="${sitter.photoUrl}" x="5" y="5" width="40" height="40" clip-path="url(#circle-${sitter.id})" preserveAspectRatio="xMidYMid slice"/>
            </svg>
          `),
          scaledSize: new google.maps.Size(50, 50),
          anchor: new google.maps.Point(25, 25)
        } : {
          url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
            <svg width="50" height="50" viewBox="0 0 50 50" xmlns="http://www.w3.org/2000/svg">
              <circle cx="25" cy="25" r="23" fill="#8B4B5C" stroke="white" stroke-width="4"/>
            </svg>
          `),
          scaledSize: new google.maps.Size(50, 50),
          anchor: new google.maps.Point(25, 25)
        }
      });

      // Create info window content
      const infoContent = `
        <div class="p-2 max-w-xs">
          <div class="flex items-center gap-2 mb-2">
            <div class="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center">
              <svg class="w-4 h-4 text-gray-600" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd"></path>
              </svg>
            </div>
            <div>
              <h3 class="font-semibold text-sm">${firstName}</h3>
              <div class="flex items-center gap-1">
                <svg class="w-3 h-3 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                </svg>
                <span class="text-xs text-gray-600">${sitter.rating} (${sitter.reviewCount})</span>
              </div>
            </div>
          </div>
          <p class="text-xs text-gray-700 mb-2">${sitter.bio.substring(0, 100)}...</p>
          <div class="flex items-center justify-between">
            <span class="text-sm font-semibold text-[#8B5A3C]">$${sitter.hourlyRate}/hr</span>
            <button onclick="window.selectSitter && window.selectSitter(${sitter.id})" class="text-xs bg-[#8B5A3C] text-white px-2 py-1 rounded hover:bg-[#7A4D35]">
              View Profile
            </button>
          </div>
        </div>
      `;

      marker.addListener('click', () => {
        if (infoWindowRef.current) {
          infoWindowRef.current.setContent(infoContent);
          infoWindowRef.current.open(mapInstanceRef.current, marker);
        }
      });

      markersRef.current.push(marker);
    });

    console.log(`Successfully created ${markersRef.current.length} markers on the map`);

      // Expose sitter selection to global scope for info window buttons
      (window as any).selectSitter = (sitterId: number) => {
        const sitter = sittersWithLocations.find(s => s.id === sitterId);
        if (sitter && onSitterSelect) {
          onSitterSelect(sitter);
        }
      };
    }, 500); // 500ms delay to ensure map is fully loaded

    return () => {
      clearTimeout(createMarkersTimer);
    };

  }, [sitters, onSitterSelect, isLoading]);

  if (error) {
    return (
      <Card className={className}>
        <CardContent className="flex items-center justify-center h-full">
          <div className="text-center">
            <MapPin className="h-8 w-8 text-gray-400 mx-auto mb-2" />
            <p className="text-gray-600">Map unavailable</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className={`relative ${className}`}>
      {isLoading && (
        <div className="absolute inset-0 bg-white bg-opacity-75 flex items-center justify-center z-10">
          <div className="text-center">
            <div className="animate-spin w-6 h-6 border-2 border-[#8B5A3C] border-t-transparent rounded-full mx-auto mb-2"></div>
            <p className="text-sm text-gray-600">Loading map...</p>
          </div>
        </div>
      )}
      <div ref={mapRef} className="w-full h-full rounded-lg overflow-hidden" />
      
      {/* Map legend */}
      <div className="absolute bottom-4 left-4 bg-white rounded-lg shadow-lg p-3 text-xs">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 bg-[#8B5A3C] rounded-full flex items-center justify-center">
            <User className="w-2 h-2 text-white" />
          </div>
          <span>Available Sitters</span>
        </div>
      </div>
    </div>
  );
};