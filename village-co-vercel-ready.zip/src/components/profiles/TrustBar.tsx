import React from 'react';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, Award, Heart, Shield } from 'lucide-react';

interface TrustBarProps {
  verified?: boolean;
  firstAid?: boolean;
  valuesAligned?: boolean;
  background?: boolean;
  superSitter?: boolean;
}

export function TrustBar({
  verified = false,
  firstAid = false,
  valuesAligned = false,
  background = false,
  superSitter = false
}: TrustBarProps) {
  return (
    <div className="flex flex-wrap gap-2 mt-4 text-sm">
      {verified && (
        <Badge variant="outline" className="bg-green-50 text-green-800 hover:bg-green-100 border-green-200 px-2.5 py-1 flex items-center gap-1">
          <CheckCircle2 className="h-3.5 w-3.5" />
          <span>ID Verified</span>
        </Badge>
      )}
      
      {firstAid && (
        <Badge variant="outline" className="bg-rose-50 text-rose-800 hover:bg-rose-100 border-rose-200 px-2.5 py-1 flex items-center gap-1">
          <Shield className="h-3.5 w-3.5" />
          <span>First Aid Certified</span>
        </Badge>
      )}
      
      {valuesAligned && (
        <Badge variant="outline" className="bg-blue-50 text-blue-800 hover:bg-blue-100 border-blue-200 px-2.5 py-1 flex items-center gap-1">
          <Heart className="h-3.5 w-3.5" />
          <span>Values Aligned</span>
        </Badge>
      )}
      
      {background && (
        <Badge variant="outline" className="bg-purple-50 text-purple-800 hover:bg-purple-100 border-purple-200 px-2.5 py-1 flex items-center gap-1">
          <CheckCircle2 className="h-3.5 w-3.5" />
          <span>Background Checked</span>
        </Badge>
      )}
      
      {superSitter && (
        <Badge variant="outline" className="bg-amber-50 text-amber-800 hover:bg-amber-100 border-amber-200 px-2.5 py-1 flex items-center gap-1">
          <Award className="h-3.5 w-3.5" />
          <span>Super Sitter</span>
        </Badge>
      )}
    </div>
  );
}