import React, { useRef, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Award, Plus, ArrowLeft, ArrowRight, Check, Clock, X } from 'lucide-react';
import type { SitterOnboardingData } from '@/pages/SitterOnboarding';

const step3Schema = z.object({
  qualifications: z.array(z.string()).optional(),
});

type Step3FormData = z.infer<typeof step3Schema>;

interface SitterOnboardingStep3Props {
  data: SitterOnboardingData;
  updateData: (data: Partial<SitterOnboardingData>) => void;
  onNext: () => void;
  onBack: () => void;
}

export default function SitterOnboardingStep3({ data, updateData, onNext, onBack }: SitterOnboardingStep3Props) {
  const [selectedQualifications, setSelectedQualifications] = useState<string[]>(data.qualifications || []);

  const form = useForm<Step3FormData>({
    resolver: zodResolver(step3Schema),
    defaultValues: {
      qualifications: data.qualifications || [],
    },
  });

  const qualificationOptions = [
    // Health & Safety
    { key: 'first_aid_certified', displayName: 'First Aid Certified', emoji: '🩹', category: 'Health & Safety' },
    { key: 'cpr_certified', displayName: 'CPR Certified', emoji: '❤️', category: 'Health & Safety' },
    { key: 'police_check', displayName: 'Police Background Check', emoji: '🛡️', category: 'Health & Safety' },
    { key: 'child_protection', displayName: 'Child Protection Training', emoji: '🔒', category: 'Health & Safety' },
    
    // Education & Experience
    { key: 'early_childhood', displayName: 'Early Childhood Education', emoji: '🎓', category: 'Education' },
    { key: 'teaching_degree', displayName: 'Teaching Degree', emoji: '📚', category: 'Education' },
    { key: 'montessori', displayName: 'Montessori Training', emoji: '🧩', category: 'Education' },
    { key: 'special_needs', displayName: 'Special Needs Training', emoji: '🌟', category: 'Education' },
    
    // Additional Skills
    { key: 'swimming_instructor', displayName: 'Swimming Instructor', emoji: '🏊', category: 'Skills' },
    { key: 'music_education', displayName: 'Music Education', emoji: '🎵', category: 'Skills' },
    { key: 'multilingual', displayName: 'Multilingual', emoji: '🌍', category: 'Skills' },
    { key: 'cooking', displayName: 'Cooking & Nutrition', emoji: '👨‍🍳', category: 'Skills' },
  ];

  const handleQualificationToggle = (qualKey: string) => {
    const newQualifications = selectedQualifications.includes(qualKey)
      ? selectedQualifications.filter(q => q !== qualKey)
      : [...selectedQualifications, qualKey];
    
    setSelectedQualifications(newQualifications);
    updateData({ qualifications: newQualifications });
  };

  const onSubmit = () => {
    updateData({ qualifications: selectedQualifications });
    onNext();
  };

  const categoryLabels = {
    'Health & Safety': 'Health & Safety',
    'Education': 'Education & Experience',
    'Skills': 'Additional Skills'
  };

  const groupedQualifications = qualificationOptions.reduce((acc, qual) => {
    if (!acc[qual.category]) {
      acc[qual.category] = [];
    }
    acc[qual.category].push(qual);
    return acc;
  }, {} as Record<string, typeof qualificationOptions>);

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 border border-brushed-pink/20">
      {/* Header */}
      <div className="text-center mb-8">
        <div className="flex justify-center mb-4">
          <div className="bg-gradient-to-br from-village-wine to-rose p-3 rounded-full">
            <Award className="h-8 w-8 text-white" />
          </div>
        </div>
        <h1 className="text-3xl font-bold text-village-wine mb-2">
          Show Your Qualifications
        </h1>
        <p className="text-lg text-taupe leading-relaxed max-w-md mx-auto">
          What makes you amazing with kids?
        </p>
        <p className="text-base text-gray-600 mt-4 max-w-lg mx-auto">
          Select any qualifications, certifications or special skills you have. This helps parents understand your experience and builds trust. You can always add more later.
        </p>
      </div>

      {/* Qualifications Grid */}
      <div className="space-y-8">
        {Object.entries(groupedQualifications).map(([category, qualifications]) => (
          <div key={category}>
            <h3 className="font-semibold text-village-wine text-lg mb-4">
              {categoryLabels[category as keyof typeof categoryLabels]}
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {qualifications.map((qual) => (
                <button
                  key={qual.key}
                  type="button"
                  onClick={() => handleQualificationToggle(qual.key)}
                  className={`p-4 rounded-xl border-2 text-left transition-all duration-200 ${
                    selectedQualifications.includes(qual.key)
                      ? 'border-village-wine bg-village-wine/5 shadow-md'
                      : 'border-gray-200 hover:border-village-wine/50 hover:bg-gray-50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <span className="text-xl">{qual.emoji}</span>
                      <div>
                        <div className="font-medium text-village-wine">
                          {qual.displayName}
                        </div>
                      </div>
                    </div>
                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                      selectedQualifications.includes(qual.key)
                        ? 'border-village-wine bg-village-wine'
                        : 'border-gray-300'
                    }`}>
                      {selectedQualifications.includes(qual.key) && (
                        <Check className="w-3 h-3 text-white" />
                      )}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Selected Qualifications Summary */}
      {selectedQualifications.length > 0 && (
        <div className="mt-8 p-6 bg-village-wine/5 rounded-xl border border-village-wine/20">
          <h4 className="font-semibold text-village-wine mb-3">
            Selected Qualifications ({selectedQualifications.length})
          </h4>
          <div className="flex flex-wrap gap-2">
            {selectedQualifications.map((qualKey) => {
              const qual = qualificationOptions.find(q => q.key === qualKey);
              return qual ? (
                <span
                  key={qualKey}
                  className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-village-wine text-white"
                >
                  <span className="mr-1">{qual.emoji}</span>
                  {qual.displayName}
                </span>
              ) : null;
            })}
          </div>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex gap-4 pt-8">
        <Button
          type="button"
          variant="outline"
          onClick={onBack}
          className="flex-1 h-12 border-2 border-gray-300 text-gray-600 hover:bg-gray-50 rounded-xl"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back
        </Button>
        <Button 
          type="button"
          onClick={onSubmit}
          className="flex-1 h-12 bg-gradient-to-r from-village-wine to-rose hover:from-village-wine/90 hover:to-rose/90 text-white font-semibold rounded-xl transition-all duration-300"
        >
          Continue
          <ArrowRight className="ml-2 h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}