import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowRight, Heart, Clock, Calendar, Repeat } from "lucide-react";

interface OnboardingStep1Props {
  data: {
    firstName?: string;
    email?: string;
    phoneNumber?: string;
    city?: string;
    suburb?: string;
    careNeeds?: string[];
  };
  updateData: (data: any) => void;
  onNext: () => void;
}

const careNeedsOptions = [
  {
    id: "date-night",
    label: "Date night",
    description: "Evening babysitting for parents' time out",
    icon: Heart,
    color: "text-village-rose"
  },
  {
    id: "after-school",
    label: "After school",
    description: "Pickup and care until parents return",
    icon: Clock,
    color: "text-village-eucalyptus"
  },
  {
    id: "weekends",
    label: "Weekends",
    description: "Saturday and Sunday childcare",
    icon: Calendar,
    color: "text-village-wine"
  },
  {
    id: "ongoing-care",
    label: "Ongoing care",
    description: "Regular weekly or monthly arrangements",
    icon: Repeat,
    color: "text-village-taupe"
  }
];

const newZealandCities = [
  "Auckland", "Wellington", "Christchurch", "Hamilton", "Tauranga",
  "Napier-Hastings", "Dunedin", "Palmerston North", "Nelson", "Rotorua",
  "New Plymouth", "Whangarei", "Invercargill", "Whanganui", "Gisborne",
  "Kapiti Coast", "Upper Hutt", "Lower Hutt", "Porirua", "Masterton",
  "Blenheim", "Timaru", "Oamaru", "Queenstown", "Greymouth", "Westport",
  "Thames", "Taupo", "Tokoroa", "Te Awamutu", "Cambridge", "Morrinsville",
  "Huntly", "Pukekohe", "Papakura", "Manukau", "North Shore", "Waitakere"
];

export default function OnboardingStep1New({ data, updateData, onNext }: OnboardingStep1Props) {
  const firstName = data.firstName || '';
  const email = data.email || '';
  const phoneNumber = data.phoneNumber || '';
  const city = data.city || data.suburb || '';
  const careNeeds = data.careNeeds || [];

  const isValid = firstName.trim() !== '' && 
                  email.includes('@') && 
                  phoneNumber.trim() !== '' &&
                  city !== '' &&
                  careNeeds.length > 0;

  const handleInputChange = (field: string, value: string) => {
    updateData({ [field]: value });
  };

  const handleCareNeedClick = (careNeedId: string) => {
    const newCareNeeds = careNeeds.includes(careNeedId)
      ? careNeeds.filter(need => need !== careNeedId)
      : [...careNeeds, careNeedId];
    
    updateData({ careNeeds: newCareNeeds });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isValid) {
      onNext();
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Personal Information */}
      <div className="grid md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="firstName" className="text-village-wine font-medium">
            First Name *
          </Label>
          <Input
            id="firstName"
            type="text"
            value={firstName}
            onChange={(e) => handleInputChange('firstName', e.target.value)}
            placeholder="What should we call you?"
            className="border-village-wine/30 focus:border-village-wine"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="email" className="text-village-wine font-medium">
            Email Address *
          </Label>
          <Input
            id="email"
            type="email"
            value={email}
            onChange={(e) => handleInputChange('email', e.target.value)}
            placeholder="your@email.com"
            className="border-village-wine/30 focus:border-village-wine"
            required
          />
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="space-y-2">
          <Label htmlFor="phoneNumber" className="text-village-wine font-medium">
            Phone Number *
          </Label>
          <Input
            id="phoneNumber"
            type="tel"
            value={phoneNumber}
            onChange={(e) => handleInputChange('phoneNumber', e.target.value)}
            placeholder="+64 21 123 4567"
            className="border-village-wine/30 focus:border-village-wine"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="city" className="text-village-wine font-medium">
            City *
          </Label>
          <select
            id="city"
            value={city}
            onChange={(e) => handleInputChange('city', e.target.value)}
            className="w-full px-3 py-2 border border-village-wine/30 rounded-md focus:border-village-wine focus:outline-none focus:ring-1 focus:ring-village-wine/20"
            required
          >
            <option value="">Select your city</option>
            {newZealandCities.map(cityName => (
              <option key={cityName} value={cityName}>{cityName}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Care Needs Selection */}
      <div className="space-y-4">
        <div>
          <Label className="text-village-wine font-medium text-lg">
            What do you need help with? *
          </Label>
          <p className="text-village-taupe/70 text-sm mt-1">
            Select all that apply to help us match you with the right sitters
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          {careNeedsOptions.map((option) => {
            const Icon = option.icon;
            const isSelected = careNeeds.includes(option.id);
            
            return (
              <Card 
                key={option.id} 
                className={`cursor-pointer transition-all duration-200 hover:shadow-md ${
                  isSelected 
                    ? 'ring-2 ring-village-wine bg-village-wine/5 border-village-wine' 
                    : 'border-village-wine/20 hover:border-village-wine/40'
                }`}
                onClick={() => handleCareNeedClick(option.id)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className={`w-5 h-5 rounded border-2 mt-1 flex items-center justify-center ${
                      isSelected 
                        ? 'border-village-wine bg-village-wine' 
                        : 'border-village-wine/30'
                    }`}>
                      {isSelected && (
                        <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                      )}
                    </div>
                    <Icon className={`w-5 h-5 mt-1 ${option.color}`} />
                    <div className="flex-1">
                      <h3 className="font-medium text-village-wine mb-1">
                        {option.label}
                      </h3>
                      <p className="text-sm text-village-taupe/70">
                        {option.description}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Submit Button */}
      <div className="pt-6">
        <Button
          type="submit"
          disabled={!isValid}
          className="w-full bg-village-wine hover:bg-village-wine/90 text-white font-medium py-3 text-lg"
        >
          Next: Meet Sitters
          <ArrowRight className="w-5 h-5 ml-2" />
        </Button>
        
        {!isValid && (
          <p className="text-sm text-village-taupe/60 text-center mt-2">
            Please fill in all required fields and select at least one care need
          </p>
        )}
      </div>
    </form>
  );
}