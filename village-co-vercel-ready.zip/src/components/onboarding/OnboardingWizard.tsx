import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { USER_ROLES } from '@shared/schema';
import { CheckCircle, ChevronRight, ChevronLeft, UserCircle, Mail, Phone, MapPin, BriefcaseMedical, Calendar, Heart, ShieldCheck } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { Confetti } from '@/components/ui/confetti';
import VeriffVerification from '@/components/sitters/VeriffVerification';
import ParentVerificationStep from '@/components/onboarding/ParentVerificationStep';

// Define steps that apply to all user types
const commonSteps = [
  { id: 'profile', title: 'Basic Profile', icon: UserCircle },
  { id: 'contact', title: 'Contact Info', icon: Mail },
  { id: 'photo', title: 'Profile Picture', icon: UserCircle },
];

// Define role-specific steps
const roleSpecificSteps = {
  [USER_ROLES.PARENT]: [
    { id: 'children', title: 'Children Info', icon: Heart },
    { id: 'emergency', title: 'Emergency Contacts', icon: Phone },
    { id: 'verification', title: 'ID Verification', icon: ShieldCheck },
    { id: 'preferences', title: 'Care Preferences', icon: BriefcaseMedical },
  ],
  [USER_ROLES.SITTER]: [
    { id: 'availability', title: 'Availability', icon: Calendar },
    { id: 'verification', title: 'ID Verification', icon: ShieldCheck },
    { id: 'experience', title: 'Experience & Skills', icon: BriefcaseMedical },
    { id: 'location', title: 'Service Area', icon: MapPin },
  ],
  [USER_ROLES.ADMIN]: [
    { id: 'permissions', title: 'Access Level', icon: ShieldCheck },
  ],
};

interface OnboardingWizardProps {
  onComplete?: () => void;
}

export default function OnboardingWizard({ onComplete }: OnboardingWizardProps) {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<string[]>([]);
  const [showConfetti, setShowConfetti] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [userData, setUserData] = useState<any>(null);

  // Get the appropriate steps based on user role
  const getStepsForRole = () => {
    if (!user || !user.role) return commonSteps;
    return [...commonSteps, ...(roleSpecificSteps[user.role as keyof typeof roleSpecificSteps] || [])];
  };

  const steps = getStepsForRole();
  const currentStep = steps[currentStepIndex];
  const progress = completedSteps.length > 0 
    ? Math.round((completedSteps.length / steps.length) * 100) 
    : 0;

  // Fetch user data on component mount
  useEffect(() => {
    const fetchUserData = async () => {
      if (!user) return;
      
      try {
        const { data, error } = await supabase
          .from('user_profiles')
          .select('*')
          .eq('user_id', user.id)
          .single();
        
        if (error) throw error;
        setUserData(data);
        
        // Check completed steps based on user data
        const completed: string[] = [];
        
        if (data.first_name && data.last_name) completed.push('profile');
        if (data.email && data.phone) completed.push('contact');
        if (data.avatar_url) completed.push('photo');
        
        if (user.role === USER_ROLES.PARENT) {
          if (data.children && data.children.length > 0) completed.push('children');
          if (data.emergency_contacts && data.emergency_contacts.length > 0) completed.push('emergency');
          if (data.is_verified) completed.push('verification');
          if (data.care_preferences) completed.push('preferences');
        }
        
        if (user.role === USER_ROLES.SITTER) {
          if (data.availability) completed.push('availability');
          if (data.is_verified) completed.push('verification');
          if (data.experience || data.skills) completed.push('experience');
          if (data.service_area || data.location) completed.push('location');
        }
        
        setCompletedSteps(completed);
        
        // Find the first incomplete step
        for (let i = 0; i < steps.length; i++) {
          if (!completed.includes(steps[i].id)) {
            setCurrentStepIndex(i);
            break;
          }
        }
      } catch (err) {
        console.error('Error fetching user data:', err);
      }
    };
    
    fetchUserData();
  }, [user]);

  const handleNext = () => {
    // In a real implementation, save the data for the current step
    // For this example, we'll just mark the step as completed
    if (!completedSteps.includes(currentStep.id)) {
      setCompletedSteps(prev => [...prev, currentStep.id]);
    }
    
    if (currentStepIndex < steps.length - 1) {
      setCurrentStepIndex(currentStepIndex + 1);
    } else {
      handleComplete();
    }
  };

  const handlePrevious = () => {
    if (currentStepIndex > 0) {
      setCurrentStepIndex(currentStepIndex - 1);
    }
  };

  const handleSkip = () => {
    if (currentStepIndex < steps.length - 1) {
      setCurrentStepIndex(currentStepIndex + 1);
    } else {
      handleComplete();
    }
  };

  const handleComplete = async () => {
    setIsLoading(true);
    
    try {
      // Mark onboarding as complete
      if (!user || !user.id) {
        throw new Error('User not found');
      }
      
      const { error } = await supabase
        .from('user_profiles')
        .update({ onboarding_completed: true, onboarding_completed_at: new Date().toISOString() })
        .eq('user_id', user.id);
      
      if (error) throw error;
      
      // Show completion celebration
      setShowConfetti(true);
      
      toast({
        title: "Onboarding Complete! 🎉",
        description: "Your profile is now set up and ready to go.",
        duration: 5000,
      });
      
      // Redirect based on user role after a short delay
      setTimeout(() => {
        if (onComplete) {
          onComplete();
        } else {
          if (user?.role === USER_ROLES.PARENT) {
            navigate('/find-sitter');
          } else if (user?.role === USER_ROLES.SITTER) {
            navigate('/sitter-dashboard');
          } else {
            navigate('/dashboard');
          }
        }
      }, 3000);
    } catch (err) {
      console.error('Error completing onboarding:', err);
      toast({
        title: "Error",
        description: "There was a problem completing your onboarding. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Render step content based on the current step ID
  const renderStepContent = () => {
    switch (currentStep.id) {
      case 'profile':
        return (
          <div className="space-y-4">
            <p className="text-muted-foreground">
              Tell us about yourself! This information helps us personalize your experience.
            </p>
            <div className="bg-muted/50 p-4 rounded-md">
              <p className="text-sm">This step would include fields for:</p>
              <ul className="list-disc list-inside text-sm mt-2 space-y-1">
                <li>First name</li>
                <li>Last name</li>
                <li>Date of birth</li>
                <li>Short bio</li>
              </ul>
            </div>
          </div>
        );
      case 'contact':
        return (
          <div className="space-y-4">
            <p className="text-muted-foreground">
              How can others reach you? Your contact information is kept private and only shared with approved connections.
            </p>
            <div className="bg-muted/50 p-4 rounded-md">
              <p className="text-sm">This step would include fields for:</p>
              <ul className="list-disc list-inside text-sm mt-2 space-y-1">
                <li>Email address</li>
                <li>Phone number</li>
                <li>Preferred contact method</li>
              </ul>
            </div>
          </div>
        );
      case 'photo':
        return (
          <div className="space-y-4">
            <p className="text-muted-foreground">
              Add a profile photo to help others recognize you. A clear, friendly photo helps build trust.
            </p>
            <div className="bg-muted/50 p-4 rounded-md">
              <p className="text-sm">This step would include:</p>
              <ul className="list-disc list-inside text-sm mt-2 space-y-1">
                <li>Photo upload widget</li>
                <li>Option to take a photo</li>
                <li>Cropping tool</li>
              </ul>
            </div>
          </div>
        );
      case 'children':
        return (
          <div className="space-y-4">
            <p className="text-muted-foreground">
              Tell us about your children so we can match you with the right sitters for their needs.
            </p>
            <div className="bg-muted/50 p-4 rounded-md">
              <p className="text-sm">This step would include fields for each child:</p>
              <ul className="list-disc list-inside text-sm mt-2 space-y-1">
                <li>First name</li>
                <li>Age</li>
                <li>Special needs or considerations</li>
                <li>Allergies</li>
                <li>Interests/hobbies</li>
              </ul>
            </div>
          </div>
        );
      case 'emergency':
        return (
          <div className="space-y-4">
            <p className="text-muted-foreground">
              Emergency contacts are important in case we need to reach someone during a booking.
            </p>
            <div className="bg-muted/50 p-4 rounded-md">
              <p className="text-sm">This step would include fields for:</p>
              <ul className="list-disc list-inside text-sm mt-2 space-y-1">
                <li>Emergency contact name</li>
                <li>Relationship</li>
                <li>Phone number</li>
                <li>Option to add multiple contacts</li>
              </ul>
            </div>
          </div>
        );
      case 'preferences':
        return (
          <div className="space-y-4">
            <p className="text-muted-foreground">
              Let sitters know your preferences for childcare to ensure the best match.
            </p>
            <div className="bg-muted/50 p-4 rounded-md">
              <p className="text-sm">This step would include preferences for:</p>
              <ul className="list-disc list-inside text-sm mt-2 space-y-1">
                <li>Screen time rules</li>
                <li>Dietary restrictions</li>
                <li>Bedtime routines</li>
                <li>Activities you approve/disapprove</li>
                <li>Discipline approaches</li>
              </ul>
            </div>
          </div>
        );
      case 'availability':
        return (
          <div className="space-y-4">
            <p className="text-muted-foreground">
              Set your availability so parents can book you when you're free.
            </p>
            <div className="bg-muted/50 p-4 rounded-md">
              <p className="text-sm">This step would include:</p>
              <ul className="list-disc list-inside text-sm mt-2 space-y-1">
                <li>Weekly schedule selector</li>
                <li>Recurring availability patterns</li>
                <li>Special dates (holidays, etc.)</li>
                <li>Minimum/maximum booking hours</li>
              </ul>
            </div>
          </div>
        );
      case 'verification':
        if (!user) return null;
        
        if (user.role === USER_ROLES.PARENT) {
          return (
            <ParentVerificationStep
              onNext={() => {
                if (!completedSteps.includes(currentStep.id)) {
                  setCompletedSteps(prev => [...prev, currentStep.id]);
                }
                if (currentStepIndex < steps.length - 1) {
                  setCurrentStepIndex(currentStepIndex + 1);
                }
              }}
              onSkip={() => {
                // Allow skipping verification during onboarding
                if (currentStepIndex < steps.length - 1) {
                  setCurrentStepIndex(currentStepIndex + 1);
                }
              }}
            />
          );
        } else {
          return (
            <div className="space-y-4">
              <p className="text-muted-foreground">
                Verify your identity to build trust with parents and unlock more booking opportunities.
              </p>
              <VeriffVerification 
                userId={user.id}
                onComplete={() => {
                  if (!completedSteps.includes(currentStep.id)) {
                    setCompletedSteps(prev => [...prev, currentStep.id]);
                  }
                  if (currentStepIndex < steps.length - 1) {
                    setCurrentStepIndex(currentStepIndex + 1);
                  }
                }}
              />
            </div>
          );
        }
      case 'experience':
        return (
          <div className="space-y-4">
            <p className="text-muted-foreground">
              Share your childcare experience and special skills to stand out to parents.
            </p>
            <div className="bg-muted/50 p-4 rounded-md">
              <p className="text-sm">This step would include fields for:</p>
              <ul className="list-disc list-inside text-sm mt-2 space-y-1">
                <li>Years of childcare experience</li>
                <li>Age groups you've worked with</li>
                <li>Special skills (first aid, languages, arts, sports)</li>
                <li>Certifications</li>
                <li>References</li>
              </ul>
            </div>
          </div>
        );
      case 'location':
        return (
          <div className="space-y-4">
            <p className="text-muted-foreground">
              Set your service area so parents know if you're available in their neighborhood.
            </p>
            <div className="bg-muted/50 p-4 rounded-md">
              <p className="text-sm">This step would include:</p>
              <ul className="list-disc list-inside text-sm mt-2 space-y-1">
                <li>Home location</li>
                <li>Travel radius</li>
                <li>Neighborhoods you serve</li>
                <li>Transportation options</li>
              </ul>
            </div>
          </div>
        );
      default:
        return (
          <div className="text-muted-foreground">
            Complete this step to continue with your onboarding.
          </div>
        );
    }
  };

  if (!user) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Please log in</CardTitle>
          <CardDescription>You need to be logged in to complete the onboarding process.</CardDescription>
        </CardHeader>
        <CardFooter>
          <Button onClick={() => navigate('/login')}>Go to Login</Button>
        </CardFooter>
      </Card>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-3xl">
      {showConfetti && <Confetti />}
      
      <Card className="border-2 border-linen">
        <CardHeader className="pb-4">
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-2xl font-bold text-wine">
                {progress === 100 ? 'All Set!' : `Step ${currentStepIndex + 1} of ${steps.length}`}
              </CardTitle>
              <CardDescription>
                {progress === 100 
                  ? "You've completed all onboarding steps! Your profile is ready." 
                  : `Complete your profile • ${progress}% done`}
              </CardDescription>
            </div>
            <div className="h-12 w-12 rounded-full bg-linen flex items-center justify-center">
              {currentStep && <currentStep.icon className="h-6 w-6 text-wine" />}
            </div>
          </div>
          
          <Progress value={progress} className="mt-4 h-2" />
          
          <div className="flex flex-wrap mt-4 gap-2">
            {steps.map((step, index) => (
              <Button
                key={step.id}
                variant={completedSteps.includes(step.id) ? "default" : "outline"}
                size="sm"
                className={`
                  rounded-full px-3 
                  ${completedSteps.includes(step.id) ? 'bg-wine text-white' : ''} 
                  ${currentStepIndex === index ? 'border-wine text-wine' : ''}
                `}
                onClick={() => setCurrentStepIndex(index)}
              >
                {completedSteps.includes(step.id) && (
                  <CheckCircle className="mr-1 h-3 w-3" />
                )}
                {step.title}
              </Button>
            ))}
          </div>
        </CardHeader>
        
        <CardContent className="pt-4 pb-6">
          <div className="mb-4">
            <h3 className="text-xl font-medium">
              {currentStep ? currentStep.title : 'Complete Your Profile'}
            </h3>
          </div>
          
          {renderStepContent()}
        </CardContent>
        
        <CardFooter className="border-t bg-muted/20 p-4 flex justify-between">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentStepIndex === 0}
            className="gap-1"
          >
            <ChevronLeft className="h-4 w-4" />
            Back
          </Button>
          
          <div className="flex gap-2">
            {currentStepIndex < steps.length - 1 && (
              <Button variant="ghost" onClick={handleSkip}>
                Skip for now
              </Button>
            )}
            
            <Button 
              onClick={progress === 100 ? handleComplete : handleNext}
              className="gap-1 bg-wine hover:bg-wine/90"
              disabled={isLoading}
            >
              {isLoading ? (
                <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full" />
              ) : (
                <>
                  {progress === 100 ? 'Complete' : 'Continue'}
                  <ChevronRight className="h-4 w-4" />
                </>
              )}
            </Button>
          </div>
        </CardFooter>
      </Card>
    </div>
  );
}