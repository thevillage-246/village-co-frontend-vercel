import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { Heart, Baby, Shield, Settings, CheckCircle2 } from "lucide-react";

const childSchema = z.object({
  firstName: z.string().min(2, "First name must be at least 2 characters"),
  lastName: z.string().min(2, "Last name must be at least 2 characters"),
  birthDate: z.string().min(1, "Birth date is required"),
  allergies: z.string().optional(),
  notes: z.string().optional(),
});

const emergencyContactSchema = z.object({
  emergencyContact: z.string().min(2, "Emergency contact name is required"),
  emergencyPhone: z.string().min(10, "Valid phone number is required"),
});

const preferencesSchema = z.object({
  sitterGender: z.string().optional(),
  drivingRequired: z.boolean().optional(),
  timePreference: z.string().optional(),
});

interface ParentOnboardingProps {
  userId: number;
  onComplete: () => void;
}

export default function ParentOnboarding({ userId, onComplete }: ParentOnboardingProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get current parent profile and progress
  const { data: parentProfile } = useQuery({
    queryKey: ["/api/parent-onboarding/progress", userId],
    enabled: !!userId,
  });

  const { data: children = [] } = useQuery({
    queryKey: ["/api/children", userId],
    enabled: !!userId,
  });

  // Calculate progress based on completion
  const getProgress = () => {
    if (!parentProfile) return 0;
    
    const steps = {
      childAdded: !!children.length,
      emergencyContactAdded: !!(parentProfile.emergencyContact && parentProfile.emergencyPhone),
      preferencesSet: !!parentProfile.preferencesSet
    };
    
    const completedSteps = Object.values(steps).filter(Boolean).length;
    return Math.round((completedSteps / 3) * 100);
  };

  // Child form
  const childForm = useForm({
    resolver: zodResolver(childSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      birthDate: "",
      allergies: "",
      notes: "",
    },
  });

  // Emergency contact form
  const emergencyForm = useForm({
    resolver: zodResolver(emergencyContactSchema),
    defaultValues: {
      emergencyContact: parentProfile?.emergencyContact || "",
      emergencyPhone: parentProfile?.emergencyPhone || "",
    },
  });

  // Preferences form
  const preferencesForm = useForm({
    resolver: zodResolver(preferencesSchema),
    defaultValues: {
      sitterGender: "",
      drivingRequired: false,
      timePreference: "",
    },
  });

  // Mutations
  const addChildMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/children", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/children", userId] });
      queryClient.invalidateQueries({ queryKey: ["/api/parent-onboarding/progress", userId] });
      toast({ title: "Child added successfully!" });
      setCurrentStep(2);
    },
    onError: () => {
      toast({ 
        title: "Error", 
        description: "Failed to add child. Please try again.",
        variant: "destructive" 
      });
    },
  });

  const updateEmergencyContactMutation = useMutation({
    mutationFn: (data: any) => apiRequest("PUT", `/api/parents/${userId}/emergency-contact`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/parent-onboarding/progress", userId] });
      toast({ title: "Emergency contact saved!" });
      setCurrentStep(3);
    },
    onError: () => {
      toast({ 
        title: "Error", 
        description: "Failed to save emergency contact. Please try again.",
        variant: "destructive" 
      });
    },
  });

  const updatePreferencesMutation = useMutation({
    mutationFn: (data: any) => apiRequest("PUT", `/api/parents/${userId}/preferences`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/parent-onboarding/progress", userId] });
      toast({ title: "Preferences saved!" });
      setCurrentStep(4);
    },
    onError: () => {
      toast({ 
        title: "Error", 
        description: "Failed to save preferences. Please try again.",
        variant: "destructive" 
      });
    },
  });

  const completeOnboardingMutation = useMutation({
    mutationFn: () => apiRequest("POST", `/api/parent-onboarding/complete`, { userId }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/parent-onboarding/progress", userId] });
      toast({ title: "Welcome to The Village Co.!", description: "Your profile is complete!" });
      onComplete();
    },
  });

  // Form handlers
  const handleAddChild = (data: any) => {
    const birthDate = new Date(data.birthDate);
    addChildMutation.mutate({
      ...data,
      parentId: userId,
      birthDate: birthDate,
    });
  };

  const handleEmergencyContact = (data: any) => {
    updateEmergencyContactMutation.mutate(data);
  };

  const handlePreferences = (data: any) => {
    updatePreferencesMutation.mutate(data);
  };

  const handleComplete = () => {
    completeOnboardingMutation.mutate();
  };

  const progress = getProgress();

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 to-orange-50 p-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome to The Village Co.</h1>
          <p className="text-lg text-gray-600">Your shortcut to trusted sitters and guilt-free breaks.</p>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between text-sm text-gray-600 mb-2">
            <span>Progress</span>
            <span>{progress}% complete</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Step 1: Add Children */}
        {currentStep === 1 && (
          <Card className="mb-6">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-rose-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Baby className="w-8 h-8 text-rose-600" />
              </div>
              <CardTitle>Add Your Children</CardTitle>
              <CardDescription>
                Tell us about your little legends — so your sitter shows up ready.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={childForm.handleSubmit(handleAddChild)} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName">First Name</Label>
                    <Input
                      id="firstName"
                      {...childForm.register("firstName")}
                      placeholder="Enter first name"
                    />
                    {childForm.formState.errors.firstName && (
                      <p className="text-sm text-red-600 mt-1">
                        {childForm.formState.errors.firstName.message}
                      </p>
                    )}
                  </div>
                  <div>
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input
                      id="lastName"
                      {...childForm.register("lastName")}
                      placeholder="Enter last name"
                    />
                    {childForm.formState.errors.lastName && (
                      <p className="text-sm text-red-600 mt-1">
                        {childForm.formState.errors.lastName.message}
                      </p>
                    )}
                  </div>
                </div>

                <div>
                  <Label htmlFor="birthDate">Date of Birth</Label>
                  <Input
                    id="birthDate"
                    type="date"
                    {...childForm.register("birthDate")}
                  />
                  {childForm.formState.errors.birthDate && (
                    <p className="text-sm text-red-600 mt-1">
                      {childForm.formState.errors.birthDate.message}
                    </p>
                  )}
                </div>

                <div>
                  <Label htmlFor="allergies">Allergies (optional)</Label>
                  <Input
                    id="allergies"
                    {...childForm.register("allergies")}
                    placeholder="Any allergies or medical conditions"
                  />
                </div>

                <div>
                  <Label htmlFor="notes">Bedtime Notes (optional)</Label>
                  <Textarea
                    id="notes"
                    {...childForm.register("notes")}
                    placeholder="Bedtime routine, comfort items, etc."
                    rows={3}
                  />
                </div>

                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={addChildMutation.isPending}
                >
                  {addChildMutation.isPending ? "Adding..." : "Continue"}
                </Button>
              </form>

              {/* Show existing children */}
              {children.length > 0 && (
                <div className="mt-6 pt-6 border-t">
                  <h3 className="font-medium mb-4">Your Children:</h3>
                  {children.map((child: any) => (
                    <div key={child.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg mb-2">
                      <span>{child.firstName} {child.lastName}</span>
                      <CheckCircle2 className="w-5 h-5 text-green-600" />
                    </div>
                  ))}
                  <Button onClick={() => setCurrentStep(2)} className="w-full mt-4">
                    Continue to Emergency Contact
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Step 2: Emergency Contact */}
        {currentStep === 2 && (
          <Card className="mb-6">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-orange-600" />
              </div>
              <CardTitle>Add Emergency Contacts</CardTitle>
              <CardDescription>
                Just in case. We'll only use this if we really need to.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={emergencyForm.handleSubmit(handleEmergencyContact)} className="space-y-4">
                <div>
                  <Label htmlFor="emergencyContact">Emergency Contact Name</Label>
                  <Input
                    id="emergencyContact"
                    {...emergencyForm.register("emergencyContact")}
                    placeholder="Full name"
                  />
                  {emergencyForm.formState.errors.emergencyContact && (
                    <p className="text-sm text-red-600 mt-1">
                      {emergencyForm.formState.errors.emergencyContact.message}
                    </p>
                  )}
                </div>

                <div>
                  <Label htmlFor="emergencyPhone">Phone Number</Label>
                  <Input
                    id="emergencyPhone"
                    type="tel"
                    {...emergencyForm.register("emergencyPhone")}
                    placeholder="027 123 4567"
                  />
                  {emergencyForm.formState.errors.emergencyPhone && (
                    <p className="text-sm text-red-600 mt-1">
                      {emergencyForm.formState.errors.emergencyPhone.message}
                    </p>
                  )}
                </div>

                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={updateEmergencyContactMutation.isPending}
                >
                  {updateEmergencyContactMutation.isPending ? "Saving..." : "Continue"}
                </Button>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Step 3: Preferences */}
        {currentStep === 3 && (
          <Card className="mb-6">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Settings className="w-8 h-8 text-blue-600" />
              </div>
              <CardTitle>Set Preferences</CardTitle>
              <CardDescription>
                Help us match you with the perfect sitter. No stress, just what works.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={preferencesForm.handleSubmit(handlePreferences)} className="space-y-4">
                <div>
                  <Label htmlFor="sitterGender">Preferred Sitter Gender</Label>
                  <Select onValueChange={(value) => preferencesForm.setValue("sitterGender", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="No preference" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="any">No preference</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                      <SelectItem value="male">Male</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="timePreference">Preferred Time of Day</Label>
                  <Select onValueChange={(value) => preferencesForm.setValue("timePreference", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Any time" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="any">Any time</SelectItem>
                      <SelectItem value="morning">Morning (6am - 12pm)</SelectItem>
                      <SelectItem value="afternoon">Afternoon (12pm - 6pm)</SelectItem>
                      <SelectItem value="evening">Evening (6pm - 11pm)</SelectItem>
                      <SelectItem value="overnight">Overnight (11pm - 6am)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="drivingRequired"
                    {...preferencesForm.register("drivingRequired")}
                    className="rounded"
                  />
                  <Label htmlFor="drivingRequired">Sitter must have own transport</Label>
                </div>

                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={updatePreferencesMutation.isPending}
                >
                  {updatePreferencesMutation.isPending ? "Saving..." : "Continue"}
                </Button>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Step 4: Complete */}
        {currentStep === 4 && (
          <Card className="mb-6">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-8 h-8 text-green-600" />
              </div>
              <CardTitle>You're Ready!</CardTitle>
              <CardDescription>
                Welcome to The Village Co. You're all set to book your first guilt-free break.
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <div className="space-y-4">
                <div className="p-4 bg-green-50 rounded-lg">
                  <CheckCircle2 className="w-8 h-8 text-green-600 mx-auto mb-2" />
                  <p className="text-sm text-green-800">
                    Profile complete! You can now book trusted sitters in your area.
                  </p>
                </div>
                
                <Button 
                  onClick={handleComplete}
                  className="w-full"
                  size="lg"
                  disabled={completeOnboardingMutation.isPending}
                >
                  {completeOnboardingMutation.isPending ? "Finishing..." : "Book Your First Break"}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}