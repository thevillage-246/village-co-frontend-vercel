import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, X, Upload, Users, CheckCircle } from "lucide-react";
import { OnboardingData } from "@/pages/Onboarding";

interface OnboardingStep3Props {
  data: OnboardingData;
  updateData: (data: Partial<OnboardingData>) => void;
  onComplete: () => void;
}

interface Child {
  name: string;
  age: number;
  allergies?: string;
  notes?: string;
}

export default function OnboardingStep3({ data, updateData, onComplete }: OnboardingStep3Props) {
  const [formData, setFormData] = useState({
    children: data.children.length > 0 ? data.children : [{ name: "", age: 0, allergies: "", notes: "" }],
    emergencyContactName: data.emergencyContactName,
    emergencyContactPhone: data.emergencyContactPhone,
    familyPhoto: data.familyPhoto
  });

  const [isValid, setIsValid] = useState(false);

  useEffect(() => {
    const validChildren = formData.children.filter(child => 
      child.name.trim() !== '' && child.age > 0
    );
    
    const valid = validChildren.length > 0 && 
                  formData.emergencyContactName.trim() !== '' && 
                  formData.emergencyContactPhone.trim() !== '';
    
    setIsValid(valid);
  }, [formData]);

  const handleChange = (field: string, value: any) => {
    const newData = { ...formData, [field]: value };
    setFormData(newData);
    // Use a timeout to prevent infinite updates
    setTimeout(() => {
      updateData(newData);
    }, 0);
  };

  const handleChildChange = (index: number, field: string, value: string | number) => {
    const newChildren = [...formData.children];
    newChildren[index] = { ...newChildren[index], [field]: value };
    handleChange('children', newChildren);
  };

  const addChild = () => {
    const newChildren = [...formData.children, { name: "", age: 0, allergies: "", notes: "" }];
    handleChange('children', newChildren);
  };

  const removeChild = (index: number) => {
    if (formData.children.length > 1) {
      const newChildren = formData.children.filter((_, i) => i !== index);
      handleChange('children', newChildren);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const base64 = e.target?.result as string;
        handleChange('familyPhoto', base64);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isValid) {
      onComplete();
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      {/* Children Information */}
      <div className="space-y-6">
        <div className="flex items-center gap-2">
          <Users className="w-5 h-5 text-village-wine" />
          <h3 className="text-lg font-semibold text-village-wine">Your Children</h3>
        </div>

        <div className="space-y-4">
          {formData.children.map((child, index) => (
            <Card key={index} className="border-village-wine/20">
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <Badge variant="outline" className="border-village-rose/30 text-village-rose">
                    Child {index + 1}
                  </Badge>
                  {formData.children.length > 1 && (
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeChild(index)}
                      className="text-village-taupe/60 hover:text-village-wine h-8 w-8 p-0"
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  )}
                </div>

                <div className="grid md:grid-cols-2 gap-4 mb-4">
                  <div className="space-y-2">
                    <Label htmlFor={`child-name-${index}`} className="text-village-wine font-medium">
                      Name *
                    </Label>
                    <Input
                      id={`child-name-${index}`}
                      type="text"
                      value={child.name}
                      onChange={(e) => handleChildChange(index, 'name', e.target.value)}
                      placeholder="Child's name"
                      className="border-village-wine/30 focus:border-village-wine"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor={`child-age-${index}`} className="text-village-wine font-medium">
                      Age *
                    </Label>
                    <Input
                      id={`child-age-${index}`}
                      type="number"
                      min="0"
                      max="18"
                      value={child.age || ''}
                      onChange={(e) => handleChildChange(index, 'age', parseInt(e.target.value) || 0)}
                      placeholder="Age in years"
                      className="border-village-wine/30 focus:border-village-wine"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor={`child-allergies-${index}`} className="text-village-wine font-medium">
                      Allergies or Medical Conditions
                    </Label>
                    <Input
                      id={`child-allergies-${index}`}
                      type="text"
                      value={child.allergies || ''}
                      onChange={(e) => handleChildChange(index, 'allergies', e.target.value)}
                      placeholder="e.g. Peanut allergy, Asthma (leave blank if none)"
                      className="border-village-wine/30 focus:border-village-wine"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor={`child-notes-${index}`} className="text-village-wine font-medium">
                      Special Notes
                    </Label>
                    <Textarea
                      id={`child-notes-${index}`}
                      value={child.notes || ''}
                      onChange={(e) => handleChildChange(index, 'notes', e.target.value)}
                      placeholder="e.g. Bedtime routine, favourite activities, things to know..."
                      className="border-village-wine/30 focus:border-village-wine resize-none"
                      rows={3}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}

          <Button
            type="button"
            variant="outline"
            onClick={addChild}
            className="w-full border-village-wine/30 text-village-wine hover:bg-village-wine/10 border-dashed"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Another Child
          </Button>
        </div>
      </div>

      {/* Emergency Contact */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-village-wine">Emergency Contact</h3>
        <p className="text-village-taupe/70 text-sm">
          Someone we can reach if you're not available during a booking
        </p>

        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="emergency-name" className="text-village-wine font-medium">
              Contact Name *
            </Label>
            <Input
              id="emergency-name"
              type="text"
              value={formData.emergencyContactName}
              onChange={(e) => handleChange('emergencyContactName', e.target.value)}
              placeholder="e.g. Partner, Family member, Friend"
              className="border-village-wine/30 focus:border-village-wine"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="emergency-phone" className="text-village-wine font-medium">
              Contact Phone *
            </Label>
            <Input
              id="emergency-phone"
              type="tel"
              value={formData.emergencyContactPhone}
              onChange={(e) => handleChange('emergencyContactPhone', e.target.value)}
              placeholder="+64 21 123 4567"
              className="border-village-wine/30 focus:border-village-wine"
              required
            />
          </div>
        </div>
      </div>

      {/* Family Photo (Optional) */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-village-wine">Family Photo (Optional)</h3>
        <p className="text-village-taupe/70 text-sm">
          Help your sitters recognise your family - makes pickup easier and builds trust
        </p>

        <Card className="border-village-wine/20 border-dashed">
          <CardContent className="p-6">
            <div className="text-center">
              {formData.familyPhoto ? (
                <div className="space-y-4">
                  <img 
                    src={formData.familyPhoto} 
                    alt="Family photo" 
                    className="max-w-48 max-h-48 mx-auto rounded-lg object-cover"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => handleChange('familyPhoto', undefined)}
                    className="text-village-taupe border-village-taupe/30"
                  >
                    Remove Photo
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  <Upload className="w-12 h-12 text-village-taupe/40 mx-auto" />
                  <div>
                    <p className="text-village-wine font-medium mb-1">Upload a family photo</p>
                    <p className="text-sm text-village-taupe/60">
                      JPG, PNG up to 5MB
                    </p>
                  </div>
                  <label htmlFor="family-photo">
                    <Button
                      type="button"
                      variant="outline"
                      className="border-village-wine/30 text-village-wine hover:bg-village-wine/10"
                      onClick={() => document.getElementById('family-photo')?.click()}
                    >
                      Choose Photo
                    </Button>
                  </label>
                  <input
                    id="family-photo"
                    type="file"
                    accept="image/jpeg,image/jpg,image/png"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Submit Button */}
      <div className="pt-6">
        <Button
          type="submit"
          disabled={!isValid}
          className="w-full bg-village-wine hover:bg-village-wine/90 text-white font-medium py-3 text-lg"
        >
          <CheckCircle className="w-5 h-5 mr-2" />
          Create My Village Profile
        </Button>
        
        {!isValid && (
          <p className="text-sm text-village-taupe/60 text-center mt-2">
            Please add at least one child and emergency contact details
          </p>
        )}

        <div className="mt-6 p-4 bg-village-eucalyptus/10 rounded-lg border border-village-eucalyptus/20">
          <div className="flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-village-eucalyptus mt-0.5" />
            <div>
              <h4 className="font-medium text-village-eucalyptus mb-1">What happens next?</h4>
              <p className="text-sm text-village-taupe/80">
                Your profile will be created and you'll have access to book trusted sitters, 
                join our parent community, and get support when you need it most.
              </p>
            </div>
          </div>
        </div>
      </div>
    </form>
  );
}