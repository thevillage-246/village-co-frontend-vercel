import React, { useRef, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Camera, Star, MapPin, Clock, ArrowLeft, ArrowRight, Upload } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import type { SitterOnboardingData } from '@/pages/SitterOnboarding';

const step2Schema = z.object({
  bio: z.string().min(50, 'Please write at least 50 characters about yourself'),
  experienceLevel: z.string().min(1, 'Please select your experience level'),
  suburbs: z.array(z.string()).min(1, 'Please select at least one suburb'),
  preferredTimes: z.array(z.string()).min(1, 'Please select at least one preferred time'),
});

type Step2FormData = z.infer<typeof step2Schema>;

interface SitterOnboardingStep2Props {
  data: SitterOnboardingData;
  updateData: (data: Partial<SitterOnboardingData>) => void;
  onNext: () => void;
  onBack: () => void;
}

const newZealandCities = [
  // Major Cities
  "Auckland",
  "Wellington", 
  "Christchurch",
  "Hamilton",
  "Tauranga",
  "Napier-Hastings",
  "Dunedin",
  "Palmerston North",
  "Nelson",
  "Rotorua",
  "New Plymouth",
  "Whangarei",
  "Invercargill",
  "Whanganui",
  "Gisborne",
  
  // Regional Centers
  "Kapiti Coast",
  "Upper Hutt",
  "Lower Hutt",
  "Porirua",
  "Masterton",
  "Blenheim",
  "Timaru",
  "Oamaru",
  "Queenstown",
  "Greymouth",
  "Westport",
  "Thames",
  "Taupo",
  "Tokoroa",
  "Te Awamutu",
  "Cambridge",
  "Morrinsville",
  "Huntly",
  "Pukekohe",
  "Papakura",
  "Manukau",
  "North Shore",
  "Waitakere"
];

const timeSlots = [
  'Early Morning (6am-9am)', 'Morning (9am-12pm)', 'Afternoon (12pm-5pm)',
  'Evening (5pm-8pm)', 'Night (8pm-11pm)', 'Late Night (11pm+)',
  'Weekends', 'School Holidays'
];

export default function SitterOnboardingStep2({ data, updateData, onNext, onBack }: SitterOnboardingStep2Props) {
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [selectedAvailability, setSelectedAvailability] = useState(data.availability);
  const [selectedCities, setSelectedCities] = useState<string[]>(data.suburbs || data.cities || []);
  const [selectedTimes, setSelectedTimes] = useState<string[]>(data.preferredTimes);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const form = useForm<Step2FormData>({
    resolver: zodResolver(step2Schema),
    defaultValues: {
      bio: data.bio,
      experienceLevel: data.experienceLevel,
      suburbs: data.suburbs,
      preferredTimes: data.preferredTimes,
    },
  });

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      updateData({ profilePhoto: file });
      const reader = new FileReader();
      reader.onload = (e) => setSelectedImage(e.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleAvailabilityChange = (day: keyof typeof selectedAvailability, checked: boolean) => {
    const newAvailability = { ...selectedAvailability, [day]: checked };
    setSelectedAvailability(newAvailability);
    updateData({ availability: newAvailability });
  };

  const handleCityToggle = (city: string) => {
    const newCities = selectedCities.includes(city)
      ? selectedCities.filter(c => c !== city)
      : [...selectedCities, city];
    setSelectedCities(newCities);
    form.setValue('suburbs', newCities); // Keep 'suburbs' for backward compatibility
  };

  const handleTimeToggle = (time: string) => {
    const newTimes = selectedTimes.includes(time)
      ? selectedTimes.filter(t => t !== time)
      : [...selectedTimes, time];
    setSelectedTimes(newTimes);
    form.setValue('preferredTimes', newTimes);
  };

  const onSubmit = async (formData: Step2FormData) => {
    setIsSubmitting(true);
    try {
      console.log('📤 Saving step 2 data:', {
        ...formData,
        suburbs: selectedCities,
        preferredTimes: selectedTimes,
        availability: selectedAvailability,
      });
      
      // Save step 2 data to backend
      const step2Data = {
        bio: formData.bio,
        experienceLevel: formData.experienceLevel,
        availability: selectedAvailability,
        preferredTimes: selectedTimes,
        suburbs: selectedCities,
      };
      
      const response = await apiRequest('POST', '/api/sitter/onboarding/step2', step2Data);
      const result = await response.json();
      
      console.log('✅ Step 2 data saved:', result);
      
      // Update local state
      updateData({
        ...formData,
        suburbs: selectedCities,
        cities: selectedCities,
        preferredTimes: selectedTimes,
        availability: selectedAvailability,
      });
      
      // Move to next step
      onNext();
      
      toast({
        title: "Step 2 Complete",
        description: "Your profile details have been saved successfully.",
      });
      
    } catch (error) {
      console.error('❌ Error saving step 2 data:', error);
      toast({
        title: "Error",
        description: "Failed to save your profile details. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 border border-brushed-pink/20">
      {/* Header */}
      <div className="text-center mb-8">
        <div className="flex justify-center mb-4">
          <div className="bg-gradient-to-br from-village-wine to-rose p-3 rounded-full">
            <Star className="h-8 w-8 text-white" />
          </div>
        </div>
        <h1 className="text-3xl font-bold text-village-wine mb-2">
          Build Your Profile
        </h1>
        <p className="text-lg text-taupe leading-relaxed max-w-md mx-auto">
          This is your moment. Parents will see this.
        </p>
        <p className="text-base text-gray-600 mt-4 max-w-lg mx-auto">
          We want families to see you — the real you. So be honest, be warm, and let your personality shine.
        </p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          {/* Profile Photo Upload */}
          <div className="text-center">
            <FormLabel className="text-village-wine font-semibold text-lg block mb-4">Profile Photo</FormLabel>
            <div className="flex flex-col items-center gap-4">
              <div 
                className="w-32 h-32 rounded-full border-4 border-dashed border-gray-300 flex items-center justify-center cursor-pointer hover:border-village-wine transition-colors bg-gray-50"
                onClick={() => fileInputRef.current?.click()}
              >
                {selectedImage ? (
                  <img src={selectedImage} alt="Profile" className="w-full h-full rounded-full object-cover" />
                ) : (
                  <div className="text-center">
                    <Camera className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                    <p className="text-sm text-gray-500">Upload Photo</p>
                  </div>
                )}
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
              />
              <Button
                type="button"
                variant="outline"
                onClick={() => fileInputRef.current?.click()}
                className="border-village-wine text-village-wine hover:bg-village-wine hover:text-white"
              >
                <Upload className="h-4 w-4 mr-2" />
                Choose Photo
              </Button>
            </div>
          </div>

          {/* Bio */}
          <FormField
            control={form.control}
            name="bio"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-village-wine font-semibold text-lg">
                  Why families love me...
                </FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder="Share what makes you special! Maybe you're great at bedtime stories, love cooking with kids, or have a knack for calming tantrums. Parents want to know the real you."
                    className="min-h-32 border-2 border-gray-200 focus:border-village-wine rounded-xl resize-none"
                    {...field} 
                  />
                </FormControl>
                <FormMessage />
                <p className="text-sm text-gray-500 mt-1">
                  {field.value?.length || 0}/300 characters
                </p>
              </FormItem>
            )}
          />

          {/* Experience Level */}
          <FormField
            control={form.control}
            name="experienceLevel"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-village-wine font-semibold text-lg">Experience Level</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger className="h-12 border-2 border-gray-200 focus:border-village-wine rounded-xl">
                      <SelectValue placeholder="Select your experience level" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="student">Student (some babysitting experience)</SelectItem>
                    <SelectItem value="experienced">Experienced Babysitter (2+ years)</SelectItem>
                    <SelectItem value="parent">Parent (raising my own children)</SelectItem>
                    <SelectItem value="qualified">Early Childhood Qualified</SelectItem>
                    <SelectItem value="professional">Professional Childcare Worker</SelectItem>
                    <SelectItem value="teacher">Teacher/Education Background</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* Availability */}
          <div>
            <FormLabel className="text-village-wine font-semibold text-lg block mb-4">
              <Clock className="inline h-5 w-5 mr-2" />
              Which days work for you?
            </FormLabel>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {Object.entries(selectedAvailability).map(([day, isSelected]) => (
                <div key={day} className="flex items-center space-x-2">
                  <Checkbox
                    id={day}
                    checked={isSelected}
                    onCheckedChange={(checked) => 
                      handleAvailabilityChange(day as keyof typeof selectedAvailability, checked as boolean)
                    }
                    className="border-2 border-gray-300 data-[state=checked]:bg-village-wine data-[state=checked]:border-village-wine"
                  />
                  <label htmlFor={day} className="text-sm font-medium capitalize cursor-pointer">
                    {day}
                  </label>
                </div>
              ))}
            </div>
          </div>

          {/* Preferred Times */}
          <div>
            <FormLabel className="text-village-wine font-semibold text-lg block mb-4">
              Preferred Times
            </FormLabel>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {timeSlots.map((time) => (
                <div
                  key={time}
                  className={`p-3 border-2 rounded-xl cursor-pointer transition-all ${
                    selectedTimes.includes(time)
                      ? 'border-village-wine bg-village-wine/5 text-village-wine'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => handleTimeToggle(time)}
                >
                  <p className="text-sm font-medium">{time}</p>
                </div>
              ))}
            </div>
            {form.formState.errors.preferredTimes && (
              <p className="text-red-500 text-sm mt-2">{form.formState.errors.preferredTimes.message}</p>
            )}
          </div>

          {/* Location/Cities */}
          <div>
            <FormLabel className="text-village-wine font-semibold text-lg block mb-4">
              <MapPin className="inline h-5 w-5 mr-2" />
              Where can you babysit? (Select all that work)
            </FormLabel>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 max-h-48 overflow-y-auto">
              {newZealandCities.map((city) => (
                <div
                  key={city}
                  className={`p-3 border-2 rounded-xl cursor-pointer transition-all ${
                    selectedCities.includes(city)
                      ? 'border-village-wine bg-village-wine/5 text-village-wine'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => handleCityToggle(city)}
                >
                  <p className="text-sm font-medium">{city}</p>
                </div>
              ))}
            </div>
            {form.formState.errors.suburbs && (
              <p className="text-red-500 text-sm mt-2">{form.formState.errors.suburbs.message}</p>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex gap-4 pt-6">
            <Button
              type="button"
              variant="outline"
              onClick={onBack}
              disabled={isSubmitting}
              className="flex-1 h-12 border-2 border-gray-300 text-gray-600 hover:bg-gray-50 rounded-xl disabled:opacity-50"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back
            </Button>
            <Button 
              type="submit" 
              disabled={isSubmitting}
              className="flex-1 h-12 bg-gradient-to-r from-village-wine to-rose hover:from-village-wine/90 hover:to-rose/90 text-white font-semibold rounded-xl transition-all duration-300 disabled:opacity-50"
            >
              {isSubmitting ? 'Saving...' : 'Next: Safety & Support'}
              {!isSubmitting && <ArrowRight className="ml-2 h-4 w-4" />}
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}