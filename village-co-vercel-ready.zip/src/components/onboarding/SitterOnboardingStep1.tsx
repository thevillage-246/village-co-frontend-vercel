import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Heart, Users, ArrowRight } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import type { SitterOnboardingData } from '@/pages/SitterOnboarding';

const step1Schema = z.object({
  firstName: z.string().min(1, 'First name is required'),
  email: z.string().email('Please enter a valid email address'),
  mobile: z.string().min(1, 'Mobile number is required'),
  howHeardAbout: z.string().min(1, 'Please let us know how you heard about us'),
  whyBabysit: z.string().min(10, 'Please share a bit more about why you want to babysit'),
});

type Step1FormData = z.infer<typeof step1Schema>;

interface SitterOnboardingStep1Props {
  data: SitterOnboardingData;
  updateData: (data: Partial<SitterOnboardingData>) => void;
  onNext: () => void;
}

export default function SitterOnboardingStep1({ data, updateData, onNext }: SitterOnboardingStep1Props) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const form = useForm<Step1FormData>({
    resolver: zodResolver(step1Schema),
    defaultValues: {
      firstName: data.firstName,
      email: data.email,
      mobile: data.mobile,
      howHeardAbout: data.howHeardAbout,
      whyBabysit: data.whyBabysit,
    },
  });

  const onSubmit = async (formData: Step1FormData) => {
    setIsSubmitting(true);
    try {
      console.log('📤 Saving step 1 data:', formData);
      
      // Save step 1 data to backend
      const response = await apiRequest('POST', '/api/sitter/onboarding/step1', formData);
      const result = await response.json();
      
      console.log('✅ Step 1 data saved:', result);
      
      // Update local state
      updateData(formData);
      
      // Move to next step
      onNext();
      
      toast({
        title: "Step 1 Complete",
        description: "Your basic information has been saved successfully.",
      });
      
    } catch (error) {
      console.error('❌ Error saving step 1 data:', error);
      toast({
        title: "Error",
        description: "Failed to save your information. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 border border-brushed-pink/20">
      {/* Header */}
      <div className="text-center mb-8">
        <div className="flex justify-center mb-4">
          <div className="bg-gradient-to-br from-village-wine to-rose p-3 rounded-full">
            <Heart className="h-8 w-8 text-white" />
          </div>
        </div>
        <h1 className="text-3xl font-bold text-village-wine mb-2">
          Want to become a Village Sitter?
        </h1>
        <p className="text-lg text-taupe leading-relaxed max-w-md mx-auto">
          We'd love to hear from you.
        </p>
        <p className="text-base text-gray-600 mt-4 max-w-lg mx-auto">
          You already care. You're already someone parents would trust. We're just here to help you turn that into flexible, paid, meaningful work — with a village backing you.
        </p>
      </div>

      {/* Form */}
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <FormField
            control={form.control}
            name="firstName"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-village-wine font-semibold">First Name</FormLabel>
                <FormControl>
                  <Input 
                    placeholder="What should we call you?" 
                    className="h-12 border-2 border-gray-200 focus:border-village-wine rounded-xl"
                    {...field} 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-village-wine font-semibold">Email Address</FormLabel>
                  <FormControl>
                    <Input 
                      type="email"
                      placeholder="your@email.com" 
                      className="h-12 border-2 border-gray-200 focus:border-village-wine rounded-xl"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="mobile"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-village-wine font-semibold">Mobile Number</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="+64 21 123 4567" 
                      className="h-12 border-2 border-gray-200 focus:border-village-wine rounded-xl"
                      {...field} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="howHeardAbout"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-village-wine font-semibold">How did you hear about us?</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger className="h-12 border-2 border-gray-200 focus:border-village-wine rounded-xl">
                      <SelectValue placeholder="Choose one option" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="facebook">Facebook</SelectItem>
                    <SelectItem value="instagram">Instagram</SelectItem>
                    <SelectItem value="google">Google Search</SelectItem>
                    <SelectItem value="friend">Friend or Family</SelectItem>
                    <SelectItem value="university">University/College</SelectItem>
                    <SelectItem value="community">Community Board</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="whyBabysit"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-village-wine font-semibold">
                  Why do you want to babysit?
                </FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder="Tell us what draws you to childcare. Maybe you're saving for something special, love working with kids, or want flexible income while studying? We'd love to hear your story."
                    className="min-h-24 border-2 border-gray-200 focus:border-village-wine rounded-xl resize-none"
                    {...field} 
                  />
                </FormControl>
                <FormMessage />
                <p className="text-sm text-gray-500 mt-1">This helps us match you with the right families</p>
              </FormItem>
            )}
          />

          {/* Trust Badge */}
          <div className="bg-gradient-to-r from-eucalyptus/10 to-brushed-pink/10 rounded-xl p-4 border border-eucalyptus/20">
            <div className="flex items-center gap-3">
              <Users className="h-5 w-5 text-eucalyptus" />
              <div>
                <p className="text-sm font-medium text-village-wine">We'll never share your info</p>
                <p className="text-xs text-gray-600">Your privacy matters to us</p>
              </div>
            </div>
          </div>

          <Button 
            type="submit" 
            disabled={isSubmitting}
            className="w-full h-14 bg-gradient-to-r from-village-wine to-rose hover:from-village-wine/90 hover:to-rose/90 text-white text-lg font-semibold rounded-xl transition-all duration-300 shadow-lg hover:shadow-xl disabled:opacity-50"
          >
            {isSubmitting ? 'Saving...' : 'Next: Build Your Profile'}
            {!isSubmitting && <ArrowRight className="ml-2 h-5 w-5" />}
          </Button>

          <p className="text-center text-sm text-gray-500">
            This part takes 2 mins tops
          </p>
        </form>
      </Form>
    </div>
  );
}