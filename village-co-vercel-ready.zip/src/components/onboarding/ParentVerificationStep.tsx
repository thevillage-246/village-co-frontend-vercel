import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Shield, CheckCircle, AlertTriangle } from 'lucide-react';

interface ParentVerificationStepProps {
  onNext: () => void;
  onSkip?: () => void;
}

export default function ParentVerificationStep({ onNext, onSkip }: ParentVerificationStepProps) {
  const [isStarting, setIsStarting] = useState(false);
  const [verificationStarted, setVerificationStarted] = useState(false);
  const { toast } = useToast();

  const startVerification = async () => {
    setIsStarting(true);
    try {
      const response = await apiRequest('POST', '/api/veriff/parent-start-verification');
      const data = await response.json();

      if (data.verification?.url) {
        setVerificationStarted(true);
        
        // Open Veriff in a new window
        const veriffWindow = window.open(data.verification.url, '_blank', 'width=800,height=600');
        
        if (!veriffWindow) {
          toast({
            variant: 'destructive',
            title: 'Popup Blocked',
            description: 'Please allow popups to continue with verification.',
          });
          return;
        }

        // Poll for completion
        const checkCompletion = setInterval(() => {
          if (veriffWindow.closed) {
            clearInterval(checkCompletion);
            toast({
              title: "Verification Submitted",
              description: "Your verification has been submitted for review. You can continue setting up your profile.",
            });
            // Move to next step after verification window closes
            setTimeout(() => {
              onNext();
            }, 1000);
          }
        }, 1000);

        toast({
          title: "Verification Started",
          description: "Complete the verification process in the new window.",
        });
      }
    } catch (error) {
      console.error('Failed to start verification:', error);
      toast({
        title: "Verification Failed",
        description: "Unable to start verification. You can skip this step and complete it later from your dashboard.",
        variant: "destructive"
      });
    } finally {
      setIsStarting(false);
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader className="text-center">
        <div className="flex justify-center mb-4">
          <div className="p-3 bg-village-wine/10 rounded-full">
            <Shield className="h-8 w-8 text-village-wine" />
          </div>
        </div>
        <CardTitle className="text-2xl text-village-wine">Identity Verification</CardTitle>
        <CardDescription className="text-lg">
          Verify your identity to build trust with sitters and ensure platform safety
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-start space-x-3">
            <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
            <div>
              <h4 className="font-semibold text-green-800">Why verify your identity?</h4>
              <ul className="text-sm text-green-700 mt-2 space-y-1">
                <li>• Build trust with sitters before they accept bookings</li>
                <li>• Ensure the safety of all families on the platform</li>
                <li>• Access to all premium platform features</li>
                <li>• Faster booking confirmations from verified sitters</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-start space-x-3">
            <AlertTriangle className="h-5 w-5 text-blue-600 mt-0.5" />
            <div>
              <h4 className="font-semibold text-blue-800">What you'll need:</h4>
              <ul className="text-sm text-blue-700 mt-2 space-y-1">
                <li>• A government-issued photo ID and passport</li>
                <li>• Good lighting and a device with a camera</li>
                <li>• About 2-3 minutes to complete the process</li>
              </ul>
            </div>
          </div>
        </div>

        <div className="text-center space-y-4">
          <p className="text-sm text-gray-600">
            Your verification is processed securely by Veriff and typically takes 1-2 business days to review.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button 
              onClick={startVerification}
              disabled={isStarting}
              className="bg-village-wine hover:bg-village-wine/90 text-white px-8 py-3"
            >
              {isStarting ? (
                <>
                  <div className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full mr-2"></div>
                  Starting Verification...
                </>
              ) : verificationStarted ? (
                'Verification Started'
              ) : (
                <>
                  <Shield className="h-4 w-4 mr-2" />
                  Start Identity Verification
                </>
              )}
            </Button>
            
            {onSkip && (
              <Button 
                variant="outline" 
                onClick={onSkip}
                className="border-village-wine text-village-wine hover:bg-village-wine/10 px-8 py-3"
              >
                Skip for Now
              </Button>
            )}
          </div>
          
          {onSkip && (
            <p className="text-xs text-gray-500">
              You can complete identity verification later from your dashboard
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}