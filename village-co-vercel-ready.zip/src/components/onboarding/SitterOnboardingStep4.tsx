import React, { useRef, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Shield, Upload, Video, FileText, Users, ArrowLeft, CheckCircle } from 'lucide-react';
import type { SitterOnboardingData } from '@/pages/SitterOnboarding';

const step4Schema = z.object({
  backgroundCheckConsent: z.boolean().refine(val => val === true, {
    message: 'You must consent to background check to continue',
  }),
  referee1Name: z.string().min(1, 'Reference contact name is required'),
  referee1Email: z.string().email('Please enter a valid email for reference contact'),
  codeOfCareAgreement: z.boolean().refine(val => val === true, {
    message: 'You must agree to the Code of Care to continue',
  }),
});

type Step4FormData = z.infer<typeof step4Schema>;

interface SitterOnboardingStep4Props {
  data: SitterOnboardingData;
  updateData: (data: Partial<SitterOnboardingData>) => void;
  onComplete: () => void;
  onBack: () => void;
}

export default function SitterOnboardingStep4({ data, updateData, onComplete, onBack }: SitterOnboardingStep4Props) {
  const videoInputRef = useRef<HTMLInputElement>(null);
  const idInputRef = useRef<HTMLInputElement>(null);
  const firstAidInputRef = useRef<HTMLInputElement>(null);
  
  const [videoSelected, setVideoSelected] = useState(false);
  const [idSelected, setIdSelected] = useState(false);
  const [firstAidSelected, setFirstAidSelected] = useState(false);

  const form = useForm<Step4FormData>({
    resolver: zodResolver(step4Schema),
    defaultValues: {
      backgroundCheckConsent: data.backgroundCheckConsent,
      referee1Name: data.referees[0]?.name || '',
      referee1Email: data.referees[0]?.email || '',
      codeOfCareAgreement: data.codeOfCareAgreement,
    },
  });

  const handleVideoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      updateData({ videoIntro: file });
      setVideoSelected(true);
    }
  };

  const handleIdUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      updateData({ idDocument: file });
      setIdSelected(true);
    }
  };

  const handleFirstAidUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      updateData({ firstAidCertificate: file });
      setFirstAidSelected(true);
    }
  };

  const onSubmit = (formData: Step4FormData) => {
    updateData({
      backgroundCheckConsent: formData.backgroundCheckConsent,
      referees: [
        { name: formData.referee1Name, email: formData.referee1Email }
      ],
      codeOfCareAgreement: formData.codeOfCareAgreement,
    });
    onComplete();
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 border border-brushed-pink/20">
      {/* Header */}
      <div className="text-center mb-8">
        <div className="flex justify-center mb-4">
          <div className="bg-gradient-to-br from-village-wine to-rose p-3 rounded-full">
            <Shield className="h-8 w-8 text-white" />
          </div>
        </div>
        <h1 className="text-3xl font-bold text-village-wine mb-2">
          Trust Goes Both Ways
        </h1>
        <p className="text-lg text-taupe leading-relaxed max-w-md mx-auto">
          We take your safety seriously too.
        </p>
        <p className="text-base text-gray-600 mt-4 max-w-lg mx-auto">
          Every sitter on The Village Co. is personally welcomed by our team, supported with resources, and backed by insurance. We ask for a few things up front to keep everyone safe and trusted.
        </p>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          {/* Upload Sections */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Video Intro */}
            <div className="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center">
              <Video className="h-8 w-8 text-gray-400 mx-auto mb-3" />
              <h3 className="font-semibold text-village-wine mb-2">Selfie Video Intro</h3>
              <p className="text-sm text-gray-600 mb-4">
                Record a quick 30-second video introducing yourself. Just be natural!
              </p>
              <Button
                type="button"
                variant="outline"
                onClick={() => videoInputRef.current?.click()}
                className={`w-full ${videoSelected ? 'border-green-500 text-green-600' : 'border-village-wine text-village-wine'}`}
              >
                {videoSelected ? (
                  <>
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Video Selected
                  </>
                ) : (
                  <>
                    <Upload className="h-4 w-4 mr-2" />
                    Upload Video
                  </>
                )}
              </Button>
              <input
                ref={videoInputRef}
                type="file"
                accept="video/*"
                onChange={handleVideoUpload}
                className="hidden"
              />
            </div>

            {/* ID Document */}
            <div className="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center">
              <FileText className="h-8 w-8 text-gray-400 mx-auto mb-3" />
              <h3 className="font-semibold text-village-wine mb-2">ID or Passport</h3>
              <p className="text-sm text-gray-600 mb-4">
                Upload a clear photo of your ID or passport
              </p>
              <Button
                type="button"
                variant="outline"
                onClick={() => idInputRef.current?.click()}
                className={`w-full ${idSelected ? 'border-green-500 text-green-600' : 'border-village-wine text-village-wine'}`}
              >
                {idSelected ? (
                  <>
                    <CheckCircle className="h-4 w-4 mr-2" />
                    ID Selected
                  </>
                ) : (
                  <>
                    <Upload className="h-4 w-4 mr-2" />
                    Upload ID
                  </>
                )}
              </Button>
              <input
                ref={idInputRef}
                type="file"
                accept="image/*"
                onChange={handleIdUpload}
                className="hidden"
              />
            </div>
          </div>

          {/* Background Check Consent */}
          <div className="bg-gray-50 rounded-xl p-6">
            <FormField
              control={form.control}
              name="backgroundCheckConsent"
              render={({ field }) => (
                <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                      className="border-2 border-gray-300 data-[state=checked]:bg-village-wine data-[state=checked]:border-village-wine"
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel className="text-village-wine font-semibold">
                      I consent to a background check
                    </FormLabel>
                    <p className="text-sm text-gray-600">
                      We'll run a basic background check to keep families safe. This includes a police check and reference verification.
                    </p>
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          {/* Referees */}
          <div>
            <FormLabel className="text-village-wine font-semibold text-lg block mb-4">
              <Users className="inline h-5 w-5 mr-2" />
              Reference Contacts
            </FormLabel>
            <p className="text-sm text-gray-600 mb-6">
              Provide one person who can vouch for your character and reliability with children.
            </p>
            
            <div className="max-w-md space-y-4">
              <FormField
                control={form.control}
                name="referee1Name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Full Name</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="e.g., Sarah Johnson"
                        className="h-12 border-2 border-gray-200 focus:border-village-wine rounded-xl"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="referee1Email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email Address</FormLabel>
                    <FormControl>
                      <Input 
                        type="email"
                        placeholder="sarah@email.com"
                        className="h-12 border-2 border-gray-200 focus:border-village-wine rounded-xl"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </div>

          {/* Optional First Aid Certificate */}
          <div className="border border-gray-200 rounded-xl p-6">
            <h3 className="font-semibold text-village-wine mb-2">First Aid Certificate (Optional)</h3>
            <p className="text-sm text-gray-600 mb-4">
              Having first aid training gives parents extra confidence. If you have a certificate, upload it here.
            </p>
            <Button
              type="button"
              variant="outline"
              onClick={() => firstAidInputRef.current?.click()}
              className={`${firstAidSelected ? 'border-green-500 text-green-600' : 'border-village-wine text-village-wine'}`}
            >
              {firstAidSelected ? (
                <>
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Certificate Selected
                </>
              ) : (
                <>
                  <Upload className="h-4 w-4 mr-2" />
                  Upload Certificate
                </>
              )}
            </Button>
            <input
              ref={firstAidInputRef}
              type="file"
              accept="image/*,application/pdf"
              onChange={handleFirstAidUpload}
              className="hidden"
            />
          </div>

          {/* Code of Care Agreement */}
          <div className="bg-village-wine/5 rounded-xl p-6 border border-village-wine/20">
            <FormField
              control={form.control}
              name="codeOfCareAgreement"
              render={({ field }) => (
                <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                      className="border-2 border-village-wine data-[state=checked]:bg-village-wine data-[state=checked]:border-village-wine"
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel className="text-village-wine font-semibold">
                      I agree to The Village Co. <a 
                        href="https://thevillageco.nz/terms-of-service" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="underline hover:text-village-wine/80 transition-colors"
                      >
                        Code of Care
                      </a>
                    </FormLabel>
                    <p className="text-sm text-gray-600">
                      Our Code of Care outlines the standards we expect from all sitters, including safety protocols, professional conduct, and communication guidelines.
                    </p>
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          {/* Action Buttons */}
          <div className="flex gap-4 pt-6">
            <Button
              type="button"
              variant="outline"
              onClick={onBack}
              className="flex-1 h-12 border-2 border-gray-300 text-gray-600 hover:bg-gray-50 rounded-xl"
            >
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back
            </Button>
            <Button 
              type="submit" 
              className="flex-1 h-12 bg-gradient-to-r from-village-wine to-rose hover:from-village-wine/90 hover:to-rose/90 text-white font-semibold rounded-xl transition-all duration-300"
            >
              Submit & Book Your Welcome Call
              <CheckCircle className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}