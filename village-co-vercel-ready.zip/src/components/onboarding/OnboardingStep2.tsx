import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ArrowRight, Star, MapPin, Clock, Shield, Heart } from "lucide-react";
import { OnboardingData } from "@/pages/Onboarding";

interface OnboardingStep2Props {
  data: OnboardingData;
  updateData: (data: Partial<OnboardingData>) => void;
  onNext: () => void;
}

interface Sitter {
  id: number;
  userId: number;
  bio: string;
  experience: string;
  hourlyRate: string;
  photoUrl?: string;
  availabilityTags: string[];
  age: number;
  badge?: string;
  firstName: string;
  lastName: string;
  email: string;
  skills?: any[];
  rating?: number;
  reviewCount?: number;
}

export default function OnboardingStep2({ data, updateData, onNext }: OnboardingStep2Props) {
  const [selectedSitter, setSelectedSitter] = useState<number | null>(data.selectedSitterId || null);

  // Fetch sitters for preview
  const { data: sitters = [], isLoading } = useQuery({
    queryKey: ['/api/sitters'],
    select: (data: any[]) => {
      // Get top 3 sitters for onboarding preview
      return data.slice(0, 3);
    }
  });

  const handleSitterSelect = (sitterId: number) => {
    setSelectedSitter(sitterId);
    // Use a timeout to prevent infinite updates
    setTimeout(() => {
      updateData({ selectedSitterId: sitterId });
    }, 0);
  };

  const handleMatchLater = () => {
    setSelectedSitter(null);
    updateData({ selectedSitterId: undefined });
    onNext();
  };

  const handleContinueWithSitter = () => {
    if (selectedSitter) {
      onNext();
    }
  };

  const getSitterInitials = (name: string | undefined) => {
    if (!name) return 'S';
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const formatQualifications = (qualifications: string[]) => {
    const key = qualifications.slice(0, 2);
    const remaining = qualifications.length - 2;
    
    if (remaining > 0) {
      return `${key.join(', ')} +${remaining} more`;
    }
    return key.join(', ');
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin w-8 h-8 border-4 border-village-wine border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Introduction */}
      <div className="text-center mb-8">
        <div className="flex items-center justify-center gap-2 mb-4">
          <Shield className="w-6 h-6 text-village-eucalyptus" />
          <span className="text-village-eucalyptus font-medium">All verified and background checked</span>
        </div>
        <p className="text-village-taupe/70">
          Every sitter has passed our comprehensive screening process and is ready to support your family
        </p>
      </div>

      {/* Sitter Cards */}
      <div className="grid gap-6">
        {sitters.map((sitter: Sitter) => (
          <Card 
            key={sitter.id}
            className={`cursor-pointer transition-all duration-200 hover:shadow-lg ${
              selectedSitter === sitter.id
                ? 'ring-2 ring-village-wine border-village-wine bg-village-wine/5'
                : 'border-village-wine/20 hover:border-village-wine/40'
            }`}
            onClick={() => handleSitterSelect(sitter.id)}
          >
            <CardContent className="p-6">
              <div className="flex gap-4">
                {/* Avatar */}
                <Avatar className="w-16 h-16 border-2 border-village-wine/20">
                  <AvatarImage src={sitter.photoUrl} alt={`${sitter.firstName || 'Sitter'} ${sitter.lastName || ''}`} />
                  <AvatarFallback className="bg-village-rose/20 text-village-wine font-semibold">
                    {getSitterInitials(`${sitter.firstName || 'S'} ${sitter.lastName || ''}`)}
                  </AvatarFallback>
                </Avatar>

                {/* Sitter Info */}
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="text-xl font-bold text-village-wine mb-1">
                        {sitter.firstName || 'Sitter'} {sitter.lastName ? sitter.lastName.charAt(0) + '.' : ''}
                      </h3>
                      <div className="flex items-center gap-4 text-sm text-village-taupe/70">
                        <div className="flex items-center gap-1">
                          <MapPin className="w-4 h-4" />
                          Auckland
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          {sitter.age} years old
                        </div>
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <div className="text-2xl font-bold text-village-wine">
                        ${sitter.hourlyRate}
                        <span className="text-sm font-normal text-village-taupe/70">/hour</span>
                      </div>
                      <div className="flex items-center gap-1 justify-end mt-1">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm font-medium text-village-taupe">5.0</span>
                      </div>
                    </div>
                  </div>

                  {/* Bio */}
                  <p className="text-village-taupe/80 mb-3 line-clamp-2">
                    {sitter.bio}
                  </p>

                  {/* Experience */}
                  <p className="text-sm font-medium text-village-wine mb-3">
                    {sitter.experience}
                  </p>

                  {/* Availability Tags */}
                  <div className="flex flex-wrap gap-2 mb-3">
                    {sitter.availabilityTags.slice(0, 3).map((tag, index) => (
                      <Badge 
                        key={index} 
                        variant="secondary"
                        className="bg-village-eucalyptus/20 text-village-eucalyptus border-village-eucalyptus/30 text-xs"
                      >
                        {tag}
                      </Badge>
                    ))}
                    {sitter.availabilityTags.length > 3 && (
                      <Badge 
                        variant="outline"
                        className="border-village-taupe/30 text-village-taupe text-xs"
                      >
                        +{sitter.availabilityTags.length - 3} more
                      </Badge>
                    )}
                  </div>

                  {/* Skills/Qualifications */}
                  {sitter.skills && sitter.skills.length > 0 && (
                    <div className="flex items-center gap-2 text-sm text-village-taupe/70">
                      <span>Skills:</span>
                      <span className="font-medium">{sitter.skills.slice(0, 2).map(skill => skill.name).join(', ')}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Selection Indicator */}
              {selectedSitter === sitter.userId && (
                <div className="mt-4 p-3 bg-village-wine/10 rounded-lg border border-village-wine/20">
                  <div className="flex items-center gap-2 text-village-wine">
                    <Heart className="w-4 h-4 fill-current" />
                    <span className="font-medium">Selected for your family</span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Action Buttons */}
      <div className="space-y-4 pt-6">
        {selectedSitter ? (
          <Button
            onClick={handleContinueWithSitter}
            className="w-full bg-village-wine hover:bg-village-wine/90 text-white font-medium py-3 text-lg"
          >
            Continue with {sitters.find(s => s.userId === selectedSitter)?.firstName}
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        ) : null}
        
        <Button
          onClick={handleMatchLater}
          variant="outline"
          className="w-full border-village-wine/30 text-village-wine hover:bg-village-wine/10 font-medium py-3 text-lg"
        >
          {selectedSitter ? "Actually, match me later" : "Match me later"}
          <ArrowRight className="w-5 h-5 ml-2" />
        </Button>

        <p className="text-sm text-village-taupe/60 text-center">
          Don't worry - you can always browse all our sitters and change your mind after creating your profile
        </p>
      </div>
    </div>
  );
}