import React, { useState, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { 
  User, 
  Shield, 
  Video, 
  Calendar, 
  Clock, 
  CheckCircle2, 
  Upload,
  Camera,
  FileText 
} from "lucide-react";

const profileSchema = z.object({
  firstName: z.string().min(2, "First name required"),
  lastName: z.string().min(2, "Last name required"),
  bio: z.string().min(50, "Bio must be at least 50 characters"),
  hourlyRate: z.string().min(1, "Hourly rate is required"),
  age: z.number().min(16, "Must be at least 16 years old"),
});

const credentialsSchema = z.object({
  firstAidCert: z.any().optional(),
  referee1Name: z.string().min(2, "First referee name required"),
  referee1Phone: z.string().min(10, "Valid phone number required"),
  referee2Name: z.string().min(2, "Second referee name required"),
  referee2Phone: z.string().min(10, "Valid phone number required"),
});

interface SitterOnboardingProps {
  userId: number;
  onComplete: () => void;
}

export default function SitterOnboarding({ userId, onComplete }: SitterOnboardingProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [videoBlob, setVideoBlob] = useState<Blob | null>(null);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get current sitter profile and progress
  const { data: sitterProfile } = useQuery({
    queryKey: ["/api/sitter-onboarding/progress", userId],
    enabled: !!userId,
  });

  // Calculate progress based on completion
  const getProgress = () => {
    if (!sitterProfile) return 0;
    
    const steps = {
      profileComplete: !!(sitterProfile.firstName && sitterProfile.bio && sitterProfile.hourlyRate),
      verificationUploaded: sitterProfile.verificationStatus === 'pending' || sitterProfile.verificationStatus === 'verified',
      videoUploaded: !!sitterProfile.introVideoUrl,
      callBooked: !!sitterProfile.callBookingLink
    };
    
    const completedSteps = Object.values(steps).filter(Boolean).length;
    return Math.round((completedSteps / 4) * 100);
  };

  // Profile form
  const profileForm = useForm({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      firstName: sitterProfile?.firstName || "",
      lastName: sitterProfile?.lastName || "",
      bio: sitterProfile?.bio || "",
      hourlyRate: sitterProfile?.hourlyRate || "",
      age: sitterProfile?.age || 18,
    },
  });

  // Credentials form
  const credentialsForm = useForm({
    resolver: zodResolver(credentialsSchema),
    defaultValues: {
      referee1Name: "",
      referee1Phone: "",
      referee2Name: "",
      referee2Phone: "",
    },
  });

  // Mutations
  const updateProfileMutation = useMutation({
    mutationFn: (data: any) => apiRequest("PUT", `/api/sitters/${userId}/profile`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sitter-onboarding/progress", userId] });
      toast({ title: "Profile updated successfully!" });
      setCurrentStep(2);
    },
    onError: () => {
      toast({ 
        title: "Error", 
        description: "Failed to update profile. Please try again.",
        variant: "destructive" 
      });
    },
  });

  const startVerificationMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/veriff/start-verification", { userId }),
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/sitter-onboarding/progress", userId] });
      if (data.verificationUrl) {
        window.open(data.verificationUrl, '_blank');
        toast({ title: "Verification started!", description: "Complete the ID check in the new window." });
      }
      setCurrentStep(3);
    },
    onError: () => {
      toast({ 
        title: "Error", 
        description: "Failed to start verification. Please try again.",
        variant: "destructive" 
      });
    },
  });

  const uploadVideoMutation = useMutation({
    mutationFn: (formData: FormData) => 
      fetch("/api/sitters/upload-intro-video", {
        method: "POST",
        body: formData,
        credentials: "include",
      }).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sitter-onboarding/progress", userId] });
      toast({ title: "Video uploaded successfully!" });
      setCurrentStep(4);
    },
    onError: () => {
      toast({ 
        title: "Error", 
        description: "Failed to upload video. Please try again.",
        variant: "destructive" 
      });
    },
  });

  const submitRefereesMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", `/api/sitters/${userId}/referees`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sitter-onboarding/progress", userId] });
      toast({ title: "References submitted!" });
      // Stay on step 2 until verification is complete
    },
  });

  // Video recording functions
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { width: 640, height: 480 }, 
        audio: true 
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }

      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      
      const chunks: BlobPart[] = [];
      mediaRecorder.ondataavailable = (event) => {
        chunks.push(event.data);
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'video/webm' });
        setVideoBlob(blob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      
      // Start timer
      const timer = setInterval(() => {
        setRecordingTime(prev => {
          if (prev >= 60) { // 60 second limit
            stopRecording();
            return 0;
          }
          return prev + 1;
        });
      }, 1000);

      setTimeout(() => clearInterval(timer), 61000);
      
    } catch (error) {
      toast({ 
        title: "Camera Error", 
        description: "Please allow camera access to record your introduction.",
        variant: "destructive" 
      });
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      setRecordingTime(0);
    }
  };

  const uploadVideo = () => {
    if (!videoBlob) return;

    const formData = new FormData();
    formData.append('video', videoBlob, 'intro-video.webm');
    formData.append('userId', userId.toString());
    
    uploadVideoMutation.mutate(formData);
  };

  // Form handlers
  const handleUpdateProfile = (data: any) => {
    updateProfileMutation.mutate(data);
  };

  const handleSubmitCredentials = (data: any) => {
    // Start Veriff verification
    startVerificationMutation.mutate();
    
    // Submit referee information
    submitRefereesMutation.mutate(data);
  };

  const handleBookCall = () => {
    // Open Calendly or booking modal
    window.open('https://calendly.com/thevillageco/sitter-interview', '_blank');
    toast({ 
      title: "Call Booking", 
      description: "Book your intro call in the new window. We'll update your status once complete." 
    });
  };

  const progress = getProgress();

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 p-4">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome to The Village Co.</h1>
          <p className="text-lg text-gray-600">Real families are counting on real humans. Let's get you started.</p>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between text-sm text-gray-600 mb-2">
            <span>Progress</span>
            <span>{progress}% complete</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Step 1: Profile Setup */}
        {currentStep === 1 && (
          <Card className="mb-6">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <User className="w-8 h-8 text-purple-600" />
              </div>
              <CardTitle>Profile Setup</CardTitle>
              <CardDescription>
                This is what parents see first — make it shine ✨
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={profileForm.handleSubmit(handleUpdateProfile)} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName">First Name</Label>
                    <Input
                      id="firstName"
                      {...profileForm.register("firstName")}
                      placeholder="Enter first name"
                    />
                    {profileForm.formState.errors.firstName && (
                      <p className="text-sm text-red-600 mt-1">
                        {profileForm.formState.errors.firstName.message}
                      </p>
                    )}
                  </div>
                  <div>
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input
                      id="lastName"
                      {...profileForm.register("lastName")}
                      placeholder="Enter last name"
                    />
                    {profileForm.formState.errors.lastName && (
                      <p className="text-sm text-red-600 mt-1">
                        {profileForm.formState.errors.lastName.message}
                      </p>
                    )}
                  </div>
                </div>

                <div>
                  <Label htmlFor="age">Age</Label>
                  <Input
                    id="age"
                    type="number"
                    min="16"
                    max="65"
                    {...profileForm.register("age", { valueAsNumber: true })}
                    placeholder="18"
                  />
                  {profileForm.formState.errors.age && (
                    <p className="text-sm text-red-600 mt-1">
                      {profileForm.formState.errors.age.message}
                    </p>
                  )}
                </div>

                <div>
                  <Label htmlFor="hourlyRate">Hourly Rate (NZD)</Label>
                  <Input
                    id="hourlyRate"
                    {...profileForm.register("hourlyRate")}
                    placeholder="25.00"
                  />
                  {profileForm.formState.errors.hourlyRate && (
                    <p className="text-sm text-red-600 mt-1">
                      {profileForm.formState.errors.hourlyRate.message}
                    </p>
                  )}
                </div>

                <div>
                  <Label htmlFor="bio">About You</Label>
                  <Textarea
                    id="bio"
                    {...profileForm.register("bio")}
                    placeholder="Tell parents about your experience with children, what you love about babysitting, and what makes you special..."
                    rows={4}
                  />
                  <p className="text-sm text-gray-500 mt-1">
                    Minimum 50 characters ({(profileForm.watch("bio") || "").length}/50)
                  </p>
                  {profileForm.formState.errors.bio && (
                    <p className="text-sm text-red-600 mt-1">
                      {profileForm.formState.errors.bio.message}
                    </p>
                  )}
                </div>

                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={updateProfileMutation.isPending}
                >
                  {updateProfileMutation.isPending ? "Saving..." : "Continue"}
                </Button>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Step 2: Upload Credentials */}
        {currentStep === 2 && (
          <Card className="mb-6">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-blue-600" />
              </div>
              <CardTitle>Upload Credentials</CardTitle>
              <CardDescription>
                Trust is everything. Upload your ID and referee contacts here.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={credentialsForm.handleSubmit(handleSubmitCredentials)} className="space-y-6">
                {/* Veriff ID Check */}
                <div className="p-4 border rounded-lg">
                  <div className="flex items-center space-x-3 mb-3">
                    <FileText className="w-5 h-5 text-blue-600" />
                    <h3 className="font-medium">Identity Verification</h3>
                  </div>
                  <p className="text-sm text-gray-600 mb-3">
                    We use Veriff for secure ID verification. You'll need a government-issued photo ID.
                  </p>
                  {sitterProfile?.verificationStatus === 'verified' ? (
                    <div className="flex items-center text-green-600">
                      <CheckCircle2 className="w-4 h-4 mr-2" />
                      <span className="text-sm">ID Verified</span>
                    </div>
                  ) : (
                    <p className="text-sm text-orange-600">Will start verification when you submit this form</p>
                  )}
                </div>

                {/* References */}
                <div className="space-y-4">
                  <h3 className="font-medium">References (2 required)</h3>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="referee1Name">First Reference Name</Label>
                      <Input
                        id="referee1Name"
                        {...credentialsForm.register("referee1Name")}
                        placeholder="Full name"
                      />
                      {credentialsForm.formState.errors.referee1Name && (
                        <p className="text-sm text-red-600 mt-1">
                          {credentialsForm.formState.errors.referee1Name.message}
                        </p>
                      )}
                    </div>
                    <div>
                      <Label htmlFor="referee1Phone">Phone Number</Label>
                      <Input
                        id="referee1Phone"
                        type="tel"
                        {...credentialsForm.register("referee1Phone")}
                        placeholder="027 123 4567"
                      />
                      {credentialsForm.formState.errors.referee1Phone && (
                        <p className="text-sm text-red-600 mt-1">
                          {credentialsForm.formState.errors.referee1Phone.message}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="referee2Name">Second Reference Name</Label>
                      <Input
                        id="referee2Name"
                        {...credentialsForm.register("referee2Name")}
                        placeholder="Full name"
                      />
                      {credentialsForm.formState.errors.referee2Name && (
                        <p className="text-sm text-red-600 mt-1">
                          {credentialsForm.formState.errors.referee2Name.message}
                        </p>
                      )}
                    </div>
                    <div>
                      <Label htmlFor="referee2Phone">Phone Number</Label>
                      <Input
                        id="referee2Phone"
                        type="tel"
                        {...credentialsForm.register("referee2Phone")}
                        placeholder="027 123 4567"
                      />
                      {credentialsForm.formState.errors.referee2Phone && (
                        <p className="text-sm text-red-600 mt-1">
                          {credentialsForm.formState.errors.referee2Phone.message}
                        </p>
                      )}
                    </div>
                  </div>
                </div>

                <Button 
                  type="submit" 
                  className="w-full"
                  disabled={startVerificationMutation.isPending || submitRefereesMutation.isPending}
                >
                  {(startVerificationMutation.isPending || submitRefereesMutation.isPending) 
                    ? "Processing..." 
                    : "Submit & Start Verification"
                  }
                </Button>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Step 3: Intro Video */}
        {currentStep === 3 && (
          <Card className="mb-6">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Video className="w-8 h-8 text-green-600" />
              </div>
              <CardTitle>Intro Video</CardTitle>
              <CardDescription>
                A friendly face goes a long way. Parents love to hear your vibe.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 bg-blue-50 rounded-lg">
                  <h3 className="font-medium mb-2">Video Tips:</h3>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• Keep it to 30-60 seconds</li>
                    <li>• Introduce yourself and share your experience</li>
                    <li>• Let your personality shine through!</li>
                    <li>• Find good lighting and speak clearly</li>
                  </ul>
                </div>

                {!videoBlob && (
                  <div className="text-center">
                    <video
                      ref={videoRef}
                      autoPlay
                      muted
                      className="w-full max-w-md mx-auto rounded-lg mb-4"
                      style={{ display: isRecording ? 'block' : 'none' }}
                    />
                    
                    {!isRecording && (
                      <div className="mb-4">
                        <Camera className="w-16 h-16 text-gray-400 mx-auto mb-2" />
                        <p className="text-gray-600">Ready to record your introduction?</p>
                      </div>
                    )}

                    {isRecording && (
                      <div className="mb-4">
                        <div className="flex items-center justify-center space-x-2">
                          <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
                          <span className="text-red-600 font-medium">Recording... {recordingTime}s</span>
                        </div>
                      </div>
                    )}

                    <div className="space-x-4">
                      {!isRecording ? (
                        <Button onClick={startRecording} size="lg">
                          <Camera className="w-4 h-4 mr-2" />
                          Start Recording
                        </Button>
                      ) : (
                        <Button onClick={stopRecording} variant="destructive" size="lg">
                          Stop Recording
                        </Button>
                      )}
                    </div>
                  </div>
                )}

                {videoBlob && (
                  <div className="text-center">
                    <video
                      controls
                      className="w-full max-w-md mx-auto rounded-lg mb-4"
                      src={URL.createObjectURL(videoBlob)}
                    />
                    
                    <div className="space-x-4">
                      <Button onClick={() => setVideoBlob(null)} variant="outline">
                        Record Again
                      </Button>
                      <Button 
                        onClick={uploadVideo}
                        disabled={uploadVideoMutation.isPending}
                      >
                        {uploadVideoMutation.isPending ? "Uploading..." : "Upload Video"}
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Step 4: Book Intro Call */}
        {currentStep === 4 && (
          <Card className="mb-6">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Calendar className="w-8 h-8 text-orange-600" />
              </div>
              <CardTitle>Final Step: Call With The Village</CardTitle>
              <CardDescription>
                Every sitter speaks to a real human before joining
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <div className="space-y-4">
                <div className="p-4 bg-orange-50 rounded-lg">
                  <Clock className="w-8 h-8 text-orange-600 mx-auto mb-2" />
                  <p className="text-sm text-orange-800">
                    Quick 15-minute chat to welcome you to the village and answer any questions.
                  </p>
                </div>
                
                <Button onClick={handleBookCall} size="lg" className="w-full">
                  <Calendar className="w-4 h-4 mr-2" />
                  Book Your Call
                </Button>

                <p className="text-sm text-gray-600">
                  We'll confirm your profile after your ID verification and intro call are complete.
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Pending Review Screen */}
        {sitterProfile?.introCallCompleted && sitterProfile?.verificationStatus === 'verified' && (
          <Card className="mb-6">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle2 className="w-8 h-8 text-green-600" />
              </div>
              <CardTitle>You're Almost There!</CardTitle>
              <CardDescription>
                Thank you! We'll be in touch after your verification + call are complete.
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <div className="space-y-4">
                <div className="p-4 bg-green-50 rounded-lg">
                  <p className="text-sm text-green-800">
                    Your profile is under review. You'll receive an email once approved and can start receiving bookings!
                  </p>
                </div>
                
                <Button onClick={onComplete} className="w-full">
                  Continue to Dashboard
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}