import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2 } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

export default function VerificationTest() {
  const [isLoading, setIsLoading] = useState(false);
  const [response, setResponse] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const testVerificationAPI = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      // Test the status endpoint
      const statusResponse = await apiRequest('GET', '/api/sitter-verification/status');
      const statusData = await statusResponse.json();
      
      // Test the start endpoint
      const startResponse = await apiRequest('POST', '/api/sitter-verification/start', {});
      const startData = await startResponse.json();
      
      setResponse({
        status: statusData,
        start: startData
      });
      
      toast({
        title: 'Verification Test Successful',
        description: 'API endpoints are working correctly.',
      });
    } catch (err) {
      console.error('Error testing verification API:', err);
      setError(err instanceof Error ? err.message : String(err));
      
      toast({
        variant: 'destructive',
        title: 'Verification Test Failed',
        description: 'Check console for details.',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Verification API Test</CardTitle>
      </CardHeader>
      <CardContent>
        <Button 
          onClick={testVerificationAPI}
          disabled={isLoading}
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Testing...
            </>
          ) : (
            'Test Verification API'
          )}
        </Button>
        
        {error && (
          <Alert variant="destructive" className="mt-4">
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        
        {response && (
          <div className="mt-4 p-4 bg-muted rounded-md">
            <h3 className="font-medium mb-2">Test Results:</h3>
            <pre className="text-xs whitespace-pre-wrap overflow-auto max-h-[300px]">
              {JSON.stringify(response, null, 2)}
            </pre>
          </div>
        )}
      </CardContent>
    </Card>
  );
}