import React, { useState, useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Edit3 } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { 
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts';

interface SitterEarningsProps {
  totalBookings: number;
  totalEarned: number;
  monthlyEarnings?: Array<{
    month: string;
    amount: number;
  }>;
  targetEarnings?: number;
  onTargetUpdate?: (newTarget: number) => void;
}

/**
 * Format currency in NZD format
 */
const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-NZ', {
    style: 'currency',
    currency: 'NZD',
    minimumFractionDigits: 2
  }).format(amount);
};

export function SitterEarnings({ 
  totalBookings, 
  totalEarned,
  monthlyEarnings = [],
  targetEarnings = 1000,
  onTargetUpdate
}: SitterEarningsProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch the sitter profile to get the most current monthly target
  const { data: sitterProfile } = useQuery<any>({
    queryKey: ['/api/sitter/profile'],
    staleTime: 0, // Always fetch fresh data
  });

  // Use the target from the fresh profile data, fallback to prop
  const currentTarget = sitterProfile?.monthlyTargetEarnings 
    ? parseFloat(sitterProfile.monthlyTargetEarnings) 
    : targetEarnings;

  const [newTarget, setNewTarget] = useState(currentTarget.toString());

  // Update newTarget when currentTarget changes
  useEffect(() => {
    setNewTarget(currentTarget.toString());
  }, [currentTarget]);
  
  const progressPercentage = Math.min(100, (totalEarned / currentTarget) * 100);

  const handleUpdateTarget = async () => {
    const targetValue = parseFloat(newTarget);
    
    if (isNaN(targetValue) || targetValue < 50) {
      toast({
        title: "Invalid Target",
        description: "Monthly target must be at least $50",
        variant: "destructive",
      });
      return;
    }

    if (targetValue > 5000) {
      toast({
        title: "Invalid Target", 
        description: "Monthly target cannot exceed $5,000",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const response = await apiRequest("PUT", "/api/sitter/monthly-target", {
        monthlyTarget: targetValue
      });

      if (response.ok) {
        // Invalidate cache to refresh the sitter profile data
        await queryClient.invalidateQueries({ queryKey: ['/api/sitter/profile'] });
        
        toast({
          title: "Target Updated",
          description: `Monthly target set to ${formatCurrency(targetValue)}`,
        });
        setIsEditing(false);
        if (onTargetUpdate) {
          onTargetUpdate(targetValue);
        }
      } else {
        throw new Error("Failed to update target");
      }
    } catch (error) {
      toast({
        title: "Update Failed",
        description: "Could not update monthly target. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-xl flex items-center">
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            width="20" 
            height="20" 
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="currentColor" 
            strokeWidth="2" 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            className="mr-2 text-wine"
          >
            <circle cx="12" cy="12" r="10" />
            <path d="M12 6v12" />
            <path d="M16 10H8" />
          </svg>
          Earnings Summary
        </CardTitle>
        <CardDescription>
          Track your income from babysitting sessions
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="monthly">Monthly Stats</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="rounded-lg bg-linen/40 p-4">
                <h3 className="text-sm font-medium text-muted-foreground mb-1">
                  Bookings Completed
                </h3>
                <p className="text-2xl font-bold">
                  {totalBookings}
                </p>
              </div>
              
              <div className="rounded-lg bg-rose/10 p-4">
                <h3 className="text-sm font-medium text-muted-foreground mb-1">
                  Total Earned
                </h3>
                <p className="text-2xl font-bold text-wine">
                  {formatCurrency(totalEarned)}
                </p>
              </div>
            </div>
            
            <div className="mt-6 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Monthly Target</span>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">{formatCurrency(currentTarget)}</span>
                  <Dialog open={isEditing} onOpenChange={setIsEditing}>
                    <DialogTrigger asChild>
                      <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                        <Edit3 className="h-3 w-3" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="sm:max-w-md">
                      <DialogHeader>
                        <DialogTitle>Update Monthly Target</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <label htmlFor="target" className="text-sm font-medium">
                            Monthly Earnings Target (NZD)
                          </label>
                          <Input
                            id="target"
                            type="number"
                            value={newTarget}
                            onChange={(e) => setNewTarget(e.target.value)}
                            placeholder="Enter amount ($50 - $5,000)"
                            min="50"
                            max="5000"
                            step="50"
                          />
                          <p className="text-xs text-muted-foreground">
                            Range: $50 - $5,000
                          </p>
                        </div>
                        <div className="flex justify-end gap-3">
                          <Button 
                            variant="outline" 
                            onClick={() => setIsEditing(false)}
                            disabled={isLoading}
                          >
                            Cancel
                          </Button>
                          <Button 
                            onClick={handleUpdateTarget}
                            disabled={isLoading}
                            className="bg-[#6b3e4b] hover:bg-[#5a3240]"
                          >
                            {isLoading ? "Updating..." : "Update Target"}
                          </Button>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </div>
              <Progress value={progressPercentage} className="h-2" />
              <p className="text-xs text-muted-foreground text-right">
                {progressPercentage.toFixed(0)}% of monthly target
              </p>
            </div>
          </TabsContent>
          
          <TabsContent value="monthly">
            {monthlyEarnings.length > 0 ? (
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={monthlyEarnings}
                    margin={{
                      top: 10,
                      right: 10,
                      left: 10,
                      bottom: 20,
                    }}
                  >
                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                    <XAxis dataKey="month" />
                    <YAxis 
                      tickFormatter={(value) => `$${value}`}
                      width={50}
                    />
                    <Tooltip 
                      formatter={(value) => [`$${value}`, 'Earnings']}
                      contentStyle={{
                        backgroundColor: '#fff',
                        border: '1px solid #ddd',
                        borderRadius: '4px',
                      }}
                    />
                    <Bar 
                      dataKey="amount" 
                      fill="#6B3E4B" 
                      radius={[4, 4, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                No monthly data available yet
              </div>
            )}
          </TabsContent>
        </Tabs>
        
        <p className="text-xs text-muted-foreground mt-6">
          * Based on confirmed/completed sits. Platform fees have been deducted.
        </p>
      </CardContent>
    </Card>
  );
}