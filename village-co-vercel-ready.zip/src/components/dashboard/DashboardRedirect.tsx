import React, { useEffect } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { USER_ROLES } from '@shared/schema';

interface DashboardRedirectProps {
  user?: {
    id: string;
    role?: string;
  } | null;
}

/**
 * Component that redirects users to the appropriate dashboard based on their role
 */
export function DashboardRedirect({ user }: DashboardRedirectProps) {
  const { user: authUser } = useAuth();
  const [, navigate] = useLocation();
  const activeUser = user || authUser;

  useEffect(() => {
    if (!activeUser) {
      navigate('/login');
      return;
    }

    const getRoleAndRedirect = async () => {
      // If user already has role from auth context, use that
      if (activeUser.role) {
        redirectByRole(activeUser.role);
        return;
      }

      try {
        // Otherwise fetch from database
        const { data, error } = await supabase
          .from('users')
          .select('role')
          .eq('id', activeUser.id)
          .single();

        if (error) {
          console.error('Error fetching user role:', error);
          navigate('/dashboard'); // Fallback to generic dashboard
          return;
        }

        redirectByRole(data?.role);
      } catch (error) {
        console.error('Unexpected error:', error);
        navigate('/dashboard');
      }
    };

    const redirectByRole = (role?: string) => {
      if (role === USER_ROLES.PARENT) {
        navigate('/parent/dashboard');
      } else if (role === USER_ROLES.SITTER) {
        navigate('/sitter/dashboard');
      } else if (role === USER_ROLES.ADMIN) {
        navigate('/admin/dashboard');
      } else {
        // If role is undefined or not recognized, redirect to onboarding
        navigate('/onboarding');
      }
    };

    getRoleAndRedirect();
  }, [activeUser, navigate]);

  // Render a loading state while redirecting
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="flex flex-col items-center gap-4">
        <div className="animate-spin h-8 w-8 border-4 border-wine border-t-transparent rounded-full"></div>
        <p className="text-muted-foreground">Redirecting to your dashboard...</p>
      </div>
    </div>
  );
}