import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { X, Play, Star } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useAuth } from '@/hooks/useAuth';

interface SitterPhoto {
  id: number;
  sitterId: number;
  photoUrl: string;
  caption?: string;
  isPrimary: boolean;
  displayOrder: number;
  createdAt: string;
  updatedAt: string;
}

interface SitterVideo {
  id: number;
  sitterId: number;
  videoUrl: string;
  thumbnailUrl?: string;
  title?: string;
  description?: string;
  durationSeconds?: number;
  isIntroVideo: boolean;
  createdAt: string;
  updatedAt: string;
}

interface SitterMediaGalleryProps {
  sitterId: number;
  isOwner?: boolean;
  refreshTrigger?: number;
}

export default function SitterMediaGallery({ sitterId, isOwner = false, refreshTrigger }: SitterMediaGalleryProps) {
  const { toast } = useToast();
  const { user } = useAuth();
  const [photos, setPhotos] = useState<SitterPhoto[]>([]);
  const [videos, setVideos] = useState<SitterVideo[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchMedia = async () => {
    try {
      setLoading(true);
      
      // Fetch photos
      const photosResponse = await apiRequest('GET', `/api/sitter-media/${sitterId}/photos`);
      if (photosResponse.ok) {
        const photosData = await photosResponse.json();
        setPhotos(photosData);
      }

      // Fetch videos
      const videosResponse = await apiRequest('GET', `/api/sitter-media/${sitterId}/videos`);
      if (videosResponse.ok) {
        const videosData = await videosResponse.json();
        setVideos(videosData);
      }

    } catch (error) {
      console.error('Error fetching media:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMedia();
  }, [sitterId, refreshTrigger]);

  const deletePhoto = async (photoId: number) => {
    if (!isOwner) return;
    
    try {
      const response = await apiRequest('DELETE', `/api/sitter-media/photos/${photoId}`);
      
      if (response.ok) {
        setPhotos(prev => prev.filter(photo => photo.id !== photoId));
        toast({
          title: "Photo deleted",
          description: "Photo has been removed from your profile"
        });
      }
    } catch (error: any) {
      toast({
        title: "Delete failed",
        description: error.message || "Failed to delete photo",
        variant: "destructive"
      });
    }
  };

  const deleteVideo = async (videoId: number) => {
    if (!isOwner) return;
    
    try {
      const response = await apiRequest('DELETE', `/api/sitter-media/videos/${videoId}`);
      
      if (response.ok) {
        setVideos(prev => prev.filter(video => video.id !== videoId));
        toast({
          title: "Video deleted",
          description: "Video has been removed from your profile"
        });
      }
    } catch (error: any) {
      toast({
        title: "Delete failed", 
        description: error.message || "Failed to delete video",
        variant: "destructive"
      });
    }
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="aspect-square bg-gray-200 rounded-lg animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Photos Section */}
      {photos.length > 0 && (
        <div>
          <h3 className="text-lg font-medium mb-4">Photos</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {photos.map((photo) => (
              <div key={photo.id} className="relative group">
                <div className="aspect-square overflow-hidden rounded-lg">
                  <img
                    src={photo.photoUrl}
                    alt={photo.caption || 'Sitter photo'}
                    className="w-full h-full object-cover transition-transform group-hover:scale-105"
                  />
                </div>
                
                {photo.isPrimary && (
                  <Badge className="absolute top-2 left-2 bg-yellow-500 text-white">
                    <Star className="h-3 w-3 mr-1" />
                    Primary
                  </Badge>
                )}
                
                {isOwner && (
                  <Button
                    variant="destructive"
                    size="sm"
                    className="absolute top-2 right-2 h-8 w-8 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={() => deletePhoto(photo.id)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                )}
                
                {photo.caption && (
                  <div className="absolute bottom-0 left-0 right-0 bg-black/75 text-white p-2 text-sm">
                    {photo.caption}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Videos Section */}
      {videos.length > 0 && (
        <div>
          <h3 className="text-lg font-medium mb-4">Videos</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {videos.map((video) => (
              <Card key={video.id} className="overflow-hidden">
                <div className="relative">
                  <video
                    src={video.videoUrl}
                    poster={video.thumbnailUrl}
                    controls
                    className="w-full aspect-video"
                  />
                  
                  {video.isIntroVideo && (
                    <Badge className="absolute top-2 left-2 bg-blue-500 text-white">
                      <Play className="h-3 w-3 mr-1" />
                      Intro Video
                    </Badge>
                  )}
                  
                  {isOwner && (
                    <Button
                      variant="destructive"
                      size="sm"
                      className="absolute top-2 right-2 h-8 w-8 p-0"
                      onClick={() => deleteVideo(video.id)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  )}
                </div>
                
                {(video.title || video.description) && (
                  <CardContent className="p-4">
                    {video.title && (
                      <h4 className="font-medium mb-2">{video.title}</h4>
                    )}
                    {video.description && (
                      <p className="text-sm text-gray-600">{video.description}</p>
                    )}
                  </CardContent>
                )}
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Empty State */}
      {photos.length === 0 && videos.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          {isOwner ? (
            <p>No photos or videos uploaded yet. Add some media to showcase your personality!</p>
          ) : (
            <p>No photos or videos available for this sitter.</p>
          )}
        </div>
      )}
    </div>
  );
}