import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Brain, 
  MessageSquare, 
  Calendar, 
  Shield, 
  TrendingUp, 
  Sparkles,
  Clock,
  AlertTriangle,
  CheckCircle,
  Users,
  Send,
  Heart,
  Coffee,
  Moon,
  Star,
  Briefcase,
  GraduationCap,
  Copy
} from "lucide-react";

interface VillageAIAssistantProps {
  userRole: "parent" | "sitter" | "admin";
}

export default function VillageAIAssistant({ userRole }: VillageAIAssistantProps) {
  const [activeTab, setActiveTab] = useState("sitter-ready");
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<any>(null);
  const [workingMumMode, setWorkingMumMode] = useState(false);
  const [schoolHolidayMode, setSchoolHolidayMode] = useState(false);
  const { toast } = useToast();

  // Form states
  const [sitNotes, setSitNotes] = useState("");
  const [duration, setDuration] = useState(3);
  const [selectedSitterId, setSelectedSitterId] = useState("");
  const [messageType, setMessageType] = useState("booking_request");
  const [sitterName, setSitterName] = useState("");
  const [specificContext, setSpecificContext] = useState("");

  // API Functions with warm, encouraging messaging
  const checkSitterReady = async () => {
    if (!sitNotes.trim()) return;
    
    setLoading(true);
    try {
      const response = await apiRequest("POST", "/api/ai/analyze-booking", {
        sitNotes,
        duration,
        workingMumMode,
        schoolHolidayMode
      });

      if (response.ok) {
        const data = await response.json();
        setResults(data.analysis);
        toast({
          title: "All sorted! ✨",
          description: "Your sitter checklist is ready. You're doing amazing, by the way.",
        });
      }
    } catch (error) {
      toast({
        title: "Oops!",
        description: "Something went wrong. Let's try that again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const checkMyRoutine = async () => {
    setLoading(true);
    try {
      const response = await apiRequest("POST", "/api/ai/booking-patterns", {
        workingMumMode,
        schoolHolidayMode
      });

      if (response.ok) {
        const data = await response.json();
        setResults(data.patterns);
        toast({
          title: "Your routine revealed! 📊",
          description: "Spotted some interesting patterns in your bookings.",
        });
      }
    } catch (error) {
      toast({
        title: "Hmm, that didn't work",
        description: "Let's give it another go.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const checkNextNightOff = async () => {
    setLoading(true);
    try {
      const response = await apiRequest("POST", "/api/ai/break-reminder", {
        workingMumMode,
        schoolHolidayMode
      });

      if (response.ok) {
        const data = await response.json();
        setResults(data.reminder);
        toast({
          title: "Time for some you-time! 🌙",
          description: "It's been 2 weeks. You deserve this.",
        });
      }
    } catch (error) {
      toast({
        title: "Couldn't check your break schedule",
        description: "Try again in a moment.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const planMyWeek = async () => {
    setLoading(true);
    try {
      const response = await apiRequest("POST", "/api/ai/smart-scheduling", {
        preferences: specificContext,
        workingMumMode,
        schoolHolidayMode
      });

      if (response.ok) {
        const data = await response.json();
        setResults(data.suggestions);
        toast({
          title: "Week planned! 📅",
          description: "Here are your perfect booking times.",
        });
      }
    } catch (error) {
      toast({
        title: "Planning hiccup",
        description: "Let me try that again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const helpWithMessage = async () => {
    if (!sitterName.trim()) return;
    
    setLoading(true);
    try {
      const response = await apiRequest("POST", "/api/ai/communication-help", {
        messageType,
        sitterName,
        context: specificContext,
        workingMumMode,
        schoolHolidayMode
      });

      if (response.ok) {
        const data = await response.json();
        setResults(data.suggestions);
        toast({
          title: "Message ready! 💬",
          description: "Perfectly crafted and ready to send.",
        });
      }
    } catch (error) {
      toast({
        title: "Message help failed",
        description: "Let's try writing that again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied! ✨",
      description: "Ready to paste wherever you need it.",
    });
  };

  const renderResults = () => {
    if (!results) return null;

    return (
      <Card className="mt-6 bg-gradient-to-r from-emerald-50 to-blue-50 border-emerald-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-emerald-800">
            <Sparkles className="h-5 w-5" />
            Your Results
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Array.isArray(results) ? (
              results.map((item: any, index: number) => (
                <div key={index} className="p-4 bg-white rounded-lg shadow-sm border">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900">{item.title || item.type}</h4>
                      <p className="text-gray-600 mt-1">{item.description || item.message}</p>
                      {item.action && (
                        <Button
                          size="sm"
                          className="mt-3 bg-[#8B4B5C] hover:bg-[#7A4051]"
                          onClick={() => item.action()}
                        >
                          {item.actionText}
                        </Button>
                      )}
                    </div>
                    {item.priority && (
                      <Badge 
                        variant={item.priority === 'high' ? 'destructive' : 'secondary'}
                        className="ml-2"
                      >
                        {item.priority}
                      </Badge>
                    )}
                  </div>
                </div>
              ))
            ) : (
              <div className="p-4 bg-white rounded-lg shadow-sm border">
                <p className="text-gray-700">{results.message || JSON.stringify(results, null, 2)}</p>
                {results.suggestions && (
                  <div className="mt-4 space-y-2">
                    {results.suggestions.map((suggestion: string, index: number) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                        <span className="text-sm">{suggestion}</span>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => copyToClipboard(suggestion)}
                        >
                          <Copy className="h-3 w-3" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
          
          {/* Fun affirmation */}
          <div className="mt-6 p-4 bg-gradient-to-r from-pink-100 to-rose-100 rounded-lg border border-pink-200">
            <p className="text-pink-800 text-center font-medium">
              You're doing amazing, by the way. 🌟
            </p>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 to-orange-50">
      <div className="max-w-4xl mx-auto p-4 md:p-6">
        {/* Hero Section with Village Co. warmth */}
        <div className="text-center mb-8 bg-white p-8 rounded-xl shadow-sm">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Heart className="h-10 w-10 text-[#8B4B5C]" />
            <Sparkles className="h-8 w-8 text-amber-500" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Your parenting co-pilot, built for sanity.
          </h1>
          <p className="text-lg text-gray-600 mb-6 max-w-2xl mx-auto leading-relaxed">
            We've trained our AI to think like a village — not an algorithm.
          </p>
          
          {/* Mode Toggles */}
          <div className="flex flex-col sm:flex-row gap-6 items-center justify-center mb-6">
            <div className="flex items-center space-x-3">
              <Switch
                id="working-mum-mode"
                checked={workingMumMode}
                onCheckedChange={setWorkingMumMode}
              />
              <Label htmlFor="working-mum-mode" className="flex items-center gap-2 text-sm font-medium">
                <Briefcase className="h-4 w-4 text-blue-600" />
                Working Mum Mode
              </Label>
            </div>
            <div className="flex items-center space-x-3">
              <Switch
                id="school-holiday-mode"
                checked={schoolHolidayMode}
                onCheckedChange={setSchoolHolidayMode}
              />
              <Label htmlFor="school-holiday-mode" className="flex items-center gap-2 text-sm font-medium">
                <GraduationCap className="h-4 w-4 text-emerald-600" />
                School Holiday Mode
              </Label>
            </div>
          </div>

          <Badge className="bg-[#8B4B5C] text-white px-4 py-2">
            <Heart className="h-3 w-3 mr-2" />
            Powered by AI + Village Love
          </Badge>
        </div>

        {/* How It Helps Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-white/80 backdrop-blur-sm border-none shadow-sm">
            <CardContent className="p-6 text-center">
              <Brain className="h-8 w-8 text-[#8B4B5C] mx-auto mb-3" />
              <h3 className="font-semibold text-gray-900 mb-2">Knows your needs</h3>
              <p className="text-sm text-gray-600">Bedtime? Pet allergies? Favourite games? We remember it all.</p>
            </CardContent>
          </Card>
          
          <Card className="bg-white/80 backdrop-blur-sm border-none shadow-sm">
            <CardContent className="p-6 text-center">
              <AlertTriangle className="h-8 w-8 text-[#8B4B5C] mx-auto mb-3" />
              <h3 className="font-semibold text-gray-900 mb-2">Anticipates the chaos</h3>
              <p className="text-sm text-gray-600">Get a nudge when it's time to book for the school holidays.</p>
            </CardContent>
          </Card>
          
          <Card className="bg-white/80 backdrop-blur-sm border-none shadow-sm">
            <CardContent className="p-6 text-center">
              <Heart className="h-8 w-8 text-[#8B4B5C] mx-auto mb-3" />
              <h3 className="font-semibold text-gray-900 mb-2">Keeps it personal</h3>
              <p className="text-sm text-gray-600">Smart, but never robotic. You're still in charge.</p>
            </CardContent>
          </Card>
        </div>

        {/* Social Proof */}
        <Card className="bg-gradient-to-r from-pink-50 to-rose-50 border-pink-100 mb-8">
          <CardContent className="p-6 text-center">
            <blockquote className="text-lg text-gray-700 italic mb-2">
              "It felt like it knew exactly what I needed before I even opened the app."
            </blockquote>
            <cite className="text-sm text-gray-500">— Emma, new mum</cite>
          </CardContent>
        </Card>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 gap-1 h-auto p-1 bg-white/70 backdrop-blur-sm">
            <TabsTrigger 
              value="sitter-ready" 
              className="flex flex-col items-center gap-2 text-xs p-4 min-h-[5rem] data-[state=active]:bg-white data-[state=active]:shadow-md"
            >
              <CheckCircle className="h-6 w-6" />
              <span className="font-medium">Is My Sitter Ready?</span>
            </TabsTrigger>
            
            <TabsTrigger 
              value="my-routine" 
              className="flex flex-col items-center gap-2 text-xs p-4 min-h-[5rem] data-[state=active]:bg-white data-[state=active]:shadow-md"
            >
              <Coffee className="h-6 w-6" />
              <span className="font-medium">What's My Routine?</span>
            </TabsTrigger>
            
            <TabsTrigger 
              value="next-night-off" 
              className="flex flex-col items-center gap-2 text-xs p-4 min-h-[5rem] data-[state=active]:bg-white data-[state=active]:shadow-md"
            >
              <Moon className="h-6 w-6" />
              <span className="font-medium">Next Night Off?</span>
            </TabsTrigger>
            
            <TabsTrigger 
              value="plan-my-week" 
              className="flex flex-col items-center gap-2 text-xs p-4 min-h-[5rem] data-[state=active]:bg-white data-[state=active]:shadow-md"
            >
              <Calendar className="h-6 w-6" />
              <span className="font-medium">Plan My Week</span>
            </TabsTrigger>
          </TabsList>

          {/* Is My Sitter Ready? */}
          <TabsContent value="sitter-ready" className="mt-6">
            <Card className="bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-xl">
                  <CheckCircle className="h-6 w-6 text-emerald-600" />
                  Is My Sitter Ready? 🌟
                </CardTitle>
                <CardDescription className="text-base">
                  Quick check to make sure your sitter has everything sorted. Think of it as your peace-of-mind checklist before they arrive.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label htmlFor="sit-notes" className="text-base font-medium text-gray-700 mb-2 block">
                    Tell me about tonight's sit 💭
                  </Label>
                  <Textarea
                    id="sit-notes"
                    placeholder="e.g., 'Jess has a school trip Friday, please remind her to pack her lunch. Ollie skipped his nap today so might be extra tired. We're running a bit behind on dinner prep...'"
                    value={sitNotes}
                    onChange={(e) => setSitNotes(e.target.value)}
                    className="min-h-[120px] text-base"
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="duration" className="text-sm font-medium">How many hours?</Label>
                    <Input
                      id="duration"
                      type="number"
                      value={duration}
                      onChange={(e) => setDuration(parseInt(e.target.value))}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="sitter-select" className="text-sm font-medium">Which sitter?</Label>
                    <Select value={selectedSitterId} onValueChange={setSelectedSitterId}>
                      <SelectTrigger className="mt-1">
                        <SelectValue placeholder="Choose your sitter" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">Sarah M.</SelectItem>
                        <SelectItem value="2">Emma L.</SelectItem>
                        <SelectItem value="3">Rachel T.</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Button 
                  onClick={checkSitterReady} 
                  disabled={loading || !sitNotes.trim()}
                  className="w-full bg-[#8B4B5C] hover:bg-[#7A4051] text-white py-3 text-base"
                >
                  {loading ? (
                    <>
                      <Sparkles className="mr-2 h-5 w-5 animate-spin" />
                      Checking everything...
                    </>
                  ) : (
                    <>
                      <CheckCircle className="mr-2 h-5 w-5" />
                      Check Credentials + Extras
                    </>
                  )}
                </Button>

                {renderResults()}
              </CardContent>
            </Card>
          </TabsContent>

          {/* What's My Routine? */}
          <TabsContent value="my-routine" className="mt-6">
            <Card className="bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-xl">
                  <Coffee className="h-6 w-6 text-amber-600" />
                  What's My Routine? ☕
                </CardTitle>
                <CardDescription className="text-base">
                  Let's look at your booking patterns and find those sweet spots. You might be more predictable than you think!
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <Button 
                  onClick={checkMyRoutine} 
                  disabled={loading}
                  className="w-full bg-amber-600 hover:bg-amber-700 text-white py-3 text-base"
                >
                  {loading ? (
                    <>
                      <Sparkles className="mr-2 h-5 w-5 animate-spin" />
                      Analysing your patterns...
                    </>
                  ) : (
                    <>
                      <TrendingUp className="mr-2 h-5 w-5" />
                      Show Me My Patterns
                    </>
                  )}
                </Button>

                {results && activeTab === "my-routine" && (
                  <div className="mt-6 space-y-4">
                    <div className="p-4 bg-gradient-to-r from-amber-50 to-orange-50 rounded-lg border border-amber-200">
                      <h4 className="font-medium text-amber-800 mb-2">Your Favourite Time Slots</h4>
                      <p className="text-amber-700">You love Fridays at 3PM. Want to lock it in weekly?</p>
                      <Button size="sm" className="mt-3 bg-amber-600 hover:bg-amber-700">
                        Book Regular Friday Slot
                      </Button>
                    </div>
                    {renderResults()}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* When's My Next Night Off? */}
          <TabsContent value="next-night-off" className="mt-6">
            <Card className="bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-xl">
                  <Moon className="h-6 w-6 text-indigo-600" />
                  When's My Next Night Off? 🌙
                </CardTitle>
                <CardDescription className="text-base">
                  Time to check when you last had some proper me-time. Spoiler alert: it's probably been too long.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <Button 
                  onClick={checkNextNightOff} 
                  disabled={loading}
                  className="w-full bg-indigo-600 hover:bg-indigo-700 text-white py-3 text-base"
                >
                  {loading ? (
                    <>
                      <Sparkles className="mr-2 h-5 w-5 animate-spin" />
                      Checking your break schedule...
                    </>
                  ) : (
                    <>
                      <Clock className="mr-2 h-5 w-5" />
                      When's My Next Break?
                    </>
                  )}
                </Button>

                {results && activeTab === "next-night-off" && (
                  <div className="mt-6 space-y-4">
                    <div className="p-4 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-lg border border-indigo-200">
                      <h4 className="font-medium text-indigo-800 mb-2">You Deserve This</h4>
                      <p className="text-indigo-700">It's been 2 weeks since your last proper night out. Time to book that dinner reservation!</p>
                      <Button size="sm" className="mt-3 bg-indigo-600 hover:bg-indigo-700">
                        Book Sarah for Saturday Night
                      </Button>
                    </div>
                    {renderResults()}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Plan My Week */}
          <TabsContent value="plan-my-week" className="mt-6">
            <Card className="bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-xl">
                  <Calendar className="h-6 w-6 text-emerald-600" />
                  Plan My Week 📅
                </CardTitle>
                <CardDescription className="text-base">
                  Let's map out your perfect week. Based on your history, here are the times that work best for you.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label htmlFor="week-context" className="text-base font-medium text-gray-700 mb-2 block">
                    What's happening this week? 🗓️
                  </Label>
                  <Textarea
                    id="week-context"
                    placeholder="e.g., 'Big work presentation Tuesday, Jess has gymnastics Wednesday, date night plans for Friday...'"
                    value={specificContext}
                    onChange={(e) => setSpecificContext(e.target.value)}
                    className="min-h-[100px]"
                  />
                </div>

                <Button 
                  onClick={planMyWeek} 
                  disabled={loading}
                  className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-3 text-base"
                >
                  {loading ? (
                    <>
                      <Sparkles className="mr-2 h-5 w-5 animate-spin" />
                      Planning your perfect week...
                    </>
                  ) : (
                    <>
                      <Calendar className="mr-2 h-5 w-5" />
                      Plan My Week
                    </>
                  )}
                </Button>

                {renderResults()}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}