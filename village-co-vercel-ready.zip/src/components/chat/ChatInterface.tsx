import React, { useState, useEffect, useRef } from "react";
import { useChat } from "@/contexts/ChatContext";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Send, User, CircleX, AlertCircle, CheckCircle, Loader2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

// Message type for the component
interface MessageItem {
  id: number;
  content: string;
  senderId: number;
  recipientId?: number | null;
  bookingId?: number | null;
  createdAt: Date;
  isRead: boolean;
  sender?: {
    id: number;
    firstName: string;
    lastName: string;
  };
  recipient?: {
    id: number;
    firstName: string;
    lastName: string;
  };
}

// Contact interface for users in chat
interface Contact {
  id: number;
  firstName: string;
  lastName: string;
  lastMessage?: string;
  hasUnread?: boolean;
  photoUrl?: string;
}

// Chat interface props
interface ChatInterfaceProps {
  recipientId?: number;
  bookingId?: number;
  onClose?: () => void;
  className?: string;
}

// Get initials from name for avatar
const getInitials = (firstName: string, lastName: string): string => {
  return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase();
};

// Format timestamp for messages
const formatMessageTime = (date: Date): string => {
  return formatDistanceToNow(new Date(date), { addSuffix: true });
};

export const ChatInterface: React.FC<ChatInterfaceProps> = ({ 
  recipientId, 
  bookingId, 
  onClose,
  className = ""
}) => {
  const { user } = useAuth();
  const { 
    messages, 
    sendMessage, 
    loadMessageThread, 
    markAsRead,
    activeThread,
    setActiveThread,
    wsStatus
  } = useChat();
  
  const [newMessage, setNewMessage] = useState("");
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Scroll to bottom of messages
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  // Effect to scroll to bottom when messages change
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Effect to load initial thread if recipientId is provided
  useEffect(() => {
    if (user && recipientId) {
      setIsLoading(true);
      loadMessageThread(user.id, recipientId)
        .finally(() => setIsLoading(false));
    }
  }, [user, recipientId, loadMessageThread]);

  // Effect to set selected contact from recipientId
  useEffect(() => {
    if (recipientId && messages.length > 0) {
      const recipientInfo = messages.find(m => 
        m.recipientId === recipientId || m.senderId === recipientId
      )?.sender || messages.find(m => 
        m.recipientId === recipientId || m.senderId === recipientId
      )?.recipient;
      
      if (recipientInfo && recipientInfo.id === recipientId) {
        setSelectedContact({
          id: recipientInfo.id,
          firstName: recipientInfo.firstName,
          lastName: recipientInfo.lastName
        });
      }
    }
  }, [recipientId, messages]);

  // Effect to set Admin as a favorite contact
  useEffect(() => {
    if (!user) return;
    
    // Simple approach: just show Admin as a favorite contact
    const adminContact: Contact = {
      id: 2, // Admin user ID
      firstName: "Admin",
      lastName: "",
      lastMessage: "Available for support",
      hasUnread: false,
      photoUrl: undefined
    };
    
    setContacts([adminContact]);
  }, [user]);

  // Handle sending a message
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newMessage.trim() || !user) return;
    
    const targetRecipientId = recipientId || selectedContact?.id;
    
    if (!targetRecipientId && !bookingId) {
      alert("Please select a recipient");
      return;
    }
    
    try {
      await sendMessage(newMessage, targetRecipientId!, bookingId);
      setNewMessage("");
    } catch (error) {
      console.error("Error sending message:", error);
    }
  };

  // Handle selecting a contact
  const handleContactSelect = (contact: Contact) => {
    setSelectedContact(contact);
    
    if (user) {
      setIsLoading(true);
      setActiveThread(user.id, contact.id);
      
      // Mark messages from this contact as read
      markAsRead(user.id, contact.id)
        .finally(() => setIsLoading(false));
    }
  };

  // If we have no user, show a message
  if (!user) {
    return (
      <Card className={`w-full max-w-md mx-auto ${className}`}>
        <CardHeader>
          <CardTitle className="text-center">Messaging</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col items-center justify-center p-8">
            <AlertCircle className="h-12 w-12 text-muted-foreground mb-4" />
            <p className="text-center">Please log in to use the messaging system.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Filtered messages for the current thread
  const filteredMessages = activeThread.userId1 && activeThread.userId2
    ? messages.filter(m => 
        (m.senderId === activeThread.userId1 && m.recipientId === activeThread.userId2) ||
        (m.senderId === activeThread.userId2 && m.recipientId === activeThread.userId1)
      )
    : bookingId
      ? messages.filter(m => m.bookingId === bookingId)
      : selectedContact && user
        ? messages.filter(m => 
            (m.senderId === user.id && m.recipientId === selectedContact.id) ||
            (m.senderId === selectedContact.id && m.recipientId === user.id)
          )
        : [];

  // Debug logging
  console.log("Chat Debug:", {
    totalMessages: messages.length,
    filteredMessages: filteredMessages.length,
    activeThread,
    selectedContact,
    user: user?.id,
    bookingId
  });

  return (
    <Card className={`h-[600px] flex flex-col ${className}`}>
      <CardHeader className="p-4 border-b">
        <div className="flex justify-between items-center">
          <CardTitle className="text-xl font-semibold">
            {selectedContact ? `Chat with ${selectedContact.firstName} ${selectedContact.lastName}` : "Messages"}
          </CardTitle>
          {onClose && (
            <Button variant="ghost" size="icon" onClick={onClose}>
              <CircleX className="h-5 w-5" />
            </Button>
          )}
        </div>
        
        {/* Connection status indicator */}
        <div className="flex items-center text-sm">
          {wsStatus === "connected" ? (
            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
              <CheckCircle className="h-3 w-3 mr-1" /> Connected
            </Badge>
          ) : wsStatus === "connecting" ? (
            <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
              <Loader2 className="h-3 w-3 mr-1 animate-spin" /> Connecting
            </Badge>
          ) : (
            <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
              <AlertCircle className="h-3 w-3 mr-1" /> Disconnected
            </Badge>
          )}
        </div>
      </CardHeader>
      
      <div className="flex flex-1 overflow-hidden">
        {/* Left panel - Contacts list (only show when not in a specific booking chat) */}
        {!bookingId && (
          <div className="w-1/3 border-r">
            <ScrollArea className="h-full">
              {contacts.length > 0 ? (
                contacts.map((contact) => (
                  <div
                    key={contact.id}
                    className={`flex items-center p-3 cursor-pointer hover:bg-muted ${
                      selectedContact?.id === contact.id ? "bg-muted" : ""
                    }`}
                    onClick={() => handleContactSelect(contact)}
                  >
                    <Avatar className="h-9 w-9 mr-3">
                      {contact.photoUrl && (
                        <AvatarImage 
                          src={contact.photoUrl} 
                          alt={`${contact.firstName} ${contact.lastName}`}
                        />
                      )}
                      <AvatarFallback>{getInitials(contact.firstName, contact.lastName)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-center">
                        <p className="font-medium truncate">
                          {contact.firstName} {contact.lastName}
                        </p>
                        {contact.hasUnread && (
                          <Badge className="ml-2 bg-primary text-white">New</Badge>
                        )}
                      </div>
                      {contact.lastMessage && (
                        <p className="text-sm text-muted-foreground truncate">{contact.lastMessage}</p>
                      )}
                    </div>
                  </div>
                ))
              ) : (
                <div className="flex flex-col items-center justify-center p-8 text-center text-muted-foreground">
                  <User className="h-8 w-8 mb-2" />
                  <p>No contacts yet</p>
                  <p className="text-sm">Messages you send and receive will appear here</p>
                </div>
              )}
            </ScrollArea>
          </div>
        )}
        
        {/* Right panel - Chat messages */}
        <div className={`flex flex-col ${bookingId ? "w-full" : "w-2/3"}`}>
          <ScrollArea className="flex-1 p-4">
            {isLoading ? (
              <div className="flex justify-center items-center h-full">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : filteredMessages.length > 0 ? (
              <div className="space-y-4">
                {filteredMessages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex ${
                      msg.senderId === user.id ? "justify-end" : "justify-start"
                    }`}
                  >
                    <div
                      className={`max-w-[80%] rounded-lg p-3 ${
                        msg.senderId === user.id
                          ? "bg-primary text-primary-foreground"
                          : "bg-muted"
                      }`}
                    >
                      <div className="flex items-center mb-1">
                        <span className="text-xs font-medium">
                          {msg.senderId === user.id
                            ? "You"
                            : msg.sender
                            ? `${msg.sender.firstName} ${msg.sender.lastName}`
                            : "Unknown"}
                        </span>
                        <span className="text-xs ml-2 opacity-70">
                          {formatMessageTime(new Date(msg.createdAt))}
                        </span>
                      </div>
                      <p className="whitespace-pre-wrap break-words">{msg.content}</p>
                    </div>
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-center text-muted-foreground">
                <Send className="h-8 w-8 mb-2" />
                <p>No messages yet</p>
                <p className="text-sm">Send a message to start the conversation</p>
              </div>
            )}
          </ScrollArea>
          
          <CardFooter className="p-4 border-t mt-auto">
            <form onSubmit={handleSendMessage} className="flex w-full gap-2">
              <Input
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder="Type your message..."
                className="flex-1"
              />
              <Button type="submit" disabled={!newMessage.trim()}>
                <Send className="h-4 w-4 mr-2" />
                Send
              </Button>
            </form>
          </CardFooter>
        </div>
      </div>
    </Card>
  );
};

// ContactSelector component for searching and selecting contacts
interface ContactSelectorProps {
  onSelect: (contact: { id: number; name: string }) => void;
}

export const ContactSelector: React.FC<ContactSelectorProps> = ({ onSelect }) => {
  // Implementation for contact selection would go here
  return (
    <div>
      <p>Contact selector not implemented yet</p>
    </div>
  );
};

export default ChatInterface;