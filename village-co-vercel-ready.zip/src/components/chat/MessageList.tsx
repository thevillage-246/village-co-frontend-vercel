import React from 'react';
import { format, isToday, isYesterday } from 'date-fns';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';

interface Message {
  id: number;
  content: string;
  senderId: number;
  createdAt: string;
  isRead: boolean;
  sender?: {
    id: number;
    firstName: string;
    lastName: string;
  };
}

interface MessageListProps {
  messages: Message[];
  currentUserId?: number;
}

const MessageList: React.FC<MessageListProps> = ({ messages, currentUserId }) => {
  // Function to format message timestamp
  const formatMessageTime = (timestamp: string) => {
    const date = new Date(timestamp);
    
    if (isToday(date)) {
      return `Today, ${format(date, 'h:mm a')}`;
    } else if (isYesterday(date)) {
      return `Yesterday, ${format(date, 'h:mm a')}`;
    } else {
      return format(date, 'MMM d, h:mm a');
    }
  };

  // Group messages by date
  const groupedMessages: { [key: string]: Message[] } = {};
  messages.forEach(message => {
    const date = new Date(message.createdAt);
    const dateKey = format(date, 'yyyy-MM-dd');
    
    if (!groupedMessages[dateKey]) {
      groupedMessages[dateKey] = [];
    }
    
    groupedMessages[dateKey].push(message);
  });

  // Get user initials for avatar
  const getInitials = (firstName?: string, lastName?: string) => {
    if (!firstName && !lastName) return '?';
    return `${firstName?.[0] || ''}${lastName?.[0] || ''}`;
  };

  return (
    <div className="space-y-6">
      {Object.entries(groupedMessages).map(([dateKey, dayMessages]) => (
        <div key={dateKey} className="space-y-4">
          <div className="relative py-2">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-muted"></div>
            </div>
            <div className="relative flex justify-center text-xs">
              <span className="bg-card px-2 text-muted-foreground">
                {isToday(new Date(dateKey)) 
                  ? 'Today' 
                  : isYesterday(new Date(dateKey))
                    ? 'Yesterday'
                    : format(new Date(dateKey), 'MMMM d, yyyy')}
              </span>
            </div>
          </div>
          
          {dayMessages.map((message, index) => {
            const isCurrentUser = message.senderId === currentUserId;
            const sender = message.sender;
            const showSenderInfo = !isCurrentUser && 
              (index === 0 || dayMessages[index - 1].senderId !== message.senderId);
              
            return (
              <div 
                key={message.id} 
                className={cn(
                  "flex gap-2 max-w-[80%]",
                  isCurrentUser ? "ml-auto flex-row-reverse" : "mr-auto"
                )}
              >
                {showSenderInfo && !isCurrentUser && (
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>
                      {getInitials(sender?.firstName, sender?.lastName)}
                    </AvatarFallback>
                  </Avatar>
                )}
                
                <div 
                  className={cn(
                    "rounded-lg px-4 py-2 text-sm",
                    isCurrentUser
                      ? "bg-primary text-primary-foreground"
                      : "bg-muted"
                  )}
                >
                  {/* Show sender name for other users */}
                  {showSenderInfo && !isCurrentUser && sender && (
                    <p className="font-medium text-xs mb-1">
                      {sender.firstName} {sender.lastName}
                    </p>
                  )}
                  
                  {/* Message content */}
                  <p className="whitespace-pre-wrap break-words">{message.content}</p>
                  
                  {/* Timestamp */}
                  <p 
                    className={cn(
                      "text-xs mt-1 text-right",
                      isCurrentUser 
                        ? "text-primary-foreground/80" 
                        : "text-muted-foreground"
                    )}
                  >
                    {formatMessageTime(message.createdAt)}
                    {isCurrentUser && (
                      <span className="ml-1">
                        {message.isRead ? '• Read' : ''}
                      </span>
                    )}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
};

export default MessageList;
