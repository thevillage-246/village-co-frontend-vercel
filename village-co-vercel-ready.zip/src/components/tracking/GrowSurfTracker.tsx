import { useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';

declare global {
  interface Window {
    grsfSettings?: {
      campaignId: string;
      version: string;
    };
    grsfInit?: boolean;
    growsurf?: any;
  }
}

export default function GrowSurfTracker() {
  const { user } = useAuth();

  useEffect(() => {
    // Initialize GrowSurf script if not already loaded
    if (!window.grsfInit) {
      window.grsfSettings = { campaignId: "2irxbh", version: "2.0.0" };
      const head = document.getElementsByTagName("head")[0];
      const script = document.createElement("script");
      script.async = true;
      script.src = `https://app.growsurf.com/growsurf.js?v=${window.grsfSettings.version}`;
      script.setAttribute("grsf-campaign", window.grsfSettings.campaignId);
      head.appendChild(script);
      window.grsfInit = true;
    }
  }, []);

  useEffect(() => {
    if (user?.email && user?.firstName && user?.lastName) {
      // Create or update all GrowSurf tracking blocks with dynamic user data
      const initializeGrowSurfUser = () => {
        const trackingBlocks = [
          'data-grsf-block-form',
          'data-grsf-block-invite', 
          'data-grsf-block-referral-status',
          'data-grsf-block-rewards'
        ];

        trackingBlocks.forEach(blockType => {
          let existingBlock = document.querySelector(`[${blockType}]`);
          
          if (existingBlock) {
            // Update existing block with current user data
            existingBlock.setAttribute('data-grsf-email', user.email);
            existingBlock.setAttribute('data-grsf-first-name', user.firstName);
            existingBlock.setAttribute('data-grsf-last-name', user.lastName);
          } else {
            // Create new tracking block
            const div = document.createElement('div');
            div.setAttribute(blockType, '');
            div.setAttribute('data-grsf-email', user.email);
            div.setAttribute('data-grsf-first-name', user.firstName);
            div.setAttribute('data-grsf-last-name', user.lastName);
            div.style.display = 'none'; // Hidden tracking element
            document.body.appendChild(div);
          }
        });

        // Track user as participant if GrowSurf is loaded
        if (window.growsurf && typeof window.growsurf === 'function') {
          try {
            window.growsurf('addParticipant', {
              email: user.email,
              firstName: user.firstName,
              lastName: user.lastName
            });
            console.log('GrowSurfTracker: Added participant successfully:', user.email);
          } catch (error) {
            console.log('GrowSurf participant tracking:', error);
          }
        }
      };

      // Initialize immediately if GrowSurf is loaded, otherwise wait
      if (window.growsurf) {
        initializeGrowSurfUser();
      } else {
        // Wait for GrowSurf to load
        setTimeout(initializeGrowSurfUser, 2000);
      }
    }
  }, [user]);

  // This component renders nothing visible - it's just for tracking
  return null;
}