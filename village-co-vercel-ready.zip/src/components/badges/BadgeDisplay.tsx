import React from 'react';
import { 
  Award, 
  Medal, 
  Trophy, 
  Users,
  Star
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface BadgeDisplayProps {
  badgeType: 'badge' | 'referralBadge';
  value: string | null;
  size?: 'sm' | 'md' | 'lg';
  showLabel?: boolean;
  className?: string;
}

export const BadgeDisplay: React.FC<BadgeDisplayProps> = ({
  badgeType,
  value,
  size = 'md',
  showLabel = true,
  className
}) => {
  if (!value) return null;

  const sizeClasses = {
    sm: 'h-5 w-5',
    md: 'h-6 w-6',
    lg: 'h-8 w-8'
  };

  const labelSizeClasses = {
    sm: 'text-xs',
    md: 'text-sm',
    lg: 'text-base'
  };

  const containerClasses = {
    sm: 'px-1.5 py-0.5 gap-1',
    md: 'px-2 py-1 gap-1.5',
    lg: 'px-3 py-1.5 gap-2'
  };

  // Badge type specific styling
  let bgColor = 'bg-primary/10';
  let textColor = 'text-primary';
  let borderColor = 'border-primary/20';
  let icon = <Award className={sizeClasses[size]} />;
  let tooltipText = 'Recognition for exceptional service';

  // Style based on badge type and value
  if (badgeType === 'badge') {
    switch (value) {
      case 'Super Sitter':
        bgColor = 'bg-blue-500/10';
        textColor = 'text-blue-500';
        borderColor = 'border-blue-500/20';
        icon = <Star className={sizeClasses[size]} />;
        tooltipText = 'Highly rated babysitter with excellent performance';
        break;
      case 'Elite Caregiver':
        bgColor = 'bg-purple-500/10';
        textColor = 'text-purple-500';
        borderColor = 'border-purple-500/20';
        icon = <Trophy className={sizeClasses[size]} />;
        tooltipText = '10+ completed bookings with 4.7+ average rating';
        break;
      case 'Trusted Expert':
        bgColor = 'bg-amber-500/10';
        textColor = 'text-amber-500';
        borderColor = 'border-amber-500/20';
        icon = <Award className={sizeClasses[size]} />;
        tooltipText = '20+ completed bookings with 4.8+ average rating';
        break;
      default:
        break;
    }
  } else if (badgeType === 'referralBadge') {
    switch (value) {
      case 'Bronze Referrer':
        bgColor = 'bg-amber-700/10';
        textColor = 'text-amber-700';
        borderColor = 'border-amber-700/20';
        icon = <Medal className={sizeClasses[size]} />;
        tooltipText = '3+ successful referrals';
        break;
      case 'Silver Referrer':
        bgColor = 'bg-slate-400/10';
        textColor = 'text-slate-500';
        borderColor = 'border-slate-400/20';
        icon = <Medal className={sizeClasses[size]} />;
        tooltipText = '5+ successful referrals';
        break;
      case 'Gold Referrer':
        bgColor = 'bg-yellow-500/10';
        textColor = 'text-yellow-500';
        borderColor = 'border-yellow-500/20';
        icon = <Medal className={sizeClasses[size]} />;
        tooltipText = '10+ successful referrals';
        break;
      default:
        icon = <Users className={sizeClasses[size]} />;
        tooltipText = 'Community contributor';
        break;
    }
  }

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div 
            className={cn(
              'flex items-center rounded-full border',
              containerClasses[size],
              bgColor,
              borderColor,
              className
            )}
          >
            {icon}
            {showLabel && (
              <span className={cn('font-medium', textColor, labelSizeClasses[size])}>
                {value}
              </span>
            )}
          </div>
        </TooltipTrigger>
        <TooltipContent>
          <p>{tooltipText}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};