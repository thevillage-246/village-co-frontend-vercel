import { useState } from 'react';
import { useLocation } from 'wouter';
import { CalendarPlus, HelpCircle, X } from 'lucide-react';
import { Button } from './button';
import { useAuth } from '@/contexts/AuthContext';

export function FloatingActionButton() {
  const [isExpanded, setIsExpanded] = useState(false);
  const [, navigate] = useLocation();
  const { user } = useAuth();

  const toggleExpanded = () => {
    setIsExpanded(!isExpanded);
  };

  const handleBookNow = () => {
    setIsExpanded(false);
    navigate('/find-sitter');
  };

  const handleNeedHelp = () => {
    setIsExpanded(false);
    navigate('/support');
  };

  // Don't show help widget if we're on the support page or admin pages
  const currentPath = window.location.pathname;
  if (currentPath === '/support' || currentPath === '/find-sitter' || !user || currentPath.startsWith('/admin')) {
    return null;
  }

  // Don't show Book Now for sitters - they don't need to book sitters
  const showBookNow = user.role !== 'sitter';

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col items-end space-y-3">
      {isExpanded && (
        <>
          {showBookNow && (
            <Button
              variant="secondary"
              className="bg-wine text-white px-4 py-2 shadow-md hover:bg-wine/90 transition-all"
              onClick={handleBookNow}
            >
              <CalendarPlus className="mr-2 h-4 w-4" />
              Book Now
            </Button>
          )}
          

        </>
      )}
      
      <Button
        variant="default"
        size="icon"
        className={`h-12 w-12 rounded-full shadow-md transition-all ${
          isExpanded ? 'bg-rose hover:bg-rose/90' : 'bg-wine hover:bg-wine/90'
        }`}
        onClick={toggleExpanded}
      >
        {isExpanded ? (
          <X className="h-5 w-5 text-white" />
        ) : (
          <div className="flex flex-col items-center justify-center">
            <div className="h-1 w-5 bg-white mb-1 rounded-full"/>
            <div className="h-1 w-5 bg-white mb-1 rounded-full"/>
            <div className="h-1 w-5 bg-white rounded-full"/>
          </div>
        )}
      </Button>
    </div>
  );
}