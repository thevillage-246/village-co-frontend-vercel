import { useEffect, useState } from "react";

export function Confetti() {
  const [isClient, setIsClient] = useState(false);

  useEffect(() => {
    setIsClient(true);
    
    // Only import the confetti library on the client side
    if (typeof window !== "undefined") {
      // Dynamic import of the confetti library
      import('canvas-confetti').then((confetti) => {
        const duration = 3000;
        const animationEnd = Date.now() + duration;
        const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 9999 };

        const randomInRange = (min: number, max: number) => {
          return Math.random() * (max - min) + min;
        };

        // Create explosion of confetti
        const interval = setInterval(() => {
          const timeLeft = animationEnd - Date.now();

          if (timeLeft <= 0) {
            return clearInterval(interval);
          }

          const particleCount = 50 * (timeLeft / duration);
          
          // Use confetti default() as it's the default export
          confetti.default({
            ...defaults,
            particleCount,
            origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 }
          });
          
          confetti.default({
            ...defaults,
            particleCount,
            origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 }
          });
        }, 250);

        // Fire a big burst with custom colors
        confetti.default({
          particleCount: 100,
          spread: 100,
          origin: { x: 0.5, y: 0.3 },
          colors: ['#EBD3CB', '#6B3E4B', '#B8A89F', '#C7D1C5', '#F9F5F0'],
        });
      }).catch(err => {
        console.error('Failed to load confetti:', err);
      });
    }
    
    // Clean up function
    return () => {
      // No need to clean up as the interval will clear itself
    };
  }, []);

  // Don't render anything on the server
  if (!isClient) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-50" aria-hidden="true" />
  );
}