import { useEffect, useState } from 'react';

export default function InstallBanner() {
  const [prompt, setPrompt] = useState<any>(null);

  useEffect(() => {
    const handler = (e: any) => {
      e.preventDefault();
      setPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstall = () => {
    prompt.prompt();
    prompt.userChoice.then((choiceResult: any) => {
      if (choiceResult.outcome === 'accepted') {
        console.log('User accepted A2HS');
      }
      setPrompt(null);
    });
  };

  if (!prompt) return null;

  return (
    <div className="fixed bottom-4 left-4 right-4 bg-wine text-white p-4 rounded shadow-md z-50 flex justify-between items-center">
      <span>Add The Village Co. to your home screen?</span>
      <button onClick={handleInstall} className="ml-4 bg-white text-wine px-3 py-1 rounded font-bold">
        Add
      </button>
    </div>
  );
}