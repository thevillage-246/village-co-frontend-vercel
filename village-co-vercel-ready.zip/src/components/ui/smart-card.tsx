import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Calendar, 
  Clock, 
  Repeat, 
  TrendingUp, 
  Heart, 
  Star,
  User,
  MapPin,
  AlertCircle
} from 'lucide-react';

interface SmartCardProps {
  type: 'repeat_booking' | 'time_pattern' | 'frequency_suggestion' | 'day_preference' | 'perfect_timing' | 'streak_saver' | 'parent_win' | 'referral_reminder' | 'trusted_user_tip' | 'availability_alert';
  title: string;
  message: string;
  actionText: string;
  priority: 'high' | 'medium' | 'low';
  data?: any;
  onAction: () => void;
  className?: string;
}

const cardIcons = {
  repeat_booking: Repeat,
  time_pattern: Clock,
  frequency_suggestion: TrendingUp,
  day_preference: Calendar,
  perfect_timing: Star,
  streak_saver: Heart,
  parent_win: User,
  referral_reminder: TrendingUp,
  trusted_user_tip: AlertCircle,
  availability_alert: MapPin
};

const cardColors = {
  high: {
    border: 'border-village-wine/30',
    bg: 'bg-village-wine/5',
    text: 'text-village-wine',
    badge: 'bg-village-wine/10 text-village-wine',
    button: 'bg-village-wine hover:bg-village-wine/90'
  },
  medium: {
    border: 'border-brushed-pink/30',
    bg: 'bg-brushed-pink/5',
    text: 'text-brushed-pink',
    badge: 'bg-brushed-pink/10 text-brushed-pink',
    button: 'bg-brushed-pink hover:bg-brushed-pink/90'
  },
  low: {
    border: 'border-eucalyptus/30',
    bg: 'bg-eucalyptus/5',
    text: 'text-eucalyptus',
    badge: 'bg-eucalyptus/10 text-eucalyptus',
    button: 'bg-eucalyptus hover:bg-eucalyptus/90'
  }
};

export function SmartCard({ 
  type, 
  title, 
  message, 
  actionText, 
  priority, 
  data, 
  onAction, 
  className = '' 
}: SmartCardProps) {
  const Icon = cardIcons[type];
  const colors = cardColors[priority];
  
  return (
    <Card className={`${colors.border} ${colors.bg} ${className} transition-all hover:shadow-md border-2`}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-2">
            <div className={`p-2 rounded-full ${colors.badge}`}>
              <Icon className={`w-4 h-4 ${colors.text}`} />
            </div>
            <CardTitle className={`text-sm font-medium ${colors.text}`}>
              {title}
            </CardTitle>
          </div>
          <Badge variant="outline" className={`${colors.badge} border-current`}>
            {priority}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        <p className={`text-sm mb-4 ${colors.text}`}>
          {message}
        </p>
        {data?.additionalInfo && (
          <div className={`text-xs mb-3 p-2 rounded ${colors.badge}`}>
            {data.additionalInfo}
          </div>
        )}
        <Button 
          onClick={onAction}
          className={`w-full ${colors.button} text-white`}
          size="sm"
        >
          {actionText}
        </Button>
      </CardContent>
    </Card>
  );
}

// Specialized card variants for common use cases
export function RepeatBookingCard({ 
  sitterName, 
  daysAgo, 
  onBook, 
  className = '' 
}: { 
  sitterName: string; 
  daysAgo: number; 
  onBook: () => void; 
  className?: string; 
}) {
  const getDayDescription = (days: number) => {
    if (days === 1) return 'yesterday';
    if (days < 7) return `${days} days ago`;
    if (days < 14) return 'last week';
    if (days < 21) return '2 weeks ago';
    const weeksAgo = Math.floor(days / 7);
    return `${weeksAgo} week${weeksAgo > 1 ? 's' : ''} ago`;
  };

  return (
    <SmartCard
      type="repeat_booking"
      title="Perfect Timing"
      message={`You booked ${sitterName} ${getDayDescription(daysAgo)}. Ready for another session?`}
      actionText={`Book ${sitterName}`}
      priority={daysAgo > 14 ? 'high' : 'medium'}
      onAction={onBook}
      className={className}
    />
  );
}

export function FrequencyCard({ 
  sitterName, 
  averageDays, 
  overdueDays, 
  onSchedule, 
  className = '' 
}: { 
  sitterName: string; 
  averageDays: number; 
  overdueDays: number; 
  onSchedule: () => void; 
  className?: string; 
}) {
  return (
    <SmartCard
      type="frequency_suggestion"
      title="Streak Saver"
      message={`You usually book ${sitterName} every ${Math.round(averageDays)} days. You're ${overdueDays} days overdue!`}
      actionText="Schedule Now"
      priority="high"
      data={{
        additionalInfo: `Your regular pattern: Every ${Math.round(averageDays)} days`
      }}
      onAction={onSchedule}
      className={className}
    />
  );
}

export function TimePatternCard({ 
  sitterName, 
  timeSlot, 
  onBook, 
  className = '' 
}: { 
  sitterName: string; 
  timeSlot: string; 
  onBook: () => void; 
  className?: string; 
}) {
  const timeSlotEmoji = {
    morning: '🌅',
    afternoon: '☀️', 
    evening: '🌙'
  };

  return (
    <SmartCard
      type="time_pattern"
      title="Your Usual Style"
      message={`You prefer ${timeSlot} sessions with ${sitterName}. Book another?`}
      actionText="Book Similar Time"
      priority="low"
      onAction={onBook}
      className={className}
    />
  );
}

export function DayPreferenceCard({ 
  sitterName, 
  dayName, 
  onBook, 
  className = '' 
}: { 
  sitterName: string; 
  dayName: string; 
  onBook: () => void; 
  className?: string; 
}) {
  return (
    <SmartCard
      type="day_preference"
      title="Day Pattern Detected"
      message={`You usually book ${sitterName} on ${dayName}s. Continue the pattern?`}
      actionText={`Book for ${dayName}`}
      priority="low"
      onAction={onBook}
      className={className}
    />
  );
}