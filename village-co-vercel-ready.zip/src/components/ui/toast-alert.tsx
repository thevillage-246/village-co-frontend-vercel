import React, { useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { CheckCircle, XCircle, AlertCircle, Info } from 'lucide-react';

interface ToastAlertProps {
  message: string;
  type?: 'success' | 'error' | 'warning' | 'info';
  duration?: number;
  position?: 'top-right' | 'top-left' | 'bottom-right' | 'bottom-left';
  onClose?: () => void;
}

/**
 * Toast Alert Component
 * Simplified toast alert component that uses the shadcn toast system.
 */
export function ToastAlert({
  message,
  type = 'success',
  duration = 5000,
  onClose
}: ToastAlertProps) {
  const { toast } = useToast();

  useEffect(() => {
    // Configure toast based on type
    const toastOptions = {
      title: getToastTitle(type),
      description: message,
      variant: type === 'success' ? 'default' : type === 'error' ? 'destructive' : undefined,
      duration: duration,
    };

    // Show the toast
    const { dismiss } = toast(toastOptions);

    // Setup cleanup
    return () => {
      dismiss();
      if (onClose) onClose();
    };
  }, [message, type, duration, toast, onClose]);

  // This component doesn't render anything itself
  return null;
}

// Helper function to get toast title based on type
function getToastTitle(type: 'success' | 'error' | 'warning' | 'info'): string {
  switch (type) {
    case 'success':
      return 'Success';
    case 'error':
      return 'Error';
    case 'warning':
      return 'Warning';
    case 'info':
      return 'Information';
    default:
      return 'Notification';
  }
}

// Icon components for different toast types
export const ToastIcons = {
  Success: () => <CheckCircle className="h-4 w-4 text-green-500" />,
  Error: () => <XCircle className="h-4 w-4 text-red-500" />,
  Warning: () => <AlertCircle className="h-4 w-4 text-amber-500" />,
  Info: () => <Info className="h-4 w-4 text-blue-500" />,
};