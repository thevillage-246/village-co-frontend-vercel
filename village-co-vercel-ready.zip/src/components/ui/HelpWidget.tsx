import { useState } from 'react';
import { useLocation } from 'wouter';
import { HelpCircle, MessageSquare, X, Phone, Mail } from 'lucide-react';
import { Button } from './button';
import { Card, CardContent } from './card';
import { toast } from '@/hooks/use-toast';

export function HelpWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [, navigate] = useLocation();

  const toggleWidget = () => {
    setIsOpen(!isOpen);
  };

  const closeWidget = () => {
    setIsOpen(false);
  };

  const openSupportPage = () => {
    navigate('/support');
    closeWidget();
  };

  const sendQuickMessage = () => {
    // This would normally open a chat or send a message to admin
    toast({
      title: "Message sent",
      description: "A support agent will respond to you shortly.",
    });
    closeWidget();
  };

  return (
    <div className="fixed right-5 bottom-5 z-50">
      {isOpen && (
        <Card className="mb-4 w-72 shadow-lg border-eucalyptus bg-white">
          <CardContent className="p-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-semibold text-lg">Need Help?</h3>
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={closeWidget}
                className="h-8 w-8"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
            
            <div className="space-y-3">
              <Button 
                variant="outline" 
                onClick={openSupportPage}
                className="w-full flex items-center justify-start gap-2 border-wine text-wine hover:bg-wine/10"
              >
                <MessageSquare className="h-4 w-4" />
                <span>Support Ticket</span>
              </Button>
              
              <a 
                href="tel:+6491234567" 
                className="block w-full"
              >
                <Button 
                  variant="outline" 
                  className="w-full flex items-center justify-start gap-2 border-wine text-wine hover:bg-wine/10"
                >
                  <Phone className="h-4 w-4" />
                  <span>Call Us</span>
                </Button>
              </a>
              
              <a 
                href="mailto:help@ittakesavillage.nz" 
                className="block w-full"
              >
                <Button 
                  variant="outline" 
                  className="w-full flex items-center justify-start gap-2 border-wine text-wine hover:bg-wine/10"
                >
                  <Mail className="h-4 w-4" />
                  <span>Email Us</span>
                </Button>
              </a>
            </div>
            
            <div className="mt-4 text-xs text-gray-500">
              Emergency? Call us directly at +64 9 123 4567
            </div>
          </CardContent>
        </Card>
      )}
      
      <Button
        onClick={toggleWidget}
        className="rounded-full h-14 w-14 bg-wine hover:bg-wine/90 shadow-md"
        size="icon"
      >
        <HelpCircle className={`h-6 w-6 transition-transform ${isOpen ? 'rotate-45' : ''}`} />
      </Button>
    </div>
  );
}