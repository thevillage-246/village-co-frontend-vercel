import React, { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { FormControl, FormLabel, FormItem, FormMessage } from '@/components/ui/form';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { GraduationCap, Building2, MapPin, Plus, Search } from 'lucide-react';

interface SchoolSelectProps {
  value?: string;
  onChange: (value: string) => void;
  placeholder?: string;
}

interface School {
  id: number;
  name: string;
  type: 'school' | 'daycare';
  location: string;
  familyCount: number;
}

interface GroupedSchools {
  [city: string]: School[];
}

export function SearchableSchoolSelect({ value, onChange, placeholder = "Search for school or daycare (type 2+ letters)" }: SchoolSelectProps) {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');
  const [showDropdown, setShowDropdown] = useState(false);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [newSchool, setNewSchool] = useState<{
    name: string;
    type: 'school' | 'daycare';
    location: string;
  }>({
    name: '',
    type: 'school',
    location: ''
  });

  // Fetch schools with search
  const { data: schoolsResponse, isLoading, error } = useQuery({
    queryKey: ['/api/schools', searchTerm],
    queryFn: async () => {
      const params = searchTerm.length >= 2 ? `?search=${encodeURIComponent(searchTerm)}` : '';
      const response = await fetch(`/api/schools${params}`);
      if (!response.ok) {
        throw new Error('Failed to fetch schools');
      }
      return response.json();
    },
    enabled: true,
  });

  // Ensure we have a valid grouped schools object
  const groupedSchools: GroupedSchools = schoolsResponse && typeof schoolsResponse === 'object' && !Array.isArray(schoolsResponse)
    ? schoolsResponse 
    : {};

  // Create new school mutation
  const createSchool = useMutation({
    mutationFn: async (schoolData: typeof newSchool) => {
      const response = await apiRequest('POST', '/api/schools', schoolData);
      return response;
    },
    onSuccess: (newSchoolData: any) => {
      // Invalidate all school queries (including search term variations)
      queryClient.invalidateQueries({ queryKey: ['/api/schools'] });
      // Force refetch current query
      queryClient.refetchQueries({ queryKey: ['/api/schools', searchTerm] });
      onChange(newSchoolData.name);
      setShowAddDialog(false);
      setNewSchool({ name: '', type: 'school', location: '' });
      toast({
        title: 'School Added',
        description: 'The new school has been added successfully.',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to add school',
        variant: 'destructive',
      });
    },
  });

  const handleInputChange = (inputValue: string) => {
    setSearchTerm(inputValue);
    setShowDropdown(inputValue.length >= 2);
  };

  const handleSchoolSelect = (schoolName: string) => {
    onChange(schoolName);
    setShowDropdown(false);
    setSearchTerm('');
  };

  const handleAddSchool = () => {
    if (!newSchool.name || !newSchool.location) {
      toast({
        title: 'Missing Information',
        description: 'Please fill in both school name and location.',
        variant: 'destructive',
      });
      return;
    }
    createSchool.mutate(newSchool);
  };

  // Get display value
  const displayValue = value === 'none' ? '' : value || '';

  return (
    <div className="relative w-full">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
        <Input
          type="text"
          placeholder={placeholder}
          value={searchTerm || displayValue}
          onChange={(e) => handleInputChange(e.target.value)}
          onFocus={() => setShowDropdown(searchTerm.length >= 2)}
          className="pl-10"
        />
      </div>

      {/* Search Results Dropdown */}
      {showDropdown && !isLoading && groupedSchools && (
        <Card className="absolute top-full left-0 right-0 z-50 mt-1 max-h-80 overflow-y-auto shadow-lg">
          <CardContent className="p-0">
            {Object.keys(groupedSchools).length === 0 ? (
              <div className="p-4 text-center text-gray-500">
                <p>No schools found matching "{searchTerm}"</p>
                <Button
                  variant="outline"
                  size="sm"
                  className="mt-2"
                  onClick={() => setShowAddDialog(true)}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add New School or Daycare
                </Button>
              </div>
            ) : (
              <div>
                {Object.entries(groupedSchools).map(([city, schools]) => (
                  <div key={city} className="border-b last:border-b-0">
                    <div className="sticky top-0 bg-gray-50 px-4 py-2 font-medium text-sm text-gray-700 flex items-center">
                      <MapPin className="h-4 w-4 mr-2" />
                      {city}
                    </div>
                    {schools.map((school) => (
                      <div
                        key={school.id}
                        className="px-4 py-3 hover:bg-gray-50 cursor-pointer border-b last:border-b-0"
                        onClick={() => handleSchoolSelect(school.name)}
                      >
                        <div className="flex items-center gap-3">
                          {school.type === 'school' ? (
                            <GraduationCap className="h-4 w-4 text-blue-500" />
                          ) : (
                            <Building2 className="h-4 w-4 text-green-500" />
                          )}
                          <div className="flex-1">
                            <div className="font-medium">{school.name}</div>
                            <div className="text-sm text-gray-500">
                              {school.familyCount} families • {school.type}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ))}
                <div className="p-3 border-t bg-gray-50">
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full"
                    onClick={() => setShowAddDialog(true)}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Don't see your school? Add it here
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Current Selection Display */}
      {value && value !== 'none' && !showDropdown && (
        <div className="mt-2 p-2 bg-blue-50 rounded-md flex items-center justify-between">
          <div className="flex items-center gap-2">
            <GraduationCap className="h-4 w-4 text-blue-600" />
            <span className="text-sm font-medium">{value}</span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onChange('none')}
            className="text-gray-500 hover:text-gray-700"
          >
            Clear
          </Button>
        </div>
      )}

      {/* Add New School Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New School or Daycare</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <FormItem>
              <FormLabel>School/Daycare Name</FormLabel>
              <FormControl>
                <Input
                  placeholder="e.g. Hamilton West Primary School"
                  value={newSchool.name}
                  onChange={(e) => setNewSchool({ ...newSchool, name: e.target.value })}
                />
              </FormControl>
            </FormItem>
            
            <FormItem>
              <FormLabel>Type</FormLabel>
              <FormControl>
                <Select
                  value={newSchool.type}
                  onValueChange={(value) => 
                    setNewSchool({ ...newSchool, type: value as 'school' | 'daycare' })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="school">School</SelectItem>
                    <SelectItem value="daycare">Daycare</SelectItem>
                  </SelectContent>
                </Select>
              </FormControl>
            </FormItem>
            
            <FormItem>
              <FormLabel>Location/City</FormLabel>
              <FormControl>
                <Input
                  placeholder="e.g. Hamilton West"
                  value={newSchool.location}
                  onChange={(e) => setNewSchool({ ...newSchool, location: e.target.value })}
                />
              </FormControl>
            </FormItem>
            
            <div className="flex justify-end space-x-2 pt-4">
              <Button
                variant="outline"
                onClick={() => setShowAddDialog(false)}
              >
                Cancel
              </Button>
              <Button
                onClick={handleAddSchool}
                disabled={createSchool.isPending}
              >
                {createSchool.isPending ? 'Adding...' : 'Add School'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}