import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { format } from 'date-fns';
import { 
  Sheet, 
  SheetContent, 
  SheetHeader, 
  SheetTitle, 
  SheetTrigger 
} from '@/components/ui/sheet';
import { NotificationBadge } from './NotificationBadge';
import { Button } from './button';
import { useLocation } from 'wouter';
import { MessageSquare, CalendarCheck, Clock, DollarSign } from 'lucide-react';
import { cn } from '@/lib/utils';

export function NotificationPanel() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [open, setOpen] = useState(false);

  // Simplified notification handling
  const unreadCount = 0; // Placeholder until proper notification system is implemented

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <NotificationBadge />
        </Button>
      </SheetTrigger>
      <SheetContent>
        <SheetHeader>
          <SheetTitle>Notifications</SheetTitle>
        </SheetHeader>
        <div className="py-4">
          <div className="text-center py-10 text-muted-foreground">
            <p>No notifications yet</p>
            <p className="text-xs mt-2">Notifications will appear here when you have bookings and messages</p>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}