import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import { 
  Bell, 
  MessageSquare, 
  CalendarCheck, 
  Star, 
  CheckCircle, 
  AlertCircle 
} from 'lucide-react';

type NotificationType = 'message' | 'booking' | 'review' | 'approval' | 'reminder' | 'system';

interface Notification {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  timestamp: number;
  read: boolean;
  actionUrl?: string;
}

export function NotificationManager() {
  const { user } = useAuth();
  const [ws, setWs] = useState<WebSocket | null>(null);
  const [connected, setConnected] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([]);

  useEffect(() => {
    if (!user) return;

    // WebSocket connection setup
    const connectWebSocket = () => {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      
      const socket = new WebSocket(wsUrl);
      
      socket.onopen = () => {
        console.log('WebSocket connected');
        setConnected(true);
        
        // Authenticate with the WebSocket server
        socket.send(JSON.stringify({
          type: 'auth',
          userId: user.id
        }));
      };
      
      socket.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          console.log('WebSocket message received:', data);
          
          // Handle notification messages
          if (data.type === 'notification') {
            handleNewNotification(data.notification);
          }
          
          // Handle authentication confirmation
          if (data.type === 'auth_success') {
            console.log('WebSocket authenticated for user', data.userId);
          }
        } catch (error) {
          console.error('Error parsing WebSocket message:', error);
        }
      };
      
      socket.onclose = () => {
        console.log('WebSocket disconnected');
        setConnected(false);
        
        // Attempt to reconnect after 5 seconds
        setTimeout(() => {
          if (user) {
            connectWebSocket();
          }
        }, 5000);
      };
      
      socket.onerror = (error) => {
        console.error('WebSocket error:', error);
      };
      
      setWs(socket);
      
      // Clean up function
      return () => {
        socket.close();
      };
    };
    
    connectWebSocket();
    
  }, [user]);
  
  // Handle new notifications
  const handleNewNotification = (notification: Notification) => {
    // Add to notifications list
    setNotifications(prev => [notification, ...prev]);
    
    // Determine notification icon
    const getIcon = () => {
      switch (notification.type) {
        case 'message': return <MessageSquare className="h-4 w-4" />;
        case 'booking': return <CalendarCheck className="h-4 w-4" />;
        case 'review': return <Star className="h-4 w-4" />;
        case 'approval': return <CheckCircle className="h-4 w-4" />;
        default: return <Bell className="h-4 w-4" />;
      }
    };
    
    // Display toast notification with icon in the description instead
    toast({
      title: notification.title,
      description: (
        <div className="flex items-center gap-2">
          {getIcon()}
          <span>{notification.message}</span>
        </div>
      ),
      variant: notification.type === 'system' ? 'destructive' : 'default',
      action: notification.actionUrl ? (
        <a href={notification.actionUrl} className="bg-wine text-white text-xs px-2 py-1 rounded">
          View
        </a>
      ) : undefined
    });
  };
  
  // Send a heartbeat every 30 seconds to keep the connection alive
  useEffect(() => {
    if (!ws || !connected) return;
    
    const interval = setInterval(() => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ type: 'PING' }));
      }
    }, 30000);
    
    return () => clearInterval(interval);
  }, [ws, connected]);
  
  // Nothing to render - this is a background component
  return null;
}