import { Badge } from '@/components/ui/badge';
import { Calendar, CheckCircle, AlertTriangle, Clock } from 'lucide-react';
import { format } from 'date-fns';

interface ProfileFreshnessBadgeProps {
  lastUpdated: Date;
  daysSinceUpdate: number;
  status: 'fresh' | 'warning' | 'stale';
  showText?: boolean;
  className?: string;
}

export function ProfileFreshnessBadge({ 
  lastUpdated, 
  daysSinceUpdate, 
  status,
  showText = true,
  className = ""
}: ProfileFreshnessBadgeProps) {
  const getStatusConfig = () => {
    switch (status) {
      case 'fresh':
        return {
          icon: CheckCircle,
          text: `✅ Last Updated ${daysSinceUpdate} day${daysSinceUpdate !== 1 ? 's' : ''} ago`,
          variant: 'default' as const,
          bgColor: 'bg-green-50 text-green-700 border-green-200'
        };
      case 'warning':
        return {
          icon: AlertTriangle,
          text: `⚠️ Last Updated ${daysSinceUpdate} days ago`,
          variant: 'secondary' as const,
          bgColor: 'bg-yellow-50 text-yellow-700 border-yellow-200'
        };
      case 'stale':
        return {
          icon: Clock,
          text: `🔄 Last Updated ${Math.floor(daysSinceUpdate / 30)}+ months ago`,
          variant: 'destructive' as const,
          bgColor: 'bg-red-50 text-red-700 border-red-200'
        };
      default:
        return {
          icon: Calendar,
          text: `Last Updated ${daysSinceUpdate} days ago`,
          variant: 'outline' as const,
          bgColor: 'bg-gray-50 text-gray-700 border-gray-200'
        };
    }
  };

  const config = getStatusConfig();
  const Icon = config.icon;

  if (!showText) {
    return (
      <div className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium border ${config.bgColor} ${className}`}>
        <Icon className="w-3 h-3" />
        <span>{daysSinceUpdate}d</span>
      </div>
    );
  }

  return (
    <Badge 
      variant={config.variant}
      className={`inline-flex items-center gap-1.5 px-3 py-1.5 ${config.bgColor} ${className}`}
    >
      <Icon className="w-3.5 h-3.5" />
      <span className="font-medium">{config.text}</span>
      {lastUpdated && !isNaN(new Date(lastUpdated).getTime()) && (
        <span className="text-xs opacity-75 ml-1">
          ({format(new Date(lastUpdated), 'MMM d')})
        </span>
      )}
    </Badge>
  );
}

// Sitter confidence indicator for recent profile updates
interface SitterConfidenceBadgeProps {
  daysSinceUpdate: number;
  className?: string;
}

export function SitterConfidenceBadge({ daysSinceUpdate, className = "" }: SitterConfidenceBadgeProps) {
  const isRecent = daysSinceUpdate <= 30;
  
  if (!isRecent) return null;

  return (
    <div className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium bg-green-50 text-green-700 border border-green-200 ${className}`}>
      <CheckCircle className="w-3 h-3" />
      <span>Care info updated recently ✅</span>
    </div>
  );
}

// In-app banner for stale profiles
interface ProfileUpdateBannerProps {
  daysSinceUpdate: number;
  onUpdateClick: () => void;
  onDismiss?: () => void;
  className?: string;
}

export function ProfileUpdateBanner({ 
  daysSinceUpdate, 
  onUpdateClick, 
  onDismiss,
  className = ""
}: ProfileUpdateBannerProps) {
  const monthsSinceUpdate = Math.floor(daysSinceUpdate / 30);
  
  if (daysSinceUpdate < 60) return null;

  return (
    <div className={`bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4 ${className}`}>
      <div className="flex items-start justify-between">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
          <div>
            <h4 className="font-medium text-yellow-800">
              ⚠️ Your profile hasn't been updated in {monthsSinceUpdate}+ months
            </h4>
            <p className="text-sm text-yellow-700 mt-1">
              Sitters use your care notes to prepare for bookings.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 ml-4">
          <button
            onClick={onUpdateClick}
            className="bg-yellow-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-yellow-700 transition-colors"
          >
            Update Now
          </button>
          {onDismiss && (
            <button
              onClick={onDismiss}
              className="text-yellow-600 hover:text-yellow-700 text-sm"
            >
              Dismiss
            </button>
          )}
        </div>
      </div>
    </div>
  );
}