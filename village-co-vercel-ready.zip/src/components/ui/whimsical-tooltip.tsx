import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Heart, Star, Sparkles, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

export interface WhimsicalTooltipProps {
  isVisible: boolean;
  onClose: () => void;
  title: string;
  message: string;
  type?: 'encouragement' | 'tip' | 'celebration' | 'guidance';
  position?: 'top' | 'bottom' | 'left' | 'right';
  targetElement?: HTMLElement | null;
  autoHide?: boolean;
  autoHideDelay?: number;
}

const tooltipIcons = {
  encouragement: Heart,
  tip: Sparkles,
  celebration: Star,
  guidance: CheckCircle,
};

const tooltipColors = {
  encouragement: 'from-rose-400 to-pink-500',
  tip: 'from-blue-400 to-indigo-500',
  celebration: 'from-yellow-400 to-orange-500',
  guidance: 'from-green-400 to-emerald-500',
};

export function WhimsicalTooltip({
  isVisible,
  onClose,
  title,
  message,
  type = 'encouragement',
  position = 'top',
  targetElement,
  autoHide = true,
  autoHideDelay = 4000,
}: WhimsicalTooltipProps) {
  const [tooltipPosition, setTooltipPosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    if (targetElement && isVisible) {
      const rect = targetElement.getBoundingClientRect();
      const scrollX = window.pageXOffset || document.documentElement.scrollLeft;
      const scrollY = window.pageYOffset || document.documentElement.scrollTop;
      
      let x = rect.left + scrollX + rect.width / 2;
      let y = rect.top + scrollY;
      
      switch (position) {
        case 'top':
          y = rect.top + scrollY - 20;
          break;
        case 'bottom':
          y = rect.bottom + scrollY + 20;
          break;
        case 'left':
          x = rect.left + scrollX - 20;
          y = rect.top + scrollY + rect.height / 2;
          break;
        case 'right':
          x = rect.right + scrollX + 20;
          y = rect.top + scrollY + rect.height / 2;
          break;
      }
      
      setTooltipPosition({ x, y });
    }
  }, [targetElement, isVisible, position]);

  useEffect(() => {
    if (isVisible && autoHide) {
      const timer = setTimeout(() => {
        onClose();
      }, autoHideDelay);
      
      return () => clearTimeout(timer);
    }
  }, [isVisible, autoHide, autoHideDelay, onClose]);

  const Icon = tooltipIcons[type];
  const colorClass = tooltipColors[type];

  if (!isVisible) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, scale: 0.8, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.8, y: -10 }}
        transition={{ 
          type: "spring", 
          stiffness: 300, 
          damping: 25,
          duration: 0.3 
        }}
        className="fixed z-50"
        style={{
          left: targetElement ? tooltipPosition.x : '50%',
          top: targetElement ? tooltipPosition.y : '50%',
          transform: targetElement ? 'translate(-50%, -50%)' : 'translate(-50%, -50%)',
        }}
      >
        <div className="relative">
          {/* Main tooltip bubble */}
          <motion.div
            animate={{ 
              boxShadow: [
                '0 10px 30px rgba(0,0,0,0.1)',
                '0 15px 35px rgba(0,0,0,0.15)',
                '0 10px 30px rgba(0,0,0,0.1)'
              ]
            }}
            transition={{ duration: 2, repeat: Infinity }}
            className="bg-white rounded-2xl p-6 shadow-xl border border-gray-100 max-w-xs relative overflow-hidden"
          >
            {/* Background gradient overlay */}
            <div className={`absolute inset-0 bg-gradient-to-br ${colorClass} opacity-5 rounded-2xl`} />
            
            {/* Floating particles animation */}
            <div className="absolute inset-0 pointer-events-none">
              {[...Array(6)].map((_, i) => (
                <motion.div
                  key={i}
                  className={`absolute w-1 h-1 bg-gradient-to-br ${colorClass} rounded-full opacity-30`}
                  animate={{
                    x: [0, Math.random() * 100 - 50],
                    y: [0, Math.random() * 100 - 50],
                    opacity: [0.3, 0.8, 0.3],
                  }}
                  transition={{
                    duration: 3 + Math.random() * 2,
                    repeat: Infinity,
                    delay: Math.random() * 2,
                  }}
                  style={{
                    left: `${Math.random() * 100}%`,
                    top: `${Math.random() * 100}%`,
                  }}
                />
              ))}
            </div>

            {/* Close button */}
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="absolute top-2 right-2 h-6 w-6 p-0 hover:bg-gray-100 rounded-full"
            >
              <X className="h-3 w-3" />
            </Button>

            {/* Icon with pulsing animation */}
            <motion.div
              animate={{ 
                scale: [1, 1.1, 1],
                rotate: [0, 5, -5, 0]
              }}
              transition={{ 
                duration: 2, 
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className={`inline-flex items-center justify-center w-10 h-10 rounded-full bg-gradient-to-br ${colorClass} mb-3`}
            >
              <Icon className="h-5 w-5 text-white" />
            </motion.div>

            {/* Content */}
            <div className="relative z-10">
              <motion.h3
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="font-semibold text-gray-900 mb-2 text-sm"
              >
                {title}
              </motion.h3>
              
              <motion.p
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="text-xs text-gray-600 leading-relaxed"
              >
                {message}
              </motion.p>
            </div>
          </motion.div>

          {/* Arrow pointing to target element */}
          {targetElement && (
            <div
              className={`absolute w-3 h-3 bg-white border-l border-t border-gray-100 transform rotate-45 ${
                position === 'top' ? 'bottom-[-6px] left-1/2 -translate-x-1/2' :
                position === 'bottom' ? 'top-[-6px] left-1/2 -translate-x-1/2' :
                position === 'left' ? 'right-[-6px] top-1/2 -translate-y-1/2' :
                'left-[-6px] top-1/2 -translate-y-1/2'
              }`}
            />
          )}
        </div>
      </motion.div>
    </AnimatePresence>
  );
}

export default WhimsicalTooltip;