import { useEffect } from 'react';
import { supabase } from '@/lib/supabase';

export default function NotificationSubscriber() {
  useEffect(() => {
    const requestNotificationPermission = async () => {
      if ('Notification' in window && 'serviceWorker' in navigator) {
        const permission = await Notification.requestPermission();
        
        if (permission === 'granted') {
          try {
            const registration = await navigator.serviceWorker.ready;
            
            const subscription = await registration.pushManager.subscribe({
              userVisibleOnly: true,
              // Replace with your actual VAPID public key
              applicationServerKey: 'xxxx'
            });
            
            const { data: user } = await supabase.auth.getUser();
            
            if (user) {
              // Save subscription to Supabase
              const { error } = await supabase
                .from('subscriptions')
                .upsert({
                  user_id: user.user?.id,
                  endpoint: subscription.endpoint,
                  keys: {
                    auth: subscription.toJSON().keys?.auth,
                    p256dh: subscription.toJSON().keys?.p256dh
                  }
                }, { onConflict: 'user_id, endpoint' });
                
              if (error) {
                console.error('Error saving subscription:', error);
              } else {
                console.log('Push notification subscription saved successfully');
              }
            }
          } catch (error) {
            console.error('Error subscribing to push notifications:', error);
          }
        }
      }
    };
    
    // Only request permission after the user has interacted with the site
    const handleUserInteraction = () => {
      requestNotificationPermission();
      // Remove event listeners after permission has been requested
      document.removeEventListener('click', handleUserInteraction);
      document.removeEventListener('keydown', handleUserInteraction);
    };
    
    document.addEventListener('click', handleUserInteraction);
    document.addEventListener('keydown', handleUserInteraction);
    
    return () => {
      document.removeEventListener('click', handleUserInteraction);
      document.removeEventListener('keydown', handleUserInteraction);
    };
  }, []);
  
  return null; // This component doesn't render anything
}