import { Card, CardContent } from "@/components/ui/card";
import { Heart, Search, Calendar, MessageCircle, Users, Star, CreditCard, Shield } from "lucide-react";
import { Link } from "wouter";

interface EmptyStateProps {
  icon?: React.ReactNode;
  title: string;
  description: string;
  action?: {
    text: string;
    href: string;
  };
  className?: string;
}

export function EmptyState({ icon, title, description, action, className = "" }: EmptyStateProps) {
  return (
    <Card className={`border-almond-frost/20 shadow-sm ${className}`}>
      <CardContent className="p-8 text-center">
        {icon && (
          <div className="w-12 h-12 bg-village-wine/10 rounded-full flex items-center justify-center mx-auto mb-4">
            {icon}
          </div>
        )}
        
        <h3 className="text-lg font-semibold text-village-wine mb-2">{title}</h3>
        <p className="text-gray-600 mb-4">{description}</p>
        
        {action && (
          <Link href={action.href}>
            <button className="inline-flex items-center justify-center px-4 py-2 text-sm font-medium text-white bg-village-wine rounded-lg hover:bg-village-wine/90 transition-colors">
              {action.text}
            </button>
          </Link>
        )}
      </CardContent>
    </Card>
  );
}

// Pre-configured empty states for common scenarios
export const EmptyStates = {
  NoSitters: () => (
    <EmptyState
      icon={<Search className="h-6 w-6 text-village-wine" />}
      title="No sitters available right now"
      description="All our wonderful sitters are currently booked or unavailable. Try adjusting your search criteria or check back soon!"
      action={{ text: "Adjust Search", href: "/find-sitter" }}
    />
  ),

  NoFavorites: () => (
    <EmptyState
      icon={<Heart className="h-6 w-6 text-village-wine" />}
      title="No favorite sitters yet"
      description="Start building your trusted circle by adding sitters to your favorites. It makes future bookings even easier!"
      action={{ text: "Browse Sitters", href: "/find-sitter" }}
    />
  ),

  NoBookings: () => (
    <EmptyState
      icon={<Calendar className="h-6 w-6 text-village-wine" />}
      title="No bookings yet"
      description="Ready to find trusted childcare? Browse our verified sitters and book your first session—help is just a click away!"
      action={{ text: "Find a Sitter", href: "/find-sitter" }}
    />
  ),

  NoMessages: () => (
    <EmptyState
      icon={<MessageCircle className="h-6 w-6 text-village-wine" />}
      title="No messages yet"
      description="Your conversations with sitters will appear here. Start chatting to coordinate care details and build trust."
    />
  ),

  NoReviews: () => (
    <EmptyState
      icon={<Star className="h-6 w-6 text-village-wine" />}
      title="No reviews yet"
      description="Reviews from families help other parents find great care. Your first review will help build our trusted community!"
    />
  ),

  NoTransactions: () => (
    <EmptyState
      icon={<CreditCard className="h-6 w-6 text-village-wine" />}
      title="No transactions yet"
      description="Your payment history will appear here once you complete your first booking. All payments are secure and automatic."
    />
  ),

  NoChildren: () => (
    <EmptyState
      icon={<Users className="h-6 w-6 text-village-wine" />}
      title="Add your children's details"
      description="Help sitters provide the best care by sharing your children's ages, interests, and any special needs or preferences."
      action={{ text: "Add Children", href: "/parent/edit-profile" }}
    />
  ),

  ProfileIncomplete: () => (
    <EmptyState
      icon={<Shield className="h-6 w-6 text-village-wine" />}
      title="Complete your profile"
      description="A complete profile helps families feel confident booking with you and helps you get more opportunities."
      action={{ text: "Complete Profile", href: "/sitter/edit-profile" }}
    />
  ),

  // Loading states with encouraging messages
  LoadingSitters: () => (
    <EmptyState
      icon={<Search className="h-6 w-6 text-village-wine animate-pulse" />}
      title="Finding perfect sitters for you..."
      description="We're searching through our network of trusted, verified sitters in your area."
    />
  ),

  LoadingBookings: () => (
    <EmptyState
      icon={<Calendar className="h-6 w-6 text-village-wine animate-pulse" />}
      title="Loading your bookings..."
      description="Getting your latest booking information and schedule updates."
    />
  )
};

// Helper function for conditional empty states
export function ConditionalEmptyState({ 
  condition, 
  children, 
  fallback 
}: { 
  condition: boolean; 
  children: React.ReactNode; 
  fallback: React.ReactNode;
}) {
  if (condition) {
    return <>{fallback}</>;
  }
  return <>{children}</>;
}