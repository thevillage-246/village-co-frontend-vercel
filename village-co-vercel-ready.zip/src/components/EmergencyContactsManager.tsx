import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { 
  Phone, 
  Plus, 
  Edit, 
  Trash2, 
  Heart, 
  Shield, 
  Users, 
  AlertTriangle,
  CheckCircle2
} from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';

interface EmergencyContact {
  id: number;
  name: string;
  phone: string;
  relationship: string;
  isPrimary: boolean;
  canPickUp: boolean;
  canMakeMedicalDecisions: boolean;
  medicalInfo?: string;
  allergies?: string;
  medications?: string;
  priority: number;
}

interface EmergencyContactFormData {
  name: string;
  phone: string;
  relationship: string;
  isPrimary: boolean;
  canPickUp: boolean;
  canMakeMedicalDecisions: boolean;
}

const RELATIONSHIP_OPTIONS = [
  'Partner/Spouse',
  'Parent',
  'Grandparent',
  'Sibling',
  'Other Family',
  'Friend',
  'Neighbor',
  'Childcare Provider',
  'Other'
];

export default function EmergencyContactsManager() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingContact, setEditingContact] = useState<EmergencyContact | null>(null);
  const [formData, setFormData] = useState<EmergencyContactFormData>({
    name: '',
    phone: '',
    relationship: '',
    isPrimary: false,
    canPickUp: false,
    canMakeMedicalDecisions: false
  });

  // Fetch emergency contacts
  const { data: contacts = [], isLoading } = useQuery<EmergencyContact[]>({
    queryKey: ['/api/emergency-contacts', user?.id],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/emergency-contacts');
      return response.json();
    },
    enabled: !!user?.id
  });

  // Create/update contact mutation
  const saveContactMutation = useMutation({
    mutationFn: async (contactData: EmergencyContactFormData) => {
      const url = editingContact 
        ? `/api/emergency-contacts/${editingContact.id}`
        : '/api/emergency-contacts';
      const method = editingContact ? 'PUT' : 'POST';
      
      const response = await apiRequest(method, url, contactData);
      
      if (!response.ok) throw new Error('Failed to save contact');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: editingContact ? "Contact Updated" : "Contact Added",
        description: "Emergency contact has been saved successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/emergency-contacts'] });
      resetForm();
      setIsDialogOpen(false);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save emergency contact. Please try again.",
        variant: "destructive"
      });
    }
  });

  // Delete contact mutation
  const deleteContactMutation = useMutation({
    mutationFn: async (contactId: number) => {
      const response = await apiRequest('DELETE', `/api/emergency-contacts/${contactId}`);
      if (!response.ok) throw new Error('Failed to delete contact');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Contact Deleted",
        description: "Emergency contact has been removed.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/emergency-contacts'] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete contact. Please try again.",
        variant: "destructive"
      });
    }
  });

  // Verify contacts mutation
  const verifyContactsMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', `/api/emergency-contacts/${user?.id}/verify`);
      if (!response.ok) throw new Error('Failed to verify contacts');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Contacts Verified",
        description: "All emergency contacts have been verified for current bookings.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/emergency-contacts'] });
    }
  });

  const resetForm = () => {
    setFormData({
      name: '',
      phone: '',
      relationship: '',
      isPrimary: false,
      canPickUp: false,
      canMakeMedicalDecisions: false
    });
    setEditingContact(null);
  };

  const openEditDialog = (contact: EmergencyContact) => {
    setEditingContact(contact);
    setFormData({
      name: contact.name,
      phone: contact.phone,
      relationship: contact.relationship,
      isPrimary: contact.isPrimary,
      canPickUp: contact.canPickUp,
      canMakeMedicalDecisions: contact.canMakeMedicalDecisions
    });
    setIsDialogOpen(true);
  };

  const openAddDialog = () => {
    resetForm();
    setIsDialogOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!formData.name.trim() || !formData.phone.trim() || !formData.relationship) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive"
      });
      return;
    }

    // Phone validation (basic NZ format)
    const phoneRegex = /^(\+64|0)[2-9]\d{7,9}$/;
    if (!phoneRegex.test(formData.phone.replace(/\s/g, ''))) {
      toast({
        title: "Invalid Phone Number",
        description: "Please enter a valid New Zealand phone number.",
        variant: "destructive"
      });
      return;
    }

    saveContactMutation.mutate(formData);
  };

  const sortedContacts = [...contacts].sort((a, b) => {
    if (a.isPrimary && !b.isPrimary) return -1;
    if (!a.isPrimary && b.isPrimary) return 1;
    return a.priority - b.priority;
  });

  const primaryContact = contacts.find(c => c.isPrimary);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-wine">Emergency Contacts</h2>
          <p className="text-gray-600">Manage your emergency contacts for babysitting bookings</p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={() => verifyContactsMutation.mutate()}
            variant="outline"
            size="sm"
            disabled={verifyContactsMutation.isPending || contacts.length === 0}
          >
            <CheckCircle2 className="h-4 w-4 mr-2" />
            Verify All
          </Button>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button onClick={openAddDialog} className="bg-wine hover:bg-wine/90">
                <Plus className="h-4 w-4 mr-2" />
                Add Contact
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>
                  {editingContact ? 'Edit Emergency Contact' : 'Add Emergency Contact'}
                </DialogTitle>
              </DialogHeader>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Full Name *</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Enter full name"
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="phone">Phone Number *</Label>
                    <Input
                      id="phone"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="0x xxx xxxx or +64 x xxx xxxx"
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="relationship">Relationship *</Label>
                  <Select
                    value={formData.relationship}
                    onValueChange={(value) => setFormData({ ...formData, relationship: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select relationship" />
                    </SelectTrigger>
                    <SelectContent>
                      {RELATIONSHIP_OPTIONS.map((option) => (
                        <SelectItem key={option} value={option}>
                          {option}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Authority permissions */}
                <div className="space-y-3 p-4 bg-gray-50 rounded-lg">
                  <Label className="text-sm font-semibold">Authority & Permissions</Label>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="isPrimary"
                      checked={formData.isPrimary}
                      onCheckedChange={(checked) => 
                        setFormData({ ...formData, isPrimary: checked === true })}
                    />
                    <Label htmlFor="isPrimary" className="text-sm">
                      Primary Emergency Contact
                    </Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="canPickUp"
                      checked={formData.canPickUp}
                      onCheckedChange={(checked) => 
                        setFormData({ ...formData, canPickUp: checked === true })}
                    />
                    <Label htmlFor="canPickUp" className="text-sm">
                      Authorized to pick up children
                    </Label>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="canMakeMedicalDecisions"
                      checked={formData.canMakeMedicalDecisions}
                      onCheckedChange={(checked) => 
                        setFormData({ ...formData, canMakeMedicalDecisions: checked === true })}
                    />
                    <Label htmlFor="canMakeMedicalDecisions" className="text-sm">
                      Can make emergency medical decisions
                    </Label>
                  </div>
                </div>



                <div className="flex justify-end gap-2 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setIsDialogOpen(false)}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={saveContactMutation.isPending}
                    className="bg-wine hover:bg-wine/90"
                  >
                    {saveContactMutation.isPending 
                      ? 'Saving...' 
                      : editingContact 
                        ? 'Update Contact' 
                        : 'Add Contact'
                    }
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {!primaryContact && contacts.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 p-4 rounded-lg flex items-center gap-3">
          <AlertTriangle className="h-5 w-5 text-amber-600" />
          <div>
            <p className="text-amber-800 font-medium">No Primary Contact Set</p>
            <p className="text-amber-700 text-sm">Please designate one contact as your primary emergency contact.</p>
          </div>
        </div>
      )}

      {isLoading ? (
        <div className="flex justify-center p-8">
          <div className="animate-spin w-8 h-8 border-4 border-wine border-t-transparent rounded-full"></div>
        </div>
      ) : contacts.length === 0 ? (
        <Card>
          <CardContent className="text-center p-8">
            <Phone className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-600 mb-2">No Emergency Contacts</h3>
            <p className="text-gray-500 mb-4">
              Add emergency contacts so sitters know who to call if needed during bookings.
            </p>
            <Button onClick={openAddDialog} className="bg-wine hover:bg-wine/90">
              <Plus className="h-4 w-4 mr-2" />
              Add Your First Contact
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {sortedContacts.map((contact) => (
            <Card key={contact.id} className={contact.isPrimary ? "border-wine ring-2 ring-wine/20" : ""}>
              <CardContent className="p-4">
                <div className="flex justify-between items-start">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-lg font-semibold">{contact.name}</h3>
                      {contact.isPrimary && (
                        <Badge className="bg-wine text-white">
                          <Heart className="h-3 w-3 mr-1" />
                          Primary
                        </Badge>
                      )}
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-gray-600">
                          <Phone className="h-4 w-4 inline mr-2" />
                          {contact.phone}
                        </p>
                        <p className="text-gray-600 mt-1">
                          <Users className="h-4 w-4 inline mr-2" />
                          {contact.relationship}
                        </p>
                      </div>
                      
                      <div className="space-y-1">
                        {contact.canPickUp && (
                          <Badge variant="outline" className="mr-1 mb-1">
                            <Shield className="h-3 w-3 mr-1" />
                            Can Pick Up
                          </Badge>
                        )}
                        {contact.canMakeMedicalDecisions && (
                          <Badge variant="outline" className="mr-1 mb-1">
                            <Heart className="h-3 w-3 mr-1" />
                            Medical Decisions
                          </Badge>
                        )}
                      </div>
                    </div>

                    {(contact.allergies || contact.medications || contact.medicalInfo) && (
                      <div className="mt-3 p-3 bg-blue-50 rounded border-l-4 border-blue-400">
                        <p className="text-xs font-semibold text-blue-800 mb-1">Medical Information:</p>
                        {contact.allergies && (
                          <p className="text-xs text-blue-700">
                            <strong>Allergies:</strong> {contact.allergies}
                          </p>
                        )}
                        {contact.medications && (
                          <p className="text-xs text-blue-700">
                            <strong>Medications:</strong> {contact.medications}
                          </p>
                        )}
                        {contact.medicalInfo && (
                          <p className="text-xs text-blue-700">
                            <strong>Notes:</strong> {contact.medicalInfo}
                          </p>
                        )}
                      </div>
                    )}
                  </div>
                  
                  <div className="flex gap-2 ml-4">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => openEditDialog(contact)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => deleteContactMutation.mutate(contact.id)}
                      disabled={deleteContactMutation.isPending}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <div className="bg-gray-50 p-4 rounded-lg">
        <h4 className="font-semibold mb-2">Important Notes:</h4>
        <ul className="text-sm text-gray-600 space-y-1">
          <li>• Emergency contacts are verified at every booking to ensure current information</li>
          <li>• Sitters can view all emergency contacts during active bookings</li>
          <li>• Primary contact will be called first in case of emergencies</li>
          <li>• Medical information helps sitters respond appropriately to health situations</li>
        </ul>
      </div>
    </div>
  );
}