import React, { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue 
} from "@/components/ui/select";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { format } from "date-fns";

interface Child {
  id: number;
  firstName: string;
  lastName: string;
}

interface MoodTrackerProps {
  bookingId: number;
  sitterId: number;
  children: Child[];
}

const MOODS = {
  happy: { emoji: "🙂", name: "Happy" },
  neutral: { emoji: "😐", name: "Neutral" },
  sad: { emoji: "😢", name: "Sad" },
  asleep: { emoji: "😴", name: "Asleep" }
};

const moodSchema = z.object({
  childId: z.number(),
  mood: z.enum(["happy", "neutral", "sad", "asleep"]),
  notes: z.string().optional(),
});

type MoodFormValues = z.infer<typeof moodSchema>;

export function MoodTracker({ bookingId, sitterId, children }: MoodTrackerProps) {
  const [selectedChild, setSelectedChild] = useState<Child | null>(
    children && children.length > 0 ? children[0] : null
  );
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { data: moods, isLoading } = useQuery({
    queryKey: ['/api/mood', bookingId],
    queryFn: async () => {
      const res = await apiRequest('GET', `/api/mood/${bookingId}`);
      return res.json();
    },
    enabled: !!bookingId
  });
  
  const addMoodMutation = useMutation({
    mutationFn: async (data: MoodFormValues) => {
      const payload = {
        ...data,
        bookingId,
        sitterId,
        timestamp: new Date().toISOString()
      };
      const res = await apiRequest('POST', '/api/mood', payload);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Mood recorded",
        description: "The child's mood has been successfully recorded.",
      });
      form.reset();
      queryClient.invalidateQueries({ queryKey: ['/api/mood', bookingId] });
    },
    onError: (error) => {
      toast({
        title: "Error recording mood",
        description: "There was an error recording the mood. Please try again.",
        variant: "destructive",
      });
      console.error("Error recording mood:", error);
    }
  });
  
  const form = useForm<MoodFormValues>({
    resolver: zodResolver(moodSchema),
    defaultValues: {
      childId: selectedChild?.id || 0,
      mood: "happy",
      notes: "",
    },
  });
  
  useEffect(() => {
    if (selectedChild) {
      form.setValue("childId", selectedChild.id);
    }
  }, [selectedChild, form]);
  
  const onSubmit = (data: MoodFormValues) => {
    addMoodMutation.mutate(data);
  };
  
  const getMoodsForChild = (childId: number) => {
    if (!moods || !Array.isArray(moods)) return [];
    return moods.filter((mood: any) => mood.childId === childId);
  };
  
  const getLatestMood = (childId: number) => {
    const childMoods = getMoodsForChild(childId);
    if (childMoods.length === 0) return null;
    
    // Sort by timestamp (most recent first)
    childMoods.sort((a: any, b: any) => {
      return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime();
    });
    
    return childMoods[0];
  };
  
  if (!children || children.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>No Children to Track</CardTitle>
          <CardDescription>No children information available for this booking.</CardDescription>
        </CardHeader>
      </Card>
    );
  }
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col space-y-4 sm:flex-row sm:space-y-0 sm:space-x-4">
        {children.map((child) => {
          const latestMood = getLatestMood(child.id);
          const moodInfo = latestMood ? MOODS[latestMood.mood as keyof typeof MOODS] : null;
          
          return (
            <Card 
              key={child.id} 
              className={`flex-1 cursor-pointer hover:border-primary transition-colors ${
                selectedChild?.id === child.id ? 'border-primary' : ''
              }`}
              onClick={() => setSelectedChild(child)}
            >
              <CardHeader className="pb-2">
                <CardTitle className="text-base">{child.firstName} {child.lastName}</CardTitle>
                {moodInfo && (
                  <div className="flex items-center mt-1">
                    <span className="text-2xl mr-2">{moodInfo.emoji}</span>
                    <span className="text-sm text-muted-foreground">{moodInfo.name}</span>
                  </div>
                )}
              </CardHeader>
              <CardContent className="pt-0">
                {latestMood && (
                  <div className="text-xs text-muted-foreground">
                    Last update: {format(new Date(latestMood.timestamp), 'h:mm a')}
                  </div>
                )}
                {!latestMood && (
                  <div className="text-xs text-muted-foreground">No mood recorded yet</div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
      
      {selectedChild && (
        <Card>
          <CardHeader>
            <CardTitle>Record {selectedChild.firstName}'s Mood</CardTitle>
            <CardDescription>
              Keep track of how {selectedChild.firstName} is feeling during your sitting session.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="mood"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Current Mood</FormLabel>
                      <div className="grid grid-cols-4 gap-2">
                        {Object.entries(MOODS).map(([key, { emoji, name }]) => (
                          <div 
                            key={key}
                            className={`flex flex-col items-center justify-center p-3 rounded-md border cursor-pointer hover:border-primary transition-colors ${
                              field.value === key ? 'border-primary bg-primary/5' : ''
                            }`}
                            onClick={() => form.setValue("mood", key as any)}
                          >
                            <span className="text-3xl mb-1">{emoji}</span>
                            <span className="text-xs">{name}</span>
                          </div>
                        ))}
                      </div>
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Notes (Optional)</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder={`Add any details about ${selectedChild.firstName}'s mood or activities...`}
                          className="resize-none h-20"
                          {...field}
                        />
                      </FormControl>
                      <FormDescription>
                        Include any relevant information about meals, activities, or behavior.
                      </FormDescription>
                    </FormItem>
                  )}
                />
                
                <Button 
                  type="submit"
                  className="w-full"
                  disabled={addMoodMutation.isPending}
                >
                  {addMoodMutation.isPending ? "Saving..." : "Record Mood"}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      )}
      
      {/* Mood History */}
      {selectedChild && (
        <Card>
          <CardHeader>
            <CardTitle>Mood History</CardTitle>
            <CardDescription>
              Previous mood entries for {selectedChild.firstName} during this booking
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="text-center py-4">Loading mood history...</div>
            ) : (
              <div className="space-y-4">
                {getMoodsForChild(selectedChild.id).length === 0 ? (
                  <div className="text-center py-4 text-muted-foreground">
                    No mood history available yet
                  </div>
                ) : (
                  getMoodsForChild(selectedChild.id)
                    .sort((a: any, b: any) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
                    .map((mood: any) => {
                      const moodInfo = MOODS[mood.mood as keyof typeof MOODS];
                      return (
                        <div key={mood.id} className="border-b pb-3 last:border-0">
                          <div className="flex justify-between items-center mb-1">
                            <div className="flex items-center">
                              <span className="text-2xl mr-2">{moodInfo.emoji}</span>
                              <span className="font-medium">{moodInfo.name}</span>
                            </div>
                            <div className="text-sm text-muted-foreground">
                              {format(new Date(mood.timestamp), 'h:mm a')}
                            </div>
                          </div>
                          {mood.notes && (
                            <div className="text-sm mt-1">{mood.notes}</div>
                          )}
                        </div>
                      );
                    })
                )}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}