import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Info, Check } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Schema for referee input validation
const refereeSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  email: z.string().email({ message: "Please enter a valid email address" }),
  phone: z.string().min(8, { message: "Please enter a valid phone number" }),
  relationship: z.string().min(3, { message: "Please describe your relationship" }),
  yearsKnown: z.string().min(1, { message: "Please indicate how long you've known this person" }),
  additionalNotes: z.string().optional(),
});

type RefereeFormData = z.infer<typeof refereeSchema>;

interface RefereeFormProps {
  userId: number;
  onComplete: () => void;
  refereeNumber: number;
}

export default function RefereeForm({ userId, onComplete, refereeNumber }: RefereeFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { toast } = useToast();

  const form = useForm<RefereeFormData>({
    resolver: zodResolver(refereeSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      relationship: "",
      yearsKnown: "",
      additionalNotes: "",
    },
  });

  const onSubmit = async (data: RefereeFormData) => {
    setIsSubmitting(true);
    try {
      // Submit referee data
      await apiRequest("POST", "/api/sitters/referee", {
        userId,
        refereeNumber,
        ...data,
        submittedAt: new Date().toISOString(),
      });
      
      // Show success message
      toast({
        title: "Reference Added",
        description: "Your reference has been successfully added.",
      });
      
      // Invalidate relevant queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/sitters', userId] });
      
      // Mark as submitted and call completion callback
      setIsSubmitted(true);
      setTimeout(() => {
        onComplete();
      }, 2000);
    } catch (error) {
      console.error("Error submitting referee:", error);
      toast({
        title: "Submission Error",
        description: "There was a problem adding your reference. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="w-full max-w-xl mx-auto">
      {isSubmitted ? (
        <div className="p-6 flex flex-col items-center justify-center">
          <div className="rounded-full bg-green-100 p-3 mb-4">
            <Check className="h-8 w-8 text-green-600" />
          </div>
          <h3 className="text-xl font-semibold text-center">Reference Added</h3>
          <p className="text-center text-muted-foreground mt-2">
            Your reference has been successfully added. We may contact them as part of your verification process.
          </p>
        </div>
      ) : (
        <>
          <CardHeader>
            <CardTitle className="text-xl font-semibold text-wine">
              Reference {refereeNumber}
            </CardTitle>
            <CardDescription>
              Provide contact details for someone who can vouch for your childcare abilities or character
            </CardDescription>
          </CardHeader>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
              <CardContent className="space-y-4">
                <div className="bg-blue-50 p-3 rounded-md flex items-start mb-4">
                  <Info className="h-5 w-5 text-blue-500 mr-2 mt-0.5 flex-shrink-0" />
                  <div className="text-sm text-blue-700">
                    <p>Please provide references who:</p>
                    <ul className="list-disc pl-5 mt-1">
                      <li>Have known you for at least 1 year</li>
                      <li>Can speak to your childcare abilities</li>
                      <li>Are not family members</li>
                    </ul>
                  </div>
                </div>
                
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Full Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Jane Smith" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email Address</FormLabel>
                        <FormControl>
                          <Input type="email" placeholder="jane.smith@example.com" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone Number</FormLabel>
                        <FormControl>
                          <Input placeholder="+64 021 123 4567" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="relationship"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Relationship to You</FormLabel>
                      <FormControl>
                        <Input placeholder="Former employer, teacher, etc." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="yearsKnown"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Years Known</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., 3 years" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="additionalNotes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Additional Notes (Optional)</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Any additional information about this reference..." 
                          className="min-h-[100px]"
                          {...field} 
                        />
                      </FormControl>
                      <FormDescription>
                        Provide any context that might help us understand this reference better.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
              
              <CardFooter className="flex justify-end">
                <Button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="bg-wine hover:bg-wine/90"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Submitting...
                    </>
                  ) : (
                    "Add Reference"
                  )}
                </Button>
              </CardFooter>
            </form>
          </Form>
        </>
      )}
    </Card>
  );
}