import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Save, MapPin, Phone, User } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';

const addressEmergencySchema = z.object({
  streetAddress: z.string().min(1, 'Street address is required').max(200, 'Address must be less than 200 characters'),
  suburb: z.string().min(1, 'Suburb is required').max(100, 'Suburb must be less than 100 characters'),
  city: z.string().min(1, 'City is required').max(100, 'City must be less than 100 characters'),
  postcode: z.string().min(4, 'Postcode must be at least 4 characters').max(10, 'Postcode must be less than 10 characters'),
  emergencyContactName: z.string().min(1, 'Emergency contact name is required').max(100, 'Name must be less than 100 characters'),
  emergencyContactPhone: z.string().min(8, 'Phone number must be at least 8 characters').max(20, 'Phone number must be less than 20 characters'),
  emergencyContactRelationship: z.string().min(1, 'Relationship is required').max(50, 'Relationship must be less than 50 characters'),
});

type AddressEmergencyData = z.infer<typeof addressEmergencySchema>;

interface AddressEmergencyFormProps {
  profile: any;
  onSuccess: () => void;
}

export default function AddressEmergencyForm({ profile, onSuccess }: AddressEmergencyFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const form = useForm<AddressEmergencyData>({
    resolver: zodResolver(addressEmergencySchema),
    defaultValues: {
      streetAddress: profile?.streetAddress || '',
      suburb: profile?.suburb || '',
      city: profile?.city || '',
      postcode: profile?.postcode || '',
      emergencyContactName: profile?.emergencyContactName || '',
      emergencyContactPhone: profile?.emergencyContactPhone || '',
      emergencyContactRelationship: profile?.emergencyContactRelationship || '',
    },
  });

  const updateAddressMutation = useMutation({
    mutationFn: async (data: AddressEmergencyData) => {
      console.log('🔧 Submitting address and emergency contact data:', data);
      const response = await apiRequest('PUT', '/api/sitter/profile', data);
      console.log('🔧 Address update response:', response);
      return response;
    },
    onSuccess: (data) => {
      console.log('✅ Address and emergency contact update successful:', data);
      
      // Invalidate relevant queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/sitter/profile'] });
      queryClient.invalidateQueries({ queryKey: ['/api/sitter'] });
      
      onSuccess();
      toast({
        title: "Information Updated",
        description: "Your address and emergency contact information have been updated successfully.",
      });
    },
    onError: (error: any) => {
      console.error('❌ Address and emergency contact update failed:', error);
      toast({
        title: "Update Failed",
        description: error.message || "Failed to update information. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: AddressEmergencyData) => {
    console.log('📝 Submitting address and emergency contact form:', data);
    updateAddressMutation.mutate(data);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-village-wine flex items-center gap-2">
          <MapPin className="w-5 h-5" />
          Address & Emergency Contact
        </CardTitle>
        <CardDescription>
          This information is private and only accessible to administrators for safety and verification purposes
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {/* Address Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium text-village-wine">Address Information</h3>
            
            <div className="space-y-2">
              <Label htmlFor="streetAddress">Street Address *</Label>
              <Input
                id="streetAddress"
                placeholder="123 Main Street"
                {...form.register('streetAddress')}
              />
              {form.formState.errors.streetAddress && (
                <p className="text-sm text-red-600">{form.formState.errors.streetAddress.message}</p>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="suburb">Suburb *</Label>
                <Input
                  id="suburb"
                  placeholder="Addington"
                  {...form.register('suburb')}
                />
                {form.formState.errors.suburb && (
                  <p className="text-sm text-red-600">{form.formState.errors.suburb.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="city">City *</Label>
                <Input
                  id="city"
                  placeholder="Christchurch"
                  {...form.register('city')}
                />
                {form.formState.errors.city && (
                  <p className="text-sm text-red-600">{form.formState.errors.city.message}</p>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="postcode">Postcode *</Label>
              <Input
                id="postcode"
                placeholder="8024"
                {...form.register('postcode')}
              />
              {form.formState.errors.postcode && (
                <p className="text-sm text-red-600">{form.formState.errors.postcode.message}</p>
              )}
            </div>
          </div>

          {/* Emergency Contact Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium text-village-wine flex items-center gap-2">
              <Phone className="w-5 h-5" />
              Emergency Contact
            </h3>
            
            <div className="space-y-2">
              <Label htmlFor="emergencyContactName">Full Name *</Label>
              <Input
                id="emergencyContactName"
                placeholder="Jane Smith"
                {...form.register('emergencyContactName')}
              />
              {form.formState.errors.emergencyContactName && (
                <p className="text-sm text-red-600">{form.formState.errors.emergencyContactName.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="emergencyContactPhone">Phone Number *</Label>
              <Input
                id="emergencyContactPhone"
                placeholder="+64 21 123 4567"
                {...form.register('emergencyContactPhone')}
              />
              {form.formState.errors.emergencyContactPhone && (
                <p className="text-sm text-red-600">{form.formState.errors.emergencyContactPhone.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="emergencyContactRelationship">Relationship *</Label>
              <Input
                id="emergencyContactRelationship"
                placeholder="Mother, Father, Partner, Friend, etc."
                {...form.register('emergencyContactRelationship')}
              />
              {form.formState.errors.emergencyContactRelationship && (
                <p className="text-sm text-red-600">{form.formState.errors.emergencyContactRelationship.message}</p>
              )}
            </div>
          </div>

          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
            <div className="flex items-start gap-2">
              <User className="w-5 h-5 text-amber-600 mt-0.5" />
              <div>
                <h4 className="font-medium text-amber-800">Privacy Notice</h4>
                <p className="text-sm text-amber-700 mt-1">
                  This information is kept strictly confidential and is only accessible to Village Co administrators for safety, verification, and emergency purposes. It will never be shared with parents or other users.
                </p>
              </div>
            </div>
          </div>

          <div className="flex justify-end">
            <Button
              type="submit"
              disabled={updateAddressMutation.isPending}
              className="flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              {updateAddressMutation.isPending ? 'Saving...' : 'Save Information'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}