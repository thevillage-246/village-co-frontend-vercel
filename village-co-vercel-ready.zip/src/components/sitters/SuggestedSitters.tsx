import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { TrustBar } from '@/components/profiles';
import { Link } from 'wouter';
import { MapPin, Star } from 'lucide-react';

interface SuggestedSittersProps {
  tags?: string[];
  limit?: number;
}

export function SuggestedSitters({ tags = [], limit = 3 }: SuggestedSittersProps) {
  // Query to fetch suggested sitters based on tags
  const { data: sitters = [], isLoading } = useQuery({
    queryKey: ['/api/sitters/suggested', { tags, limit }],
    enabled: tags.length > 0,
  });

  // If no tags provided or sitters not found, show general recommendation
  if ((!tags || tags.length === 0) && !isLoading) {
    return (
      <Card className="bg-linen/50 border-rose/20">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">Discover Sitters for You</CardTitle>
          <CardDescription>
            Complete your profile to get personalized sitter recommendations
          </CardDescription>
        </CardHeader>
        <CardFooter className="pt-2">
          <Button asChild variant="outline" className="w-full">
            <Link to="/parent/edit-profile">Set Preferences</Link>
          </Button>
        </CardFooter>
      </Card>
    );
  }

  if (isLoading) {
    return <SuggestedSittersSkeletons count={limit} />;
  }

  if (sitters.length === 0) {
    return (
      <Card className="bg-linen/50 border-rose/20">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">No Matches Found</CardTitle>
          <CardDescription>
            We couldn't find any sitters matching your preferences yet
          </CardDescription>
        </CardHeader>
        <CardFooter className="pt-2">
          <Button asChild variant="outline" className="w-full">
            <Link to="/find-sitter">Browse All Sitters</Link>
          </Button>
        </CardFooter>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold">Suggested Sitters</h3>
      <p className="text-sm text-muted-foreground mb-4">
        Based on your preferences and child's needs
      </p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {sitters.map((sitter: any) => (
          <Card key={sitter.id} className="overflow-hidden">
            <div className="aspect-video bg-muted relative">
              <img 
                src={sitter.profile_image || 'https://placehold.co/400x200?text=Village+Sitter'} 
                alt={sitter.first_name} 
                className="w-full h-full object-cover"
              />
              {sitter.distance && (
                <Badge className="absolute bottom-2 right-2 bg-background/80 text-foreground">
                  <MapPin className="h-3 w-3 mr-1" />
                  {sitter.distance < 1 ? '<1' : Math.round(sitter.distance)} km away
                </Badge>
              )}
            </div>
            
            <CardHeader className="pb-2">
              <CardTitle className="text-xl flex justify-between items-center">
                <span>{sitter.first_name}</span>
                <div className="flex items-center">
                  <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
                  <span className="text-sm ml-1">{sitter.rating || 'New'}</span>
                </div>
              </CardTitle>
              <CardDescription>
                {sitter.tagline || 'Experienced Village Sitter'}
              </CardDescription>
            </CardHeader>
            
            <CardContent className="pb-2">
              <TrustBar 
                verified={sitter.verified}
                firstAid={sitter.first_aid_certified}
                background={sitter.background_checked}
                valuesAligned={sitter.values_aligned}
                superSitter={sitter.super_sitter}
              />
              
              <div className="flex flex-wrap gap-1 mt-3">
                {sitter.tags?.slice(0, 3).map((tag: string) => (
                  <Badge key={tag} variant="outline" className="bg-linen text-wine">
                    {tag}
                  </Badge>
                ))}
              </div>
            </CardContent>
            
            <CardFooter>
              <Button asChild className="w-full bg-wine hover:bg-wine/90">
                <Link to={`/profile/${sitter.id}`}>View Profile</Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
}

function SuggestedSittersSkeletons({ count = 3 }: { count?: number }) {
  return (
    <div className="space-y-4">
      <Skeleton className="h-7 w-48" />
      <Skeleton className="h-4 w-full max-w-lg mb-4" />
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {Array(count).fill(0).map((_, i) => (
          <Card key={i} className="overflow-hidden">
            <Skeleton className="aspect-video w-full" />
            <CardHeader className="pb-2">
              <Skeleton className="h-6 w-32 mb-2" />
              <Skeleton className="h-4 w-full" />
            </CardHeader>
            <CardContent className="pb-2">
              <div className="flex gap-2 mb-4">
                <Skeleton className="h-6 w-24 rounded-full" />
                <Skeleton className="h-6 w-24 rounded-full" />
              </div>
              <div className="flex gap-1">
                <Skeleton className="h-5 w-16" />
                <Skeleton className="h-5 w-16" />
                <Skeleton className="h-5 w-16" />
              </div>
            </CardContent>
            <CardFooter>
              <Skeleton className="h-10 w-full" />
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
}