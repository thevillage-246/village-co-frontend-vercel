import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Upload, Camera, User, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

interface PhotoUploadProps {
  currentPhotoUrl?: string;
  sitterId: number;
  onPhotoUpdated: (photoUrl: string) => void;
}

export default function PhotoUpload({ currentPhotoUrl, sitterId, onPhotoUpdated }: PhotoUploadProps) {
  const [isUploading, setIsUploading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast({
        title: "Invalid File",
        description: "Please select an image file.",
        variant: "destructive",
      });
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        title: "File Too Large",
        description: "Please select an image smaller than 5MB.",
        variant: "destructive",
      });
      return;
    }

    // Create preview
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      setPreviewUrl(result);
    };
    reader.readAsDataURL(file);
  };

  const handleUpload = async () => {
    if (!previewUrl) return;

    setIsUploading(true);
    try {
      const response = await apiRequest('POST', `/api/sitters/${sitterId}/upload-photo`, {
        photoData: previewUrl
      });

      const data = await response.json();
      onPhotoUpdated(data.photoUrl);
      setPreviewUrl(null);
      
      toast({
        title: "Photo Uploaded",
        description: "Your profile photo has been updated successfully.",
      });

      // Reset file input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (error: any) {
      toast({
        title: "Upload Failed",
        description: error.message || "Failed to upload photo. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsUploading(false);
    }
  };

  const handleButtonClick = () => {
    fileInputRef.current?.click();
  };

  const cancelPreview = () => {
    setPreviewUrl(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Camera className="h-5 w-5" />
          Profile Photo
        </CardTitle>
        <CardDescription>
          Upload a clear, professional photo for your sitter profile
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-center space-x-6">
          {/* Current Photo */}
          <div className="text-center">
            <p className="text-sm font-medium mb-2">Current Photo</p>
            <Avatar className="h-20 w-20">
              <AvatarImage src={currentPhotoUrl} alt="Current profile photo" />
              <AvatarFallback>
                <User className="h-8 w-8" />
              </AvatarFallback>
            </Avatar>
          </div>

          {/* Preview Photo */}
          {previewUrl && (
            <div className="text-center">
              <p className="text-sm font-medium mb-2">New Photo</p>
              <Avatar className="h-20 w-20">
                <AvatarImage src={previewUrl} alt="Photo preview" />
                <AvatarFallback>
                  <User className="h-8 w-8" />
                </AvatarFallback>
              </Avatar>
            </div>
          )}
        </div>

        <div className="space-y-2">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileSelect}
            className="hidden"
          />
          
          {!previewUrl ? (
            <Button 
              onClick={handleButtonClick}
              variant="outline"
              className="w-full"
            >
              <Upload className="h-4 w-4 mr-2" />
              Select Photo
            </Button>
          ) : (
            <div className="space-y-2">
              <Button 
                onClick={handleUpload}
                disabled={isUploading}
                className="w-full"
              >
                {isUploading ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Uploading...
                  </>
                ) : (
                  <>
                    <Upload className="h-4 w-4 mr-2" />
                    Upload Photo
                  </>
                )}
              </Button>
              <Button 
                onClick={cancelPreview}
                variant="outline"
                className="w-full"
                disabled={isUploading}
              >
                Cancel
              </Button>
            </div>
          )}
        </div>

        <div className="text-xs text-gray-500">
          <p>• Accepted formats: JPG, PNG, GIF</p>
          <p>• Maximum file size: 5MB</p>
          <p>• Recommended: Square photo, clear face, professional appearance</p>
        </div>
      </CardContent>
    </Card>
  );
}