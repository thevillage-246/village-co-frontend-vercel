import React from 'react';
import { Link } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Calendar, MessageSquare, Star } from 'lucide-react';

interface Sitter {
  id: string;
  first_name: string;
  last_name?: string;
  profile_image?: string;
  rating?: number;
  last_booking_date?: string;
  tags?: string[];
  super_sitter?: boolean;
}

interface MySittersListProps {
  sitters: Sitter[];
  isLoading?: boolean;
}

export function MySittersList({ sitters = [], isLoading = false }: MySittersListProps) {
  if (isLoading) {
    return <MySittersListSkeleton />;
  }

  if (sitters.length === 0) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">My Trusted Sitters</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-6">
            <p className="text-muted-foreground">
              You haven't booked with any sitters yet.
            </p>
            <Button asChild className="mt-4 bg-wine hover:bg-wine/90">
              <Link to="/find-sitter">Find Sitters</Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg">My Trusted Sitters</CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="divide-y">
          {sitters.map((sitter) => (
            <li key={sitter.id} className="py-3 first:pt-0 last:pb-0">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Avatar className="h-10 w-10">
                    <AvatarImage src={sitter.profile_image} alt={sitter.first_name} />
                    <AvatarFallback className="bg-rose/30 text-wine">
                      {sitter.first_name?.charAt(0)}
                      {sitter.last_name?.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div>
                    <h4 className="font-medium">
                      {sitter.first_name} {sitter.last_name}
                      {sitter.super_sitter && (
                        <Badge className="ml-2 bg-amber-100 text-amber-800 border-amber-300 hover:bg-amber-200">
                          Super Sitter
                        </Badge>
                      )}
                    </h4>
                    <div className="flex items-center text-sm text-muted-foreground">
                      {sitter.rating ? (
                        <div className="flex items-center">
                          <Star className="h-3.5 w-3.5 text-amber-500 fill-amber-500 mr-1" />
                          <span>{sitter.rating.toFixed(1)}</span>
                        </div>
                      ) : (
                        <span>New Sitter</span>
                      )}
                      
                      {sitter.last_booking_date && (
                        <>
                          <span className="mx-2 text-muted-foreground">•</span>
                          <div className="flex items-center">
                            <Calendar className="h-3.5 w-3.5 mr-1" />
                            <span>Last booking: {new Date(sitter.last_booking_date).toLocaleDateString()}</span>
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="flex items-center gap-1 h-8" asChild>
                    <Link to={`/messages/${sitter.id}`}>
                      <MessageSquare className="h-3.5 w-3.5" />
                      <span className="hidden sm:inline">Message</span>
                    </Link>
                  </Button>
                  <Button size="sm" className="h-8 bg-rose hover:bg-rose/90" asChild>
                    <Link to={`/book?sitter=${sitter.id}`}>Book Again</Link>
                  </Button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}

function MySittersListSkeleton() {
  return (
    <Card>
      <CardHeader className="pb-2">
        <Skeleton className="h-6 w-32" />
      </CardHeader>
      <CardContent>
        <ul className="divide-y">
          {[1, 2, 3].map((i) => (
            <li key={i} className="py-3 first:pt-0 last:pb-0">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Skeleton className="h-10 w-10 rounded-full" />
                  <div>
                    <Skeleton className="h-4 w-32 mb-2" />
                    <Skeleton className="h-3 w-24" />
                  </div>
                </div>
                <div className="flex gap-2">
                  <Skeleton className="h-8 w-20" />
                  <Skeleton className="h-8 w-24" />
                </div>
              </div>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}