import React, { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Upload, X, Camera, Plus } from 'lucide-react';

interface MultiPhotoUploadProps {
  currentPhotos: string[];
  primaryPhoto?: string;
  sitterId: number;
  onPhotosUpdated: () => void;
}

export default function MultiPhotoUpload({ currentPhotos, primaryPhoto, sitterId, onPhotosUpdated }: MultiPhotoUploadProps) {
  const [uploading, setUploading] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const uploadPhotoMutation = useMutation({
    mutationFn: async (file: File) => {
      // Convert file to base64
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = async () => {
          try {
            const photoData = reader.result as string;
            const response = await apiRequest('POST', '/api/sitter/photos/upload', { photoData });
            resolve(response);
          } catch (error) {
            reject(error);
          }
        };
        reader.onerror = () => reject(new Error('Failed to read file'));
        reader.readAsDataURL(file);
      });
    },
    onSuccess: () => {
      onPhotosUpdated();
      toast({
        title: "Photo Uploaded",
        description: "Your photo has been uploaded successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Upload Failed",
        description: "Failed to upload photo. Please try again.",
        variant: "destructive",
      });
    }
  });

  const deletePhotoMutation = useMutation({
    mutationFn: async (photoUrl: string) => {
      return apiRequest('DELETE', '/api/sitter/photos/delete', { photoUrl });
    },
    onSuccess: () => {
      onPhotosUpdated();
      toast({
        title: "Photo Deleted",
        description: "Photo has been removed from your profile.",
      });
    },
    onError: () => {
      toast({
        title: "Delete Failed",
        description: "Failed to delete photo. Please try again.",
        variant: "destructive",
      });
    }
  });

  const setPrimaryPhotoMutation = useMutation({
    mutationFn: async (photoUrl: string) => {
      return apiRequest('PUT', '/api/sitter/photos/set-primary', { photoUrl });
    },
    onSuccess: () => {
      onPhotosUpdated();
      toast({
        title: "Primary Photo Set",
        description: "This photo is now your primary profile photo.",
      });
    }
  });

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "File Too Large",
          description: "Please select a photo under 5MB.",
          variant: "destructive",
        });
        return;
      }
      
      if (!file.type.startsWith('image/')) {
        toast({
          title: "Invalid File Type",
          description: "Please select an image file.",
          variant: "destructive",
        });
        return;
      }
      
      uploadPhotoMutation.mutate(file);
    }
  };

  const allPhotos = [...(currentPhotos || [])];
  if (primaryPhoto && !allPhotos.includes(primaryPhoto)) {
    allPhotos.unshift(primaryPhoto);
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-village-wine flex items-center gap-2">
          <Camera className="w-5 h-5" />
          Profile Photos
        </CardTitle>
        <CardDescription>
          Upload multiple photos to showcase yourself. The first photo will be your primary profile photo.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Current Photos Grid */}
        {allPhotos.length > 0 && (
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {allPhotos.map((photo, index) => (
              <div key={index} className="relative group">
                <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden">
                  <img 
                    src={photo} 
                    alt={`Profile photo ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </div>
                
                {/* Photo Actions Overlay */}
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center gap-2">
                  {photo !== primaryPhoto && (
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() => setPrimaryPhotoMutation.mutate(photo)}
                      disabled={setPrimaryPhotoMutation.isPending}
                    >
                      Set Primary
                    </Button>
                  )}
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={() => deletePhotoMutation.mutate(photo)}
                    disabled={deletePhotoMutation.isPending}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
                
                {/* Primary Photo Badge */}
                {photo === primaryPhoto && (
                  <div className="absolute top-2 left-2 bg-village-wine text-white text-xs px-2 py-1 rounded">
                    Primary
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Upload New Photo */}
        <div className="border-2 border-dashed border-gray-300 rounded-lg p-8">
          <div className="text-center">
            <Upload className="w-12 h-12 mx-auto text-gray-400 mb-4" />
            <div className="space-y-2">
              <p className="text-lg font-medium">Add New Photo</p>
              <p className="text-sm text-gray-500">
                Upload high-quality photos that show your personality
              </p>
              <div className="flex justify-center">
                <label className="cursor-pointer">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                    disabled={uploadPhotoMutation.isPending}
                  />
                  <Button
                    disabled={uploadPhotoMutation.isPending}
                    className="bg-village-wine hover:bg-village-wine/90"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    {uploadPhotoMutation.isPending ? 'Uploading...' : 'Choose Photo'}
                  </Button>
                </label>
              </div>
            </div>
          </div>
        </div>

        {/* Upload Guidelines */}
        <div className="bg-blue-50 p-4 rounded-lg">
          <h4 className="font-medium text-blue-900 mb-2">Photo Guidelines</h4>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• Clear, well-lit photos work best</li>
            <li>• Include photos that show you interacting with children (with permission)</li>
            <li>• Professional headshot as primary photo recommended</li>
            <li>• Maximum file size: 5MB per photo</li>
            <li>• Supported formats: JPG, PNG, WebP</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}