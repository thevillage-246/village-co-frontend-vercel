import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Upload, FileText, X } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';

interface QualificationUploadDialogProps {
  isOpen: boolean;
  onClose: () => void;
  sitterId: number;
}

const qualificationSchema = z.object({
  selectedQualifications: z.array(z.string()).min(1, "Please select at least one qualification"),
  additionalInfo: z.string().optional(),
  expiryDate: z.string().optional(),
  documents: z.array(z.instanceof(File)).optional()
});

type QualificationFormData = z.infer<typeof qualificationSchema>;

// Qualification options organized by category
const qualificationCategories = {
  "Health & Safety": [
    { key: "first_aid_certified", name: "First Aid Certified", emoji: "🩹" },
    { key: "cpr_certified", name: "CPR Certified", emoji: "❤️" },
    { key: "police_background_check", name: "Police Background Check", emoji: "🛡️" },
    { key: "child_protection_training", name: "Child Protection Training", emoji: "🔒" }
  ],
  "Education & Experience": [
    { key: "early_childhood_education", name: "Early Childhood Education", emoji: "🎓" },
    { key: "teaching_degree", name: "Teaching Degree", emoji: "📚" },
    { key: "montessori_training", name: "Montessori Training", emoji: "🌿" },
    { key: "special_needs_training", name: "Special Needs Training", emoji: "🌟" }
  ],
  "Additional Skills": [
    { key: "swimming_instructor", name: "Swimming Instructor", emoji: "🏊" },
    { key: "music_education", name: "Music Education", emoji: "🎵" },
    { key: "multilingual", name: "Multilingual", emoji: "🌍" }
  ]
};

export default function QualificationUploadDialog({ isOpen, onClose, sitterId }: QualificationUploadDialogProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);

  const form = useForm<QualificationFormData>({
    resolver: zodResolver(qualificationSchema),
    defaultValues: {
      selectedQualifications: [],
      additionalInfo: "",
      expiryDate: "",
      documents: []
    }
  });

  const uploadMutation = useMutation({
    mutationFn: async (data: QualificationFormData) => {
      // Get current sitter profile first
      const profileResponse = await apiRequest('GET', `/api/sitters/${sitterId}/profile`);
      const currentProfile = await profileResponse.json();
      
      // Create new qualification objects from selected qualifications
      const newQualifications = data.selectedQualifications.map(qualKey => {
        const qualOption = Object.values(qualificationCategories)
          .flat()
          .find(q => q.key === qualKey);
        
        return {
          id: Math.random(), // Temporary ID for frontend
          sitterId: sitterId,
          category: Object.keys(qualificationCategories).find(cat => 
            qualificationCategories[cat as keyof typeof qualificationCategories].some(q => q.key === qualKey)
          ) || 'Additional Skills',
          qualificationKey: qualKey,
          displayName: qualOption?.name || qualKey,
          emoji: qualOption?.emoji || '📋',
          isVerified: false,
          verifiedAt: null,
          verifiedBy: null,
          additionalInfo: data.additionalInfo || null,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString()
        };
      });
      
      // Merge with existing qualifications (avoiding duplicates)
      const existingQualifications = currentProfile.qualifications || [];
      const existingKeys = existingQualifications.map((q: any) => q.qualificationKey);
      const uniqueNewQualifications = newQualifications.filter(q => !existingKeys.includes(q.qualificationKey));
      
      const updatedQualifications = [...existingQualifications, ...uniqueNewQualifications];
      
      // Update sitter profile with new qualifications
      return apiRequest('PATCH', `/api/sitters/${sitterId}/profile`, {
        qualifications: updatedQualifications
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sitters', sitterId, 'profile'] });
      toast({
        title: "Qualifications Added",
        description: "Your qualifications have been added to your profile for admin verification.",
      });
      onClose();
      form.reset();
      setUploadedFiles([]);
    },
    onError: (error: Error) => {
      toast({
        title: "Upload Failed",
        description: error.message || "Failed to add qualifications. Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    setUploadedFiles(prev => [...prev, ...files]);
  };

  const removeFile = (index: number) => {
    setUploadedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const onSubmit = (data: QualificationFormData) => {
    uploadMutation.mutate({
      ...data,
      documents: uploadedFiles
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Add Qualifications</DialogTitle>
          <DialogDescription>
            Select the qualifications and certifications you have. Upload supporting documents for verification.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {/* Qualification Selection */}
            <FormField
              control={form.control}
              name="selectedQualifications"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Select Your Qualifications</FormLabel>
                  <FormControl>
                    <div className="space-y-6">
                      {Object.entries(qualificationCategories).map(([category, qualifications]) => (
                        <div key={category}>
                          <h4 className="font-medium text-village-wine mb-3">{category}</h4>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            {qualifications.map((qual) => (
                              <div key={qual.key} className="flex items-center space-x-3">
                                <Checkbox
                                  id={qual.key}
                                  checked={field.value.includes(qual.key)}
                                  onCheckedChange={(checked) => {
                                    if (checked) {
                                      field.onChange([...field.value, qual.key]);
                                    } else {
                                      field.onChange(field.value.filter(item => item !== qual.key));
                                    }
                                  }}
                                />
                                <label 
                                  htmlFor={qual.key}
                                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer flex items-center gap-2"
                                >
                                  <span>{qual.emoji}</span>
                                  <span>{qual.name}</span>
                                </label>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Document Upload */}
            <div className="space-y-4">
              <FormLabel>Supporting Documents</FormLabel>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <div className="text-sm text-gray-600 mb-4">
                  Upload certificates, licenses, or other supporting documents
                </div>
                <input
                  type="file"
                  multiple
                  accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                  onChange={handleFileUpload}
                  className="hidden"
                  id="file-upload"
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => document.getElementById('file-upload')?.click()}
                >
                  Choose Files
                </Button>
              </div>
              
              {/* File List */}
              {uploadedFiles.length > 0 && (
                <div className="space-y-2">
                  <p className="text-sm font-medium">Uploaded Files:</p>
                  {uploadedFiles.map((file, index) => (
                    <div key={index} className="flex items-center justify-between bg-gray-50 p-3 rounded-lg">
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4 text-gray-500" />
                        <span className="text-sm font-medium">{file.name}</span>
                        <span className="text-xs text-gray-500">
                          ({Math.round(file.size / 1024)} KB)
                        </span>
                      </div>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => removeFile(index)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Additional Information */}
            <FormField
              control={form.control}
              name="additionalInfo"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Additional Information (Optional)</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Add any additional details about your qualifications..."
                      className="min-h-[80px]"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Expiry Date */}
            <FormField
              control={form.control}
              name="expiryDate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Expiry Date (Optional)</FormLabel>
                  <FormControl>
                    <Input
                      type="date"
                      placeholder="When does this qualification expire?"
                      {...field}
                    />
                  </FormControl>
                  <p className="text-sm text-gray-500">
                    If your qualification has an expiry date, please enter it so we can remind you when renewal is needed.
                  </p>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Actions */}
            <div className="flex justify-end gap-3">
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={uploadMutation.isPending}
                className="bg-village-wine hover:bg-village-wine/90"
              >
                {uploadMutation.isPending ? "Submitting..." : "Submit for Verification"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}