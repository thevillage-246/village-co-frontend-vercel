import React from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { 
  CheckCircle2, XCircle, Clock, AlertCircle, Loader2, 
  ShieldCheck, Award, Users, FileCheck, BookOpen
} from "lucide-react";

interface Step {
  id: string;
  title: string;
  description: string;
  completed: boolean;
  icon: React.ReactNode;
  action?: () => void;
  actionLabel?: string;
}

interface SitterOnboardingProgressProps {
  userId: number;
  onCompleteStep?: (stepId: string) => void;
}

export default function SitterOnboardingProgress({ userId, onCompleteStep }: SitterOnboardingProgressProps) {
  const { data: profile, isLoading } = useQuery({
    queryKey: ['/api/sitters', userId],
    queryFn: async () => {
      return apiRequest(`GET`, `/api/sitters/${userId}`).then(res => res.json());
    },
  });

  const generateSteps = (profile: any): Step[] => {
    if (!profile) return [];

    return [
      {
        id: "profileComplete",
        title: "Complete Profile",
        description: "Add your photo, bio, and experience.",
        completed: !!profile.bio && !!profile.experience && !!profile.photoUrl,
        icon: <Users className="h-5 w-5 text-blue-500" />,
        action: () => onCompleteStep?.("profileComplete"),
        actionLabel: "Edit Profile"
      },
      {
        id: "valuesQuiz",
        title: "Values Assessment",
        description: "Complete our childcare values assessment.",
        completed: !!profile.valuesQuizComplete,
        icon: <BookOpen className="h-5 w-5 text-indigo-500" />,
        action: () => onCompleteStep?.("valuesQuiz"),
        actionLabel: "Take Assessment"
      },
      {
        id: "references",
        title: "Submit References",
        description: "Provide contact information for 2 references.",
        completed: !!profile.referencesSubmitted,
        icon: <Users className="h-5 w-5 text-violet-500" />,
        action: () => onCompleteStep?.("references"),
        actionLabel: "Add References"
      },
      {
        id: "identityVerification",
        title: "Identity Verification",
        description: "Verify your identity through our secure system.",
        completed: !!profile.identityVerified,
        icon: <ShieldCheck className="h-5 w-5 text-emerald-500" />,
        action: () => onCompleteStep?.("identityVerification"),
        actionLabel: "Verify Identity"
      },
      {
        id: "firstAidCert",
        title: "First Aid Certification",
        description: "Upload your First Aid/CPR certification.",
        completed: !!profile.firstAidCertDate,
        icon: <FileCheck className="h-5 w-5 text-red-500" />,
        action: () => onCompleteStep?.("firstAidCert"),
        actionLabel: "Upload Certificate"
      },
      {
        id: "training",
        title: "Training Modules",
        description: "Complete our online safety and childcare training.",
        completed: !!profile.trainingComplete,
        icon: <Award className="h-5 w-5 text-amber-500" />,
        action: () => onCompleteStep?.("training"),
        actionLabel: "Start Training"
      }
    ];
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="pt-6 flex justify-center">
          <Loader2 className="h-6 w-6 animate-spin text-wine" />
        </CardContent>
      </Card>
    );
  }

  if (!profile) {
    return (
      <Card>
        <CardContent className="pt-6 text-center">
          <AlertCircle className="h-10 w-10 text-muted-foreground mx-auto mb-2" />
          <p>Failed to load profile information.</p>
        </CardContent>
      </Card>
    );
  }

  const steps = generateSteps(profile);
  const completedSteps = steps.filter(step => step.completed).length;
  const progress = Math.round((completedSteps / steps.length) * 100);
  const isProfileComplete = progress === 100;

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-xl font-semibold">Sitter Onboarding</CardTitle>
        <CardDescription>
          Complete these steps to be ready for bookings
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>Readiness Score</span>
            <span className={`font-medium ${isProfileComplete ? 'text-green-600' : 'text-wine'}`}>
              {progress}% Complete
            </span>
          </div>
          <Progress 
            value={progress} 
            className="h-2" 
            indicatorClassName={isProfileComplete ? "bg-green-600" : "bg-wine"} 
          />
          
          {isProfileComplete ? (
            <div className="flex items-center mt-1 text-sm text-green-600">
              <CheckCircle2 className="h-4 w-4 mr-1" />
              <span>All steps completed! You're ready to accept bookings.</span>
            </div>
          ) : (
            <div className="flex items-center mt-1 text-sm text-muted-foreground">
              <Clock className="h-4 w-4 mr-1" />
              <span>{steps.length - completedSteps} steps remaining</span>
            </div>
          )}
        </div>
        
        <div className="space-y-3 mt-4">
          {steps.map(step => (
            <div 
              key={step.id} 
              className={`flex items-start p-3 rounded-md border ${
                step.completed ? 'bg-green-50 border-green-200' : 'bg-muted/20'
              }`}
            >
              <div className="mr-3 mt-0.5">
                {step.completed ? (
                  <CheckCircle2 className="h-5 w-5 text-green-600" />
                ) : (
                  <div className="flex-shrink-0">{step.icon}</div>
                )}
              </div>
              
              <div className="flex-grow">
                <h4 className="text-sm font-medium">{step.title}</h4>
                <p className="text-xs text-muted-foreground">{step.description}</p>
              </div>
              
              {!step.completed && step.action && (
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={step.action}
                  className="ml-2 whitespace-nowrap"
                >
                  {step.actionLabel || "Complete"}
                </Button>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}