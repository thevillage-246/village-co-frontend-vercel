import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Save } from 'lucide-react';

const sitterProfileSchema = z.object({
  bio: z.string().max(2000, 'Bio must be less than 2000 characters'),
  experience: z.string().max(1000, 'Experience must be less than 1000 characters'),
  hourlyRate: z.string().min(1, 'Hourly rate is required'),
  whyKidsQuote: z.string().max(200, 'Quote must be less than 200 characters'),
  references: z.string().max(5000, 'References must be less than 5000 characters').optional(),
  availabilityTags: z.array(z.string()).default([]),
  age: z.number().min(16, 'Must be at least 16 years old').max(100, 'Invalid age'),
  isActive: z.boolean().default(true),
});

type SitterProfileData = z.infer<typeof sitterProfileSchema>;

interface EditSitterProfileFormProps {
  profile: any;
  onSuccess: () => void;
}

export default function EditSitterProfileForm({ profile, onSuccess }: EditSitterProfileFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const form = useForm<SitterProfileData>({
    resolver: zodResolver(sitterProfileSchema),
    defaultValues: {
      bio: profile?.bio || '',
      experience: profile?.experience || '',
      hourlyRate: profile?.hourlyRate || '',
      whyKidsQuote: profile?.whyKidsQuote || '',
      references: profile?.references || '',
      availabilityTags: profile?.availabilityTags || [],
      age: profile?.age || 18,
      isActive: profile?.isActive ?? true,
    },
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (data: SitterProfileData) => {
      console.log('🔧 Submitting profile data:', data);
      const response = await apiRequest('PUT', '/api/sitter/profile', data);
      console.log('🔧 Profile update response:', response);
      return response;
    },
    onSuccess: (data) => {
      console.log('✅ Profile update successful:', data);
      
      // Invalidate relevant queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/sitter/profile'] });
      queryClient.invalidateQueries({ queryKey: ['/api/sitter'] });
      
      onSuccess();
      toast({
        title: "Profile Updated",
        description: "Your sitter profile has been updated successfully.",
      });
    },
    onError: (error: any) => {
      console.error('❌ Profile update failed:', error);
      toast({
        title: "Update Failed",
        description: error.message || "Failed to update profile. Please try again.",
        variant: "destructive",
      });
    }
  });

  const onSubmit = (data: SitterProfileData) => {
    updateProfileMutation.mutate(data);
  };

  const availabilityOptions = [
    'Weekends',
    'After School',
    'Evenings',
    'Date Nights',
    'Emergency Care',
    'Overnight',
    'School Holidays',
    'Public Holidays'
  ];

  const toggleAvailabilityTag = (tag: string) => {
    const currentTags = form.getValues('availabilityTags');
    const newTags = currentTags.includes(tag)
      ? currentTags.filter(t => t !== tag)
      : [...currentTags, tag];
    form.setValue('availabilityTags', newTags);
  };

  return (
    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
      <div className="space-y-2">
        <Label htmlFor="bio" className="text-sm font-medium text-[#6B3E4B]">
          Bio
        </Label>
        <Textarea
          id="bio"
          {...form.register('bio')}
          className="rounded-xl border-gray-200 focus:border-[#6B3E4B] min-h-[100px]"
          placeholder="Tell parents about yourself in 2-3 lines..."
        />
        <p className="text-xs text-gray-500">
          {form.watch('bio')?.length || 0}/2000 characters
        </p>
        {form.formState.errors.bio && (
          <p className="text-sm text-red-600">{form.formState.errors.bio.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="experience" className="text-sm font-medium text-[#6B3E4B]">
          Experience & Background
        </Label>
        <Textarea
          id="experience"
          {...form.register('experience')}
          className="rounded-xl border-gray-200 focus:border-[#6B3E4B] min-h-[120px]"
          placeholder="Describe your childcare experience, qualifications, and background..."
        />
        <p className="text-xs text-gray-500">
          {form.watch('experience')?.length || 0}/1000 characters
        </p>
        {form.formState.errors.experience && (
          <p className="text-sm text-red-600">{form.formState.errors.experience.message}</p>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="hourlyRate" className="text-sm font-medium text-[#6B3E4B]">
            Hourly Rate (NZD) *
          </Label>
          <Input
            id="hourlyRate"
            {...form.register('hourlyRate')}
            className="rounded-xl border-gray-200 focus:border-[#6B3E4B]"
            placeholder="e.g. $25"
          />
          {form.formState.errors.hourlyRate && (
            <p className="text-sm text-red-600">{form.formState.errors.hourlyRate.message}</p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="age" className="text-sm font-medium text-[#6B3E4B]">
            Age *
          </Label>
          <Input
            id="age"
            type="number"
            {...form.register('age', { valueAsNumber: true })}
            className="rounded-xl border-gray-200 focus:border-[#6B3E4B]"
            placeholder="Enter your age"
          />
          {form.formState.errors.age && (
            <p className="text-sm text-red-600">{form.formState.errors.age.message}</p>
          )}
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="whyKidsQuote" className="text-sm font-medium text-[#6B3E4B]">
          Why I Love Working with Kids
        </Label>
        <Textarea
          id="whyKidsQuote"
          {...form.register('whyKidsQuote')}
          className="rounded-xl border-gray-200 focus:border-[#6B3E4B] min-h-[80px]"
          placeholder="Share what you love most about caring for children..."
        />
        <p className="text-xs text-gray-500">
          {form.watch('whyKidsQuote')?.length || 0}/200 characters
        </p>
        {form.formState.errors.whyKidsQuote && (
          <p className="text-sm text-red-600">{form.formState.errors.whyKidsQuote.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="references" className="text-sm font-medium text-[#6B3E4B]">
          References
        </Label>
        <Textarea
          id="references"
          {...form.register('references')}
          className="rounded-xl border-gray-200 focus:border-[#6B3E4B] min-h-[120px]"
          placeholder="Copy and paste your references here, including contact details, previous experience with families, or other testimonials..."
        />
        <p className="text-xs text-gray-500">
          {form.watch('references')?.length || 0}/5000 characters
        </p>
        {form.formState.errors.references && (
          <p className="text-sm text-red-600">{form.formState.errors.references.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <Label className="text-sm font-medium text-[#6B3E4B]">
          Availability Tags
        </Label>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {availabilityOptions.map((tag) => (
            <button
              key={tag}
              type="button"
              onClick={() => toggleAvailabilityTag(tag)}
              className={`p-2 text-sm rounded-xl border transition-colors ${
                form.watch('availabilityTags')?.includes(tag)
                  ? 'bg-[#6B3E4B] text-white border-[#6B3E4B]'
                  : 'bg-white text-gray-700 border-gray-200 hover:border-[#6B3E4B]'
              }`}
            >
              {tag}
            </button>
          ))}
        </div>
      </div>



      <div className="flex items-center justify-between p-4 bg-[#F9F5F0] rounded-xl">
        <div>
          <Label htmlFor="isActive" className="text-sm font-medium text-[#6B3E4B]">
            Profile Active
          </Label>
          <p className="text-xs text-gray-600">
            When active, your profile is visible to parents
          </p>
        </div>
        <Switch
          id="isActive"
          checked={form.watch('isActive')}
          onCheckedChange={(checked) => form.setValue('isActive', checked)}
        />
      </div>

      <Button
        type="submit"
        disabled={updateProfileMutation.isPending}
        className="w-full bg-[#6B3E4B] hover:bg-[#5A334A] text-white rounded-xl shadow-lg"
      >
        <Save className="h-4 w-4 mr-2" />
        {updateProfileMutation.isPending ? 'Saving...' : 'Save Profile Changes'}
      </Button>
    </form>
  );
}