import React, { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Loader2, Save } from 'lucide-react';

// Define schema for sitter profile form
const sitterProfileSchema = z.object({
  bio: z.string()
    .min(10, { message: 'Bio must be at least 10 characters' })
    .max(500, { message: 'Bio cannot exceed 500 characters' }),
  experience: z.string()
    .min(10, { message: 'Experience description must be at least 10 characters' })
    .max(1000, { message: 'Experience description cannot exceed 1000 characters' }),
  hourlyRate: z.string()
    .refine((val) => !isNaN(parseFloat(val)) && parseFloat(val) > 0, {
      message: 'Hourly rate must be a number greater than 0',
    }),
  age: z.string()
    .refine((val) => val === '' || (!isNaN(parseInt(val)) && parseInt(val) >= 16), {
      message: 'Age must be at least 16',
    })
    .optional(),
  photoUrl: z.string().url({ message: 'Please enter a valid URL for your photo' }).optional().or(z.literal('')),
});

type SitterProfileFormValues = z.infer<typeof sitterProfileSchema>;

interface SitterProfileFormProps {
  userId: number;
  profileData?: any;
  onSaved: () => void;
}

export default function SitterProfileForm({ userId, profileData, onSaved }: SitterProfileFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Initialize form with existing profile data or defaults
  const form = useForm<SitterProfileFormValues>({
    resolver: zodResolver(sitterProfileSchema),
    defaultValues: {
      bio: profileData?.bio || '',
      experience: profileData?.experience || '',
      hourlyRate: profileData?.hourlyRate ? String(profileData.hourlyRate) : '',
      age: profileData?.age ? String(profileData.age) : '',
      photoUrl: profileData?.photoUrl || '',
    },
  });

  // Submit handler
  const onSubmit = async (values: SitterProfileFormValues) => {
    setIsSubmitting(true);
    
    try {
      const payload = {
        ...values,
        hourlyRate: parseFloat(values.hourlyRate),
        age: values.age ? parseInt(values.age) : undefined,
      };
      
      // Check if this is an update or create
      if (profileData?.id) {
        // Update existing profile
        await apiRequest('PATCH', `/api/sitters/${profileData.id}/profile`, payload);
      } else {
        // Create new profile
        await apiRequest('POST', `/api/sitters/${userId}/profile`, {
          ...payload,
          userId,
        });
      }
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/sitters', userId] });
      
      toast({
        title: 'Profile Saved',
        description: 'Your sitter profile has been updated successfully.',
      });
      
      // Notify parent component
      onSaved();
    } catch (error) {
      console.error('Error saving profile:', error);
      toast({
        title: 'Save Failed',
        description: 'There was a problem saving your profile. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card>
      <CardContent className="pt-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="bio"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Bio</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Tell parents about yourself, your personality and why you enjoy babysitting..."
                      className="min-h-[100px]"
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>
                    This will be displayed on your profile for parents to see.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="experience"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Experience</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Describe your experience with childcare, including babysitting, nannying, or other relevant experience..."
                      className="min-h-[100px]"
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>
                    Share your relevant childcare experience and qualifications.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="hourlyRate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Hourly Rate ($)</FormLabel>
                    <FormControl>
                      <Input 
                        type="text" 
                        placeholder="25.00" 
                        {...field} 
                      />
                    </FormControl>
                    <FormDescription>
                      Set your hourly rate in New Zealand dollars.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="age"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Age (Optional)</FormLabel>
                    <FormControl>
                      <Input 
                        type="text" 
                        placeholder="21" 
                        {...field} 
                      />
                    </FormControl>
                    <FormDescription>
                      Your age will be shown to parents.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="photoUrl"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Profile Photo URL (Optional)</FormLabel>
                  <FormControl>
                    <Input 
                      type="text" 
                      placeholder="https://example.com/your-photo.jpg" 
                      {...field} 
                    />
                  </FormControl>
                  <FormDescription>
                    Enter a URL for your profile photo. You can use services like Imgur to host your image.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Button type="submit" className="w-full" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Save Profile
                </>
              )}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}