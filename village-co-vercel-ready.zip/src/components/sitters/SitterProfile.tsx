import React, { useState } from 'react';
import { format } from 'date-fns';
import { Calendar, Clock, BadgeCheck, MapPin, Star, MessageCircle, Video, BookOpen } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import BookingForm from '../booking/BookingForm';
import ReviewList from '../reviews/ReviewList';

interface SitterProfileProps {
  userId: number;
  showBookingForm?: boolean;
}

const SitterProfile: React.FC<SitterProfileProps> = ({ userId, showBookingForm = false }) => {
  const [activeTab, setActiveTab] = useState(showBookingForm ? 'book' : 'about');
  const [, navigate] = useLocation();

  // Fetch sitter profile
  const { data: sitter, isLoading } = useQuery({
    queryKey: [`/api/sitters/${userId}/profile`],
    enabled: !!userId,
  });

  // Fetch sitter availability
  const { data: availability } = useQuery({
    queryKey: [`/api/sitters/${sitter?.id}/availability`],
    enabled: !!sitter?.id,
  });

  // Fetch sitter reviews
  const { data: reviews } = useQuery({
    queryKey: [`/api/sitters/${sitter?.id}/reviews`],
    enabled: !!sitter?.id,
  });

  if (isLoading) {
    return (
      <div className="flex justify-center p-8">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!sitter) {
    return (
      <div className="text-center py-8">
        <p className="text-destructive">Sitter profile not found.</p>
      </div>
    );
  }

  // Calculate average rating
  const averageRating = reviews?.length 
    ? reviews.reduce((acc, review) => acc + review.rating, 0) / reviews.length 
    : 0;

  // Generate initials for avatar fallback
  const getInitials = () => {
    return `${sitter.firstName?.[0] || ''}${sitter.lastName?.[0] || ''}`;
  };

  return (
    <div className="container mx-auto py-8 px-4 sm:px-6 lg:px-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Left column - Profile info */}
        <div className="md:col-span-1 space-y-6">
          {/* Profile Card */}
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col items-center">
                <div className="relative mb-4">
                  <Avatar className="h-24 w-24">
                    <AvatarImage src={sitter.photoUrl} alt={`${sitter.firstName} ${sitter.lastName}`} />
                    <AvatarFallback className="text-3xl">{getInitials()}</AvatarFallback>
                  </Avatar>
                  {sitter.isApproved && (
                    <Badge variant="secondary" className="absolute -bottom-2 right-0 flex gap-1 items-center">
                      <BadgeCheck className="h-3 w-3 text-primary" />
                      <span>Verified</span>
                    </Badge>
                  )}
                </div>
                
                <h2 className="text-xl font-semibold mb-1">{sitter.firstName} {sitter.lastName}</h2>
                
                {sitter.age && (
                  <p className="text-sm text-muted-foreground mb-2">{sitter.age} years old</p>
                )}

                {sitter.location && (
                  <div className="flex items-center gap-1 text-sm text-muted-foreground mb-2">
                    <MapPin className="h-4 w-4" />
                    <span>{sitter.location}</span>
                  </div>
                )}
                
                <div className="flex items-center gap-1 mb-4">
                  <div className="flex text-yellow-400">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className="h-4 w-4"
                        fill={i < Math.floor(averageRating) ? "currentColor" : "none"}
                        fillOpacity={i < Math.floor(averageRating) ? 1 : 0.2}
                      />
                    ))}
                  </div>
                  <span className="text-sm text-muted-foreground">
                    {averageRating.toFixed(1)} ({reviews?.length || 0} reviews)
                  </span>
                </div>
                
                <div className="bg-muted/50 rounded-md p-3 w-full text-center mb-4">
                  <span className="block text-2xl font-bold">{sitter.hourlyRate?.toLocaleString('en-NZ', { style: 'currency', currency: 'NZD' })}</span>
                  <span className="text-sm text-muted-foreground">per hour</span>
                </div>
                
                <div className="flex flex-col space-y-2 w-full">
                  <Button 
                    className="w-full" 
                    onClick={() => setActiveTab('book')}
                    disabled={activeTab === 'book'}
                  >
                    <BookOpen className="h-4 w-4 mr-2" />
                    Book Now
                  </Button>
                  
                  <Button 
                    className="w-full"
                    variant="outline"
                    onClick={() => navigate(`/messages?sitterId=${sitter.id}`)}
                  >
                    <MessageCircle className="h-4 w-4 mr-2" />
                    Contact Me
                  </Button>
                  
                  <Button
                    className="w-full"
                    variant="outline"
                    onClick={() => alert('Video chat coming soon!')}
                  >
                    <Video className="h-4 w-4 mr-2" />
                    Start Video Chat
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Availability Card */}
          {availability && availability.length > 0 && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Availability</CardTitle>
                <CardDescription>Available time slots for bookings</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {/* Group availability by day and sort by day of week */}
                  {[...Array(7)].map((_, dayIndex) => {
                    const dayAvailability = availability.filter(slot => slot.dayOfWeek === dayIndex);
                    if (dayAvailability.length === 0) return null;
                    
                    // Format day name
                    const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
                    
                    // Format time slots
                    const formatTime = (time24: string) => {
                      const [hours, minutes] = time24.split(':');
                      const hour = parseInt(hours);
                      const period = hour >= 12 ? 'PM' : 'AM';
                      const hour12 = hour % 12 || 12;
                      return `${hour12}:${minutes} ${period}`;
                    };
                    
                    return (
                      <div key={dayIndex} className="flex justify-between items-center py-2 border-b last:border-0">
                        <span className="font-medium">{dayNames[dayIndex]}</span>
                        <div className="flex flex-col gap-1 items-end">
                          {dayAvailability.map(slot => (
                            <div key={slot.id} className="text-sm">
                              {formatTime(slot.startTime)} - {formatTime(slot.endTime)}
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
        
        {/* Right column - Tabs */}
        <div className="md:col-span-2">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="about">About</TabsTrigger>
              <TabsTrigger value="book">Book</TabsTrigger>
            </TabsList>
            
            <TabsContent value="about" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>About {sitter.firstName}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="whitespace-pre-line">{sitter.bio}</p>
                </CardContent>
              </Card>
              
              {sitter.skills && sitter.skills.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle>Skills & Experience</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {sitter.skills.map(skill => (
                        <Badge key={skill.id} variant="secondary">
                          {skill.name}
                        </Badge>
                      ))}
                    </div>
                    
                    {sitter.experience && (
                      <div className="mt-4">
                        <h4 className="font-medium mb-2">Experience</h4>
                        <p>{sitter.experience}</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}
              
              {/* Reviews Section */}
              <Card>
                <CardHeader>
                  <CardTitle>Reviews</CardTitle>
                </CardHeader>
                <CardContent>
                  {reviews && reviews.length > 0 ? (
                    <ReviewList reviews={reviews} />
                  ) : (
                    <p className="text-muted-foreground text-center py-4">
                      No reviews yet.
                    </p>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="book">
              <BookingForm 
                sitterId={sitter.id} 
                sitterName={`${sitter.firstName} ${sitter.lastName}`} 
                hourlyRate={sitter.hourlyRate}
                availability={availability}
              />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default SitterProfile;
