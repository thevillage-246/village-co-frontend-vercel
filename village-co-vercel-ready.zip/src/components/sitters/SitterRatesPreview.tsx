import React from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { apiRequest } from "@/lib/queryClient";
import { Loader2, DollarSign, Clock } from "lucide-react";

interface SitterRatesPreviewProps {
  sitterId: number;
}

export default function SitterRatesPreview({ sitterId }: SitterRatesPreviewProps) {
  // Fetch sitter rates
  const { data: rates, isLoading, error } = useQuery({
    queryKey: ['/api/sitters', sitterId, 'rates'],
    queryFn: async () => 
      apiRequest(`GET`, `/api/sitters/${sitterId}/rates`).then(res => res.json()),
  });

  if (isLoading) {
    return (
      <div className="flex justify-center py-4">
        <Loader2 className="h-6 w-6 animate-spin text-wine" />
      </div>
    );
  }

  if (error || !rates) {
    return (
      <div className="text-sm text-muted-foreground p-4 text-center">
        Unable to load rate information at this time.
      </div>
    );
  }

  return (
    <Card className="bg-linen/50 border-0 shadow-sm">
      <CardContent className="p-4">
        <h3 className="font-medium text-wine mb-3">Babysitting Rates</h3>
        
        <div className="space-y-3">
          {rates.map((rate: any) => (
            <div key={rate.id} className="flex justify-between items-center">
              <div className="flex items-center">
                <Clock className="h-4 w-4 mr-2 text-rose" />
                <span className="text-sm">{rate.label}</span>
              </div>
              <div className="font-medium flex items-center text-wine">
                <DollarSign className="h-4 w-4" />
                <span>{parseFloat(rate.value).toFixed(2)}</span>
                <span className="text-xs text-muted-foreground ml-1">/hour</span>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-4 pt-3 border-t text-xs text-muted-foreground">
          <p>Rates are subject to 10% service fee.</p>
          <p>Additional charges may apply for special services.</p>
        </div>
      </CardContent>
    </Card>
  );
}