import React, { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { format, parseISO } from "date-fns";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MoodTracker } from "@/components/mood/MoodTracker";
import { Clock, Calendar, MapPin, User, Users } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface ActiveBookingProps {
  sitterId: number;
}

export function ActiveBooking({ sitterId }: ActiveBookingProps) {
  const [, navigate] = useLocation();
  const { data: activeBookings, isLoading } = useQuery({
    queryKey: ['/api/bookings/active', sitterId],
    queryFn: async () => {
      const res = await apiRequest('GET', `/api/bookings/active/${sitterId}`);
      return res.json();
    }
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Active Booking</CardTitle>
          <CardDescription>Loading active booking information...</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  if (!activeBookings || activeBookings.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>No Active Bookings</CardTitle>
          <CardDescription>You don't have any active bookings right now.</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  // Select the first active booking
  const booking = activeBookings[0];
  const startTime = parseISO(booking.startTime);
  const endTime = parseISO(booking.endTime);

  return (
    <Card className="mb-6">
      <CardHeader className="bg-primary/5">
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Active Booking</CardTitle>
            <CardDescription>Currently babysitting for {booking.parent?.firstName} {booking.parent?.lastName}</CardDescription>
          </div>
          <Badge variant="success" className="px-3 py-1">Active Now</Badge>
        </div>
      </CardHeader>
      <CardContent className="pt-6">
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="mb-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="mood">Mood Tracking</TabsTrigger>
            <TabsTrigger value="location">Location</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-3">
                <div className="flex items-center">
                  <Calendar className="h-4 w-4 mr-2 text-muted-foreground" />
                  <span>{format(startTime, 'EEEE, MMMM d, yyyy')}</span>
                </div>
                <div className="flex items-center">
                  <Clock className="h-4 w-4 mr-2 text-muted-foreground" />
                  <span>{format(startTime, 'h:mm a')} - {format(endTime, 'h:mm a')}</span>
                </div>
                <div className="flex items-center">
                  <MapPin className="h-4 w-4 mr-2 text-muted-foreground" />
                  <span>{booking.parent?.address}, {booking.parent?.city}</span>
                </div>
              </div>
              <div className="space-y-3">
                <div className="flex items-center">
                  <Users className="h-4 w-4 mr-2 text-muted-foreground" />
                  <span>
                    <strong>Children:</strong> {booking.children?.map((child: any) => 
                      `${child.firstName} ${child.lastName}`
                    ).join(', ') || 'No children information'}
                  </span>
                </div>
                <div className="flex items-center">
                  <User className="h-4 w-4 mr-2 text-muted-foreground" />
                  <span>
                    <strong>Parent:</strong> {booking.parent?.firstName} {booking.parent?.lastName} (
                    <a href={`tel:${booking.parent?.phone}`} className="text-primary hover:underline">
                      {booking.parent?.phone}
                    </a>)
                  </span>
                </div>
              </div>
            </div>
            
            {booking.specialRequests && (
              <div className="mt-4 p-4 bg-muted rounded-md">
                <h4 className="font-medium mb-1">Special Requests:</h4>
                <p>{booking.specialRequests}</p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="mood">
            <MoodTracker 
              bookingId={booking.id}
              sitterId={sitterId}
              children={booking.children || []}
            />
          </TabsContent>
          
          <TabsContent value="location">
            <div className="text-center py-8">
              <Button onClick={() => navigate(`/location-sharing/${booking.id}`)}>
                Share Location with Parent
              </Button>
              <p className="text-sm text-muted-foreground mt-2">
                This helps parents know you've arrived safely and where the children are.
              </p>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="border-t bg-muted/50 px-6 py-4">
        <Button 
          variant="outline" 
          className="ml-auto mr-2"
          onClick={() => navigate(`/booking/${booking.id}`)}
        >
          Booking Details
        </Button>
        <Button
          variant="default"
          onClick={() => navigate(`/booking/${booking.id}/complete`)}
        >
          Complete Booking
        </Button>
      </CardFooter>
    </Card>
  );
}