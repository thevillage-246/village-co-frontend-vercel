import React, { useState } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';
import { Calendar as CalendarIcon, Upload, Loader2 } from 'lucide-react';
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from '@/lib/utils';
import { apiRequest } from '@/lib/queryClient';

interface FirstAidCertUploadProps {
  userId: number;
  onUploadComplete: () => void;
}

export default function FirstAidCertUpload({ userId, onUploadComplete }: FirstAidCertUploadProps) {
  const [file, setFile] = useState<File | null>(null);
  const [expiryDate, setExpiryDate] = useState<Date | undefined>(
    new Date(Date.now() + 2 * 365 * 24 * 60 * 60 * 1000) // Default to 2 years from now
  );
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!file) {
      toast({
        title: 'No File Selected',
        description: 'Please select a file to upload.',
        variant: 'destructive',
      });
      return;
    }

    if (!expiryDate) {
      toast({
        title: 'Expiry Date Required',
        description: 'Please select an expiry date for your certification.',
        variant: 'destructive',
      });
      return;
    }

    setIsUploading(true);

    try {
      // Create form data for file upload
      const formData = new FormData();
      formData.append('file', file);
      formData.append('expiryDate', expiryDate.toISOString());
      
      // First upload the file
      const uploadResponse = await fetch(`/api/sitters/${userId}/upload-first-aid-cert`, {
        method: 'POST',
        body: formData,
      });
      
      if (!uploadResponse.ok) {
        throw new Error('Failed to upload certification');
      }
      
      const uploadData = await uploadResponse.json();
      
      // Then update the sitter profile with the cert URL and expiry date
      await apiRequest('PATCH', `/api/sitters/${userId}/profile`, {
        firstAidCertDate: expiryDate.toISOString(),
        firstAidCertUrl: uploadData.url
      });
      
      toast({
        title: 'Certification Uploaded',
        description: 'Your First Aid certification has been uploaded successfully.',
      });
      
      onUploadComplete();
    } catch (error) {
      console.error('Error uploading certification:', error);
      toast({
        title: 'Upload Failed',
        description: 'There was a problem uploading your certification. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <Card>
      <CardContent className="pt-6">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="certification">First Aid Certification</Label>
            <Input
              id="certification"
              type="file"
              accept=".pdf,.jpg,.jpeg,.png"
              onChange={handleFileChange}
              className="cursor-pointer"
            />
            <p className="text-xs text-muted-foreground">
              Accepted formats: PDF, JPEG, PNG. Max size: 5MB.
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="expiry-date">Certification Expiry Date</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant={"outline"}
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !expiryDate && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {expiryDate ? format(expiryDate, "PPP") : <span>Pick a date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={expiryDate}
                  onSelect={setExpiryDate}
                  initialFocus
                  disabled={(date) => date < new Date()}
                />
              </PopoverContent>
            </Popover>
          </div>

          <Button type="submit" className="w-full" disabled={isUploading}>
            {isUploading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Uploading...
              </>
            ) : (
              <>
                <Upload className="mr-2 h-4 w-4" />
                Upload Certification
              </>
            )}
          </Button>
          
          <div className="text-center text-sm text-muted-foreground mt-4">
            <p>Don't have a First Aid certification yet?</p>
            <Button 
              variant="link" 
              className="p-0 h-auto text-wine"
              type="button"
              onClick={() => {
                // Set placeholder date far in future (100 years)
                const farFutureDate = new Date();
                farFutureDate.setFullYear(farFutureDate.getFullYear() + 100);
                
                // Skip this step
                onUploadComplete();
              }}
            >
              Skip this step (you can add it later)
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}