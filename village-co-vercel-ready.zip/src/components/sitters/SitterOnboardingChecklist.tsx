import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  User, 
  Shield, 
  FileText, 
  CheckCircle2, 
  Circle, 
  ArrowRight, 
  Clock, 
  Star, 
  AlertCircle 
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
// import AuthDebugger from "@/components/debug/AuthDebugger";

interface ChecklistItem {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  completed: boolean;
  required: boolean;
  actionPath: string;
  actionText: string;
}

export default function SitterOnboardingChecklist() {
  const queryClient = useQueryClient();

  // Fetch current user with error handling
  const { data: currentUser, isLoading: userLoading, error: userError } = useQuery({
    queryKey: ['/api/auth/user'],
    retry: false,
    staleTime: 1000 * 60 * 5, // 5 minutes
    cacheTime: 1000 * 60 * 10, // 10 minutes
  });

  // Fetch sitter profile with error handling
  const { data: sitterProfile, isLoading: profileLoading, error: profileError } = useQuery({
    queryKey: ['/api/sitter/profile'],
    enabled: !!currentUser,
    retry: false
  });

  // Fetch verification status with error handling
  const { data: verificationStatus, isLoading: verificationLoading } = useQuery({
    queryKey: ['/api/sitter/verification/status'],
    enabled: !!currentUser,
    retry: false
  });

  // Fetch Stripe Connect status with error handling
  const { data: stripeConnectStatus, isLoading: stripeLoading } = useQuery({
    queryKey: ['/api/stripe-connect/status'],
    enabled: !!currentUser,
    retry: false
  });

  // Update active status mutation
  const updateActiveStatusMutation = useMutation({
    mutationFn: (isActive: boolean) => 
      apiRequest('PATCH', `/api/sitters/${currentUser?.id}/active`, { isActive }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sitter/profile'] });
    }
  });

  // Handle authentication errors - redirect to login
  if (userError) {
    // Clear any expired tokens
    localStorage.removeItem('auth_token');
    localStorage.removeItem('authToken');
    localStorage.removeItem('user_data');
    
    return (
      <div className="min-h-screen bg-gradient-to-br from-linen via-brushed-pink/20 to-white flex items-center justify-center">
        <div className="text-center space-y-4">
          <AlertCircle className="h-16 w-16 text-village-wine mx-auto" />
          <h2 className="text-2xl font-bold text-village-wine">Session Expired</h2>
          <p className="text-taupe">Your session has expired. Please log in again to continue.</p>
          <Link href="/auth">
            <Button className="bg-village-wine hover:bg-village-wine/90">
              Log In Again
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  // Show loading state while user data is being fetched
  if (userLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-linen via-brushed-pink/20 to-white flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="animate-spin w-8 h-8 border-4 border-village-wine border-t-transparent rounded-full mx-auto" />
          <p className="text-taupe">Loading your profile...</p>
        </div>
      </div>
    );
  }

  // If user is not authenticated, redirect to login
  if (!currentUser) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-linen via-brushed-pink/20 to-white flex items-center justify-center">
        <div className="text-center space-y-4">
          <AlertCircle className="h-16 w-16 text-village-wine mx-auto" />
          <h2 className="text-2xl font-bold text-village-wine">Please Log In</h2>
          <p className="text-taupe">You need to be logged in to access sitter onboarding.</p>
          <Link href="/auth">
            <Button className="bg-village-wine hover:bg-village-wine/90">
              Go to Login
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  // Provide safe defaults for sitter profile data
  const profile = sitterProfile || {};
  const verification = verificationStatus || {};
  const stripeConnect = stripeConnectStatus || {};

  // Define checklist items with warmer, more encouraging copy
  const checklistItems: ChecklistItem[] = [
    {
      id: 'profile',
      title: 'Tell us about yourself',
      description: 'Share what makes you special — your story, experience, and rate. This is how families get to know you!',
      icon: <User className="h-6 w-6" />,
      completed: !!(profile.bio && profile.hourlyRate && profile.experience),
      required: true,
      actionPath: '/sitter/onboarding/profile',
      actionText: 'Complete Profile'
    },
    {
      id: 'verification',
      title: 'Verify your identity',
      description: 'Quick ID check that builds trust with families. Takes 2 minutes and unlocks premium bookings.',
      icon: <Shield className="h-6 w-6" />,
      completed: verification.status === 'approved' || profile.identityVerified === true,
      required: true,
      actionPath: '/sitter/verification',
      actionText: verification.status === 'approved' ? 'Verified ✓' : 'Start Verification'
    },
    {
      id: 'qualifications',
      title: 'Show your qualifications',
      description: 'Upload your certificates and qualifications to stand out to families looking for specialized care.',
      icon: <FileText className="h-6 w-6" />,
      completed: !!(profile.qualifications?.length > 0),
      required: false,
      actionPath: '/sitter/onboarding/qualifications',
      actionText: 'Upload Certificates'
    }
  ];

  // Calculate completion stats
  const requiredItems = checklistItems.filter(item => item.required);
  const completedRequired = requiredItems.filter(item => item.completed).length;
  const totalCompleted = checklistItems.filter(item => item.completed).length;
  const progressPercentage = Math.round((totalCompleted / checklistItems.length) * 100);
  const readyToReceiveBookings = completedRequired === requiredItems.length;

  // Debug logging to understand the authentication state
  console.log('SitterOnboardingChecklist - currentUser:', currentUser);
  console.log('SitterOnboardingChecklist - sitterProfile:', sitterProfile);
  console.log('SitterOnboardingChecklist - localStorage auth_token:', !!localStorage.getItem('auth_token'));

  return (
    <div className="min-h-screen bg-gradient-to-br from-linen via-brushed-pink/20 to-white">
      <div className="container max-w-4xl py-8 px-4">
        {/* Welcome Banner */}
        <Card className="mb-8 bg-gradient-to-r from-[#6B3E4B] to-[#8b5a6b] text-white border-0 rounded-2xl shadow-xl overflow-hidden">
          <CardContent className="p-8">
            <div className="flex items-center gap-4">
              <div className="text-4xl">🎉</div>
              <div>
                <h1 className="text-3xl font-bold mb-2" style={{ fontFamily: 'Satoshi, sans-serif' }}>
                  Welcome to The Village Co., {currentUser?.firstName || 'Sitter'}!
                </h1>
                <p className="text-white/90 text-lg leading-relaxed" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                  You're so close to connecting with amazing families in your community. Let's get you set up! 🌟
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Steps Header */}
        <div className="mb-8 text-center">
          <h2 className="text-2xl font-bold text-[#6B3E4B] mb-2" style={{ fontFamily: 'Satoshi, sans-serif' }}>
            Just a few quick steps to get started
          </h2>
          <p className="text-gray-600 text-lg" style={{ fontFamily: 'DM Sans, sans-serif' }}>
            Each step brings you closer to earning with families who need you
          </p>
        </div>

        {/* Progress Overview */}
        <Card className="mb-6 bg-[#F9F5F0] border-0 rounded-xl shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-xl font-semibold text-[#6B3E4B]" style={{ fontFamily: 'Satoshi, sans-serif' }}>
                  Your Progress
                </h3>
                <p className="text-gray-600 text-sm" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                  {totalCompleted} of {checklistItems.length} steps completed
                </p>
              </div>
              <div className="text-right">
                <div className="text-2xl font-bold text-[#6B3E4B]">{progressPercentage}%</div>
                {readyToReceiveBookings ? (
                  <Badge className="bg-green-100 text-green-800 border-green-200">
                    <CheckCircle2 className="h-3 w-3 mr-1" />
                    Ready for Bookings
                  </Badge>
                ) : (
                  <Badge variant="outline" className="border-orange-200 text-orange-700">
                    <Clock className="h-3 w-3 mr-1" />
                    {requiredItems.length - completedRequired} required steps left
                  </Badge>
                )}
              </div>
            </div>
            <Progress value={progressPercentage} className="h-2" />
          </CardContent>
        </Card>

        {/* Quick Action for Going Active */}
        {readyToReceiveBookings && (
          <Card className="mb-6 bg-gradient-to-r from-[#6B3E4B] to-[#8b5a6b] text-white rounded-xl shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-semibold mb-2" style={{ fontFamily: 'Satoshi, sans-serif' }}>
                    🎉 You're ready to receive bookings!
                  </h3>
                  <p className="text-white/90" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                    {profile.isActive
                      ? "You're currently active and visible to families. Great work!"
                      : "Make yourself visible to families by going active now."
                    }
                  </p>
                </div>
                {!profile.isActive && (
                  <Button 
                    onClick={() => updateActiveStatusMutation.mutate(true)}
                    disabled={updateActiveStatusMutation.isPending}
                    className="bg-white text-[#6B3E4B] hover:bg-gray-100"
                  >
                    {updateActiveStatusMutation.isPending ? 'Updating...' : 'Go Active'}
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Checklist Items */}
        <div className="space-y-4">
          {checklistItems.map((item, index) => (
            <Card 
              key={item.id} 
              className={`rounded-xl shadow-lg transition-all duration-200 hover:shadow-xl ${
                item.completed ? 'bg-green-50 border-green-200' : 'bg-white border-gray-200'
              }`}
            >
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  {/* Status Icon */}
                  <div className={`mt-1 ${item.completed ? 'text-green-600' : 'text-gray-400'}`}>
                    {item.completed ? (
                      <CheckCircle2 className="h-6 w-6" />
                    ) : (
                      <Circle className="h-6 w-6" />
                    )}
                  </div>

                  {/* Content */}
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <div className={`${item.completed ? 'text-green-600' : 'text-[#6B3E4B]'}`}>
                        {item.icon}
                      </div>
                      <h3 className="text-lg font-semibold text-[#6B3E4B]" style={{ fontFamily: 'Satoshi, sans-serif' }}>
                        {item.title}
                      </h3>
                      {item.required && (
                        <Badge variant="outline" className="text-xs border-orange-200 text-orange-700">
                          Required
                        </Badge>
                      )}
                    </div>
                    <p className="text-gray-600 mb-4" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                      {item.description}
                    </p>
                    
                    {!item.completed && (
                      <Button asChild className="bg-[#6B3E4B] hover:bg-[#6B3E4B]/90">
                        <Link to={item.actionPath}>
                          {item.actionText}
                          <ArrowRight className="h-4 w-4 ml-2" />
                        </Link>
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Next Steps */}
        <Card className="mt-8 rounded-xl shadow-lg">
          <CardHeader>
            <CardTitle className="text-xl text-[#6B3E4B]" style={{ fontFamily: 'Satoshi, sans-serif' }}>
              What happens next?
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4" style={{ fontFamily: 'DM Sans, sans-serif' }}>
            <div className="flex items-start space-x-3">
              <Star className="h-5 w-5 text-[#6B3E4B] mt-0.5" />
              <div>
                <p className="font-medium">Complete required steps</p>
                <p className="text-sm text-gray-600">Finish your profile and identity verification to start receiving bookings</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <AlertCircle className="h-5 w-5 text-[#6B3E4B] mt-0.5" />
              <div>
                <p className="font-medium">Review and approval</p>
                <p className="text-sm text-gray-600">Our team will review your application within 1-2 business days</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <CheckCircle2 className="h-5 w-5 text-[#6B3E4B] mt-0.5" />
              <div>
                <p className="font-medium">Start earning</p>
                <p className="text-sm text-gray-600">Once approved, you'll receive booking requests from families in your area</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Help Section */}
        <Card className="mt-6 rounded-xl shadow-lg bg-[#F9F5F0] border-0">
          <CardContent className="p-6 text-center">
            <h3 className="text-lg font-semibold text-[#6B3E4B] mb-2" style={{ fontFamily: 'Satoshi, sans-serif' }}>
              Need help getting started?
            </h3>
            <p className="text-gray-600 mb-4" style={{ fontFamily: 'DM Sans, sans-serif' }}>
              Our team is here to support you every step of the way.
            </p>
            <Button 
              variant="outline" 
              className="border-[#6B3E4B] text-[#6B3E4B] hover:bg-[#6B3E4B] hover:text-white"
              onClick={() => window.location.href = 'mailto:info@thevillageco.nz'}
            >
              Contact Support
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}