import { 
  AlertCircle,
  Check,
  Clock,
  Shield,
  XCircle
} from "lucide-react";
import { SitterProfile } from '@shared/schema';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useCallback } from "react";

interface VerificationStatusDisplayProps {
  profile: Partial<SitterProfile>;
  onStartVerification?: () => void;
  className?: string;
}

/**
 * Displays the current status of a sitter's identity verification
 * and provides appropriate actions based on that status
 */
export default function VerificationStatusDisplay({
  profile,
  onStartVerification,
  className = '',
}: VerificationStatusDisplayProps) {
  const getStatusContent = useCallback(() => {
    // If verification is complete and approved
    if (profile.verificationStatus === 'approved' || profile.identityVerified === true) {
      return {
        icon: <Check className="h-6 w-6 text-green-500" />,
        title: "Verification Complete",
        description: "Your identity has been verified successfully.",
        variant: "success" as const,
        showButton: false,
      };
    }
    
    // If verification was declined
    if (profile.verificationStatus === 'declined') {
      return {
        icon: <XCircle className="h-6 w-6 text-red-500" />,
        title: "Verification Declined",
        description: "There was an issue with your verification. Please try again.",
        variant: "destructive" as const,
        showButton: true,
        buttonText: "Restart Verification"
      };
    }
    
    // If verification is in progress
    if (profile.verificationStatus === 'initiated') {
      return {
        icon: <Clock className="h-6 w-6 text-yellow-500" />,
        title: "Verification In Progress",
        description: "Please complete the verification process to start accepting bookings.",
        variant: "warning" as const,
        showButton: true,
        buttonText: "Continue Verification"
      };
    }
    
    // Default: Not started
    return {
      icon: <AlertCircle className="h-6 w-6 text-gray-500" />,
      title: "Verification Required",
      description: "Identity verification is required before you can accept bookings.",
      variant: "default" as const,
      showButton: true,
      buttonText: "Start Verification"
    };
  }, [profile.verificationStatus, profile.identityVerified]);
  
  const { icon, title, description, variant, showButton, buttonText } = getStatusContent();
  
  return (
    <Card className={`${className} border-2 ${variant === 'success' ? 'border-green-200' : variant === 'warning' ? 'border-yellow-200' : variant === 'destructive' ? 'border-red-200' : 'border-gray-200'}`}>
      <CardHeader className="pb-2">
        <div className="flex items-center gap-2">
          <Shield className="h-5 w-5 text-primary" />
          <CardTitle className="text-lg">Identity Verification</CardTitle>
        </div>
        <CardDescription>
          We verify all sitters to keep the community safe
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <Alert variant={variant} className="mb-4">
          <div className="flex items-center gap-3">
            {icon}
            <div>
              <AlertTitle>{title}</AlertTitle>
              <AlertDescription className="mt-1">
                {description}
              </AlertDescription>
            </div>
          </div>
        </Alert>
        
        {showButton && onStartVerification && (
          <Button 
            onClick={onStartVerification}
            className="w-full"
            variant={variant === 'default' ? 'default' : 'outline'}
          >
            {buttonText}
          </Button>
        )}
      </CardContent>
    </Card>
  );
}