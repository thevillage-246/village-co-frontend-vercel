import React from 'react';
import { Link } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { MapPin, Clock, Calendar, User } from 'lucide-react';

interface Booking {
  id: string;
  parent_id: string;
  parent_name: string;
  child_name: string;
  start_time: string;
  end_time: string;
  rate_label?: string;
  status: 'confirmed' | 'pending' | 'completed' | 'cancelled';
  address?: string;
  amount_paid?: number;
}

interface SitterBookingsProps {
  bookings: Booking[];
  isLoading?: boolean;
}

export function SitterBookings({ bookings = [], isLoading = false }: SitterBookingsProps) {
  // Group bookings by status
  const upcomingBookings = bookings.filter(b => 
    b.status === 'confirmed' && new Date(b.start_time) > new Date()
  );
  
  const pastBookings = bookings.filter(b => 
    b.status === 'completed' || new Date(b.start_time) < new Date()
  );
  
  if (isLoading) {
    return <SitterBookingsSkeleton />;
  }

  if (bookings.length === 0) {
    return (
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">My Bookings</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-6">
            <p className="text-muted-foreground">
              You don't have any bookings yet.
            </p>
            <Button asChild className="mt-4 bg-wine hover:bg-wine/90">
              <Link to="/profile/availability">Update Availability</Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-2 flex flex-row items-center justify-between">
        <CardTitle className="text-lg">My Bookings</CardTitle>
        <div className="text-sm text-muted-foreground">
          {bookings.length} total
        </div>
      </CardHeader>
      <CardContent>
        {upcomingBookings.length > 0 && (
          <div className="mb-6">
            <h3 className="font-medium text-sm uppercase tracking-wide text-muted-foreground mb-3">
              Upcoming
            </h3>
            <ul className="space-y-3">
              {upcomingBookings.map((booking) => (
                <BookingItem key={booking.id} booking={booking} upcoming />
              ))}
            </ul>
          </div>
        )}
        
        {pastBookings.length > 0 && (
          <div>
            <h3 className="font-medium text-sm uppercase tracking-wide text-muted-foreground mb-3">
              Past Bookings
            </h3>
            <ul className="space-y-3">
              {pastBookings.map((booking) => (
                <BookingItem key={booking.id} booking={booking} />
              ))}
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function BookingItem({ booking, upcoming = false }: { booking: Booking, upcoming?: boolean }) {
  // Format date and time with Auckland timezone
  let startDate: Date;
  let endDate: Date;
  
  try {
    startDate = new Date(booking.start_time);
    endDate = new Date(booking.end_time);
    
    // Validate dates
    if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
      throw new Error('Invalid date format');
    }
  } catch (error) {
    console.error('Error parsing booking dates:', error);
    // Fallback to current time if dates are invalid
    startDate = new Date();
    endDate = new Date();
  }
  
  const formattedDate = startDate.toLocaleDateString('en-NZ', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    timeZone: 'Pacific/Auckland'
  });
  
  const formattedStartTime = startDate.toLocaleTimeString('en-NZ', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
    timeZone: 'Pacific/Auckland'
  });
  
  const formattedEndTime = endDate.toLocaleTimeString('en-NZ', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
    timeZone: 'Pacific/Auckland'
  });
  
  // Status color mapping
  const statusColorMap = {
    confirmed: 'bg-green-100 text-green-800 border-green-200',
    pending: 'bg-amber-100 text-amber-800 border-amber-200',
    completed: 'bg-blue-100 text-blue-800 border-blue-200',
    cancelled: 'bg-red-100 text-red-800 border-red-200',
  };
  
  return (
    <li className="border rounded-md p-3 hover:border-primary/50 transition-colors">
      <div className="flex flex-col gap-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Badge variant="outline" className={statusColorMap[booking.status]}>
              {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
            </Badge>
            
            {booking.rate_label && (
              <Badge variant="outline" className="bg-linen border-rose/20">
                {booking.rate_label}
              </Badge>
            )}
          </div>
          
          {upcoming && (
            <Button variant="outline" size="sm" asChild>
              <Link to={`/bookings/${booking.id}`}>View Details</Link>
            </Button>
          )}
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-1">
          <div className="flex items-center gap-2">
            <User className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm">
              <span className="font-medium">{booking.child_name}</span>
              <span className="text-muted-foreground"> ({booking.parent_name}'s child)</span>
            </span>
          </div>
          
          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm">{formattedDate}</span>
          </div>
          
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm">{formattedStartTime} - {formattedEndTime}</span>
          </div>
          
          {booking.address && (
            <div className="flex items-center gap-2">
              <MapPin className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm truncate">{booking.address}</span>
            </div>
          )}
        </div>
        
        {booking.amount_paid && (
          <div className="mt-1 text-sm font-medium text-right">
            Earned: ${booking.amount_paid.toFixed(2)}
          </div>
        )}
      </div>
    </li>
  );
}

function SitterBookingsSkeleton() {
  return (
    <Card>
      <CardHeader className="pb-2">
        <Skeleton className="h-6 w-32" />
      </CardHeader>
      <CardContent>
        <Skeleton className="h-5 w-24 mb-3" />
        <ul className="space-y-3">
          {[1, 2, 3].map((i) => (
            <li key={i} className="border rounded-md p-3">
              <div className="flex items-center justify-between mb-3">
                <Skeleton className="h-5 w-24" />
                <Skeleton className="h-8 w-28" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-full" />
              </div>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}