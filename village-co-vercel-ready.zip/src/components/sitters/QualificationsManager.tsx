import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { Plus, Check, Clock, X, Upload } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import QualificationUploadDialog from './QualificationUploadDialog';

interface SitterQualification {
  id: number;
  sitterId: number;
  category: string;
  qualificationKey: string;
  displayName: string;
  emoji: string;
  isVerified: boolean;
  verifiedAt: string | null;
  verifiedBy: number | null;
  additionalInfo: string | null;
  createdAt: string;
  updatedAt: string;
}

interface QualificationOption {
  key: string;
  displayName: string;
  emoji: string;
  category: string;
}

const qualificationOptions: QualificationOption[] = [
  // Health & Safety Certifications
  { key: 'first-aid', displayName: 'First Aid Certification', emoji: '🏥', category: 'health-safety' },
  { key: 'cpr', displayName: 'CPR Certification', emoji: '❤️', category: 'health-safety' },
  { key: 'infant-child-cpr', displayName: 'Infant/Child CPR Certification', emoji: '👶', category: 'health-safety' },
  { key: 'police-check', displayName: 'Police/Background Check', emoji: '🛡️', category: 'health-safety' },
  { key: 'working-with-children', displayName: 'Valid Working with Children Check', emoji: '✅', category: 'health-safety' },
  { key: 'food-safety', displayName: 'Food Safety Certification', emoji: '🍽️', category: 'health-safety' },
  
  // Education & Professional
  { key: 'early-childhood-ece', displayName: 'Early Childhood Education Certification (ECE)', emoji: '🎓', category: 'education' },
  { key: 'childcare-education-degree', displayName: 'Degree in Childcare/Education', emoji: '📚', category: 'education' },
  { key: 'child-development', displayName: 'Child Development Training', emoji: '🧠', category: 'education' },
  
  // Specialized Training
  { key: 'autism-adhd', displayName: 'Specialised Training in Autism/ADHD', emoji: '🌈', category: 'specialized' },
  { key: 'medical-needs', displayName: 'Experience with Children with Medical Needs', emoji: '🩺', category: 'specialized' },
  
  // Practical Skills
  { key: 'drivers-license', displayName: 'Driver\'s License', emoji: '🚗', category: 'practical' },
  { key: 'swimming-supervision', displayName: 'Swimming Supervision', emoji: '🏊', category: 'practical' },
  { key: 'cooking-meal-prep', displayName: 'Cooking/Meal Prep for Kids', emoji: '👨‍🍳', category: 'practical' },
  { key: 'homework-help', displayName: 'Homework Help', emoji: '📝', category: 'practical' },
];

const categoryLabels = {
  'health-safety': 'Health & Safety Certifications',
  'education': 'Education & Professional',
  'specialized': 'Specialized Training', 
  'practical': 'Practical Skills'
};

interface QualificationsManagerProps {
  sitterId: number;
}

export default function QualificationsManager({ sitterId }: QualificationsManagerProps) {
  console.log(`🎯 QualificationsManager: Component rendered with sitterId: ${sitterId}`);
  
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch sitter profile (qualifications are now part of the profile)
  const { data: sitterProfile, isLoading, error } = useQuery({
    queryKey: ['/api/sitters', sitterId, 'profile'],
    queryFn: async () => {
      console.log(`🔍 QualificationsManager: Fetching sitter profile for sitterId: ${sitterId}`);
      try {
        const response = await apiRequest('GET', `/api/sitters/${sitterId}/profile`);
        const data = await response.json();
        console.log(`✅ QualificationsManager: Got sitter profile data:`, data);
        return data;
      } catch (error) {
        console.error(`❌ QualificationsManager: Error fetching sitter profile:`, error);
        throw error;
      }
    }
  });

  // Extract qualifications from profile
  const qualifications = sitterProfile?.qualifications || [];

  // Add error logging
  if (error) {
    console.error(`❌ QualificationsManager: Query error for sitterId ${sitterId}:`, error);
  }

  // Debug the qualifications data
  console.log(`📊 QualificationsManager: Current state - isLoading: ${isLoading}, qualifications length: ${qualifications.length}, qualifications:`, qualifications);



  const removeQualificationMutation = useMutation({
    mutationFn: (qualificationKey: string) => {
      // Remove qualification by updating the sitter profile
      const updatedQualifications = qualifications.filter(q => q.qualificationKey !== qualificationKey);
      return apiRequest('PATCH', `/api/sitters/${sitterId}/profile`, {
        qualifications: updatedQualifications
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sitters', sitterId, 'profile'] });
      toast({
        title: "Qualification Removed",
        description: "The qualification has been removed from your profile.",
      });
    },
    onError: () => {
      toast({
        title: "Error Removing Qualification",
        description: "Failed to remove qualification. Please try again.",
        variant: "destructive",
      });
    }
  });

  const getVerificationBadge = (qualification: SitterQualification) => {
    if (qualification.isVerified) {
      return (
        <Badge variant="default" className="bg-green-100 text-green-800 border-green-200">
          <Check className="w-3 h-3 mr-1" />
          Verified
        </Badge>
      );
    } else {
      return (
        <Badge variant="secondary" className="bg-yellow-100 text-yellow-800 border-yellow-200">
          <Clock className="w-3 h-3 mr-1" />
          Pending Review
        </Badge>
      );
    }
  };

  const groupedQualifications = qualifications.reduce((acc: Record<string, SitterQualification[]>, qualification: SitterQualification) => {
    if (!acc[qualification.category]) {
      acc[qualification.category] = [];
    }
    acc[qualification.category].push(qualification);
    return acc;
  }, {});

  const existingQualificationKeys = qualifications.map((q: SitterQualification) => q.qualificationKey);




  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Qualifications & Certifications</CardTitle>
          <CardDescription>Loading your qualifications...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="animate-pulse space-y-2">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="text-xl font-semibold text-village-wine">
            Qualifications & Certifications
          </CardTitle>
          <CardDescription>
            Showcase your qualifications to build trust with families. All qualifications require admin verification.
          </CardDescription>
        </div>
        <Button 
          variant="outline" 
          size="sm"
          onClick={() => setIsUploadDialogOpen(true)}
        >
          <Upload className="w-4 h-4 mr-2" />
          Add Qualifications
        </Button>

      </CardHeader>

      <CardContent>
        {qualifications.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <div className="w-16 h-16 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
              <Plus className="w-8 h-8 text-gray-400" />
            </div>
            <p className="text-lg font-medium mb-2">No qualifications added yet</p>
            <p className="text-sm mb-4">Add your qualifications to build trust with families</p>
            <Button onClick={() => setIsUploadDialogOpen(true)}>
              Add Your First Qualification
            </Button>
          </div>
        ) : (
          <div className="space-y-6">
            {Object.entries(groupedQualifications).map(([category, categoryQualifications]) => (
              <div key={category}>
                <h3 className="font-medium text-village-wine mb-3">
                  {categoryLabels[category as keyof typeof categoryLabels]}
                </h3>
                <div className="grid gap-3">
                  {(categoryQualifications as SitterQualification[]).map((qualification: SitterQualification) => (
                    <div 
                      key={qualification.id}
                      className="flex items-center justify-between p-4 border rounded-lg bg-white"
                    >
                      <div className="flex items-center space-x-3">
                        <span className="text-xl">{qualification.emoji}</span>
                        <div>
                          <div className="flex items-center space-x-2">
                            <span className="font-medium">{qualification.displayName}</span>
                            {getVerificationBadge(qualification)}
                          </div>
                          {qualification.isVerified && qualification.verifiedAt && (
                            <p className="text-sm text-gray-500 mt-1">
                              Verified on {new Date(qualification.verifiedAt).toLocaleDateString()}
                            </p>
                          )}
                        </div>
                      </div>
                      
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeQualificationMutation.mutate(qualification.qualificationKey)}
                        disabled={removeQualificationMutation.isPending}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>

      {/* New Upload Dialog */}
      <QualificationUploadDialog
        isOpen={isUploadDialogOpen}
        onClose={() => setIsUploadDialogOpen(false)}
        sitterId={sitterId}
      />
    </Card>
  );
}