import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { Loader } from '@googlemaps/js-api-loader';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Search, MapPin, Filter, Star, Clock, Award, Navigation } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { formatCurrency } from '@/lib/utils';

interface Sitter {
  id: number;
  userId: number;
  firstName: string;
  lastName: string;
  hourlyRate: number;
  rating?: number;
  reviewCount?: number;
  isApproved: boolean;
  profileImage?: string;
  badges?: string[];
  skills?: any[];
  latitude?: number;
  longitude?: number;
  distance?: number;
  availability?: string;
  travelTime?: number;
}

interface GoogleMapSearchProps {
  initialLocation?: [number, number];
}

export default function GoogleMapSearch({ initialLocation = [-41.2865, 174.7762] }: GoogleMapSearchProps) {
  const [, navigate] = useLocation();
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<google.maps.Marker[]>([]);
  const infoWindowRef = useRef<google.maps.InfoWindow | null>(null);
  const autocompleteRef = useRef<google.maps.places.Autocomplete | null>(null);
  
  const [searchAddress, setSearchAddress] = useState('');
  const [coordinates, setCoordinates] = useState<[number, number]>(initialLocation);
  const [searchRadius, setSearchRadius] = useState(10); // km
  const [travelTimeLimit, setTravelTimeLimit] = useState(20); // minutes
  const [searchMode, setSearchMode] = useState<'radius' | 'travelTime'>('radius');
  const [isMapLoaded, setIsMapLoaded] = useState(false);
  const [userLocation, setUserLocation] = useState<[number, number] | null>(null);
  
  const [filters, setFilters] = useState({
    verifiedOnly: false,
    minRating: 0,
    availableNow: false,
    hasBadges: false,
    suburbs: [] as string[],
  });
  
  const [selectedSitter, setSelectedSitter] = useState<number | null>(null);

  // Initialize Google Maps
  useEffect(() => {
    const initMap = async () => {
      const loader = new Loader({
        apiKey: process.env.VITE_GOOGLE_MAPS_API_KEY || '',
        version: 'weekly',
        libraries: ['places', 'geometry']
      });

      try {
        await loader.load();
        
        if (mapRef.current) {
          const map = new google.maps.Map(mapRef.current, {
            center: { lat: coordinates[0], lng: coordinates[1] },
            zoom: 13,
            styles: [
              {
                featureType: 'poi.business',
                stylers: [{ visibility: 'off' }]
              }
            ]
          });
          
          mapInstanceRef.current = map;
          infoWindowRef.current = new google.maps.InfoWindow();
          
          // Initialize autocomplete for address search
          const input = document.getElementById('address-search') as HTMLInputElement;
          if (input) {
            const autocomplete = new google.maps.places.Autocomplete(input, {
              componentRestrictions: { country: 'nz' },
              types: ['address']
            });
            
            autocomplete.addListener('place_changed', () => {
              const place = autocomplete.getPlace();
              if (place.geometry?.location) {
                const newCoords: [number, number] = [
                  place.geometry.location.lat(),
                  place.geometry.location.lng()
                ];
                setCoordinates(newCoords);
                map.setCenter({ lat: newCoords[0], lng: newCoords[1] });
              }
            });
            
            autocompleteRef.current = autocomplete;
          }
          
          setIsMapLoaded(true);
        }
      } catch (error) {
        console.error('Error loading Google Maps:', error);
      }
    };

    initMap();
  }, []);

  // Get user's current location
  const getUserLocation = useCallback(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const userCoords: [number, number] = [
            position.coords.latitude,
            position.coords.longitude
          ];
          setUserLocation(userCoords);
          setCoordinates(userCoords);
          
          if (mapInstanceRef.current) {
            mapInstanceRef.current.setCenter({ 
              lat: userCoords[0], 
              lng: userCoords[1] 
            });
          }
        },
        (error) => {
          console.error('Error getting user location:', error);
        }
      );
    }
  }, []);

  // Fetch sitters from API
  const { data: sitters = [], isLoading } = useQuery<Sitter[]>({
    queryKey: ['/api/sitters/map-search', coordinates, searchRadius, travelTimeLimit, searchMode, filters],
    queryFn: async () => {
      const params = new URLSearchParams({
        lat: coordinates[0].toString(),
        lng: coordinates[1].toString(),
        radius: searchRadius.toString(),
        travelTime: travelTimeLimit.toString(),
        searchMode,
        verifiedOnly: filters.verifiedOnly.toString(),
        minRating: filters.minRating.toString(),
        availableNow: filters.availableNow.toString(),
        hasBadges: filters.hasBadges.toString()
      });
      
      const response = await apiRequest('GET', `/api/sitters/map-search?${params}`);
      return response.json();
    },
  });

  // Update map markers when sitters change
  useEffect(() => {
    if (!mapInstanceRef.current || !isMapLoaded) return;
    
    // Clear existing markers
    markersRef.current.forEach(marker => marker.setMap(null));
    markersRef.current = [];
    
    // Add search center marker
    const centerMarker = new google.maps.Marker({
      position: { lat: coordinates[0], lng: coordinates[1] },
      map: mapInstanceRef.current,
      title: 'Search Center',
      icon: {
        url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
          <svg width="30" height="30" viewBox="0 0 30 30" xmlns="http://www.w3.org/2000/svg">
            <circle cx="15" cy="15" r="12" fill="#6B3E4B" stroke="white" stroke-width="3"/>
            <circle cx="15" cy="15" r="4" fill="white"/>
          </svg>
        `),
        scaledSize: new google.maps.Size(30, 30),
        anchor: new google.maps.Point(15, 15)
      }
    });
    
    markersRef.current.push(centerMarker);
    
    // Add search radius circle
    const circle = new google.maps.Circle({
      strokeColor: '#6B3E4B',
      strokeOpacity: 0.8,
      strokeWeight: 2,
      fillColor: '#6B3E4B',
      fillOpacity: 0.1,
      map: mapInstanceRef.current,
      center: { lat: coordinates[0], lng: coordinates[1] },
      radius: searchRadius * 1000 // Convert km to meters
    });
    
    // Add sitter markers
    sitters.forEach((sitter) => {
      if (!sitter.latitude || !sitter.longitude) return;
      
      const isSelected = selectedSitter === sitter.id;
      const pinColor = sitter.isApproved ? '#6B3E4B' : '#B8A89F';
      const pinSize = isSelected ? 35 : 30;
      
      const marker = new google.maps.Marker({
        position: { lat: sitter.latitude, lng: sitter.longitude },
        map: mapInstanceRef.current,
        title: `${sitter.firstName} ${sitter.lastName}`,
        icon: {
          url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
            <svg width="${pinSize}" height="${pinSize}" viewBox="0 0 30 30" xmlns="http://www.w3.org/2000/svg">
              <circle cx="15" cy="15" r="12" fill="${pinColor}" stroke="white" stroke-width="3"/>
              ${sitter.isApproved ? '<text x="15" y="19" text-anchor="middle" fill="white" font-size="12" font-weight="bold">✓</text>' : ''}
              ${sitter.availability === 'available' ? '<circle cx="22" cy="8" r="4" fill="#10B981"/>' : ''}
            </svg>
          `),
          scaledSize: new google.maps.Size(pinSize, pinSize),
          anchor: new google.maps.Point(pinSize / 2, pinSize / 2)
        }
      });
      
      marker.addListener('click', () => {
        setSelectedSitter(sitter.id);
        
        const content = `
          <div style="max-width: 250px; padding: 10px;">
            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
              <div style="width: 40px; height: 40px; border-radius: 50%; background: #EBD3CB; display: flex; align-items: center; justify-content: center; font-weight: bold; color: #6B3E4B;">
                ${sitter.profileImage ? `<img src="${sitter.profileImage}" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;">` : 
                  `${sitter.firstName.charAt(0)}${sitter.lastName.charAt(0)}`}
              </div>
              <div>
                <h4 style="margin: 0; font-weight: bold;">${sitter.firstName} ${sitter.lastName}</h4>
                <div style="display: flex; align-items: center; gap: 5px; font-size: 12px; color: #666;">
                  <span>📍 ${sitter.distance?.toFixed(1)}km away</span>
                  ${sitter.travelTime ? `<span>🚗 ${sitter.travelTime}min drive</span>` : ''}
                </div>
              </div>
            </div>
            
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
              <span style="font-size: 18px; font-weight: bold; color: #6B3E4B;">${formatCurrency(sitter.hourlyRate)}/hr</span>
              ${sitter.rating ? `
                <div style="display: flex; align-items: center; gap: 2px;">
                  <span style="color: #F59E0B;">⭐</span>
                  <span style="font-size: 14px;">${sitter.rating.toFixed(1)}</span>
                </div>
              ` : ''}
            </div>
            
            ${sitter.availability === 'available' ? '<div style="color: #10B981; font-size: 12px; margin-bottom: 8px;">🟢 Available Now</div>' : ''}
            
            ${sitter.badges && sitter.badges.length > 0 ? `
              <div style="margin-bottom: 8px;">
                ${sitter.badges.map(badge => `<span style="background: #F3F4F6; padding: 2px 6px; border-radius: 12px; font-size: 10px; margin-right: 4px;">${badge}</span>`).join('')}
              </div>
            ` : ''}
            
            <button onclick="window.parent.postMessage({type: 'viewProfile', sitterId: ${sitter.userId}}, '*')" 
                    style="background: #6B3E4B; color: white; border: none; padding: 8px 16px; border-radius: 6px; cursor: pointer; width: 100%;">
              View Profile & Book
            </button>
          </div>
        `;
        
        infoWindowRef.current?.setContent(content);
        infoWindowRef.current?.open(mapInstanceRef.current, marker);
      });
      
      markersRef.current.push(marker);
    });
    
    // Listen for profile view messages from info windows
    const handleMessage = (event: MessageEvent) => {
      if (event.data.type === 'viewProfile') {
        navigate(`/profile/${event.data.sitterId}`);
      }
    };
    
    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
    
  }, [sitters, isMapLoaded, coordinates, searchRadius, selectedSitter]);

  // Filter sitters for the list view
  const filteredSitters = sitters.filter(sitter => {
    if (searchMode === 'radius' && sitter.distance && sitter.distance > searchRadius) return false;
    if (searchMode === 'travelTime' && sitter.travelTime && sitter.travelTime > travelTimeLimit) return false;
    return true;
  }).sort((a, b) => {
    if (searchMode === 'radius') return (a.distance || 0) - (b.distance || 0);
    return (a.travelTime || 0) - (b.travelTime || 0);
  });

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-wine">Find Nearby Sitters</h1>
        <Button onClick={getUserLocation} variant="outline" size="sm">
          <Navigation className="h-4 w-4 mr-2" />
          Use My Location
        </Button>
      </div>
      
      {/* Search and filters section */}
      <div className="grid grid-cols-1 lg:grid-cols-[2fr_1fr] gap-6 mb-6">
        {/* Search controls */}
        <div className="space-y-4">
          <div className="flex gap-2">
            <Input
              id="address-search"
              placeholder="Enter an address, suburb, or postal code"
              value={searchAddress}
              onChange={(e) => setSearchAddress(e.target.value)}
              className="flex-1"
            />
          </div>
          
          {/* Search mode toggle */}
          <div className="flex gap-4">
            <div className="flex items-center space-x-2">
              <input
                type="radio"
                id="radius-mode"
                checked={searchMode === 'radius'}
                onChange={() => setSearchMode('radius')}
              />
              <Label htmlFor="radius-mode">Distance-based</Label>
            </div>
            <div className="flex items-center space-x-2">
              <input
                type="radio"
                id="travel-mode"
                checked={searchMode === 'travelTime'}
                onChange={() => setSearchMode('travelTime')}
              />
              <Label htmlFor="travel-mode">Travel time-based</Label>
            </div>
          </div>
          
          {/* Distance/Time slider */}
          <div>
            {searchMode === 'radius' ? (
              <>
                <div className="flex justify-between mb-2">
                  <Label>Search Radius: {searchRadius} km</Label>
                </div>
                <Slider
                  value={[searchRadius]}
                  min={1}
                  max={25}
                  step={1}
                  onValueChange={(values) => setSearchRadius(values[0])}
                  className="w-full"
                />
              </>
            ) : (
              <>
                <div className="flex justify-between mb-2">
                  <Label>Travel Time: {travelTimeLimit} minutes</Label>
                </div>
                <Slider
                  value={[travelTimeLimit]}
                  min={5}
                  max={45}
                  step={5}
                  onValueChange={(values) => setTravelTimeLimit(values[0])}
                  className="w-full"
                />
              </>
            )}
          </div>
        </div>
        
        {/* Filters */}
        <Card>
          <CardContent className="pt-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center">
              <Filter className="h-4 w-4 mr-2" />
              Filters
            </h3>
            
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="verified"
                  checked={filters.verifiedOnly}
                  onCheckedChange={(checked) => 
                    setFilters({ ...filters, verifiedOnly: checked === true })}
                />
                <Label htmlFor="verified">Verified Sitters Only</Label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="available"
                  checked={filters.availableNow}
                  onCheckedChange={(checked) => 
                    setFilters({ ...filters, availableNow: checked === true })}
                />
                <Label htmlFor="available">Available Now</Label>
              </div>
              
              <div>
                <Label>Minimum Rating</Label>
                <Select
                  value={filters.minRating.toString()}
                  onValueChange={(value) => 
                    setFilters({ ...filters, minRating: parseInt(value) })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Any Rating" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">Any Rating</SelectItem>
                    <SelectItem value="3">3+ Stars</SelectItem>
                    <SelectItem value="4">4+ Stars</SelectItem>
                    <SelectItem value="5">5 Stars Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="badges"
                  checked={filters.hasBadges}
                  onCheckedChange={(checked) => 
                    setFilters({ ...filters, hasBadges: checked === true })}
                />
                <Label htmlFor="badges">Has Achievement Badges</Label>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Results count */}
      <div className="mb-4">
        <p className="text-gray-500">
          {filteredSitters.length} sitters found within {searchMode === 'radius' ? `${searchRadius}km` : `${travelTimeLimit} minutes`}
          {userLocation ? ' of your location' : ''}
        </p>
      </div>
      
      {/* Map and results section */}
      <div className="grid grid-cols-1 lg:grid-cols-[3fr_2fr] gap-6">
        {/* Google Map */}
        <div 
          ref={mapRef}
          className="bg-gray-100 rounded-lg"
          style={{ height: '600px', width: '100%' }}
        />
        
        {/* Sitter list */}
        <div className="bg-linen rounded-lg p-4 overflow-y-auto" style={{ maxHeight: '600px' }}>
          <h3 className="text-xl font-semibold mb-4">Nearby Sitters</h3>
          
          {isLoading ? (
            <div className="flex justify-center p-8">
              <div className="animate-spin w-8 h-8 border-4 border-wine border-t-transparent rounded-full"></div>
            </div>
          ) : filteredSitters.length === 0 ? (
            <div className="text-center p-8 text-gray-500">
              No sitters found matching your criteria
            </div>
          ) : (
            <div className="space-y-4">
              {filteredSitters.map((sitter) => (
                <Card 
                  key={sitter.id} 
                  className={`border cursor-pointer transition-all ${selectedSitter === sitter.id ? 'border-wine ring-2 ring-wine/20' : 'border-gray-200 hover:border-wine/50'}`}
                  onClick={() => setSelectedSitter(sitter.id)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div className="w-16 h-16 rounded-full bg-rose flex-shrink-0 flex items-center justify-center overflow-hidden">
                        {sitter.profileImage ? (
                          <img 
                            src={sitter.profileImage} 
                            alt={`${sitter.firstName} ${sitter.lastName ? sitter.lastName.charAt(0) + '.' : ''}`}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="text-2xl font-bold text-wine">
                            {sitter.firstName?.charAt(0)}{sitter.lastName?.charAt(0)}
                          </div>
                        )}
                      </div>
                      
                      <div className="flex-1">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h4 className="font-semibold text-lg">{sitter.firstName} {sitter.lastName}</h4>
                            <div className="flex items-center text-sm text-gray-500 gap-3">
                              <div className="flex items-center">
                                <MapPin className="h-3.5 w-3.5 mr-1" />
                                <span>{sitter.distance?.toFixed(1)}km away</span>
                              </div>
                              {sitter.travelTime && (
                                <div className="flex items-center">
                                  <Clock className="h-3.5 w-3.5 mr-1" />
                                  <span>{sitter.travelTime}min drive</span>
                                </div>
                              )}
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-bold text-lg text-wine">{formatCurrency(sitter.hourlyRate)}/hr</div>
                            <div className="flex items-center justify-end text-sm gap-1">
                              {sitter.rating && (
                                <>
                                  <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                                  <span>{sitter.rating.toFixed(1)}</span>
                                  {sitter.reviewCount && <span className="text-gray-500">({sitter.reviewCount})</span>}
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                        
                        <div className="space-y-2">
                          {/* Status badges */}
                          <div className="flex flex-wrap gap-1">
                            {sitter.isApproved && (
                              <Badge variant="secondary" className="text-xs">
                                ✓ Verified
                              </Badge>
                            )}
                            {sitter.availability === 'available' && (
                              <Badge className="text-xs bg-green-100 text-green-800">
                                🟢 Available Now
                              </Badge>
                            )}
                          </div>
                          
                          {/* Achievement badges */}
                          {sitter.badges && sitter.badges.length > 0 && (
                            <div className="flex flex-wrap gap-1">
                              {sitter.badges.slice(0, 3).map((badge, index) => (
                                <Badge key={index} variant="outline" className="text-xs">
                                  <Award className="h-3 w-3 mr-1" />
                                  {badge}
                                </Badge>
                              ))}
                              {sitter.badges.length > 3 && (
                                <Badge variant="outline" className="text-xs">
                                  +{sitter.badges.length - 3} more
                                </Badge>
                              )}
                            </div>
                          )}
                          
                          <div className="flex gap-2 mt-3">
                            <Button 
                              size="sm"
                              className="flex-1 bg-wine hover:bg-wine/90"
                              onClick={(e) => {
                                e.stopPropagation();
                                navigate(`/book?sitterId=${sitter.userId}`);
                              }}
                            >
                              Book Now
                            </Button>
                            <Button 
                              size="sm"
                              variant="outline"
                              className="flex-1"
                              onClick={(e) => {
                                e.stopPropagation();
                                navigate(`/profile/${sitter.userId}`);
                              }}
                            >
                              View Profile
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}