import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useLocation } from 'wouter';
import { Star, Shield, Heart } from 'lucide-react';
import InstantBookingModal from '@/components/booking/InstantBookingModal';

interface ModernSitterCardProps {
  sitter: any;
  isFavourite?: boolean;
  onBookingComplete?: () => void;
}

export default function ModernSitterCard({ 
  sitter, 
  isFavourite = false,
  onBookingComplete 
}: ModernSitterCardProps) {
  const [, navigate] = useLocation();
  const [showBookingModal, setShowBookingModal] = useState(false);

  const handleViewProfile = () => {
    navigate(`/profile/${sitter.userId || sitter.user_id}`);
  };

  const handleBookSitter = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowBookingModal(true);
  };

  const getInitials = () => {
    const firstName = sitter.firstName || '';
    const lastName = sitter.lastName || '';
    return `${firstName[0] || ''}${lastName[0] || ''}`;
  };

  const getDisplayName = () => {
    const firstName = sitter.firstName || 'Sitter';
    const lastName = sitter.lastName || '';
    const lastInitial = lastName ? ` ${lastName.charAt(0)}.` : '';
    return firstName === 'Sitter' ? 'Sitter' : `${firstName}${lastInitial}`;
  };

  const renderTrustBadges = () => {
    const badges = [];
    
    // Only show badges if sitter has been verified and provided profile information
    const hasVerifiedInfo = sitter.identityVerified || sitter.verificationStatus === 'approved';
    const hasProfileInfo = sitter.bio && sitter.experience && sitter.hourlyRate;
    
    if (!hasVerifiedInfo || !hasProfileInfo) {
      return []; // Don't show any badges until verification and profile completion
    }
    
    // Limit to 2-3 most important badges for clarity
    if (sitter.identityVerified) {
      badges.push(
        <span key="verified" className="trust-badge">
          ✔ Verified
        </span>
      );
    }
    
    if (sitter.firstAidCertDate) {
      badges.push(
        <span key="firstaid" className="trust-badge">
          First Aid Cert
        </span>
      );
    }
    
    if (sitter.badge && badges.length < 3) {
      badges.push(
        <span key="badge" className="trust-badge">
          {sitter.badge}
        </span>
      );
    }
    
    return badges.slice(0, 3); // Absolutely max 3 badges
  };

  const getPersonalQuote = () => {
    if (sitter.whyKidsQuote) return sitter.whyKidsQuote;
    if (sitter.bio) return sitter.bio.slice(0, 80) + '...';
    return '"I love baking, messy play, and bedtime stories."';
  };

  const renderRating = () => {
    const rating = sitter.rating || 4.8; // Default for display
    return (
      <div className="flex items-center gap-1">
        <Star className="h-4 w-4 text-yellow-400 fill-current" />
        <span className="text-sm font-medium">{rating.toFixed(1)}</span>
      </div>
    );
  };

  return (
    <>
      <div 
        className="sitter-card"
        onClick={handleViewProfile}
      >
        {/* Profile photo - round and prominent */}
        <div className="flex items-start gap-4 mb-4">
          {sitter.photoUrl ? (
            <img 
              src={sitter.photoUrl} 
              alt={getDisplayName()}
              className="profile-photo"
            />
          ) : (
            <div className="profile-photo bg-village-wine text-white flex items-center justify-center text-xl font-semibold">
              {getInitials()}
            </div>
          )}
          
          <div className="flex-1">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold text-gray-900 mb-1">
                {getDisplayName()} 🌱
              </h2>
              <button className="text-gray-400 hover:text-red-500 transition-colors">
                <Heart className={`h-5 w-5 ${isFavourite ? 'fill-current text-red-500' : ''}`} />
              </button>
            </div>
            {renderRating()}
          </div>
        </div>

        {/* Personal quote - warm and inviting */}
        <p className="text-gray-600 mb-4 text-sm leading-relaxed italic">
          {getPersonalQuote()}
        </p>

        {/* Trust badges - limited to 2-3 for clarity */}
        <div className="flex flex-wrap gap-2 mb-4">
          {renderTrustBadges()}
        </div>

        {/* Hourly rate - only show if sitter has provided rate */}
        <div className="flex items-center justify-between">
          {sitter.hourlyRate && sitter.hourlyRate > 0 ? (
            <span className="text-lg font-semibold text-village-wine">
              ${sitter.hourlyRate}/hr
            </span>
          ) : (
            <span className="text-sm text-gray-500 italic">
              Rate not set
            </span>
          )}
          <button
            onClick={handleBookSitter}
            className="cta-btn"
          >
            ✨ Book {sitter.firstName || 'Sitter'}
          </button>
        </div>
      </div>

      {/* Booking modal */}
      {showBookingModal && (
        <InstantBookingModal
          isOpen={showBookingModal}
          onClose={() => setShowBookingModal(false)}
          sitter={sitter}
          onSuccess={() => {
            setShowBookingModal(false);
            onBookingComplete?.();
          }}
        />
      )}
    </>
  );
}