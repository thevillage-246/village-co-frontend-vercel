import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from '@/hooks/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import VeriffVerification from './VeriffVerification';
import ValuesQuizForm from './ValuesQuizForm';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Badge } from '@/components/ui/badge';
import { apiRequest } from '@/lib/queryClient';
import { Progress } from '@/components/ui/progress';
import {
  CheckCircle,
  User,
  AlertCircle,
  Copy,
  FileCheck,
  HelpCircle,
  Loader2,
  Upload,
  Clock
} from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import SitterProfileForm from '@/components/sitters/SitterProfileForm';
import FirstAidCertUpload from '@/components/sitters/FirstAidCertUpload';

interface OnboardingFlowProps {
  userId: number;
  onComplete?: () => void;
}

export default function OnboardingFlow({ userId, onComplete }: OnboardingFlowProps) {
  const [activeTab, setActiveTab] = useState('profile');
  const [progress, setProgress] = useState(0);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch sitter profile
  const { data: profile, isLoading } = useQuery({
    queryKey: ['/api/sitters', userId],
    queryFn: async () => {
      return apiRequest(`GET`, `/api/sitters/${userId}`).then(res => res.json());
    },
    enabled: !!userId,
  });

  // Calculate completion state for each step
  const steps = {
    profile: {
      isComplete: !!profile?.bio && !!profile?.experience && !!profile?.hourlyRate,
      label: 'Profile',
      description: 'Complete your sitter profile with bio, experience, and hourly rate'
    },
    verification: {
      isComplete: !!profile?.identityVerified || profile?.verificationStatus === 'approved',
      label: 'Verification',
      description: 'Verify your identity with our secure verification partner'
    },
    values: {
      isComplete: !!profile?.valuesQuizComplete,
      label: 'Values Quiz',
      description: 'Complete our values assessment to ensure alignment with our community'
    },
    firstAid: {
      isComplete: !!profile?.firstAidCertDate,
      label: 'First Aid',
      description: 'Upload your first aid certification'
    }
  };

  // Calculate overall progress
  useEffect(() => {
    if (profile) {
      const totalSteps = Object.keys(steps).length;
      const completedSteps = Object.values(steps).filter(step => step.isComplete).length;
      setProgress((completedSteps / totalSteps) * 100);
    }
  }, [profile]);

  // Handle tab navigation based on completion
  const navigateToNextIncompleteStep = () => {
    const stepsOrder = ['profile', 'verification', 'values', 'firstAid'];
    const currentIndex = stepsOrder.indexOf(activeTab);
    
    // Find the next incomplete step
    for (let i = currentIndex + 1; i < stepsOrder.length; i++) {
      const step = stepsOrder[i];
      if (!steps[step as keyof typeof steps].isComplete) {
        setActiveTab(step);
        return;
      }
    }
    
    // If all steps are complete
    if (onComplete) {
      onComplete();
    }
  };

  const handleStepComplete = (step: string) => {
    // Invalidate the sitter profile query to get fresh data
    queryClient.invalidateQueries({ queryKey: ['/api/sitters', userId] });
    
    // Show success toast
    toast({
      title: 'Step Completed',
      description: `You've completed the ${steps[step as keyof typeof steps].label} step!`,
    });
    
    // Navigate to the next step
    navigateToNextIncompleteStep();
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-wine" />
      </div>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle className="text-xl text-wine">Sitter Onboarding</CardTitle>
            <CardDescription>Complete these steps to start receiving bookings</CardDescription>
          </div>
          <Badge variant={progress === 100 ? "outline" : "secondary"} className={progress === 100 ? "bg-green-100 text-green-700 border-green-200" : ""}>
            {progress === 100 ? 'Complete' : `${Math.round(progress)}% Complete`}
          </Badge>
        </div>
        <Progress value={progress} className="h-2 mt-2" />
      </CardHeader>
      
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-4">
            {Object.entries(steps).map(([key, { label, isComplete }]) => (
              <TabsTrigger key={key} value={key} className="relative">
                {label}
                {isComplete && (
                  <CheckCircle className="h-3 w-3 text-green-500 absolute -top-1 -right-1" />
                )}
              </TabsTrigger>
            ))}
          </TabsList>
          
          <TabsContent value="profile" className="mt-4">
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <User className="h-5 w-5 text-wine" />
                <h3 className="text-lg font-medium">Complete Your Profile</h3>
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                Tell parents about yourself, your experience, and set your hourly rate.
              </p>
              
              <SitterProfileForm 
                userId={userId}
                profileData={profile}
                onSaved={() => handleStepComplete('profile')}
              />
            </div>
          </TabsContent>
          
          <TabsContent value="verification" className="mt-4">
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <FileCheck className="h-5 w-5 text-wine" />
                <h3 className="text-lg font-medium">Identity Verification</h3>
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                Verify your identity to build trust with parents. This step requires a government-issued ID.
              </p>
              
              {profile?.verificationStatus === 'approved' || profile?.identityVerified ? (
                <div className="bg-green-50 p-4 rounded-md border border-green-200 flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <div>
                    <p className="font-medium">Verification Complete</p>
                    <p className="text-sm text-muted-foreground">
                      Your identity has been verified successfully.
                    </p>
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="ml-auto"
                    onClick={() => navigateToNextIncompleteStep()}
                  >
                    Continue
                  </Button>
                </div>
              ) : profile?.verificationStatus === 'pending' ? (
                <div className="bg-yellow-50 p-4 rounded-md border border-yellow-200 flex items-center">
                  <Clock className="h-5 w-5 text-yellow-500 mr-3" />
                  <div>
                    <p className="font-medium">Verification In Progress</p>
                    <p className="text-sm text-muted-foreground">
                      Your verification is being processed. This usually takes 1-2 hours.
                    </p>
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="ml-auto"
                    onClick={() => navigateToNextIncompleteStep()}
                  >
                    Continue to Next Step
                  </Button>
                </div>
              ) : (
                <VeriffVerification 
                  userId={userId} 
                  onComplete={() => handleStepComplete('verification')} 
                />
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="values" className="mt-4">
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <HelpCircle className="h-5 w-5 text-wine" />
                <h3 className="text-lg font-medium">Values Assessment</h3>
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                This quiz helps us understand your approach to childcare and ensures our values align.
              </p>
              
              {profile?.valuesQuizComplete ? (
                <div className="bg-green-50 p-4 rounded-md border border-green-200 flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <div>
                    <p className="font-medium">Values Quiz Complete</p>
                    <p className="text-sm text-muted-foreground">
                      Your values align nicely with our community standards!
                      {profile.valuesQuizScore && (
                        <span className="ml-2 font-medium">Score: {profile.valuesQuizScore}%</span>
                      )}
                    </p>
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="ml-auto"
                    onClick={() => navigateToNextIncompleteStep()}
                  >
                    Continue
                  </Button>
                </div>
              ) : (
                <ScrollArea className="h-[500px] pr-4">
                  <ValuesQuizForm 
                    userId={userId} 
                    onComplete={() => handleStepComplete('values')} 
                  />
                </ScrollArea>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="firstAid" className="mt-4">
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <AlertCircle className="h-5 w-5 text-wine" />
                <h3 className="text-lg font-medium">First Aid Certification</h3>
              </div>
              <p className="text-sm text-muted-foreground mb-4">
                Upload your First Aid certification (optional, but gives you a trust badge on your profile).
              </p>
              
              {profile?.firstAidCertDate ? (
                <div className="bg-green-50 p-4 rounded-md border border-green-200 flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <div>
                    <p className="font-medium">First Aid Certification Verified</p>
                    <p className="text-sm text-muted-foreground">
                      Certificate valid until: {new Date(profile.firstAidCertDate).toLocaleDateString()}
                    </p>
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="ml-auto"
                    onClick={() => {
                      if (onComplete) onComplete();
                    }}
                  >
                    Finish Onboarding
                  </Button>
                </div>
              ) : (
                <FirstAidCertUpload
                  userId={userId}
                  onUploadComplete={() => handleStepComplete('firstAid')}
                />
              )}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      
      <CardFooter className="border-t bg-muted/50 px-6 py-4 flex justify-between">
        <Button 
          variant="outline"
          onClick={() => {
            const stepsOrder = ['profile', 'verification', 'values', 'firstAid'];
            const currentIndex = stepsOrder.indexOf(activeTab);
            if (currentIndex > 0) {
              setActiveTab(stepsOrder[currentIndex - 1]);
            }
          }}
          disabled={activeTab === 'profile'}
        >
          Previous Step
        </Button>
        
        <Button
          onClick={() => {
            const stepsOrder = ['profile', 'verification', 'values', 'firstAid'];
            const currentIndex = stepsOrder.indexOf(activeTab);
            
            if (currentIndex < stepsOrder.length - 1) {
              // Check if current step is complete
              const currentStep = steps[activeTab as keyof typeof steps];
              
              if (!currentStep.isComplete) {
                toast({
                  title: 'Step Incomplete',
                  description: `Please complete the current step before proceeding.`,
                  variant: 'destructive',
                });
                return;
              }
              
              setActiveTab(stepsOrder[currentIndex + 1]);
            } else if (progress === 100) {
              // All steps are complete
              if (onComplete) onComplete();
            }
          }}
        >
          {activeTab === 'firstAid' && progress === 100 ? 'Finish Onboarding' : 'Next Step'}
        </Button>
      </CardFooter>
    </Card>
  );
}