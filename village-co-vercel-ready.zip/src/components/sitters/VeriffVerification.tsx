import { useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield, Loader2 } from "lucide-react";
import { useToast } from '@/hooks/use-toast';
import { useSitterVerification } from '@/hooks/useSitterVerification';

export interface VeriffVerificationProps {
  userId: number;
  onComplete: () => void;
}

/**
 * Component for integrating Veriff identity verification into the sitter onboarding flow
 * Uses the useSitterVerification hook for state management
 */
export default function VeriffVerification({ userId, onComplete }: VeriffVerificationProps) {
  const {
    startVerification,
    isInitiating,
    verificationUrl,
    handleVerificationComplete,
    isLoading,
    error
  } = useSitterVerification(userId);
  
  const { toast } = useToast();

  // Open Veriff in a new window when the URL is available
  useEffect(() => {
    if (verificationUrl) {
      const veriffWindow = window.open(verificationUrl, '_blank');
      
      // Check if the window was blocked
      if (!veriffWindow || veriffWindow.closed || typeof veriffWindow.closed === 'undefined') {
        toast({
          variant: 'destructive',
          title: 'Popup Blocked',
          description: 'Please allow popups to continue with verification.',
        });
      } else {
        // Set up polling to check when the verification process is complete (window closed)
        const checkVeriffClosed = setInterval(() => {
          if (veriffWindow.closed) {
            clearInterval(checkVeriffClosed);
            handleVerificationComplete();
            onComplete();
          }
        }, 1000);
        
        // Clean up interval if component unmounts
        return () => clearInterval(checkVeriffClosed);
      }
    }
  }, [verificationUrl, toast, handleVerificationComplete, onComplete]);

  return (
    <Card className="border-2 border-primary/20">
      <CardHeader className="pb-2">
        <div className="flex items-center gap-2">
          <Shield className="h-5 w-5 text-primary" />
          <CardTitle className="text-lg">Identity Verification</CardTitle>
        </div>
        <CardDescription>
          We verify all sitters to keep our community safe
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <div className="mb-4 text-sm">
          <p>To verify your identity, you'll need:</p>
          <ul className="list-disc pl-5 mt-2 space-y-1">
            <li>A valid government-issued ID and passport</li>
            <li>A webcam or smartphone camera</li>
            <li>A few minutes to complete the process</li>
          </ul>
        </div>
        
        {error && <p className="text-red-500 mb-4 text-sm">{error instanceof Error ? error.message : String(error)}</p>}
        
        <Button 
          className="w-full" 
          onClick={() => startVerification()}
          disabled={isLoading || isInitiating || !!verificationUrl}
        >
          {isInitiating ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Preparing Verification...
            </>
          ) : verificationUrl ? (
            "Verification In Progress..."
          ) : (
            "Start Verification"
          )}
        </Button>
        
        {verificationUrl && (
          <p className="mt-2 text-center text-sm text-muted-foreground">
            A verification window has opened. If it was blocked, please click the button again.
          </p>
        )}
      </CardContent>
    </Card>
  );
}