import React, { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Loader2, CheckCircle2, Clock, MapPin, Phone, HeartPulse, Users, BookOpen } from "lucide-react";

interface PreCallChecklistProps {
  sitterId: number;
}

interface ChecklistItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  hint?: string;
  completed: boolean;
}

export default function PreCallChecklist({ sitterId }: PreCallChecklistProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Fetch existing checklist data if available
  const { data, isLoading } = useQuery({
    queryKey: ['/api/sitters', sitterId, 'checklist'],
    queryFn: async () => {
      try {
        const response = await apiRequest("GET", `/api/sitters/${sitterId}/checklist`);
        return response.json();
      } catch (error) {
        console.error("Error fetching checklist:", error);
        return { checklist: {} };
      }
    },
  });

  // Initialize checklist state
  const [checklist, setChecklist] = useState<ChecklistItem[]>([
    {
      id: "arrival_time",
      label: "Confirm arrival time with family",
      icon: <Clock className="h-4 w-4 text-wine" />,
      hint: "Double-check the expected arrival time",
      completed: false,
    },
    {
      id: "location",
      label: "Verify address and parking details",
      icon: <MapPin className="h-4 w-4 text-wine" />,
      hint: "Check for any special parking instructions",
      completed: false,
    },
    {
      id: "emergency_contacts",
      label: "Save parent's emergency contact",
      icon: <Phone className="h-4 w-4 text-wine" />,
      hint: "Add to your phone contacts for quick access",
      completed: false,
    },
    {
      id: "medical_info",
      label: "Review any medical information",
      icon: <HeartPulse className="h-4 w-4 text-wine" />,
      hint: "Note allergies, medications, or special needs",
      completed: false,
    },
    {
      id: "house_rules",
      label: "Ask about house rules and routines",
      icon: <BookOpen className="h-4 w-4 text-wine" />,
      hint: "Bedtime routines, screen time limits, etc.",
      completed: false,
    },
    {
      id: "children_activities",
      label: "Plan age-appropriate activities",
      icon: <Users className="h-4 w-4 text-wine" />,
      hint: "Consider interests of each child in your care",
      completed: false,
    },
  ]);

  // Update checklist items from fetched data
  React.useEffect(() => {
    if (data?.checklist) {
      setChecklist(prevList => 
        prevList.map(item => ({
          ...item,
          completed: !!data.checklist[item.id]
        }))
      );
    }
  }, [data]);

  const updateChecklistMutation = useMutation({
    mutationFn: async (updatedChecklist: Record<string, boolean>) => {
      return apiRequest("POST", `/api/sitters/${sitterId}/checklist`, { checklist: updatedChecklist });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sitters', sitterId, 'checklist'] });
      toast({
        title: "Checklist Updated",
        description: "Your pre-call checklist has been saved.",
      });
      setIsSubmitting(false);
    },
    onError: () => {
      toast({
        title: "Update Failed",
        description: "Failed to update checklist. Please try again.",
        variant: "destructive",
      });
      setIsSubmitting(false);
    },
  });

  const handleChecklistItemChange = (id: string, checked: boolean) => {
    setChecklist(prevList => 
      prevList.map(item => 
        item.id === id ? { ...item, completed: checked } : item
      )
    );
  };

  const handleSaveChecklist = () => {
    setIsSubmitting(true);
    
    // Create checklist object in format expected by API
    const checklistData = checklist.reduce<Record<string, boolean>>(
      (acc, item) => {
        acc[item.id] = item.completed;
        return acc;
      },
      {}
    );
    
    updateChecklistMutation.mutate(checklistData);
  };

  const allCompleted = checklist.every(item => item.completed);
  const progress = Math.round((checklist.filter(item => item.completed).length / checklist.length) * 100);

  if (isLoading) {
    return (
      <Card className="w-full">
        <CardContent className="pt-6 flex justify-center">
          <Loader2 className="h-6 w-6 animate-spin text-wine" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold flex items-center gap-2">
          <CheckCircle2 className="h-5 w-5 text-wine" />
          Pre-Call Checklist
        </CardTitle>
        <CardDescription>
          Complete these steps before your babysitting session
        </CardDescription>
      </CardHeader>
      
      <CardContent className="pt-2">
        <div className="space-y-1">
          {checklist.map((item) => (
            <div key={item.id} className="flex items-start space-x-2 py-2">
              <Checkbox
                id={item.id}
                checked={item.completed}
                onCheckedChange={(checked) => handleChecklistItemChange(item.id, checked === true)}
                className="mt-0.5"
              />
              <div className="space-y-1 leading-none">
                <Label
                  htmlFor={item.id}
                  className={`flex items-center cursor-pointer ${item.completed ? 'line-through text-muted-foreground' : ''}`}
                >
                  <span className="mr-2">{item.icon}</span>
                  {item.label}
                </Label>
                {item.hint && <p className="text-xs text-muted-foreground">{item.hint}</p>}
              </div>
            </div>
          ))}
        </div>
        
        <Separator className="my-4" />
        
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>Progress</span>
            <span>{progress}% Complete</span>
          </div>
          <div className="w-full bg-slate-100 rounded-full h-2.5">
            <div 
              className="bg-wine h-2.5 rounded-full transition-all duration-300 ease-in-out" 
              style={{ width: `${progress}%` }}
            ></div>
          </div>
        </div>
      </CardContent>
      
      <CardFooter>
        <Button
          onClick={handleSaveChecklist}
          disabled={isSubmitting}
          className={`w-full ${allCompleted ? 'bg-green-600 hover:bg-green-700' : 'bg-wine hover:bg-wine/90'}`}
        >
          {isSubmitting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Saving...
            </>
          ) : allCompleted ? (
            <>
              <CheckCircle2 className="mr-2 h-4 w-4" />
              All Items Completed
            </>
          ) : (
            "Save Progress"
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}