import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { 
  User, 
  Star, 
  MapPin, 
  DollarSign, 
  Clock, 
  Heart, 
  Shield, 
  Camera,
  CheckCircle,
  AlertCircle,
  Languages,
  Award,
  Phone,
  Mail
} from 'lucide-react';

// Comprehensive profile schema that covers all fields in one place
const profileSchema = z.object({
  // Basic Info
  bio: z.string().max(500, 'Bio must be less than 500 characters').optional(),
  experience: z.string().max(300, 'Experience must be less than 300 characters').optional(),
  hourlyRate: z.string().min(1, 'Hourly rate is required'),
  age: z.number().min(16, 'Must be at least 16 years old').max(100).optional(),
  location: z.string().max(100, 'Location must be less than 100 characters').optional(),
  
  // Preferences & Skills
  okWithPets: z.boolean().default(false),
  languagesSpoken: z.string().max(200).optional(),
  qualifications: z.array(z.string()).default([]),
  availabilityTags: z.array(z.string()).default([]),
  
  // Contact & Emergency (for safety)
  emergencyContactName: z.string().optional(),
  emergencyContactPhone: z.string().optional(),
  emergencyContactRelationship: z.string().optional(),
  
  // Status
  isActive: z.boolean().default(true),
});

type ProfileData = z.infer<typeof profileSchema>;

interface ProfileSection {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  fields: (keyof ProfileData)[];
  required: boolean;
}

export default function StreamlinedProfileManager() {
  const [activeSection, setActiveSection] = useState<string>('basics');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch current profile
  const { data: profile, isLoading } = useQuery({
    queryKey: ['/api/sitter/profile'],
    queryFn: () => apiRequest('GET', '/api/sitter/profile').then(res => res.json())
  });

  // Form setup with all current values
  const form = useForm<ProfileData>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      bio: profile?.bio || '',
      experience: profile?.experience || '',
      hourlyRate: profile?.hourlyRate?.toString() || '',
      age: profile?.age || 18,
      location: profile?.location || '',
      okWithPets: profile?.okWithPets || false,
      languagesSpoken: profile?.languagesSpoken || '',
      qualifications: profile?.qualifications || [],
      availabilityTags: profile?.availabilityTags || [],
      emergencyContactName: profile?.emergencyContactName || '',
      emergencyContactPhone: profile?.emergencyContactPhone || '',
      emergencyContactRelationship: profile?.emergencyContactRelationship || '',
      isActive: profile?.isActive ?? true,
    }
  });

  // Update form values when profile data loads
  React.useEffect(() => {
    if (profile) {
      form.reset({
        bio: profile.bio || '',
        experience: profile.experience || '',
        hourlyRate: profile.hourlyRate?.toString() || '',
        age: profile.age || 18,
        location: profile.location || '',
        okWithPets: profile.okWithPets || false,
        languagesSpoken: profile.languagesSpoken || '',
        qualifications: profile.qualifications || [],
        availabilityTags: profile.availabilityTags || [],
        emergencyContactName: profile.emergencyContactName || '',
        emergencyContactPhone: profile.emergencyContactPhone || '',
        emergencyContactRelationship: profile.emergencyContactRelationship || '',
        isActive: profile.isActive ?? true,
      });
    }
  }, [profile, form]);

  // Profile sections for organized editing
  const profileSections: ProfileSection[] = [
    {
      id: 'basics',
      title: 'About You',
      description: 'Tell families what makes you special',
      icon: <User className="h-5 w-5" />,
      fields: ['bio', 'experience', 'hourlyRate', 'age', 'location'],
      required: true
    },
    {
      id: 'skills',
      title: 'Skills & Preferences',
      description: 'Your qualifications and what you offer',
      icon: <Star className="h-5 w-5" />,
      fields: ['qualifications', 'availabilityTags', 'okWithPets', 'languagesSpoken'],
      required: false
    },
    {
      id: 'emergency',
      title: 'Emergency Contact',
      description: 'Safety information (private)',
      icon: <Shield className="h-5 w-5" />,
      fields: ['emergencyContactName', 'emergencyContactPhone', 'emergencyContactRelationship'],
      required: false
    }
  ];

  // Calculate completion percentage
  const calculateCompletion = () => {
    const values = form.getValues();
    const requiredFields = ['bio', 'experience', 'hourlyRate'];
    const optionalFields = ['qualifications', 'availabilityTags', 'emergencyContactName'];
    
    const requiredComplete = requiredFields.filter(field => {
      const value = values[field as keyof ProfileData];
      return value && (Array.isArray(value) ? value.length > 0 : String(value).trim().length > 0);
    });
    
    const optionalComplete = optionalFields.filter(field => {
      const value = values[field as keyof ProfileData];
      return value && (Array.isArray(value) ? value.length > 0 : String(value).trim().length > 0);
    });
    
    const totalWeight = requiredFields.length * 2 + optionalFields.length;
    const completedWeight = requiredComplete.length * 2 + optionalComplete.length;
    
    return Math.round((completedWeight / totalWeight) * 100);
  };

  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: ProfileData) => {
      const response = await apiRequest('PUT', '/api/sitter/profile', data);
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sitter/profile'] });
      toast({
        title: "Profile Updated",
        description: "Your profile has been saved successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Update Failed",
        description: error.message || "Failed to save profile. Please try again.",
        variant: "destructive",
      });
    }
  });

  const onSubmit = (data: ProfileData) => {
    updateProfileMutation.mutate(data);
  };

  // Auto-save functionality
  React.useEffect(() => {
    const subscription = form.watch(() => {
      // Auto-save after 2 seconds of no changes
      const timeoutId = setTimeout(() => {
        const data = form.getValues();
        if (data.hourlyRate) { // Only save if required field exists
          updateProfileMutation.mutate(data);
        }
      }, 2000);
      
      return () => clearTimeout(timeoutId);
    });
    
    return () => subscription.unsubscribe();
  }, [form, updateProfileMutation]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-linen via-brushed-pink/20 to-white flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  const completion = calculateCompletion();
  const currentSection = profileSections.find(s => s.id === activeSection);

  return (
    <div className="min-h-screen bg-gradient-to-br from-linen via-brushed-pink/20 to-white p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header with progress */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-3xl font-bold text-wine">Complete Your Profile</h1>
              <p className="text-wine/70">One form, all your information - no duplication!</p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm text-wine/70">Profile Completion</p>
                <p className="text-2xl font-bold text-wine">{completion}%</p>
              </div>
              <Progress value={completion} className="w-24" />
            </div>
          </div>
          
          {/* Quick stats */}
          <div className="flex flex-wrap gap-4">
            <Badge variant={profile?.identityVerified ? "default" : "secondary"} className="flex items-center gap-1">
              <Shield className="h-3 w-3" />
              {profile?.identityVerified ? 'Verified' : 'Verification Pending'}
            </Badge>
            <Badge variant={profile?.isActive ? "default" : "secondary"} className="flex items-center gap-1">
              <CheckCircle className="h-3 w-3" />
              {profile?.isActive ? 'Available' : 'Unavailable'}
            </Badge>
            <Badge variant="outline" className="flex items-center gap-1">
              <DollarSign className="h-3 w-3" />
              ${profile?.hourlyRate || 0}/hr
            </Badge>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Section Navigation */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Profile Sections</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {profileSections.map((section) => {
                  const sectionData = form.getValues();
                  const isComplete = section.fields.some(field => {
                    const value = sectionData[field];
                    return value && (Array.isArray(value) ? value.length > 0 : String(value).trim().length > 0);
                  });
                  
                  return (
                    <button
                      key={section.id}
                      onClick={() => setActiveSection(section.id)}
                      className={`w-full text-left p-3 rounded-lg transition-colors ${
                        activeSection === section.id 
                          ? 'bg-wine text-white' 
                          : 'hover:bg-gray-100'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {section.icon}
                          <span className="font-medium">{section.title}</span>
                        </div>
                        {isComplete && (
                          <CheckCircle className="h-4 w-4 text-green-500" />
                        )}
                      </div>
                      <p className="text-xs opacity-70 mt-1">{section.description}</p>
                    </button>
                  );
                })}
              </CardContent>
            </Card>
          </div>

          {/* Main Form */}
          <div className="lg:col-span-3">
            <Card>
              <CardHeader>
                <div className="flex items-center gap-2">
                  {currentSection?.icon}
                  <CardTitle>{currentSection?.title}</CardTitle>
                </div>
                <p className="text-sm text-muted-foreground">{currentSection?.description}</p>
              </CardHeader>
              <CardContent>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  {/* Basics Section */}
                  {activeSection === 'basics' && (
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium mb-2">Tell families about yourself</label>
                        <Textarea
                          placeholder="Share your personality, what you love about working with children, and what makes you special..."
                          className="min-h-[100px]"
                          {...form.register('bio')}
                        />
                        <p className="text-xs text-muted-foreground mt-1">
                          {form.watch('bio')?.length || 0}/500 characters
                        </p>
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">Your childcare experience</label>
                        <Textarea
                          placeholder="Describe your experience with children - babysitting, family care, professional work..."
                          className="min-h-[80px]"
                          {...form.register('experience')}
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <label className="block text-sm font-medium mb-2">Hourly Rate (NZD)</label>
                          <div className="relative">
                            <DollarSign className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                            <Input
                              type="number"
                              placeholder="25"
                              className="pl-10"
                              {...form.register('hourlyRate')}
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-sm font-medium mb-2">Your Age</label>
                          <Input
                            type="number"
                            placeholder="25"
                            {...form.register('age', { valueAsNumber: true })}
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium mb-2">Location</label>
                          <div className="relative">
                            <MapPin className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                            <Input
                              type="text"
                              placeholder="e.g., Auckland, NZ"
                              className="pl-10"
                              {...form.register('location')}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Skills Section */}
                  {activeSection === 'skills' && (
                    <div className="space-y-6">
                      {/* Pet Preferences */}
                      <div className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center gap-3">
                          <Heart className="h-5 w-5 text-pink-500" />
                          <div>
                            <p className="font-medium">Comfortable with Pets</p>
                            <p className="text-sm text-muted-foreground">Are you okay babysitting in homes with pets?</p>
                          </div>
                        </div>
                        <Switch
                          checked={form.watch('okWithPets')}
                          onCheckedChange={(checked) => form.setValue('okWithPets', checked)}
                        />
                      </div>

                      {/* Languages */}
                      <div>
                        <label className="block text-sm font-medium mb-2 flex items-center gap-2">
                          <Languages className="h-4 w-4" />
                          Languages Spoken
                        </label>
                        <Input
                          placeholder="e.g., English, Mandarin, Spanish"
                          {...form.register('languagesSpoken')}
                        />
                      </div>

                      {/* Qualifications */}
                      <div>
                        <label className="block text-sm font-medium mb-3 flex items-center gap-2">
                          <Award className="h-4 w-4" />
                          Qualifications & Certifications
                        </label>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          {[
                            'First Aid Certified',
                            'CPR Certified',
                            'Police Check',
                            'ECE Qualified',
                            'Driver\'s License',
                            'Swimming Instructor',
                            'Child Development',
                            'Cooking/Meal Prep'
                          ].map((qual) => {
                            const isSelected = form.watch('qualifications')?.includes(qual);
                            return (
                              <button
                                key={qual}
                                type="button"
                                onClick={() => {
                                  const current = form.getValues('qualifications') || [];
                                  const updated = isSelected 
                                    ? current.filter(q => q !== qual)
                                    : [...current, qual];
                                  form.setValue('qualifications', updated);
                                }}
                                className={`p-3 text-left border rounded-lg transition-colors ${
                                  isSelected 
                                    ? 'border-wine bg-wine/10 text-wine' 
                                    : 'hover:border-gray-300'
                                }`}
                              >
                                <div className="flex items-center justify-between">
                                  <span className="text-sm">{qual}</span>
                                  {isSelected && <CheckCircle className="h-4 w-4" />}
                                </div>
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      {/* Availability */}
                      <div>
                        <label className="block text-sm font-medium mb-3 flex items-center gap-2">
                          <Clock className="h-4 w-4" />
                          When are you typically available?
                        </label>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                          {[
                            'Weekends',
                            'After School',
                            'Evenings',
                            'Date Nights',
                            'Emergency Care',
                            'Overnight',
                            'School Holidays',
                            'Public Holidays'
                          ].map((tag) => {
                            const isSelected = form.watch('availabilityTags')?.includes(tag);
                            return (
                              <button
                                key={tag}
                                type="button"
                                onClick={() => {
                                  const current = form.getValues('availabilityTags') || [];
                                  const updated = isSelected 
                                    ? current.filter(t => t !== tag)
                                    : [...current, tag];
                                  form.setValue('availabilityTags', updated);
                                }}
                                className={`p-2 text-sm border rounded-lg transition-colors ${
                                  isSelected 
                                    ? 'border-wine bg-wine text-white' 
                                    : 'hover:border-gray-300'
                                }`}
                              >
                                {tag}
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Emergency Contact Section */}
                  {activeSection === 'emergency' && (
                    <div className="space-y-4">
                      <div className="bg-blue-50 p-4 rounded-lg">
                        <div className="flex items-start gap-2">
                          <Shield className="h-5 w-5 text-blue-600 mt-0.5" />
                          <div>
                            <p className="font-medium text-blue-900">Privacy Notice</p>
                            <p className="text-sm text-blue-700">This information is confidential and only accessible to Village Co administrators for safety purposes.</p>
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium mb-2">Emergency Contact Name</label>
                          <Input
                            placeholder="Full name"
                            {...form.register('emergencyContactName')}
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium mb-2">Phone Number</label>
                          <Input
                            placeholder="021 123 4567"
                            {...form.register('emergencyContactPhone')}
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">Relationship</label>
                        <Input
                          placeholder="e.g., Mother, Father, Partner, Flatmate"
                          {...form.register('emergencyContactRelationship')}
                        />
                      </div>
                    </div>
                  )}

                  {/* Save Button */}
                  <div className="flex items-center justify-between pt-6 border-t">
                    <p className="text-sm text-muted-foreground">
                      Changes save automatically
                    </p>
                    <Button 
                      type="submit" 
                      disabled={updateProfileMutation.isPending}
                      className="bg-wine hover:bg-wine/90"
                    >
                      {updateProfileMutation.isPending ? 'Saving...' : 'Save Profile'}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}