import React, { useState, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { 
  Upload, 
  Video, 
  Play, 
  Pause, 
  RotateCcw, 
  Check, 
  AlertCircle, 
  Trash2,
  Info,
  Clock
} from 'lucide-react';

interface VideoUploadManagerProps {
  currentAboutVideo?: string | null;
  currentIntroVideo?: string | null;
  onVideoUpdate?: () => void;
  hideIntroVideo?: boolean;
}

export default function VideoUploadManager({ 
  currentAboutVideo, 
  currentIntroVideo, 
  onVideoUpdate,
  hideIntroVideo = false
}: VideoUploadManagerProps) {
  const [uploadProgress, setUploadProgress] = useState<{ [key: string]: number }>({});
  const [isUploading, setIsUploading] = useState<{ [key: string]: boolean }>({});
  const [previewUrls, setPreviewUrls] = useState<{ [key: string]: string }>({});
  const fileInputRefs = useRef<{ [key: string]: HTMLInputElement | null }>({});
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const uploadVideoMutation = useMutation({
    mutationFn: async ({ file, videoType }: { file: File; videoType: 'about' | 'intro' }) => {
      const formData = new FormData();
      formData.append('video', file);
      formData.append('videoType', videoType);

      return fetch('/api/sitter/upload-video', {
        method: 'POST',
        body: formData,
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('authToken')}`
        }
      });
    },
    onSuccess: (response, { videoType }) => {
      setIsUploading(prev => ({ ...prev, [videoType]: false }));
      setUploadProgress(prev => ({ ...prev, [videoType]: 100 }));
      
      toast({
        title: "Video Uploaded Successfully",
        description: `Your ${videoType === 'about' ? 'about me' : 'intro'} video has been uploaded and is now visible on your profile.`,
      });

      // Invalidate queries to refresh profile data
      queryClient.invalidateQueries({ queryKey: ['/api/sitter/profile'] });
      onVideoUpdate?.();
    },
    onError: (error: any, { videoType }) => {
      setIsUploading(prev => ({ ...prev, [videoType]: false }));
      setUploadProgress(prev => ({ ...prev, [videoType]: 0 }));
      
      toast({
        title: "Upload Failed",
        description: error.message || "Failed to upload video. Please try again.",
        variant: "destructive",
      });
    }
  });

  const deleteVideoMutation = useMutation({
    mutationFn: async (videoType: 'about' | 'intro') => {
      return apiRequest('DELETE', `/api/sitter/video/${videoType}`);
    },
    onSuccess: (_, videoType) => {
      toast({
        title: "Video Removed",
        description: `Your ${videoType === 'about' ? 'about me' : 'intro'} video has been removed.`,
      });

      queryClient.invalidateQueries({ queryKey: ['/api/sitter/profile'] });
      onVideoUpdate?.();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: "Failed to remove video. Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>, videoType: 'about' | 'intro') => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('video/')) {
      toast({
        title: "Invalid File Type",
        description: "Please select a video file (MP4, MOV, AVI, etc.)",
        variant: "destructive",
      });
      return;
    }

    // Validate file size (50MB limit)
    const maxSize = 50 * 1024 * 1024; // 50MB
    if (file.size > maxSize) {
      toast({
        title: "File Too Large",
        description: "Video file must be smaller than 50MB. Please compress your video and try again.",
        variant: "destructive",
      });
      return;
    }

    // Create preview URL
    const previewUrl = URL.createObjectURL(file);
    setPreviewUrls(prev => ({ ...prev, [videoType]: previewUrl }));

    // Start upload
    setIsUploading(prev => ({ ...prev, [videoType]: true }));
    setUploadProgress(prev => ({ ...prev, [videoType]: 0 }));

    // Simulate upload progress (replace with actual progress tracking)
    const progressInterval = setInterval(() => {
      setUploadProgress(prev => {
        const current = prev[videoType] || 0;
        if (current >= 90) {
          clearInterval(progressInterval);
          return prev;
        }
        return { ...prev, [videoType]: current + 10 };
      });
    }, 300);

    uploadVideoMutation.mutate({ file, videoType });
  };

  const triggerFileSelect = (videoType: 'about' | 'intro') => {
    fileInputRefs.current[videoType]?.click();
  };

  const VideoCard = ({ 
    type, 
    title, 
    description, 
    currentVideo, 
    maxDuration,
    recommendations 
  }: { 
    type: 'about' | 'intro';
    title: string;
    description: string;
    currentVideo?: string | null;
    maxDuration: string;
    recommendations: string[];
  }) => {
    const hasVideo = currentVideo || previewUrls[type];
    const uploading = isUploading[type];
    const progress = uploadProgress[type] || 0;

    return (
      <Card className="overflow-hidden">
        <CardHeader>
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Video className="h-5 w-5 text-village-wine" />
                {title}
              </CardTitle>
              <CardDescription className="mt-1">
                {description}
              </CardDescription>
            </div>
            <Badge variant="outline" className="text-xs">
              <Clock className="h-3 w-3 mr-1" />
              {maxDuration}
            </Badge>
          </div>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Video Preview/Player */}
          {hasVideo && (
            <div className="relative bg-gray-100 rounded-lg overflow-hidden">
              <video 
                controls 
                className="w-full h-48 object-cover"
                src={previewUrls[type] || currentVideo || undefined}
              >
                Your browser does not support video playback.
              </video>
              {uploading && (
                <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                  <div className="text-white text-center">
                    <div className="mb-2">Uploading...</div>
                    <Progress value={progress} className="w-32" />
                    <div className="text-sm mt-1">{progress}%</div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Upload Area */}
          {!hasVideo && (
            <div 
              className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-village-wine transition-colors cursor-pointer"
              onClick={() => triggerFileSelect(type)}
            >
              <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">Upload {title}</h3>
              <p className="text-sm text-gray-600 mb-4">
                Drag and drop your video file or click to browse
              </p>
              <Button variant="outline">
                <Upload className="h-4 w-4 mr-2" />
                Choose Video File
              </Button>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-2">
            {hasVideo && !uploading && (
              <>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => triggerFileSelect(type)}
                  disabled={uploadVideoMutation.isPending}
                >
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Replace Video
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => deleteVideoMutation.mutate(type)}
                  disabled={deleteVideoMutation.isPending}
                  className="text-red-600 hover:text-red-700"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Remove
                </Button>
              </>
            )}
            {!hasVideo && (
              <Button 
                onClick={() => triggerFileSelect(type)}
                disabled={uploading}
                className="bg-village-wine hover:bg-village-wine/90"
              >
                <Upload className="h-4 w-4 mr-2" />
                Upload Video
              </Button>
            )}
          </div>

          {/* Recommendations */}
          <div className="bg-blue-50 rounded-lg p-4">
            <div className="flex items-start gap-2">
              <Info className="h-5 w-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-medium text-blue-900 mb-2">Video Tips</h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  {recommendations.map((tip, index) => (
                    <li key={index} className="flex items-start gap-1">
                      <span className="text-blue-600">•</span>
                      {tip}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Hidden file input */}
          <input
            ref={el => fileInputRefs.current[type] = el}
            type="file"
            accept="video/*"
            className="hidden"
            onChange={(e) => handleFileSelect(e, type)}
          />
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="space-y-6">
      <div className={`grid gap-6 ${hideIntroVideo ? 'md:grid-cols-1' : 'md:grid-cols-1 lg:grid-cols-2'}`}>
        <VideoCard
          type="about"
          title="About Me Video"
          description="Share a quick introduction about yourself and why you love working with children. This video appears on your public profile."
          currentVideo={currentAboutVideo}
          maxDuration="30-60 seconds"
          recommendations={[
            "Introduce yourself and mention your experience",
            "Share what you love about working with kids",
            "Keep it natural and friendly",
            "Film in good lighting with clear audio",
            "Maximum file size: 50MB"
          ]}
        />

        {!hideIntroVideo && (
          <VideoCard
            type="intro"
            title="Onboarding Video"
            description="A personal introduction for the Village Co team. This helps us get to know you better during the verification process."
            currentVideo={currentIntroVideo}
            maxDuration="1-2 minutes"
            recommendations={[
              "Tell us about your background and experience",
              "Explain why you want to be a sitter",
              "Share any relevant qualifications",
              "Be authentic and personable",
              "This video is for admin review only"
            ]}
          />
        )}
      </div>

      {/* General Guidelines */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-amber-600" />
            Video Guidelines
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <h4 className="font-medium mb-2">Technical Requirements</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Supported formats: MP4, MOV, AVI, WebM</li>
                <li>• Maximum file size: 50MB</li>
                <li>• Recommended resolution: 720p or higher</li>
                <li>• Stable internet connection for upload</li>
              </ul>
            </div>
            <div>
              <h4 className="font-medium mb-2">Content Guidelines</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Professional and appropriate content only</li>
                <li>• Clear audio and good lighting</li>
                <li>• Avoid background noise or distractions</li>
                <li>• Dress professionally as you would for work</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}