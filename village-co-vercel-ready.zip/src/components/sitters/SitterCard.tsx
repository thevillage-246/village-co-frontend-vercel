import React from 'react';
import { useLocation } from 'wouter';
import { Star, Clock, BadgeCheck } from 'lucide-react';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';

interface Skill {
  id: number;
  name: string;
}

interface SitterCardProps {
  sitter: {
    id: number;
    userId: number;
    firstName: string;
    lastName: string;
    age?: number;
    hourlyRate: number;
    bio: string;
    photoUrl?: string;
    isApproved: boolean;
    skills?: Skill[];
    rating?: number;
    reviewCount?: number;
  };
  onBookNow?: (sitterId: number) => void;
  isFavorite?: boolean;
  onToggleFavorite?: (sitterId: number) => void;
}

const SitterCard: React.FC<SitterCardProps> = ({
  sitter,
  onBookNow,
  isFavorite,
  onToggleFavorite,
}) => {
  const [, navigate] = useLocation();

  const handleViewProfile = () => {
    console.log('Navigating to profile for sitter:', { id: sitter.id, userId: sitter.userId });
    navigate(`/profile/${sitter.userId}`);
  };

  const handleBookNow = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onBookNow) {
      onBookNow(sitter.id);
    } else {
      navigate(`/profile/${sitter.userId}?book=true`);
    }
  };

  const handleToggleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onToggleFavorite) {
      onToggleFavorite(sitter.id);
    }
  };

  // Generate initials for avatar fallback
  const getInitials = () => {
    return `${sitter.firstName?.[0] || ''}${sitter.lastName?.[0] || ''}`;
  };

  return (
    <Card 
      className="overflow-hidden cursor-pointer hover:shadow-md transition-shadow"
      onClick={handleViewProfile}
    >
      <div className="aspect-[4/3] relative">
        {sitter.photoUrl ? (
          <img 
            src={sitter.photoUrl} 
            alt={sitter.firstName} 
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full bg-neutral-100 flex items-center justify-center">
            <Avatar className="h-24 w-24">
              <AvatarFallback className="text-3xl">
                {getInitials()}
              </AvatarFallback>
            </Avatar>
          </div>
        )}
        {sitter.isApproved && (
          <div className="absolute top-2 right-2">
            <Badge variant="secondary" className="flex gap-1 items-center bg-white/90">
              <BadgeCheck className="h-3 w-3 text-primary" />
              <span>Verified</span>
            </Badge>
          </div>
        )}
      </div>

      <CardContent className="p-4">
        <div className="flex justify-between items-start mb-2">
          <div>
            <h3 className="font-medium text-lg">{sitter.firstName}{sitter.lastName ? ` ${sitter.lastName.charAt(0)}.` : ''}</h3>
            {sitter.age && <p className="text-sm text-muted-foreground">{sitter.age} years old</p>}
          </div>
          <div className="text-right">
            <div className="font-semibold text-lg">{sitter.hourlyRate.toLocaleString('en-NZ', { style: 'currency', currency: 'NZD' })}</div>
            <p className="text-xs text-muted-foreground">per hour</p>
          </div>
        </div>
        
        {sitter.rating && (
          <div className="flex items-center gap-1 mb-3">
            <div className="flex text-yellow-400">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className="h-4 w-4"
                  fill={i < Math.floor(sitter.rating || 0) ? "currentColor" : "none"}
                  fillOpacity={i < Math.floor(sitter.rating || 0) ? 1 : 0.2}
                />
              ))}
            </div>
            <span className="text-sm text-muted-foreground">
              {sitter.rating.toFixed(1)} ({sitter.reviewCount} reviews)
            </span>
          </div>
        )}

        <p className="text-sm line-clamp-3 mb-3">
          {sitter.bio}
        </p>

        {sitter.skills && sitter.skills.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-2">
            {sitter.skills.slice(0, 3).map((skill) => (
              <Badge key={skill.id} variant="outline" className="text-xs bg-neutral-50">
                {skill.name}
              </Badge>
            ))}
            {sitter.skills.length > 3 && (
              <Badge variant="outline" className="text-xs bg-neutral-50">
                +{sitter.skills.length - 3} more
              </Badge>
            )}
          </div>
        )}
      </CardContent>

      <CardFooter className="px-4 py-3 bg-muted/20 flex justify-between border-t">
        {onToggleFavorite && (
          <Button
            variant="ghost"
            size="sm"
            className="text-muted-foreground hover:text-primary"
            onClick={handleToggleFavorite}
          >
            {isFavorite ? 'Remove from Favorites' : 'Add to Favorites'}
          </Button>
        )}
        <Button
          size="sm"
          onClick={handleBookNow}
          className="ml-auto"
        >
          Book Now
        </Button>
      </CardFooter>
    </Card>
  );
};

export default SitterCard;
