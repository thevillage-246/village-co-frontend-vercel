import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Loader2 } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Quiz questions schema
const valuesQuizSchema = z.object({
  childSafety: z.enum(["1", "2", "3", "4", "5"]),
  communication: z.enum(["1", "2", "3", "4", "5"]),
  flexibility: z.enum(["1", "2", "3", "4", "5"]),
  reliability: z.enum(["1", "2", "3", "4", "5"]),
  empathy: z.enum(["1", "2", "3", "4", "5"]),
  scenario1: z.enum(["a", "b", "c", "d"]),
  scenario2: z.enum(["a", "b", "c", "d"]),
  scenario3: z.enum(["a", "b", "c", "d"]),
});

type ValuesQuizFormData = z.infer<typeof valuesQuizSchema>;

interface ValuesQuizFormProps {
  userId: number;
  onComplete: () => void;
}

export default function ValuesQuizForm({ userId, onComplete }: ValuesQuizFormProps) {
  const [step, setStep] = useState<number>(1);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const { toast } = useToast();

  const form = useForm<ValuesQuizFormData>({
    resolver: zodResolver(valuesQuizSchema),
    defaultValues: {
      childSafety: undefined,
      communication: undefined,
      flexibility: undefined,
      reliability: undefined,
      empathy: undefined,
      scenario1: undefined,
      scenario2: undefined,
      scenario3: undefined,
    },
  });

  const totalSteps = 3;

  const nextStep = () => {
    // Validate the current step's fields
    let fieldsToValidate: Array<keyof ValuesQuizFormData> = [];

    switch (step) {
      case 1:
        fieldsToValidate = ["childSafety", "communication", "flexibility"];
        break;
      case 2:
        fieldsToValidate = ["reliability", "empathy"];
        break;
      case 3:
        fieldsToValidate = ["scenario1", "scenario2", "scenario3"];
        break;
    }

    const isValid = fieldsToValidate.every(field => form.getValues(field));

    if (!isValid) {
      toast({
        title: "Missing answers",
        description: "Please answer all questions before continuing.",
        variant: "destructive",
      });
      return;
    }

    if (step < totalSteps) {
      setStep(prev => prev + 1);
      window.scrollTo(0, 0);
    }
  };

  const prevStep = () => {
    if (step > 1) {
      setStep(prev => prev - 1);
      window.scrollTo(0, 0);
    }
  };

  const onSubmit = async (data: ValuesQuizFormData) => {
    setIsSubmitting(true);
    try {
      // Calculate score (simple example - can be more complex based on business logic)
      const valueRatings = [
        parseInt(data.childSafety), 
        parseInt(data.communication), 
        parseInt(data.flexibility), 
        parseInt(data.reliability), 
        parseInt(data.empathy)
      ];
      
      // Calculate average values rating (1-5 scale)
      const avgValueRating = valueRatings.reduce((sum, val) => sum + val, 0) / valueRatings.length;
      
      // Correct answers for scenarios (example)
      const correctScenarioAnswers = {
        scenario1: "c", // Example: best safety choice
        scenario2: "b", // Example: best communication choice
        scenario3: "a", // Example: best reliability choice
      };
      
      // Calculate scenario score (0-3)
      let scenarioScore = 0;
      if (data.scenario1 === correctScenarioAnswers.scenario1) scenarioScore++;
      if (data.scenario2 === correctScenarioAnswers.scenario2) scenarioScore++;
      if (data.scenario3 === correctScenarioAnswers.scenario3) scenarioScore++;
      
      // Combined score calculation
      const totalScore = (avgValueRating * 0.6) + (scenarioScore / 3 * 5 * 0.4);

      // Save to database
      await apiRequest("POST", "/api/sitters/values-quiz", {
        userId,
        answers: data,
        score: totalScore.toFixed(1),
        completedAt: new Date().toISOString(),
      });

      toast({
        title: "Quiz Completed!",
        description: "Your values assessment has been submitted successfully.",
      });
      
      // Invalidate queries to refresh sitter data
      queryClient.invalidateQueries({ queryKey: ['/api/sitters', userId] });
      
      // Call the onComplete callback
      onComplete();
    } catch (error) {
      console.error("Error submitting values quiz:", error);
      toast({
        title: "Submission Error",
        description: "There was a problem submitting your quiz. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Card className="w-full max-w-3xl mx-auto">
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-wine">Our Values Assessment</CardTitle>
        <CardDescription>
          Step {step} of {totalSteps} - This helps us understand your approach to childcare
        </CardDescription>
        <div className="w-full bg-gray-200 h-2 mt-2 rounded-full overflow-hidden">
          <div 
            className="bg-rose h-full transition-all duration-300 ease-in-out"
            style={{ width: `${(step / totalSteps) * 100}%` }}
          ></div>
        </div>
      </CardHeader>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)}>
          <CardContent className="space-y-6">
            {step === 1 && (
              <div className="space-y-6">
                <div className="text-lg font-medium mb-4">Rate how important each value is to you in childcare:</div>
                
                <FormField
                  control={form.control}
                  name="childSafety"
                  render={({ field }) => (
                    <FormItem className="space-y-1">
                      <FormLabel className="font-medium">Child Safety</FormLabel>
                      <FormDescription>
                        Prioritizing the physical and emotional well-being of children above all else.
                      </FormDescription>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="flex justify-between pt-2"
                        >
                          {[1, 2, 3, 4, 5].map((value) => (
                            <div key={value} className="flex flex-col items-center">
                              <RadioGroupItem value={String(value)} id={`childSafety-${value}`} className="sr-only" />
                              <Label
                                htmlFor={`childSafety-${value}`}
                                className={`w-10 h-10 rounded-full flex items-center justify-center border cursor-pointer
                                ${field.value === String(value) ? 'bg-wine text-white border-wine' : 'border-gray-300 hover:border-wine'}`}
                              >
                                {value}
                              </Label>
                              {value === 1 && <div className="text-xs mt-1">Less</div>}
                              {value === 5 && <div className="text-xs mt-1">More</div>}
                            </div>
                          ))}
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Separator />
                
                <FormField
                  control={form.control}
                  name="communication"
                  render={({ field }) => (
                    <FormItem className="space-y-1">
                      <FormLabel className="font-medium">Communication</FormLabel>
                      <FormDescription>
                        Clear, honest, and open communication with parents and children.
                      </FormDescription>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="flex justify-between pt-2"
                        >
                          {[1, 2, 3, 4, 5].map((value) => (
                            <div key={value} className="flex flex-col items-center">
                              <RadioGroupItem value={String(value)} id={`communication-${value}`} className="sr-only" />
                              <Label
                                htmlFor={`communication-${value}`}
                                className={`w-10 h-10 rounded-full flex items-center justify-center border cursor-pointer
                                ${field.value === String(value) ? 'bg-wine text-white border-wine' : 'border-gray-300 hover:border-wine'}`}
                              >
                                {value}
                              </Label>
                              {value === 1 && <div className="text-xs mt-1">Less</div>}
                              {value === 5 && <div className="text-xs mt-1">More</div>}
                            </div>
                          ))}
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Separator />
                
                <FormField
                  control={form.control}
                  name="flexibility"
                  render={({ field }) => (
                    <FormItem className="space-y-1">
                      <FormLabel className="font-medium">Flexibility</FormLabel>
                      <FormDescription>
                        Ability to adapt to changing situations and family needs.
                      </FormDescription>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="flex justify-between pt-2"
                        >
                          {[1, 2, 3, 4, 5].map((value) => (
                            <div key={value} className="flex flex-col items-center">
                              <RadioGroupItem value={String(value)} id={`flexibility-${value}`} className="sr-only" />
                              <Label
                                htmlFor={`flexibility-${value}`}
                                className={`w-10 h-10 rounded-full flex items-center justify-center border cursor-pointer
                                ${field.value === String(value) ? 'bg-wine text-white border-wine' : 'border-gray-300 hover:border-wine'}`}
                              >
                                {value}
                              </Label>
                              {value === 1 && <div className="text-xs mt-1">Less</div>}
                              {value === 5 && <div className="text-xs mt-1">More</div>}
                            </div>
                          ))}
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            )}

            {step === 2 && (
              <div className="space-y-6">
                <div className="text-lg font-medium mb-4">Continue rating how important each value is to you:</div>
                
                <FormField
                  control={form.control}
                  name="reliability"
                  render={({ field }) => (
                    <FormItem className="space-y-1">
                      <FormLabel className="font-medium">Reliability</FormLabel>
                      <FormDescription>
                        Being dependable, punctual, and consistently meeting commitments.
                      </FormDescription>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="flex justify-between pt-2"
                        >
                          {[1, 2, 3, 4, 5].map((value) => (
                            <div key={value} className="flex flex-col items-center">
                              <RadioGroupItem value={String(value)} id={`reliability-${value}`} className="sr-only" />
                              <Label
                                htmlFor={`reliability-${value}`}
                                className={`w-10 h-10 rounded-full flex items-center justify-center border cursor-pointer
                                ${field.value === String(value) ? 'bg-wine text-white border-wine' : 'border-gray-300 hover:border-wine'}`}
                              >
                                {value}
                              </Label>
                              {value === 1 && <div className="text-xs mt-1">Less</div>}
                              {value === 5 && <div className="text-xs mt-1">More</div>}
                            </div>
                          ))}
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Separator />
                
                <FormField
                  control={form.control}
                  name="empathy"
                  render={({ field }) => (
                    <FormItem className="space-y-1">
                      <FormLabel className="font-medium">Empathy</FormLabel>
                      <FormDescription>
                        Understanding and responding to children's needs and feelings with compassion.
                      </FormDescription>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="flex justify-between pt-2"
                        >
                          {[1, 2, 3, 4, 5].map((value) => (
                            <div key={value} className="flex flex-col items-center">
                              <RadioGroupItem value={String(value)} id={`empathy-${value}`} className="sr-only" />
                              <Label
                                htmlFor={`empathy-${value}`}
                                className={`w-10 h-10 rounded-full flex items-center justify-center border cursor-pointer
                                ${field.value === String(value) ? 'bg-wine text-white border-wine' : 'border-gray-300 hover:border-wine'}`}
                              >
                                {value}
                              </Label>
                              {value === 1 && <div className="text-xs mt-1">Less</div>}
                              {value === 5 && <div className="text-xs mt-1">More</div>}
                            </div>
                          ))}
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            )}

            {step === 3 && (
              <div className="space-y-6">
                <div className="text-lg font-medium mb-4">How would you handle these situations?</div>
                
                <FormField
                  control={form.control}
                  name="scenario1"
                  render={({ field }) => (
                    <FormItem className="space-y-1">
                      <FormLabel className="font-medium">Scenario 1: Safety Concern</FormLabel>
                      <FormDescription>
                        You notice that a 4-year-old in your care is trying to climb onto a high bookshelf. What do you do?
                      </FormDescription>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="space-y-2 pt-2"
                        >
                          <div className="flex items-start space-x-2">
                            <RadioGroupItem value="a" id="scenario1-a" />
                            <Label htmlFor="scenario1-a" className="font-normal cursor-pointer">
                              Tell them to get down firmly, then return to what you were doing.
                            </Label>
                          </div>
                          <div className="flex items-start space-x-2">
                            <RadioGroupItem value="b" id="scenario1-b" />
                            <Label htmlFor="scenario1-b" className="font-normal cursor-pointer">
                              Wait to see if they can climb it safely before intervening.
                            </Label>
                          </div>
                          <div className="flex items-start space-x-2">
                            <RadioGroupItem value="c" id="scenario1-c" />
                            <Label htmlFor="scenario1-c" className="font-normal cursor-pointer">
                              Immediately go to them, help them down, and redirect them to a safer activity while explaining the danger.
                            </Label>
                          </div>
                          <div className="flex items-start space-x-2">
                            <RadioGroupItem value="d" id="scenario1-d" />
                            <Label htmlFor="scenario1-d" className="font-normal cursor-pointer">
                              Take a photo to show the parents later what their child was doing.
                            </Label>
                          </div>
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Separator />
                
                <FormField
                  control={form.control}
                  name="scenario2"
                  render={({ field }) => (
                    <FormItem className="space-y-1">
                      <FormLabel className="font-medium">Scenario 2: Communication</FormLabel>
                      <FormDescription>
                        Parents are running 30 minutes late to pick up their child. What's your approach?
                      </FormDescription>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="space-y-2 pt-2"
                        >
                          <div className="flex items-start space-x-2">
                            <RadioGroupItem value="a" id="scenario2-a" />
                            <Label htmlFor="scenario2-a" className="font-normal cursor-pointer">
                              Be upset and immediately ask for extra payment when they arrive.
                            </Label>
                          </div>
                          <div className="flex items-start space-x-2">
                            <RadioGroupItem value="b" id="scenario2-b" />
                            <Label htmlFor="scenario2-b" className="font-normal cursor-pointer">
                              Call or text to make sure everything is okay, let them know you can stay longer, and discuss any additional fees later.
                            </Label>
                          </div>
                          <div className="flex items-start space-x-2">
                            <RadioGroupItem value="c" id="scenario2-c" />
                            <Label htmlFor="scenario2-c" className="font-normal cursor-pointer">
                              Just wait without contacting them, assuming they'll arrive eventually.
                            </Label>
                          </div>
                          <div className="flex items-start space-x-2">
                            <RadioGroupItem value="d" id="scenario2-d" />
                            <Label htmlFor="scenario2-d" className="font-normal cursor-pointer">
                              Leave at the scheduled time regardless, since that's what was agreed upon.
                            </Label>
                          </div>
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Separator />
                
                <FormField
                  control={form.control}
                  name="scenario3"
                  render={({ field }) => (
                    <FormItem className="space-y-1">
                      <FormLabel className="font-medium">Scenario 3: Reliability</FormLabel>
                      <FormDescription>
                        You agreed to babysit but then receive an invitation to a concert you really want to attend on the same evening. What do you do?
                      </FormDescription>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="space-y-2 pt-2"
                        >
                          <div className="flex items-start space-x-2">
                            <RadioGroupItem value="a" id="scenario3-a" />
                            <Label htmlFor="scenario3-a" className="font-normal cursor-pointer">
                              Honor your commitment to babysit since you already agreed to it.
                            </Label>
                          </div>
                          <div className="flex items-start space-x-2">
                            <RadioGroupItem value="b" id="scenario3-b" />
                            <Label htmlFor="scenario3-b" className="font-normal cursor-pointer">
                              Cancel the babysitting job at the last minute to attend the concert.
                            </Label>
                          </div>
                          <div className="flex items-start space-x-2">
                            <RadioGroupItem value="c" id="scenario3-c" />
                            <Label htmlFor="scenario3-c" className="font-normal cursor-pointer">
                              Try to find a replacement sitter without telling the parents you won't be coming.
                            </Label>
                          </div>
                          <div className="flex items-start space-x-2">
                            <RadioGroupItem value="d" id="scenario3-d" />
                            <Label htmlFor="scenario3-d" className="font-normal cursor-pointer">
                              Tell the parents you're sick so you can go to the concert.
                            </Label>
                          </div>
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            )}
          </CardContent>

          <CardFooter className="flex justify-between">
            {step > 1 ? (
              <Button type="button" variant="outline" onClick={prevStep}>
                Previous
              </Button>
            ) : (
              <div></div> // Empty div for spacing
            )}

            {step < totalSteps ? (
              <Button type="button" onClick={nextStep} className="bg-wine hover:bg-wine/90">
                Next
              </Button>
            ) : (
              <Button 
                type="submit" 
                disabled={isSubmitting}
                className="bg-wine hover:bg-wine/90"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Submitting...
                  </>
                ) : (
                  "Submit Assessment"
                )}
              </Button>
            )}
          </CardFooter>
        </form>
      </Form>
    </Card>
  );
}