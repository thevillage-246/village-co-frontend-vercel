import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { format, parseISO } from "date-fns";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer 
} from "recharts";

interface SitterPerformanceProps {
  userId: number;
}

type MoodType = "happy" | "neutral" | "sad" | "asleep";

const MOODS = {
  happy: { emoji: "🙂", name: "Happy", color: "#4ade80" },
  neutral: { emoji: "😐", name: "Neutral", color: "#a1a1aa" },
  sad: { emoji: "😢", name: "Sad", color: "#fb7185" },
  asleep: { emoji: "😴", name: "Asleep", color: "#a78bfa" }
};

export function SitterPerformanceCard({ userId }: SitterPerformanceProps) {
  const [timeRange, setTimeRange] = useState("30days");
  
  const { data: performance, isLoading } = useQuery({
    queryKey: ['/api/sitters/performance', userId, timeRange],
    queryFn: async () => {
      const res = await apiRequest('GET', `/api/sitters/${userId}/performance?timeRange=${timeRange}`);
      return res.json();
    }
  });
  
  const { data: moodStats, isLoading: isLoadingMoodStats } = useQuery({
    queryKey: ['/api/sitters/mood-stats', userId, timeRange],
    queryFn: async () => {
      const res = await apiRequest('GET', `/api/sitters/${userId}/mood-stats?timeRange=${timeRange}`);
      return res.json();
    }
  });
  
  // Calculate mood distribution
  const calculateMoodStats = () => {
    if (!moodStats || !moodStats.moods) return {};
    
    const moodCounts: Record<MoodType, number> = {
      happy: 0,
      neutral: 0,
      sad: 0,
      asleep: 0
    };
    
    let totalEntries = 0;
    
    moodStats.moods.forEach((entry: any) => {
      if (entry.mood in moodCounts) {
        moodCounts[entry.mood as MoodType] += entry.count;
        totalEntries += entry.count;
      }
    });
    
    // Convert to percentages
    const moodPercentages: Record<string, number> = {};
    for (const [mood, count] of Object.entries(moodCounts)) {
      moodPercentages[mood] = totalEntries > 0 ? Math.round((count / totalEntries) * 100) : 0;
    }
    
    return {
      counts: moodCounts,
      percentages: moodPercentages,
      totalEntries
    };
  };
  
  const moodData = calculateMoodStats();
  
  // Prepare chart data if available
  const prepareChartData = () => {
    if (!moodStats || !moodStats.moodTimeline || moodStats.moodTimeline.length === 0) {
      return [];
    }
    
    return moodStats.moodTimeline.map((item: any) => ({
      date: format(parseISO(item.date), 'MMM d'),
      happy: item.moods.happy || 0,
      neutral: item.moods.neutral || 0,
      sad: item.moods.sad || 0,
      asleep: item.moods.asleep || 0
    }));
  };
  
  const chartData = prepareChartData();
  
  if (isLoading || isLoadingMoodStats) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Performance Metrics</CardTitle>
          <CardDescription>Loading your performance data...</CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center items-center h-40">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
        </CardContent>
      </Card>
    );
  }
  
  if (!performance) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Performance Metrics</CardTitle>
          <CardDescription>No performance data available yet.</CardDescription>
        </CardHeader>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle>Performance & Mood Tracking</CardTitle>
            <CardDescription>Track your babysitting performance and the moods of children under your care</CardDescription>
          </div>
          <Tabs defaultValue="30days" onValueChange={setTimeRange} className="w-[200px]">
            <TabsList className="grid grid-cols-3">
              <TabsTrigger value="7days">7d</TabsTrigger>
              <TabsTrigger value="30days">30d</TabsTrigger>
              <TabsTrigger value="90days">90d</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Performance Stats */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Your Performance</h3>
            
            <div className="grid grid-cols-2 gap-4">
              <Card className="bg-card/50">
                <CardContent className="p-4">
                  <div className="text-sm text-muted-foreground mb-1">Bookings Completed</div>
                  <div className="text-2xl font-bold">{performance.completedBookings || 0}</div>
                </CardContent>
              </Card>
              
              <Card className="bg-card/50">
                <CardContent className="p-4">
                  <div className="text-sm text-muted-foreground mb-1">Average Rating</div>
                  <div className="text-2xl font-bold">
                    {performance.averageRating ? performance.averageRating.toFixed(1) : 'N/A'}
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-card/50">
                <CardContent className="p-4">
                  <div className="text-sm text-muted-foreground mb-1">Parent Return Rate</div>
                  <div className="text-2xl font-bold">
                    {performance.returnRate ? `${Math.round(performance.returnRate * 100)}%` : 'N/A'}
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-card/50">
                <CardContent className="p-4">
                  <div className="text-sm text-muted-foreground mb-1">Mood Score</div>
                  <div className="text-2xl font-bold">
                    {performance.moodScore ? performance.moodScore.toFixed(1) : 'N/A'}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {performance.badges && performance.badges.length > 0 && (
              <div>
                <h4 className="text-sm font-medium mb-2">Your Badges</h4>
                <div className="flex flex-wrap gap-2">
                  {performance.badges.map((badge: string) => (
                    <Badge key={badge} variant="outline" className="px-2 py-1">
                      {badge}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </div>
          
          {/* Mood Distribution */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium">Child Mood Distribution</h3>
            
            {moodData.totalEntries ? (
              <div className="space-y-3">
                {Object.entries(MOODS).map(([mood, { emoji, name, color }]) => (
                  <div key={mood} className="space-y-1">
                    <div className="flex justify-between items-center">
                      <div className="flex items-center">
                        <span className="text-lg mr-2">{emoji}</span>
                        <span>{name}</span>
                      </div>
                      <span className="text-sm font-medium">
                        {moodData.percentages[mood]}%
                      </span>
                    </div>
                    <Progress 
                      value={moodData.percentages[mood]} 
                      className="h-2"
                      indicatorClassName={mood === 'happy' ? 'bg-green-500' : 
                                         mood === 'neutral' ? 'bg-gray-400' : 
                                         mood === 'sad' ? 'bg-red-400' : 'bg-purple-400'}
                    />
                  </div>
                ))}
                
                <div className="text-xs text-muted-foreground mt-2">
                  Based on {moodData.totalEntries} mood entries across all your bookings
                </div>
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                No mood data available yet. Track children's moods during your bookings to see statistics here.
              </div>
            )}
          </div>
        </div>
        
        {/* Mood Timeline Chart */}
        {chartData.length > 0 && (
          <div className="mt-8">
            <h3 className="text-lg font-medium mb-4">Mood Trends Over Time</h3>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="happy" stroke={MOODS.happy.color} />
                  <Line type="monotone" dataKey="neutral" stroke={MOODS.neutral.color} />
                  <Line type="monotone" dataKey="sad" stroke={MOODS.sad.color} />
                  <Line type="monotone" dataKey="asleep" stroke={MOODS.asleep.color} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}