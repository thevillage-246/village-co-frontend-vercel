import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import { Save, Heart, Languages, Award } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';

const petPreferencesSchema = z.object({
  okWithPets: z.boolean().default(false),
  languagesSpoken: z.string().max(200, 'Languages must be less than 200 characters').optional(),
  qualifications: z.array(z.string()).default([]),
});

type PetPreferencesData = z.infer<typeof petPreferencesSchema>;

interface PetPreferencesFormProps {
  profile: any;
  onSuccess: () => void;
}

const qualificationOptions = [
  'First Aid Certification',
  'CPR Certification', 
  'Infant/Child CPR Certification',
  'Police/Background Check',
  'Early Childhood Education Certification (ECE)',
  'Food Safety Certification',
  'Driver\'s License',
  'Swimming Supervision',
  'Valid Working with Children Check',
  'Degree in Childcare/Education',
  'Specialised Training in Autism/ADHD',
  'Experience with Children with Medical Needs',
  'Child Development Training',
  'Cooking/Meal Prep for Kids',
  'Homework Help'
];

export default function PetPreferencesForm({ profile, onSuccess }: PetPreferencesFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const form = useForm<PetPreferencesData>({
    resolver: zodResolver(petPreferencesSchema),
    defaultValues: {
      okWithPets: profile?.okWithPets || false,
      languagesSpoken: profile?.languagesSpoken || '',
      qualifications: profile?.qualifications || [],
    },
  });

  const updatePreferencesMutation = useMutation({
    mutationFn: async (data: PetPreferencesData) => {
      console.log('🔧 Submitting pet preferences data:', data);
      const response = await apiRequest('PUT', '/api/sitter/profile', data);
      console.log('🔧 Pet preferences update response:', response);
      return response;
    },
    onSuccess: (data) => {
      console.log('✅ Pet preferences update successful:', data);
      
      // Invalidate relevant queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/sitter/profile'] });
      queryClient.invalidateQueries({ queryKey: ['/api/sitter'] });
      
      onSuccess();
      toast({
        title: "Preferences Updated",
        description: "Your pet preferences and qualifications have been updated successfully.",
      });
    },
    onError: (error: any) => {
      console.error('❌ Pet preferences update failed:', error);
      toast({
        title: "Update Failed",
        description: error.message || "Failed to update preferences. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: PetPreferencesData) => {
    console.log('📝 Submitting pet preferences form:', data);
    updatePreferencesMutation.mutate(data);
  };

  const handleQualificationChange = (qualification: string, checked: boolean) => {
    const currentQualifications = form.getValues('qualifications');
    if (checked) {
      form.setValue('qualifications', [...currentQualifications, qualification]);
    } else {
      form.setValue('qualifications', currentQualifications.filter(q => q !== qualification));
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-village-wine flex items-center gap-2">
          <Heart className="w-5 h-5" />
          Pet Preferences & Additional Info
        </CardTitle>
        <CardDescription>
          Tell parents about your comfort with pets and additional qualifications
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {/* Pet Preferences */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label htmlFor="okWithPets" className="text-base font-medium">
                  Comfortable with Pets
                </Label>
                <p className="text-sm text-gray-500">
                  Are you okay with babysitting in homes with pets?
                </p>
              </div>
              <Switch
                id="okWithPets"
                checked={form.watch('okWithPets')}
                onCheckedChange={(checked) => form.setValue('okWithPets', checked)}
              />
            </div>
          </div>

          {/* Languages Spoken */}
          <div className="space-y-2">
            <Label htmlFor="languagesSpoken" className="flex items-center gap-2">
              <Languages className="w-4 h-4" />
              Languages Spoken
            </Label>
            <Input
              id="languagesSpoken"
              placeholder="e.g., English, Spanish, Mandarin"
              {...form.register('languagesSpoken')}
            />
            <p className="text-sm text-gray-500">
              List any additional languages you speak fluently
            </p>
          </div>

          {/* Qualifications */}
          <div className="space-y-4">
            <Label className="flex items-center gap-2">
              <Award className="w-4 h-4" />
              Certifications, Skills & Qualifications
            </Label>
            <p className="text-sm text-gray-500">
              Select all that apply to help parents find the right match
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {qualificationOptions.map((qualification) => (
                <div key={qualification} className="flex items-center space-x-2">
                  <Checkbox
                    id={qualification}
                    checked={form.watch('qualifications').includes(qualification)}
                    onCheckedChange={(checked) => 
                      handleQualificationChange(qualification, !!checked)
                    }
                  />
                  <Label
                    htmlFor={qualification}
                    className="text-sm font-normal cursor-pointer"
                  >
                    {qualification}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-end">
            <Button
              type="submit"
              disabled={updatePreferencesMutation.isPending}
              className="flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              {updatePreferencesMutation.isPending ? 'Saving...' : 'Save Preferences'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}