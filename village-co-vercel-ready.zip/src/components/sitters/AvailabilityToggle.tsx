import React from 'react';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { CheckCircle2, XCircle } from 'lucide-react';

interface AvailabilityToggleProps {
  available: boolean;
  onToggle?: (isAvailable: boolean) => void;
  userId?: string;
  compact?: boolean;
}

export function AvailabilityToggle({ 
  available, 
  onToggle, 
  userId,
  compact = false 
}: AvailabilityToggleProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Mutation to update availability status
  const { mutate: updateAvailability, isPending } = useMutation({
    mutationFn: async (isAvailable: boolean) => {
      return apiRequest('PATCH', `/api/sitters/${userId || 'me'}/availability`, {
        is_available: isAvailable
      });
    },
    onSuccess: (_, isAvailable) => {
      // If onToggle is provided, call it
      if (onToggle) {
        onToggle(isAvailable);
      }
      
      // Show success toast
      toast({
        title: isAvailable ? 'You are now available' : 'You are now unavailable',
        description: isAvailable 
          ? 'Parents can now book you for sitting' 
          : 'You will not receive new booking requests',
        variant: isAvailable ? 'default' : 'destructive',
      });
      
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ['/api/sitters/me'] });
      queryClient.invalidateQueries({ queryKey: ['/api/sitters/availability'] });
    },
    onError: (error) => {
      console.error('Failed to update availability:', error);
      toast({
        title: 'Failed to update availability',
        description: 'Please try again later',
        variant: 'destructive',
      });
    }
  });
  
  const handleToggle = (checked: boolean) => {
    updateAvailability(checked);
  };
  
  if (compact) {
    return (
      <div className="flex items-center space-x-2">
        <Switch 
          id="availability-mode"
          checked={available}
          onCheckedChange={handleToggle}
          disabled={isPending}
        />
        <Label htmlFor="availability-mode" className="font-medium text-sm">
          {available ? 'Available' : 'Unavailable'}
        </Label>
      </div>
    );
  }
  
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg">Availability Status</CardTitle>
        <CardDescription>
          Control when you're available for new bookings
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {available ? (
              <>
                <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center">
                  <CheckCircle2 className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <div className="font-medium">Available</div>
                  <div className="text-sm text-muted-foreground">
                    Parents can book you
                  </div>
                </div>
              </>
            ) : (
              <>
                <div className="h-8 w-8 rounded-full bg-red-100 flex items-center justify-center">
                  <XCircle className="h-5 w-5 text-red-600" />
                </div>
                <div>
                  <div className="font-medium">Unavailable</div>
                  <div className="text-sm text-muted-foreground">
                    You won't receive new bookings
                  </div>
                </div>
              </>
            )}
          </div>
          
          <Switch 
            id="availability-toggle"
            checked={available}
            onCheckedChange={handleToggle}
            disabled={isPending}
          />
        </div>
      </CardContent>
    </Card>
  );
}