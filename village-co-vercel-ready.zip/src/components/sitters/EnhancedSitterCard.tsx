import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { useLocation } from 'wouter';
import { Star, Shield, Play, Calendar, Clock, MapPin, Heart } from 'lucide-react';
import InstantBookingModal from '@/components/booking/InstantBookingModal';
import FavouriteSitterButton from '@/components/booking/FavouriteSitterButton';

interface EnhancedSitterCardProps {
  sitter: any;
  isFavourite?: boolean;
  matchScore?: 'Best Match' | 'Good Fit' | 'Possible Fit';
  onBookingComplete?: () => void;
}

export default function EnhancedSitterCard({ 
  sitter, 
  isFavourite = false,
  matchScore,
  onBookingComplete 
}: EnhancedSitterCardProps) {
  const [, navigate] = useLocation();
  const [showBookingModal, setShowBookingModal] = useState(false);

  const handleViewProfile = () => {
    navigate(`/profile/${sitter.userId || sitter.user_id}`);
  };

  const handleInstantBook = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowBookingModal(true);
  };

  const getInitials = () => {
    return `${sitter.firstName?.[0] || ''}${sitter.lastName?.[0] || ''}`;
  };

  const getMatchScoreColor = (score?: string) => {
    switch (score) {
      case 'Best Match':
        return 'bg-green-100 text-green-800';
      case 'Good Fit':
        return 'bg-blue-100 text-blue-800';
      case 'Possible Fit':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const renderCredentialBadges = () => {
    const badges = [];
    
    if (sitter.identityVerified) {
      badges.push(
        <Badge key="verified" variant="secondary" className="text-xs bg-green-100 text-green-800">
          <Shield className="h-3 w-3 mr-1" />
          ID Verified
        </Badge>
      );
    }
    
    if (sitter.firstAidCertDate) {
      badges.push(
        <Badge key="firstaid" variant="secondary" className="text-xs bg-blue-100 text-blue-800">
          🩹 First Aid
        </Badge>
      );
    }
    
    if (sitter.qualifications && (
      Array.isArray(sitter.qualifications) 
        ? sitter.qualifications.some(q => {
            if (typeof q === 'string') return q.includes('police_background_check');
            if (q && typeof q === 'object' && q.displayName) return q.displayName.toLowerCase().includes('police') || q.displayName.toLowerCase().includes('background');
            return false;
          })
        : sitter.qualifications.includes('police_background_check')
    )) {
      badges.push(
        <Badge key="police" variant="secondary" className="text-xs bg-purple-100 text-purple-800">
          🛡️ Police Check
        </Badge>
      );
    }
    
    if (sitter.badge) {
      badges.push(
        <Badge key="badge" variant="secondary" className="text-xs bg-village-rose text-village-wine">
          {sitter.badge}
        </Badge>
      );
    }
    
    return badges.slice(0, 3); // Show max 3 badges
  };

  return (
    <>
      <Card 
        className="overflow-hidden cursor-pointer hover:shadow-lg transition-all duration-200 hover:-translate-y-1"
        onClick={handleViewProfile}
      >
        <div className="aspect-[4/3] relative">
          {sitter.photoUrl ? (
            <img 
              src={sitter.photoUrl} 
              alt={`${sitter.firstName}${sitter.lastName ? ` ${sitter.lastName.charAt(0)}.` : ''}`} 
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-village-linen to-village-rose flex items-center justify-center">
              <Avatar className="h-24 w-24">
                <AvatarFallback className="text-3xl bg-village-wine text-white">
                  {getInitials()}
                </AvatarFallback>
              </Avatar>
            </div>
          )}
          
          {/* Top badges */}
          <div className="absolute top-2 left-2 flex flex-col gap-1">
            {matchScore && (
              <Badge className={`text-xs font-medium ${getMatchScoreColor(matchScore)}`}>
                {matchScore}
              </Badge>
            )}
            {sitter.availableForInstantBooking && (
              <Badge className="text-xs bg-village-wine text-white">
                Instant Book
              </Badge>
            )}
          </div>
          
          {/* Favourite button */}
          <div className="absolute top-2 right-2">
            <FavouriteSitterButton 
              sitterId={sitter.id} 
              isFavourite={isFavourite}
              variant="ghost"
            />
          </div>
          
          {/* Video indicator */}
          {sitter.introVideoUrl && (
            <div className="absolute bottom-2 left-2">
              <Badge variant="secondary" className="text-xs bg-black/70 text-white">
                <Play className="h-3 w-3 mr-1" />
                30s intro
              </Badge>
            </div>
          )}
        </div>

        <CardContent className="p-4">
          <div className="flex justify-between items-start mb-3">
            <div className="flex-1">
              <h3 className="font-semibold text-lg mb-1">
                {sitter.firstName}{sitter.lastName ? ` ${sitter.lastName.charAt(0)}.` : ''}
              </h3>
              
              {/* Rating and reviews */}
              <div className="flex items-center gap-1 mb-2">
                <div className="flex text-yellow-400">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className="h-4 w-4"
                      fill={i < Math.floor(sitter.rating || 4.8) ? "currentColor" : "none"}
                      fillOpacity={i < Math.floor(sitter.rating || 4.8) ? 1 : 0.2}
                    />
                  ))}
                </div>
                <span className="text-sm font-medium">
                  {(sitter.rating || 4.8).toFixed(1)}
                </span>
                <span className="text-sm text-muted-foreground">
                  ({sitter.reviewCount || 0} reviews)
                </span>
              </div>
              
              {/* Location and age */}
              <div className="flex items-center gap-3 text-sm text-muted-foreground mb-2">
                {sitter.location && (
                  <div className="flex items-center gap-1">
                    <MapPin className="h-3 w-3" />
                    <span>{sitter.location}</span>
                  </div>
                )}
                {sitter.age && (
                  <span>{sitter.age} years old</span>
                )}
              </div>
            </div>
            
            <div className="text-right">
              <div className="text-2xl font-bold text-village-wine">
                ${sitter.hourlyRate}
              </div>
              <div className="text-xs text-muted-foreground">per hour</div>
            </div>
          </div>
          
          {/* Bio preview */}
          <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
            {sitter.bio || 'Experienced and caring babysitter ready to help your family.'}
          </p>
          
          {/* Credential badges */}
          <div className="flex flex-wrap gap-1 mb-3 min-h-[24px]">
            {renderCredentialBadges()}
          </div>
          
          {/* Availability tags */}
          {sitter.availabilityTags && sitter.availabilityTags.length > 0 && (
            <div className="flex items-center gap-1 mb-3">
              <Clock className="h-3 w-3 text-muted-foreground" />
              <span className="text-xs text-muted-foreground">
                {sitter.availabilityTags.slice(0, 2).join(', ')}
                {sitter.availabilityTags.length > 2 && ` +${sitter.availabilityTags.length - 2} more`}
              </span>
            </div>
          )}
          
          {/* Action buttons */}
          <div className="flex gap-2 mt-4">
            <Button
              variant="outline"
              size="sm"
              onClick={handleViewProfile}
              className="flex-1"
            >
              View Profile
            </Button>
            <Button
              size="sm"
              onClick={handleInstantBook}
              className="flex-1 bg-village-wine hover:bg-village-wine/90 text-white"
            >
              <Calendar className="h-4 w-4 mr-1" />
              Book Now
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Instant Booking Modal */}
      <InstantBookingModal
        isOpen={showBookingModal}
        onClose={() => setShowBookingModal(false)}
        sitter={sitter}
        onSuccess={onBookingComplete}
      />
    </>
  );
}