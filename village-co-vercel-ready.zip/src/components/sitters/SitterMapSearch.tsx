import React, { useState, useEffect, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { MapContainer, TileLayer, Marker, Popup, Circle, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Search, MapPin, Filter, Star, Clock, Award } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { formatCurrency } from '@/lib/utils';

// Fix Leaflet icon issue
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

// Fix the default icon issue in Leaflet
const DefaultIcon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
});

L.Marker.prototype.options.icon = DefaultIcon;

// Custom pin with different colors based on sitter stats
const createCustomPin = (rating: number, isVerified: boolean) => {
  let color = '#6B3E4B'; // wine color for verified with high rating 
  
  if (!isVerified) {
    color = '#B8A89F'; // taupe for non-verified
  } else if (rating < 4) {
    color = '#C7D1C5'; // eucalyptus for lower ratings
  }

  return L.divIcon({
    className: "custom-pin",
    html: `<div style="background-color: ${color}; width: 30px; height: 30px; border-radius: 50%; border: 3px solid white; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">
             ${isVerified ? '✓' : ''}
           </div>`,
    iconSize: [30, 30],
    iconAnchor: [15, 15],
  });
};

// Component to recenter map when location changes
function MapRecenter({ coordinates }: { coordinates: [number, number] }) {
  const map = useMap();
  useEffect(() => {
    map.setView(coordinates, map.getZoom());
  }, [coordinates]);
  return null;
}

// Geocoder component to convert address to coordinates
function Geocoder({ address, onResult }: { address: string, onResult: (lat: number, lng: number) => void }) {
  useEffect(() => {
    if (address) {
      const geocodeAddress = async () => {
        try {
          // Call our server-side geocoding endpoint
          const response = await apiRequest(
            'GET', 
            `/api/geocode?address=${encodeURIComponent(address)}`
          );
          
          if (response.ok) {
            const data = await response.json();
            if (data.success) {
              onResult(data.lat, data.lng);
            } else {
              console.error('Geocoding failed:', data.error);
            }
          } else {
            console.error('Geocoding API error:', response.statusText);
          }
        } catch (error) {
          console.error('Geocoding error:', error);
        }
      };
      
      geocodeAddress();
    }
  }, [address]);
  
  return null;
}

interface SitterMapSearchProps {
  initialLocation?: [number, number];
}

export default function SitterMapSearch({ initialLocation = [-41.2865, 174.7762] }: SitterMapSearchProps) {
  const [, navigate] = useLocation();
  const [searchAddress, setSearchAddress] = useState('');
  const [geocodedAddress, setGeocodedAddress] = useState('');
  const [coordinates, setCoordinates] = useState<[number, number]>(initialLocation);
  const [searchRadius, setSearchRadius] = useState(5); // km
  const [filters, setFilters] = useState({
    verifiedOnly: false,
    minRating: 0,
    hasBadges: false,
    skills: [] as number[],
  });
  const [selectedSitter, setSelectedSitter] = useState<number | null>(null);

  // Handle address search
  const handleSearch = () => {
    setGeocodedAddress(searchAddress);
  };

  // Handle geocoding results
  const handleGeocodingResult = (lat: number, lng: number) => {
    setCoordinates([lat, lng]);
  };

  // Fetch sitters from API
  const { data: sitters = [], isLoading } = useQuery<any[]>({
    queryKey: ['/api/sitters/public'],
  });

  // Fetch skills for filtering
  const { data: skills = [] } = useQuery<any[]>({
    queryKey: ['/api/skills'],
  });

  // Filter sitters based on location and other criteria
  const filteredSitters = (sitters as any[])
    .filter((sitter: any) => {
      // Filter by verification status
      if (filters.verifiedOnly && !sitter.isApproved) {
        return false;
      }

      // Filter by minimum rating
      if (filters.minRating > 0 && (sitter.rating || 0) < filters.minRating) {
        return false;
      }

      // Filter by badges
      if (filters.hasBadges && (!sitter.badges || sitter.badges.length === 0)) {
        return false;
      }

      // Filter by skills
      if (filters.skills.length > 0 && (!sitter.skills || !sitter.skills.some((skill: any) => 
        filters.skills.includes(skill.id)))) {
        return false;
      }

      // For demonstration, we'll assume each sitter has lat/lng, but in a real app
      // you would have to geocode their addresses or store coordinates
      return true;
    })
    .map((sitter: any) => {
      // For demonstration, generate random coordinates near the search point
      // In a real application, you'd use actual sitter coordinates
      if (!sitter.latitude || !sitter.longitude) {
        const randomOffset = () => (Math.random() - 0.5) * (searchRadius / 50);
        sitter.latitude = coordinates[0] + randomOffset();
        sitter.longitude = coordinates[1] + randomOffset();
      }
      
      // Calculate distance to the search center (simple approximation)
      // In production, use a proper haversine formula or GIS function
      const latDiff = sitter.latitude - coordinates[0];
      const lngDiff = sitter.longitude - coordinates[1];
      sitter.distance = Math.sqrt(latDiff * latDiff + lngDiff * lngDiff) * 111; // Rough km conversion
      
      return sitter;
    })
    .filter((sitter: any) => sitter.distance <= searchRadius) // Filter by radius
    .sort((a: any, b: any) => a.distance - b.distance); // Sort by distance

  return (
    <div className="container mx-auto px-4 py-6">
      <h1 className="text-3xl font-bold text-wine mb-6">Find Nearby Sitters</h1>
      
      {/* Search and filters section */}
      <div className="grid grid-cols-1 md:grid-cols-[2fr_1fr] gap-6 mb-8">
        {/* Search box */}
        <div className="flex flex-col gap-4">
          <div className="flex gap-2">
            <Input
              placeholder="Enter an address or suburb"
              value={searchAddress}
              onChange={(e) => setSearchAddress(e.target.value)}
              className="flex-1"
            />
            <Button onClick={handleSearch}>
              <Search className="h-4 w-4 mr-2" />
              Search
            </Button>
          </div>
          
          {/* Radius slider */}
          <div>
            <div className="flex justify-between mb-2">
              <Label>Search Radius: {searchRadius} km</Label>
            </div>
            <Slider
              value={[searchRadius]}
              min={1}
              max={20}
              step={1}
              onValueChange={(values) => setSearchRadius(values[0])}
              className="w-full"
            />
          </div>
        </div>
        
        {/* Filters */}
        <Card>
          <CardContent className="pt-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center">
              <Filter className="h-4 w-4 mr-2" />
              Filters
            </h3>
            
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="verified"
                  checked={filters.verifiedOnly}
                  onCheckedChange={(checked) => 
                    setFilters({ ...filters, verifiedOnly: checked === true })}
                />
                <Label htmlFor="verified">Verified Sitters Only</Label>
              </div>
              
              <div>
                <Label>Minimum Rating</Label>
                <Select
                  value={filters.minRating.toString()}
                  onValueChange={(value) => 
                    setFilters({ ...filters, minRating: parseInt(value) })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Any Rating" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="0">Any Rating</SelectItem>
                    <SelectItem value="3">3+ Stars</SelectItem>
                    <SelectItem value="4">4+ Stars</SelectItem>
                    <SelectItem value="5">5 Stars</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="badges"
                  checked={filters.hasBadges}
                  onCheckedChange={(checked) => 
                    setFilters({ ...filters, hasBadges: checked === true })}
                />
                <Label htmlFor="badges">Has Achievement Badges</Label>
              </div>
              
              {/* Skills filter would go here */}
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Results count */}
      <div className="mb-4">
        <p className="text-gray-500">
          {filteredSitters.length} sitters found within {searchRadius}km
          {geocodedAddress ? ` of ${geocodedAddress}` : ''}
        </p>
      </div>
      
      {/* Map and results section */}
      <div className="grid grid-cols-1 lg:grid-cols-[3fr_2fr] gap-6">
        {/* Map */}
        <div className="bg-gray-100 rounded-lg overflow-hidden" style={{ height: '600px' }}>
          <MapContainer
            center={coordinates}
            zoom={13}
            style={{ height: '100%', width: '100%' }}
            scrollWheelZoom={true}
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            
            {/* Search radius circle */}
            <Circle
              center={coordinates}
              radius={searchRadius * 1000} // Convert km to meters
              pathOptions={{ color: '#6B3E4B', fillColor: '#6B3E4B', fillOpacity: 0.1 }}
            />
            
            {/* Search center marker */}
            <Marker position={coordinates}>
              <Popup>
                Search Center
              </Popup>
            </Marker>
            
            {/* Sitter markers */}
            {filteredSitters.map((sitter: any) => (
              <Marker
                key={sitter.id}
                position={[sitter.latitude, sitter.longitude]}
                icon={createCustomPin(sitter.rating || 0, sitter.isApproved)}
                eventHandlers={{
                  click: () => setSelectedSitter(sitter.id),
                }}
              >
                <Popup>
                  <div className="text-center">
                    <div className="font-bold">{sitter.firstName} {sitter.lastName}</div>
                    <div className="text-sm">{formatCurrency(sitter.hourlyRate)}/hr</div>
                    <div className="text-xs text-gray-500">{sitter.distance.toFixed(1)}km away</div>
                    <Button 
                      variant="link" 
                      size="sm"
                      onClick={() => navigate(`/profile/${sitter.userId}`)}
                    >
                      View Profile
                    </Button>
                  </div>
                </Popup>
              </Marker>
            ))}
            
            {/* Recenter map when location changes */}
            <MapRecenter coordinates={coordinates} />
            
            {/* Geocoder to handle address search */}
            <Geocoder address={geocodedAddress} onResult={handleGeocodingResult} />
          </MapContainer>
        </div>
        
        {/* Sitter list */}
        <div className="bg-linen rounded-lg p-4 overflow-y-auto" style={{ maxHeight: '600px' }}>
          <h3 className="text-xl font-semibold mb-4">Nearby Sitters</h3>
          
          {isLoading ? (
            <div className="flex justify-center p-8">
              <div className="animate-spin w-8 h-8 border-4 border-wine border-t-transparent rounded-full"></div>
            </div>
          ) : filteredSitters.length === 0 ? (
            <div className="text-center p-8 text-gray-500">
              No sitters found matching your criteria
            </div>
          ) : (
            <div className="space-y-4">
              {filteredSitters.map((sitter: any) => (
                <Card 
                  key={sitter.id} 
                  className={`border transition-all ${selectedSitter === sitter.id ? 'border-wine ring-2 ring-wine/20' : 'border-gray-200'}`}
                  onClick={() => setSelectedSitter(sitter.id)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div 
                        className="w-16 h-16 rounded-full bg-rose flex-shrink-0 flex items-center justify-center overflow-hidden"
                        style={{ backgroundColor: '#EBD3CB' }}
                      >
                        {sitter.profileImage ? (
                          <img 
                            src={sitter.profileImage} 
                            alt={`${sitter.firstName} ${sitter.lastName}`}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="text-2xl font-bold text-wine">
                            {sitter.firstName?.charAt(0)}{sitter.lastName?.charAt(0)}
                          </div>
                        )}
                      </div>
                      
                      <div className="flex-1">
                        <div className="flex justify-between items-start">
                          <div>
                            <h4 className="font-semibold text-lg">{sitter.firstName} {sitter.lastName ? sitter.lastName.charAt(0) + '.' : ''}</h4>
                            <div className="flex items-center text-sm text-gray-500 mb-1">
                              <MapPin className="h-3.5 w-3.5 mr-1" />
                              <span>{sitter.distance.toFixed(1)}km away</span>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-bold text-lg text-wine">{formatCurrency(sitter.hourlyRate)}/hr</div>
                            {sitter.rating && (
                              <div className="flex items-center justify-end text-sm">
                                <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400 mr-1" />
                                <span>{sitter.rating.toFixed(1)}</span>
                              </div>
                            )}
                          </div>
                        </div>
                        
                        <div className="mt-2 space-y-2">
                          {/* Badges */}
                          {sitter.badges && sitter.badges.length > 0 && (
                            <div className="flex flex-wrap gap-1">
                              {sitter.badges.map((badge: any) => (
                                <Badge 
                                  key={badge.id} 
                                  className="bg-eucalyptus text-wine hover:bg-eucalyptus/80"
                                  variant="secondary"
                                >
                                  <Award className="h-3 w-3 mr-1" /> {badge.name}
                                </Badge>
                              ))}
                            </div>
                          )}
                          
                          {/* Skills or tags */}
                          {sitter.skills && sitter.skills.length > 0 && (
                            <div className="flex flex-wrap gap-1">
                              {sitter.skills.slice(0, 3).map((skill: any) => (
                                <Badge 
                                  key={skill.id} 
                                  variant="outline"
                                  className="bg-linen"
                                >
                                  {skill.skillName || skill.name || 'Skill'}
                                </Badge>
                              ))}
                              {sitter.skills.length > 3 && (
                                <Badge variant="outline">+{sitter.skills.length - 3} more</Badge>
                              )}
                            </div>
                          )}
                        </div>
                        
                        <div className="mt-3 flex justify-between">
                          <Badge 
                            variant="outline" 
                            className={`${sitter.isApproved ? 'border-green-500 text-green-600' : 'border-amber-500 text-amber-600'}`}
                          >
                            {sitter.isApproved ? 'Verified' : 'Pending Verification'}
                          </Badge>
                          
                          <Button 
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              navigate(`/profile/${sitter.userId}`);
                            }}
                          >
                            View Profile
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}