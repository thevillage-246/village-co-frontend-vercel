import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, Gift, TrendingUp, DollarSign } from "lucide-react";

interface ReferralStatistics {
  totalReferrals: number;
  completedReferrals: number;
  pendingReferrals: number;
  recentReferrals: number;
  totalReferralCost: number;
  referralConversionRate: string;
  averageReferralValue: number;
  monthlyGrowthRate: number;
}

export default function ReferralStats() {
  const { data: stats, isLoading, error } = useQuery<ReferralStatistics>({
    queryKey: ['/api/admin/referral-stats'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  if (isLoading) {
    return (
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {[...Array(4)].map((_, i) => (
          <Card key={i}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <div className="h-4 w-20 bg-gray-200 rounded animate-pulse" />
              <div className="h-4 w-4 bg-gray-200 rounded animate-pulse" />
            </CardHeader>
            <CardContent>
              <div className="h-8 w-16 bg-gray-200 rounded animate-pulse mb-1" />
              <div className="h-3 w-24 bg-gray-200 rounded animate-pulse" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <Card className="border-red-200">
        <CardHeader>
          <CardTitle className="text-red-600">Error Loading Referral Statistics</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-600">
            Unable to load referral data. Please try refreshing the page.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-[#6b3e4b]">Referral Program Statistics</h3>
        <Badge variant="outline" className="text-[#6b3e4b] border-[#6b3e4b]">
          Live Data
        </Badge>
      </div>
      
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {/* Total Referrals */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Referrals</CardTitle>
            <Users className="h-4 w-4 text-[#6b3e4b]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-[#6b3e4b]">{stats?.totalReferrals || 0}</div>
            <p className="text-xs text-gray-600">
              All time referral codes created
            </p>
          </CardContent>
        </Card>

        {/* Completed Referrals */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Successful Referrals</CardTitle>
            <Gift className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{stats?.completedReferrals || 0}</div>
            <p className="text-xs text-gray-600">
              {stats?.referralConversionRate || '0'}% conversion rate
            </p>
          </CardContent>
        </Card>

        {/* Total Referral Cost */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Program Cost</CardTitle>
            <DollarSign className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              ${stats?.totalReferralCost || 0}
            </div>
            <p className="text-xs text-gray-600">
              Total credits distributed
            </p>
          </CardContent>
        </Card>

        {/* Monthly Growth */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">This Month</CardTitle>
            <TrendingUp className="h-4 w-4 text-[#ebd3cb]" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-[#6b3e4b]">{stats?.recentReferrals || 0}</div>
            <p className="text-xs text-gray-600">
              New referrals (30 days)
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base text-[#6b3e4b]">Program Performance</CardTitle>
          <CardDescription>
            Detailed breakdown of referral program effectiveness
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            <div className="text-center p-4 bg-gray-50 rounded-lg">
              <div className="text-lg font-semibold text-[#6b3e4b]">
                {stats?.pendingReferrals || 0}
              </div>
              <div className="text-sm text-gray-600">Pending Referrals</div>
              <div className="text-xs text-gray-500 mt-1">
                Codes created but not used
              </div>
            </div>
            
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <div className="text-lg font-semibold text-green-600">
                ${stats?.averageReferralValue || 0}
              </div>
              <div className="text-sm text-gray-600">Average Value</div>
              <div className="text-xs text-gray-500 mt-1">
                Per completed referral
              </div>
            </div>
            
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <div className="text-lg font-semibold text-blue-600">
                {stats?.referralConversionRate || '0'}%
              </div>
              <div className="text-sm text-gray-600">Conversion Rate</div>
              <div className="text-xs text-gray-500 mt-1">
                Codes used vs created
              </div>
            </div>
          </div>

          {stats && stats.totalReferrals > 0 && (
            <div className="pt-4 border-t">
              <div className="flex justify-between items-center text-sm">
                <span className="text-gray-600">Program ROI Impact:</span>
                <span className="font-medium text-[#6b3e4b]">
                  Each $20 investment brings in new families
                </span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}