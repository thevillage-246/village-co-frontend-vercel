import { Link, useLocation } from 'wouter';
import { useState } from 'react';
import { 
  Home, 
  Users, 
  Settings, 
  Calendar, 
  Bell, 
  Award, 
  CheckCircle, 
  AlertTriangle,
  MessageSquare,
  ClipboardList,
  CreditCard,
  Download,
  Menu,
  X,
  Camera,
  Database
} from 'lucide-react';

/**
 * Mobile-responsive sidebar navigation component for the admin dashboard
 */
export default function AdminSidebar() {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  // Define navigation items matching actual routes
  const navItems = [
    { path: '/admin', label: 'Dashboard', icon: <Home size={18} /> },
    { path: '/admin/sitter-approvals', label: 'Sitter Approvals', icon: <CheckCircle size={18} /> },
    { path: '/admin/sitter-photos', label: 'Sitter Photos', icon: <Camera size={18} /> },
    { path: '/admin-dashboard', label: 'Notifications', icon: <Bell size={18} /> },
    { path: '/admin/notifications', label: 'Message Sitters', icon: <MessageSquare size={18} /> },
    { path: '/admin/badge-management', label: 'Badges', icon: <Award size={18} /> },
    { path: '/admin/booking-review', label: 'Booking Review', icon: <ClipboardList size={18} /> },
    { path: '/admin/event-management', label: 'Event Management', icon: <Calendar size={18} /> },
    { path: '/admin/concierge-requests', label: 'Concierge', icon: <Calendar size={18} /> },
    { path: '/admin-inactive', label: 'Inactive Sitters', icon: <Users size={18} /> },
    { path: '/admin-inactive-parents', label: 'Inactive Parents', icon: <Users size={18} /> },
    { path: '/admin-at-risk', label: 'At-Risk Users', icon: <AlertTriangle size={18} /> },
    { path: '/admin/policy-settings', label: 'Policy Settings', icon: <Settings size={18} /> },
    { path: '/admin/stripe-transactions', label: 'Stripe Transactions', icon: <CreditCard size={18} /> },
    { path: '/admin/stripe-sync', label: 'Stripe Sync', icon: <Download size={18} /> },
    { path: '/admin/hubspot-data', label: 'HubSpot Data', icon: <Database size={18} /> },
    { path: '/admin/sms-dashboard', label: 'SMS Dashboard', icon: <MessageSquare size={18} /> },
  ];

  const closeMobileMenu = () => setIsMobileMenuOpen(false);
  
  return (
    <>
      {/* Mobile menu button */}
      <div className="lg:hidden fixed top-4 left-4 z-50">
        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="p-2 bg-white rounded-md shadow-md border"
        >
          {isMobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {/* Mobile overlay */}
      {isMobileMenuOpen && (
        <div 
          className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-40"
          onClick={closeMobileMenu}
        />
      )}

      {/* Sidebar */}
      <aside className={`
        fixed lg:static inset-y-0 left-0 z-50 w-64 bg-white border-r min-h-screen transform transition-transform duration-200 ease-in-out
        ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        lg:block
      `}>
        <div className="flex items-center justify-center h-16 border-b">
          <h1 className="text-lg lg:text-xl font-semibold text-primary">Admin Panel</h1>
        </div>
        
        <nav className="mt-6">
          <ul className="space-y-1 px-2">
            {navItems.map((item) => {
              const isActive = location === item.path;
              
              return (
                <li key={item.path}>
                  <Link href={item.path}>
                    <a 
                      onClick={closeMobileMenu}
                      className={`flex items-center px-4 py-2.5 text-sm rounded-md transition-colors ${
                        isActive
                          ? 'bg-primary text-white'
                          : 'text-gray-700 hover:bg-gray-100'
                      }`}
                    >
                      <span className="mr-3">{item.icon}</span>
                      <span className="truncate">{item.label}</span>
                    </a>
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
      </aside>
    </>
  );
}