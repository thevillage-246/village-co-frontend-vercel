import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { 
  DragDropContext, 
  Droppable, 
  Draggable, 
  DropResult 
} from '@hello-pangea/dnd';
import { 
  UserCheck, 
  HelpCircle, 
  AlertTriangle, 
  Settings, 
  Award, 
  Bell, 
  Flag, 
  Inbox, 
  DollarSign, 
  CheckSquare,
  GripVertical,
  Plus,
  X
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface QuickAction {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  path: string;
  color: string;
  description: string;
  isActive: boolean;
}

const availableActions: QuickAction[] = [
  {
    id: 'sitter-approvals',
    label: 'Approve Sitters',
    icon: UserCheck,
    path: '/admin/sitter-approvals',
    color: 'bg-blue-500',
    description: 'Review and approve new sitter applications',
    isActive: true
  },
  {
    id: 'concierge-requests',
    label: 'Manage Concierge',
    icon: HelpCircle,
    path: '/admin/concierge-requests',
    color: 'bg-purple-500',
    description: 'Handle concierge booking requests',
    isActive: true
  },
  {
    id: 'late-fees',
    label: 'Late Fee Management',
    icon: AlertTriangle,
    path: '/admin/late-fee-management',
    color: 'bg-orange-500',
    description: 'Manage late fee policies and overrides',
    isActive: true
  },
  {
    id: 'policy-settings',
    label: 'Policy Settings',
    icon: Settings,
    path: '/admin/policy-settings',
    color: 'bg-gray-500',
    description: 'Configure platform policies and rules',
    isActive: true
  },
  {
    id: 'badge-management',
    label: 'Badge Management',
    icon: Award,
    path: '/admin/badge-management',
    color: 'bg-yellow-500',
    description: 'Manage sitter badges and achievements',
    isActive: true
  },
  {
    id: 'notifications',
    label: 'Notification Center',
    icon: Bell,
    path: '/admin/notifications',
    color: 'bg-green-500',
    description: 'Send platform-wide notifications',
    isActive: true
  },
  {
    id: 'flagged-bookings',
    label: 'Flagged Bookings',
    icon: Flag,
    path: '/admin/booking-review',
    color: 'bg-red-500',
    description: 'Review flagged or problematic bookings',
    isActive: false
  },
  {
    id: 'hubspot-contacts',
    label: 'HubSpot Contacts',
    icon: Inbox,
    path: '/admin/hubspot-contacts',
    color: 'bg-indigo-500',
    description: 'Sync and manage HubSpot contacts',
    isActive: false
  },
  {
    id: 'financial-reports',
    label: 'Financial Reports',
    icon: DollarSign,
    path: '/admin/financial-reports',
    color: 'bg-emerald-500',
    description: 'View revenue and financial analytics',
    isActive: false
  },
  {
    id: 'system-settings',
    label: 'System Settings',
    icon: CheckSquare,
    path: '/admin/system-settings',
    color: 'bg-slate-500',
    description: 'Configure system-wide settings',
    isActive: false
  }
];

export default function DragDropQuickActions() {
  const [, navigate] = useLocation();
  const [actions, setActions] = useState<QuickAction[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [availableToAdd, setAvailableToAdd] = useState<QuickAction[]>([]);

  // Load saved layout from localStorage
  useEffect(() => {
    const savedActions = localStorage.getItem('admin-quick-actions');
    if (savedActions) {
      try {
        const parsed = JSON.parse(savedActions);
        setActions(parsed);
        
        // Update available actions to add
        const activeIds = parsed.map((action: QuickAction) => action.id);
        setAvailableToAdd(availableActions.filter(action => !activeIds.includes(action.id)));
      } catch (error) {
        console.error('Error loading saved actions:', error);
        loadDefaultActions();
      }
    } else {
      loadDefaultActions();
    }
  }, []);

  const loadDefaultActions = () => {
    const defaultActions = availableActions.filter(action => action.isActive);
    setActions(defaultActions);
    setAvailableToAdd(availableActions.filter(action => !action.isActive));
  };

  // Save layout to localStorage
  const saveActions = (newActions: QuickAction[]) => {
    localStorage.setItem('admin-quick-actions', JSON.stringify(newActions));
  };

  const handleDragEnd = (result: DropResult) => {
    if (!result.destination) return;

    const items = Array.from(actions);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    setActions(items);
    saveActions(items);
  };

  const addAction = (actionToAdd: QuickAction) => {
    const newActions = [...actions, actionToAdd];
    setActions(newActions);
    setAvailableToAdd(availableToAdd.filter(action => action.id !== actionToAdd.id));
    saveActions(newActions);
  };

  const removeAction = (actionId: string) => {
    const actionToRemove = actions.find(action => action.id === actionId);
    if (!actionToRemove) return;

    const newActions = actions.filter(action => action.id !== actionId);
    setActions(newActions);
    setAvailableToAdd([...availableToAdd, actionToRemove]);
    saveActions(newActions);
  };

  const resetToDefault = () => {
    loadDefaultActions();
    saveActions(availableActions.filter(action => action.isActive));
  };

  return (
    <Card className="mt-6">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              Quick Actions
              {isEditing && <Badge variant="secondary">Editing Mode</Badge>}
            </CardTitle>
            <p className="text-sm text-muted-foreground mt-1">
              {isEditing ? 'Drag to reorder, click + to add, or × to remove actions' : 'Click to access frequently used admin functions'}
            </p>
          </div>
          <div className="flex gap-2">
            {isEditing && (
              <Button
                variant="outline"
                size="sm"
                onClick={resetToDefault}
              >
                Reset
              </Button>
            )}
            <Button
              variant={isEditing ? "default" : "outline"}
              size="sm"
              onClick={() => setIsEditing(!isEditing)}
            >
              {isEditing ? 'Done' : 'Customise'}
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <DragDropContext onDragEnd={handleDragEnd}>
          <Droppable droppableId="quick-actions" direction="horizontal">
            {(provided, snapshot) => (
              <div
                {...provided.droppableProps}
                ref={provided.innerRef}
                className={`grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3 min-h-[120px] p-3 rounded-lg transition-colors ${
                  snapshot.isDraggingOver ? 'bg-muted/50' : ''
                }`}
              >
                {actions.map((action, index) => (
                  <Draggable
                    key={action.id}
                    draggableId={action.id}
                    index={index}
                    isDragDisabled={!isEditing}
                  >
                    {(provided, snapshot) => (
                      <div
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        className={`relative group ${snapshot.isDragging ? 'z-50' : ''}`}
                      >
                        <Button
                          variant="outline"
                          className={`h-auto p-4 flex flex-col items-center justify-center gap-2 w-full transition-all hover:shadow-md ${
                            snapshot.isDragging ? 'shadow-lg rotate-3' : ''
                          } ${isEditing ? 'border-dashed border-2' : ''}`}
                          onClick={() => !isEditing && navigate(action.path)}
                          disabled={isEditing}
                        >
                          {isEditing && (
                            <>
                              <div
                                {...provided.dragHandleProps}
                                className="absolute top-1 left-1 text-muted-foreground hover:text-foreground cursor-grab active:cursor-grabbing"
                              >
                                <GripVertical className="h-3 w-3" />
                              </div>
                              <Button
                                variant="ghost"
                                size="sm"
                                className="absolute top-1 right-1 h-5 w-5 p-0 text-muted-foreground hover:text-red-500"
                                onClick={() => removeAction(action.id)}
                              >
                                <X className="h-3 w-3" />
                              </Button>
                            </>
                          )}
                          <div className={`h-8 w-8 rounded-full ${action.color} flex items-center justify-center`}>
                            <action.icon className="h-4 w-4 text-white" />
                          </div>
                          <span className="text-xs font-medium text-center leading-tight">
                            {action.label}
                          </span>
                        </Button>
                      </div>
                    )}
                  </Draggable>
                ))}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </DragDropContext>

        {/* Add Actions Panel */}
        {isEditing && availableToAdd.length > 0 && (
          <div className="mt-4 pt-4 border-t">
            <h4 className="text-sm font-medium mb-3 text-muted-foreground">Available Actions</h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3">
              {availableToAdd.map((action) => (
                <Button
                  key={action.id}
                  variant="ghost"
                  className="h-auto p-3 flex flex-col items-center justify-center gap-2 border-2 border-dashed border-muted-foreground/30 hover:border-primary/50"
                  onClick={() => addAction(action)}
                >
                  <div className={`h-6 w-6 rounded-full ${action.color} flex items-center justify-center`}>
                    <action.icon className="h-3 w-3 text-white" />
                  </div>
                  <span className="text-xs text-center leading-tight">
                    {action.label}
                  </span>
                  <Plus className="h-3 w-3 text-muted-foreground" />
                </Button>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}