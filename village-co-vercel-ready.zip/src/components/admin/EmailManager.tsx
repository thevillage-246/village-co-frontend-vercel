import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { Mail, Send, Users, UserCheck, BarChart3, Target, AlertCircle, CheckCircle, Loader2 } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';

interface EmailTemplate {
  id: string;
  name: string;
  description: string;
}

interface EmailStats {
  totalUsers: number;
  totalParents: number;
  totalSitters: number;
  unverifiedUsers: number;
  lastUpdated: string;
}

const EmailManager: React.FC = () => {
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [recipientEmail, setRecipientEmail] = useState<string>('');
  const [customSubject, setCustomSubject] = useState<string>('');
  const [customMessage, setCustomMessage] = useState<string>('');
  const [firstName, setFirstName] = useState<string>('');
  const [isSending, setIsSending] = useState<boolean>(false);
  const [stats, setStats] = useState<EmailStats | null>(null);
  const [loadingStats, setLoadingStats] = useState<boolean>(true);
  const { toast } = useToast();

  // Load email statistics on component mount
  useEffect(() => {
    loadEmailStats();
  }, []);

  const loadEmailStats = async () => {
    try {
      const response = await apiRequest('GET', '/api/admin/email-stats');
      const data = await response.json();
      
      if (data.success) {
        setStats(data.stats);
      }
    } catch (error) {
      console.error('Error loading email stats:', error);
    } finally {
      setLoadingStats(false);
    }
  };

  const emailTemplates: EmailTemplate[] = [
    {
      id: 'cmd88knih3kz40g0iuywd1zha',
      name: 'New Parent Welcome',
      description: 'Welcome message for new parent registrations'
    },
    {
      id: 'cmd88v16n2hz2z90i0cing87e',
      name: 'Verification Reminder',
      description: 'Reminder to complete identity verification'
    },
    {
      id: 'cmd88svb92gvu1z0izpkfv8dk',
      name: 'No Booking Break Reminder',
      description: 'Encourage parents to book their next break'
    }
  ];

  const bulkEmailOptions = [
    {
      id: 'all_parents',
      name: 'All Parents',
      description: 'Send to all registered parents'
    },
    {
      id: 'all_sitters',
      name: 'All Sitters',
      description: 'Send to all registered sitters'
    },
    {
      id: 'unverified_users',
      name: 'Unverified Users',
      description: 'Send to users who haven\'t completed verification'
    }
  ];

  const handleSendEmail = async () => {
    if (!selectedTemplate || !recipientEmail) {
      toast({
        title: "Missing Information",
        description: "Please select a template and enter recipient email.",
        variant: "destructive",
      });
      return;
    }

    setIsSending(true);
    
    try {
      const response = await apiRequest('POST', '/api/admin/send-custom-email', {
        templateId: selectedTemplate,
        recipientEmail,
        customSubject,
        customMessage,
        variables: {
          first_name: firstName || 'User',
          email: recipientEmail
        }
      });

      const result = await response.json();
      
      if (result.success) {
        toast({
          title: "Email Sent Successfully",
          description: `Email sent to ${recipientEmail}`,
        });
        
        // Reset form
        setRecipientEmail('');
        setCustomSubject('');
        setCustomMessage('');
        setFirstName('');
      } else {
        throw new Error(result.message || 'Failed to send email');
      }
    } catch (error) {
      console.error('Email send error:', error);
      toast({
        title: "Email Send Failed",
        description: error instanceof Error ? error.message : "Failed to send email",
        variant: "destructive",
      });
    } finally {
      setIsSending(false);
    }
  };

  const handleBulkEmail = async (bulkType: string) => {
    if (!selectedTemplate) {
      toast({
        title: "Missing Template",
        description: "Please select an email template first.",
        variant: "destructive",
      });
      return;
    }

    setIsSending(true);
    
    try {
      const response = await apiRequest('POST', '/api/admin/send-bulk-email', {
        templateId: selectedTemplate,
        bulkType,
        customSubject,
        customMessage
      });

      toast({
        title: "Bulk Email Initiated",
        description: `Bulk email campaign started for ${bulkType}`,
      });
    } catch (error) {
      toast({
        title: "Bulk Email Failed",
        description: error instanceof Error ? error.message : "Failed to send bulk email",
        variant: "destructive",
      });
    } finally {
      setIsSending(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Mail className="h-5 w-5" />
          Email Manager
        </CardTitle>
        <CardDescription>
          Send individual emails or bulk campaigns using Loops templates
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Email Statistics */}
        {!loadingStats && stats && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="h-5 w-5" />
                Email Campaign Statistics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">{stats.totalUsers}</div>
                  <div className="text-sm text-muted-foreground">Total Users</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">{stats.totalParents}</div>
                  <div className="text-sm text-muted-foreground">Parents</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">{stats.totalSitters}</div>
                  <div className="text-sm text-muted-foreground">Sitters</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-600">{stats.unverifiedUsers}</div>
                  <div className="text-sm text-muted-foreground">Unverified</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Template Selection */}
        <div className="space-y-2">
          <label className="text-sm font-medium">Email Template</label>
          <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
            <SelectTrigger>
              <SelectValue placeholder="Select email template" />
            </SelectTrigger>
            <SelectContent>
              {emailTemplates.map((template) => (
                <SelectItem key={template.id} value={template.id}>
                  <div className="flex items-center justify-between w-full">
                    <div>
                      <div className="font-medium">{template.name}</div>
                      <div className="text-xs text-muted-foreground">{template.description}</div>
                    </div>
                    <CheckCircle className="h-4 w-4 text-green-500 ml-2" />
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Individual Email Section */}
        <div className="border rounded-lg p-4 space-y-4">
          <h3 className="font-medium flex items-center gap-2">
            <Send className="h-4 w-4" />
            Send Individual Email
          </h3>
          
          <div className="space-y-3">
            <div>
              <label className="text-sm font-medium">Recipient Email</label>
              <Input
                type="email"
                placeholder="user@example.com"
                value={recipientEmail}
                onChange={(e) => setRecipientEmail(e.target.value)}
              />
            </div>

            <div>
              <label className="text-sm font-medium">First Name (Optional)</label>
              <Input
                placeholder="User's first name"
                value={firstName}
                onChange={(e) => setFirstName(e.target.value)}
              />
            </div>
            
            <div>
              <label className="text-sm font-medium">Custom Subject (Optional)</label>
              <Input
                placeholder="Override template subject"
                value={customSubject}
                onChange={(e) => setCustomSubject(e.target.value)}
              />
            </div>
            
            <div>
              <label className="text-sm font-medium">Custom Message (Optional)</label>
              <Textarea
                placeholder="Add custom message to template"
                value={customMessage}
                onChange={(e) => setCustomMessage(e.target.value)}
                rows={3}
              />
            </div>
            
            <Button 
              onClick={handleSendEmail} 
              disabled={isSending || !selectedTemplate || !recipientEmail}
              className="w-full"
            >
              {isSending ? 'Sending...' : 'Send Email'}
            </Button>
          </div>
        </div>

        {/* Bulk Email Section */}
        <div className="border rounded-lg p-4 space-y-4">
          <h3 className="font-medium flex items-center gap-2">
            <Users className="h-4 w-4" />
            Send Bulk Email
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {bulkEmailOptions.map((option) => {
              let userCount = 0;
              if (stats) {
                switch (option.id) {
                  case 'all_parents':
                    userCount = stats.totalParents;
                    break;
                  case 'all_sitters':
                    userCount = stats.totalSitters;
                    break;
                  case 'unverified_users':
                    userCount = stats.unverifiedUsers;
                    break;
                }
              }
              
              return (
                <Button
                  key={option.id}
                  variant="outline"
                  className="h-auto flex flex-col items-center justify-center gap-2 p-4"
                  onClick={() => handleBulkEmail(option.id)}
                  disabled={isSending || !selectedTemplate}
                >
                  {option.id === 'all_parents' && <Users className="h-5 w-5" />}
                  {option.id === 'all_sitters' && <UserCheck className="h-5 w-5" />}
                  {option.id === 'unverified_users' && <Mail className="h-5 w-5" />}
                  <div className="text-center">
                    <div className="text-sm font-medium">{option.name}</div>
                    <div className="text-xs text-muted-foreground">{option.description}</div>
                    {stats && (
                      <Badge variant="secondary" className="mt-1">
                        {userCount} users
                      </Badge>
                    )}
                  </div>
                </Button>
              );
            })}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="border rounded-lg p-4 space-y-3">
          <h3 className="font-medium">Quick Actions</h3>
          <div className="flex flex-wrap gap-2">
            <Button size="sm" variant="outline" onClick={() => window.open('/admin/loops-content', '_blank')}>
              Manage Templates
            </Button>
            <Button size="sm" variant="outline" onClick={() => setSelectedTemplate('cmd88v16n2hz2z90i0cing87e')}>
              Send Verification Reminder
            </Button>
            <Button size="sm" variant="outline" onClick={() => setSelectedTemplate('cmd88knih3kz40g0iuywd1zha')}>
              Welcome New Parent
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default EmailManager;