/**
 * Veriff Notifications Component
 * Admin dashboard component for managing verification approvals
 */

import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertCircle, CheckCircle, XCircle, Clock, User, Mail } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface VeriffNotification {
  id: string;
  userId: number;
  userType: 'parent' | 'sitter';
  email: string;
  firstName: string;
  lastName: string;
  verificationId: string;
  status: 'approved' | 'declined' | 'expired' | 'abandoned';
  timestamp: string;
  processed: boolean;
  adminNotified: boolean;
}

export default function VeriffNotifications() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('unprocessed');

  // Fetch unprocessed notifications
  const { data: unprocessedNotifications = [], isLoading: loadingUnprocessed } = useQuery({
    queryKey: ['/api/admin/veriff-notifications'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Fetch all notifications
  const { data: allNotifications = [], isLoading: loadingAll } = useQuery({
    queryKey: ['/api/admin/veriff-notifications/all'],
    enabled: activeTab === 'all',
  });

  // Mark notification as processed
  const processNotificationMutation = useMutation({
    mutationFn: async (notificationId: string) => {
      const response = await apiRequest('POST', `/api/admin/veriff-notifications/${notificationId}/process`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/veriff-notifications'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/veriff-notifications/all'] });
      toast({
        title: "Notification Processed",
        description: "The verification notification has been marked as processed.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: "Failed to process notification. Please try again.",
        variant: "destructive",
      });
    },
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'declined':
        return <XCircle className="w-4 h-4 text-red-500" />;
      case 'expired':
        return <Clock className="w-4 h-4 text-orange-500" />;
      case 'abandoned':
        return <AlertCircle className="w-4 h-4 text-gray-500" />;
      default:
        return <AlertCircle className="w-4 h-4 text-gray-500" />;
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, 'default' | 'secondary' | 'destructive' | 'outline'> = {
      approved: 'default',
      declined: 'destructive',
      expired: 'secondary',
      abandoned: 'outline',
    };

    return (
      <Badge variant={variants[status] || 'outline'} className="capitalize">
        {status}
      </Badge>
    );
  };

  const NotificationCard = ({ notification }: { notification: VeriffNotification }) => (
    <Card className="mb-4">
      <CardContent className="p-4">
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              {getStatusIcon(notification.status)}
              <h3 className="font-medium">
                {notification.firstName} {notification.lastName}
              </h3>
              {getStatusBadge(notification.status)}
              <Badge variant="outline" className="capitalize">
                {notification.userType}
              </Badge>
            </div>
            
            <div className="space-y-1 text-sm text-gray-600">
              <div className="flex items-center gap-2">
                <Mail className="w-3 h-3" />
                {notification.email}
              </div>
              <div className="flex items-center gap-2">
                <User className="w-3 h-3" />
                User ID: {notification.userId}
              </div>
              <div>
                Verification ID: {notification.verificationId}
              </div>
              <div>
                {new Date(notification.timestamp).toLocaleString()}
              </div>
            </div>
          </div>
          
          <div className="flex flex-col gap-2">
            {!notification.processed && (
              <Button
                size="sm"
                onClick={() => processNotificationMutation.mutate(notification.id)}
                disabled={processNotificationMutation.isPending}
              >
                {processNotificationMutation.isPending ? 'Processing...' : 'Mark Processed'}
              </Button>
            )}
            {notification.processed && (
              <Badge variant="secondary">Processed</Badge>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="w-5 h-5" />
            Veriff Verification Notifications
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="unprocessed">
                Unprocessed ({unprocessedNotifications.length})
              </TabsTrigger>
              <TabsTrigger value="all">All Notifications</TabsTrigger>
            </TabsList>

            <TabsContent value="unprocessed" className="space-y-4">
              {loadingUnprocessed ? (
                <div className="text-center py-8">Loading notifications...</div>
              ) : unprocessedNotifications.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No unprocessed verification notifications
                </div>
              ) : (
                <div>
                  {unprocessedNotifications.map((notification: VeriffNotification) => (
                    <NotificationCard key={notification.id} notification={notification} />
                  ))}
                </div>
              )}
            </TabsContent>

            <TabsContent value="all" className="space-y-4">
              {loadingAll ? (
                <div className="text-center py-8">Loading all notifications...</div>
              ) : allNotifications.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  No verification notifications found
                </div>
              ) : (
                <div>
                  {allNotifications.map((notification: VeriffNotification) => (
                    <NotificationCard key={notification.id} notification={notification} />
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Verification Status Guide</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-green-500" />
              <span>Approved - User verified successfully</span>
            </div>
            <div className="flex items-center gap-2">
              <XCircle className="w-4 h-4 text-red-500" />
              <span>Declined - Verification failed</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-orange-500" />
              <span>Expired - Session timed out</span>
            </div>
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-gray-500" />
              <span>Abandoned - User left process</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}