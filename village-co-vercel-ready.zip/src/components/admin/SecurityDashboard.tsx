import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { ShieldAlert, Users, Eye, EyeOff, Trash2, Flag, AlertTriangle } from "lucide-react";

interface User {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  role: string;
  isVillageVerified?: boolean;
  mustChangePassword?: boolean;
  lastActivity?: string;
}

interface Review {
  id: number;
  rating: number;
  comment: string;
  isReported?: boolean;
  isHidden?: boolean;
  reportReason?: string;
  hideReason?: string;
  reviewerName?: string;
  sitterName?: string;
}

export function SecurityDashboard() {
  const [inactiveUsers, setInactiveUsers] = useState<User[]>([]);
  const [reportedReviews, setReportedReviews] = useState<Review[]>([]);
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [newPassword, setNewPassword] = useState("");
  const [hideReason, setHideReason] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  // Load data on component mount
  useEffect(() => {
    loadInactiveUsers();
    loadReportedReviews();
  }, []);

  const loadInactiveUsers = async () => {
    try {
      const response = await apiRequest("GET", "/api/admin/users/inactive");
      if (response.ok) {
        const data = await response.json();
        setInactiveUsers(data.inactiveUsers || []);
      }
    } catch (error) {
      console.error("Failed to load inactive users:", error);
    }
  };

  const loadReportedReviews = async () => {
    try {
      const response = await apiRequest("GET", "/api/admin/reviews/reported");
      if (response.ok) {
        const data = await response.json();
        setReportedReviews(data.reportedReviews || []);
      }
    } catch (error) {
      console.error("Failed to load reported reviews:", error);
    }
  };

  const handlePasswordReset = async (userId: number) => {
    if (!newPassword) {
      toast({
        title: "Password required",
        description: "Please enter a new password",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const response = await apiRequest("PUT", `/api/admin/users/${userId}/password`, {
        newPassword,
        mustChangePassword: true
      });

      if (response.ok) {
        toast({
          title: "Password updated",
          description: "User password has been reset and they must change it on next login",
        });
        setNewPassword("");
        setSelectedUser(null);
      } else {
        const error = await response.json();
        toast({
          title: "Password reset failed",
          description: error.message || "Failed to reset password",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Password reset error:", error);
      toast({
        title: "Error",
        description: "Failed to reset password. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerificationToggle = async (userId: number, verified: boolean) => {
    setIsLoading(true);
    try {
      const response = await apiRequest("PUT", `/api/admin/users/${userId}/village-verification`, {
        verified
      });

      if (response.ok) {
        toast({
          title: `User ${verified ? 'verified' : 'unverified'}`,
          description: `Village verification status updated successfully`,
        });
        loadInactiveUsers(); // Refresh the list
      } else {
        const error = await response.json();
        toast({
          title: "Verification update failed",
          description: error.message || "Failed to update verification status",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Verification update error:", error);
      toast({
        title: "Error",
        description: "Failed to update verification. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleHideReview = async (reviewId: number) => {
    if (!hideReason) {
      toast({
        title: "Reason required",
        description: "Please provide a reason for hiding this review",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const response = await apiRequest("PUT", `/api/admin/reviews/${reviewId}/hide`, {
        reason: hideReason
      });

      if (response.ok) {
        toast({
          title: "Review hidden",
          description: "Review has been hidden successfully",
        });
        setHideReason("");
        loadReportedReviews(); // Refresh the list
      } else {
        const error = await response.json();
        toast({
          title: "Hide review failed",
          description: error.message || "Failed to hide review",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Hide review error:", error);
      toast({
        title: "Error",
        description: "Failed to hide review. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleUnhideReview = async (reviewId: number) => {
    setIsLoading(true);
    try {
      const response = await apiRequest("PUT", `/api/admin/reviews/${reviewId}/unhide`);

      if (response.ok) {
        toast({
          title: "Review unhidden",
          description: "Review is now visible again",
        });
        loadReportedReviews(); // Refresh the list
      } else {
        const error = await response.json();
        toast({
          title: "Unhide review failed",
          description: error.message || "Failed to unhide review",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Unhide review error:", error);
      toast({
        title: "Error",
        description: "Failed to unhide review. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteReview = async (reviewId: number) => {
    if (!confirm("Are you sure you want to permanently delete this review? This action cannot be undone.")) {
      return;
    }

    setIsLoading(true);
    try {
      const response = await apiRequest("DELETE", `/api/admin/reviews/${reviewId}`);

      if (response.ok) {
        toast({
          title: "Review deleted",
          description: "Review has been permanently deleted",
        });
        loadReportedReviews(); // Refresh the list
      } else {
        const error = await response.json();
        toast({
          title: "Delete review failed",
          description: error.message || "Failed to delete review",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Delete review error:", error);
      toast({
        title: "Error",
        description: "Failed to delete review. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const flagInactiveUsers = async () => {
    setIsLoading(true);
    try {
      const response = await apiRequest("POST", "/api/admin/users/flag-inactive");

      if (response.ok) {
        const data = await response.json();
        toast({
          title: "Users flagged",
          description: `${data.flaggedUsers?.length || 0} inactive users have been flagged`,
        });
        loadInactiveUsers(); // Refresh the list
      } else {
        const error = await response.json();
        toast({
          title: "Flag users failed",
          description: error.message || "Failed to flag inactive users",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error("Flag users error:", error);
      toast({
        title: "Error",
        description: "Failed to flag users. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-2">
        <ShieldAlert className="h-6 w-6 text-village-wine" />
        <h1 className="text-2xl font-bold">Security & Moderation Dashboard</h1>
      </div>

      <Tabs defaultValue="users" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="users" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            User Management
          </TabsTrigger>
          <TabsTrigger value="reviews" className="flex items-center gap-2">
            <Flag className="h-4 w-4" />
            Review Moderation
          </TabsTrigger>
        </TabsList>

        <TabsContent value="users" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Inactive Users</CardTitle>
              <CardDescription>
                Users who haven't made bookings in 90+ days. You can flag them for follow-up or manage their access.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">
                  {inactiveUsers.length} inactive users found
                </span>
                <Button 
                  onClick={flagInactiveUsers}
                  disabled={isLoading}
                  variant="outline"
                  size="sm"
                >
                  <AlertTriangle className="h-4 w-4 mr-2" />
                  Flag All Inactive
                </Button>
              </div>

              <div className="space-y-3">
                {inactiveUsers.map((user) => (
                  <div key={user.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{user.firstName} {user.lastName}</span>
                        <Badge variant={user.role === 'admin' ? 'default' : user.role === 'sitter' ? 'secondary' : 'outline'}>
                          {user.role}
                        </Badge>
                        {user.isVillageVerified && (
                          <Badge variant="default" className="bg-green-100 text-green-800">
                            Village Verified
                          </Badge>
                        )}
                        {user.mustChangePassword && (
                          <Badge variant="destructive">
                            Must Change Password
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">{user.email}</p>
                      {user.lastActivity && (
                        <p className="text-xs text-muted-foreground">Last active: {user.lastActivity}</p>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setSelectedUser(user)}
                      >
                        Reset Password
                      </Button>
                      <Button
                        size="sm"
                        variant={user.isVillageVerified ? "destructive" : "default"}
                        onClick={() => handleVerificationToggle(user.id, !user.isVillageVerified)}
                        disabled={isLoading}
                      >
                        {user.isVillageVerified ? 'Unverify' : 'Verify'}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {selectedUser && (
            <Card>
              <CardHeader>
                <CardTitle>Reset Password for {selectedUser.firstName} {selectedUser.lastName}</CardTitle>
                <CardDescription>
                  Enter a new temporary password. The user will be required to change it on their next login.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="newPassword">New Password</Label>
                  <Input
                    id="newPassword"
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Enter new password (min 8 characters)"
                    minLength={8}
                  />
                </div>
                <div className="flex gap-2">
                  <Button
                    onClick={() => handlePasswordReset(selectedUser.id)}
                    disabled={isLoading || !newPassword}
                  >
                    {isLoading ? "Updating..." : "Reset Password"}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setSelectedUser(null);
                      setNewPassword("");
                    }}
                  >
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="reviews" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Reported Reviews</CardTitle>
              <CardDescription>
                Reviews that have been flagged by users for inappropriate content or violations.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-sm text-muted-foreground">
                {reportedReviews.length} reported reviews requiring attention
              </div>

              <div className="space-y-4">
                {reportedReviews.map((review) => (
                  <div key={review.id} className="border rounded-lg p-4 space-y-3">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="font-medium">Review #{review.id}</span>
                          <Badge variant="outline">
                            {review.rating}/5 stars
                          </Badge>
                          {review.isHidden && (
                            <Badge variant="secondary">
                              <EyeOff className="h-3 w-3 mr-1" />
                              Hidden
                            </Badge>
                          )}
                          {review.isReported && (
                            <Badge variant="destructive">
                              <Flag className="h-3 w-3 mr-1" />
                              Reported
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm mb-2">{review.comment}</p>
                        {review.reviewerName && (
                          <p className="text-xs text-muted-foreground">
                            By: {review.reviewerName} → {review.sitterName}
                          </p>
                        )}
                        {review.reportReason && (
                          <p className="text-xs text-red-600">
                            Report reason: {review.reportReason}
                          </p>
                        )}
                        {review.hideReason && (
                          <p className="text-xs text-orange-600">
                            Hidden reason: {review.hideReason}
                          </p>
                        )}
                      </div>
                    </div>

                    {!review.isHidden && (
                      <div className="space-y-2">
                        <Textarea
                          placeholder="Reason for hiding this review..."
                          value={hideReason}
                          onChange={(e) => setHideReason(e.target.value)}
                          className="h-20"
                        />
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleHideReview(review.id)}
                            disabled={isLoading || !hideReason}
                          >
                            <EyeOff className="h-4 w-4 mr-2" />
                            Hide Review
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleDeleteReview(review.id)}
                            disabled={isLoading}
                          >
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete Permanently
                          </Button>
                        </div>
                      </div>
                    )}

                    {review.isHidden && (
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleUnhideReview(review.id)}
                          disabled={isLoading}
                        >
                          <Eye className="h-4 w-4 mr-2" />
                          Unhide Review
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleDeleteReview(review.id)}
                          disabled={isLoading}
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete Permanently
                        </Button>
                      </div>
                    )}
                  </div>
                ))}

                {reportedReviews.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    <Flag className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>No reported reviews at this time</p>
                    <p className="text-sm">All reviews are currently in good standing</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}