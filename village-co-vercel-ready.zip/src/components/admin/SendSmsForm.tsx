import { useState } from 'react';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, Send, Check } from 'lucide-react';

// Schema for SMS form validation
const smsFormSchema = z.object({
  to: z.string()
    .min(8, { message: 'Phone number is too short' })
    .max(15, { message: 'Phone number is too long' })
    .regex(/^[0-9+]+$/, { message: 'Phone number can only contain numbers and +' }),
  message: z.string()
    .min(1, { message: 'Message is required' })
    .max(160, { message: 'Message cannot exceed 160 characters' }),
});

type SmsFormValues = z.infer<typeof smsFormSchema>;

export default function SendSmsForm() {
  const [isSending, setIsSending] = useState(false);
  const [success, setSuccess] = useState(false);
  const { toast } = useToast();

  // Form definition
  const form = useForm<SmsFormValues>({
    resolver: zodResolver(smsFormSchema),
    defaultValues: {
      to: '',
      message: '',
    },
  });

  // Handle form submission
  const onSubmit = async (values: SmsFormValues) => {
    setIsSending(true);
    setSuccess(false);
    
    try {
      const response = await apiRequest('POST', '/api/sms/send', values);
      const data = await response.json();
      
      if (response.ok) {
        setSuccess(true);
        form.reset();
        toast({
          title: 'SMS Sent Successfully',
          description: `Message sent to ${values.to}`,
          variant: 'default',
        });
      } else {
        throw new Error(data.error || 'Failed to send SMS');
      }
    } catch (error: any) {
      toast({
        title: 'Failed to send SMS',
        description: error.message || 'An unexpected error occurred',
        variant: 'destructive',
      });
    } finally {
      setIsSending(false);
      
      // Reset success indicator after a delay
      if (success) {
        setTimeout(() => setSuccess(false), 3000);
      }
    }
  };

  // Character counter for message
  const messageLength = form.watch('message')?.length || 0;

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="text-lg">Send SMS Notification</CardTitle>
        <CardDescription>
          Send a verification or reminder SMS to a sitter
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="to"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Phone Number</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="+64xxxxxxxxx" 
                      {...field}
                      disabled={isSending} 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="message"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Message</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Your message here..."
                      className="h-24 resize-none"
                      maxLength={160}
                      {...field}
                      disabled={isSending}
                    />
                  </FormControl>
                  <div className="text-xs text-muted-foreground mt-1 flex justify-between">
                    <span>Max 160 characters</span>
                    <span>{messageLength}/160</span>
                  </div>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Button 
              type="submit" 
              className="w-full" 
              disabled={isSending || !form.formState.isValid}
            >
              {isSending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Sending...
                </>
              ) : success ? (
                <>
                  <Check className="mr-2 h-4 w-4" />
                  Sent
                </>
              ) : (
                <>
                  <Send className="mr-2 h-4 w-4" />
                  Send SMS
                </>
              )}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}