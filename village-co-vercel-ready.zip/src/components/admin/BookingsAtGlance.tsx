import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar, TrendingUp, TrendingDown, Users, DollarSign, Star, Clock, Filter, X } from 'lucide-react';
import { format } from 'date-fns';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

interface BookingAnalytics {
  upcomingBookings: Array<{
    id: string;
    parentName: string;
    sitterName: string;
    startTime: string;
    endTime: string;
    status: string;
  }>;
  volumeTrends: {
    thisWeek: number;
    thisMonth: number;
    weeklyChange: number;
    monthlyChange: number;
  };
  topPerformers: {
    sitters: Array<{
      id: string;
      name: string;
      bookings: number;
      rating: number;
    }>;
    parents: Array<{
      id: string;
      name: string;
      bookings: number;
    }>;
  };
  summaryStats: {
    totalActiveSitters: number;
    totalActiveParents: number;
    totalRevenue: number;
  };
}

interface ChartData {
  date: string;
  bookings: number;
  label: string;
}

export default function BookingsAtGlance() {
  const [chartPeriod, setChartPeriod] = useState<'7days' | '30days'>('7days');
  const [showFilters, setShowFilters] = useState(false);
  
  // Filter states
  const [statusFilters, setStatusFilters] = useState({
    pending: false,
    confirmed: false,
    completed: false,
    cancelled: false,
  });
  
  const [dateFilters, setDateFilters] = useState({
    today: false,
    thisWeek: false,
    thisMonth: false,
    lastMonth: false,
  });
  
  const [sitterFilters, setSitterFilters] = useState({
    topPerformers: false,
    newSitters: false,
    verifiedOnly: false,
  });

  // Fetch booking analytics
  const { data: analytics, isLoading, error } = useQuery<BookingAnalytics>({
    queryKey: ['/api/admin/booking-analytics'],
    queryFn: async () => {
      const token = localStorage.getItem('authToken');
      if (!token) throw new Error('Authentication required');
      
      const response = await fetch('/api/admin/booking-analytics', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      if (!response.ok) throw new Error('Failed to fetch booking analytics');
      return response.json();
    }
  });

  // Fetch chart data
  const { data: chartData, isLoading: chartLoading } = useQuery<ChartData[]>({
    queryKey: ['/api/admin/booking-chart-data', chartPeriod],
    queryFn: async () => {
      const token = localStorage.getItem('authToken');
      if (!token) throw new Error('Authentication required');
      
      const response = await fetch(`/api/admin/booking-chart-data?period=${chartPeriod}`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      if (!response.ok) throw new Error('Failed to fetch chart data');
      return response.json();
    }
  });

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      pending: { variant: 'secondary' as const, label: 'Pending' },
      confirmed: { variant: 'default' as const, label: 'Confirmed' },
      completed: { variant: 'outline' as const, label: 'Completed' },
      cancelled: { variant: 'destructive' as const, label: 'Cancelled' }
    };
    
    const config = statusConfig[status.toLowerCase() as keyof typeof statusConfig] || statusConfig.pending;
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-NZ', {
      style: 'currency',
      currency: 'NZD',
      minimumFractionDigits: 0
    }).format(amount);
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star 
        key={i}
        className={`h-4 w-4 ${i < Math.floor(rating) ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
      />
    ));
  };

  // Clear all filters
  const clearAllFilters = () => {
    setStatusFilters({
      pending: false,
      confirmed: false,
      completed: false,
      cancelled: false,
    });
    setDateFilters({
      today: false,
      thisWeek: false,
      thisMonth: false,
      lastMonth: false,
    });
    setSitterFilters({
      topPerformers: false,
      newSitters: false,
      verifiedOnly: false,
    });
  };

  // Check if any filters are active
  const hasActiveFilters = () => {
    return Object.values(statusFilters).some(Boolean) ||
           Object.values(dateFilters).some(Boolean) ||
           Object.values(sitterFilters).some(Boolean);
  };

  if (error) {
    return (
      <div className="p-6">
        <Card>
          <CardContent className="pt-6">
            <div className="text-center text-red-600">
              Failed to load booking analytics. Please try again.
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-village-wine">Bookings at a Glance</h1>
          <p className="text-muted-foreground">Overview of platform booking activity and performance</p>
        </div>
        <Popover open={showFilters} onOpenChange={setShowFilters}>
          <PopoverTrigger asChild>
            <Button variant="outline" className={`flex items-center gap-2 ${hasActiveFilters() ? 'border-village-wine text-village-wine' : ''}`}>
              <Filter className="h-4 w-4" />
              <span className="hidden sm:inline">Advanced Filters</span>
              <span className="sm:hidden">Filters</span>
              {hasActiveFilters() && (
                <Badge variant="secondary" className="ml-1 px-1.5 py-0.5 text-xs bg-village-wine text-white">
                  {Object.values({...statusFilters, ...dateFilters, ...sitterFilters}).filter(Boolean).length}
                </Badge>
              )}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-80" align="end">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-medium">Advanced Filters</h4>
                {hasActiveFilters() && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={clearAllFilters}
                    className="text-xs p-1 h-auto"
                  >
                    <X className="h-3 w-3 mr-1" />
                    Clear All
                  </Button>
                )}
              </div>

              {/* Booking Status Filters */}
              <div>
                <h5 className="text-sm font-medium mb-2">Booking Status</h5>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="status-pending"
                      checked={statusFilters.pending}
                      onCheckedChange={(checked) =>
                        setStatusFilters(prev => ({ ...prev, pending: checked as boolean }))
                      }
                    />
                    <Label htmlFor="status-pending" className="text-sm">Pending</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="status-confirmed"
                      checked={statusFilters.confirmed}
                      onCheckedChange={(checked) =>
                        setStatusFilters(prev => ({ ...prev, confirmed: checked as boolean }))
                      }
                    />
                    <Label htmlFor="status-confirmed" className="text-sm">Confirmed</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="status-completed"
                      checked={statusFilters.completed}
                      onCheckedChange={(checked) =>
                        setStatusFilters(prev => ({ ...prev, completed: checked as boolean }))
                      }
                    />
                    <Label htmlFor="status-completed" className="text-sm">Completed</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="status-cancelled"
                      checked={statusFilters.cancelled}
                      onCheckedChange={(checked) =>
                        setStatusFilters(prev => ({ ...prev, cancelled: checked as boolean }))
                      }
                    />
                    <Label htmlFor="status-cancelled" className="text-sm">Cancelled</Label>
                  </div>
                </div>
              </div>

              {/* Date Range Filters */}
              <div>
                <h5 className="text-sm font-medium mb-2">Date Range</h5>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="date-today"
                      checked={dateFilters.today}
                      onCheckedChange={(checked) =>
                        setDateFilters(prev => ({ ...prev, today: checked as boolean }))
                      }
                    />
                    <Label htmlFor="date-today" className="text-sm">Today</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="date-week"
                      checked={dateFilters.thisWeek}
                      onCheckedChange={(checked) =>
                        setDateFilters(prev => ({ ...prev, thisWeek: checked as boolean }))
                      }
                    />
                    <Label htmlFor="date-week" className="text-sm">This Week</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="date-month"
                      checked={dateFilters.thisMonth}
                      onCheckedChange={(checked) =>
                        setDateFilters(prev => ({ ...prev, thisMonth: checked as boolean }))
                      }
                    />
                    <Label htmlFor="date-month" className="text-sm">This Month</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="date-last-month"
                      checked={dateFilters.lastMonth}
                      onCheckedChange={(checked) =>
                        setDateFilters(prev => ({ ...prev, lastMonth: checked as boolean }))
                      }
                    />
                    <Label htmlFor="date-last-month" className="text-sm">Last Month</Label>
                  </div>
                </div>
              </div>

              {/* Sitter Type Filters */}
              <div>
                <h5 className="text-sm font-medium mb-2">Sitter Categories</h5>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="sitter-top"
                      checked={sitterFilters.topPerformers}
                      onCheckedChange={(checked) =>
                        setSitterFilters(prev => ({ ...prev, topPerformers: checked as boolean }))
                      }
                    />
                    <Label htmlFor="sitter-top" className="text-sm">Top Performers</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="sitter-new"
                      checked={sitterFilters.newSitters}
                      onCheckedChange={(checked) =>
                        setSitterFilters(prev => ({ ...prev, newSitters: checked as boolean }))
                      }
                    />
                    <Label htmlFor="sitter-new" className="text-sm">New Sitters</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="sitter-verified"
                      checked={sitterFilters.verifiedOnly}
                      onCheckedChange={(checked) =>
                        setSitterFilters(prev => ({ ...prev, verifiedOnly: checked as boolean }))
                      }
                    />
                    <Label htmlFor="sitter-verified" className="text-sm">Verified Only</Label>
                  </div>
                </div>
              </div>
            </div>
          </PopoverContent>
        </Popover>
      </div>

      {/* Summary Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Bookings</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <>
                <div className="text-2xl font-bold">{analytics?.volumeTrends.thisMonth || 0}</div>
                <p className="text-xs text-muted-foreground">
                  {analytics?.volumeTrends.monthlyChange !== undefined && (
                    <span className={`flex items-center gap-1 ${
                      analytics.volumeTrends.monthlyChange >= 0 ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {analytics.volumeTrends.monthlyChange >= 0 ? (
                        <TrendingUp className="h-3 w-3" />
                      ) : (
                        <TrendingDown className="h-3 w-3" />
                      )}
                      {Math.abs(analytics.volumeTrends.monthlyChange)}% vs last month
                    </span>
                  )}
                </p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Sitters</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <>
                <div className="text-2xl font-bold">{analytics?.summaryStats.totalActiveSitters || 0}</div>
                <p className="text-xs text-muted-foreground">Active in last 30 days</p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Parents</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <>
                <div className="text-2xl font-bold">{analytics?.summaryStats.totalActiveParents || 0}</div>
                <p className="text-xs text-muted-foreground">Active in last 30 days</p>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <Skeleton className="h-8 w-20" />
            ) : (
              <>
                <div className="text-2xl font-bold">
                  {formatCurrency(analytics?.summaryStats.totalRevenue || 0)}
                </div>
                <p className="text-xs text-muted-foreground">Commission this month</p>
              </>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upcoming Bookings This Week */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              Upcoming Bookings This Week
            </CardTitle>
            <CardDescription>
              Next 7 days of confirmed and pending bookings
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-3">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className="flex items-center justify-between p-3 border rounded">
                    <div className="space-y-1">
                      <Skeleton className="h-4 w-32" />
                      <Skeleton className="h-3 w-24" />
                    </div>
                    <Skeleton className="h-6 w-16" />
                  </div>
                ))}
              </div>
            ) : analytics?.upcomingBookings.length ? (
              <div className="space-y-3 max-h-64 overflow-y-auto">
                {analytics.upcomingBookings.map((booking) => (
                  <div key={booking.id} className="flex items-center justify-between p-3 border rounded hover:bg-gray-50">
                    <div className="space-y-1">
                      <div className="font-medium text-sm">
                        {booking.parentName} → {booking.sitterName}
                      </div>
                      <div className="text-xs text-muted-foreground flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {format(new Date(booking.startTime), 'MMM dd, h:mm a')} - 
                        {format(new Date(booking.endTime), 'h:mm a')}
                      </div>
                    </div>
                    {getStatusBadge(booking.status)}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center text-muted-foreground py-8">
                No upcoming bookings this week
              </div>
            )}
          </CardContent>
        </Card>

        {/* Booking Volume Trends Chart */}
        <Card>
          <CardHeader>
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Booking Volume Trends
                </CardTitle>
                <CardDescription>
                  Daily booking activity
                </CardDescription>
              </div>
              <Select value={chartPeriod} onValueChange={(value: string) => setChartPeriod(value as "7days" | "30days")}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7days">7 Days</SelectItem>
                  <SelectItem value="30days">30 Days</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent>
            {chartLoading ? (
              <Skeleton className="h-64 w-full" />
            ) : chartData?.length ? (
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="label" 
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                  />
                  <YAxis 
                    fontSize={12}
                    tickLine={false}
                    axisLine={false}
                    tickFormatter={(value) => `${value}`}
                  />
                  <Tooltip 
                    content={({ active, payload, label }) => {
                      if (active && payload && payload.length) {
                        return (
                          <div className="bg-white p-3 border rounded shadow-lg">
                            <p className="font-medium">{label}</p>
                            <p className="text-village-wine">
                              Bookings: {payload[0].value}
                            </p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Bar 
                    dataKey="bookings" 
                    fill="#6b3e4b" 
                    radius={[4, 4, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-64 flex items-center justify-center text-muted-foreground">
                No booking data available
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Performing Sitters */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Star className="h-5 w-5" />
              Top Sitters This Month
            </CardTitle>
            <CardDescription>
              Most active sitters by booking count
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-3">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className="flex items-center justify-between p-3 border rounded">
                    <div className="flex items-center gap-3">
                      <Skeleton className="h-8 w-8 rounded-full" />
                      <div className="space-y-1">
                        <Skeleton className="h-4 w-24" />
                        <Skeleton className="h-3 w-16" />
                      </div>
                    </div>
                    <Skeleton className="h-6 w-12" />
                  </div>
                ))}
              </div>
            ) : analytics?.topPerformers.sitters.length ? (
              <div className="space-y-3">
                {analytics.topPerformers.sitters.map((sitter, index) => (
                  <div key={sitter.id} className="flex items-center justify-between p-3 border rounded hover:bg-gray-50">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-village-wine text-white rounded-full flex items-center justify-center text-sm font-bold">
                        {index + 1}
                      </div>
                      <div>
                        <div className="font-medium text-sm">{sitter.name}</div>
                        <div className="flex items-center gap-1">
                          {renderStars(sitter.rating)}
                          <span className="text-xs text-muted-foreground ml-1">
                            {sitter.rating.toFixed(1)}
                          </span>
                        </div>
                      </div>
                    </div>
                    <Badge variant="secondary">
                      {sitter.bookings} bookings
                    </Badge>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center text-muted-foreground py-8">
                No sitter data available
              </div>
            )}
          </CardContent>
        </Card>

        {/* Top Parents by Bookings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Top Parents by Bookings
            </CardTitle>
            <CardDescription>
              Most active parents this month
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-3">
                {Array.from({ length: 5 }).map((_, i) => (
                  <div key={i} className="flex items-center justify-between p-3 border rounded">
                    <div className="flex items-center gap-3">
                      <Skeleton className="h-8 w-8 rounded-full" />
                      <Skeleton className="h-4 w-24" />
                    </div>
                    <Skeleton className="h-6 w-12" />
                  </div>
                ))}
              </div>
            ) : analytics?.topPerformers.parents.length ? (
              <div className="space-y-3">
                {analytics.topPerformers.parents.map((parent, index) => (
                  <div key={parent.id} className="flex items-center justify-between p-3 border rounded hover:bg-gray-50">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-brushed-pink text-village-wine rounded-full flex items-center justify-center text-sm font-bold">
                        {index + 1}
                      </div>
                      <div className="font-medium text-sm">{parent.name}</div>
                    </div>
                    <Badge variant="outline">
                      {parent.bookings} bookings
                    </Badge>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center text-muted-foreground py-8">
                No parent data available
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}