import { useState, useEffect } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Search, X } from 'lucide-react';

interface SearchBarProps {
  onSearch: (term: string) => void;
  placeholder?: string;
  initialValue?: string;
  className?: string;
}

export function SearchBar({ 
  onSearch, 
  placeholder = "Search...", 
  initialValue = "",
  className = ""
}: SearchBarProps) {
  const [searchTerm, setSearchTerm] = useState(initialValue);
  
  // Handle initial value changes (e.g. when clearing filters externally)
  useEffect(() => {
    setSearchTerm(initialValue);
  }, [initialValue]);

  const handleSearch = () => {
    onSearch(searchTerm);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  const handleClear = () => {
    setSearchTerm('');
    onSearch('');
  };

  return (
    <div className={`flex items-center space-x-2 ${className}`}>
      <div className="relative flex-grow">
        <Input
          type="text"
          placeholder={placeholder}
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          onKeyDown={handleKeyDown}
          className="pr-10"
        />
        {searchTerm && (
          <button
            className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
            onClick={handleClear}
            type="button"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>
      <Button onClick={handleSearch} size="sm" variant="default">
        <Search className="h-4 w-4 mr-2" />
        Search
      </Button>
    </div>
  );
}

interface ActiveFiltersProps {
  filters: { key: string; value: string; label: string }[];
  onRemove: (key: string) => void;
  className?: string;
}

export function ActiveFilters({ filters, onRemove, className = "" }: ActiveFiltersProps) {
  if (filters.length === 0) return null;
  
  return (
    <div className={`flex flex-wrap gap-2 ${className}`}>
      {filters.map((filter) => (
        <Badge 
          key={`${filter.key}-${filter.value}`}
          variant="secondary"
          className="px-2 py-1 flex items-center"
        >
          <span className="font-medium mr-1">{filter.label}:</span>
          <span>{filter.value}</span>
          <button
            onClick={() => onRemove(filter.key)}
            className="ml-2 rounded-full hover:bg-muted p-0.5"
          >
            <X className="h-3 w-3" />
          </button>
        </Badge>
      ))}
    </div>
  );
}