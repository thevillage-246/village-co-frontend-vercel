import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Calendar, Clock, User, DollarSign, Shield, AlertTriangle } from "lucide-react";

const bookingSchema = z.object({
  parentId: z.number().min(1, "Please select a parent"),
  sitterId: z.number().min(1, "Please select a sitter"),
  startTime: z.string().min(1, "Start time is required"),
  endTime: z.string().min(1, "End time is required"),
  specialRequests: z.string().optional(),
  sitNotes: z.string().optional(),
  adminNote: z.string().min(10, "Admin note is required (minimum 10 characters)"),
  chargePayment: z.boolean().default(false),
});

type BookingFormData = z.infer<typeof bookingSchema>;

export default function BookOnBehalfOfParent() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedParent, setSelectedParent] = useState<any>(null);
  const [selectedSitter, setSelectedSitter] = useState<any>(null);

  const form = useForm<BookingFormData>({
    resolver: zodResolver(bookingSchema),
    defaultValues: {
      specialRequests: "",
      sitNotes: "",
      adminNote: "",
      chargePayment: false,
    },
  });

  // Fetch parents
  const { data: parents = [] } = useQuery({
    queryKey: ["/api/admin/parents"],
  });

  // Fetch sitters
  const { data: sitters = [] } = useQuery({
    queryKey: ["/api/admin/sitters"],
  });

  // Create booking mutation
  const createBookingMutation = useMutation({
    mutationFn: async (data: BookingFormData) => {
      const response = await apiRequest("POST", "/api/admin/book-on-behalf", data);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Booking Created Successfully",
        description: `Booking #${data.booking.id} has been created and logged for audit.`,
      });
      
      // Reset form
      form.reset();
      setSelectedParent(null);
      setSelectedSitter(null);
      
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ["/api/admin/bookings"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/audit-logs"] });
    },
    onError: (error: any) => {
      toast({
        title: "Booking Creation Failed",
        description: error.message || "An error occurred while creating the booking.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: BookingFormData) => {
    createBookingMutation.mutate(data);
  };

  const calculateEstimatedCost = () => {
    if (!selectedSitter || !form.watch("startTime") || !form.watch("endTime")) {
      return null;
    }

    const startTime = new Date(form.watch("startTime"));
    const endTime = new Date(form.watch("endTime"));
    const hours = (endTime.getTime() - startTime.getTime()) / (1000 * 60 * 60);
    const hourlyRate = selectedSitter.hourlyRate || 25;
    const subtotal = hours * hourlyRate;
    const platformFee = subtotal * 0.10; // 10% platform fee for parents
    const total = subtotal + platformFee;

    return {
      hours: hours.toFixed(1),
      hourlyRate,
      subtotal: subtotal.toFixed(2),
      platformFee: platformFee.toFixed(2),
      total: total.toFixed(2),
    };
  };

  const estimatedCost = calculateEstimatedCost();

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Shield className="h-5 w-5 text-village-wine" />
        <h2 className="text-2xl font-bold">Book on Behalf of Parent</h2>
        <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-300">
          Admin Action
        </Badge>
      </div>

      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
        <div className="flex items-start gap-2">
          <AlertTriangle className="h-5 w-5 text-amber-600 mt-0.5" />
          <div>
            <h3 className="font-medium text-amber-900">Administrative Booking</h3>
            <p className="text-sm text-amber-700 mt-1">
              This action will create a booking on behalf of a parent and will be logged in the audit trail.
              Ensure you have proper authorization before proceeding.
            </p>
          </div>
        </div>
      </div>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Parent Selection */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-4 w-4" />
                  Parent
                </CardTitle>
                <CardDescription>Select the parent for this booking</CardDescription>
              </CardHeader>
              <CardContent>
                <FormField
                  control={form.control}
                  name="parentId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Parent</FormLabel>
                      <Select
                        onValueChange={(value) => {
                          field.onChange(parseInt(value));
                          const parent = parents.find((p: any) => p.id === parseInt(value));
                          setSelectedParent(parent);
                        }}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a parent" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {parents.map((parent: any) => (
                            <SelectItem key={parent.id} value={parent.id.toString()}>
                              {parent.firstName} {parent.lastName} ({parent.email})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {selectedParent && (
                  <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                    <p className="text-sm font-medium">{selectedParent.firstName} {selectedParent.lastName}</p>
                    <p className="text-xs text-gray-600">{selectedParent.email}</p>
                    <p className="text-xs text-gray-600">{selectedParent.phone}</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Sitter Selection */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-4 w-4" />
                  Sitter
                </CardTitle>
                <CardDescription>Select the sitter for this booking</CardDescription>
              </CardHeader>
              <CardContent>
                <FormField
                  control={form.control}
                  name="sitterId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Sitter</FormLabel>
                      <Select
                        onValueChange={(value) => {
                          field.onChange(parseInt(value));
                          const sitter = sitters.find((s: any) => s.id === parseInt(value));
                          setSelectedSitter(sitter);
                        }}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a sitter" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {sitters.map((sitter: any) => (
                            <SelectItem key={sitter.id} value={sitter.id.toString()}>
                              {sitter.firstName} {sitter.lastName} - ${sitter.hourlyRate}/hr
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {selectedSitter && (
                  <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                    <p className="text-sm font-medium">{selectedSitter.firstName} {selectedSitter.lastName}</p>
                    <p className="text-xs text-gray-600">{selectedSitter.email}</p>
                    <p className="text-xs text-gray-600">${selectedSitter.hourlyRate}/hour</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Booking Details */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                Booking Details
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="startTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Start Time</FormLabel>
                      <FormControl>
                        <Input type="datetime-local" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="endTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>End Time</FormLabel>
                      <FormControl>
                        <Input type="datetime-local" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="specialRequests"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Special Requests</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Any special requests or instructions..." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="sitNotes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Sit Notes</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Additional notes for the sitter..." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          {/* Admin Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-4 w-4" />
                Admin Information
              </CardTitle>
              <CardDescription>Required for audit trail</CardDescription>
            </CardHeader>
            <CardContent>
              <FormField
                control={form.control}
                name="adminNote"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Admin Note *</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Reason for creating this booking on behalf of the parent..." 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
          </Card>

          {/* Cost Estimate */}
          {estimatedCost && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <DollarSign className="h-4 w-4" />
                  Estimated Cost
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Duration:</span>
                    <span>{estimatedCost.hours} hours</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Hourly Rate:</span>
                    <span>${estimatedCost.hourlyRate}/hour</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <span>${estimatedCost.subtotal}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Platform Fee (10%):</span>
                    <span>${estimatedCost.platformFee}</span>
                  </div>
                  <div className="flex justify-between font-bold border-t pt-2">
                    <span>Total:</span>
                    <span>${estimatedCost.total}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          <Button 
            type="submit" 
            className="w-full bg-village-wine hover:bg-village-wine/90"
            disabled={createBookingMutation.isPending}
          >
            {createBookingMutation.isPending ? "Creating Booking..." : "Create Admin Booking"}
          </Button>
        </form>
      </Form>
    </div>
  );
}