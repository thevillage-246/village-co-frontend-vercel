import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuery } from "@tanstack/react-query";
import { Trophy, TrendingUp, Users, DollarSign, Calendar, RefreshCw } from "lucide-react";
import { format } from "date-fns";

interface LeaderboardEntry {
  sitterId: number;
  sitterName: string;
  totalRebookings: number;
  totalEarnings: string;
  lastRebookingAt: string;
}

interface RebookingStats {
  month: string;
  totalRebookings: number;
  totalEarnings: string;
  topSitters: any[];
  allStats: any[];
  leaderboard: LeaderboardEntry[];
}

export default function RebookingLeaderboard() {
  const [selectedMonth, setSelectedMonth] = useState(() => {
    return new Date().toISOString().slice(0, 7); // Current month YYYY-MM
  });

  // Generate month options for the last 12 months
  const monthOptions = Array.from({ length: 12 }, (_, i) => {
    const date = new Date();
    date.setMonth(date.getMonth() - i);
    const value = date.toISOString().slice(0, 7);
    const label = format(date, "MMMM yyyy");
    return { value, label };
  });

  // Fetch rebooking statistics
  const { data: stats, isLoading, refetch } = useQuery<RebookingStats>({
    queryKey: ["/api/admin/rebooking/stats", selectedMonth],
    queryFn: () => fetch(`/api/admin/rebooking/stats?month=${selectedMonth}`).then(res => res.json()),
  });

  // Fetch leaderboard
  const { data: leaderboardData } = useQuery({
    queryKey: ["/api/admin/rebooking/leaderboard", selectedMonth],
    queryFn: () => fetch(`/api/admin/rebooking/leaderboard?month=${selectedMonth}&limit=10`).then(res => res.json()),
  });

  const leaderboard = leaderboardData?.leaderboard || [];

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="h-5 w-5" />
            Most Rebooked Sitters This Month
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-8">
            <RefreshCw className="h-6 w-6 animate-spin text-gray-400" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header with Month Selection */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="h-5 w-5 text-[#6b3e4b]" />
                Rebooking Analytics
              </CardTitle>
              <CardDescription>
                Track sitter rebooking performance and platform retention metrics
              </CardDescription>
            </div>
            <div className="flex items-center gap-3">
              <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {monthOptions.map(({ value, label }) => (
                    <SelectItem key={value} value={value}>
                      {label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button
                variant="outline"
                size="sm"
                onClick={() => refetch()}
                className="shrink-0"
              >
                <RefreshCw className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>

        {/* Summary Stats */}
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-gradient-to-r from-[#6b3e4b]/10 to-[#ebd3cb]/20 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <RefreshCw className="h-4 w-4 text-[#6b3e4b]" />
                <span className="text-sm font-medium text-gray-600">Total Rebookings</span>
              </div>
              <div className="text-2xl font-bold text-[#6b3e4b]">
                {stats?.totalRebookings || 0}
              </div>
            </div>

            <div className="bg-gradient-to-r from-green-50 to-green-100 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <DollarSign className="h-4 w-4 text-green-600" />
                <span className="text-sm font-medium text-gray-600">Revenue Generated</span>
              </div>
              <div className="text-2xl font-bold text-green-600">
                ${parseFloat(stats?.totalEarnings || "0").toFixed(0)}
              </div>
            </div>

            <div className="bg-gradient-to-r from-blue-50 to-blue-100 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Users className="h-4 w-4 text-blue-600" />
                <span className="text-sm font-medium text-gray-600">Active Sitters</span>
              </div>
              <div className="text-2xl font-bold text-blue-600">
                {leaderboard.length}
              </div>
            </div>

            <div className="bg-gradient-to-r from-purple-50 to-purple-100 p-4 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="h-4 w-4 text-purple-600" />
                <span className="text-sm font-medium text-gray-600">Avg per Sitter</span>
              </div>
              <div className="text-2xl font-bold text-purple-600">
                {leaderboard.length > 0 
                  ? Math.round((stats?.totalRebookings || 0) / leaderboard.length)
                  : 0
                }
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Leaderboard */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="h-5 w-5 text-[#6b3e4b]" />
            Most Rebooked Sitters - {format(new Date(selectedMonth + "-01"), "MMMM yyyy")}
          </CardTitle>
          <CardDescription>
            Top performing sitters based on repeat bookings from satisfied families
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          {leaderboard.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Users className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p>No rebooking data for this month yet.</p>
              <p className="text-sm">Check back after families start rebooking their favorite sitters!</p>
            </div>
          ) : (
            <div className="space-y-3">
              {leaderboard.map((entry, index) => (
                <div
                  key={entry.sitterId}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    index === 0
                      ? "border-yellow-300 bg-gradient-to-r from-yellow-50 to-yellow-100"
                      : index === 1
                      ? "border-gray-300 bg-gradient-to-r from-gray-50 to-gray-100"
                      : index === 2
                      ? "border-orange-300 bg-gradient-to-r from-orange-50 to-orange-100"
                      : "border-gray-200 bg-gray-50"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      {/* Rank Badge */}
                      <div className={`flex items-center justify-center w-10 h-10 rounded-full font-bold ${
                        index === 0
                          ? "bg-yellow-400 text-yellow-900"
                          : index === 1
                          ? "bg-gray-400 text-gray-900"
                          : index === 2
                          ? "bg-orange-400 text-orange-900"
                          : "bg-gray-300 text-gray-700"
                      }`}>
                        {index < 3 ? (
                          <Trophy className="h-5 w-5" />
                        ) : (
                          <span>#{index + 1}</span>
                        )}
                      </div>

                      {/* Sitter Info */}
                      <div>
                        <h4 className="font-semibold text-gray-900">
                          {entry.sitterName}
                        </h4>
                        <p className="text-sm text-gray-600">
                          Last rebooking: {format(new Date(entry.lastRebookingAt), "MMM d, yyyy")}
                        </p>
                      </div>
                    </div>

                    {/* Stats */}
                    <div className="flex items-center gap-6">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-[#6b3e4b]">
                          {entry.totalRebookings}
                        </div>
                        <div className="text-xs text-gray-500">Rebookings</div>
                      </div>
                      
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-600">
                          ${parseFloat(entry.totalEarnings).toFixed(0)}
                        </div>
                        <div className="text-xs text-gray-500">Earnings</div>
                      </div>

                      {index < 3 && (
                        <Badge 
                          variant="outline" 
                          className={
                            index === 0
                              ? "bg-yellow-100 text-yellow-800 border-yellow-300"
                              : index === 1
                              ? "bg-gray-100 text-gray-800 border-gray-300"
                              : "bg-orange-100 text-orange-800 border-orange-300"
                          }
                        >
                          {index === 0 ? "🥇 Champion" : index === 1 ? "🥈 Runner-up" : "🥉 Third Place"}
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}