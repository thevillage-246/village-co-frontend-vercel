import { useState, useEffect } from 'react';
import { SearchBar, ActiveFilters } from './SearchBar';
import { FilterDropdown, SortDropdown, type FilterOption } from './FilterControls';
import { Button } from '@/components/ui/button';
import { RotateCcw } from 'lucide-react';

export interface SearchAndFilterState {
  searchTerm: string;
  filters: {
    [key: string]: any;
  };
  sortBy: string;
}

interface SearchAndFilterBarProps {
  initialState: SearchAndFilterState;
  onStateChange: (state: SearchAndFilterState) => void;
  filterOptions: FilterOption[];
  sortOptions: { value: string; label: string }[];
  className?: string;
}

export function SearchAndFilterBar({
  initialState,
  onStateChange,
  filterOptions,
  sortOptions,
  className = "",
}: SearchAndFilterBarProps) {
  const [state, setState] = useState<SearchAndFilterState>(initialState);
  
  const handleSearchChange = (searchTerm: string) => {
    const newState = { ...state, searchTerm };
    setState(newState);
    onStateChange(newState);
  };

  const handleFilterChange = (key: string, value: any) => {
    // Handle range filters differently
    if (key.includes('.')) {
      const [baseKey, subKey] = key.split('.');
      const newState = { 
        ...state, 
        filters: { 
          ...state.filters, 
          [baseKey]: { 
            ...state.filters[baseKey],
            [subKey]: value 
          } 
        } 
      };
      setState(newState);
      onStateChange(newState);
      return;
    }

    // Handle regular filters
    const newState = { 
      ...state, 
      filters: { ...state.filters, [key]: value } 
    };
    setState(newState);
    onStateChange(newState);
  };

  const handleSortChange = (sortBy: string) => {
    const newState = { ...state, sortBy };
    setState(newState);
    onStateChange(newState);
  };

  const handleRemoveFilter = (key: string) => {
    const newFilters = { ...state.filters };
    delete newFilters[key];
    const newState = { ...state, filters: newFilters };
    setState(newState);
    onStateChange(newState);
  };

  const handleResetAll = () => {
    const resetState = {
      searchTerm: '',
      filters: {},
      sortBy: sortOptions[0]?.value || 'default',
    };
    setState(resetState);
    onStateChange(resetState);
  };

  // Generate active filters for display
  const activeFilters = Object.entries(state.filters).map(([key, value]) => {
    // Find the matching filter option to get the label
    const filterOption = filterOptions.find(option => option.key === key);
    if (!filterOption) return null;

    if (filterOption.type === 'checkbox' && Array.isArray(value)) {
      // For checkbox filters with multiple values
      return value.map(val => {
        const option = filterOption.options.find(opt => opt.value === val);
        return {
          key,
          value: val,
          label: `${filterOption.label}: ${option?.label || val}`
        };
      });
    } else if (filterOption.type === 'radio' && value) {
      // For radio filters with a single value
      const option = filterOption.options.find(opt => opt.value === value);
      return {
        key,
        value,
        label: filterOption.label
      };
    } else if (filterOption.type === 'range' && typeof value === 'object') {
      // For range filters with min/max values
      const filters = [];
      if (value.min !== null && value.min !== undefined) {
        filters.push({
          key: `${key}.min`,
          value: `Min: ${value.min}${filterOption.unit || ''}`,
          label: filterOption.label
        });
      }
      if (value.max !== null && value.max !== undefined) {
        filters.push({
          key: `${key}.max`,
          value: `Max: ${value.max}${filterOption.unit || ''}`,
          label: filterOption.label
        });
      }
      return filters;
    }
    return null;
  })
  .flat()
  .filter(Boolean) as { key: string; value: string; label: string }[];

  // Keep internal state synchronized with external initialState
  useEffect(() => {
    setState(initialState);
  }, [initialState]);

  return (
    <div className={`space-y-4 ${className}`}>
      <div className="flex flex-col sm:flex-row gap-4">
        <SearchBar
          onSearch={handleSearchChange}
          initialValue={state.searchTerm}
          placeholder="Search..."
          className="flex-grow"
        />
        <div className="flex gap-2">
          <FilterDropdown
            filters={filterOptions}
            onFilterChange={handleFilterChange}
          />
          <SortDropdown
            options={sortOptions}
            selectedOption={state.sortBy}
            onSortChange={handleSortChange}
          />
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleResetAll}
            className="hidden sm:flex"
          >
            <RotateCcw className="h-4 w-4 mr-2" />
            Reset
          </Button>
        </div>
      </div>
      
      <div className="flex flex-wrap justify-between items-center gap-2">
        <ActiveFilters
          filters={activeFilters}
          onRemove={handleRemoveFilter}
          className="flex-grow"
        />
        {(activeFilters.length > 0 || state.searchTerm) && (
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={handleResetAll}
            className="sm:hidden"
          >
            <RotateCcw className="h-4 w-4 mr-2" />
            Reset All
          </Button>
        )}
      </div>
    </div>
  );
}