import { useState } from 'react';
import { Check, ChevronDown, Filter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Separator } from '@/components/ui/separator';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';

// For options that can have multiple selections
export interface CheckboxFilterOption {
  type: 'checkbox';
  key: string;
  label: string;
  options: { value: string; label: string }[];
  selectedValues: string[];
}

// For options that can only have a single selection
export interface RadioFilterOption {
  type: 'radio';
  key: string;
  label: string;
  options: { value: string; label: string }[];
  selectedValue: string | null;
}

// For options that use a range (e.g., date ranges, numerical ranges)
export interface RangeFilterOption {
  type: 'range';
  key: string;
  label: string;
  minValue: number | null;
  maxValue: number | null;
  unit?: string;
}

export type FilterOption = CheckboxFilterOption | RadioFilterOption | RangeFilterOption;

interface FilterDropdownProps {
  filters: FilterOption[];
  onFilterChange: (key: string, value: any) => void;
  className?: string;
}

export function FilterDropdown({ filters, onFilterChange, className = "" }: FilterDropdownProps) {
  const hasActiveFilters = filters.some((filter) => {
    if (filter.type === 'checkbox') return filter.selectedValues.length > 0;
    if (filter.type === 'radio') return filter.selectedValue !== null;
    if (filter.type === 'range') return filter.minValue !== null || filter.maxValue !== null;
    return false;
  });

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button 
          variant={hasActiveFilters ? "default" : "outline"} 
          size="sm"
          className={className}
        >
          <Filter className="h-4 w-4 mr-2" />
          Filter
          {hasActiveFilters && (
            <span className="ml-1 rounded-full bg-primary-foreground text-primary w-5 h-5 flex items-center justify-center text-xs">
              {countActiveFilters(filters)}
            </span>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-56" align="start">
        <DropdownMenuLabel>Filter By</DropdownMenuLabel>
        <DropdownMenuSeparator />
        
        {filters.map((filter, index) => (
          <div key={filter.key}>
            {index > 0 && <DropdownMenuSeparator />}
            
            <DropdownMenuLabel className="text-xs font-medium text-muted-foreground pl-2">
              {filter.label}
            </DropdownMenuLabel>
            
            {filter.type === 'checkbox' && (
              <>
                {filter.options.map((option) => (
                  <DropdownMenuCheckboxItem
                    key={option.value}
                    checked={filter.selectedValues.includes(option.value)}
                    onCheckedChange={(checked) => {
                      const newSelectedValues = checked
                        ? [...filter.selectedValues, option.value]
                        : filter.selectedValues.filter((val) => val !== option.value);
                      onFilterChange(filter.key, newSelectedValues);
                    }}
                  >
                    {option.label}
                  </DropdownMenuCheckboxItem>
                ))}
              </>
            )}
            
            {filter.type === 'radio' && (
              <DropdownMenuRadioGroup
                value={filter.selectedValue || ""}
                onValueChange={(value) => {
                  onFilterChange(filter.key, value === "" ? null : value);
                }}
              >
                <DropdownMenuRadioItem value="">All</DropdownMenuRadioItem>
                {filter.options.map((option) => (
                  <DropdownMenuRadioItem key={option.value} value={option.value}>
                    {option.label}
                  </DropdownMenuRadioItem>
                ))}
              </DropdownMenuRadioGroup>
            )}
            
            {filter.type === 'range' && (
              <div className="px-2 py-1.5">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs">Min:</span>
                  <input
                    type="number"
                    className="w-20 h-7 rounded border px-2 text-sm"
                    value={filter.minValue || ""}
                    onChange={(e) => {
                      const value = e.target.value === "" ? null : Number(e.target.value);
                      onFilterChange(`${filter.key}.min`, value);
                    }}
                    placeholder="Min"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs">Max:</span>
                  <input
                    type="number"
                    className="w-20 h-7 rounded border px-2 text-sm"
                    value={filter.maxValue || ""}
                    onChange={(e) => {
                      const value = e.target.value === "" ? null : Number(e.target.value);
                      onFilterChange(`${filter.key}.max`, value);
                    }}
                    placeholder="Max"
                  />
                </div>
              </div>
            )}
          </div>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

function countActiveFilters(filters: FilterOption[]): number {
  return filters.reduce((count, filter) => {
    if (filter.type === 'checkbox') {
      return count + filter.selectedValues.length;
    }
    if (filter.type === 'radio' && filter.selectedValue !== null) {
      return count + 1;
    }
    if (filter.type === 'range') {
      return count + (filter.minValue !== null ? 1 : 0) + (filter.maxValue !== null ? 1 : 0);
    }
    return count;
  }, 0);
}

interface SortDropdownProps {
  options: { value: string; label: string }[];
  selectedOption: string;
  onSortChange: (value: string) => void;
  className?: string;
}

export function SortDropdown({ 
  options, 
  selectedOption, 
  onSortChange,
  className = ""
}: SortDropdownProps) {
  return (
    <Select value={selectedOption} onValueChange={onSortChange}>
      <SelectTrigger className={`w-[180px] ${className}`}>
        <SelectValue placeholder="Sort by" />
      </SelectTrigger>
      <SelectContent>
        {options.map((option) => (
          <SelectItem key={option.value} value={option.value}>
            {option.label}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}