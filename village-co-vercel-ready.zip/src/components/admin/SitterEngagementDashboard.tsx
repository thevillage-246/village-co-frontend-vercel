import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  Star, 
  MessageSquare, 
  Calendar, 
  TrendingUp, 
  TrendingDown,
  AlertTriangle,
  CheckCircle,
  Clock,
  Users,
  Activity,
  Mail,
  Phone
} from 'lucide-react';
import { format, subDays, differenceInDays } from 'date-fns';

interface SitterEngagementData {
  id: number;
  userId: number;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  photoUrl?: string;
  badge?: string;
  lastLogin?: string;
  totalBookings: number;
  completedBookings: number;
  responseRate: number;
  approvalRate: number;
  averageRating: number;
  reviewCount: number;
  messageCount: number;
  engagementScore: number;
  status: 'high_performer' | 'under_engaged' | 'inactive' | 'new';
  joinDate: string;
  hourlyRate: number;
  isActive: boolean;
  lastBookingDate?: string;
  profileCompleteness: number;
  verificationStatus: 'verified' | 'pending' | 'rejected';
}

interface EngagementMetrics {
  totalSitters: number;
  highPerformers: number;
  underEngaged: number;
  inactive: number;
  averageResponseRate: number;
  averageApprovalRate: number;
  totalBookings: number;
  averageRating: number;
}

export default function SitterEngagementDashboard() {
  const [timeRange, setTimeRange] = useState('30'); // days
  const [sortBy, setSortBy] = useState('engagementScore');
  const [filterStatus, setFilterStatus] = useState('all');

  const { data: sitterEngagement, isLoading } = useQuery<{
    sitters: SitterEngagementData[];
    metrics: EngagementMetrics;
  }>({
    queryKey: ['/api/admin/sitter-engagement', timeRange],
    enabled: true,
  });

  const filteredSitters = sitterEngagement?.sitters?.filter(sitter => {
    if (filterStatus === 'all') return true;
    return sitter.status === filterStatus;
  }) || [];

  const sortedSitters = [...filteredSitters].sort((a, b) => {
    switch (sortBy) {
      case 'engagementScore':
        return b.engagementScore - a.engagementScore;
      case 'bookings':
        return b.totalBookings - a.totalBookings;
      case 'responseRate':
        return b.responseRate - a.responseRate;
      case 'lastLogin':
        return new Date(b.lastLogin || 0).getTime() - new Date(a.lastLogin || 0).getTime();
      default:
        return 0;
    }
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'high_performer':
        return <Badge className="bg-green-100 text-green-800 border-green-200">⭐ High Performer</Badge>;
      case 'under_engaged':
        return <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200">🟡 Under-engaged</Badge>;
      case 'inactive':
        return <Badge className="bg-red-100 text-red-800 border-red-200">🔴 Inactive</Badge>;
      case 'new':
        return <Badge className="bg-blue-100 text-blue-800 border-blue-200">🆕 New</Badge>;
      default:
        return <Badge variant="secondary">Unknown</Badge>;
    }
  };

  const getEngagementColor = (score: number) => {
    if (score >= 80) return 'bg-green-500';
    if (score >= 60) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const getDaysInactive = (lastLogin?: string) => {
    if (!lastLogin) return 'Never';
    const days = differenceInDays(new Date(), new Date(lastLogin));
    if (days === 0) return 'Today';
    if (days === 1) return 'Yesterday';
    return `${days} days ago`;
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-6 bg-gray-200 rounded w-1/2"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Metrics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Sitters</p>
                <p className="text-2xl font-bold">{sitterEngagement?.metrics?.totalSitters || 0}</p>
              </div>
              <Users className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">High Performers</p>
                <p className="text-2xl font-bold text-green-600">{sitterEngagement?.metrics?.highPerformers || 0}</p>
              </div>
              <Star className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Under-engaged</p>
                <p className="text-2xl font-bold text-yellow-600">{sitterEngagement?.metrics?.underEngaged || 0}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Inactive</p>
                <p className="text-2xl font-bold text-red-600">{sitterEngagement?.metrics?.inactive || 0}</p>
              </div>
              <TrendingDown className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters and Controls */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
        <div className="flex gap-2">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7">Last 7 days</SelectItem>
              <SelectItem value="30">Last 30 days</SelectItem>
              <SelectItem value="90">Last 3 months</SelectItem>
              <SelectItem value="365">Last year</SelectItem>
            </SelectContent>
          </Select>

          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Sitters</SelectItem>
              <SelectItem value="high_performer">High Performers</SelectItem>
              <SelectItem value="under_engaged">Under-engaged</SelectItem>
              <SelectItem value="inactive">Inactive</SelectItem>
              <SelectItem value="new">New</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Select value={sortBy} onValueChange={setSortBy}>
          <SelectTrigger className="w-48">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="engagementScore">Engagement Score</SelectItem>
            <SelectItem value="bookings">Total Bookings</SelectItem>
            <SelectItem value="responseRate">Response Rate</SelectItem>
            <SelectItem value="lastLogin">Last Login</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Sitter Engagement Table */}
      <Card>
        <CardHeader>
          <CardTitle>Sitter Performance Analytics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Sitter</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Engagement Score</TableHead>
                  <TableHead>Bookings</TableHead>
                  <TableHead>Response Rate</TableHead>
                  <TableHead>Approval Rate</TableHead>
                  <TableHead>Rating</TableHead>
                  <TableHead>Last Login</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sortedSitters.map((sitter) => (
                  <TableRow key={sitter.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarImage src={sitter.photoUrl} />
                          <AvatarFallback>
                            {sitter.firstName?.[0]}{sitter.lastName?.[0]}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{sitter.firstName} {sitter.lastName}</p>
                          <p className="text-sm text-gray-500">{sitter.email}</p>
                          {sitter.badge && (
                            <Badge variant="secondary" className="text-xs mt-1">
                              {sitter.badge}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      {getStatusBadge(sitter.status)}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Progress 
                          value={sitter.engagementScore} 
                          className="w-16 h-2"
                          indicatorClassName={getEngagementColor(sitter.engagementScore)}
                        />
                        <span className="text-sm font-medium">{sitter.engagementScore}%</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-center">
                        <p className="font-medium">{sitter.totalBookings}</p>
                        <p className="text-xs text-gray-500">
                          {sitter.completedBookings} completed
                        </p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <MessageSquare className="h-4 w-4 text-gray-400" />
                        <span>{sitter.responseRate}%</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <CheckCircle className="h-4 w-4 text-gray-400" />
                        <span>{sitter.approvalRate}%</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 text-yellow-500" />
                        <span>{sitter.averageRating.toFixed(1)}</span>
                        <span className="text-xs text-gray-500">({sitter.reviewCount})</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        {getDaysInactive(sitter.lastLogin)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Button size="sm" variant="outline">
                          <Mail className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Phone className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}