import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Progress } from '@/components/ui/progress';
import { 
  MapPin, 
  TrendingUp, 
  Clock, 
  AlertTriangle, 
  CheckCircle,
  Users,
  Calendar,
  DollarSign,
  Target,
  Activity,
  BarChart3
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';

interface SuburbDemandData {
  suburb: string;
  coordinates: [number, number];
  totalBookings: number;
  totalSearches: number;
  availableSitters: number;
  demandScore: number;
  averageHourlyRate: number;
  peakHours: string[];
  conversionRate: number; // searches to bookings
  supplyDemandRatio: number;
  gapSeverity: 'high' | 'medium' | 'low' | 'oversupplied';
  recentTrend: 'increasing' | 'stable' | 'decreasing';
  parentCount: number;
  lastBookingDate?: string;
}

interface TimeSlotDemand {
  timeSlot: string;
  hour: number;
  bookingCount: number;
  searchCount: number;
  dayOfWeek: string;
  averageRate: number;
  successRate: number;
}

interface DemandMetrics {
  totalSuburbs: number;
  highDemandAreas: number;
  supplyGaps: number;
  averageConversionRate: number;
  peakBookingHour: string;
  totalBookings: number;
  totalSearches: number;
  averageSupplyDemandRatio: number;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

export default function DemandHeatmapDashboard() {
  const [timeRange, setTimeRange] = useState('30');
  const [selectedSuburb, setSelectedSuburb] = useState('all');
  const [viewMode, setViewMode] = useState<'heatmap' | 'analytics'>('analytics');

  const { data: demandData, isLoading } = useQuery<{
    suburbs: SuburbDemandData[];
    timeSlots: TimeSlotDemand[];
    metrics: DemandMetrics;
  }>({
    queryKey: ['/api/admin/demand-analytics', timeRange],
    enabled: true,
  });

  const getGapSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high':
        return 'bg-red-500';
      case 'medium':
        return 'bg-yellow-500';
      case 'low':
        return 'bg-green-500';
      case 'oversupplied':
        return 'bg-blue-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getGapSeverityBadge = (severity: string) => {
    switch (severity) {
      case 'high':
        return <Badge className="bg-red-100 text-red-800 border-red-200">🔴 Critical Gap</Badge>;
      case 'medium':
        return <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200">🟡 Supply Gap</Badge>;
      case 'low':
        return <Badge className="bg-green-100 text-green-800 border-green-200">🟢 Balanced</Badge>;
      case 'oversupplied':
        return <Badge className="bg-blue-100 text-blue-800 border-blue-200">📈 Oversupplied</Badge>;
      default:
        return <Badge variant="secondary">Unknown</Badge>;
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'increasing':
        return <TrendingUp className="h-4 w-4 text-green-500" />;
      case 'decreasing':
        return <TrendingUp className="h-4 w-4 text-red-500 rotate-180" />;
      default:
        return <Activity className="h-4 w-4 text-gray-500" />;
    }
  };

  // Group time slots by day for better visualization
  const timeSlotsByDay = demandData?.timeSlots?.reduce((acc, slot) => {
    if (!acc[slot.dayOfWeek]) acc[slot.dayOfWeek] = [];
    acc[slot.dayOfWeek].push(slot);
    return acc;
  }, {} as Record<string, TimeSlotDemand[]>) || {};

  // Top booking hours chart data
  const topHoursData = demandData?.timeSlots
    ?.sort((a, b) => b.bookingCount - a.bookingCount)
    ?.slice(0, 12)
    ?.map(slot => ({
      hour: slot.timeSlot,
      bookings: slot.bookingCount,
      searches: slot.searchCount,
      successRate: slot.successRate
    })) || [];

  // Suburb demand distribution for pie chart
  const suburbDistribution = demandData?.suburbs
    ?.sort((a, b) => b.totalBookings - a.totalBookings)
    ?.slice(0, 6)
    ?.map(suburb => ({
      name: suburb.suburb,
      value: suburb.totalBookings,
      percentage: ((suburb.totalBookings / (demandData.metrics?.totalBookings || 1)) * 100).toFixed(1)
    })) || [];

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-6 bg-gray-200 rounded w-1/2"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Demand Metrics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Bookings</p>
                <p className="text-2xl font-bold">{demandData?.metrics?.totalBookings || 0}</p>
              </div>
              <Calendar className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Supply Gaps</p>
                <p className="text-2xl font-bold text-red-600">{demandData?.metrics?.supplyGaps || 0}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Conversion Rate</p>
                <p className="text-2xl font-bold text-green-600">
                  {demandData?.metrics?.averageConversionRate || 0}%
                </p>
              </div>
              <Target className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Peak Hour</p>
                <p className="text-2xl font-bold">{demandData?.metrics?.peakBookingHour || 'N/A'}</p>
              </div>
              <Clock className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Controls */}
      <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
        <div className="flex gap-2">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7">Last 7 days</SelectItem>
              <SelectItem value="30">Last 30 days</SelectItem>
              <SelectItem value="90">Last 3 months</SelectItem>
            </SelectContent>
          </Select>

          <Select value={selectedSuburb} onValueChange={setSelectedSuburb}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Suburbs</SelectItem>
              {demandData?.suburbs?.map(suburb => (
                <SelectItem key={suburb.suburb} value={suburb.suburb}>
                  {suburb.suburb}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <Tabs value={viewMode} onValueChange={setViewMode as any}>
          <TabsList>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="heatmap">Geographic View</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <Tabs value={viewMode} className="w-full">
        <TabsContent value="analytics" className="space-y-6">
          {/* Charts Section */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Top Booking Hours */}
            <Card>
              <CardHeader>
                <CardTitle>Peak Booking Hours</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={topHoursData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="hour" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="bookings" fill="#3B82F6" name="Bookings" />
                    <Bar dataKey="searches" fill="#EAB308" name="Searches" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Suburb Distribution */}
            <Card>
              <CardHeader>
                <CardTitle>Booking Distribution by Suburb</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={suburbDistribution}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={120}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {suburbDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip formatter={(value, name) => [`${value} bookings`, name]} />
                  </PieChart>
                </ResponsiveContainer>
                <div className="mt-4 space-y-1">
                  {suburbDistribution.map((entry, index) => (
                    <div key={entry.name} className="flex items-center justify-between text-sm">
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-3 h-3 rounded-full" 
                          style={{ backgroundColor: COLORS[index % COLORS.length] }}
                        />
                        <span>{entry.name}</span>
                      </div>
                      <span className="font-medium">{entry.percentage}%</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Suburb Analysis Table */}
          <Card>
            <CardHeader>
              <CardTitle>Suburb Demand Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Suburb</TableHead>
                      <TableHead>Gap Status</TableHead>
                      <TableHead>Demand Score</TableHead>
                      <TableHead>Bookings</TableHead>
                      <TableHead>Searches</TableHead>
                      <TableHead>Available Sitters</TableHead>
                      <TableHead>Conversion Rate</TableHead>
                      <TableHead>Trend</TableHead>
                      <TableHead>Avg. Rate</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {demandData?.suburbs
                      ?.sort((a, b) => b.demandScore - a.demandScore)
                      ?.map((suburb) => (
                        <TableRow key={suburb.suburb}>
                          <TableCell className="font-medium">
                            <div className="flex items-center gap-2">
                              <MapPin className="h-4 w-4 text-gray-400" />
                              {suburb.suburb}
                            </div>
                            <div className="text-xs text-gray-500 mt-1">
                              {suburb.parentCount} families
                            </div>
                          </TableCell>
                          <TableCell>
                            {getGapSeverityBadge(suburb.gapSeverity)}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Progress 
                                value={suburb.demandScore} 
                                className="w-16 h-2"
                                indicatorClassName={getGapSeverityColor(suburb.gapSeverity)}
                              />
                              <span className="text-sm font-medium">{suburb.demandScore}</span>
                            </div>
                          </TableCell>
                          <TableCell className="text-center font-medium">
                            {suburb.totalBookings}
                          </TableCell>
                          <TableCell className="text-center">
                            {suburb.totalSearches}
                          </TableCell>
                          <TableCell className="text-center">
                            <div className="flex items-center gap-1">
                              <Users className="h-4 w-4 text-gray-400" />
                              {suburb.availableSitters}
                            </div>
                          </TableCell>
                          <TableCell>
                            <span className={`font-medium ${
                              suburb.conversionRate >= 70 ? 'text-green-600' :
                              suburb.conversionRate >= 50 ? 'text-yellow-600' : 'text-red-600'
                            }`}>
                              {suburb.conversionRate}%
                            </span>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1">
                              {getTrendIcon(suburb.recentTrend)}
                              <span className="text-sm capitalize">{suburb.recentTrend}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-1">
                              <DollarSign className="h-4 w-4 text-gray-400" />
                              ${suburb.averageHourlyRate}/hr
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="heatmap" className="space-y-6">
          {/* Geographic Heatmap Placeholder */}
          <Card>
            <CardHeader>
              <CardTitle>Geographic Demand Heatmap</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-96 bg-gray-100 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <MapPin className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-lg font-medium text-gray-600">Interactive Heatmap</p>
                  <p className="text-sm text-gray-500 mt-2">
                    Geographic visualization of booking density and sitter coverage gaps
                  </p>
                  <Button className="mt-4">
                    Enable Google Maps Integration
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Coverage Gaps Summary */}
          <Card>
            <CardHeader>
              <CardTitle>Coverage Gap Priorities</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {demandData?.suburbs
                  ?.filter(suburb => suburb.gapSeverity === 'high' || suburb.gapSeverity === 'medium')
                  ?.sort((a, b) => b.demandScore - a.demandScore)
                  ?.map((suburb) => (
                    <div key={suburb.suburb} className="p-4 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium">{suburb.suburb}</h4>
                        {getGapSeverityBadge(suburb.gapSeverity)}
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <p className="text-gray-600">Searches</p>
                          <p className="font-medium">{suburb.totalSearches}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Bookings</p>
                          <p className="font-medium">{suburb.totalBookings}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Available Sitters</p>
                          <p className="font-medium">{suburb.availableSitters}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Success Rate</p>
                          <p className="font-medium">{suburb.conversionRate}%</p>
                        </div>
                      </div>
                      <div className="mt-3 flex gap-2">
                        <Button size="sm" variant="outline">
                          Recruit Sitters
                        </Button>
                        <Button size="sm" variant="outline">
                          Boost Marketing
                        </Button>
                      </div>
                    </div>
                  ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}