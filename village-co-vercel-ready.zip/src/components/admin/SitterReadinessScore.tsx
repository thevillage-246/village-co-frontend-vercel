import React from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { apiRequest } from "@/lib/queryClient";
import { CheckCircle2, AlertCircle, X, Clock, ShieldCheck, Medal, FileCheck, PhoneCall } from "lucide-react";

interface SitterReadinessScoreProps {
  filter?: "all" | "pending" | "complete" | "atRisk";
}

interface SitterReadiness {
  id: number;
  userId: number;
  firstName: string;
  lastName: string;
  profileImage?: string;
  email: string;
  phone?: string;
  signupDate: string;
  steps: {
    accountCreation: boolean;
    profileComplete: boolean;
    valuesQuizComplete: boolean;
    backgroundCheck: boolean;
    firstAidCert: boolean;
    referencesSubmitted: boolean;
    identityVerified: boolean;
    trainingComplete: boolean;
  };
  score: number; // Percentage complete
}

export default function SitterReadinessScore({ filter = "all" }: SitterReadinessScoreProps) {
  const [currentTab, setCurrentTab] = React.useState<string>(filter);

  const { data: sitters, isLoading } = useQuery({
    queryKey: ['/api/admin/sitters/readiness'],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/admin/sitters/readiness");
      return response.json();
    },
  });

  // Filter sitters based on the selected tab
  const filteredSitters = React.useMemo(() => {
    if (!sitters) return [];
    
    switch (currentTab) {
      case "pending":
        return sitters.filter((sitter: SitterReadiness) => sitter.score > 0 && sitter.score < 100);
      case "complete":
        return sitters.filter((sitter: SitterReadiness) => sitter.score === 100);
      case "atRisk":
        // At risk: Started onboarding more than 7 days ago but not completed
        return sitters.filter((sitter: SitterReadiness) => {
          const signupDate = new Date(sitter.signupDate);
          const daysSinceSignup = Math.floor((Date.now() - signupDate.getTime()) / (1000 * 60 * 60 * 24));
          return daysSinceSignup > 7 && sitter.score < 100;
        });
      default:
        return sitters;
    }
  }, [sitters, currentTab]);

  // Get counts for the badges
  const getCounts = () => {
    if (!sitters) return { all: 0, pending: 0, complete: 0, atRisk: 0 };
    
    const pendingCount = sitters.filter(
      (sitter: SitterReadiness) => sitter.score > 0 && sitter.score < 100
    ).length;
    
    const completeCount = sitters.filter(
      (sitter: SitterReadiness) => sitter.score === 100
    ).length;
    
    const atRiskCount = sitters.filter((sitter: SitterReadiness) => {
      const signupDate = new Date(sitter.signupDate);
      const daysSinceSignup = Math.floor((Date.now() - signupDate.getTime()) / (1000 * 60 * 60 * 24));
      return daysSinceSignup > 7 && sitter.score < 100;
    }).length;
    
    return {
      all: sitters.length,
      pending: pendingCount,
      complete: completeCount,
      atRisk: atRiskCount,
    };
  };

  const counts = getCounts();

  const getInitials = (firstName: string, lastName: string) => {
    return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase();
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600";
    if (score >= 50) return "text-amber-600";
    return "text-red-600";
  };

  const getStatusIcon = (completed: boolean) => {
    return completed ? (
      <CheckCircle2 className="h-4 w-4 text-green-600" />
    ) : (
      <X className="h-4 w-4 text-slate-400" />
    );
  };
  
  // Format date to a readable string
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-xl font-semibold">Sitter Onboarding Status</CardTitle>
        <CardDescription>
          Monitor the progress of sitters through the onboarding process
        </CardDescription>
        
        <Tabs value={currentTab} onValueChange={setCurrentTab} className="mt-4">
          <TabsList className="grid grid-cols-4">
            <TabsTrigger value="all" className="relative">
              All
              <Badge variant="secondary" className="ml-1.5">
                {counts.all}
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="pending" className="relative">
              In Progress
              <Badge variant="secondary" className="ml-1.5">
                {counts.pending}
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="complete" className="relative">
              Complete
              <Badge variant="secondary" className="ml-1.5">
                {counts.complete}
              </Badge>
            </TabsTrigger>
            <TabsTrigger value="atRisk" className="relative">
              At Risk
              <Badge variant="destructive" className="ml-1.5">
                {counts.atRisk}
              </Badge>
            </TabsTrigger>
          </TabsList>
          
          {Object.entries({ all: 'All Sitters', pending: 'In Progress', complete: 'Complete', atRisk: 'At Risk' }).map(([key, title]) => (
            <TabsContent key={key} value={key} className="mt-4">
              {isLoading ? (
                Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="flex items-center space-x-4 py-4 border-b">
                    <Skeleton className="h-12 w-12 rounded-full" />
                    <div className="space-y-2">
                      <Skeleton className="h-4 w-[200px]" />
                      <Skeleton className="h-4 w-[150px]" />
                    </div>
                    <Skeleton className="h-4 w-[100px] ml-auto" />
                  </div>
                ))
              ) : filteredSitters.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-10 text-center">
                  <AlertCircle className="h-10 w-10 text-slate-300 mb-2" />
                  <h3 className="text-lg font-medium">No sitters found</h3>
                  <p className="text-sm text-muted-foreground">
                    There are no sitters matching the selected filter.
                  </p>
                </div>
              ) : (
                filteredSitters.map((sitter: SitterReadiness) => (
                  <div key={sitter.id} className="py-4 border-b last:border-0">
                    <div className="flex items-center space-x-4 mb-3">
                      <Avatar>
                        <AvatarImage src={sitter.profileImage} alt={`${sitter.firstName} ${sitter.lastName}`} />
                        <AvatarFallback>{getInitials(sitter.firstName, sitter.lastName)}</AvatarFallback>
                      </Avatar>
                      
                      <div className="flex-1">
                        <h4 className="font-medium">{sitter.firstName} {sitter.lastName}</h4>
                        <div className="flex items-center text-sm text-muted-foreground">
                          <Clock className="h-3 w-3 mr-1" />
                          <span>Joined {formatDate(sitter.signupDate)}</span>
                        </div>
                      </div>
                      
                      <div className="text-center">
                        <span className={`text-lg font-semibold ${getScoreColor(sitter.score)}`}>
                          {sitter.score}%
                        </span>
                        <div className="text-xs text-muted-foreground">Complete</div>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-y-2 gap-x-4 text-sm mb-3">
                      <div className="flex items-center">
                        {getStatusIcon(sitter.steps.profileComplete)}
                        <span className="ml-2">Profile</span>
                      </div>
                      <div className="flex items-center">
                        {getStatusIcon(sitter.steps.valuesQuizComplete)}
                        <span className="ml-2">Values Quiz</span>
                      </div>
                      <div className="flex items-center">
                        {getStatusIcon(sitter.steps.backgroundCheck)}
                        <ShieldCheck className={`h-4 w-4 ${sitter.steps.backgroundCheck ? 'text-green-600' : 'text-slate-400'}`} />
                        <span className="ml-2">Background Check</span>
                      </div>
                      <div className="flex items-center">
                        {getStatusIcon(sitter.steps.firstAidCert)}
                        <Medal className={`h-4 w-4 ${sitter.steps.firstAidCert ? 'text-green-600' : 'text-slate-400'}`} />
                        <span className="ml-2">First Aid</span>
                      </div>
                      <div className="flex items-center">
                        {getStatusIcon(sitter.steps.referencesSubmitted)}
                        <PhoneCall className={`h-4 w-4 ${sitter.steps.referencesSubmitted ? 'text-green-600' : 'text-slate-400'}`} />
                        <span className="ml-2">References</span>
                      </div>
                      <div className="flex items-center">
                        {getStatusIcon(sitter.steps.identityVerified)}
                        <FileCheck className={`h-4 w-4 ${sitter.steps.identityVerified ? 'text-green-600' : 'text-slate-400'}`} />
                        <span className="ml-2">ID Verification</span>
                      </div>
                      <div className="flex items-center">
                        {getStatusIcon(sitter.steps.trainingComplete)}
                        <span className="ml-2">Training</span>
                      </div>
                    </div>
                    
                    <Progress value={sitter.score} className="h-1.5" />
                  </div>
                ))
              )}
            </TabsContent>
          ))}
        </Tabs>
      </CardHeader>
    </Card>
  );
}