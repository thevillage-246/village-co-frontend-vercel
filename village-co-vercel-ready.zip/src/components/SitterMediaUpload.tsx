import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { X, Upload, Play, Image as ImageIcon } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useAuth } from '@/hooks/useAuth';

interface SitterMediaUploadProps {
  sitterId: number;
  onMediaUpdated?: () => void;
}

interface MediaFile {
  file: File;
  preview: string;
  caption?: string;
  title?: string;
  description?: string;
}

export default function SitterMediaUpload({ sitterId, onMediaUpdated }: SitterMediaUploadProps) {
  const { toast } = useToast();
  const { user } = useAuth();
  const [photoFiles, setPhotoFiles] = useState<MediaFile[]>([]);
  const [videoFiles, setVideoFiles] = useState<MediaFile[]>([]);
  const [uploading, setUploading] = useState(false);

  const onPhotoDrop = useCallback((acceptedFiles: File[]) => {
    const newFiles = acceptedFiles.map(file => ({
      file,
      preview: URL.createObjectURL(file),
      caption: ''
    }));
    setPhotoFiles(prev => [...prev, ...newFiles]);
  }, []);

  const onVideoDrop = useCallback((acceptedFiles: File[]) => {
    const newFiles = acceptedFiles.map(file => ({
      file,
      preview: URL.createObjectURL(file),
      title: '',
      description: ''
    }));
    setVideoFiles(prev => [...prev, ...newFiles]);
  }, []);

  const photoDropzone = useDropzone({
    onDrop: onPhotoDrop,
    accept: {
      'image/*': ['.jpeg', '.jpg', '.png', '.webp', '.avif', '.gif', '.svg']
    },
    maxFiles: 10,
    maxSize: 10 * 1024 * 1024 // 10MB
  });

  const videoDropzone = useDropzone({
    onDrop: onVideoDrop,
    accept: {
      'video/*': ['.mp4', '.webm', '.ogg', '.avi', '.mov']
    },
    maxFiles: 3,
    maxSize: 50 * 1024 * 1024 // 50MB
  });

  const removePhoto = (index: number) => {
    setPhotoFiles(prev => {
      const newFiles = [...prev];
      URL.revokeObjectURL(newFiles[index].preview);
      newFiles.splice(index, 1);
      return newFiles;
    });
  };

  const removeVideo = (index: number) => {
    setVideoFiles(prev => {
      const newFiles = [...prev];
      URL.revokeObjectURL(newFiles[index].preview);
      newFiles.splice(index, 1);
      return newFiles;
    });
  };

  const updatePhotoCaption = (index: number, caption: string) => {
    setPhotoFiles(prev => {
      const newFiles = [...prev];
      newFiles[index].caption = caption;
      return newFiles;
    });
  };

  const updateVideoDetails = (index: number, field: string, value: string) => {
    setVideoFiles(prev => {
      const newFiles = [...prev];
      (newFiles[index] as any)[field] = value;
      return newFiles;
    });
  };

  const uploadMedia = async () => {
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please log in to upload media",
        variant: "destructive"
      });
      return;
    }

    if (photoFiles.length === 0 && videoFiles.length === 0) {
      toast({
        title: "No files selected",
        description: "Please select photos or videos to upload",
        variant: "destructive"
      });
      return;
    }

    setUploading(true);

    try {
      // Upload photos
      if (photoFiles.length > 0) {
        const photoFormData = new FormData();
        photoFiles.forEach((mediaFile, index) => {
          photoFormData.append('photos', mediaFile.file);
          photoFormData.append(`captions`, mediaFile.caption || '');
        });
        
        if (photoFiles.length > 0) {
          photoFormData.append('setPrimary', 'true');
        }

        const photoResponse = await apiRequest('POST', '/api/sitter-media/photos', photoFormData, {
          'Content-Type': 'multipart/form-data'
        });

        if (photoResponse.ok) {
          toast({
            title: "Photos uploaded successfully",
            description: `${photoFiles.length} photos have been added to your profile`
          });
        }
      }

      // Upload videos
      if (videoFiles.length > 0) {
        for (const mediaFile of videoFiles) {
          const videoFormData = new FormData();
          videoFormData.append('video', mediaFile.file);
          videoFormData.append('title', mediaFile.title || 'About Me Video');
          videoFormData.append('description', mediaFile.description || '');
          videoFormData.append('isIntroVideo', 'true');

          const videoResponse = await apiRequest('POST', '/api/sitter-media/videos', videoFormData, {
            'Content-Type': 'multipart/form-data'
          });

          if (videoResponse.ok) {
            toast({
              title: "Video uploaded successfully", 
              description: "Your video has been added to your profile"
            });
          }
        }
      }

      // Clear files and notify parent component
      setPhotoFiles([]);
      setVideoFiles([]);
      onMediaUpdated?.();

    } catch (error: any) {
      console.error('Upload error:', error);
      toast({
        title: "Upload failed",
        description: error.message || "Failed to upload media files",
        variant: "destructive"
      });
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Photo Upload Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ImageIcon className="h-5 w-5" />
            Upload Photos
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div
            {...photoDropzone.getRootProps()}
            className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
              photoDropzone.isDragActive 
                ? 'border-primary bg-primary/5' 
                : 'border-gray-300 hover:border-primary'
            }`}
          >
            <input {...photoDropzone.getInputProps()} />
            <Upload className="h-8 w-8 mx-auto mb-2 text-gray-400" />
            <p className="text-sm text-gray-600">
              Drop photos here or click to select
            </p>
            <p className="text-xs text-gray-500 mt-1">
              Supports JPEG, PNG, WebP, AVIF, GIF, SVG (max 10MB each)
            </p>
          </div>

          {photoFiles.length > 0 && (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {photoFiles.map((mediaFile, index) => (
                <div key={index} className="relative">
                  <img
                    src={mediaFile.preview}
                    alt={`Upload preview ${index + 1}`}
                    className="w-full h-32 object-cover rounded-lg"
                  />
                  <Button
                    type="button"
                    variant="destructive"
                    size="sm"
                    className="absolute top-1 right-1 h-6 w-6 p-0"
                    onClick={() => removePhoto(index)}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                  <div className="mt-2">
                    <Input
                      placeholder="Photo caption (optional)"
                      value={mediaFile.caption}
                      onChange={(e) => updatePhotoCaption(index, e.target.value)}
                      className="text-xs"
                    />
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Video Upload Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Play className="h-5 w-5" />
            Upload Videos
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div
            {...videoDropzone.getRootProps()}
            className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition-colors ${
              videoDropzone.isDragActive 
                ? 'border-primary bg-primary/5' 
                : 'border-gray-300 hover:border-primary'
            }`}
          >
            <input {...videoDropzone.getInputProps()} />
            <Play className="h-8 w-8 mx-auto mb-2 text-gray-400" />
            <p className="text-sm text-gray-600">
              Drop videos here or click to select
            </p>
            <p className="text-xs text-gray-500 mt-1">
              Supports MP4, WebM, OGG, AVI, MOV (max 50MB each)
            </p>
          </div>

          {videoFiles.length > 0 && (
            <div className="space-y-4">
              {videoFiles.map((mediaFile, index) => (
                <div key={index} className="border rounded-lg p-4">
                  <div className="flex items-start gap-4">
                    <video
                      src={mediaFile.preview}
                      className="w-32 h-24 object-cover rounded"
                      controls
                    />
                    <div className="flex-1 space-y-3">
                      <div className="flex justify-between items-start">
                        <div className="flex-1 space-y-2">
                          <div>
                            <Label htmlFor={`video-title-${index}`}>Title</Label>
                            <Input
                              id={`video-title-${index}`}
                              placeholder="Video title"
                              value={mediaFile.title}
                              onChange={(e) => updateVideoDetails(index, 'title', e.target.value)}
                            />
                          </div>
                          <div>
                            <Label htmlFor={`video-description-${index}`}>Description</Label>
                            <Textarea
                              id={`video-description-${index}`}
                              placeholder="Tell parents about yourself in this video..."
                              value={mediaFile.description}
                              onChange={(e) => updateVideoDetails(index, 'description', e.target.value)}
                              rows={2}
                            />
                          </div>
                        </div>
                        <Button
                          type="button"
                          variant="destructive"
                          size="sm"
                          onClick={() => removeVideo(index)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Upload Button */}
      {(photoFiles.length > 0 || videoFiles.length > 0) && (
        <div className="flex justify-end">
          <Button
            onClick={uploadMedia}
            disabled={uploading}
            className="bg-[#6B3E4B] hover:bg-[#5A2F3B] text-white"
          >
            {uploading ? 'Uploading...' : `Upload ${photoFiles.length + videoFiles.length} files`}
          </Button>
        </div>
      )}
    </div>
  );
}