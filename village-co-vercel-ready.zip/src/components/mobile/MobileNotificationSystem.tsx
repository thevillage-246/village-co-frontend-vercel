import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Bell, CheckCircle, Clock, MessageSquare, CreditCard, Shield, AlertTriangle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '@/hooks/use-toast';

interface NotificationItem {
  id: string;
  type: 'booking_confirmation' | 'sitter_response' | 'payment_success' | 'message' | 'safety_alert';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  urgent: boolean;
  actions?: {
    label: string;
    action: () => void;
  }[];
}

interface PushNotificationStatus {
  supported: boolean;
  permission: NotificationPermission;
  registration: ServiceWorkerRegistration | null;
  subscription: PushSubscription | null;
}

const MobileNotificationSystem: React.FC = () => {
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [pushStatus, setPushStatus] = useState<PushNotificationStatus>({
    supported: 'serviceWorker' in navigator && 'PushManager' in window,
    permission: 'default',
    registration: null,
    subscription: null
  });
  const [testingMode, setTestingMode] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    checkNotificationSupport();
    loadNotificationHistory();
    simulateIncomingNotifications();
  }, []);

  // 2. NOTIFICATIONS & URGENCY - Push works on iOS + Android
  const checkNotificationSupport = async () => {
    if (!pushStatus.supported) {
      console.warn('Push messaging is not supported');
      return;
    }

    try {
      // Request notification permission
      const permission = await Notification.requestPermission();
      
      // Register service worker
      const registration = await navigator.serviceWorker.register('/service-worker.js');
      
      // Check for existing subscription
      const subscription = await registration.pushManager.getSubscription();
      
      setPushStatus({
        supported: true,
        permission,
        registration,
        subscription
      });

      if (permission === 'granted') {
        await subscribeToPushNotifications(registration);
      }
    } catch (error) {
      console.error('Error setting up push notifications:', error);
    }
  };

  const subscribeToPushNotifications = async (registration: ServiceWorkerRegistration) => {
    try {
      const subscription = await registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(process.env.VITE_VAPID_PUBLIC_KEY || '')
      });

      // Send subscription to server
      await fetch('/api/notifications/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subscription,
          platform: getMobilePlatform()
        })
      });

      setPushStatus(prev => ({ ...prev, subscription }));
      
      toast({
        title: "Notifications Enabled",
        description: "You'll receive booking updates and messages instantly",
      });
    } catch (error) {
      console.error('Failed to subscribe to push notifications:', error);
    }
  };

  // Test notification delivery across all channels
  const testNotificationChannels = async () => {
    setTestingMode(true);
    
    const testNotification: NotificationItem = {
      id: `test-${Date.now()}`,
      type: 'booking_confirmation',
      title: 'Test Booking Confirmed',
      message: 'Sarah Wilson will be there tonight at 7:00 PM',
      timestamp: new Date().toISOString(),
      read: false,
      urgent: true,
      actions: [
        {
          label: 'View Details',
          action: () => toast({ title: "Booking details opened" })
        },
        {
          label: 'Message Sarah',
          action: () => toast({ title: "Chat opened with Sarah" })
        }
      ]
    };

    // 1. Push Notification
    if (pushStatus.permission === 'granted') {
      new Notification(testNotification.title, {
        body: testNotification.message,
        icon: '/icons/icon-192x192.png',
        badge: '/icons/badge-72x72.png',
        actions: [
          { action: 'view', title: 'View Details' },
          { action: 'message', title: 'Message Sitter' }
        ],
        data: { bookingId: 'test-123' }
      });
    }

    // 2. In-app notification
    setNotifications(prev => [testNotification, ...prev]);

    // 3. Email notification (simulated)
    await fetch('/api/notifications/email', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type: 'booking_confirmation',
        data: testNotification
      })
    });

    // 4. SMS notification (simulated)
    await fetch('/api/notifications/sms', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type: 'booking_confirmation',
        message: `Booking confirmed! ${testNotification.message}`
      })
    });

    toast({
      title: "Notification Test Complete",
      description: "Check your push, email, and SMS for test messages",
    });

    setTestingMode(false);
  };

  // Load notification history from localStorage and server
  const loadNotificationHistory = () => {
    const stored = localStorage.getItem('notificationHistory');
    if (stored) {
      setNotifications(JSON.parse(stored));
    }
  };

  // Simulate realistic notifications for demo
  const simulateIncomingNotifications = () => {
    const sampleNotifications: NotificationItem[] = [
      {
        id: '1',
        type: 'booking_confirmation',
        title: 'Booking Confirmed!',
        message: 'Sarah Wilson will be there tonight at 7:00 PM. Check your email for details.',
        timestamp: new Date(Date.now() - 30 * 60000).toISOString(), // 30 min ago
        read: false,
        urgent: true,
        actions: [
          {
            label: 'View Booking',
            action: () => window.location.href = '/bookings/123'
          },
          {
            label: 'Message Sarah',
            action: () => window.location.href = '/chat/456'
          }
        ]
      },
      {
        id: '2',
        type: 'sitter_response',
        title: 'Sitter Response',
        message: 'Emma Thompson accepted your booking request for Friday evening.',
        timestamp: new Date(Date.now() - 2 * 60 * 60000).toISOString(), // 2 hours ago
        read: true,
        urgent: false
      },
      {
        id: '3',
        type: 'message',
        title: 'New Message',
        message: 'Sarah: "Hi! I\'m looking forward to meeting your family tonight. Just confirming..."',
        timestamp: new Date(Date.now() - 15 * 60000).toISOString(), // 15 min ago
        read: false,
        urgent: false,
        actions: [
          {
            label: 'Reply',
            action: () => window.location.href = '/chat/456'
          }
        ]
      },
      {
        id: '4',
        type: 'payment_success',
        title: 'Payment Processed',
        message: 'Your payment of $132.00 has been processed successfully.',
        timestamp: new Date(Date.now() - 45 * 60000).toISOString(), // 45 min ago
        read: true,
        urgent: false
      }
    ];

    setNotifications(sampleNotifications);
  };

  const markAsRead = (notificationId: string) => {
    setNotifications(prev => 
      prev.map(n => n.id === notificationId ? { ...n, read: true } : n)
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const getNotificationIcon = (type: NotificationItem['type']) => {
    switch (type) {
      case 'booking_confirmation':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'sitter_response':
        return <Bell className="w-5 h-5 text-blue-500" />;
      case 'message':
        return <MessageSquare className="w-5 h-5 text-purple-500" />;
      case 'payment_success':
        return <CreditCard className="w-5 h-5 text-green-500" />;
      case 'safety_alert':
        return <Shield className="w-5 h-5 text-red-500" />;
      default:
        return <Bell className="w-5 h-5 text-gray-500" />;
    }
  };

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date();
    const time = new Date(timestamp);
    const diffMs = now.getTime() - time.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    return `${diffDays}d ago`;
  };

  const getMobilePlatform = (): 'ios' | 'android' | 'web' => {
    const userAgent = navigator.userAgent.toLowerCase();
    if (/iphone|ipad|ipod/.test(userAgent)) return 'ios';
    if (/android/.test(userAgent)) return 'android';
    return 'web';
  };

  // Convert VAPID key for push subscription
  const urlBase64ToUint8Array = (base64String: string) => {
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64 = (base64String + padding)
      .replace(/-/g, '+')
      .replace(/_/g, '/');

    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);

    for (let i = 0; i < rawData.length; ++i) {
      outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray;
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <div className="max-w-md mx-auto min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white p-4 border-b">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Bell className="w-6 h-6 text-village-wine" />
            <div>
              <h1 className="text-xl font-bold text-village-wine">Notifications</h1>
              <p className="text-sm text-gray-600">
                {unreadCount > 0 ? `${unreadCount} unread` : 'All caught up'}
              </p>
            </div>
          </div>
          
          {unreadCount > 0 && (
            <Button
              variant="outline"
              size="sm"
              onClick={markAllAsRead}
            >
              Mark all read
            </Button>
          )}
        </div>
      </div>

      {/* Push Notification Status */}
      <div className="p-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Notification Settings</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm">Push Notifications</span>
              <Badge variant={pushStatus.permission === 'granted' ? 'default' : 'destructive'}>
                {pushStatus.permission === 'granted' ? 'Enabled' : 'Disabled'}
              </Badge>
            </div>
            
            <div className="flex items-center justify-between">
              <span className="text-sm">Platform</span>
              <Badge variant="outline">
                {getMobilePlatform().toUpperCase()}
              </Badge>
            </div>

            {pushStatus.permission !== 'granted' && (
              <Alert>
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription className="text-xs">
                  Enable push notifications to receive instant booking updates
                </AlertDescription>
              </Alert>
            )}

            <Button
              onClick={testNotificationChannels}
              disabled={testingMode}
              className="w-full"
              variant="outline"
            >
              {testingMode ? 'Testing...' : 'Test All Channels'}
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Notification List */}
      <div className="px-4 pb-4">
        <div className="space-y-2">
          <AnimatePresence>
            {notifications.map((notification) => (
              <motion.div
                key={notification.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
              >
                <Card 
                  className={`cursor-pointer transition-colors ${
                    !notification.read 
                      ? 'border-l-4 border-l-village-wine bg-white' 
                      : 'bg-gray-50'
                  }`}
                  onClick={() => markAsRead(notification.id)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start space-x-3">
                      <div className="flex-shrink-0 mt-1">
                        {getNotificationIcon(notification.type)}
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <h4 className={`text-sm font-medium ${
                            !notification.read ? 'text-gray-900' : 'text-gray-600'
                          }`}>
                            {notification.title}
                          </h4>
                          
                          <div className="flex items-center gap-2">
                            {notification.urgent && (
                              <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                            )}
                            <span className="text-xs text-gray-500">
                              {formatTimeAgo(notification.timestamp)}
                            </span>
                          </div>
                        </div>
                        
                        <p className={`text-sm mt-1 ${
                          !notification.read ? 'text-gray-700' : 'text-gray-500'
                        }`}>
                          {notification.message}
                        </p>

                        {notification.actions && notification.actions.length > 0 && (
                          <div className="flex gap-2 mt-3">
                            {notification.actions.map((action, index) => (
                              <Button
                                key={index}
                                size="sm"
                                variant="outline"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  action.action();
                                }}
                                className="text-xs"
                              >
                                {action.label}
                              </Button>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {notifications.length === 0 && (
          <div className="text-center py-12">
            <Bell className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No notifications yet</h3>
            <p className="text-gray-500">You'll see booking updates and messages here</p>
          </div>
        )}
      </div>

      {/* Cross-platform sync indicator */}
      <div className="p-4 border-t bg-white">
        <div className="flex items-center justify-center gap-2 text-xs text-gray-500">
          <CheckCircle className="w-4 h-4 text-green-500" />
          Synced across all devices
        </div>
      </div>
    </div>
  );
};

export default MobileNotificationSystem;