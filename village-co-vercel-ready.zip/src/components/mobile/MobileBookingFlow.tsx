import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Calendar, Clock, MapPin, Shield, Heart, Star, CheckCircle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { motion, AnimatePresence } from 'framer-motion';

interface Sitter {
  id: number;
  firstName: string;
  lastName: string;
  profileImage?: string;
  hourlyRate: number;
  rating: number;
  reviewCount: number;
  badges: string[];
  isVerified: boolean;
  hasFirstAid: boolean;
  location: string;
  availableTonight: boolean;
}

interface BookingStep {
  step: number;
  title: string;
  subtitle: string;
  component: React.ReactNode;
}

const MobileBookingFlow: React.FC = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedSitter, setSelectedSitter] = useState<Sitter | null>(null);
  const [bookingData, setBookingData] = useState({
    startTime: '',
    endTime: '',
    childrenCount: 1,
    specialRequests: '',
    totalAmount: 0
  });
  const [isLoading, setIsLoading] = useState(false);
  const [paymentComplete, setPaymentComplete] = useState(false);
  const { toast } = useToast();

  // Sample sitters data (would come from API)
  const sitters: Sitter[] = [
    {
      id: 1,
      firstName: 'Sarah',
      lastName: 'Wilson',
      profileImage: '/images/sitter-sarah.jpg',
      hourlyRate: 30,
      rating: 4.9,
      reviewCount: 127,
      badges: ['Top Sitter', 'First Aid Certified', 'Village Verified'],
      isVerified: true,
      hasFirstAid: true,
      location: 'Hamilton Central',
      availableTonight: true
    },
    {
      id: 2,
      firstName: 'Emma',
      lastName: 'Thompson',
      profileImage: '/images/sitter-emma.jpg',
      hourlyRate: 28,
      rating: 4.8,
      reviewCount: 89,
      badges: ['Village Verified', 'Background Checked'],
      isVerified: true,
      hasFirstAid: false,
      location: 'Hamilton East',
      availableTonight: true
    }
  ];

  // 1. BOOKING CONVERSION FLOW (<3 taps)
  const handleQuickBook = (sitter: Sitter) => {
    setSelectedSitter(sitter);
    
    // Auto-fill tonight's booking (7pm-11pm)
    const tonight = new Date();
    tonight.setHours(19, 0, 0, 0);
    const endTime = new Date(tonight);
    endTime.setHours(23, 0, 0, 0);
    
    setBookingData({
      ...bookingData,
      startTime: tonight.toISOString().slice(0, 16),
      endTime: endTime.toISOString().slice(0, 16),
      totalAmount: sitter.hourlyRate * 4 // 4 hours
    });
    
    setCurrentStep(2);
    
    toast({
      title: "Sitter Selected!",
      description: `${sitter.firstName} is available tonight. Just confirm details and pay.`,
    });
  };

  const handleConfirmBooking = async () => {
    setIsLoading(true);
    
    try {
      // Simulate booking creation
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Simulate payment processing
      await processPayment();
      
      setPaymentComplete(true);
      setCurrentStep(4); // Success step
      
      // Celebration toast
      toast({
        title: "🎉 Booking Confirmed!",
        description: `${selectedSitter?.firstName} will be there tonight. Check your inbox for details.`,
      });
      
    } catch (error) {
      toast({
        title: "Booking Failed",
        description: "Please try again or contact support.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const processPayment = async () => {
    // Simulate Stripe payment with Apple Pay/Google Pay support
    await new Promise(resolve => setTimeout(resolve, 2000));
    return { success: true, paymentIntentId: 'pi_test_123' };
  };

  // Handle abandonment recovery
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (currentStep > 1 && currentStep < 4) {
        e.preventDefault();
        e.returnValue = 'You have an incomplete booking. Are you sure you want to leave?';
        
        // Store abandoned booking for later nudge
        localStorage.setItem('abandonedBooking', JSON.stringify({
          sitterId: selectedSitter?.id,
          step: currentStep,
          timestamp: new Date().toISOString()
        }));
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [currentStep, selectedSitter]);

  // Step 1: Sitter Selection (Progressive Enhancement)
  const SitterSelectionStep = () => (
    <div className="space-y-4">
      <div className="text-center mb-6">
        <h1 className="text-2xl font-bold text-village-wine mb-2">Need a sitter tonight?</h1>
        <p className="text-gray-600">Available verified sitters near you</p>
      </div>

      <div className="space-y-3">
        {sitters.map((sitter) => (
          <motion.div
            key={sitter.id}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Card 
              className="cursor-pointer border-2 hover:border-village-wine transition-colors"
              onClick={() => handleQuickBook(sitter)}
            >
              <CardContent className="p-4">
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <div className="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center">
                      <span className="text-gray-500 text-lg font-medium">
                        {sitter.firstName[0]}{sitter.lastName[0]}
                      </span>
                    </div>
                    {sitter.availableTonight && (
                      <div className="absolute -top-1 -right-1 w-5 h-5 bg-green-500 rounded-full border-2 border-white"></div>
                    )}
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold">{sitter.firstName} {sitter.lastName}</h3>
                      {sitter.isVerified && <Shield className="w-4 h-4 text-blue-500" />}
                      {sitter.hasFirstAid && <Heart className="w-4 h-4 text-red-500" />}
                    </div>
                    
                    <div className="flex items-center gap-1 mt-1">
                      <Star className="w-4 h-4 text-yellow-500 fill-current" />
                      <span className="text-sm">{sitter.rating} ({sitter.reviewCount} reviews)</span>
                    </div>
                    
                    <p className="text-sm text-gray-600 flex items-center gap-1 mt-1">
                      <MapPin className="w-3 h-3" />
                      {sitter.location}
                    </p>
                    
                    <div className="flex flex-wrap gap-1 mt-2">
                      {sitter.badges.slice(0, 2).map((badge) => (
                        <Badge key={badge} variant="secondary" className="text-xs">
                          {badge}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <p className="font-semibold text-lg">${sitter.hourlyRate}/hr</p>
                    <Button size="sm" className="bg-village-wine hover:bg-village-wine/90 mt-2">
                      Book Now
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Trust Signals */}
      <div className="bg-gray-50 p-4 rounded-lg">
        <div className="flex items-center gap-2 mb-2">
          <Shield className="w-5 h-5 text-blue-500" />
          <h4 className="font-medium">Every booking is protected</h4>
        </div>
        <ul className="text-sm text-gray-600 space-y-1">
          <li>• $2 million liability insurance coverage</li>
          <li>• All sitters background checked</li>
          <li>• 24/7 emergency support available</li>
          <li>• 100% money-back guarantee</li>
        </ul>
      </div>
    </div>
  );

  // Step 2: Booking Details (Quick confirm)
  const BookingDetailsStep = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-xl font-bold text-village-wine">Confirm Your Booking</h2>
        <p className="text-gray-600">With {selectedSitter?.firstName} {selectedSitter?.lastName}</p>
      </div>

      <Card>
        <CardContent className="p-4">
          <div className="flex items-center space-x-4 mb-4">
            <div className="w-12 h-12 bg-gray-200 rounded-full flex items-center justify-center">
              <span className="text-gray-500 font-medium">
                {selectedSitter?.firstName[0]}{selectedSitter?.lastName[0]}
              </span>
            </div>
            <div>
              <h3 className="font-semibold">{selectedSitter?.firstName} {selectedSitter?.lastName}</h3>
              <div className="flex items-center gap-1">
                <Star className="w-4 h-4 text-yellow-500 fill-current" />
                <span className="text-sm">{selectedSitter?.rating} ({selectedSitter?.reviewCount} reviews)</span>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="startTime">Start Time</Label>
                <Input
                  id="startTime"
                  type="datetime-local"
                  value={bookingData.startTime}
                  onChange={(e) => setBookingData({...bookingData, startTime: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="endTime">End Time</Label>
                <Input
                  id="endTime"
                  type="datetime-local"
                  value={bookingData.endTime}
                  onChange={(e) => setBookingData({...bookingData, endTime: e.target.value})}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="childrenCount">Number of Children</Label>
              <Input
                id="childrenCount"
                type="number"
                min="1"
                max="5"
                value={bookingData.childrenCount}
                onChange={(e) => setBookingData({...bookingData, childrenCount: parseInt(e.target.value)})}
              />
            </div>

            <div>
              <Label htmlFor="specialRequests">Special Requests (Optional)</Label>
              <Textarea
                id="specialRequests"
                placeholder="Any special instructions for your sitter..."
                value={bookingData.specialRequests}
                onChange={(e) => setBookingData({...bookingData, specialRequests: e.target.value})}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Pricing Breakdown */}
      <Card>
        <CardContent className="p-4">
          <h4 className="font-medium mb-3">Booking Summary</h4>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span>4 hours @ ${selectedSitter?.hourlyRate}/hr</span>
              <span>${(selectedSitter?.hourlyRate || 0) * 4}</span>
            </div>
            <div className="flex justify-between">
              <span>Service fee</span>
              <span>${((selectedSitter?.hourlyRate || 0) * 4 * 0.1).toFixed(2)}</span>
            </div>
            <div className="border-t pt-2 flex justify-between font-semibold">
              <span>Total</span>
              <span>${((selectedSitter?.hourlyRate || 0) * 4 * 1.1).toFixed(2)}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex gap-3">
        <Button 
          variant="outline" 
          onClick={() => setCurrentStep(1)}
          className="flex-1"
        >
          Back
        </Button>
        <Button 
          onClick={() => setCurrentStep(3)}
          className="flex-1 bg-village-wine hover:bg-village-wine/90"
        >
          Continue to Payment
        </Button>
      </div>
    </div>
  );

  // Step 3: Payment (Streamlined)
  const PaymentStep = () => (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-xl font-bold text-village-wine">Secure Payment</h2>
        <p className="text-gray-600">Complete your booking in seconds</p>
      </div>

      <Card>
        <CardContent className="p-4">
          <div className="space-y-4">
            <Button 
              className="w-full bg-black text-white hover:bg-black/90 h-12"
              onClick={handleConfirmBooking}
              disabled={isLoading}
            >
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  Processing...
                </div>
              ) : (
                'Pay with Apple Pay'
              )}
            </Button>
            
            <Button 
              className="w-full bg-blue-600 text-white hover:bg-blue-700 h-12"
              onClick={handleConfirmBooking}
              disabled={isLoading}
            >
              Pay with Google Pay
            </Button>
            
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-white px-2 text-gray-500">Or pay with card</span>
              </div>
            </div>
            
            <Button 
              variant="outline"
              className="w-full h-12"
              onClick={handleConfirmBooking}
              disabled={isLoading}
            >
              Pay with Card
            </Button>
          </div>
        </CardContent>
      </Card>

      <Alert>
        <Shield className="h-4 w-4" />
        <AlertDescription>
          Payments are processed securely by Stripe. Your booking is protected by our $2M insurance policy.
        </AlertDescription>
      </Alert>

      <div className="flex gap-3">
        <Button 
          variant="outline" 
          onClick={() => setCurrentStep(2)}
          className="flex-1"
          disabled={isLoading}
        >
          Back
        </Button>
      </div>
    </div>
  );

  // Step 4: Success (Celebratory)
  const SuccessStep = () => (
    <motion.div 
      className="space-y-6 text-center"
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
    >
      <div className="space-y-4">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
        >
          <CheckCircle className="w-20 h-20 text-green-500 mx-auto" />
        </motion.div>
        
        <h2 className="text-2xl font-bold text-village-wine">
          You're all set!
        </h2>
        
        <p className="text-gray-600">
          {selectedSitter?.firstName} will be there tonight at 7:00 PM
        </p>
      </div>

      <Card>
        <CardContent className="p-4">
          <h4 className="font-medium mb-3">What happens next?</h4>
          <div className="space-y-3 text-left">
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 bg-village-wine text-white rounded-full flex items-center justify-center text-sm font-bold">1</div>
              <div>
                <p className="font-medium">Confirmation sent</p>
                <p className="text-sm text-gray-600">Check your email and SMS for booking details</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 bg-village-wine text-white rounded-full flex items-center justify-center text-sm font-bold">2</div>
              <div>
                <p className="font-medium">{selectedSitter?.firstName} will message you</p>
                <p className="text-sm text-gray-600">She'll introduce herself and confirm arrival time</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 bg-village-wine text-white rounded-full flex items-center justify-center text-sm font-bold">3</div>
              <div>
                <p className="font-medium">Enjoy your evening</p>
                <p className="text-sm text-gray-600">Your children are in safe, caring hands</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-3">
        <Button 
          className="w-full bg-village-wine hover:bg-village-wine/90"
          onClick={() => window.location.href = '/bookings'}
        >
          View My Bookings
        </Button>
        
        <Button 
          variant="outline"
          className="w-full"
          onClick={() => {
            setCurrentStep(1);
            setSelectedSitter(null);
            setPaymentComplete(false);
          }}
        >
          Book Another Sitter
        </Button>
      </div>

      <div className="text-sm text-gray-500">
        Need help? Call our 24/7 support: 07 807 9114
      </div>
    </motion.div>
  );

  const steps: BookingStep[] = [
    { step: 1, title: 'Choose Sitter', subtitle: 'Available tonight', component: <SitterSelectionStep /> },
    { step: 2, title: 'Confirm Details', subtitle: 'Quick setup', component: <BookingDetailsStep /> },
    { step: 3, title: 'Secure Payment', subtitle: 'Apple Pay, Google Pay, or card', component: <PaymentStep /> },
    { step: 4, title: 'All Done!', subtitle: 'Enjoy your evening', component: <SuccessStep /> }
  ];

  return (
    <div className="max-w-md mx-auto min-h-screen bg-white">
      {/* Progress Indicator */}
      {currentStep < 4 && (
        <div className="px-4 py-6 border-b">
          <div className="flex items-center justify-between mb-2">
            {steps.slice(0, 3).map((step) => (
              <div key={step.step} className="flex items-center">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                  currentStep >= step.step 
                    ? 'bg-village-wine text-white' 
                    : 'bg-gray-200 text-gray-600'
                }`}>
                  {step.step}
                </div>
                {step.step < 3 && (
                  <div className={`w-12 h-1 mx-2 ${
                    currentStep > step.step ? 'bg-village-wine' : 'bg-gray-200'
                  }`} />
                )}
              </div>
            ))}
          </div>
          <h3 className="font-semibold">{steps[currentStep - 1].title}</h3>
          <p className="text-sm text-gray-600">{steps[currentStep - 1].subtitle}</p>
        </div>
      )}

      {/* Step Content */}
      <div className="p-4">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            {steps[currentStep - 1].component}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
};

export default MobileBookingFlow;