import React from 'react';
import { useLocation } from 'wouter';
import { MessageSquare, CalendarDays } from 'lucide-react';

interface SitterCardProps {
  sitter: {
    id: number;
    full_name: string;
    bio?: string;
    hourly_rate?: number;
    rating?: number;
    profile_image?: string;
  }
}

const SitterCard: React.FC<SitterCardProps> = ({ sitter }) => {
  const [, navigate] = useLocation();

  return (
    <div className="rounded-lg shadow-md p-5 bg-white border border-gray-100">
      <div className="flex items-center gap-3 mb-3">
        <div className="h-12 w-12 rounded-full bg-[#EBD3CB] flex items-center justify-center text-[#6B3E4B] font-medium">
          {sitter.profile_image ? (
            <img src={sitter.profile_image} alt={sitter.full_name.split(' ')[0]} className="h-full w-full object-cover rounded-full" />
          ) : (
            sitter.full_name.charAt(0)
          )}
        </div>
        <h3 className="text-xl font-semibold">{sitter.full_name.split(' ')[0]}{sitter.full_name.split(' ')[1] ? ` ${sitter.full_name.split(' ')[1][0]}.` : ''}</h3>
      </div>
      
      {sitter.bio && (
        <p className="text-gray-600 text-sm mb-4 line-clamp-2">{sitter.bio}</p>
      )}
      
      <div className="flex gap-2 mt-3">
        <button
          onClick={() => navigate(`/messages?sitterId=${sitter.id}`)}
          className="flex items-center justify-center bg-gray-800 text-white px-4 py-2 rounded hover:bg-gray-700 transition-colors flex-1"
        >
          <MessageSquare className="h-4 w-4 mr-2" />
          Contact Me
        </button>
        <button
          onClick={() => navigate(`/book?sitterId=${sitter.id}`)}
          className="flex items-center justify-center bg-[#6B3E4B] text-white px-4 py-2 rounded hover:bg-[#5a3340] transition-colors flex-1"
        >
          <CalendarDays className="h-4 w-4 mr-2" />
          Book Now
        </button>
      </div>
    </div>
  );
};

export default SitterCard;