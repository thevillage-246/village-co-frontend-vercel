import { Badge } from "@/components/ui/badge";
import { Heart, Baby, Brain, Shield, Car, Clock, Star } from "lucide-react";

interface ExperienceTagsProps {
  sitter: {
    firstAidCertified?: boolean;
    infantExperience?: boolean;
    neurodivergentFriendly?: boolean;
    hasTransport?: boolean;
    flexibleSchedule?: boolean;
    verified?: boolean;
    rating?: number;
    qualifications?: string;
  };
  showAll?: boolean;
  size?: "sm" | "default" | "lg";
}

export function ExperienceTags({ sitter, showAll = false, size = "default" }: ExperienceTagsProps) {
  const tags = [];

  // Auto-detect from qualifications string or array
  const qualifications = (() => {
    if (Array.isArray(sitter.qualifications)) {
      return sitter.qualifications
        .map(q => typeof q === 'string' ? q : q?.displayName || '')
        .join(' ')
        .toLowerCase();
    }
    return (sitter.qualifications?.toLowerCase() || "");
  })();
  const hasFirstAid = sitter.firstAidCertified || qualifications.includes('first aid') || qualifications.includes('cpr');
  const hasInfantExp = sitter.infantExperience || qualifications.includes('infant') || qualifications.includes('baby') || qualifications.includes('newborn');
  const isNeurodivergentFriendly = sitter.neurodivergentFriendly || qualifications.includes('autism') || qualifications.includes('adhd') || qualifications.includes('special needs');

  // Build tags array
  if (sitter.verified) {
    tags.push({
      icon: Shield,
      label: "Village Verified",
      color: "bg-green-100 text-green-800 border-green-200",
      priority: 1
    });
  }

  if (hasFirstAid) {
    tags.push({
      icon: Heart,
      label: "First Aid Certified",
      color: "bg-red-100 text-red-800 border-red-200",
      priority: 2
    });
  }

  if (hasInfantExp) {
    tags.push({
      icon: Baby,
      label: "Infant Experience",
      color: "bg-blue-100 text-blue-800 border-blue-200",
      priority: 3
    });
  }

  if (isNeurodivergentFriendly) {
    tags.push({
      icon: Brain,
      label: "Neurodivergent-Friendly",
      color: "bg-purple-100 text-purple-800 border-purple-200",
      priority: 4
    });
  }

  if (sitter.hasTransport) {
    tags.push({
      icon: Car,
      label: "Has Transport",
      color: "bg-orange-100 text-orange-800 border-orange-200",
      priority: 5
    });
  }

  if (sitter.flexibleSchedule) {
    tags.push({
      icon: Clock,
      label: "Flexible Schedule",
      color: "bg-indigo-100 text-indigo-800 border-indigo-200",
      priority: 6
    });
  }

  if (sitter.rating && sitter.rating >= 4.8) {
    tags.push({
      icon: Star,
      label: "Top Rated",
      color: "bg-yellow-100 text-yellow-800 border-yellow-200",
      priority: 7
    });
  }

  // Sort by priority and limit if not showing all
  const sortedTags = tags.sort((a, b) => a.priority - b.priority);
  const displayTags = showAll ? sortedTags : sortedTags.slice(0, 3);

  if (displayTags.length === 0) return null;

  return (
    <div className="flex flex-wrap gap-2">
      {displayTags.map((tag, index) => {
        const Icon = tag.icon;
        return (
          <Badge
            key={index}
            variant="outline"
            className={`${tag.color} border ${
              size === "sm" ? "text-xs px-2 py-1" : 
              size === "lg" ? "text-sm px-3 py-2" : 
              "text-xs px-2.5 py-1"
            }`}
          >
            <Icon className={`${
              size === "sm" ? "w-3 h-3" : 
              size === "lg" ? "w-4 h-4" : 
              "w-3 h-3"
            } mr-1`} />
            {tag.label}
          </Badge>
        );
      })}
      {!showAll && tags.length > 3 && (
        <Badge variant="outline" className="text-xs px-2.5 py-1 text-gray-600 border-gray-300">
          +{tags.length - 3} more
        </Badge>
      )}
    </div>
  );
}

// Auto-detect experience tags from sitter data
export function detectExperienceTags(sitterProfile: any): {
  firstAidCertified: boolean;
  infantExperience: boolean;
  neurodivergentFriendly: boolean;
  hasTransport: boolean;
  flexibleSchedule: boolean;
} {
  const qualifications = sitterProfile.qualifications?.toLowerCase() || "";
  const bio = sitterProfile.bio?.toLowerCase() || "";
  const experience = sitterProfile.experience?.toLowerCase() || "";
  
  const allText = `${qualifications} ${bio} ${experience}`;

  return {
    firstAidCertified: 
      allText.includes('first aid') || 
      allText.includes('cpr') || 
      allText.includes('red cross') ||
      allText.includes('st john'),
    
    infantExperience: 
      allText.includes('infant') || 
      allText.includes('baby') || 
      allText.includes('newborn') ||
      allText.includes('0-1') ||
      allText.includes('under 1'),
    
    neurodivergentFriendly: 
      allText.includes('autism') || 
      allText.includes('adhd') || 
      allText.includes('special needs') ||
      allText.includes('neurodivergent') ||
      allText.includes('sensory'),
    
    hasTransport: 
      allText.includes('transport') || 
      allText.includes('car') || 
      allText.includes('drive') ||
      allText.includes('vehicle') ||
      allText.includes('pick up') ||
      allText.includes('drop off'),
    
    flexibleSchedule: 
      allText.includes('flexible') || 
      allText.includes('last minute') || 
      allText.includes('short notice') ||
      allText.includes('emergency') ||
      allText.includes('available anytime')
  };
}