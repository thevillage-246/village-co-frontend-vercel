import { useState, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Play, Upload, Video, CheckCircle, Clock, Mic } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface VideoData {
  videoUrl: string;
  thumbnailUrl: string;
  duration: number;
  transcript: string;
  uploadedAt: Date;
  status: 'pending' | 'approved' | 'rejected';
}

interface VideoIntroductionProps {
  sitterId: number;
  isOwner?: boolean;
}

export function VideoIntroduction({ sitterId, isOwner = false }: VideoIntroductionProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [recordedBlob, setRecordedBlob] = useState<Blob | null>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch existing video
  const { data: videoData, isLoading } = useQuery({
    queryKey: [`/api/sitter/${sitterId}/video-intro`],
    queryFn: () => apiRequest('GET', `/api/sitter/${sitterId}/video-intro`).then(res => res.json()),
    retry: false
  });

  // Upload video mutation
  const uploadMutation = useMutation({
    mutationFn: (videoBlob: Blob) => {
      // Simulate upload progress
      const formData = new FormData();
      formData.append('video', videoBlob, 'intro.mp4');
      
      // In production, this would upload to storage service
      const videoUrl = URL.createObjectURL(videoBlob);
      
      return apiRequest('POST', '/api/sitter/video-intro', {
        videoUrl,
        duration: 45,
        transcript: 'Auto-generated transcript will appear here...'
      }).then(res => res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/sitter/${sitterId}/video-intro`] });
      setRecordedBlob(null);
      setUploadProgress(0);
      toast({
        title: "Video Uploaded Successfully",
        description: "Your introduction video is now under review"
      });
    },
    onError: () => {
      toast({
        title: "Upload Failed",
        description: "Failed to upload video. Please try again.",
        variant: "destructive"
      });
    }
  });

  // Start recording
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { width: 640, height: 480, facingMode: 'user' },
        audio: true 
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }

      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      
      const chunks: BlobPart[] = [];
      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          chunks.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'video/mp4' });
        setRecordedBlob(blob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      
      toast({
        title: "Recording Started",
        description: "Introduce yourself to families! Keep it under 60 seconds."
      });
    } catch (error) {
      toast({
        title: "Camera Access Denied",
        description: "Please allow camera and microphone access to record your introduction.",
        variant: "destructive"
      });
    }
  };

  // Stop recording
  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  // Handle upload
  const handleUpload = () => {
    if (recordedBlob) {
      // Simulate upload progress
      const interval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 100) {
            clearInterval(interval);
            uploadMutation.mutate(recordedBlob);
            return 100;
          }
          return prev + 10;
        });
      }, 200);
    }
  };

  if (isLoading && !isOwner) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse flex items-center gap-4">
            <div className="w-32 h-24 bg-gray-200 rounded" />
            <div className="flex-1">
              <div className="h-4 bg-gray-200 rounded w-3/4 mb-2" />
              <div className="h-3 bg-gray-200 rounded w-1/2" />
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Display existing video for viewers
  if (videoData && !isOwner) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Video className="w-5 h-5 text-blue-600" />
            Meet Your Sitter
          </CardTitle>
          <CardDescription>
            Personal introduction video
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="relative">
            <video
              className="w-full h-48 bg-gray-100 rounded-lg object-cover"
              poster={videoData.thumbnailUrl}
              controls
              preload="metadata"
            >
              <source src={videoData.videoUrl} type="video/mp4" />
              Your browser does not support video playback.
            </video>
            
            <div className="mt-3 flex items-center justify-between text-sm text-gray-600">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4" />
                <span>{videoData.duration} seconds</span>
              </div>
              <Badge className="bg-green-100 text-green-800">
                <CheckCircle className="w-3 h-3 mr-1" />
                Verified
              </Badge>
            </div>

            {videoData.transcript && (
              <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-700">
                  <strong>Transcript:</strong> {videoData.transcript}
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    );
  }

  // Upload interface for sitter owners
  if (isOwner) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Video className="w-5 h-5 text-blue-600" />
            Video Introduction
          </CardTitle>
          <CardDescription>
            Record a 30-60 second introduction to help families get to know you
          </CardDescription>
        </CardHeader>
        <CardContent>
          {videoData ? (
            // Existing video management
            <div className="space-y-4">
              <div className="relative">
                <video
                  className="w-full h-48 bg-gray-100 rounded-lg object-cover"
                  poster={videoData.thumbnailUrl}
                  controls
                >
                  <source src={videoData.videoUrl} type="video/mp4" />
                </video>
                
                <Badge 
                  className={`absolute top-2 right-2 ${
                    videoData.status === 'approved' 
                      ? 'bg-green-100 text-green-800'
                      : videoData.status === 'pending'
                      ? 'bg-yellow-100 text-yellow-800'
                      : 'bg-red-100 text-red-800'
                  }`}
                >
                  {videoData.status === 'approved' && <CheckCircle className="w-3 h-3 mr-1" />}
                  {videoData.status === 'pending' && <Clock className="w-3 h-3 mr-1" />}
                  {videoData.status.charAt(0).toUpperCase() + videoData.status.slice(1)}
                </Badge>
              </div>

              <div className="text-sm text-gray-600">
                <p><strong>Duration:</strong> {videoData.duration} seconds</p>
                <p><strong>Uploaded:</strong> {new Date(videoData.uploadedAt).toLocaleDateString()}</p>
              </div>

              <Button
                variant="outline"
                onClick={() => {
                  setRecordedBlob(null);
                  queryClient.setQueryData([`/api/sitter/${sitterId}/video-intro`], null);
                }}
                className="w-full"
              >
                <Upload className="w-4 h-4 mr-2" />
                Record New Video
              </Button>
            </div>
          ) : (
            // Recording interface
            <div className="space-y-4">
              {!recordedBlob ? (
                <div className="text-center">
                  <div className="relative mb-4">
                    <video
                      ref={videoRef}
                      className="w-full h-48 bg-gray-100 rounded-lg object-cover"
                      autoPlay
                      muted
                      style={{ display: isRecording ? 'block' : 'none' }}
                    />
                    
                    {!isRecording && (
                      <div className="w-full h-48 bg-gray-100 rounded-lg flex items-center justify-center">
                        <div className="text-center">
                          <Video className="w-12 h-12 text-gray-400 mx-auto mb-2" />
                          <p className="text-gray-600">Ready to record your introduction</p>
                        </div>
                      </div>
                    )}

                    {isRecording && (
                      <div className="absolute top-4 left-4 flex items-center gap-2 bg-red-600 text-white px-3 py-1 rounded-full text-sm">
                        <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
                        Recording
                      </div>
                    )}
                  </div>

                  <div className="flex gap-2">
                    <Button
                      onClick={isRecording ? stopRecording : startRecording}
                      className={isRecording ? "bg-red-600 hover:bg-red-700" : "bg-blue-600 hover:bg-blue-700"}
                      disabled={uploadMutation.isPending}
                    >
                      {isRecording ? (
                        <>
                          <Video className="w-4 h-4 mr-2" />
                          Stop Recording
                        </>
                      ) : (
                        <>
                          <Mic className="w-4 h-4 mr-2" />
                          Start Recording
                        </>
                      )}
                    </Button>
                  </div>

                  <Alert className="mt-4">
                    <Video className="h-4 w-4" />
                    <AlertDescription>
                      <strong>Tips for a great introduction:</strong>
                      <br />• Keep it 30-60 seconds
                      <br />• Mention your experience with children
                      <br />• Share what makes you special as a sitter
                      <br />• Smile and speak clearly
                    </AlertDescription>
                  </Alert>
                </div>
              ) : (
                // Preview and upload
                <div className="space-y-4">
                  <div className="relative">
                    <video
                      className="w-full h-48 bg-gray-100 rounded-lg object-cover"
                      controls
                      src={URL.createObjectURL(recordedBlob)}
                    />
                  </div>

                  {uploadProgress > 0 && uploadProgress < 100 && (
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Uploading...</span>
                        <span>{uploadProgress}%</span>
                      </div>
                      <Progress value={uploadProgress} />
                    </div>
                  )}

                  <div className="flex gap-2">
                    <Button
                      onClick={handleUpload}
                      disabled={uploadMutation.isPending || uploadProgress > 0}
                      className="flex-1 bg-green-600 hover:bg-green-700"
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      Upload Video
                    </Button>
                    
                    <Button
                      variant="outline"
                      onClick={() => setRecordedBlob(null)}
                      disabled={uploadMutation.isPending || uploadProgress > 0}
                    >
                      Re-record
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    );
  }

  return null;
}