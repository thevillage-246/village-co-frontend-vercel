import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { AlertTriangle, Users, MapPin, Clock, Shield, Eye, EyeOff, Info, Calendar } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { format } from 'date-fns';
import { SitterConfidenceBadge } from '@/components/ui/profile-freshness-badge';

interface FamilyPreviewProps {
  parentId: number;
  bookingId?: number;
  isBookingConfirmed?: boolean;
  onAccessGranted?: () => void;
}

interface CareInfo {
  familySize: number;
  parentFirstName: string;
  generalLocation: string;
  lastUpdated: Date;
  children: Array<{
    firstName: string;
    age: number | null;
    birthDate: Date | null;
    specialNeeds: string | null;
    allergies: string | null;
    notes: string | null;
    hasSpecialNeeds: boolean;
    hasAllergies: boolean;
  }>;
  familyNotes: string | null;
  whyWeShare: string;
}

interface FamilyProfile {
  parent: {
    firstName: string;
    lastName: string;
    address: string;
    city: string;
    state: string;
    zipCode: string;
    notes: string;
  };
  children: Array<{
    firstName: string;
    lastName: string;
    birthDate: Date | null;
    specialNeeds: string | null;
    allergies: string | null;
    notes: string | null;
  }>;
  emergencyContacts: Array<{
    name: string;
    relationship: string;
    phone: string;
    notes: string | null;
  }>;
  accessLevel: string;
  accessNote: string;
}

export default function FamilyProfilePreview({ 
  parentId, 
  bookingId, 
  isBookingConfirmed = false,
  onAccessGranted 
}: FamilyPreviewProps) {
  const [showFullProfile, setShowFullProfile] = useState(false);

  // Get family preview (always available)
  const { data: preview, isLoading: previewLoading } = useQuery<FamilyPreview>({
    queryKey: ['family-preview', parentId],
    queryFn: () => apiRequest('GET', `/api/family-profile/${parentId}/preview`).then(res => res.json())
  });

  // Get full family profile (only if booking confirmed)
  const { data: fullProfile, isLoading: profileLoading, error: profileError } = useQuery<FamilyProfile>({
    queryKey: ['family-profile-full', parentId],
    queryFn: () => apiRequest('GET', `/api/family-profile/${parentId}/full`).then(res => res.json()),
    enabled: showFullProfile && isBookingConfirmed
  });

  // Get profile freshness data for confidence indicators
  const { data: profileFreshness } = useQuery({
    queryKey: ['profile-freshness', parentId],
    queryFn: () => apiRequest('GET', `/api/profile/freshness/${parentId}`).then(res => res.json()),
    enabled: !!parentId
  });

  const calculateAge = (birthDate: Date | null): number | null => {
    if (!birthDate) return null;
    const today = new Date();
    const birth = new Date(birthDate);
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--;
    }
    return age;
  };

  if (previewLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            <div className="h-4 bg-gray-200 rounded w-2/3"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!preview) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-muted-foreground">Family information not available</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      {/* Family Preview Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between text-village-wine">
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Family Overview
            </div>
            {profileFreshness && (
              <SitterConfidenceBadge 
                daysSinceUpdate={profileFreshness.daysSinceUpdate}
                className="text-xs"
              />
            )}
          </CardTitle>
          <CardDescription>
            Care setup preview for {preview.parentName}'s family
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Family Size */}
          <div className="flex items-center justify-between">
            <span className="font-medium">Family Size:</span>
            <Badge variant="outline">{preview.familySize} {preview.familySize === 1 ? 'child' : 'children'}</Badge>
          </div>

          {/* Location */}
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm text-muted-foreground">{preview.location}</span>
          </div>

          <Separator />

          {/* Children Preview */}
          <div className="space-y-3">
            <h4 className="font-medium text-sm">Children:</h4>
            {preview.childrenAges.map((child, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="space-y-1">
                  <p className="font-medium text-sm">{child.firstName}</p>
                  <p className="text-xs text-muted-foreground">
                    {child.age ? `${child.age} years old` : 'Age not specified'}
                  </p>
                </div>
                <div className="flex gap-1">
                  {child.hasSpecialNeeds && (
                    <Badge variant="secondary" className="text-xs bg-blue-100 text-blue-800">
                      Special needs
                    </Badge>
                  )}
                  {child.hasAllergies && (
                    <Badge variant="secondary" className="text-xs bg-red-100 text-red-800">
                      Allergies
                    </Badge>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Access Status */}
          {!isBookingConfirmed ? (
            <Alert>
              <Shield className="h-4 w-4" />
              <AlertDescription>
                Full family details will be unlocked once you confirm this booking. 
                This preview helps you understand the care requirements.
              </AlertDescription>
            </Alert>
          ) : (
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Shield className="h-4 w-4 text-green-600" />
                <span className="text-sm text-green-600 font-medium">Access Granted</span>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowFullProfile(!showFullProfile)}
                className="flex items-center gap-2"
              >
                {showFullProfile ? (
                  <>
                    <EyeOff className="h-4 w-4" />
                    Hide Details
                  </>
                ) : (
                  <>
                    <Eye className="h-4 w-4" />
                    View Full Profile
                  </>
                )}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Full Family Profile (Only shown if booking confirmed and requested) */}
      {showFullProfile && isBookingConfirmed && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-village-wine">
              <Shield className="h-5 w-5" />
              Secure Family Profile
            </CardTitle>
            <CardDescription>
              Complete care information for your confirmed booking
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {profileLoading && (
              <div className="animate-pulse space-y-4">
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                <div className="h-4 bg-gray-200 rounded w-2/3"></div>
              </div>
            )}

            {profileError && (
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>
                  Unable to load full family profile. You may not have access yet.
                </AlertDescription>
              </Alert>
            )}

            {fullProfile && (
              <div className="space-y-6">
                {/* Parent Information */}
                <div>
                  <h4 className="font-medium text-sm mb-3">Parent Information:</h4>
                  <div className="space-y-2 p-4 bg-gray-50 rounded-lg">
                    <p><span className="font-medium">Name:</span> {fullProfile.parent.firstName} {fullProfile.parent.lastName}</p>
                    <p><span className="font-medium">Address:</span> {fullProfile.parent.address}</p>
                    <p><span className="font-medium">City:</span> {fullProfile.parent.city}, {fullProfile.parent.state} {fullProfile.parent.zipCode}</p>
                    {fullProfile.parent.notes && (
                      <p><span className="font-medium">Notes:</span> {fullProfile.parent.notes}</p>
                    )}
                  </div>
                </div>

                {/* Children Details */}
                <div>
                  <h4 className="font-medium text-sm mb-3">Children Details:</h4>
                  <div className="space-y-3">
                    {fullProfile.children.map((child, index) => (
                      <div key={index} className="p-4 bg-gray-50 rounded-lg space-y-2">
                        <div className="flex items-center justify-between">
                          <p className="font-medium">{child.firstName} {child.lastName}</p>
                          <Badge variant="outline">
                            {calculateAge(child.birthDate) ? `${calculateAge(child.birthDate)} years` : 'Age not specified'}
                          </Badge>
                        </div>
                        {child.specialNeeds && (
                          <div>
                            <span className="font-medium text-sm text-blue-700">Special Needs:</span>
                            <p className="text-sm mt-1 text-blue-600">{child.specialNeeds}</p>
                          </div>
                        )}
                        {child.allergies && (
                          <div>
                            <span className="font-medium text-sm text-red-700">Allergies:</span>
                            <p className="text-sm mt-1 text-red-600">{child.allergies}</p>
                          </div>
                        )}
                        {child.notes && (
                          <div>
                            <span className="font-medium text-sm">Notes:</span>
                            <p className="text-sm mt-1 text-muted-foreground">{child.notes}</p>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Emergency Contacts */}
                <div>
                  <h4 className="font-medium text-sm mb-3">Emergency Contacts:</h4>
                  <div className="space-y-3">
                    {fullProfile.emergencyContacts.map((contact, index) => (
                      <div key={index} className="p-4 bg-red-50 rounded-lg space-y-1">
                        <div className="flex items-center justify-between">
                          <p className="font-medium">{contact.name}</p>
                          <Badge variant="outline" className="text-red-700 border-red-200">
                            {contact.relationship}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">Phone: {contact.phone}</p>
                        {contact.notes && (
                          <p className="text-sm text-muted-foreground">{contact.notes}</p>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Access Note */}
                <Alert>
                  <Shield className="h-4 w-4" />
                  <AlertDescription className="text-sm">
                    {fullProfile.accessNote}
                  </AlertDescription>
                </Alert>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}