import { useEffect } from 'react';
import { Helmet } from 'react-helmet';

interface SEOProps {
  title: string;
  description: string;
  canonical?: string;
  keywords?: string;
  ogImage?: string;
  ogType?: string;
  twitterCard?: string;
  structuredData?: object;
  noindex?: boolean;
}

export default function SEO({
  title,
  description,
  canonical,
  keywords,
  ogImage = 'https://thevillageco.nz/images/village-signature.png',
  ogType = 'website',
  twitterCard = 'summary_large_image',
  structuredData,
  noindex = false
}: SEOProps) {
  const fullTitle = title.includes('Village Co') ? title : `${title} | The Village Co.`;
  const url = canonical || window.location.href;

  return (
    <Helmet>
      {/* Basic Meta Tags */}
      <title>{fullTitle}</title>
      <meta name="description" content={description} />
      {keywords && <meta name="keywords" content={keywords} />}
      <link rel="canonical" href={url} />
      
      {/* Robots */}
      {noindex && <meta name="robots" content="noindex,nofollow" />}
      
      {/* Open Graph */}
      <meta property="og:title" content={fullTitle} />
      <meta property="og:description" content={description} />
      <meta property="og:url" content={url} />
      <meta property="og:type" content={ogType} />
      <meta property="og:image" content={ogImage} />
      <meta property="og:site_name" content="The Village Co." />
      
      {/* Twitter Cards */}
      <meta name="twitter:card" content={twitterCard} />
      <meta name="twitter:title" content={fullTitle} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content={ogImage} />
      
      {/* Structured Data */}
      {structuredData && (
        <script type="application/ld+json">
          {JSON.stringify(structuredData)}
        </script>
      )}
    </Helmet>
  );
}

// High-converting SEO configurations for different page types
export const SEOConfigs = {
  homepage: {
    title: "Trusted Babysitting in New Zealand - Book Your Perfect Sitter",
    description: "Find verified, background-checked babysitters in New Zealand. Book instantly, enjoy peace of mind. Over 500 trusted sitters ready to help your family thrive.",
    keywords: "babysitter New Zealand, childcare NZ, trusted sitters, instant booking, verified babysitters, Auckland babysitting, Wellington childcare",
    structuredData: {
      "@context": "https://schema.org",
      "@type": "Service",
      "name": "The Village Co. Babysitting",
      "provider": {
        "@type": "Organization",
        "name": "The Village Co.",
        "url": "https://thevillageco.nz"
      },
      "serviceType": "Babysitting Service",
      "areaServed": "New Zealand",
      "hasOfferCatalog": {
        "@type": "OfferCatalog",
        "name": "Babysitting Services",
        "itemListElement": [
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Evening Babysitting"
            }
          },
          {
            "@type": "Offer", 
            "itemOffered": {
              "@type": "Service",
              "name": "Regular Childcare"
            }
          }
        ]
      }
    }
  },
  
  findSitter: {
    title: "Find Your Perfect Babysitter - Browse Verified Sitters Near You",
    description: "Search through our network of verified, background-checked babysitters. Filter by location, availability, and special skills. Book your trusted sitter today.",
    keywords: "find babysitter, search sitters, verified childcare, background checked babysitters, New Zealand nannies"
  },
  
  faq: {
    title: "Babysitting FAQ - Common Questions About The Village Co.",
    description: "Get answers about booking babysitters, sitter verification, payments, cancellations, and safety. Everything you need to know about trusted childcare.",
    keywords: "babysitting questions, childcare FAQ, sitter verification, booking help, payment questions"
  },
  
  sitterApplication: {
    title: "Become a Babysitter - Join New Zealand's Premier Childcare Network",
    description: "Earn $25-35/hour as a trusted babysitter. Flexible schedule, verified families, and full support. Apply to join our exclusive network of childcare professionals.",
    keywords: "babysitting jobs NZ, childcare work, earn money babysitting, flexible work, part time jobs"
  },
  
  villagePlans: {
    title: "Village Plans - Subscription Babysitting Packages",
    description: "Choose your perfect babysitting plan. From occasional care to unlimited bookings. Save money and get priority access to our best sitters.",
    keywords: "babysitting plans, subscription childcare, monthly babysitting, recurring childcare"
  },
  
  hotels: {
    title: "Hotel Babysitting Services - Premium Childcare for Guests",
    description: "Partner with The Village Co. to offer guests premium babysitting services. Vetted sitters, seamless booking, and elevated family experiences.",
    keywords: "hotel babysitting, guest childcare services, hospitality childcare, tourism babysitting"
  },
  
  employers: {
    title: "Corporate Childcare Benefits - Support Working Parents",
    description: "Enhance your employee benefits with trusted babysitting services. Help working parents thrive with flexible, reliable childcare solutions.",
    keywords: "corporate childcare, employee benefits, workplace family support, business babysitting"
  },
  
  giftSitter: {
    title: "Gift a Babysitter - Give the Gift of Time and Freedom",
    description: "Perfect for new parents, busy families, or special occasions. Gift cards for trusted babysitting services. Give someone the gift of time.",
    keywords: "babysitting gift card, childcare gifts, new parent gifts, babysitting voucher"
  },
  
  auth: {
    title: "Login or Sign Up - Access Your Village Co. Account",
    description: "Login to book trusted babysitters or access your sitter dashboard. Join thousands of families who trust The Village Co. for their childcare needs.",
    keywords: "babysitter login, childcare account, sitter sign up",
    noindex: true
  },
  
  privacyPolicy: {
    title: "Privacy Policy - How We Protect Your Family's Information",
    description: "Learn how The Village Co. protects your personal information and ensures your family's privacy and safety on our platform.",
    keywords: "privacy policy, data protection, family safety, information security"
  },
  
  termsOfService: {
    title: "Terms of Service - Platform Guidelines and Policies",
    description: "Read our terms of service to understand platform policies, user responsibilities, and service guidelines for safe babysitting experiences.",
    keywords: "terms of service, platform rules, user agreement, babysitting policies"
  }
};