import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { 
  Brain, 
  MessageSquare, 
  Calendar, 
  Shield, 
  TrendingUp, 
  Sparkles,
  Clock,
  AlertTriangle,
  CheckCircle,
  Users,
  Send,
  Heart,
  Coffee,
  Moon,
  Star,
  Briefcase,
  GraduationCap
} from "lucide-react";

interface AIAssistantProps {
  userRole: "parent" | "sitter" | "admin";
}

export default function AIAssistant({ userRole }: AIAssistantProps) {
  const [activeTab, setActiveTab] = useState("sitter-ready");
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<any>(null);
  const [workingMumMode, setWorkingMumMode] = useState(false);
  const [schoolHolidayMode, setSchoolHolidayMode] = useState(false);
  const { toast } = useToast();

  // Booking Analysis State
  const [sitNotes, setSitNotes] = useState("");
  const [duration, setDuration] = useState(3);
  const [timeOfDay, setTimeOfDay] = useState("evening");

  // Communication Helper State
  const [messageType, setMessageType] = useState("booking_request");
  const [sitterName, setSitterName] = useState("");
  const [specificContext, setSpecificContext] = useState("");

  // Smart Scheduling State
  const [requestedDate, setRequestedDate] = useState("");
  const [preferences, setPreferences] = useState("");

  // Safety Check State
  const [selectedSitterId, setSelectedSitterId] = useState("");
  const [bookingDetails, setBookingDetails] = useState("");

  const analyzeBooking = async () => {
    setLoading(true);
    try {
      const response = await apiRequest("POST", "/api/ai/analyze-booking", {
        sitNotes,
        duration,
        timeOfDay
      });

      if (response.ok) {
        const data = await response.json();
        setResults(data.analysis);
        toast({
          title: "Analysis Complete",
          description: "AI has analyzed your booking for safety and requirements.",
        });
      }
    } catch (error) {
      toast({
        title: "Analysis Failed",
        description: "Could not analyze booking. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const optimizeProfile = async () => {
    setLoading(true);
    try {
      const response = await apiRequest("POST", "/api/ai/optimize-profile");

      if (response.ok) {
        const data = await response.json();
        setResults(data.suggestions);
        toast({
          title: "Profile Suggestions Ready",
          description: "AI has analyzed your profile and provided optimization tips.",
        });
      }
    } catch (error) {
      toast({
        title: "Analysis Failed",
        description: "Could not analyze profile. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getCommunicationHelp = async () => {
    setLoading(true);
    try {
      const response = await apiRequest("POST", "/api/ai/communication-help", {
        messageType,
        sitterName,
        specificContext
      });

      if (response.ok) {
        const data = await response.json();
        setResults(data.suggestions);
        toast({
          title: "Message Suggestions Ready",
          description: "AI has created message options for you.",
        });
      }
    } catch (error) {
      toast({
        title: "Generation Failed",
        description: "Could not generate message suggestions. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const getSchedulingSuggestions = async () => {
    setLoading(true);
    try {
      const response = await apiRequest("POST", "/api/ai/smart-scheduling", {
        requestedDate,
        preferences: preferences ? preferences.split(",").map(p => p.trim()) : []
      });

      if (response.ok) {
        const data = await response.json();
        setResults(data.suggestions);
        toast({
          title: "Schedule Optimised",
          description: "AI has found the best booking times for you.",
        });
      }
    } catch (error) {
      toast({
        title: "Analysis Failed",
        description: "Could not analyze scheduling. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  // Next Break Reminder - Check if parent needs a break
  const getBreakReminder = async () => {
    setLoading(true);
    setResults(null);

    try {
      const response = await apiRequest("POST", "/api/ai/break-reminder", {});

      if (response.ok) {
        const data = await response.json();
        setResults(data.reminder);
        toast({
          title: "Break Reminder Generated",
          description: "AI analysed your booking history for personalised suggestions.",
        });
      }
    } catch (error) {
      toast({
        title: "Analysis Failed",
        description: "Could not generate break reminder. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  // Booking Pattern Analysis - Find recurring patterns
  const analyzePatterns = async () => {
    setLoading(true);
    setResults(null);

    try {
      const response = await apiRequest("POST", "/api/ai/booking-patterns", {});

      if (response.ok) {
        const data = await response.json();
        setResults(data.patterns);
        toast({
          title: "Patterns Analyzed",
          description: "AI found booking patterns and smart suggestions.",
        });
      }
    } catch (error) {
      toast({
        title: "Analysis Failed",
        description: "Could not analyze booking patterns. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  // Safety Compliance Check - Check sitter credentials and booking safety
  const checkSafety = async () => {
    if (!selectedSitterId) {
      toast({
        title: "Sitter Required",
        description: "Please select a sitter to check safety compliance.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    setResults(null);

    try {
      const response = await apiRequest("POST", "/api/ai/safety-check", {
        sitterId: parseInt(selectedSitterId),
        bookingDetails: bookingDetails ? JSON.parse(bookingDetails) : {}
      });

      if (response.ok) {
        const data = await response.json();
        setResults(data.safety);
        toast({
          title: "Safety Check Complete",
          description: "AI reviewed safety compliance for this booking.",
        });
      }
    } catch (error) {
      toast({
        title: "Safety Check Failed",
        description: "Could not complete safety analysis. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const renderBookingAnalysisResults = () => {
    if (!results) return null;

    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <Shield className="h-5 w-5" />
          <h3 className="text-lg font-semibold">Booking Analysis Results</h3>
          <Badge variant={
            results.riskLevel === "high" ? "destructive" : 
            results.riskLevel === "medium" ? "secondary" : "default"
          }>
            {results.riskLevel.toUpperCase()} RISK
          </Badge>
        </div>

        {results.specialRequirements?.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Special Requirements</CardTitle>
            </CardHeader>
            <CardContent>
              {results.specialRequirements.map((req: any, idx: number) => (
                <div key={idx} className="mb-2 p-2 bg-yellow-50 rounded-md">
                  <div className="font-medium">{req.requirement}</div>
                  <div className="text-sm text-muted-foreground">{req.recommendation}</div>
                  <Badge size="sm" variant={req.severity === "high" ? "destructive" : "secondary"}>
                    {req.severity}
                  </Badge>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {results.additionalServices?.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Recommended Additional Services</CardTitle>
            </CardHeader>
            <CardContent>
              {results.additionalServices.map((service: any, idx: number) => (
                <div key={idx} className="mb-2 p-2 bg-green-50 rounded-md">
                  <div className="font-medium">{service.service} - {service.suggestedFee}</div>
                  <div className="text-sm text-muted-foreground">{service.reason}</div>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {results.safetyConsiderations?.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Safety Considerations</CardTitle>
            </CardHeader>
            <CardContent>
              {results.safetyConsiderations.map((safety: any, idx: number) => (
                <div key={idx} className="mb-2 p-2 bg-red-50 rounded-md">
                  <div className="font-medium flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-red-500" />
                    {safety.concern}
                  </div>
                  <div className="text-sm text-muted-foreground">{safety.mitigation}</div>
                </div>
              ))}
            </CardContent>
          </Card>
        )}
      </div>
    );
  };

  const renderProfileOptimizationResults = () => {
    if (!results) return null;

    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5" />
          <h3 className="text-lg font-semibold">Profile Optimization</h3>
          <Badge variant="default">Score: {results.overallScore}/10</Badge>
        </div>

        {results.bioSuggestions?.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Bio Improvements</CardTitle>
            </CardHeader>
            <CardContent>
              {results.bioSuggestions.map((suggestion: any, idx: number) => (
                <div key={idx} className="mb-3 p-3 border rounded-md">
                  <div className="font-medium">{suggestion.suggestion}</div>
                  <div className="text-sm text-muted-foreground mt-1">{suggestion.example}</div>
                  <div className="text-xs text-green-600 mt-1">Expected: {suggestion.impact}</div>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {results.pricingAnalysis && (
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Pricing Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div>Current Rate: NZD ${results.pricingAnalysis.currentRate}/hour</div>
                <div>Suggested Range: {results.pricingAnalysis.suggestedRange}</div>
                <div className="text-sm text-muted-foreground">{results.pricingAnalysis.reasoning}</div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    );
  };

  const renderCommunicationResults = () => {
    if (!results) return null;

    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <MessageSquare className="h-5 w-5" />
          <h3 className="text-lg font-semibold">Message Suggestions</h3>
        </div>

        {results.messageOptions?.map((option: any, idx: number) => (
          <Card key={idx}>
            <CardHeader>
              <CardTitle className="text-sm capitalize">{option.tone} Tone</CardTitle>
              <CardDescription>{option.subject}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="whitespace-pre-wrap p-3 bg-gray-50 rounded-md mb-3">
                {option.message}
              </div>
              <div className="flex gap-1 flex-wrap">
                {option.tips?.map((tip: string, tipIdx: number) => (
                  <Badge key={tipIdx} variant="outline" className="text-xs">
                    {tip}
                  </Badge>
                ))}
              </div>
              <Button 
                size="sm" 
                className="mt-2"
                onClick={() => navigator.clipboard.writeText(option.message)}
              >
                Copy Message
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  };

  const renderSchedulingResults = () => {
    if (!results) return null;

    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <Calendar className="h-5 w-5" />
          <h3 className="text-lg font-semibold">Smart Scheduling Suggestions</h3>
        </div>

        {results.recommendations?.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Recommended Times</CardTitle>
            </CardHeader>
            <CardContent>
              {results.recommendations.map((rec: any, idx: number) => (
                <div key={idx} className="mb-3 p-3 border rounded-md">
                  <div className="flex items-center justify-between">
                    <div className="font-medium">{rec.timeSlot}</div>
                    <Badge>{rec.rating}/10</Badge>
                  </div>
                  <div className="mt-2">
                    <div className="text-sm font-medium text-green-600">Why this works:</div>
                    <ul className="text-sm text-muted-foreground list-disc ml-4">
                      {rec.pros?.map((pro: string, proIdx: number) => (
                        <li key={proIdx}>{pro}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {results.pricingInsights && (
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Pricing Insights</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div>Peak Times: {results.pricingInsights.peakTimes?.join(", ") || "None specified"}</div>
                <div className="text-sm text-green-600">{results.pricingInsights.savings}</div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    );
  };

  const renderBreakReminderResults = () => {
    if (!results) return null;

    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <Clock className="h-5 w-5" />
          <h3 className="text-lg font-semibold">Break Reminder Analysis</h3>
        </div>

        {results.recommendation && (
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">When to Book Your Next Break</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="font-medium text-lg">{results.recommendation}</div>
                {results.reasoning && (
                  <div className="text-sm text-muted-foreground">
                    <div className="font-medium mb-1">Why now:</div>
                    <p>{results.reasoning}</p>
                  </div>
                )}
                {results.suggestedDuration && (
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">Suggested Duration: {results.suggestedDuration}</Badge>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {results.lastBookingInsight && (
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm">{results.lastBookingInsight}</p>
            </CardContent>
          </Card>
        )}
      </div>
    );
  };

  const renderPatternsResults = () => {
    if (!results) return null;

    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <Sparkles className="h-5 w-5" />
          <h3 className="text-lg font-semibold">Booking Patterns Analysis</h3>
        </div>

        {results.patterns?.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Detected Patterns</CardTitle>
            </CardHeader>
            <CardContent>
              {results.patterns.map((pattern: any, idx: number) => (
                <div key={idx} className="mb-3 p-3 border rounded-md">
                  <div className="font-medium">{pattern.type}</div>
                  <div className="text-sm text-muted-foreground mt-1">{pattern.description}</div>
                  {pattern.confidence && (
                    <Badge variant="outline" className="mt-2">
                      {pattern.confidence}% confidence
                    </Badge>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {results.suggestions?.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Smart Suggestions</CardTitle>
            </CardHeader>
            <CardContent>
              {results.suggestions.map((suggestion: any, idx: number) => (
                <div key={idx} className="mb-3 p-3 border rounded-md">
                  <div className="font-medium">{suggestion.action}</div>
                  <div className="text-sm text-muted-foreground mt-1">{suggestion.reason}</div>
                  {suggestion.priority && (
                    <Badge variant={suggestion.priority === "high" ? "destructive" : "secondary"} className="mt-2">
                      {suggestion.priority} priority
                    </Badge>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {results.favoritesSummary && (
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Your Favorite Sitters</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm">{results.favoritesSummary}</p>
            </CardContent>
          </Card>
        )}
      </div>
    );
  };

  const renderSafetyResults = () => {
    if (!results) return null;

    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2">
          <AlertTriangle className="h-5 w-5" />
          <h3 className="text-lg font-semibold">Safety Compliance Report</h3>
          <Badge variant={
            results.overallRisk === "high" ? "destructive" : 
            results.overallRisk === "medium" ? "secondary" : "default"
          }>
            {results.overallRisk?.toUpperCase()} RISK
          </Badge>
        </div>

        {results.flags?.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Safety Flags</CardTitle>
            </CardHeader>
            <CardContent>
              {results.flags.map((flag: any, idx: number) => (
                <div key={idx} className="mb-3 p-3 border rounded-md">
                  <div className="flex items-center gap-2">
                    <div className="font-medium">{flag.category}</div>
                    <Badge variant={flag.severity === "high" ? "destructive" : "secondary"}>
                      {flag.severity}
                    </Badge>
                  </div>
                  <div className="text-sm text-muted-foreground mt-1">{flag.description}</div>
                  {flag.recommendation && (
                    <div className="text-sm font-medium text-blue-600 mt-2">
                      Recommendation: {flag.recommendation}
                    </div>
                  )}
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {results.checklist && (
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Safety Checklist</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {Object.entries(results.checklist).map(([item, status]: [string, any]) => (
                  <div key={item} className="flex items-center gap-2">
                    {status ? (
                      <CheckCircle className="h-4 w-4 text-green-600" />
                    ) : (
                      <AlertTriangle className="h-4 w-4 text-red-600" />
                    )}
                    <span className="text-sm">{item.replace(/([A-Z])/g, ' $1').trim()}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {results.recommendations?.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Safety Recommendations</CardTitle>
            </CardHeader>
            <CardContent>
              {results.recommendations.map((rec: any, idx: number) => (
                <div key={idx} className="mb-2 p-2 bg-blue-50 rounded">
                  <div className="text-sm font-medium">{rec.action}</div>
                  <div className="text-xs text-muted-foreground mt-1">{rec.reason}</div>
                </div>
              ))}
            </CardContent>
          </Card>
        )}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 md:bg-white">
      <div className="max-w-4xl mx-auto p-4 md:p-6">
        {/* Mobile-optimized hero section */}
        <div className="text-center mb-6 md:mb-8 bg-white md:bg-transparent p-6 md:p-0 rounded-lg md:rounded-none shadow-sm md:shadow-none">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Brain className="h-8 w-8 md:h-10 md:w-10 text-blue-600" />
            <Sparkles className="h-6 w-6 md:h-8 md:w-8 text-yellow-500" />
          </div>
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-3">
            Your Village Assistant 💫
          </h1>
          <p className="text-gray-600 text-sm md:text-base mb-4 leading-relaxed">
            Think of this as your personal parenting sidekick. From "Is my sitter sorted?" to "When's my next night off?" — we've got the answers that make life easier.
          </p>
          <div className="flex flex-col md:flex-row items-center gap-3 mb-4">
            <div className="inline-flex items-center px-3 py-1 rounded-full text-xs bg-[#8B4B5C] text-white">
              <Heart className="h-3 w-3 mr-1" />
              Powered by AI + Village Love
            </div>
          </div>
          
          {/* Mode Toggles */}
          <div className="flex flex-col sm:flex-row gap-4 items-center justify-center">
            <div className="flex items-center space-x-2">
              <Switch
                id="working-mum-mode"
                checked={workingMumMode}
                onCheckedChange={setWorkingMumMode}
              />
              <Label htmlFor="working-mum-mode" className="flex items-center gap-2 text-sm">
                <Briefcase className="h-4 w-4" />
                Working Mum Mode
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                id="school-holiday-mode"
                checked={schoolHolidayMode}
                onCheckedChange={setSchoolHolidayMode}
              />
              <Label htmlFor="school-holiday-mode" className="flex items-center gap-2 text-sm">
                <GraduationCap className="h-4 w-4" />
                School Holiday Mode
              </Label>
            </div>
          </div>
        </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4 md:grid-cols-7 gap-0.5 h-auto p-1 bg-gray-100 md:bg-gray-100">
          <TabsTrigger 
            value="sitter-ready" 
            className="flex flex-col md:flex-row items-center gap-1 text-xs p-3 md:p-2 min-h-[4rem] md:min-h-[2.5rem] data-[state=active]:bg-white data-[state=active]:shadow-sm"
          >
            <CheckCircle className="h-5 w-5 md:h-4 md:w-4" />
            <span className="text-xs font-medium">Is My Sitter Ready?</span>
          </TabsTrigger>
          {userRole === "sitter" && (
            <TabsTrigger 
              value="profile-optimization" 
              className="flex flex-col md:flex-row items-center gap-1 text-xs p-2 min-h-[3rem] md:min-h-[2.5rem]"
            >
              <TrendingUp className="h-4 w-4" />
              <span className="hidden xs:inline">Profile</span>
            </TabsTrigger>
          )}
          <TabsTrigger 
            value="plan-my-week" 
            className="flex flex-col md:flex-row items-center gap-1 text-xs p-3 md:p-2 min-h-[4rem] md:min-h-[2.5rem] data-[state=active]:bg-white data-[state=active]:shadow-sm"
          >
            <Calendar className="h-5 w-5 md:h-4 md:w-4" />
            <span className="text-xs font-medium">Plan My Week</span>
          </TabsTrigger>
          <TabsTrigger 
            value="message-help" 
            className="flex flex-col md:flex-row items-center gap-1 text-xs p-3 md:p-2 min-h-[4rem] md:min-h-[2.5rem] data-[state=active]:bg-white data-[state=active]:shadow-sm"
          >
            <MessageSquare className="h-5 w-5 md:h-4 md:w-4" />
            <span className="text-xs font-medium">Message Helper</span>
          </TabsTrigger>
          {userRole === "parent" && (
            <TabsTrigger 
              value="next-night-off" 
              className="flex flex-col md:flex-row items-center gap-1 text-xs p-3 md:p-2 min-h-[4rem] md:min-h-[2.5rem] data-[state=active]:bg-white data-[state=active]:shadow-sm"
            >
              <Moon className="h-5 w-5 md:h-4 md:w-4" />
              <span className="text-xs font-medium">Next Night Off?</span>
            </TabsTrigger>
          )}
          {userRole === "parent" && (
            <TabsTrigger 
              value="my-routine" 
              className="flex flex-col md:flex-row items-center gap-1 text-xs p-3 md:p-2 min-h-[4rem] md:min-h-[2.5rem] data-[state=active]:bg-white data-[state=active]:shadow-sm"
            >
              <Coffee className="h-5 w-5 md:h-4 md:w-4" />
              <span className="text-xs font-medium">What's My Routine?</span>
            </TabsTrigger>
          )}
          <TabsTrigger 
            value="safety-check" 
            className="flex flex-col md:flex-row items-center gap-1 text-xs p-2 min-h-[3rem] md:min-h-[2.5rem]"
          >
            <AlertTriangle className="h-4 w-4" />
            <span className="hidden xs:inline">Safety</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="sitter-ready" className="space-y-4 md:space-y-6 mt-4">
          <Card className="border-0 md:border shadow-none md:shadow-sm bg-white">
            <CardHeader className="pb-4 md:pb-6 px-4 md:px-6">
              <CardTitle className="text-lg md:text-xl flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-emerald-600" />
                Is My Sitter Ready? 🌟
              </CardTitle>
              <CardDescription className="text-sm md:text-base text-gray-600">
                Quick check to make sure your sitter has everything sorted. Think of it as your peace-of-mind checklist before they arrive.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 md:space-y-4 px-4 md:px-6">
              <div>
                <Label htmlFor="sit-notes" className="text-base font-medium text-gray-700">
                  Tell me about tonight's sit 💭
                </Label>
                <Textarea
                  id="sit-notes"
                  placeholder="e.g., 'Jess has a school trip Friday, please remind her to pack her lunch. Ollie skipped his nap today so might be extra tired. We're running a bit behind on dinner prep...'"
                  value={sitNotes}
                  onChange={(e) => setSitNotes(e.target.value)}
                  className="mt-2 min-h-[120px] text-base"
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="duration">Duration (hours)</Label>
                  <Input
                    id="duration"
                    type="number"
                    value={duration}
                    onChange={(e) => setDuration(parseInt(e.target.value))}
                    className="mt-1"
                  />
                </div>
                
                <div>
                  <Label htmlFor="time-of-day">Time of Day</Label>
                  <Select value={timeOfDay} onValueChange={setTimeOfDay}>
                    <SelectTrigger className="mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="morning">Morning</SelectItem>
                      <SelectItem value="afternoon">Afternoon</SelectItem>
                      <SelectItem value="evening">Evening</SelectItem>
                      <SelectItem value="overnight">Overnight</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button onClick={analyzeBooking} disabled={loading || !sitNotes.trim()}>
                {loading ? (
                  <>
                    <Sparkles className="mr-2 h-4 w-4 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Brain className="mr-2 h-4 w-4" />
                    Analyze Booking
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {activeTab === "booking-analysis" && renderBookingAnalysisResults()}
        </TabsContent>

        {userRole === "sitter" && (
          <TabsContent value="profile-optimization" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Profile Optimization</CardTitle>
                <CardDescription>
                  Get AI-powered suggestions to improve your sitter profile and increase bookings.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button onClick={optimizeProfile} disabled={loading}>
                  {loading ? (
                    <>
                      <Sparkles className="mr-2 h-4 w-4 animate-spin" />
                      Analyzing Profile...
                    </>
                  ) : (
                    <>
                      <TrendingUp className="mr-2 h-4 w-4" />
                      Analyze My Profile
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {activeTab === "profile-optimization" && renderProfileOptimizationResults()}
          </TabsContent>
        )}

        <TabsContent value="communication" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Communication Assistant</CardTitle>
              <CardDescription>
                Get help drafting professional and effective messages to sitters or parents.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="message-type">Message Type</Label>
                <Select value={messageType} onValueChange={setMessageType}>
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="booking_request">Booking Request</SelectItem>
                    <SelectItem value="follow_up">Follow Up</SelectItem>
                    <SelectItem value="special_instructions">Special Instructions</SelectItem>
                    <SelectItem value="appreciation">Thank You</SelectItem>
                    <SelectItem value="concern">Concern/Issue</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="sitter-name">Sitter Name</Label>
                <Input
                  id="sitter-name"
                  placeholder="Sarah"
                  value={sitterName}
                  onChange={(e) => setSitterName(e.target.value)}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="specific-context">Specific Context (Optional)</Label>
                <Textarea
                  id="specific-context"
                  placeholder="Any specific details or context for this message..."
                  value={specificContext}
                  onChange={(e) => setSpecificContext(e.target.value)}
                  className="mt-1"
                />
              </div>

              <Button onClick={getCommunicationHelp} disabled={loading || !sitterName.trim()}>
                {loading ? (
                  <>
                    <Sparkles className="mr-2 h-4 w-4 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Send className="mr-2 h-4 w-4" />
                    Generate Messages
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {activeTab === "communication" && renderCommunicationResults()}
        </TabsContent>

        <TabsContent value="scheduling" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Smart Scheduling</CardTitle>
              <CardDescription>
                Get AI recommendations for optimal booking times based on your patterns and preferences.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="requested-date">Requested Date</Label>
                <Input
                  id="requested-date"
                  type="date"
                  value={requestedDate}
                  onChange={(e) => setRequestedDate(e.target.value)}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="preferences">Preferences (comma-separated)</Label>
                <Input
                  id="preferences"
                  placeholder="morning slots, weekend preferred, 2+ hours"
                  value={preferences}
                  onChange={(e) => setPreferences(e.target.value)}
                  className="mt-1"
                />
              </div>

              <Button onClick={getSchedulingSuggestions} disabled={loading}>
                {loading ? (
                  <>
                    <Sparkles className="mr-2 h-4 w-4 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Clock className="mr-2 h-4 w-4" />
                    Get Schedule Suggestions
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {activeTab === "scheduling" && renderSchedulingResults()}
        </TabsContent>

        {userRole === "parent" && (
          <TabsContent value="break-reminder" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Next Break Reminder</CardTitle>
                <CardDescription>
                  AI analyzes your booking history to suggest when you might need your next break.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button onClick={getBreakReminder} disabled={loading}>
                  {loading ? (
                    <>
                      <Sparkles className="mr-2 h-4 w-4 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Clock className="mr-2 h-4 w-4" />
                      Check My Break Schedule
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {activeTab === "break-reminder" && renderBreakReminderResults()}
          </TabsContent>
        )}

        {userRole === "parent" && (
          <TabsContent value="patterns" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Booking Pattern Analysis</CardTitle>
                <CardDescription>
                  Discover patterns in your booking history and get smart suggestions for repeat bookings.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button onClick={analyzePatterns} disabled={loading}>
                  {loading ? (
                    <>
                      <Sparkles className="mr-2 h-4 w-4 animate-spin" />
                      Analyzing Patterns...
                    </>
                  ) : (
                    <>
                      <Sparkles className="mr-2 h-4 w-4" />
                      Analyze My Patterns
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {activeTab === "patterns" && renderPatternsResults()}
          </TabsContent>
        )}

        <TabsContent value="safety-check" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Safety & Compliance Check</CardTitle>
              <CardDescription>
                AI reviews sitter credentials and booking safety to flag any missing requirements.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="sitter-id">Select Sitter ID</Label>
                <Input
                  id="sitter-id"
                  type="number"
                  placeholder="Enter sitter ID (e.g., 1, 2, 3)"
                  value={selectedSitterId}
                  onChange={(e) => setSelectedSitterId(e.target.value)}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="booking-details">Booking Details (Optional)</Label>
                <Textarea
                  id="booking-details"
                  placeholder='Optional JSON format: {"duration": 4, "children": [{"name": "Emma", "allergies": "peanuts"}]}'
                  value={bookingDetails}
                  onChange={(e) => setBookingDetails(e.target.value)}
                  className="mt-1"
                />
              </div>

              <Button onClick={checkSafety} disabled={loading || !selectedSitterId}>
                {loading ? (
                  <>
                    <Sparkles className="mr-2 h-4 w-4 animate-spin" />
                    Checking Safety...
                  </>
                ) : (
                  <>
                    <AlertTriangle className="mr-2 h-4 w-4" />
                    Run Safety Check
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {activeTab === "safety-check" && renderSafetyResults()}
        </TabsContent>
      </Tabs>
      </div>
    </div>
  );
}