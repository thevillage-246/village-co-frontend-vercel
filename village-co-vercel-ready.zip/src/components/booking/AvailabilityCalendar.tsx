import React, { useState, useEffect } from 'react';
import { addDays, format, getDay, startOfWeek, isSameDay } from 'date-fns';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useAuth } from '@/contexts/AuthContext';
import { apiRequest } from '@/lib/queryClient';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Clock, Plus, Trash2, Calendar as CalendarIcon, Grid3X3, List, Share2, Copy, QrCode, MessageCircle, Mail } from 'lucide-react';
import { cn } from '@/lib/utils';

// Generate time options from 7 AM to 11 PM
const generateTimeOptions = () => {
  const options = [];
  for (let hour = 7; hour <= 23; hour++) {
    for (let minute of [0, 30]) {
      const formattedHour = hour.toString().padStart(2, '0');
      const formattedMinute = minute.toString().padStart(2, '0');
      const time24 = `${formattedHour}:${formattedMinute}`;
      
      const hour12 = hour % 12 || 12;
      const amPm = hour < 12 ? 'AM' : 'PM';
      const label = `${hour12}:${formattedMinute === '00' ? '00' : '30'} ${amPm}`;
      
      options.push({ value: time24, label });
    }
  }
  return options;
};

const TIME_OPTIONS = generateTimeOptions();

const availabilitySchema = z.object({
  dayOfWeek: z.coerce.number().min(0).max(6),
  startTime: z.string().regex(/^\d{2}:\d{2}$/, { message: "Invalid time format" }),
  endTime: z.string().regex(/^\d{2}:\d{2}$/, { message: "Invalid time format" }),
}).refine(data => data.startTime < data.endTime, {
  message: "End time must be after start time",
  path: ["endTime"],
});

type AvailabilityFormValues = z.infer<typeof availabilitySchema>;

const DAYS_OF_WEEK = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

interface Availability {
  id: number;
  sitterId: number;
  dayOfWeek: number;
  startTime: string;
  endTime: string;
}

interface AvailabilityCalendarProps {
  sitterProfile?: any;
}

const AvailabilityCalendar: React.FC<AvailabilityCalendarProps> = ({ sitterProfile }) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [sitterId, setSitterId] = useState<number | null>(null);

  // Update sitterId when sitterProfile changes
  useEffect(() => {
    if (sitterProfile && sitterProfile.id) {
      setSitterId(sitterProfile.id);
    }
  }, [sitterProfile]);

  // Fetch availability
  const { data: availability, isLoading: loadingAvailability } = useQuery({
    queryKey: [`/api/sitters/${sitterId}/availability`],
    enabled: !!sitterId,
  });

  const form = useForm<AvailabilityFormValues>({
    resolver: zodResolver(availabilitySchema),
    defaultValues: {
      dayOfWeek: 1, // Monday by default
      startTime: "09:00",
      endTime: "17:00",
    },
  });

  const addAvailability = useMutation({
    mutationFn: async (values: AvailabilityFormValues) => {
      const response = await apiRequest('POST', `/api/sitters/${sitterId}/availability`, values);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/sitters/${sitterId}/availability`] });
      form.reset({
        dayOfWeek: form.getValues().dayOfWeek,
        startTime: "09:00",
        endTime: "17:00",
      });
      toast({
        title: "Availability Added",
        description: "Your availability has been updated successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to Add Availability",
        description: error.message || "Something went wrong.",
        variant: "destructive",
      });
    },
  });

  const deleteAvailability = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest('DELETE', `/api/availability/${id}`, null);
      return response.ok;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/sitters/${sitterId}/availability`] });
      toast({
        title: "Availability Removed",
        description: "Your availability has been updated successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to Remove Availability",
        description: error.message || "Something went wrong.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (values: AvailabilityFormValues) => {
    addAvailability.mutate(values);
  };

  const handleDelete = (id: number) => {
    deleteAvailability.mutate(id);
  };

  if (!sitterProfile) {
    return (
      <div className="flex justify-center p-8">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!sitterProfile) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <p className="text-destructive">Sitter profile not found. Please complete your profile first.</p>
        </CardContent>
      </Card>
    );
  }

  // Group availability by day of week
  const availabilityByDay: Record<number, Availability[]> = {};
  if (availability) {
    availability.forEach((slot: Availability) => {
      if (!availabilityByDay[slot.dayOfWeek]) {
        availabilityByDay[slot.dayOfWeek] = [];
      }
      availabilityByDay[slot.dayOfWeek].push(slot);
    });
  }

  // Generate shareable link for availability
  const generateShareableLink = () => {
    const baseUrl = window.location.origin;
    return `${baseUrl}/sitter/${sitterId}/availability`;
  };

  // Generate availability summary text
  const generateAvailabilityText = () => {
    if (!availability || availability.length === 0) {
      return "I'm currently updating my availability. Please check back soon!";
    }

    const groupedAvailability = availabilityByDay;
    const availableDays = [];

    DAYS_OF_WEEK.forEach((day, index) => {
      if (groupedAvailability[index] && groupedAvailability[index].length > 0) {
        const slots = groupedAvailability[index].map(slot => {
          const formatTime = (time24: string) => {
            const [hour, minute] = time24.split(':').map(Number);
            const period = hour >= 12 ? 'PM' : 'AM';
            const hour12 = hour % 12 || 12;
            return `${hour12}:${minute.toString().padStart(2, '0')}${period}`;
          };
          return `${formatTime(slot.startTime)}-${formatTime(slot.endTime)}`;
        }).join(', ');
        availableDays.push(`${day}: ${slots}`);
      }
    });

    return availableDays.length > 0 
      ? `My weekly availability:\n\n${availableDays.join('\n')}\n\nBook with me through The Village Co: ${generateShareableLink()}`
      : "I'm currently updating my availability. Please check back soon!";
  };

  // Copy to clipboard function
  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({
        title: "Copied to clipboard",
        description: "Share link copied successfully!",
      });
    } catch (err) {
      toast({
        title: "Copy failed",
        description: "Please copy the link manually.",
        variant: "destructive",
      });
    }
  };

  // Share via native share API
  const shareNative = async () => {
    const text = generateAvailabilityText();
    const url = generateShareableLink();
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'My Babysitting Availability',
          text: text,
          url: url,
        });
      } catch (err) {
        // User cancelled or share failed
        copyToClipboard(url);
      }
    } else {
      copyToClipboard(url);
    }
  };

  // Generate QR code data URL
  const generateQRCode = () => {
    const url = generateShareableLink();
    // Simple QR code generation using a QR code API
    return `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(url)}`;
  };

  const ShareDialog = () => (
    <Dialog>
      <DialogTrigger asChild>
        <Button
          variant="outline"
          className="bg-village-wine text-white hover:bg-village-wine/90 border-village-wine"
        >
          <Share2 className="h-4 w-4 mr-2" />
          Share Availability
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Share2 className="h-5 w-5 text-village-wine" />
            Share Your Availability
          </DialogTitle>
          <DialogDescription>
            Share your weekly schedule with parents
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4">
          {/* Share Link */}
          <div className="space-y-2">
            <label className="text-sm font-medium">Share Link</label>
            <div className="flex gap-2">
              <input
                type="text"
                value={generateShareableLink()}
                readOnly
                className="flex-1 px-3 py-2 text-sm bg-gray-50 border rounded-md"
              />
              <Button
                size="sm"
                onClick={() => copyToClipboard(generateShareableLink())}
              >
                <Copy className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Quick Share Options */}
          <div className="space-y-3">
            <label className="text-sm font-medium">Quick Share</label>
            <div className="grid grid-cols-2 gap-2">
              <Button
                variant="outline"
                onClick={() => copyToClipboard(generateShareableLink())}
                className="flex items-center gap-2"
              >
                <Copy className="h-4 w-4" />
                Copy
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  // Navigate to messages page with pre-filled availability text
                  const text = generateAvailabilityText();
                  const url = `/messages?prefill=${encodeURIComponent(text)}`;
                  window.location.href = url;
                }}
                className="flex items-center gap-2"
              >
                <MessageCircle className="h-4 w-4" />
                Send to Parent
              </Button>
            </div>
          </div>

          {/* QR Code */}
          <div className="space-y-2">
            <label className="text-sm font-medium">QR Code</label>
            <div className="flex justify-center p-4 bg-gray-50 rounded-md">
              <img
                src={generateQRCode()}
                alt="QR Code for availability"
                className="w-32 h-32"
              />
            </div>
            <p className="text-xs text-muted-foreground text-center">
              Parents can scan this code to view your availability
            </p>
          </div>

          {/* Preview Text */}
          <div className="space-y-2">
            <label className="text-sm font-medium">Message Preview</label>
            <textarea
              value={generateAvailabilityText()}
              readOnly
              className="w-full h-24 px-3 py-2 text-sm bg-gray-50 border rounded-md resize-none"
            />
            <Button
              size="sm"
              variant="outline"
              onClick={() => copyToClipboard(generateAvailabilityText())}
              className="w-full"
            >
              <Copy className="h-4 w-4 mr-2" />
              Copy Message
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );

  const CalendarGridView = () => (
    <div className="space-y-6">
      {/* Calendar Grid */}
      <div className="grid grid-cols-7 gap-2 md:gap-4">
        {DAYS_OF_WEEK.map((day, index) => (
          <div key={index} className="min-h-[200px]">
            {/* Day Header */}
            <div className="bg-village-wine text-white text-center py-2 rounded-t-lg font-medium text-sm">
              {day}
            </div>
            
            {/* Day Content */}
            <div className="border border-t-0 rounded-b-lg p-2 min-h-[180px] bg-white">
              {availabilityByDay[index] && availabilityByDay[index].length > 0 ? (
                <div className="space-y-2">
                  {availabilityByDay[index].map((slot) => {
                    const formatTime = (time24: string) => {
                      const [hour, minute] = time24.split(':').map(Number);
                      const period = hour >= 12 ? 'PM' : 'AM';
                      const hour12 = hour % 12 || 12;
                      return `${hour12}:${minute.toString().padStart(2, '0')}${period}`;
                    };
                    
                    return (
                      <div 
                        key={slot.id}
                        className="bg-brushed-pink/20 border border-brushed-pink rounded p-2 text-xs group hover:bg-brushed-pink/30 transition-colors"
                      >
                        <div className="flex items-center justify-between">
                          <div className="text-village-wine font-medium">
                            {formatTime(slot.startTime)} - {formatTime(slot.endTime)}
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity"
                            onClick={() => handleDelete(slot.id)}
                          >
                            <Trash2 className="h-3 w-3 text-destructive" />
                          </Button>
                        </div>
                      </div>
                    );
                  })}
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full h-6 text-xs text-village-wine hover:bg-village-wine/10"
                    onClick={() => form.setValue('dayOfWeek', index)}
                  >
                    <Plus className="h-3 w-3 mr-1" />
                    Add More
                  </Button>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-full text-center">
                  <div className="text-gray-400 text-xs mb-2">Not available</div>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 text-xs text-village-wine hover:bg-village-wine/10"
                    onClick={() => form.setValue('dayOfWeek', index)}
                  >
                    <Plus className="h-3 w-3 mr-1" />
                    Add Hours
                  </Button>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="space-y-8">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-village-wine" />
                Add Availability
              </CardTitle>
              <CardDescription>
                Set your weekly recurring availability. Clients will only be able to book during these times.
              </CardDescription>
            </div>
            <ShareDialog />
          </div>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="dayOfWeek"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Day</FormLabel>
                      <Select 
                        onValueChange={(value) => field.onChange(parseInt(value))} 
                        value={field.value.toString()}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select day" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {DAYS_OF_WEEK.map((day, index) => (
                            <SelectItem key={index} value={index.toString()}>
                              {day}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="startTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Start Time</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select start time" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {TIME_OPTIONS.map((option) => (
                            <SelectItem key={`start-${option.value}`} value={option.value}>
                              {option.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="endTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>End Time</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select end time" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {TIME_OPTIONS.map((option) => (
                            <SelectItem key={`end-${option.value}`} value={option.value}>
                              {option.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <Button 
                type="submit" 
                disabled={addAvailability.isPending}
                className="w-full md:w-auto bg-village-wine hover:bg-village-wine/90"
              >
                {addAvailability.isPending ? 'Adding...' : 'Add Availability'}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CalendarIcon className="h-5 w-5 text-village-wine" />
            Your Weekly Availability
          </CardTitle>
          <CardDescription>
            This is your current weekly schedule. You can remove any time slots that no longer work for you.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {loadingAvailability ? (
            <div className="flex justify-center p-4">
              <div className="animate-spin h-6 w-6 border-4 border-village-wine border-t-transparent rounded-full"></div>
            </div>
          ) : !availability || availability.length === 0 ? (
            <div className="text-center p-8 text-muted-foreground">
              <CalendarIcon className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p className="text-lg font-medium mb-2">No availability set</p>
              <p className="text-sm">Add your available time slots above to get started.</p>
            </div>
          ) : (
            <Tabs defaultValue="grid" className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="grid" className="flex items-center gap-2">
                  <Grid3X3 className="h-4 w-4" />
                  Calendar View
                </TabsTrigger>
                <TabsTrigger value="list" className="flex items-center gap-2">
                  <List className="h-4 w-4" />
                  List View
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="grid">
                <CalendarGridView />
              </TabsContent>
              
              <TabsContent value="list">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Day</TableHead>
                      <TableHead>Hours</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {DAYS_OF_WEEK.map((day, index) => (
                      <TableRow key={index} className={cn(index % 2 === 0 ? 'bg-muted/50' : '')}>
                        <TableCell className="font-medium">{day}</TableCell>
                        <TableCell>
                          {availabilityByDay[index] && availabilityByDay[index].length > 0 ? (
                            <div className="flex flex-wrap gap-2">
                              {availabilityByDay[index].map((slot) => {
                                // Convert 24-hour time to 12-hour format
                                const formatTime = (time24: string) => {
                                  const [hour, minute] = time24.split(':').map(Number);
                                  const period = hour >= 12 ? 'PM' : 'AM';
                                  const hour12 = hour % 12 || 12;
                                  return `${hour12}:${minute.toString().padStart(2, '0')} ${period}`;
                                };
                                
                                const startFormatted = formatTime(slot.startTime);
                                const endFormatted = formatTime(slot.endTime);
                                
                                return (
                                  <Badge 
                                    key={slot.id} 
                                    variant="outline"
                                    className="flex items-center gap-1 p-2 border-brushed-pink text-village-wine"
                                  >
                                    <span>{startFormatted} - {endFormatted}</span>
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="h-4 w-4 text-muted-foreground hover:text-destructive"
                                      onClick={() => handleDelete(slot.id)}
                                    >
                                      <Trash2 className="h-3 w-3" />
                                    </Button>
                                  </Badge>
                                );
                              })}
                            </div>
                          ) : (
                            <span className="text-muted-foreground text-sm">Not available</span>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 text-village-wine hover:bg-village-wine/10"
                            onClick={() => {
                              // Set day in the form for quick adding
                              form.setValue('dayOfWeek', index);
                            }}
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            Add Time
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TabsContent>
            </Tabs>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default AvailabilityCalendar;
