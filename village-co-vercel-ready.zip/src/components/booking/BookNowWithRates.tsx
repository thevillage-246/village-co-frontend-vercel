import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { CalendarIcon, Clock, Loader2 } from "lucide-react";
import { format } from "date-fns";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { createClient } from "@supabase/supabase-js";
import { useAuth } from "@/contexts/AuthContext";
import BookingConfirmationModal from "./BookingConfirmationModal";

interface BookNowWithRatesProps {
  sitterId: number;
  sitterName?: string;
}

export default function BookNowWithRates({ sitterId, sitterName = "Sitter" }: BookNowWithRatesProps) {
  const [date, setDate] = useState<Date | undefined>(undefined);
  const [startTime, setStartTime] = useState<string>("");
  const [endTime, setEndTime] = useState<string>("");
  const [selectedRate, setSelectedRate] = useState<{ id: number; label: string; value: number } | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [isBooking, setIsBooking] = useState(false);
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { session } = useAuth();

  // Fetch sitter rates
  const { data: rates, isLoading, error } = useQuery({
    queryKey: ['/api/sitters', sitterId, 'rates'],
    queryFn: async () => 
      apiRequest(`GET`, `/api/sitters/${sitterId}/rates`).then(res => res.json()),
  });

  // Generate time options for select dropdown
  const generateTimeOptions = () => {
    const times = [];
    for (let hour = 0; hour < 24; hour++) {
      for (let minute of ['00', '30']) {
        const time = `${hour.toString().padStart(2, '0')}:${minute}`;
        times.push(time);
      }
    }
    return times;
  };

  const timeOptions = generateTimeOptions();

  const handleProceedToConfirm = () => {
    if (!date || !startTime || !endTime || !selectedRate) {
      toast({
        title: "Missing information",
        description: "Please select a date, time, and rate for your booking.",
        variant: "destructive",
      });
      return;
    }

    // Validate that endTime is after startTime
    if (startTime >= endTime) {
      toast({
        title: "Invalid time selection",
        description: "End time must be after start time.",
        variant: "destructive",
      });
      return;
    }

    setShowModal(true);
  };

  const handleBookingConfirm = async () => {
    if (!session || !session.user || !date || !startTime || !endTime || !selectedRate) {
      toast({
        title: "Cannot complete booking",
        description: "Please ensure you're logged in and all booking details are provided.",
        variant: "destructive",
      });
      return;
    }

    setIsBooking(true);

    try {
      // Initialize Supabase client
      const supabase = createClient(
        import.meta.env.VITE_SUPABASE_URL || "",
        import.meta.env.VITE_SUPABASE_ANON_KEY || ""
      );

      // Create Date objects for start and end times
      const startDateTime = new Date(date);
      const [startHour, startMinute] = startTime.split(':').map(Number);
      startDateTime.setHours(startHour, startMinute);

      const endDateTime = new Date(date);
      const [endHour, endMinute] = endTime.split(':').map(Number);
      endDateTime.setHours(endHour, endMinute);

      // Get parent profile ID from authenticated user
      const { data: parentProfile, error: parentError } = await supabase
        .from('parent_profiles')
        .select('id')
        .eq('userId', session.user.id)
        .single();

      if (parentError || !parentProfile) {
        throw new Error('Parent profile not found. Please complete your profile first.');
      }

      // Insert the booking into the database with correct INTEGER foreign keys
      const { data, error } = await supabase.from('bookings').insert({
        parent_id: parentProfile.id,    // Profile ID (integer)
        sitter_id: sitterId,           // Sitter profile ID (integer)
        start_time: startDateTime.toISOString(),
        end_time: endDateTime.toISOString(),
        status: 'pending'
      });

      if (error) throw error;

      // Send notification to the sitter
      try {
        // Get sitter user details to find their phone number
        const { data: sitterProfile } = await supabase
          .from('sitter_profiles')
          .select('userId')
          .eq('id', sitterId)
          .single();

        if (sitterProfile) {
          const { data: sitterData } = await supabase
            .from('users')
            .select('phone')
            .eq('id', sitterProfile.userId)
            .single();

          if (sitterData && sitterData.phone) {
            // Send notification via Supabase Function
            await fetch('/functions/v1/notify-booking', {
              method: 'POST',
              body: JSON.stringify({
                sitter_id: sitterId,
                sitter_phone: sitterData.phone,
                title: 'New Booking Request!',
                body: 'You\'ve been requested for a sit — check your dashboard.'
              })
            });
          }
        }
      } catch (notificationError) {
        console.error("Failed to send notification", notificationError);
        // We don't want to fail the booking if just the notification fails
      }

      // Show success message
      toast({
        title: "Booking Requested",
        description: "Your booking request has been sent to the sitter.",
      });

      // Navigate to booking confirmation page
      navigate("/booking-confirmed");
    } catch (error) {
      console.error("Booking error:", error);
      toast({
        title: "Booking Failed",
        description: "There was a problem creating your booking. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsBooking(false);
      setShowModal(false);
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="flex justify-center items-center p-6">
          <Loader2 className="h-6 w-6 animate-spin text-wine" />
        </CardContent>
      </Card>
    );
  }

  if (error || !rates || rates.length === 0) {
    return (
      <Card>
        <CardContent className="p-6">
          <p className="text-center text-muted-foreground">
            Rate information is not available at this time.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card className="bg-white">
        <CardHeader className="pb-3">
          <CardTitle className="text-xl font-semibold text-wine">Book a Session</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="date">Date</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !date && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {date ? format(date, "PPP") : "Select a date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={setDate}
                  initialFocus
                  disabled={(date) => date < new Date(new Date().setHours(0, 0, 0, 0))}
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="startTime">Start Time</Label>
              <Select value={startTime} onValueChange={setStartTime}>
                <SelectTrigger id="startTime" className="w-full">
                  <SelectValue placeholder="Select start time">
                    {startTime || "Select start time"}
                  </SelectValue>
                </SelectTrigger>
                <SelectContent>
                  {timeOptions.map((time) => (
                    <SelectItem key={`start-${time}`} value={time}>
                      {time}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="endTime">End Time</Label>
              <Select value={endTime} onValueChange={setEndTime}>
                <SelectTrigger id="endTime" className="w-full">
                  <SelectValue placeholder="Select end time">
                    {endTime || "Select end time"}
                  </SelectValue>
                </SelectTrigger>
                <SelectContent>
                  {timeOptions.map((time) => (
                    <SelectItem key={`end-${time}`} value={time}>
                      {time}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2 pt-2">
            <Label htmlFor="rate">Select Rate</Label>
            <Select
              value={selectedRate ? String(selectedRate.id) : ""}
              onValueChange={(value) => {
                const selected = rates.find((rate: any) => rate.id.toString() === value);
                if (selected) {
                  setSelectedRate({
                    id: selected.id,
                    label: selected.label,
                    value: selected.value
                  });
                }
              }}
            >
              <SelectTrigger id="rate" className="w-full">
                <SelectValue placeholder="Select a rate">
                  {selectedRate ? (
                    <div className="flex items-center justify-between w-full">
                      <span>{selectedRate.label}</span>
                      <span className="font-medium">${parseFloat(selectedRate.value).toFixed(2)}/hr</span>
                    </div>
                  ) : (
                    "Select a rate"
                  )}
                </SelectValue>
              </SelectTrigger>
              <SelectContent>
                {rates.map((rate: any) => (
                  <SelectItem key={rate.id} value={String(rate.id)}>
                    <div className="flex items-center justify-between w-full">
                      <span>{rate.label}</span>
                      <span className="font-medium">${parseFloat(rate.value).toFixed(2)}/hr</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="pt-4">
            <Button 
              className="w-full bg-wine hover:bg-wine/90 text-white"
              disabled={!date || !startTime || !endTime || !selectedRate}
              onClick={handleProceedToConfirm}
            >
              <Clock className="mr-2 h-4 w-4" />
              Book Now
            </Button>
          </div>

          <p className="text-xs text-muted-foreground text-center pt-2">
            By booking, you agree to our terms and conditions.
          </p>
        </CardContent>
      </Card>

      {showModal && selectedRate && (
        <BookingConfirmationModal
          sitterName={sitterName}
          rateLabel={selectedRate.label}
          rateValue={selectedRate.value}
          bookingDate={date ? format(date, "PPP") : ""}
          startTime={startTime}
          endTime={endTime}
          onConfirm={handleBookingConfirm}
          onCancel={() => setShowModal(false)}
          isLoading={isBooking}
        />
      )}
    </>
  );
}