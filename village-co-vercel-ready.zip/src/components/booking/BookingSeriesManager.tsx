import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { format } from 'date-fns';
import { 
  Calendar, 
  Clock, 
  Repeat, 
  Pause, 
  Play, 
  CheckCircle, 
  XCircle, 
  Settings,
  MessageCircle,
  Eye,
  MoreHorizontal
} from 'lucide-react';

interface BookingSeries {
  id: string;
  title: string;
  sitter: {
    id: number;
    name: string;
    photoUrl?: string;
    hourlyRate: string;
  };
  daysOfWeek: number[];
  startTime: string;
  endTime: string;
  startDate: string;
  endDate: string;
  status: string;
  totalBookings: number;
  confirmedBookings: number;
  isApproved: boolean;
  pausedAt?: string;
  pauseReason?: string;
  createdAt: string;
}

const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

export default function BookingSeriesManager() {
  const [selectedSeries, setSelectedSeries] = useState<BookingSeries | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: bookingSeries, isLoading } = useQuery({
    queryKey: ['/api/booking-series'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/booking-series');
      return response.json();
    },
  });

  const pauseSeriesMutation = useMutation({
    mutationFn: async ({ seriesId, reason }: { seriesId: string; reason: string }) => {
      const response = await apiRequest('POST', `/api/booking-series/${seriesId}/pause`, { reason });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/booking-series'] });
      toast({
        title: "Series Paused",
        description: "Your recurring booking series has been paused.",
      });
    },
  });

  const resumeSeriesMutation = useMutation({
    mutationFn: async (seriesId: string) => {
      const response = await apiRequest('POST', `/api/booking-series/${seriesId}/resume`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/booking-series'] });
      toast({
        title: "Series Resumed",
        description: "Your recurring booking series has been resumed.",
      });
    },
  });

  const cancelSeriesMutation = useMutation({
    mutationFn: async (seriesId: string) => {
      const response = await apiRequest('DELETE', `/api/booking-series/${seriesId}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/booking-series'] });
      toast({
        title: "Series Cancelled",
        description: "Your recurring booking series has been cancelled.",
      });
    },
  });

  const getStatusColor = (status: string, isApproved: boolean) => {
    if (status === 'paused') return 'bg-orange-100 text-orange-800';
    if (status === 'cancelled') return 'bg-red-100 text-red-800';
    if (!isApproved) return 'bg-yellow-100 text-yellow-800';
    if (status === 'active') return 'bg-green-100 text-green-800';
    return 'bg-gray-100 text-gray-800';
  };

  const getStatusText = (status: string, isApproved: boolean) => {
    if (status === 'paused') return 'Paused';
    if (status === 'cancelled') return 'Cancelled';
    if (!isApproved) return 'Pending Approval';
    if (status === 'active') return 'Active';
    return 'Pending';
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-village-wine">Your Recurring Bookings</h2>
          <p className="text-muted-foreground">Manage your regular childcare sessions</p>
        </div>
      </div>

      {!bookingSeries?.series || bookingSeries.series.length === 0 ? (
        <Card>
          <CardContent className="text-center py-8">
            <Repeat className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-medium mb-2">No Recurring Bookings</h3>
            <p className="text-muted-foreground mb-4">
              Set up regular sessions with your favourite sitters
            </p>
            <Button onClick={() => window.location.href = '/find-sitter?recurring=true'}>
              Create Recurring Booking
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {bookingSeries.series.map((series: BookingSeries) => (
            <Card key={series.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={series.sitter.photoUrl} />
                      <AvatarFallback className="bg-village-wine text-white">
                        {series.sitter.name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <CardTitle className="text-lg">{series.title}</CardTitle>
                      <CardDescription>
                        with {series.sitter.name} • ${series.sitter.hourlyRate}/hour
                      </CardDescription>
                    </div>
                  </div>
                  <Badge className={getStatusColor(series.status, series.isApproved)}>
                    {getStatusText(series.status, series.isApproved)}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Schedule Info */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 text-village-wine mr-2" />
                    <span>
                      {series.daysOfWeek.map(day => dayNames[day].slice(0, 3)).join(', ')}
                    </span>
                  </div>
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 text-village-wine mr-2" />
                    <span>{series.startTime} - {series.endTime}</span>
                  </div>
                  <div className="flex items-center">
                    <Repeat className="h-4 w-4 text-village-wine mr-2" />
                    <span>
                      {format(new Date(series.startDate), 'MMM d')} - {format(new Date(series.endDate), 'MMM d')}
                    </span>
                  </div>
                </div>

                {/* Progress */}
                <div className="bg-muted rounded-lg p-3">
                  <div className="flex justify-between text-sm mb-2">
                    <span>Progress</span>
                    <span>{series.confirmedBookings} of {series.totalBookings} sessions</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-village-wine h-2 rounded-full transition-all"
                      style={{ width: `${(series.confirmedBookings / series.totalBookings) * 100}%` }}
                    />
                  </div>
                </div>

                {/* Pause Reason */}
                {series.pausedAt && series.pauseReason && (
                  <div className="bg-orange-50 border border-orange-200 rounded-lg p-3">
                    <div className="flex items-center text-orange-800">
                      <Pause className="h-4 w-4 mr-2" />
                      <span className="font-medium">Paused: </span>
                      <span className="ml-1">{series.pauseReason}</span>
                    </div>
                    <p className="text-xs text-orange-600 mt-1">
                      Since {format(new Date(series.pausedAt), 'MMM d, yyyy')}
                    </p>
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex gap-2 pt-2">
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm" onClick={() => setSelectedSeries(series)}>
                        <Eye className="h-4 w-4 mr-1" />
                        View Details
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl">
                      <DialogHeader>
                        <DialogTitle>Booking Series Details</DialogTitle>
                      </DialogHeader>
                      {selectedSeries && <SeriesDetailsView series={selectedSeries} />}
                    </DialogContent>
                  </Dialog>

                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => window.location.href = `/messages?sitter=${series.sitter.id}`}
                  >
                    <MessageCircle className="h-4 w-4 mr-1" />
                    Message
                  </Button>

                  {series.status === 'paused' ? (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => resumeSeriesMutation.mutate(series.id)}
                      disabled={resumeSeriesMutation.isPending}
                    >
                      <Play className="h-4 w-4 mr-1" />
                      Resume
                    </Button>
                  ) : series.status === 'active' ? (
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm">
                          <Pause className="h-4 w-4 mr-1" />
                          Pause
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Pause Booking Series</DialogTitle>
                        </DialogHeader>
                        <PauseSeriesDialog 
                          seriesId={series.id}
                          onPause={(reason) => pauseSeriesMutation.mutate({ seriesId: series.id, reason })}
                        />
                      </DialogContent>
                    </Dialog>
                  ) : null}

                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="outline" size="sm" className="text-red-600 hover:text-red-700">
                        <XCircle className="h-4 w-4 mr-1" />
                        Cancel
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Cancel Booking Series</AlertDialogTitle>
                        <AlertDialogDescription>
                          This will cancel all future sessions in "{series.title}". 
                          This action cannot be undone.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Keep Series</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => cancelSeriesMutation.mutate(series.id)}
                          className="bg-red-600 hover:bg-red-700"
                        >
                          Cancel Series
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

function SeriesDetailsView({ series }: { series: BookingSeries }) {
  const { data: bookings } = useQuery({
    queryKey: ['/api/booking-series', series.id, 'bookings'],
    queryFn: async () => {
      const response = await apiRequest('GET', `/api/booking-series/${series.id}/bookings`);
      return response.json();
    },
  });

  return (
    <div className="space-y-6">
      {/* Series Overview */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <h4 className="font-medium mb-2">Schedule</h4>
          <p className="text-sm text-muted-foreground">
            {series.daysOfWeek.map(day => dayNames[day]).join(', ')}
          </p>
          <p className="text-sm text-muted-foreground">
            {series.startTime} - {series.endTime}
          </p>
        </div>
        <div>
          <h4 className="font-medium mb-2">Duration</h4>
          <p className="text-sm text-muted-foreground">
            {format(new Date(series.startDate), 'MMM d, yyyy')} - {format(new Date(series.endDate), 'MMM d, yyyy')}
          </p>
        </div>
      </div>

      {/* Individual Bookings */}
      <div>
        <h4 className="font-medium mb-3">Individual Sessions</h4>
        <div className="max-h-64 overflow-y-auto space-y-2">
          {bookings?.bookings?.map((booking: any, index: number) => (
            <div key={booking.id} className="flex items-center justify-between p-3 bg-muted rounded-lg">
              <div>
                <p className="font-medium">Session {index + 1}</p>
                <p className="text-sm text-muted-foreground">
                  {format(new Date(booking.startTime), 'EEEE, MMM d')} • {format(new Date(booking.startTime), 'h:mm a')}
                </p>
              </div>
              <Badge variant={booking.status === 'confirmed' ? 'default' : 'secondary'}>
                {booking.status}
              </Badge>
            </div>
          )) || (
            <div className="text-center py-4 text-muted-foreground">
              Loading sessions...
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function PauseSeriesDialog({ seriesId, onPause }: { seriesId: string; onPause: (reason: string) => void }) {
  const [reason, setReason] = useState('');
  const commonReasons = [
    'School holidays',
    'Family vacation',
    'Temporary schedule change',
    'Illness',
    'Financial reasons',
    'Other'
  ];

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">
        Let us know why you're pausing this series. This helps us improve our service.
      </p>
      
      <div className="grid grid-cols-2 gap-2">
        {commonReasons.map((commonReason) => (
          <Button
            key={commonReason}
            variant={reason === commonReason ? "default" : "outline"}
            size="sm"
            onClick={() => setReason(commonReason)}
          >
            {commonReason}
          </Button>
        ))}
      </div>
      
      <div className="flex gap-2">
        <Button
          onClick={() => onPause(reason)}
          disabled={!reason}
          className="flex-1"
        >
          Pause Series
        </Button>
      </div>
    </div>
  );
}