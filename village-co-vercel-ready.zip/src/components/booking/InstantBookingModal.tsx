import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Card, CardContent } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Clock, Star, Shield, Play, Calendar, DollarSign } from 'lucide-react';

const bookingSchema = z.object({
  startTime: z.string().min(1, 'Start time is required'),
  endTime: z.string().min(1, 'End time is required'),
  duration: z.number().min(1, 'Duration must be at least 1 hour'),
  notes: z.string().optional(),
});

type BookingFormData = z.infer<typeof bookingSchema>;

interface InstantBookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  sitter: any;
  onSuccess?: () => void;
}

export default function InstantBookingModal({ 
  isOpen, 
  onClose, 
  sitter, 
  onSuccess 
}: InstantBookingModalProps) {
  const [suggestedDuration, setSuggestedDuration] = useState(3); // Default 3 hours
  const [totalCost, setTotalCost] = useState(0);
  const [isPaymentReady, setIsPaymentReady] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<BookingFormData>({
    resolver: zodResolver(bookingSchema),
    defaultValues: {
      startTime: '',
      endTime: '',
      duration: suggestedDuration,
      notes: '',
    },
  });

  // Watch form values to calculate cost
  const watchedStartTime = form.watch('startTime');
  const watchedEndTime = form.watch('endTime');
  const watchedDuration = form.watch('duration');

  // Auto-suggest duration based on time selected
  useEffect(() => {
    if (watchedStartTime) {
      const startHour = new Date(watchedStartTime).getHours();
      
      // Suggest duration based on time of day
      if (startHour >= 18 || startHour <= 6) {
        // Evening/night booking - suggest 3-4 hours
        setSuggestedDuration(4);
        form.setValue('duration', 4);
      } else if (startHour >= 9 && startHour <= 17) {
        // Daytime booking - suggest 2-3 hours
        setSuggestedDuration(2);
        form.setValue('duration', 2);
      } else {
        // Default 3 hours
        setSuggestedDuration(3);
        form.setValue('duration', 3);
      }
    }
  }, [watchedStartTime, form]);

  // Auto-calculate end time when duration changes
  useEffect(() => {
    if (watchedStartTime && watchedDuration) {
      const start = new Date(watchedStartTime);
      const end = new Date(start.getTime() + (watchedDuration * 60 * 60 * 1000));
      const endTimeString = end.toISOString().slice(0, 16);
      form.setValue('endTime', endTimeString);
    }
  }, [watchedStartTime, watchedDuration, form]);

  // Calculate total cost
  useEffect(() => {
    if (watchedDuration && sitter?.hourlyRate) {
      const baseCost = watchedDuration * sitter.hourlyRate;
      const platformFee = baseCost * 0.10; // 10% platform fee for parents
      setTotalCost(baseCost + platformFee);
    }
  }, [watchedDuration, sitter?.hourlyRate]);

  const createBookingMutation = useMutation({
    mutationFn: async (data: BookingFormData) => {
      const bookingData = {
        sitterId: sitter.id,
        startTime: data.startTime,
        endTime: data.endTime,
        sitNotes: data.notes,
        totalAmount: totalCost,
        isInstantBooking: true,
      };

      const response = await apiRequest('POST', '/api/bookings', bookingData);

      return response;
    },
    onSuccess: () => {
      toast({
        title: "Booking Confirmed!",
        description: `Your booking with ${sitter.firstName} is confirmed. You'll receive confirmation details shortly.`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/bookings'] });
      onClose();
      if (onSuccess) onSuccess();
    },
    onError: (error: any) => {
      toast({
        title: "Booking Failed",
        description: error.message || "Failed to create booking. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: BookingFormData) => {
    createBookingMutation.mutate(data);
  };

  const getInitials = () => {
    return `${sitter.firstName?.[0] || ''}${sitter.lastName?.[0] || ''}`;
  };

  const formatDateTime = (dateTime: string) => {
    if (!dateTime) return '';
    return new Date(dateTime).toLocaleString('en-NZ', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-village-wine">
            Instant Booking
          </DialogTitle>
          <DialogDescription>
            Book {sitter.firstName} in just a few clicks - no waiting for approval!
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            
            {/* Sitter Preview Card */}
            <Card className="border-village-wine/20">
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  <Avatar className="h-16 w-16">
                    <AvatarImage src={sitter.photoUrl} alt={`${sitter.firstName} ${sitter.lastName}`} />
                    <AvatarFallback className="text-lg bg-village-rose text-village-wine">
                      {getInitials()}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold">{sitter.firstName} {sitter.lastName}</h3>
                    <div className="flex items-center gap-2 mb-2">
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        <span className="font-medium">{sitter.rating || 4.8}</span>
                        <span className="text-muted-foreground">({sitter.reviewCount || 0} reviews)</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2 flex-wrap">
                      {sitter.identityVerified && (
                        <Badge variant="secondary" className="text-xs bg-green-100 text-green-800">
                          <Shield className="h-3 w-3 mr-1" />
                          ID Verified
                        </Badge>
                      )}
                      {sitter.firstAidCertDate && (
                        <Badge variant="secondary" className="text-xs bg-blue-100 text-blue-800">
                          First Aid Certified
                        </Badge>
                      )}
                      {sitter.badge && (
                        <Badge variant="secondary" className="text-xs bg-village-rose text-village-wine">
                          {sitter.badge}
                        </Badge>
                      )}
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <div className="text-2xl font-bold text-village-wine">
                      ${sitter.hourlyRate}
                    </div>
                    <div className="text-sm text-muted-foreground">per hour</div>
                  </div>
                </div>

                {/* Video Preview */}
                {sitter.introVideoUrl && (
                  <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Play className="h-4 w-4" />
                      <span>30-second intro video available</span>
                      <Button variant="link" size="sm" className="p-0 h-auto">
                        Watch now
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Booking Details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="startTime"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      Start Time
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="datetime-local"
                        {...field}
                        min={new Date().toISOString().slice(0, 16)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="duration"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-2">
                      <Clock className="h-4 w-4" />
                      Duration (hours)
                    </FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        min="1"
                        max="12"
                        step="0.5"
                        {...field}
                        onChange={(e) => field.onChange(parseFloat(e.target.value))}
                      />
                    </FormControl>
                    <div className="text-xs text-muted-foreground">
                      Suggested: {suggestedDuration} hours for this time slot
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* End Time Preview */}
            {watchedEndTime && (
              <div className="p-3 bg-village-linen rounded-lg">
                <div className="text-sm font-medium text-village-wine">Booking Summary:</div>
                <div className="text-sm text-gray-600 mt-1">
                  {formatDateTime(watchedStartTime)} - {formatDateTime(watchedEndTime)}
                </div>
                <div className="text-sm text-gray-600">
                  Duration: {watchedDuration} hours
                </div>
              </div>
            )}

            {/* Special Instructions */}
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Any special instructions? (Optional)</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="e.g., Bedtime at 7:30pm, allergic to nuts, loves reading stories..."
                      className="min-h-[80px]"
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Cost Breakdown */}
            {totalCost > 0 && (
              <Card className="border-village-wine/20">
                <CardContent className="p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <DollarSign className="h-5 w-5 text-village-wine" />
                    <h4 className="font-semibold">Cost Breakdown</h4>
                  </div>
                  
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Childcare ({watchedDuration} hours × ${sitter.hourlyRate})</span>
                      <span>${(watchedDuration * sitter.hourlyRate).toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Platform fee (10%)</span>
                      <span>${((watchedDuration * sitter.hourlyRate) * 0.10).toFixed(2)}</span>
                    </div>
                    <div className="border-t pt-2 flex justify-between font-semibold text-village-wine">
                      <span>Total</span>
                      <span>${totalCost.toFixed(2)}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Actions */}
            <div className="flex gap-3 pt-4">
              <Button type="button" variant="outline" onClick={onClose} className="flex-1">
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={createBookingMutation.isPending || totalCost === 0}
                className="flex-1 bg-village-wine hover:bg-village-wine/90"
              >
                {createBookingMutation.isPending ? "Booking..." : `Confirm & Pay $${totalCost.toFixed(2)}`}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}