import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { format, addDays, isSameDay, getDay } from 'date-fns';
import { Calendar as CalendarIcon, Clock, Repeat, Users, Star, CheckCircle } from 'lucide-react';

const recurringBookingSchema = z.object({
  title: z.string().min(1, 'Title is required'),
  daysOfWeek: z.array(z.number()).min(1, 'Select at least one day'),
  startTime: z.string().min(1, 'Start time is required'),
  endTime: z.string().min(1, 'End time is required'),
  startDate: z.date(),
  endDate: z.date(),
  specialRequests: z.string().optional(),
  sitNotes: z.string().optional(),
});

const daysOfWeekOptions = [
  { value: 1, label: 'Monday', short: 'Mon' },
  { value: 2, label: 'Tuesday', short: 'Tue' },
  { value: 3, label: 'Wednesday', short: 'Wed' },
  { value: 4, label: 'Thursday', short: 'Thu' },
  { value: 5, label: 'Friday', short: 'Fri' },
  { value: 6, label: 'Saturday', short: 'Sat' },
  { value: 0, label: 'Sunday', short: 'Sun' },
];

interface RecurringBookingFormProps {
  sitter: {
    id: number;
    name: string;
    photoUrl?: string;
    hourlyRate: string;
    rating: number;
    reviewCount: number;
    isFlexibleForRecurring?: boolean;
  };
  onSubmit: (seriesId: string, bookingCount: number) => void;
  onCancel: () => void;
}

export default function RecurringBookingForm({ sitter, onSubmit, onCancel }: RecurringBookingFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [estimatedBookings, setEstimatedBookings] = useState(0);
  const [previewDates, setPreviewDates] = useState<Date[]>([]);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof recurringBookingSchema>>({
    resolver: zodResolver(recurringBookingSchema),
    defaultValues: {
      title: `Regular sessions with ${sitter.name}`,
      daysOfWeek: [],
      startTime: '15:00',
      endTime: '17:00',
      startDate: new Date(),
      endDate: addDays(new Date(), 30),
      specialRequests: '',
      sitNotes: '',
    },
  });

  const watchedValues = form.watch(['daysOfWeek', 'startDate', 'endDate']);

  // Calculate estimated bookings and preview dates when form values change
  React.useEffect(() => {
    const [daysOfWeek, startDate, endDate] = watchedValues;
    
    if (daysOfWeek.length > 0 && startDate && endDate) {
      const dates = calculateBookingDates(daysOfWeek, startDate, endDate);
      setPreviewDates(dates);
      setEstimatedBookings(dates.length);
    }
  }, [watchedValues]);

  const calculateBookingDates = (daysOfWeek: number[], startDate: Date, endDate: Date): Date[] => {
    const dates: Date[] = [];
    let currentDate = new Date(startDate);
    
    while (currentDate <= endDate) {
      const dayOfWeek = getDay(currentDate);
      if (daysOfWeek.includes(dayOfWeek)) {
        dates.push(new Date(currentDate));
      }
      currentDate = addDays(currentDate, 1);
    }
    
    return dates;
  };

  const calculateTotalCost = (): number => {
    const startTime = form.getValues('startTime');
    const endTime = form.getValues('endTime');
    
    if (!startTime || !endTime) return 0;
    
    const [startHour, startMinute] = startTime.split(':').map(Number);
    const [endHour, endMinute] = endTime.split(':').map(Number);
    
    const durationHours = (endHour + endMinute / 60) - (startHour + startMinute / 60);
    const sessionCost = durationHours * parseFloat(sitter.hourlyRate);
    
    return sessionCost * estimatedBookings;
  };

  const handleSubmit = async (values: z.infer<typeof recurringBookingSchema>) => {
    setIsSubmitting(true);
    
    try {
      const bookingDates = calculateBookingDates(values.daysOfWeek, values.startDate, values.endDate);
      
      const seriesData = {
        sitterId: sitter.id,
        title: values.title,
        daysOfWeek: values.daysOfWeek,
        startTime: values.startTime,
        endTime: values.endTime,
        startDate: values.startDate.toISOString(),
        endDate: values.endDate.toISOString(),
        specialRequests: values.specialRequests,
        sitNotes: values.sitNotes,
        hourlyRate: sitter.hourlyRate,
        bookingDates: bookingDates.map(date => date.toISOString()),
      };

      const response = await apiRequest('POST', '/api/booking-series', seriesData);
      const result = await response.json();

      if (response.ok) {
        toast({
          title: "Recurring Booking Created!",
          description: `${bookingDates.length} sessions created with ${sitter.name}. Awaiting sitter approval.`,
        });
        onSubmit(result.seriesId, bookingDates.length);
      } else {
        throw new Error(result.message || 'Failed to create recurring booking');
      }
    } catch (error: any) {
      toast({
        title: "Booking Failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Sitter Information */}
      <Card>
        <CardHeader className="pb-4">
          <div className="flex items-center space-x-4">
            <Avatar className="h-16 w-16">
              <AvatarImage src={sitter.photoUrl} />
              <AvatarFallback className="bg-village-wine text-white text-lg">
                {sitter.name.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <CardTitle className="text-xl text-village-wine flex items-center gap-2">
                <Repeat className="w-5 h-5" />
                Set Up Recurring Booking
              </CardTitle>
              <CardDescription className="text-base">
                ${sitter.hourlyRate}/hour • ⭐ {sitter.rating} ({sitter.reviewCount} reviews)
              </CardDescription>
              <div className="flex gap-2 mt-2">
                {sitter.isFlexibleForRecurring && (
                  <Badge variant="secondary" className="text-xs bg-green-100 text-green-800">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Flexible for recurring bookings
                  </Badge>
                )}
                <Badge variant="outline" className="text-xs">
                  <Users className="w-3 h-3 mr-1" />
                  {sitter.name}
                </Badge>
              </div>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Recurring Booking Form */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Recurring Schedule Details</CardTitle>
          <CardDescription>
            Set up regular sessions with the same sitter, time, and routine
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
              {/* Title */}
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Series Title</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., Weekly after-school care" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Days of Week Selection */}
              <FormField
                control={form.control}
                name="daysOfWeek"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Select Days of the Week</FormLabel>
                    <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
                      {daysOfWeekOptions.map((day) => (
                        <div key={day.value} className="flex items-center space-x-2">
                          <Checkbox
                            id={`day-${day.value}`}
                            checked={field.value?.includes(day.value)}
                            onCheckedChange={(checked) => {
                              const updatedDays = checked
                                ? [...field.value, day.value]
                                : field.value?.filter((d) => d !== day.value) || [];
                              field.onChange(updatedDays);
                            }}
                          />
                          <label
                            htmlFor={`day-${day.value}`}
                            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                          >
                            <span className="hidden sm:inline">{day.label}</span>
                            <span className="sm:hidden">{day.short}</span>
                          </label>
                        </div>
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Time Selection */}
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="startTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Start Time</FormLabel>
                      <FormControl>
                        <Input type="time" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="endTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>End Time</FormLabel>
                      <FormControl>
                        <Input type="time" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Date Range */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="startDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Start Date</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              className={`w-full pl-3 text-left font-normal ${
                                !field.value && "text-muted-foreground"
                              }`}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick start date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            disabled={(date) => date < new Date()}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="endDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>End Date</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant="outline"
                              className={`w-full pl-3 text-left font-normal ${
                                !field.value && "text-muted-foreground"
                              }`}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick end date</span>
                              )}
                              <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            disabled={(date) => date < form.getValues('startDate')}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Booking Preview */}
              {estimatedBookings > 0 && (
                <Card className="border-village-wine/20 bg-village-wine/5">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg text-village-wine">Booking Preview</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
                      <div>
                        <div className="text-2xl font-bold text-village-wine">{estimatedBookings}</div>
                        <div className="text-sm text-muted-foreground">Total Sessions</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-village-wine">
                          {form.watch('daysOfWeek').length}
                        </div>
                        <div className="text-sm text-muted-foreground">Days per Week</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-village-wine">
                          ${calculateTotalCost().toFixed(0)}
                        </div>
                        <div className="text-sm text-muted-foreground">Estimated Total</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-village-wine">
                          ${(calculateTotalCost() / estimatedBookings || 0).toFixed(0)}
                        </div>
                        <div className="text-sm text-muted-foreground">Per Session</div>
                      </div>
                    </div>
                    
                    {previewDates.length > 0 && (
                      <div>
                        <h4 className="font-medium mb-2">Upcoming Sessions:</h4>
                        <div className="flex flex-wrap gap-2 max-h-24 overflow-y-auto">
                          {previewDates.slice(0, 8).map((date, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {format(date, 'MMM d')}
                            </Badge>
                          ))}
                          {previewDates.length > 8 && (
                            <Badge variant="outline" className="text-xs">
                              +{previewDates.length - 8} more
                            </Badge>
                          )}
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              )}

              {/* Special Requests */}
              <FormField
                control={form.control}
                name="specialRequests"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Special Requests</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Any special requests or instructions for these sessions..."
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Sit Notes */}
              <FormField
                control={form.control}
                name="sitNotes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Sit Notes</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Bedtime routine, meal preferences, emergency contacts..."
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Info Box */}
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <h4 className="font-medium text-blue-900 mb-2">How recurring bookings work:</h4>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• {sitter.name} will receive all booking requests at once</li>
                  <li>• They can approve the entire series or individual sessions</li>
                  <li>• You can pause or modify the series anytime from your dashboard</li>
                  <li>• Each session will be charged separately as it occurs</li>
                </ul>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-3 pt-4">
                <Button
                  type="submit"
                  disabled={isSubmitting || estimatedBookings === 0}
                  className="flex-1 bg-village-wine hover:bg-village-wine/90"
                >
                  {isSubmitting ? "Creating Series..." : `Create ${estimatedBookings} Sessions`}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={onCancel}
                  disabled={isSubmitting}
                >
                  Cancel
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}