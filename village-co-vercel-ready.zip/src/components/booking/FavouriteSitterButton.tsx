import React from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Heart } from 'lucide-react';

interface FavouriteSitterButtonProps {
  sitterId: number;
  isFavourite: boolean;
  size?: 'sm' | 'default' | 'lg';
  variant?: 'outline' | 'ghost' | 'default';
}

export default function FavouriteSitterButton({ 
  sitterId, 
  isFavourite, 
  size = 'sm',
  variant = 'ghost' 
}: FavouriteSitterButtonProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const toggleFavouriteMutation = useMutation({
    mutationFn: async () => {
      console.log('🎯 FavouriteSitterButton mutation called');
      if (isFavourite) {
        console.log('🗑️ Removing favorite via FavouriteSitterButton');
        return apiRequest('DELETE', `/api/favourites/${sitterId}`, undefined);
      } else {
        console.log('❤️ Adding favorite via FavouriteSitterButton');
        return apiRequest('POST', '/api/favourites', { sitterId });
      }
    },
    onSuccess: () => {
      toast({
        title: isFavourite ? "Removed from favourites" : "Added to favourites",
        description: isFavourite 
          ? "This sitter has been removed from your favourites" 
          : "This sitter has been added to your favourites",
      });
      
      // Invalidate queries to refresh the data
      queryClient.invalidateQueries({ queryKey: ['/api/sitters'] });
      queryClient.invalidateQueries({ queryKey: ['/api/favourites'] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update favourites",
        variant: "destructive",
      });
    },
  });

  const handleToggleFavourite = (e: React.MouseEvent) => {
    e.stopPropagation(); // Prevent triggering parent click events
    toggleFavouriteMutation.mutate();
  };

  return (
    <Button
      variant={variant}
      size={size}
      onClick={handleToggleFavourite}
      disabled={toggleFavouriteMutation.isPending}
      className={`${isFavourite ? 'text-red-600 hover:text-red-700' : 'text-gray-400 hover:text-red-600'} p-2`}
    >
      <Heart 
        className={`h-4 w-4 ${isFavourite ? 'fill-current' : ''}`} 
      />
      <span className="sr-only">
        {isFavourite ? 'Remove from favourites' : 'Add to favourites'}
      </span>
    </Button>
  );
}