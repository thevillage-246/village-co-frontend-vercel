import React, { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { format, addHours, isAfter, isBefore, parseISO } from 'date-fns';
import { Calendar as CalendarIcon, Clock } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Calendar } from '@/components/ui/calendar';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { cn } from '@/lib/utils';

interface BookingFormProps {
  sitterId: number;
  sitterName: string;
  hourlyRate: number;
  availability?: {
    dayOfWeek: number;
    startTime: string;
    endTime: string;
  }[];
}

const bookingSchema = z.object({
  date: z.date({
    required_error: "Please select a date",
  }),
  startTime: z.string({
    required_error: "Please select a start time",
  }),
  endTime: z.string({
    required_error: "Please select an end time",
  }),
  specialRequests: z.string().optional(),
  childCount: z.coerce.number().int().min(1, {
    message: "Please specify how many children need care",
  }),
  isConciergeRequest: z.boolean().default(false),
});

type BookingFormValues = z.infer<typeof bookingSchema>;

// Generate time options from 7 AM to 11 PM
const generateTimeOptions = () => {
  const options = [];
  for (let hour = 7; hour <= 23; hour++) {
    const formattedHour = hour % 12 === 0 ? 12 : hour % 12;
    const period = hour < 12 ? 'AM' : 'PM';
    
    // Full hour
    options.push(`${formattedHour}:00 ${period}`);
    
    // Half hour
    options.push(`${formattedHour}:30 ${period}`);
  }
  return options;
};

const TIME_OPTIONS = generateTimeOptions();

const BookingForm: React.FC<BookingFormProps> = ({ sitterId, sitterName, hourlyRate, availability }) => {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [calculatedTotal, setCalculatedTotal] = useState<number | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [availableTimeSlots, setAvailableTimeSlots] = useState<string[]>(TIME_OPTIONS);

  const form = useForm<BookingFormValues>({
    resolver: zodResolver(bookingSchema),
    defaultValues: {
      date: undefined,
      startTime: '',
      endTime: '',
      specialRequests: '',
      childCount: 1,
      isConciergeRequest: false,
    },
  });

  // Calculate booking total when start and end times change
  useEffect(() => {
    const calculateTotal = () => {
      const startTime = form.getValues('startTime');
      const endTime = form.getValues('endTime');
      
      if (!startTime || !endTime) return;
      
      // Extract hours and minutes
      const parseTimeString = (timeStr: string) => {
        const [time, period] = timeStr.split(' ');
        const [hour, minute] = time.split(':').map(Number);
        
        let hours = hour;
        if (period === 'PM' && hour !== 12) hours += 12;
        if (period === 'AM' && hour === 12) hours = 0;
        
        return { hours, minutes: minute };
      };
      
      const start = parseTimeString(startTime);
      const end = parseTimeString(endTime);
      
      // Calculate hours difference
      let totalHours = end.hours - start.hours;
      let totalMinutes = end.minutes - start.minutes;
      
      if (totalMinutes < 0) {
        totalHours -= 1;
        totalMinutes += 60;
      }
      
      const decimal = totalHours + (totalMinutes / 60);
      if (decimal <= 0) return;
      
      const total = decimal * hourlyRate;
      setCalculatedTotal(Math.round(total * 100) / 100);
    };
    
    setIsCalculating(true);
    calculateTotal();
    setIsCalculating(false);
  }, [form.watch('startTime'), form.watch('endTime'), hourlyRate]);

  // Update available time slots based on sitter's availability for the selected date
  useEffect(() => {
    if (!selectedDate || !availability) {
      setAvailableTimeSlots(TIME_OPTIONS);
      return;
    }
    
    const dayOfWeek = selectedDate.getDay();
    const availabilityForDay = availability.filter(slot => slot.dayOfWeek === dayOfWeek);
    
    if (availabilityForDay.length === 0) {
      // No availability for this day
      setAvailableTimeSlots([]);
      return;
    }
    
    // Filter time options based on sitter's availability
    const availableTimes = TIME_OPTIONS.filter(timeOption => {
      // Convert time option (e.g., "7:00 PM") to 24-hour format for comparison
      const [time, period] = timeOption.split(' ');
      const [hours, minutes] = time.split(':').map(Number);
      
      let hour24 = hours;
      if (period === 'PM' && hours !== 12) hour24 += 12;
      if (period === 'AM' && hours === 12) hour24 = 0;
      
      const timeString = `${hour24.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
      
      // Check if time is within any availability slot
      return availabilityForDay.some(slot => {
        return timeString >= slot.startTime && timeString <= slot.endTime;
      });
    });
    
    setAvailableTimeSlots(availableTimes);
  }, [selectedDate, availability]);

  // Check if end time is after start time
  const validateTimes = (startTime: string, endTime: string) => {
    if (!startTime || !endTime) return true;
    
    const parseTimeString = (timeStr: string) => {
      const [time, period] = timeStr.split(' ');
      const [hour, minute] = time.split(':').map(Number);
      
      let hours = hour;
      if (period === 'PM' && hour !== 12) hours += 12;
      if (period === 'AM' && hour === 12) hours = 0;
      
      return new Date(2023, 0, 1, hours, minute);
    };
    
    const startDate = parseTimeString(startTime);
    const endDate = parseTimeString(endTime);
    
    return isAfter(endDate, startDate);
  };

  const onSubmit = async (data: BookingFormValues) => {
    try {
      if (!user) {
        toast({
          title: "Authentication Required",
          description: "Please sign in to book a sitter.",
          variant: "destructive",
        });
        navigate('/auth');
        return;
      }
      
      // Validate time selection
      if (!validateTimes(data.startTime, data.endTime)) {
        toast({
          title: "Invalid Time Selection",
          description: "End time must be after start time.",
          variant: "destructive",
        });
        return;
      }
      
      // Format date and times for the API
      const formatDateTime = (date: Date, timeString: string) => {
        const [time, period] = timeString.split(' ');
        const [hours, minutes] = time.split(':').map(Number);
        
        const dateObj = new Date(date);
        let hour = hours;
        
        if (period === 'PM' && hours !== 12) hour += 12;
        if (period === 'AM' && hours === 12) hour = 0;
        
        dateObj.setHours(hour, minutes, 0, 0);
        return dateObj.toISOString();
      };
      
      const startDateTime = formatDateTime(data.date, data.startTime);
      const endDateTime = formatDateTime(data.date, data.endTime);
      
      // Get parent profile
      const parentProfileResponse = await apiRequest('GET', `/api/parents/${user.id}/profile`, null);
      if (!parentProfileResponse.ok) {
        throw new Error('Could not retrieve parent profile');
      }
      const parentProfile = await parentProfileResponse.json();
      
      // Create booking
      const bookingData = {
        parentId: parentProfile.id,
        sitterId: sitterId,
        startTime: startDateTime,
        endTime: endDateTime,
        specialRequests: data.specialRequests,
        isConciergeRequest: data.isConciergeRequest,
      };
      
      const response = await apiRequest('POST', '/api/bookings', bookingData);
      
      if (!response.ok) {
        throw new Error('Failed to create booking');
      }
      
      const booking = await response.json();
      
      toast({
        title: "Booking Request Sent",
        description: `Your booking request has been sent to ${sitterName}.`,
      });
      
      // Navigate to booking summary page
      navigate(`/booking-summary/${booking.id}`);
    } catch (error: any) {
      toast({
        title: "Booking Failed",
        description: error.message || "Failed to create booking. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Disable past dates in the calendar
  const disableDate = (date: Date) => {
    return isBefore(date, new Date()) || 
      // If availability is provided, disable dates with no availability
      (availability && !availability.some(slot => slot.dayOfWeek === date.getDay()));
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Book {sitterName}</CardTitle>
        <CardDescription>Select your preferred date and time</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="date"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Date</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full pl-3 text-left font-normal",
                            !field.value && "text-muted-foreground"
                          )}
                        >
                          {field.value ? (
                            format(field.value, "PPP")
                          ) : (
                            <span>Pick a date</span>
                          )}
                          <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={(date) => {
                          field.onChange(date);
                          setSelectedDate(date || undefined);
                          
                          // Reset times when date changes
                          form.setValue('startTime', '');
                          form.setValue('endTime', '');
                        }}
                        disabled={disableDate}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                  <FormDescription>
                    Only available dates are selectable
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="startTime"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Start Time</FormLabel>
                    <Select
                      disabled={!form.getValues('date') || availableTimeSlots.length === 0}
                      onValueChange={field.onChange}
                      value={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select start time" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {availableTimeSlots.length > 0 ? (
                          availableTimeSlots.map((time) => (
                            <SelectItem key={`start-${time}`} value={time}>
                              {time}
                            </SelectItem>
                          ))
                        ) : (
                          <SelectItem value="no-availability" disabled>
                            No availability for this date
                          </SelectItem>
                        )}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="endTime"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>End Time</FormLabel>
                    <Select
                      disabled={!form.getValues('startTime')}
                      onValueChange={field.onChange}
                      value={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select end time" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {availableTimeSlots
                          .filter(time => {
                            const startTime = form.getValues('startTime');
                            if (!startTime) return true;
                            
                            // Only show end times that are after the start time
                            return validateTimes(startTime, time);
                          })
                          .map((time) => (
                            <SelectItem key={`end-${time}`} value={time}>
                              {time}
                            </SelectItem>
                          ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="childCount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Number of Children</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      min={1}
                      step={1}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="specialRequests"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Special Requests</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Any allergies, special needs, or specific instructions..."
                      className="resize-none min-h-[100px]"
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>
                    Provide any important information for the sitter
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="isConciergeRequest"
              render={({ field }) => (
                <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>
                      Request Concierge Help
                    </FormLabel>
                    <FormDescription>
                      Our team will help match you with a sitter
                    </FormDescription>
                  </div>
                </FormItem>
              )}
            />
            
            {calculatedTotal !== null && (
              <div className="rounded-md bg-muted p-4">
                <div className="font-medium">Booking Summary</div>
                <div className="mt-2 space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Hourly Rate:</span>
                    <span>${hourlyRate.toFixed(2)}/hr</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Duration:</span>
                    <span>
                      {form.getValues('startTime')} - {form.getValues('endTime')}
                    </span>
                  </div>
                  <div className="flex justify-between font-medium pt-2 border-t mt-2">
                    <span>Estimated Total:</span>
                    <span>${calculatedTotal.toFixed(2)}</span>
                  </div>
                  <div className="text-xs text-muted-foreground mt-1">
                    Final amount will be calculated after service completion
                  </div>
                </div>
              </div>
            )}
            
            <Button type="submit" className="w-full">
              Request Booking
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
};

export default BookingForm;
