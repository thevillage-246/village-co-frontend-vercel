import React, { useState } from 'react';
import { format, parseISO } from 'date-fns';
import { Clock, Calendar, MapPin, Users, MessageCircle, DollarSign, Star } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BOOKING_STATUS, USER_ROLES } from '@shared/schema';
import { createPaymentIntent } from '@/lib/stripe';
import { getStripe } from '@/lib/stripe';
import ChatInterface from '../chat/ChatInterface';
import ReviewForm from '../reviews/ReviewForm';
import ReviewList from '../reviews/ReviewList';

interface BookingDetailsProps {
  bookingId: number;
}

const BookingDetails: React.FC<BookingDetailsProps> = ({ bookingId }) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('details');
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [showReviewDialog, setShowReviewDialog] = useState(false);

  // Fetch booking details
  const { data: booking, isLoading, error } = useQuery({
    queryKey: [`/api/bookings/${bookingId}`],
    enabled: !!bookingId,
  });

  // Fetch parent profile if user is sitter
  const { data: parentProfile } = useQuery({
    queryKey: [`/api/parents/${booking?.parentId}/profile`],
    enabled: !!booking && user?.role === USER_ROLES.SITTER,
  });

  // Fetch sitter profile if user is parent
  const { data: sitterProfile } = useQuery({
    queryKey: [`/api/sitters/${booking?.sitterId}/profile`],
    enabled: !!booking && user?.role === USER_ROLES.PARENT,
  });

  // Update booking status mutation
  const updateBookingStatus = useMutation({
    mutationFn: async ({ status }: { status: string }) => {
      const response = await apiRequest('PATCH', `/api/bookings/${bookingId}/status`, { status });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/bookings/${bookingId}`] });
      
      // Also invalidate the parent/sitter bookings lists
      if (user?.role === USER_ROLES.PARENT) {
        queryClient.invalidateQueries({ queryKey: [`/api/parents/${user.id}/bookings`] });
      } else if (user?.role === USER_ROLES.SITTER) {
        queryClient.invalidateQueries({ queryKey: [`/api/sitters/${user.id}/bookings`] });
        queryClient.invalidateQueries({ queryKey: [`/api/sitters/${user.id}/booking-requests`] });
      }
      
      toast({
        title: 'Booking Updated',
        description: 'The booking status has been updated successfully.',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Update Failed',
        description: error.message || 'Failed to update booking status.',
        variant: 'destructive',
      });
    },
  });

  const handleAcceptBooking = () => {
    updateBookingStatus.mutate({ status: BOOKING_STATUS.ACCEPTED });
  };

  const handleDeclineBooking = () => {
    updateBookingStatus.mutate({ status: BOOKING_STATUS.DECLINED });
  };

  const handleCancelBooking = () => {
    updateBookingStatus.mutate({ status: BOOKING_STATUS.CANCELLED });
  };

  const handleCompleteBooking = () => {
    updateBookingStatus.mutate({ status: BOOKING_STATUS.COMPLETED });
  };

  // Handle payment
  const handlePayment = async () => {
    try {
      if (!booking) return;
      
      // Get payment intent client secret
      const clientSecret = await createPaymentIntent(booking.id);
      
      // Initialize Stripe
      const stripe = await getStripe();
      if (!stripe) throw new Error('Failed to load Stripe');
      
      // Redirect to payment
      const { error } = await stripe.redirectToCheckout({
        clientSecret,
      });
      
      if (error) throw error;
      
      setShowPaymentDialog(false);
    } catch (error: any) {
      toast({
        title: 'Payment Failed',
        description: error.message || 'Failed to initiate payment.',
        variant: 'destructive',
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center p-8">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (error || !booking) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <p className="text-destructive">Failed to load booking details.</p>
        </CardContent>
      </Card>
    );
  }

  // Format dates
  const startTime = parseISO(booking.startTime);
  const endTime = parseISO(booking.endTime);
  const date = format(startTime, 'EEEE, MMMM d, yyyy');
  const timeRange = `${format(startTime, 'h:mm a')} - ${format(endTime, 'h:mm a')}`;
  
  // Calculate duration
  const durationHours = Math.round((endTime.getTime() - startTime.getTime()) / (1000 * 60 * 60) * 10) / 10;
  
  // Determine if user can leave a review (parent for completed bookings)
  const canLeaveReview = 
    user?.role === USER_ROLES.PARENT && 
    booking.status === BOOKING_STATUS.COMPLETED;
  
  // Status badge variant
  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case BOOKING_STATUS.PENDING:
        return 'warning';
      case BOOKING_STATUS.ACCEPTED:
        return 'success';
      case BOOKING_STATUS.DECLINED:
        return 'destructive';
      case BOOKING_STATUS.COMPLETED:
        return 'default';
      case BOOKING_STATUS.CANCELLED:
        return 'secondary';
      default:
        return 'default';
    }
  };

  return (
    <>
      <Card className="overflow-hidden">
        <CardHeader className="pb-4">
          <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2">
            <CardTitle>Booking Details</CardTitle>
            <Badge variant={getStatusBadgeVariant(booking.status)}>
              {booking.status}
            </Badge>
          </div>
        </CardHeader>
        
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <div className="px-6">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="details">Details</TabsTrigger>
              <TabsTrigger value="communication">Messages</TabsTrigger>
            </TabsList>
          </div>
          
          <TabsContent value="details">
            <CardContent className="pt-6">
              <div className="space-y-6">
                {/* Date & Time */}
                <div className="space-y-3">
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-2 text-muted-foreground" />
                    <span>{date}</span>
                  </div>
                  
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-2 text-muted-foreground" />
                    <span>{timeRange} ({durationHours} hours)</span>
                  </div>
                </div>
                
                <Separator />
                
                {/* Booking details */}
                <div>
                  <h3 className="text-sm font-medium mb-2">Booking Information</h3>
                  <div className="space-y-2">
                    {booking.isConciergeRequest && (
                      <Badge variant="secondary">Concierge Request</Badge>
                    )}
                    
                    {user?.role === USER_ROLES.PARENT && sitterProfile && (
                      <p>
                        <span className="text-muted-foreground">Sitter: </span>
                        {sitterProfile.firstName} {sitterProfile.lastName}
                      </p>
                    )}
                    
                    {user?.role === USER_ROLES.SITTER && parentProfile && (
                      <p>
                        <span className="text-muted-foreground">Parent: </span>
                        {parentProfile.firstName} {parentProfile.lastName}
                      </p>
                    )}
                    
                    {booking.specialRequests && (
                      <div>
                        <p className="text-muted-foreground">Special Requests:</p>
                        <p className="text-sm mt-1">{booking.specialRequests}</p>
                      </div>
                    )}
                  </div>
                </div>
                
                <Separator />
                
                {/* Payment details */}
                <div>
                  <h3 className="text-sm font-medium mb-2">Payment Information</h3>
                  <div className="flex items-center font-medium mb-2">
                    <DollarSign className="h-4 w-4 mr-2 text-muted-foreground" />
                    <span>${booking.totalAmount?.toFixed(2) || '0.00'}</span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {booking.status === BOOKING_STATUS.COMPLETED
                      ? 'Payment has been processed'
                      : 'Payment will be processed after service completion'}
                  </p>
                </div>
              </div>
            </CardContent>
          </TabsContent>
          
          <TabsContent value="communication">
            <CardContent className="pt-6 pb-6 h-[400px]">
              {booking.status !== BOOKING_STATUS.PENDING ? (
                <ChatInterface bookingId={booking.id} />
              ) : (
                <div className="h-full flex items-center justify-center">
                  <p className="text-muted-foreground">
                    Chat will be available once the booking is confirmed
                  </p>
                </div>
              )}
            </CardContent>
          </TabsContent>
        </Tabs>
        
        <CardFooter className="flex flex-wrap justify-between gap-2 border-t bg-muted/50 p-4">
          {/* Actions for parents */}
          {user?.role === USER_ROLES.PARENT && (
            <>
              {booking.status === BOOKING_STATUS.ACCEPTED && (
                <>
                  <Button variant="outline" onClick={handleCancelBooking}>Cancel Booking</Button>
                  <Button onClick={() => setShowPaymentDialog(true)}>Make Payment</Button>
                </>
              )}
              
              {booking.status === BOOKING_STATUS.COMPLETED && !booking.stripePaymentIntentId && (
                <Button onClick={() => setShowPaymentDialog(true)} className="w-full">Make Payment</Button>
              )}
              
              {booking.status === BOOKING_STATUS.COMPLETED && (
                <Button 
                  onClick={() => setShowReviewDialog(true)}
                  variant="outline"
                  className="w-full"
                >
                  <Star className="h-4 w-4 mr-2" /> Leave a Review
                </Button>
              )}
            </>
          )}
          
          {/* Actions for sitters */}
          {user?.role === USER_ROLES.SITTER && (
            <>
              {booking.status === BOOKING_STATUS.PENDING && (
                <>
                  <Button variant="outline" onClick={handleDeclineBooking}>Decline</Button>
                  <Button onClick={handleAcceptBooking}>Accept</Button>
                </>
              )}
              
              {booking.status === BOOKING_STATUS.ACCEPTED && (
                <>
                  <Button variant="outline" onClick={handleCancelBooking}>Cancel</Button>
                  <Button onClick={handleCompleteBooking}>Mark as Completed</Button>
                </>
              )}
            </>
          )}
          
          {/* If no actions available */}
          {((user?.role === USER_ROLES.PARENT && 
             booking.status !== BOOKING_STATUS.ACCEPTED && 
             booking.status !== BOOKING_STATUS.COMPLETED) ||
            (user?.role === USER_ROLES.SITTER && 
             booking.status !== BOOKING_STATUS.PENDING && 
             booking.status !== BOOKING_STATUS.ACCEPTED)) && (
            <p className="w-full text-center text-sm text-muted-foreground py-2">
              No actions available for this booking status
            </p>
          )}
        </CardFooter>
      </Card>
      
      {/* Payment Dialog */}
      <Dialog open={showPaymentDialog} onOpenChange={setShowPaymentDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Complete Payment</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <div className="space-y-4">
              <div className="rounded-md bg-muted p-4">
                <div className="font-medium">Booking Summary</div>
                <div className="mt-2 space-y-1 text-sm">
                  <div className="flex justify-between">
                    <span>Date:</span>
                    <span>{date}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Time:</span>
                    <span>{timeRange}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Duration:</span>
                    <span>{durationHours} hours</span>
                  </div>
                  <div className="flex justify-between font-medium pt-2 border-t mt-2">
                    <span>Total:</span>
                    <span>${booking.totalAmount?.toFixed(2) || '0.00'}</span>
                  </div>
                </div>
              </div>
              
              <div className="text-sm text-muted-foreground">
                <p>You will be redirected to our secure payment processor to complete this transaction.</p>
              </div>
              
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setShowPaymentDialog(false)}>Cancel</Button>
                <Button onClick={handlePayment}>Proceed to Payment</Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Review Dialog */}
      <Dialog open={showReviewDialog} onOpenChange={setShowReviewDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Leave a Review</DialogTitle>
          </DialogHeader>
          <ReviewForm 
            bookingId={booking.id}
            revieweeId={sitterProfile?.userId}
            onComplete={() => setShowReviewDialog(false)}
          />
        </DialogContent>
      </Dialog>
    </>
  );
};

export default BookingDetails;
