import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Waves, Thermometer, BookOpen, Percent, MapPin, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface OStudioBookingProps {
  onBookingTypeChange: (type: 'ostudio' | 'regular') => void;
  isSelected: boolean;
  onDetailsChange: (details: any) => void;
}

export function OStudioBooking({ onBookingTypeChange, isSelected, onDetailsChange }: OStudioBookingProps) {
  const [promoCode, setPromoCode] = useState("");
  const [sessionType, setSessionType] = useState("");
  const [promoApplied, setPromoApplied] = useState(false);
  const { toast } = useToast();

  const oStudioServices = [
    {
      icon: <Waves className="w-5 h-5" />,
      name: "Float Tank",
      duration: "60-90 minutes",
      description: "Zero-gravity relaxation in saltwater"
    },
    {
      icon: <Thermometer className="w-5 h-5" />,
      name: "Infrared Sauna",
      duration: "30-45 minutes", 
      description: "Deep heat therapy for wellness"
    },
    {
      icon: <BookOpen className="w-5 h-5" />,
      name: "Journaling Space",
      duration: "45-60 minutes",
      description: "Quiet reflection and mindfulness"
    }
  ];

  const handlePromoCode = () => {
    if (promoCode.toUpperCase() === 'OSTUDIO15') {
      setPromoApplied(true);
      toast({
        title: "Promo Code Applied",
        description: "15% discount applied to your booking!"
      });
      onDetailsChange({
        bookingType: 'ostudio',
        promoCode: promoCode.toUpperCase(),
        discount: 15,
        sessionType,
        location: "O Studio, Hamilton",
        notes: `Parent attending O Studio session (${sessionType || 'Wellness session'})`
      });
    } else {
      toast({
        title: "Invalid Promo Code",
        description: "Please check your code and try again.",
        variant: "destructive"
      });
    }
  };

  const handleSelectOStudio = () => {
    onBookingTypeChange('ostudio');
    onDetailsChange({
      bookingType: 'ostudio',
      location: "O Studio, Hamilton",
      filterLocation: "Hamilton", // For sitter filtering
      notes: `Parent attending O Studio session (${sessionType || 'Wellness session'})`,
      sessionType,
      promoCode: promoApplied ? promoCode.toUpperCase() : null,
      discount: promoApplied ? 15 : 0
    });
  };

  return (
    <Card className={`transition-all ${isSelected ? 'ring-2 ring-village-wine bg-purple-50' : 'hover:shadow-md'}`}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-village-wine">
          <Waves className="w-6 h-6" />
          I'm Going to O Studio
        </CardTitle>
        <CardDescription>
          Wellness without the juggle — we've partnered with O Studio so you can take a moment for you
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* O Studio Services */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {oStudioServices.map((service, index) => (
            <div 
              key={index}
              className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                sessionType === service.name 
                  ? 'border-village-wine bg-village-wine/10' 
                  : 'border-gray-200 hover:border-gray-300'
              }`}
              onClick={() => setSessionType(service.name)}
            >
              <div className="flex items-center gap-2 mb-1">
                {service.icon}
                <span className="font-medium text-sm">{service.name}</span>
              </div>
              <p className="text-xs text-gray-600 mb-1">{service.duration}</p>
              <p className="text-xs text-gray-500">{service.description}</p>
            </div>
          ))}
        </div>

        {/* Location Info */}
        <div className="flex items-center gap-4 p-3 bg-gray-50 rounded-lg">
          <MapPin className="w-4 h-4 text-village-wine" />
          <div>
            <p className="font-medium text-sm">O Studio Hamilton</p>
            <p className="text-xs text-gray-600">Sitters will be filtered for Hamilton area</p>
          </div>
        </div>

        {/* Promo Code Section */}
        <div className="space-y-2">
          <Label htmlFor="promoCode">Promo Code (Optional)</Label>
          <div className="flex gap-2">
            <Input
              id="promoCode"
              placeholder="Enter OSTUDIO15 for 15% off"
              value={promoCode}
              onChange={(e) => setPromoCode(e.target.value.toUpperCase())}
              className="flex-1"
              disabled={promoApplied}
            />
            <Button 
              onClick={handlePromoCode}
              variant="outline"
              disabled={!promoCode || promoApplied}
            >
              {promoApplied ? (
                <>
                  <Percent className="w-4 h-4 mr-1" />
                  Applied
                </>
              ) : (
                'Apply'
              )}
            </Button>
          </div>
          {promoApplied && (
            <Badge className="bg-green-100 text-green-800">
              15% discount applied
            </Badge>
          )}
        </div>

        {/* What's Included */}
        <div className="p-3 bg-blue-50 rounded-lg">
          <h4 className="font-medium text-sm text-blue-800 mb-2">What's included:</h4>
          <ul className="text-xs text-blue-700 space-y-1">
            <li>• Sitters filtered for Hamilton/O Studio area</li>
            <li>• Pre-filled booking notes for your session</li>
            <li>• Special O Studio partnership rates</li>
            <li>• Priority booking for wellness appointments</li>
          </ul>
        </div>

        <Button 
          onClick={handleSelectOStudio}
          className="w-full bg-village-wine hover:bg-village-wine/90"
        >
          <Waves className="w-4 h-4 mr-2" />
          Book Sitter for O Studio Visit
        </Button>
      </CardContent>
    </Card>
  );
}