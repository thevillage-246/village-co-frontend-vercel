import React from 'react';
import { format, parseISO } from 'date-fns';
import { Clock, Calendar, MapPin, Users, DollarSign, MessageSquare, Baby } from 'lucide-react';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { BOOKING_STATUS } from '@shared/schema';

interface Child {
  id: number;
  firstName: string;
  lastName: string;
  birthDate?: string;
  specialNeeds?: string;
  allergies?: string;
  notes?: string;
}

interface BookingRequestCardProps {
  booking: {
    id: number;
    startTime: string;
    endTime: string;
    status: string;
    parent?: {
      id: number;
      firstName: string;
      lastName: string;
    };
    totalAmount: number;
    specialRequests?: string;
    location?: string;
    childCount?: number;
    children?: Child[];
  };
  onAccept?: (id: number) => void;
  onDecline?: (id: number) => void;
  onViewDetails?: (id: number) => void;
}

const BookingRequestCard: React.FC<BookingRequestCardProps> = ({
  booking,
  onAccept,
  onDecline,
  onViewDetails,
}) => {
  const startTime = parseISO(booking.startTime);
  const endTime = parseISO(booking.endTime);
  
  // Calculate duration in hours
  const durationHours = Math.round((endTime.getTime() - startTime.getTime()) / (1000 * 60 * 60) * 10) / 10;
  
  // Format date and time
  const date = format(startTime, 'EEEE, MMMM d, yyyy');
  const timeRange = `${format(startTime, 'h:mm a')} - ${format(endTime, 'h:mm a')}`;
  
  // Status color
  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case BOOKING_STATUS.PENDING:
        return 'outline' as const;
      case BOOKING_STATUS.ACCEPTED:
        return 'default' as const;
      case BOOKING_STATUS.DECLINED:
        return 'destructive' as const;
      case BOOKING_STATUS.COMPLETED:
        return 'secondary' as const;
      case BOOKING_STATUS.CANCELLED:
        return 'secondary' as const;
      default:
        return 'default' as const;
    }
  };
  
  return (
    <Card className="overflow-hidden">
      <CardHeader className="bg-muted pb-3">
        <div className="flex justify-between items-start">
          <CardTitle className="text-lg">
            Booking with {booking.parent ? `${booking.parent.firstName} ${booking.parent.lastName}` : 'Parent'}
          </CardTitle>
          <Badge variant={getStatusBadgeVariant(booking.status)}>
            {booking.status}
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent className="pt-6">
        <div className="space-y-3">
          <div className="flex items-center">
            <Calendar className="h-4 w-4 mr-2 text-muted-foreground" />
            <span>{date}</span>
          </div>
          
          <div className="flex items-center">
            <Clock className="h-4 w-4 mr-2 text-muted-foreground" />
            <span>{timeRange} ({durationHours} hours)</span>
          </div>
          
          {booking.location && (
            <div className="flex items-center">
              <MapPin className="h-4 w-4 mr-2 text-muted-foreground" />
              <span>{booking.location}</span>
            </div>
          )}
          
          {(booking.childCount || (booking.children && booking.children.length > 0)) && (
            <div className="flex items-center">
              <Users className="h-4 w-4 mr-2 text-muted-foreground" />
              <span>
                {booking.childCount || (booking.children?.length || 0)} 
                {booking.childCount === 1 || booking.children?.length === 1 ? ' child' : ' children'}
              </span>
            </div>
          )}
          
          <div className="flex items-center font-medium">
            <DollarSign className="h-4 w-4 mr-2 text-muted-foreground" />
            <span>${booking.totalAmount.toFixed(2)}</span>
          </div>
        </div>
        
        {booking.children && booking.children.length > 0 && (
          <div className="mt-4 pt-4 border-t border-border">
            <p className="text-sm font-medium mb-2">Children:</p>
            <div className="space-y-3">
              {booking.children.map(child => (
                <div key={child.id} className="bg-muted/50 p-3 rounded-md">
                  <div className="flex items-center">
                    <Baby className="h-4 w-4 mr-2 text-primary" />
                    <p className="font-medium">{child.firstName} {child.lastName}</p>
                  </div>
                  {child.birthDate && (
                    <p className="text-xs text-muted-foreground mt-1">
                      Born: {format(parseISO(child.birthDate), 'MMM d, yyyy')}
                    </p>
                  )}
                  {(child.specialNeeds || child.allergies) && (
                    <div className="mt-2 text-xs">
                      {child.specialNeeds && (
                        <p className="text-amber-600">Special needs: {child.specialNeeds}</p>
                      )}
                      {child.allergies && (
                        <p className="text-red-500">Allergies: {child.allergies}</p>
                      )}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
        
        {booking.specialRequests && (
          <div className="mt-4 pt-4 border-t border-border">
            <p className="text-sm font-medium mb-1">Special Requests:</p>
            <p className="text-sm text-muted-foreground">{booking.specialRequests}</p>
          </div>
        )}
      </CardContent>
      
      <CardFooter className="flex justify-between gap-2 border-t bg-muted/50 p-4">
        {booking.status === BOOKING_STATUS.PENDING && onAccept && onDecline ? (
          <>
            <Button
              variant="outline"
              onClick={() => onDecline(booking.id)}
              className="w-full"
            >
              Decline
            </Button>
            <Button
              onClick={() => onAccept(booking.id)}
              className="w-full"
            >
              Accept
            </Button>
          </>
        ) : (
          <Button
            variant="default"
            onClick={() => onViewDetails && onViewDetails(booking.id)}
            className="w-full"
          >
            View Details
          </Button>
        )}
      </CardFooter>
    </Card>
  );
};

export default BookingRequestCard;
