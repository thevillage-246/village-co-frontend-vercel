import React from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Calendar, Clock, AlertCircle, Loader2 } from "lucide-react";

interface BookingConfirmationModalProps {
  sitterName: string;
  rateLabel: string;
  rateValue: number;
  bookingDate: string;
  startTime: string;
  endTime: string;
  onConfirm: () => void;
  onCancel: () => void;
  isLoading?: boolean;
}

export default function BookingConfirmationModal({
  sitterName,
  rateLabel,
  rateValue,
  bookingDate,
  startTime,
  endTime,
  onConfirm,
  onCancel,
  isLoading = false,
}: BookingConfirmationModalProps) {
  // Calculate duration in hours
  const calculateDuration = () => {
    if (!startTime || !endTime) return 0;
    
    const [startHour, startMinute] = startTime.split(':').map(Number);
    const [endHour, endMinute] = endTime.split(':').map(Number);
    
    const startMinutes = startHour * 60 + startMinute;
    const endMinutes = endHour * 60 + endMinute;
    
    // Handle case where booking goes past midnight
    const durationMinutes = endMinutes >= startMinutes 
      ? endMinutes - startMinutes 
      : (24 * 60 - startMinutes) + endMinutes;
    
    return durationMinutes / 60;
  };
  
  const duration = calculateDuration();
  const subtotal = rateValue * duration;
  const serviceFee = subtotal * 0.10; // 10% service fee for parents
  const total = subtotal + serviceFee;

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl text-wine">Confirm Booking</DialogTitle>
          <DialogDescription>
            Please review your booking details before confirming
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className="flex items-center justify-between">
            <div className="font-medium">Sitter</div>
            <div>{sitterName}</div>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="font-medium flex items-center">
              <Calendar className="h-4 w-4 mr-1 text-muted-foreground" />
              <span>Date</span>
            </div>
            <div>{bookingDate}</div>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="font-medium flex items-center">
              <Clock className="h-4 w-4 mr-1 text-muted-foreground" />
              <span>Time</span>
            </div>
            <div>{startTime} - {endTime}</div>
          </div>
          
          <div className="flex items-center justify-between">
            <div className="font-medium">Rate</div>
            <div>{rateLabel} (${parseFloat(String(rateValue)).toFixed(2)}/hr)</div>
          </div>
          
          <Separator />
          
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span>Duration</span>
              <span>{duration.toFixed(1)} hours</span>
            </div>
            
            <div className="flex items-center justify-between text-sm">
              <span>Subtotal</span>
              <span>${subtotal.toFixed(2)}</span>
            </div>
            
            <div className="flex items-center justify-between text-sm">
              <span>Service Fee (10%)</span>
              <span>${serviceFee.toFixed(2)}</span>
            </div>
            
            <Separator />
            
            <div className="flex items-center justify-between font-semibold">
              <span>Total</span>
              <span>${total.toFixed(2)}</span>
            </div>
          </div>
          
          <div className="bg-amber-50 border border-amber-200 rounded-md p-3 mt-4 flex">
            <AlertCircle className="h-5 w-5 text-amber-600 mr-2 flex-shrink-0" />
            <div className="text-sm text-amber-800">
              <p>Your booking will be sent to the sitter for approval.</p>
              <p>Payment will only be processed once the sitter accepts.</p>
            </div>
          </div>
        </div>
        
        <DialogFooter className="flex space-x-2 sm:space-x-0">
          <Button
            type="button"
            variant="outline"
            onClick={onCancel}
            disabled={isLoading}
            className="flex-1"
          >
            Cancel
          </Button>
          <Button
            type="button"
            onClick={onConfirm}
            disabled={isLoading}
            className="flex-1 bg-wine hover:bg-wine/90"
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Processing...
              </>
            ) : (
              "Confirm Booking"
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}