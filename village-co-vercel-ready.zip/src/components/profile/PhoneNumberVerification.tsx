import React, { useState } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Phone, Shield, AlertCircle } from 'lucide-react';

const phoneSchema = z.object({
  phoneNumber: z.string().min(10, 'Valid phone number is required'),
});

const verificationCodeSchema = z.object({
  code: z.string().length(6, 'Verification code must be 6 digits'),
});

interface PhoneNumberVerificationProps {
  userId: number;
  initialPhone?: string;
  isVerified?: boolean;
  canAdminOverride?: boolean;
}

export default function PhoneNumberVerification({ 
  userId, 
  initialPhone, 
  isVerified = false,
  canAdminOverride = false 
}: PhoneNumberVerificationProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [step, setStep] = useState<'phone' | 'code' | 'verified'>(
    isVerified ? 'verified' : 'phone'
  );
  const [pendingPhone, setPendingPhone] = useState('');

  const phoneForm = useForm<z.infer<typeof phoneSchema>>({
    resolver: zodResolver(phoneSchema),
    defaultValues: {
      phoneNumber: initialPhone || '',
    },
  });

  const codeForm = useForm<z.infer<typeof verificationCodeSchema>>({
    resolver: zodResolver(verificationCodeSchema),
    defaultValues: {
      code: '',
    },
  });

  // Send verification code
  const sendCodeMutation = useMutation({
    mutationFn: async (data: z.infer<typeof phoneSchema>) => {
      const response = await apiRequest('POST', '/api/phone/send-verification', data);
      return response;
    },
    onSuccess: (data, variables) => {
      setPendingPhone(variables.phoneNumber);
      setStep('code');
      toast({
        title: 'Verification Code Sent',
        description: `A 6-digit code has been sent to ${variables.phoneNumber}`,
      });
    },
    onError: (error) => {
      toast({
        title: 'Failed to Send Code',
        description: 'Please check your phone number and try again.',
        variant: 'destructive',
      });
    },
  });

  // Verify code
  const verifyCodeMutation = useMutation({
    mutationFn: async (data: z.infer<typeof verificationCodeSchema>) => {
      const response = await apiRequest('POST', '/api/phone/verify-code', {
        phoneNumber: pendingPhone,
        code: data.code,
      });
      return response;
    },
    onSuccess: () => {
      setStep('verified');
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}`] });
      toast({
        title: 'Phone Verified',
        description: 'Your phone number has been successfully verified.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Invalid Code',
        description: 'Please check your verification code and try again.',
        variant: 'destructive',
      });
    },
  });

  // Admin override
  const adminOverrideMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', `/api/admin/phone/override-verification`, {
        userId,
        verified: true,
      });
      return response;
    },
    onSuccess: () => {
      setStep('verified');
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}`] });
      toast({
        title: 'Verification Overridden',
        description: 'Phone verification has been manually approved.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Override Failed',
        description: 'Failed to override verification status.',
        variant: 'destructive',
      });
    },
  });

  const onPhoneSubmit = (data: z.infer<typeof phoneSchema>) => {
    sendCodeMutation.mutate(data);
  };

  const onCodeSubmit = (data: z.infer<typeof verificationCodeSchema>) => {
    verifyCodeMutation.mutate(data);
  };

  if (step === 'verified' || isVerified) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-green-600" />
            Phone Number Verified
          </CardTitle>
          <CardDescription>
            Your phone number {initialPhone || pendingPhone} is verified
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Badge variant="secondary" className="bg-green-100 text-green-800">
            <Shield className="h-4 w-4 mr-1" />
            Verified
          </Badge>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Phone className="h-5 w-5" />
          Phone Number Verification
        </CardTitle>
        <CardDescription>
          {step === 'phone' 
            ? 'Enter your phone number to receive a verification code'
            : `Enter the 6-digit code sent to ${pendingPhone}`
          }
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {step === 'phone' && (
          <Form {...phoneForm}>
            <form onSubmit={phoneForm.handleSubmit(onPhoneSubmit)} className="space-y-4">
              <FormField
                control={phoneForm.control}
                name="phoneNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Phone Number</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="+64 21 123 4567" 
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex gap-2">
                <Button 
                  type="submit" 
                  disabled={sendCodeMutation.isPending}
                  className="bg-village-wine hover:bg-village-wine/90"
                >
                  {sendCodeMutation.isPending ? 'Sending...' : 'Send Code'}
                </Button>
                {canAdminOverride && user?.role === 'admin' && (
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => adminOverrideMutation.mutate()}
                    disabled={adminOverrideMutation.isPending}
                  >
                    {adminOverrideMutation.isPending ? 'Overriding...' : 'Admin Override'}
                  </Button>
                )}
              </div>
            </form>
          </Form>
        )}

        {step === 'code' && (
          <Form {...codeForm}>
            <form onSubmit={codeForm.handleSubmit(onCodeSubmit)} className="space-y-4">
              <FormField
                control={codeForm.control}
                name="code"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Verification Code</FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="123456" 
                        maxLength={6}
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="flex gap-2">
                <Button 
                  type="submit" 
                  disabled={verifyCodeMutation.isPending}
                  className="bg-village-wine hover:bg-village-wine/90"
                >
                  {verifyCodeMutation.isPending ? 'Verifying...' : 'Verify Code'}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setStep('phone')}
                >
                  Change Number
                </Button>
                {canAdminOverride && user?.role === 'admin' && (
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => adminOverrideMutation.mutate()}
                    disabled={adminOverrideMutation.isPending}
                  >
                    {adminOverrideMutation.isPending ? 'Overriding...' : 'Admin Override'}
                  </Button>
                )}
              </div>
            </form>
          </Form>
        )}

        {!isVerified && (
          <div className="flex items-center gap-2 text-amber-600 text-sm">
            <AlertCircle className="h-4 w-4" />
            Phone verification is required for booking
          </div>
        )}
      </CardContent>
    </Card>
  );
}