import React, { useState } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Shield, AlertCircle, ExternalLink, Clock } from 'lucide-react';

interface IDVerificationProps {
  userId: number;
  userRole: 'parent' | 'sitter' | 'admin';
  canAdminOverride?: boolean;
}

export default function IDVerification({ userId, userRole, canAdminOverride = false }: IDVerificationProps) {
  const { user } = useAuth();
  const { toast } = useToast();

  // Get verification status
  const { data: verificationStatus, isLoading } = useQuery({
    queryKey: [`/api/veriff/verification-status/${userId}`],
    refetchInterval: 5000, // Check status every 5 seconds
  });

  // Start verification process
  const startVerificationMutation = useMutation({
    mutationFn: async () => {
      const endpoint = userRole === 'parent' 
        ? '/api/veriff/parent-start-verification'
        : '/api/veriff/sitter-start-verification';
      
      const response = await apiRequest('POST', endpoint, {});
      return response;
    },
    onSuccess: (data) => {
      if (data.verificationUrl) {
        // Open Veriff in new window
        window.open(data.verificationUrl, '_blank', 'width=800,height=600');
        toast({
          title: 'Verification Started',
          description: 'Complete the ID verification in the new window.',
        });
      }
    },
    onError: (error) => {
      toast({
        title: 'Verification Failed',
        description: 'Failed to start ID verification process.',
        variant: 'destructive',
      });
    },
  });

  // Admin override
  const adminOverrideMutation = useMutation({
    mutationFn: async (verified: boolean) => {
      const response = await apiRequest('POST', `/api/admin/veriff/override`, {
        userId,
        verified,
        reason: 'Manual admin override',
      });
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/veriff/verification-status/${userId}`] });
      toast({
        title: 'Verification Status Updated',
        description: 'ID verification status has been manually updated.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Override Failed',
        description: 'Failed to override verification status.',
        variant: 'destructive',
      });
    },
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            ID Verification
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-2">
            <div className="animate-spin h-4 w-4 border-2 border-village-wine border-t-transparent rounded-full"></div>
            Loading verification status...
          </div>
        </CardContent>
      </Card>
    );
  }

  const getStatusInfo = () => {
    if (!verificationStatus) {
      return {
        status: 'Not Started',
        color: 'bg-gray-100 text-gray-800',
        icon: AlertCircle,
        description: 'ID verification is required',
        action: 'start',
      };
    }

    switch (verificationStatus.status) {
      case 'approved':
        return {
          status: 'Verified',
          color: 'bg-green-100 text-green-800',
          icon: CheckCircle,
          description: 'Your identity has been verified',
          action: 'none',
        };
      case 'submitted':
      case 'review':
        return {
          status: 'Under Review',
          color: 'bg-yellow-100 text-yellow-800',
          icon: Clock,
          description: 'Your verification is being reviewed',
          action: 'waiting',
        };
      case 'declined':
      case 'expired':
      case 'abandoned':
        return {
          status: 'Failed',
          color: 'bg-red-100 text-red-800',
          icon: AlertCircle,
          description: 'Verification failed. Please try again.',
          action: 'retry',
        };
      default:
        return {
          status: 'Pending',
          color: 'bg-yellow-100 text-yellow-800',
          icon: Clock,
          description: 'Verification in progress',
          action: 'retry',
        };
    }
  };

  const statusInfo = getStatusInfo();

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="h-5 w-5" />
          ID Verification
        </CardTitle>
        <CardDescription>
          Verify your identity using government-issued photo ID
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-3">
          <Badge variant="secondary" className={statusInfo.color}>
            <statusInfo.icon className="h-4 w-4 mr-1" />
            {statusInfo.status}
          </Badge>
          <span className="text-sm text-muted-foreground">
            {statusInfo.description}
          </span>
        </div>

        {statusInfo.action === 'start' && (
          <Button
            onClick={() => startVerificationMutation.mutate()}
            disabled={startVerificationMutation.isPending}
            className="bg-village-wine hover:bg-village-wine/90"
          >
            <ExternalLink className="h-4 w-4 mr-2" />
            {startVerificationMutation.isPending ? 'Starting...' : 'Start ID Verification'}
          </Button>
        )}

        {statusInfo.action === 'retry' && (
          <Button
            onClick={() => startVerificationMutation.mutate()}
            disabled={startVerificationMutation.isPending}
            variant="outline"
          >
            <ExternalLink className="h-4 w-4 mr-2" />
            {startVerificationMutation.isPending ? 'Starting...' : 'Retry Verification'}
          </Button>
        )}

        {statusInfo.action === 'waiting' && (
          <div className="flex items-center gap-2 text-amber-600 text-sm">
            <Clock className="h-4 w-4" />
            Verification usually takes 1-2 business days
          </div>
        )}

        {/* Admin override controls */}
        {canAdminOverride && user?.role === 'admin' && (
          <div className="border-t pt-4">
            <p className="text-sm text-muted-foreground mb-3">Admin Controls:</p>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => adminOverrideMutation.mutate(true)}
                disabled={adminOverrideMutation.isPending}
              >
                Approve
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => adminOverrideMutation.mutate(false)}
                disabled={adminOverrideMutation.isPending}
              >
                Reject
              </Button>
            </div>
          </div>
        )}

        {!verificationStatus?.verified && (
          <div className="flex items-center gap-2 text-amber-600 text-sm">
            <AlertCircle className="h-4 w-4" />
            ID verification is required for {userRole === 'parent' ? 'booking sitters' : 'accepting bookings'}
          </div>
        )}
      </CardContent>
    </Card>
  );
}