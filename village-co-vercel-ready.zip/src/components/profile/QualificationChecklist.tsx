import React, { useState } from 'react';
import { useMutation, useQuery } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { 
  CheckCircle, 
  Clock, 
  Plus, 
  AlertCircle, 
  Shield, 
  GraduationCap,
  Heart,
  Car,
  FileText
} from 'lucide-react';

interface QualificationChecklistProps {
  sitterId: number;
  canAdminOverride?: boolean;
}

interface Qualification {
  id: number;
  category: string;
  qualificationKey: string;
  displayName: string;
  emoji?: string;
  isVerified: boolean;
  verifiedAt?: string;
  verifiedBy?: number;
  expiryDate?: string;
  additionalInfo?: string;
  required?: boolean;
}

const QUALIFICATION_CATEGORIES = {
  professional: { icon: GraduationCap, color: 'bg-blue-100 text-blue-800' },
  student: { icon: GraduationCap, color: 'bg-purple-100 text-purple-800' },
  safety: { icon: Shield, color: 'bg-green-100 text-green-800' },
  verification: { icon: CheckCircle, color: 'bg-emerald-100 text-emerald-800' },
  additional: { icon: Heart, color: 'bg-pink-100 text-pink-800' },
  transport: { icon: Car, color: 'bg-orange-100 text-orange-800' },
};

export default function QualificationChecklist({ sitterId, canAdminOverride = false }: QualificationChecklistProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedCategory, setSelectedCategory] = useState('');
  const [newQualification, setNewQualification] = useState({
    displayName: '',
    additionalInfo: '',
    expiryDate: '',
  });

  // Get sitter profile (qualifications are now part of the profile)
  const { data: sitterProfile, isLoading } = useQuery({
    queryKey: [`/api/sitters/${sitterId}/profile`],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Extract qualifications from profile
  const qualifications = sitterProfile?.qualifications || [];

  // Add qualification
  const addQualificationMutation = useMutation({
    mutationFn: async (data: any) => {
      // Create new qualification object
      const newQualification = {
        id: Math.random(), // Temporary ID for frontend
        sitterId: sitterId,
        category: data.category,
        qualificationKey: data.qualificationKey,
        displayName: data.displayName,
        emoji: '📋',
        isVerified: false,
        verifiedAt: null,
        verifiedBy: null,
        additionalInfo: data.additionalInfo || null,
        expiryDate: data.expiryDate || null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      // Add to existing qualifications
      const updatedQualifications = [...qualifications, newQualification];
      
      // Update sitter profile
      return apiRequest('PATCH', `/api/sitters/${sitterId}/profile`, {
        qualifications: updatedQualifications
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/sitters/${sitterId}/profile`] });
      setNewQualification({ displayName: '', additionalInfo: '', expiryDate: '' });
      setSelectedCategory('');
      toast({
        title: 'Qualification Added',
        description: 'New qualification has been added to your profile.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Failed to Add Qualification',
        description: 'Please try again.',
        variant: 'destructive',
      });
    },
  });

  // Admin override qualification
  const adminOverrideMutation = useMutation({
    mutationFn: async ({ qualificationId, verified }: { qualificationId: number; verified: boolean }) => {
      // Update the qualification verification status
      const updatedQualifications = qualifications.map((qual: any) => 
        qual.id === qualificationId 
          ? { 
              ...qual, 
              isVerified: verified,
              verifiedAt: verified ? new Date().toISOString() : null,
              verifiedBy: verified ? user?.id : null,
              updatedAt: new Date().toISOString()
            }
          : qual
      );
      
      // Update sitter profile
      return apiRequest('PATCH', `/api/sitters/${sitterId}/profile`, {
        qualifications: updatedQualifications
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/sitters/${sitterId}/profile`] });
      toast({
        title: 'Qualification Updated',
        description: 'Qualification status has been updated.',
      });
    },
    onError: (error) => {
      toast({
        title: 'Override Failed',
        description: 'Failed to update qualification status.',
        variant: 'destructive',
      });
    },
  });

  const handleAddQualification = () => {
    if (!selectedCategory || !newQualification.displayName) {
      toast({
        title: 'Missing Information',
        description: 'Please select a category and enter a qualification name.',
        variant: 'destructive',
      });
      return;
    }

    addQualificationMutation.mutate({
      category: selectedCategory,
      qualificationKey: newQualification.displayName.toLowerCase().replace(/\s+/g, '_'),
      displayName: newQualification.displayName,
      additionalInfo: newQualification.additionalInfo,
      expiryDate: newQualification.expiryDate || null,
    });
  };

  // Group qualifications by category
  const groupedQualifications = qualifications.reduce((groups: any, qual: Qualification) => {
    if (!groups[qual.category]) {
      groups[qual.category] = [];
    }
    groups[qual.category].push(qual);
    return groups;
  }, {});

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <GraduationCap className="h-5 w-5" />
            Qualifications & Certifications
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-2">
            <div className="animate-spin h-4 w-4 border-2 border-village-wine border-t-transparent rounded-full"></div>
            Loading qualifications...
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <GraduationCap className="h-5 w-5" />
          Qualifications & Certifications
        </CardTitle>
        <CardDescription>
          Manage your professional qualifications and certifications
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Qualification categories */}
        {Object.entries(QUALIFICATION_CATEGORIES).map(([category, config]) => {
          const categoryQuals = groupedQualifications[category] || [];
          const Icon = config.icon;

          return (
            <div key={category} className="space-y-3">
              <h4 className="font-medium capitalize flex items-center gap-2">
                <Icon className="h-4 w-4" />
                {category} Qualifications
              </h4>
              
              {categoryQuals.length === 0 ? (
                <p className="text-sm text-muted-foreground">
                  No {category} qualifications added yet
                </p>
              ) : (
                <div className="space-y-2">
                  {categoryQuals.map((qual: Qualification) => (
                    <div key={qual.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="flex items-center gap-2">
                          {qual.emoji && <span>{qual.emoji}</span>}
                          <span className="font-medium">{qual.displayName}</span>
                        </div>
                        <Badge 
                          variant="secondary" 
                          className={qual.isVerified ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}
                        >
                          {qual.isVerified ? (
                            <CheckCircle className="h-3 w-3 mr-1" />
                          ) : (
                            <Clock className="h-3 w-3 mr-1" />
                          )}
                          {qual.isVerified ? 'Verified' : 'Pending'}
                        </Badge>
                      </div>
                      
                      {canAdminOverride && user?.role === 'admin' && !qual.isVerified && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => adminOverrideMutation.mutate({ 
                            qualificationId: qual.id, 
                            verified: true 
                          })}
                          disabled={adminOverrideMutation.isPending}
                        >
                          Approve
                        </Button>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}

        {/* Add new qualification */}
        <div className="border-t pt-4">
          <Dialog>
            <DialogTrigger asChild>
              <Button variant="outline" className="w-full">
                <Plus className="h-4 w-4 mr-2" />
                Add Qualification
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Qualification</DialogTitle>
                <DialogDescription>
                  Add a new qualification or certification to your profile
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4">
                <div>
                  <Label htmlFor="category">Category</Label>
                  <select
                    id="category"
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="w-full mt-1 p-2 border rounded-md"
                  >
                    <option value="">Select a category</option>
                    {Object.keys(QUALIFICATION_CATEGORIES).map((category) => (
                      <option key={category} value={category}>
                        {category.charAt(0).toUpperCase() + category.slice(1)}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <Label htmlFor="displayName">Qualification Name</Label>
                  <Input
                    id="displayName"
                    value={newQualification.displayName}
                    onChange={(e) => setNewQualification(prev => ({ 
                      ...prev, 
                      displayName: e.target.value 
                    }))}
                    placeholder="e.g., First Aid Certificate"
                  />
                </div>

                <div>
                  <Label htmlFor="additionalInfo">Additional Information (Optional)</Label>
                  <Textarea
                    id="additionalInfo"
                    value={newQualification.additionalInfo}
                    onChange={(e) => setNewQualification(prev => ({ 
                      ...prev, 
                      additionalInfo: e.target.value 
                    }))}
                    placeholder="e.g., Institution, level, or other details"
                  />
                </div>

                <div>
                  <Label htmlFor="expiryDate">Expiry Date (Optional)</Label>
                  <Input
                    id="expiryDate"
                    type="date"
                    value={newQualification.expiryDate}
                    onChange={(e) => setNewQualification(prev => ({ 
                      ...prev, 
                      expiryDate: e.target.value 
                    }))}
                  />
                </div>
              </div>

              <DialogFooter>
                <Button
                  onClick={handleAddQualification}
                  disabled={addQualificationMutation.isPending}
                  className="bg-village-wine hover:bg-village-wine/90"
                >
                  {addQualificationMutation.isPending ? 'Adding...' : 'Add Qualification'}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {/* Requirements notice */}
        <div className="flex items-start gap-2 text-amber-600 text-sm p-3 bg-amber-50 rounded-lg">
          <AlertCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
          <div>
            <p className="font-medium">Verification Required</p>
            <p>All qualifications require admin verification before appearing on your profile. Upload supporting documents or contact support for assistance.</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}