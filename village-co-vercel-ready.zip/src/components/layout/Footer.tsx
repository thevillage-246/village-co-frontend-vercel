import React from 'react';
import { Link } from 'wouter';
import { Facebook, Instagram, Twitter } from 'lucide-react';
import IntercomButton from '@/components/support/IntercomButton';

const Footer: React.FC = () => {

  return (
    <footer className="bg-village-wine text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h3 className="text-2xl font-bold mb-4">The Village Co.</h3>
          <p className="text-brushed-pink text-lg max-w-2xl mx-auto">
            Making parenting easier, one trusted connection at a time. We're building the village back with technology that works and care that's real.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-5 gap-8 mb-12">

          <div className="text-center md:text-left">
            <h4 className="font-semibold mb-4">Social</h4>
            <div className="space-y-2">
              <div>
                <a href="https://instagram.com/villagebabysitting" target="_blank" rel="noopener noreferrer" className="text-brushed-pink hover:text-white transition-colors">
                  Instagram
                </a>
              </div>
              <div>
                <a href="https://facebook.com/ittakesavillagenz" target="_blank" rel="noopener noreferrer" className="text-brushed-pink hover:text-white transition-colors">
                  Facebook
                </a>
              </div>
            </div>
          </div>
          
          <div className="text-center md:text-left">
            <h4 className="font-semibold mb-4">For Parents</h4>
            <div className="space-y-2">
              <div>
                <Link href="/find-sitter" className="text-brushed-pink hover:text-white transition-colors">
                  Find a Sitter
                </Link>
              </div>
            </div>
          </div>
          
          <div className="text-center md:text-left">
            <h4 className="font-semibold mb-4">Support</h4>
            <div className="space-y-2">
              <div>
                <Link href="/faq" className="text-brushed-pink hover:text-white transition-colors">
                  FAQ
                </Link>
              </div>
              <div>
                <IntercomButton 
                  variant="ghost" 
                  size="sm" 
                  className="text-brushed-pink hover:text-white hover:bg-transparent p-0 h-auto font-normal justify-start"
                >
                  Chat with Support
                </IntercomButton>
              </div>
              <div>
                <a href="mailto:info@thevillageco.nz?subject=Bug Report&body=Please describe the issue you encountered:" className="text-brushed-pink hover:text-white transition-colors">
                  Report a Bug
                </a>
              </div>
            </div>
          </div>
          
          <div className="text-center md:text-left">
            <h4 className="font-semibold mb-4">Legal</h4>
            <div className="space-y-2">
              <div>
                <Link href="/terms-of-service" className="text-brushed-pink hover:text-white transition-colors">
                  Terms of Service
                </Link>
              </div>
              <div>
                <Link href="/privacy-policy" className="text-brushed-pink hover:text-white transition-colors">
                  Privacy Policy
                </Link>
              </div>
            </div>
          </div>
          


          <div className="text-center md:text-left">
            <h4 className="font-semibold mb-4">Reviews</h4>
            <div className="space-y-2">
              <div className="w-full">
                <iframe 
                  src="https://widget.trustpilot.com/trustboxes/5419b6ffb0d04a09e042d5fc/index.html?businessunitId=675fa98e9a71e48b7c9ebc54&templateId=5419b6ffb0d04a09e042d5fc#locale=en-NZ&styleHeight=52px&styleWidth=100%25&theme=light&tags=ChildCare%2CBabysitting"
                  style={{
                    position: 'relative',
                    height: '52px',
                    width: '100%',
                    borderStyle: 'none',
                    display: 'block',
                    overflow: 'hidden'
                  }}
                  frameBorder="0"
                  scrolling="no"
                  title="Customer reviews powered by Trustpilot"
                />
                <a href="https://nz.trustpilot.com/evaluate/ittakesavillage.nz" target="_blank" rel="noopener noreferrer" className="text-xs text-brushed-pink hover:text-white transition-colors block mt-1">
                  View all reviews
                </a>
              </div>
              <div className="text-sm text-brushed-pink/80">
                See what families are saying about us
              </div>
            </div>
          </div>

          <div className="text-center md:text-left">
            <h4 className="font-semibold mb-4">Village Gift Cards</h4>
            <div className="space-y-2">
              <div>
                <a href="https://app.cardivo.com/giftcards/9zs06su9uj" target="_blank" rel="noopener noreferrer" className="text-brushed-pink hover:text-white transition-colors">
                  Gift the Perfect Break
                </a>
              </div>
              <div className="text-sm text-brushed-pink/80">
                Give someone special the gift of time with trusted childcare
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-brushed-pink/20 pt-8 text-center">
          <p className="text-brushed-pink">
            © 2025 The Village Co. Babysitting Reimagined.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;