import React, { useState } from 'react';
import { useLocation, Link } from 'wouter';
import { useAuth } from '@/contexts/AuthContext';
import { UserCircle, Menu, X, MessageSquare, Brain } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { NotificationPanel } from '@/components/ui/NotificationPanel';
import { USER_ROLES } from '@shared/schema';

const Navbar: React.FC = () => {
  const [location, navigate] = useLocation();
  const { user, logout } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  // Helper for navigation links
  const NavItem = ({ href, active, onClick, children }: { 
    href: string, 
    active: boolean, 
    onClick?: () => void, 
    children: React.ReactNode 
  }) => (
    <Link href={href}>
      <span 
        onClick={onClick}
        className={`${active ? 'border-village-wine text-village-wine' : 'border-transparent text-gray-600 hover:border-village-rose hover:text-village-wine'} inline-flex items-center px-2 sm:px-3 py-4 sm:py-5 border-b-2 text-sm font-medium cursor-pointer h-16 sm:h-18 lg:h-20 transition-colors`}
      >
        {children}
      </span>
    </Link>
  );

  // Helper for mobile navigation links
  const MobileNavItem = ({ href, active, onClick, children }: { 
    href: string, 
    active: boolean, 
    onClick?: () => void, 
    children: React.ReactNode 
  }) => (
    <Link href={href}>
      <span 
        className={`${active ? 'bg-neutral-50 border-primary text-primary' : 'border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700'} block pl-3 pr-4 py-2 border-l-4 text-base font-medium cursor-pointer`}
        onClick={() => {
          if (onClick) onClick();
          setIsMobileMenuOpen(false);
        }}
      >
        {children}
      </span>
    </Link>
  );

  return (
    <nav className="bg-white shadow-sm border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 sm:h-18 lg:h-20">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <Link href="/">
                <span className="flex items-center cursor-pointer">
                  <img src="/attached_assets/IMG_4964_1751883228689.png" alt="Village Co. Logo" className="h-12 sm:h-14 lg:h-16 w-auto" />
                </span>
              </Link>
            </div>
            <div className="hidden sm:ml-6 sm:flex sm:items-center sm:space-x-8">
              <NavItem href="/" active={location === '/'}>
                Home
              </NavItem>
              
              {user ? (
                <>
                  {user.role === USER_ROLES.PARENT && (
                    <>
                      <NavItem href="/dashboard" active={location === '/dashboard'}>
                        Dashboard
                      </NavItem>
                      <NavItem href="/find-sitter" active={location === '/find-sitter'}>
                        Find a Sitter
                      </NavItem>
                      <NavItem href="/instant-booking" active={location === '/instant-booking'}>
                        ✨ Quick Match
                      </NavItem>
                    </>
                  )}
                  
                  {user.role === USER_ROLES.SITTER && (
                    <>
                      <NavItem href="/sitter/dashboard" active={location === '/sitter/dashboard'}>
                        Dashboard
                      </NavItem>
                      <NavItem href="/sitter/availability" active={location === '/sitter/availability'}>
                        My Availability
                      </NavItem>
                      <NavItem href="/sitter/booking-requests" active={location === '/sitter/booking-requests'}>
                        Booking Requests
                      </NavItem>
                    </>
                  )}
                  
                  {user.role === USER_ROLES.ADMIN && (
                    <>
                      <NavItem href="/admin" active={location === '/admin'}>
                        Dashboard
                      </NavItem>
                      <NavItem href="/admin/sitter-approvals" active={location === '/admin/sitter-approvals'}>
                        Sitter Approvals
                      </NavItem>
                      <NavItem href="/admin/concierge-requests" active={location === '/admin/concierge-requests'}>
                        Concierge Requests
                      </NavItem>
                      <NavItem href="/admin/badge-management" active={location === '/admin/badge-management'}>
                        Badge Management
                      </NavItem>
                    </>
                  )}
                  

                </>
              ) : (
                <>
                  <button 
                    onClick={() => {
                      if (location !== '/') {
                        navigate('/');
                        setTimeout(() => document.getElementById('why-we-started')?.scrollIntoView({ behavior: 'smooth' }), 300);
                      } else {
                        document.getElementById('why-we-started')?.scrollIntoView({ behavior: 'smooth' });
                      }
                    }}
                    className="inline-flex items-center px-2 sm:px-3 py-4 sm:py-5 border-b-2 border-transparent text-sm font-medium text-gray-500 hover:border-gray-300 hover:text-gray-700 cursor-pointer h-16 sm:h-18 lg:h-20"
                  >
                    Our Story
                  </button>
                  <button 
                    onClick={() => {
                      if (location !== '/') {
                        navigate('/');
                        setTimeout(() => document.getElementById('for-parents')?.scrollIntoView({ behavior: 'smooth' }), 300);
                      } else {
                        document.getElementById('for-parents')?.scrollIntoView({ behavior: 'smooth' });
                      }
                    }}
                    className="inline-flex items-center px-2 sm:px-3 py-4 sm:py-5 border-b-2 border-transparent text-sm font-medium text-gray-500 hover:border-gray-300 hover:text-gray-700 cursor-pointer h-16 sm:h-18 lg:h-20"
                  >
                    For Parents
                  </button>
                  <button 
                    onClick={() => {
                      if (location !== '/') {
                        navigate('/');
                        setTimeout(() => document.getElementById('for-sitters')?.scrollIntoView({ behavior: 'smooth' }), 300);
                      } else {
                        document.getElementById('for-sitters')?.scrollIntoView({ behavior: 'smooth' });
                      }
                    }}
                    className="inline-flex items-center px-2 sm:px-3 py-4 sm:py-5 border-b-2 border-transparent text-sm font-medium text-gray-500 hover:border-gray-300 hover:text-gray-700 cursor-pointer h-16 sm:h-18 lg:h-20"
                  >
                    For Sitters
                  </button>
                  <NavItem href="/hotels" active={location === '/hotels'}>
                    Hotels
                  </NavItem>
                  <NavItem href="/employers" active={location === '/employers'}>
                    Employers
                  </NavItem>
                  <NavItem href="/plans-events" active={location === '/plans-events'}>
                    Events
                  </NavItem>
                  <NavItem href="/find-sitter" active={location === '/find-sitter'}>
                    Book Now
                  </NavItem>
                </>
              )}
            </div>
          </div>
          
          <div className="hidden sm:ml-6 sm:flex sm:items-center">
            {user ? (
              <div className="flex items-center space-x-4">
                <button 
                  onClick={() => navigate('/messages')}
                  className={`p-2 rounded-full ${location === '/messages' ? 'bg-primary/10 text-primary' : 'text-gray-500 hover:text-gray-700 hover:bg-gray-100'}`}
                >
                  <MessageSquare className="h-5 w-5" />
                  <span className="sr-only">Messages</span>
                </button>
                <NotificationPanel />
                
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button className="bg-white rounded-full flex text-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary">
                      <span className="sr-only">Open user menu</span>
                      {user.profileImage ? (
                        <img
                          className="h-8 w-8 rounded-full object-cover"
                          src={user.profileImage}
                          alt="User profile"
                        />
                      ) : (
                        <UserCircle className="h-8 w-8 text-gray-400" />
                      )}
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuLabel>My Account</DropdownMenuLabel>
                    <DropdownMenuItem asChild>
                      <Link href={user.role === USER_ROLES.SITTER ? "/sitter/profile" : "/edit-parent-profile"}>
                        Profile
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild>
                      <Link href="/account-settings">
                        Settings
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleLogout}>
                      Logout
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            ) : (
              <div className="flex items-center space-x-4">
                <Link href="/login">
                  <Button variant="outline">Sign In</Button>
                </Link>
                <Link href="/register">
                  <Button className="bg-village-wine hover:bg-village-wine/90">Join the Village</Button>
                </Link>
              </div>
            )}
          </div>
          
          <div className="-mr-2 flex items-center sm:hidden">
            <button
              type="button"
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-primary"
              onClick={toggleMobileMenu}
            >
              <span className="sr-only">{isMobileMenuOpen ? 'Close main menu' : 'Open main menu'}</span>
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isMobileMenuOpen && (
        <div className="sm:hidden">
          <div className="pt-2 pb-3 space-y-1">
            <MobileNavItem href="/" active={location === '/'}>
              Home
            </MobileNavItem>
            
            {user ? (
              <>
                {user.role === USER_ROLES.PARENT && (
                  <>
                    <MobileNavItem href="/dashboard" active={location === '/dashboard'}>
                      Dashboard
                    </MobileNavItem>
                    <MobileNavItem href="/find-sitter" active={location === '/find-sitter'}>
                      Book a Sitter
                    </MobileNavItem>
                    <MobileNavItem href="/instant-booking" active={location === '/instant-booking'}>
                      Instant Booking
                    </MobileNavItem>
                  </>
                )}
                
                {user.role === USER_ROLES.SITTER && (
                  <>
                    <MobileNavItem href="/sitter/dashboard" active={location === '/sitter/dashboard'}>
                      Dashboard
                    </MobileNavItem>
                    <MobileNavItem href="/sitter/availability" active={location === '/sitter/availability'}>
                      My Availability
                    </MobileNavItem>
                    <MobileNavItem href="/sitter/booking-requests" active={location === '/sitter/booking-requests'}>
                      Booking Requests
                    </MobileNavItem>
                  </>
                )}
                
                {user.role === USER_ROLES.ADMIN && (
                  <>
                    <MobileNavItem href="/admin" active={location === '/admin'}>
                      Dashboard
                    </MobileNavItem>
                    <MobileNavItem href="/admin/sitter-approvals" active={location === '/admin/sitter-approvals'}>
                      Sitter Approvals
                    </MobileNavItem>
                    <MobileNavItem href="/admin/concierge-requests" active={location === '/admin/concierge-requests'}>
                      Concierge Requests
                    </MobileNavItem>
                    <MobileNavItem href="/admin/badge-management" active={location === '/admin/badge-management'}>
                      Badge Management
                    </MobileNavItem>
                  </>
                )}
                

              </>
            ) : (
              <>
                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    if (location !== '/') {
                      navigate('/');
                      setTimeout(() => document.getElementById('why-we-started')?.scrollIntoView({ behavior: 'smooth' }), 400);
                    } else {
                      setTimeout(() => document.getElementById('why-we-started')?.scrollIntoView({ behavior: 'smooth' }), 100);
                    }
                  }}
                  className="border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700 block pl-3 pr-4 py-2 border-l-4 text-base font-medium w-full text-left"
                >
                  Our Story
                </button>
                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    if (location !== '/') {
                      navigate('/');
                      setTimeout(() => document.getElementById('for-parents')?.scrollIntoView({ behavior: 'smooth' }), 400);
                    } else {
                      setTimeout(() => document.getElementById('for-parents')?.scrollIntoView({ behavior: 'smooth' }), 100);
                    }
                  }}
                  className="border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700 block pl-3 pr-4 py-2 border-l-4 text-base font-medium w-full text-left"
                >
                  For Parents
                </button>
                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    if (location !== '/') {
                      navigate('/');
                      setTimeout(() => document.getElementById('for-sitters')?.scrollIntoView({ behavior: 'smooth' }), 400);
                    } else {
                      setTimeout(() => document.getElementById('for-sitters')?.scrollIntoView({ behavior: 'smooth' }), 100);
                    }
                  }}
                  className="border-transparent text-gray-500 hover:bg-gray-50 hover:border-gray-300 hover:text-gray-700 block pl-3 pr-4 py-2 border-l-4 text-base font-medium w-full text-left"
                >
                  For Sitters
                </button>
                <MobileNavItem href="/hotels" active={location === '/hotels'} onClick={() => setIsMobileMenuOpen(false)}>
                  Hotels
                </MobileNavItem>
                <MobileNavItem href="/employers" active={location === '/employers'} onClick={() => setIsMobileMenuOpen(false)}>
                  Employers
                </MobileNavItem>
                <MobileNavItem href="/plans-events" active={location === '/plans-events'} onClick={() => setIsMobileMenuOpen(false)}>
                  Events
                </MobileNavItem>
                <MobileNavItem href="/find-sitter" active={location === '/find-sitter'} onClick={() => setIsMobileMenuOpen(false)}>
                  Book Now
                </MobileNavItem>

              </>
            )}
          </div>
          
          {user ? (
            <div className="pt-4 pb-3 border-t border-gray-200">
              <div className="flex items-center px-4">
                <div className="flex-shrink-0">
                  {user.profileImage ? (
                    <img
                      className="h-10 w-10 rounded-full object-cover"
                      src={user.profileImage}
                      alt="User profile"
                    />
                  ) : (
                    <UserCircle className="h-10 w-10 text-gray-400" />
                  )}
                </div>
                <div className="ml-3">
                  <div className="text-base font-medium text-gray-800">{user.firstName} {user.lastName}</div>
                  <div className="text-sm font-medium text-gray-500">{user.email}</div>
                </div>
              </div>
              <div className="mt-3 space-y-1">
                <button
                  className="block w-full text-left px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100"
                  onClick={() => {
                    navigate('/messages');
                    setIsMobileMenuOpen(false);
                  }}
                >
                  <div className="flex items-center">
                    <MessageSquare className="h-5 w-5 mr-2" />
                    Messages
                  </div>
                </button>
                <button
                  className="block w-full text-left px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100"
                  onClick={() => {
                    navigate(user.role === USER_ROLES.SITTER ? '/sitter/profile' : '/edit-parent-profile');
                    setIsMobileMenuOpen(false);
                  }}
                >
                  Your Profile
                </button>
                <button
                  className="block w-full text-left px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100"
                  onClick={() => {
                    navigate('/account-settings');
                    setIsMobileMenuOpen(false);
                  }}
                >
                  Settings
                </button>
                <button
                  className="block w-full text-left px-4 py-2 text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100"
                  onClick={() => {
                    handleLogout();
                    setIsMobileMenuOpen(false);
                  }}
                >
                  Sign out
                </button>
              </div>
            </div>
          ) : (
            <div className="pt-4 pb-3 border-t border-gray-200">
              <div className="flex flex-col space-y-3 px-4">
                <Link href="/login">
                  <span
                    className="block w-full px-4 py-2 text-center text-base font-medium text-gray-500 hover:text-gray-800 hover:bg-gray-100 rounded border border-gray-300 cursor-pointer"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    Sign In
                  </span>
                </Link>
                <Link href="/register">
                  <span
                    className="block w-full px-4 py-2 text-center text-base font-medium text-white bg-primary hover:bg-primary-dark rounded cursor-pointer"
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    Join the Village
                  </span>
                </Link>
              </div>
            </div>
          )}
        </div>
      )}
    </nav>
  );
};

export default Navbar;