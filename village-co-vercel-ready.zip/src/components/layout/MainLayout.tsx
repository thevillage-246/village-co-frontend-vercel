import React from 'react';
import Navbar from './Navbar';
import Footer from './Footer';
import PodcastSection from '@/components/sections/PodcastSection';
import { HelpWidget } from '@/components/ui/HelpWidget';
import { FloatingActionButton } from '@/components/ui/FloatingActionButton';
import { useAuth } from '@/contexts/AuthContext';

interface MainLayoutProps {
  children: React.ReactNode;
}

const MainLayout: React.FC<MainLayoutProps> = ({ children }) => {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="animate-spin h-12 w-12 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen" style={{ backgroundColor: '#F9F5F0' }}>
      <Navbar />
      <main className="flex-grow">
        {children}
      </main>
      <PodcastSection />
      <Footer />
      <FloatingActionButton />
    </div>
  );
};

export default MainLayout;
