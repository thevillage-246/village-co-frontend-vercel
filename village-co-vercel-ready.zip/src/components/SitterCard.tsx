import { useState } from 'react';
import { Star, MapPin, Shield, CheckCircle, Award, Calendar, Clock, MessageCircle, Heart } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { useLocation } from 'wouter';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useMutation, useQueryClient } from '@tanstack/react-query';

interface Review {
  id: number;
  rating: number;
  content: string;
  authorName: string;
  createdAt: string;
}

interface SitterCardProps {
  sitter: {
    id: number;
    userId?: number;
    user_id?: number;
    sharetribeId?: string;
    firstName?: string;
    lastName?: string;
    full_name?: string;
    title?: string;
    bio?: string;
    description?: string;
    experience?: string;
    hourlyRate?: string;
    hourly_rate?: string;
    location?: string;
    avatar_url?: string;
    photoUrl?: string;
    profileImage?: string;
    badge?: string;
    rating?: number;
    reviewCount?: number;
    reviews?: Review[];
    villageVerified?: boolean;
    firstAidCertified?: boolean;
    backgroundChecked?: boolean;
    isApproved?: boolean;
    isFavorite?: boolean;
  };
}

export default function SitterCard({ sitter }: SitterCardProps) {
  const [isBooking, setIsBooking] = useState(false);
  const [isFavorite, setIsFavorite] = useState(sitter.isFavorite || false);
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star 
        key={i} 
        className={`h-4 w-4 ${i < Math.floor(rating) ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`} 
      />
    ));
  };

  const toggleFavoriteMutation = useMutation({
    mutationFn: async () => {
      const sitterId = sitter.userId || sitter.id || sitter.user_id;
      
      console.log('🔄 Toggle favorite mutation started');
      console.log('Sitter ID:', sitterId, 'Type:', typeof sitterId);
      console.log('Current isFavorite state:', isFavorite);
      
      if (!sitterId) {
        throw new Error('Sitter ID not found');
      }

      if (isFavorite) {
        // Removing from favorites
        console.log('📝 Removing from favorites...');
        console.log('About to call apiRequest with:', 'DELETE', `/api/favourites/${sitterId}`, undefined);
        const response = await apiRequest('DELETE', `/api/favourites/${sitterId}`, undefined);
        console.log('✅ Remove response:', response.status);
        return response;
      } else {
        // Adding to favorites
        console.log('📝 Adding to favorites...');
        console.log('About to call apiRequest with:', 'POST', '/api/favourites', { sitterId });
        const response = await apiRequest('POST', '/api/favourites', { sitterId });
        console.log('✅ Add response:', response.status);
        return response;
      }
    },
    onSuccess: () => {
      setIsFavorite(!isFavorite);
      toast({
        title: isFavorite ? "Removed from favorites" : "Added to favorites",
        description: isFavorite 
          ? `${sitter.firstName}${sitter.lastName ? ` ${sitter.lastName[0]}.` : ''} has been removed from your favorites` 
          : `${sitter.firstName}${sitter.lastName ? ` ${sitter.lastName[0]}.` : ''} has been added to your favorites`,
      });
      
      // Invalidate queries to refresh the data
      queryClient.invalidateQueries({ queryKey: ['/api/sitters'] });
      queryClient.invalidateQueries({ queryKey: ['/api/favourites'] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update favorites",
        variant: "destructive",
      });
    },
  });

  const handleBookNow = async (type: 'oneoff' | 'recurring') => {
    try {
      setIsBooking(true);
      
      // Navigate to booking page with sitter info
      const sitterId = sitter.userId || sitter.user_id;
      if (type === 'oneoff') {
        navigate(`/book?sitterId=${sitterId}`);
      } else {
        navigate(`/book-recurring?sitterId=${sitterId}`);
      }
      
      toast({
        title: "Redirecting to booking",
        description: `Setting up ${type === 'oneoff' ? 'one-off' : 'recurring'} booking with ${sitter.firstName || sitter.full_name || sitter.title}`
      });
    } catch (error) {
      console.error('Booking error:', error);
      toast({
        title: "Booking Error",
        description: "Unable to start booking process. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsBooking(false);
    }
  };

  // Handle name display with proper fallbacks - show first name + last initial for privacy
  const sitterName = (() => {
    if (sitter.firstName && sitter.lastName) {
      // Clean up firstName if it looks like a username (contains numbers, @, or is too long)
      let firstName = sitter.firstName;
      if (sitter.firstName.includes('@') || /\d/.test(sitter.firstName) || sitter.firstName.length > 15) {
        // Extract proper name from username-like string
        const cleanName = sitter.firstName.replace(/\d+/g, '').split(/[._@]/)[0];
        firstName = cleanName.charAt(0).toUpperCase() + cleanName.slice(1).toLowerCase();
      }
      // Show first name + last initial
      const lastInitial = sitter.lastName.charAt(0).toUpperCase();
      return `${firstName} ${lastInitial}.`;
    }
    if (sitter.firstName) {
      return sitter.firstName;
    }
    return sitter.full_name ? sitter.full_name.split(' ')[0] : 
           sitter.title ? sitter.title.split(' ')[0] : 'Village Sitter';
  })();
    
  // Handle image display with proper fallbacks
  const sitterImage = sitter.avatar_url || sitter.photoUrl || sitter.profileImage;
  
  // Create initials for avatar fallback
  const getInitials = (name: string) => {
    const nameParts = name.split(' ').filter(part => part.length > 0);
    if (nameParts.length >= 2) {
      return `${nameParts[0][0]}${nameParts[1][0]}`.toUpperCase();
    } else if (nameParts.length === 1) {
      return nameParts[0].substring(0, 2).toUpperCase();
    }
    return 'VS';
  };
  const sitterBio = sitter.bio || sitter.description || sitter.experience || "Experienced babysitter available in your area.";
  const hourlyRate = sitter.hourlyRate || sitter.hourly_rate || '25';
  const sitterRating = sitter.rating || 4.5;
  const reviewCount = sitter.reviewCount || sitter.reviews?.length || 0;

  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow relative">
      <CardContent className="p-6">
        {/* Favorite button */}
        <Button
          variant="ghost"
          size="sm"
          onClick={(e) => {
            e.stopPropagation();
            toggleFavoriteMutation.mutate();
          }}
          className="absolute top-2 right-2 z-10 h-8 w-8 p-0 bg-white/80 hover:bg-white/90 rounded-full shadow-sm"
          disabled={toggleFavoriteMutation.isPending}
        >
          <Heart 
            className={`h-4 w-4 ${isFavorite ? 'fill-red-500 text-red-500' : 'text-gray-400'}`} 
          />
        </Button>
        
        <div className="flex justify-between items-start">
          <div className="flex items-center space-x-4">
            <Avatar className="h-16 w-16 border-2 border-linen">
              <AvatarImage src={sitterImage || ''} alt={sitterName} />
              <AvatarFallback className="bg-rose text-wine font-semibold">
                {getInitials(sitterName)}
              </AvatarFallback>
            </Avatar>
            <div>
              <h3 className="font-semibold text-lg">{sitterName}</h3>
              <div className="flex items-center mt-1">
                {renderStars(sitterRating)}
                <span className="text-sm text-muted-foreground ml-2">
                  {sitterRating.toFixed(1)} (
                  <button 
                    onClick={() => navigate(`/profile/${sitter.userId || sitter.user_id}#reviews`)}
                    className="text-village-wine hover:underline cursor-pointer"
                  >
                    {reviewCount} reviews
                  </button>
                  )
                </span>
              </div>
              {sitter.location && (
                <p className="text-sm text-muted-foreground flex items-center mt-1">
                  <MapPin className="h-3 w-3 mr-1" />
                  {sitter.location}
                </p>
              )}
            </div>
          </div>
          
          {sitter.badge && (
            <Badge variant="secondary" className="bg-eucalyptus/20 text-eucalyptus">
              {sitter.badge}
            </Badge>
          )}
        </div>
        
        {/* Trust Indicators */}
        <div className="mt-4 flex flex-wrap gap-2">
          {sitter.villageVerified && (
            <div className="flex items-center text-xs bg-village-wine/10 text-village-wine px-2 py-1 rounded-full">
              <Award className="w-3 h-3 mr-1" />
              Village Verified
            </div>
          )}
          {sitter.backgroundChecked && (
            <div className="flex items-center text-xs bg-purple-50 text-purple-700 px-2 py-1 rounded-full">
              <Shield className="w-3 h-3 mr-1" />
              Background Check
            </div>
          )}
          {sitter.firstAidCertified && (
            <div className="flex items-center text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded-full">
              <CheckCircle className="w-3 h-3 mr-1" />
              First Aid
            </div>
          )}
        </div>
        
        <p className="text-sm text-muted-foreground mt-3 line-clamp-3">
          {sitterBio}
        </p>

        {/* Recent Review */}
        {sitter.reviews && sitter.reviews.length > 0 && (
          <div className="mt-4 p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-1 mb-2">
              {renderStars(sitter.reviews[0].rating)}
              <span className="text-xs text-muted-foreground ml-1">
                {sitter.reviews[0].authorName || 'Village Parent'}
              </span>
            </div>
            <p className="text-sm text-gray-600 italic line-clamp-2">
              "{sitter.reviews[0].content}"
            </p>
            {reviewCount > 1 && (
              <button 
                onClick={() => navigate(`/profile/${sitter.userId || sitter.user_id}#reviews`)}
                className="text-xs text-village-wine hover:underline mt-2 cursor-pointer block"
              >
                +{reviewCount - 1} more reviews
              </button>
            )}
          </div>
        )}
        
        <div className="mt-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-2xl font-bold text-village-wine">{hourlyRate}/hr</p>
              <p className="text-xs text-muted-foreground">Village verified</p>
            </div>
          </div>
          
          {/* Mobile-optimized button layout */}
          <div className="space-y-2">
            {/* Primary action button - full width on mobile */}
            <Popover>
              <PopoverTrigger asChild>
                <Button 
                  size="sm"
                  className="bg-village-wine hover:bg-village-wine/90 w-full"
                  disabled={isBooking}
                >
                  Book Now
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-56" align="center">
                <div className="grid gap-2">
                  <Button
                    variant="outline"
                    onClick={() => handleBookNow('oneoff')}
                    className="justify-start"
                    disabled={isBooking}
                  >
                    <Calendar className="h-4 w-4 mr-2" />
                    One-off Booking
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => handleBookNow('recurring')}
                    className="justify-start"
                    disabled={isBooking}
                  >
                    <Clock className="h-4 w-4 mr-2" />
                    Recurring Booking
                  </Button>
                </div>
              </PopoverContent>
            </Popover>
            
            {/* Secondary actions - side by side */}
            <div className="grid grid-cols-2 gap-2">
              <Button 
                size="sm"
                variant="outline"
                onClick={() => navigate(`/profile/${sitter.userId || sitter.user_id}`)}
                className="border-village-wine text-village-wine hover:bg-village-wine/10 text-xs"
              >
                View Profile
              </Button>
              <Button 
                size="sm"
                variant="outline"
                onClick={() => navigate(`/messages?sitterId=${sitter.userId || sitter.user_id}`)}
                className="border-village-wine text-village-wine hover:bg-village-wine/10 text-xs"
              >
                <MessageCircle className="h-3 w-3 mr-1" />
                Contact
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}