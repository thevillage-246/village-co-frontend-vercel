import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { CheckCircle, Calendar, Clock, Heart, Star, Repeat } from 'lucide-react';
import { format } from 'date-fns';
import AutoPrefillBookingForm from './AutoPrefillBookingForm';

interface BookingConfirmationRebookProps {
  booking: {
    id: number;
    startTime: Date;
    endTime: Date;
    totalAmount: string;
    sitter: {
      id: number;
      name: string;
      photoUrl?: string;
      hourlyRate: string;
      rating: number;
      reviewCount: number;
    };
    children: Array<{
      id: number;
      firstName: string;
      lastName: string;
      age: number;
      specialNeeds?: string;
    }>;
    specialRequests?: string;
    sitNotes?: string;
  };
  onClose: () => void;
}

export default function BookingConfirmationRebook({ booking, onClose }: BookingConfirmationRebookProps) {
  const [showRebookForm, setShowRebookForm] = useState(false);
  const [rebookingSuccess, setRebookingSuccess] = useState(false);

  const handleRebookClick = () => {
    setShowRebookForm(true);
  };

  const handleRebookSuccess = (newBookingId: number) => {
    setRebookingSuccess(true);
    setShowRebookForm(false);
    // Could redirect to new booking details or show success message
  };

  const handleRebookCancel = () => {
    setShowRebookForm(false);
  };

  if (showRebookForm) {
    return (
      <Dialog open={true} onOpenChange={() => setShowRebookForm(false)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Rebook Your Favourite Sitter</DialogTitle>
          </DialogHeader>
          <AutoPrefillBookingForm
            originalBooking={{
              id: booking.id,
              sitterId: booking.sitter.id,
              sitterName: booking.sitter.name,
              sitterPhotoUrl: booking.sitter.photoUrl,
              hourlyRate: booking.sitter.hourlyRate,
              startTime: booking.startTime,
              endTime: booking.endTime,
              specialRequests: booking.specialRequests,
              sitNotes: booking.sitNotes,
              children: booking.children,
            }}
            onRebookSuccess={handleRebookSuccess}
            onCancel={handleRebookCancel}
          />
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {/* Success Header */}
      <Card className="border-green-200 bg-green-50">
        <CardHeader className="text-center pb-4">
          <div className="flex justify-center mb-4">
            <CheckCircle className="h-16 w-16 text-green-600" />
          </div>
          <CardTitle className="text-2xl text-green-800">
            Booking Confirmed!
          </CardTitle>
          <CardDescription className="text-green-700 text-lg">
            Your session has been successfully booked
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Booking Details */}
      <Card>
        <CardHeader>
          <CardTitle className="text-village-wine">Session Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Sitter Information */}
          <div className="flex items-center space-x-4 p-4 bg-muted rounded-lg">
            <Avatar className="h-16 w-16">
              <AvatarImage src={booking.sitter.photoUrl} />
              <AvatarFallback className="bg-village-wine text-white text-lg">
                {booking.sitter.name.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <h3 className="text-xl font-semibold">{booking.sitter.name}</h3>
                <Badge variant="secondary" className="bg-green-100 text-green-800">
                  <Star className="w-3 h-3 mr-1" />
                  {booking.sitter.rating} ({booking.sitter.reviewCount})
                </Badge>
              </div>
              <p className="text-muted-foreground">
                ${booking.sitter.hourlyRate}/hour
              </p>
            </div>
          </div>

          {/* Date and Time */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="flex items-center p-3 bg-village-wine/5 rounded-lg">
              <Calendar className="h-5 w-5 text-village-wine mr-3" />
              <div>
                <p className="font-medium">Date</p>
                <p className="text-sm text-muted-foreground">
                  {format(booking.startTime, 'EEEE, MMMM do, yyyy')}
                </p>
              </div>
            </div>
            <div className="flex items-center p-3 bg-village-wine/5 rounded-lg">
              <Clock className="h-5 w-5 text-village-wine mr-3" />
              <div>
                <p className="font-medium">Time</p>
                <p className="text-sm text-muted-foreground">
                  {format(booking.startTime, 'h:mm a')} - {format(booking.endTime, 'h:mm a')}
                </p>
              </div>
            </div>
          </div>

          {/* Children */}
          <div>
            <h4 className="font-medium mb-2">Children</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {booking.children.map((child) => (
                <div key={child.id} className="flex items-center p-2 bg-muted rounded">
                  <div className="w-8 h-8 bg-village-wine rounded-full flex items-center justify-center text-white text-sm font-medium mr-3">
                    {child.firstName[0]}
                  </div>
                  <div>
                    <p className="font-medium text-sm">{child.firstName} {child.lastName}</p>
                    <p className="text-xs text-muted-foreground">Age {child.age}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Total Cost */}
          <div className="border-t pt-4">
            <div className="flex justify-between items-center">
              <span className="text-lg font-medium">Total Cost</span>
              <span className="text-2xl font-bold text-village-wine">${booking.totalAmount}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Rebooking Prompt */}
      <Card className="border-brushed-pink bg-gradient-to-r from-brushed-pink/10 to-village-wine/10">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-2">
            <Heart className="h-8 w-8 text-village-wine" />
          </div>
          <CardTitle className="text-village-wine">Love this sitter?</CardTitle>
          <CardDescription className="text-base">
            Book {booking.sitter.name} again with the same routine and preferences
          </CardDescription>
        </CardHeader>
        <CardContent className="text-center space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-sm">
            <div className="flex items-center justify-center p-2 bg-white/50 rounded-lg">
              <Repeat className="w-4 h-4 mr-2 text-village-wine" />
              Same trusted sitter
            </div>
            <div className="flex items-center justify-center p-2 bg-white/50 rounded-lg">
              <Calendar className="w-4 h-4 mr-2 text-village-wine" />
              Pre-filled preferences
            </div>
            <div className="flex items-center justify-center p-2 bg-white/50 rounded-lg">
              <Clock className="w-4 h-4 mr-2 text-village-wine" />
              Quick rebooking
            </div>
          </div>
          
          <Button
            onClick={handleRebookClick}
            className="w-full bg-village-wine hover:bg-village-wine/90 text-white"
            size="lg"
          >
            <Repeat className="w-5 h-5 mr-2" />
            Rebook {booking.sitter.name}
          </Button>
          
          <p className="text-xs text-muted-foreground">
            You can also rebook later from your dashboard or via email reminder
          </p>
        </CardContent>
      </Card>

      {/* Success Message for Rebooking */}
      {rebookingSuccess && (
        <Card className="border-green-200 bg-green-50">
          <CardContent className="text-center py-6">
            <CheckCircle className="h-12 w-12 text-green-600 mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-green-800 mb-2">
              Another Session Booked!
            </h3>
            <p className="text-green-700">
              Your additional session with {booking.sitter.name} has been confirmed.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Action Buttons */}
      <div className="flex gap-3">
        <Button 
          onClick={onClose} 
          variant="outline" 
          className="flex-1"
        >
          Back to Dashboard
        </Button>
        <Button 
          onClick={() => window.location.href = `/messages?sitter=${booking.sitter.id}`}
          variant="outline"
          className="flex-1"
        >
          Message Sitter
        </Button>
      </div>
    </div>
  );
}