import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Calendar, Clock, RefreshCw, Star, User } from "lucide-react";
import { format } from "date-fns";

interface RebookingPrompt {
  id: number;
  parentId: number;
  sitterId: number;
  originalBookingId: number;
  status: string;
  promptSentAt: string;
  emailSentAt?: string;
  viewedAt?: string;
  completedAt?: string;
  newBookingId?: number;
  expiresAt: string;
  createdAt: string;
  updatedAt: string;
}

interface RebookingSuggestionProps {
  completedBooking: any;
  sitter: any;
  onRebookClick: (sitterId: number, originalBookingId: number) => void;
}

export default function RebookingSuggestion({ 
  completedBooking, 
  sitter, 
  onRebookClick 
}: RebookingSuggestionProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showPrompt, setShowPrompt] = useState(false);

  // Check if this booking has existing rebooking prompts
  const { data: prompts } = useQuery({
    queryKey: ["/api/rebooking/prompts"],
    select: (data: RebookingPrompt[]) => 
      data.filter(prompt => prompt.originalBookingId === completedBooking.id),
  });

  // Create rebooking prompt mutation
  const createPromptMutation = useMutation({
    mutationFn: (data: { originalBookingId: number; sitterId: number }) =>
      apiRequest("POST", "/api/rebooking/create-prompt", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/rebooking/prompts"] });
      toast({
        title: "Rebooking reminder set!",
        description: "We'll send you an email reminder to rebook this sitter in 24 hours.",
      });
      setShowPrompt(false);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to set rebooking reminder",
        variant: "destructive",
      });
    },
  });

  // Show rebooking suggestion 24 hours after booking completion
  useEffect(() => {
    if (completedBooking.completedAt) {
      const completedDate = new Date(completedBooking.completedAt);
      const twentyFourHoursLater = new Date(completedDate.getTime() + 24 * 60 * 60 * 1000);
      const now = new Date();
      
      if (now >= twentyFourHoursLater && !prompts?.length) {
        setShowPrompt(true);
      }
    }
  }, [completedBooking.completedAt, prompts]);

  const handleCreateReminder = () => {
    createPromptMutation.mutate({
      originalBookingId: completedBooking.id,
      sitterId: sitter.id,
    });
  };

  const handleRebookNow = () => {
    onRebookClick(sitter.id, completedBooking.id);
  };

  if (!showPrompt && !prompts?.length) {
    return null;
  }

  const activePrompt = prompts?.find(p => p.status === "pending");
  const completedPrompt = prompts?.find(p => p.status === "completed");

  return (
    <Card className="border-2 border-dashed border-[#6b3e4b] bg-gradient-to-r from-[#ebd3cb]/10 to-[#eae1d6]/10">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <RefreshCw className="h-5 w-5 text-[#6b3e4b]" />
          <CardTitle className="text-lg text-[#6b3e4b]">
            {completedPrompt ? "Rebook Completed!" : "Rebook Your Sitter?"}
          </CardTitle>
        </div>
        <CardDescription>
          {completedPrompt 
            ? "You've successfully rebooked this sitter. Thanks for using The Village Co!"
            : "Had a great experience? Book this sitter again!"
          }
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Sitter Summary */}
        <div className="flex items-center gap-3 p-3 bg-white/50 rounded-lg">
          <div className="flex-shrink-0">
            <div className="w-12 h-12 bg-[#6b3e4b] rounded-full flex items-center justify-center">
              <User className="h-6 w-6 text-white" />
            </div>
          </div>
          <div className="flex-1">
            <h4 className="font-medium text-[#6b3e4b]">
              {sitter.user?.firstName} {sitter.user?.lastName}
            </h4>
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Star className="h-4 w-4 fill-current text-yellow-400" />
              <span>{sitter.rating || "5.0"}</span>
              <span>•</span>
              <span>${sitter.hourlyRate}/hour</span>
            </div>
          </div>
          {sitter.badge && (
            <Badge variant="outline" className="bg-[#ebd3cb] text-[#6b3e4b] border-[#6b3e4b]">
              {sitter.badge}
            </Badge>
          )}
        </div>

        {/* Original Booking Details */}
        <div className="p-3 bg-gray-50 rounded-lg">
          <h5 className="font-medium text-gray-900 mb-2">Previous Session</h5>
          <div className="space-y-1 text-sm text-gray-600">
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              <span>{format(new Date(completedBooking.startTime), "EEEE, MMMM d, yyyy")}</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4" />
              <span>
                {format(new Date(completedBooking.startTime), "h:mm a")} - 
                {format(new Date(completedBooking.endTime), "h:mm a")}
              </span>
            </div>
            {completedBooking.sitNotes && (
              <p className="mt-2 text-xs bg-white p-2 rounded border">
                <strong>Notes:</strong> {completedBooking.sitNotes}
              </p>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        {completedPrompt ? (
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <p className="text-green-700 text-sm">
              ✅ Rebooking completed on {format(new Date(completedPrompt.completedAt), "MMM d, yyyy")}
            </p>
          </div>
        ) : activePrompt ? (
          <div className="space-y-2">
            <p className="text-sm text-gray-600 text-center">
              Reminder set! We'll email you about rebooking this sitter.
            </p>
            <div className="text-center">
              <Button 
                onClick={handleRebookNow}
                className="bg-[#6b3e4b] hover:bg-[#5a3340] text-white"
              >
                Rebook Now
              </Button>
            </div>
          </div>
        ) : (
          <div className="flex gap-2">
            <Button 
              onClick={handleRebookNow}
              className="flex-1 bg-[#6b3e4b] hover:bg-[#5a3340] text-white"
            >
              Rebook Now
            </Button>
            <Button 
              onClick={handleCreateReminder}
              variant="outline"
              className="flex-1 border-[#6b3e4b] text-[#6b3e4b] hover:bg-[#6b3e4b] hover:text-white"
              disabled={createPromptMutation.isPending}
            >
              {createPromptMutation.isPending ? "Setting..." : "Remind Me Later"}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}