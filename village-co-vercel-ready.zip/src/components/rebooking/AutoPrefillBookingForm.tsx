import React, { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { format } from 'date-fns';
import { Calendar as CalendarIcon, Clock, MessageCircle, User, Users } from 'lucide-react';

const rebookingFormSchema = z.object({
  startDate: z.date(),
  startTime: z.string().min(1, 'Start time is required'),
  endTime: z.string().min(1, 'End time is required'),
  specialRequests: z.string().optional(),
  sitNotes: z.string().optional(),
});

interface AutoPrefillBookingFormProps {
  originalBooking: {
    id: number;
    sitterId: number;
    sitterName: string;
    sitterPhotoUrl?: string;
    hourlyRate: string;
    startTime: Date;
    endTime: Date;
    specialRequests?: string;
    sitNotes?: string;
    children: Array<{
      id: number;
      firstName: string;
      lastName: string;
      age: number;
      specialNeeds?: string;
    }>;
  };
  onRebookSuccess: (bookingId: number) => void;
  onCancel: () => void;
}

export default function AutoPrefillBookingForm({ 
  originalBooking, 
  onRebookSuccess, 
  onCancel 
}: AutoPrefillBookingFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [sitterAvailable, setSitterAvailable] = useState<boolean | null>(null);
  const [similarSitters, setSimilarSitters] = useState<any[]>([]);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const { toast } = useToast();

  const form = useForm<z.infer<typeof rebookingFormSchema>>({
    resolver: zodResolver(rebookingFormSchema),
    defaultValues: {
      startDate: new Date(),
      startTime: format(originalBooking.startTime, 'HH:mm'),
      endTime: format(originalBooking.endTime, 'HH:mm'),
      specialRequests: originalBooking.specialRequests || '',
      sitNotes: originalBooking.sitNotes || '',
    },
  });

  // Check sitter availability for the selected date/time
  useEffect(() => {
    checkSitterAvailability();
  }, [selectedDate, form.watch('startTime'), form.watch('endTime')]);

  const checkSitterAvailability = async () => {
    try {
      const startTime = form.getValues('startTime');
      const endTime = form.getValues('endTime');
      
      if (!startTime || !endTime) return;

      const startDateTime = new Date(selectedDate);
      const [startHour, startMinute] = startTime.split(':');
      startDateTime.setHours(parseInt(startHour), parseInt(startMinute));

      const endDateTime = new Date(selectedDate);
      const [endHour, endMinute] = endTime.split(':');
      endDateTime.setHours(parseInt(endHour), parseInt(endMinute));

      const response = await apiRequest('POST', '/api/check-sitter-availability', {
        sitterId: originalBooking.sitterId,
        startTime: startDateTime.toISOString(),
        endTime: endDateTime.toISOString(),
      });

      const data = await response.json();
      setSitterAvailable(data.available);

      // If sitter unavailable, fetch similar alternatives
      if (!data.available) {
        fetchSimilarSitters();
      }
    } catch (error) {
      console.error('Error checking availability:', error);
    }
  };

  const fetchSimilarSitters = async () => {
    try {
      const response = await apiRequest('GET', `/api/similar-sitters/${originalBooking.sitterId}`);
      const data = await response.json();
      setSimilarSitters(data.sitters || []);
    } catch (error) {
      console.error('Error fetching similar sitters:', error);
    }
  };

  const onSubmit = async (values: z.infer<typeof rebookingFormSchema>) => {
    setIsSubmitting(true);
    
    try {
      const startDateTime = new Date(selectedDate);
      const [startHour, startMinute] = values.startTime.split(':');
      startDateTime.setHours(parseInt(startHour), parseInt(startMinute));

      const endDateTime = new Date(selectedDate);
      const [endHour, endMinute] = values.endTime.split(':');
      endDateTime.setHours(parseInt(endHour), parseInt(endMinute));

      const bookingData = {
        sitterId: originalBooking.sitterId,
        startTime: startDateTime.toISOString(),
        endTime: endDateTime.toISOString(),
        specialRequests: values.specialRequests,
        sitNotes: values.sitNotes,
        isRebooking: true,
        originalBookingId: originalBooking.id,
      };

      const response = await apiRequest('POST', '/api/bookings', bookingData);
      const result = await response.json();

      if (response.ok) {
        toast({
          title: "Rebooking Successful!",
          description: `Your session with ${originalBooking.sitterName} has been rebooked.`,
        });
        onRebookSuccess(result.booking.id);
      } else {
        throw new Error(result.message || 'Rebooking failed');
      }
    } catch (error: any) {
      toast({
        title: "Rebooking Failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleMessageSitter = () => {
    // Navigate to messaging with the sitter
    window.location.href = `/messages?sitter=${originalBooking.sitterId}`;
  };

  return (
    <div className="space-y-6">
      {/* Sitter Information Card */}
      <Card>
        <CardHeader className="pb-4">
          <div className="flex items-center space-x-4">
            <Avatar className="h-16 w-16">
              <AvatarImage src={originalBooking.sitterPhotoUrl} />
              <AvatarFallback className="bg-village-wine text-white text-lg">
                {originalBooking.sitterName.split(' ').map(n => n[0]).join('')}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <CardTitle className="text-xl text-village-wine">
                Rebook {originalBooking.sitterName}
              </CardTitle>
              <CardDescription className="text-base">
                ${originalBooking.hourlyRate}/hour • Previously sat for your family
              </CardDescription>
              <div className="flex gap-2 mt-2">
                <Badge variant="secondary" className="text-xs">
                  <User className="w-3 h-3 mr-1" />
                  Trusted Sitter
                </Badge>
                <Badge variant="outline" className="text-xs">
                  <Users className="w-3 h-3 mr-1" />
                  Knows Your Routine
                </Badge>
              </div>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Children Information */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Same Family • Same Routine</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {originalBooking.children.map((child) => (
              <div key={child.id} className="flex items-center p-3 bg-muted rounded-lg">
                <div className="w-8 h-8 bg-village-wine rounded-full flex items-center justify-center text-white text-sm font-medium mr-3">
                  {child.firstName[0]}
                </div>
                <div>
                  <p className="font-medium">{child.firstName} {child.lastName}</p>
                  <p className="text-sm text-muted-foreground">Age {child.age}</p>
                  {child.specialNeeds && (
                    <p className="text-xs text-orange-600 mt-1">{child.specialNeeds}</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Booking Form */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Schedule Your Session</CardTitle>
          <CardDescription>
            Form pre-filled with your previous preferences. Adjust as needed.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {/* Date Selection */}
              <FormField
                control={form.control}
                name="startDate"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Select Date</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant="outline"
                            className={`w-full pl-3 text-left font-normal ${
                              !selectedDate && "text-muted-foreground"
                            }`}
                          >
                            {selectedDate ? (
                              format(selectedDate, "PPP")
                            ) : (
                              <span>Pick a date</span>
                            )}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={selectedDate}
                          onSelect={(date) => date && setSelectedDate(date)}
                          disabled={(date) => date < new Date()}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Time Selection */}
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="startTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Start Time</FormLabel>
                      <FormControl>
                        <Input type="time" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="endTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>End Time</FormLabel>
                      <FormControl>
                        <Input type="time" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Availability Status */}
              {sitterAvailable !== null && (
                <div className={`p-4 rounded-lg border ${
                  sitterAvailable 
                    ? 'bg-green-50 border-green-200' 
                    : 'bg-orange-50 border-orange-200'
                }`}>
                  <div className="flex items-center">
                    <Clock className={`w-5 h-5 mr-2 ${
                      sitterAvailable ? 'text-green-600' : 'text-orange-600'
                    }`} />
                    <span className={`font-medium ${
                      sitterAvailable ? 'text-green-800' : 'text-orange-800'
                    }`}>
                      {sitterAvailable 
                        ? `${originalBooking.sitterName} is available!`
                        : `${originalBooking.sitterName} is not available for this time`
                      }
                    </span>
                  </div>
                  
                  {!sitterAvailable && (
                    <div className="mt-3 space-y-2">
                      <p className="text-sm text-orange-700">
                        Try selecting a different time or consider these trusted alternatives:
                      </p>
                      <div className="flex gap-2">
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={handleMessageSitter}
                          className="text-orange-700 border-orange-300"
                        >
                          <MessageCircle className="w-4 h-4 mr-1" />
                          Message {originalBooking.sitterName}
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Similar Sitters (if original unavailable) */}
              {!sitterAvailable && similarSitters.length > 0 && (
                <Card className="border-orange-200">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg text-orange-800">Trusted Alternatives</CardTitle>
                    <CardDescription>
                      Other highly-rated sitters available for your selected time
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {similarSitters.slice(0, 3).map((sitter) => (
                        <div key={sitter.id} className="flex items-center justify-between p-3 bg-white rounded-lg border">
                          <div className="flex items-center space-x-3">
                            <Avatar className="h-10 w-10">
                              <AvatarImage src={sitter.photoUrl} />
                              <AvatarFallback className="bg-village-wine text-white">
                                {sitter.name.split(' ').map((n: string) => n[0]).join('')}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <p className="font-medium">{sitter.name}</p>
                              <p className="text-sm text-muted-foreground">
                                ${sitter.hourlyRate}/hour • ⭐ {sitter.rating}
                              </p>
                              <Badge variant="secondary" className="text-xs mt-1">
                                Trusted by {sitter.familyCount} families
                              </Badge>
                            </div>
                          </div>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => window.location.href = `/sitter/${sitter.id}?rebook=true`}
                          >
                            View Profile
                          </Button>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Pre-filled Notes */}
              <FormField
                control={form.control}
                name="specialRequests"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Special Requests (from last time)</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Any special requests or instructions..."
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="sitNotes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Sit Notes (pre-filled from previous session)</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Bedtime routine, meal preferences, etc..."
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Action Buttons */}
              <div className="flex gap-3 pt-4">
                <Button
                  type="submit"
                  disabled={isSubmitting || sitterAvailable === false}
                  className="flex-1 bg-village-wine hover:bg-village-wine/90"
                >
                  {isSubmitting ? "Booking..." : `Rebook ${originalBooking.sitterName}`}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={onCancel}
                  disabled={isSubmitting}
                >
                  Cancel
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}