import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';

// Form schema with validation
const childInfoSchema = z.object({
  child_name: z.string().min(1, 'Name is required'),
  age: z.coerce
    .number({ invalid_type_error: 'Age must be a number' })
    .int()
    .positive('Age must be positive')
    .min(0, 'Age cannot be negative')
    .max(18, 'For children 18 years or younger'),
  notes: z.string().optional(),
});

export type ChildInfoFormValues = z.infer<typeof childInfoSchema>;

interface ChildInfoFormProps {
  onSave: (data: ChildInfoFormValues) => void;
  defaultValues?: Partial<ChildInfoFormValues>;
}

export function ChildInfoForm({ onSave, defaultValues = {} }: ChildInfoFormProps) {
  const form = useForm<ChildInfoFormValues>({
    resolver: zodResolver(childInfoSchema),
    defaultValues: {
      child_name: '',
      age: undefined,
      notes: '',
      ...defaultValues,
    },
  });

  const handleSubmit = (data: ChildInfoFormValues) => {
    onSave(data);
  };

  return (
    <div className="rounded-lg border border-border bg-card shadow-sm p-6">
      <h2 className="text-xl font-semibold text-wine mb-6">Your Child's Information</h2>
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="child_name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Child's Name</FormLabel>
                <FormControl>
                  <Input placeholder="Enter your child's name" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="age"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Age</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    placeholder="Child's age" 
                    {...field}
                    onChange={(e) => {
                      const value = e.target.value === '' ? undefined : parseInt(e.target.value, 10);
                      field.onChange(value);
                    }}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="notes"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Allergies or Special Notes</FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder="Please share any allergies, preferences, or special instructions" 
                    className="min-h-[100px]"
                    {...field} 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <div className="pt-4">
            <Button 
              type="submit" 
              className="w-full sm:w-auto bg-wine hover:bg-wine/90"
            >
              Save Information
            </Button>
          </div>
        </form>
      </Form>
    </div>
  );
}