import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Crown, Clock, Calendar, Star, Check, Zap } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface VillagePlan {
  id: number;
  name: string;
  price: string;
  monthlyHours: number;
  freeEvents: number;
  features: string[];
  isActive: boolean;
}

interface UserSubscription {
  id: number;
  planId: number;
  status: string;
  hoursUsed: number;
  eventsUsed: number;
  plan: VillagePlan;
}

export default function PlansPerks() {
  const [selectedPlan, setSelectedPlan] = useState<number | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch available plans
  const { data: plans = [], isLoading: plansLoading } = useQuery({
    queryKey: ['/api/village-plans'],
    queryFn: () => apiRequest('GET', '/api/village-plans').then(res => res.json())
  });

  // Fetch user's current subscription
  const { data: subscription, isLoading: subscriptionLoading } = useQuery({
    queryKey: ['/api/user/subscription'],
    queryFn: () => apiRequest('GET', '/api/user/subscription').then(res => res.json()),
    retry: false
  });

  // Subscribe to plan mutation - now redirects to Stripe checkout
  const subscribeMutation = useMutation({
    mutationFn: async (planId: number) => {
      const response = await apiRequest('POST', '/api/stripe/create-subscription-checkout', { planId });
      const data = await response.json();
      if (data.checkoutUrl) {
        window.location.href = data.checkoutUrl;
      }
      return data;
    },
    onError: () => {
      toast({
        title: "Checkout Failed",
        description: "Unable to start checkout process. Please try again.",
        variant: "destructive"
      });
    }
  });

  // Cancel subscription mutation
  const cancelMutation = useMutation({
    mutationFn: () => {
      return apiRequest('POST', '/api/village-plans/cancel')
        .then(res => res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/user/subscription'] });
      toast({
        title: "Subscription Cancelled",
        description: "Your subscription will remain active until the end of your billing period."
      });
    }
  });

  const getPlanIcon = (planName: string) => {
    if (planName.includes('Lite')) return <Zap className="w-6 h-6" />;
    if (planName.includes('Core')) return <Star className="w-6 h-6" />;
    if (planName.includes('Luxe')) return <Crown className="w-6 h-6" />;
    return <Clock className="w-6 h-6" />;
  };

  const getPlanColor = (planName: string) => {
    if (planName.includes('Lite')) return 'border-blue-200 bg-blue-50';
    if (planName.includes('Core')) return 'border-purple-200 bg-purple-50';
    if (planName.includes('Luxe')) return 'border-yellow-200 bg-yellow-50';
    return 'border-gray-200 bg-gray-50';
  };

  const getUsageProgress = (used: number, total: number) => {
    return Math.min((used / total) * 100, 100);
  };

  if (plansLoading || subscriptionLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-64" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-96 bg-gray-200 rounded-lg" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold text-village-wine mb-4">
          Plans & Perks
        </h1>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Choose the perfect Village plan for your family. More than childcare - 
          it's a community of support designed around your life.
        </p>
      </div>

      {/* Current Subscription Status */}
      {subscription && (
        <Card className="mb-8 border-green-200 bg-green-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-800">
              <Check className="w-5 h-5" />
              Your Current Plan: {subscription.plan.name}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-green-800 mb-2">Hours This Month</h4>
                <Progress 
                  value={getUsageProgress(subscription.hoursUsed, subscription.plan.monthlyHours)} 
                  className="mb-2"
                />
                <p className="text-sm text-green-700">
                  {subscription.hoursUsed} / {subscription.plan.monthlyHours} hours used
                </p>
              </div>
              <div>
                <h4 className="font-semibold text-green-800 mb-2">Events This Month</h4>
                <Progress 
                  value={getUsageProgress(subscription.eventsUsed, subscription.plan.freeEvents)} 
                  className="mb-2"
                />
                <p className="text-sm text-green-700">
                  {subscription.eventsUsed} / {subscription.plan.freeEvents} events used
                </p>
              </div>
            </div>
            <div className="mt-4 flex gap-2">
              <Button variant="outline" size="sm">
                View Usage Details
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => cancelMutation.mutate()}
                disabled={cancelMutation.isPending}
              >
                Cancel Plan
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Available Plans */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {plans.map((plan: VillagePlan) => (
          <Card 
            key={plan.id} 
            className={`relative ${getPlanColor(plan.name)} ${
              subscription?.planId === plan.id ? 'ring-2 ring-green-500' : ''
            } ${selectedPlan === plan.id ? 'ring-2 ring-village-wine' : ''}`}
          >
            <CardHeader className="text-center">
              <div className="flex items-center justify-center mb-2 text-village-wine">
                {getPlanIcon(plan.name)}
              </div>
              <CardTitle className="text-xl text-village-wine">
                {plan.name}
              </CardTitle>
              <CardDescription className="text-2xl font-bold text-village-wine">
                ${plan.price}/month
              </CardDescription>
            </CardHeader>
            
            <CardContent>
              <div className="space-y-4">
                <div className="text-center">
                  <div className="text-3xl font-bold text-village-wine">
                    {plan.monthlyHours}
                  </div>
                  <div className="text-sm text-gray-600">hours included</div>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-village-wine" />
                    <span className="text-sm">{plan.freeEvents} free events monthly</span>
                  </div>
                  
                  {plan.features.map((feature, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <Check className="w-4 h-4 text-green-600" />
                      <span className="text-sm">{feature}</span>
                    </div>
                  ))}
                </div>

                {subscription?.planId === plan.id ? (
                  <Badge className="w-full justify-center bg-green-100 text-green-800">
                    Current Plan
                  </Badge>
                ) : (
                  <Button
                    className="w-full bg-village-wine hover:bg-village-wine/90"
                    onClick={() => subscribeMutation.mutate(plan.id)}
                    disabled={subscribeMutation.isPending}
                  >
                    {subscription ? 'Switch Plan' : 'Subscribe Now'}
                  </Button>
                )}
              </div>
            </CardContent>

            {plan.name.includes('Core') && (
              <Badge className="absolute -top-2 left-1/2 transform -translate-x-1/2 bg-purple-600 text-white">
                Most Popular
              </Badge>
            )}
          </Card>
        ))}
      </div>

      {/* Plan Benefits Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="text-village-wine">Why Choose Village Plans?</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center">
              <Clock className="w-8 h-8 text-village-wine mx-auto mb-2" />
              <h3 className="font-semibold mb-1">Predictable Childcare</h3>
              <p className="text-sm text-gray-600">Know your childcare is sorted with included hours</p>
            </div>
            
            <div className="text-center">
              <Calendar className="w-8 h-8 text-village-wine mx-auto mb-2" />
              <h3 className="font-semibold mb-1">Community Events</h3>
              <p className="text-sm text-gray-600">Connect with other parents at exclusive events</p>
            </div>
            
            <div className="text-center">
              <Star className="w-8 h-8 text-village-wine mx-auto mb-2" />
              <h3 className="font-semibold mb-1">Priority Booking</h3>
              <p className="text-sm text-gray-600">Get first access to your favourite sitters</p>
            </div>
            
            <div className="text-center">
              <Crown className="w-8 h-8 text-village-wine mx-auto mb-2" />
              <h3 className="font-semibold mb-1">Concierge Support</h3>
              <p className="text-sm text-gray-600">Personal assistance with all your childcare needs</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}