import { Card, CardContent } from "@/components/ui/card";
import { Heart, Home, Search, ArrowLeft } from "lucide-react";
import { Link } from "wouter";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-bone">
      <div className="max-w-md mx-4 text-center">
        {/* Village Co brand touch */}
        <div className="mb-8">
          <div className="w-16 h-16 bg-village-wine rounded-full flex items-center justify-center mx-auto mb-4">
            <Heart className="h-8 w-8 text-linen" />
          </div>
          <h1 className="text-3xl font-bold text-village-wine mb-2">Oops! Wrong turn</h1>
          <p className="text-gray-600 text-lg">
            This page doesn't exist, but great sitters do!
          </p>
        </div>

        <Card className="border-almond-frost/20 shadow-sm">
          <CardContent className="p-6">
            <p className="text-gray-700 mb-6">
              Don't worry—it happens to the best of us. Let's get you back to finding 
              trusted childcare or managing your bookings.
            </p>
            
            <div className="space-y-3">
              <Link href="/">
                <button className="w-full inline-flex items-center justify-center px-4 py-3 text-sm font-medium text-white bg-village-wine rounded-lg hover:bg-village-wine/90 transition-colors">
                  <Home className="h-4 w-4 mr-2" />
                  Back to Home
                </button>
              </Link>
              
              <Link href="/find-sitter">
                <button className="w-full inline-flex items-center justify-center px-4 py-3 text-sm font-medium text-village-wine bg-linen rounded-lg hover:bg-almond-frost transition-colors">
                  <Search className="h-4 w-4 mr-2" />
                  Find Sitters
                </button>
              </Link>
              
              <button 
                onClick={() => window.history.back()}
                className="w-full inline-flex items-center justify-center px-4 py-2 text-sm font-medium text-gray-600 hover:text-village-wine transition-colors"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Go Back
              </button>
            </div>
          </CardContent>
        </Card>

        <p className="text-sm text-gray-500 mt-6">
          Still need help? <a href="mailto:info@thevillageco.nz" className="text-village-wine hover:underline">Contact support</a>
        </p>
      </div>
    </div>
  );
}
