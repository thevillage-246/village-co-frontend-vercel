import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Calendar, Clock, MapPin, Users, Coffee, Baby, Star, Check } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Add Lu.ma types
declare global {
  interface Window {
    luma?: any;
  }
}

interface VillageEvent {
  id: number;
  title: string;
  description: string;
  eventDate: string;
  location: string;
  maxAttendees: number;
  currentAttendees: number;
  requiresSubscription: boolean;
  eventType: string;
  imageUrl?: string;
  lumaEventId?: string;
  lumaUrl?: string;
}

interface EventBooking {
  id: number;
  eventId: number;
  attendees: number;
  usedFreeEvent: boolean;
  bookingStatus: string;
}

export default function Events() {
  const [selectedEvent, setSelectedEvent] = useState<number | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Removed Lu.ma script loading to prevent conflicts with custom click handlers

  // Fetch upcoming events
  const { data: events = [], isLoading: eventsLoading } = useQuery({
    queryKey: ['/api/village-events'],
    queryFn: () => apiRequest('GET', '/api/village-events').then(res => res.json())
  });



  // Fetch user's event bookings
  const { data: userBookings = [], isLoading: bookingsLoading } = useQuery({
    queryKey: ['/api/user/event-bookings'],
    queryFn: () => apiRequest('GET', '/api/user/event-bookings').then(res => res.json()),
    retry: false
  });

  // Book event mutation
  const bookEventMutation = useMutation({
    mutationFn: ({ eventId, attendees }: { eventId: number; attendees: number }) => {
      return apiRequest('POST', '/api/village-events/book', { eventId, attendees })
        .then(res => res.json());
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/village-events'] });
      queryClient.invalidateQueries({ queryKey: ['/api/user/event-bookings'] });
      toast({
        title: "You're all booked!",
        description: "Sitters will be on-site — just bring yourself."
      });
    },
    onError: () => {
      toast({
        title: "Booking Failed",
        description: "Unable to book event. Please try again.",
        variant: "destructive"
      });
    }
  });

  const getEventIcon = (eventType: string) => {
    switch (eventType) {
      case 'coffee-connect': return <Coffee className="w-5 h-5" />;
      case 'playdates': return <Baby className="w-5 h-5" />;
      case 'workshops': return <Star className="w-5 h-5" />;
      default: return <Calendar className="w-5 h-5" />;
    }
  };

  const isEventBooked = (eventId: number) => {
    return userBookings.some((booking: EventBooking) => 
      booking.eventId === eventId && booking.bookingStatus === 'confirmed'
    );
  };

  const isEventFull = (event: VillageEvent) => {
    return event.currentAttendees >= event.maxAttendees;
  };

  const formatEventDate = (dateString: string) => {
    const date = new Date(dateString);
    return {
      day: date.toLocaleDateString('en-NZ', { weekday: 'short' }),
      date: date.getDate(),
      month: date.toLocaleDateString('en-NZ', { month: 'short' }),
      time: date.toLocaleTimeString('en-NZ', { 
        hour: 'numeric', 
        minute: '2-digit',
        hour12: true 
      })
    };
  };

  if (eventsLoading || bookingsLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-64" />
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="h-64 bg-gray-200 rounded-lg" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold text-village-wine mb-4">
          Village Events
        </h1>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Connect with fellow parents in our community. Bring yourself — 
          we'll handle the childcare with on-site sitters.
        </p>
      </div>

      {/* Upcoming Events */}
      <div className="space-y-6">
        <h2 className="text-2xl font-bold text-village-wine mb-4">Upcoming Events</h2>
        
        {events.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-600 mb-2">
                No upcoming events
              </h3>
              <p className="text-gray-500">
                Check back soon for new community events and workshops.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {events.map((event: VillageEvent) => {
              const eventDate = formatEventDate(event.eventDate);
              const isBooked = isEventBooked(event.id);
              const isFull = isEventFull(event);
              
              return (
                <Card key={event.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                  {event.imageUrl && (
                    <div className="h-48 bg-gray-200 relative">
                      <img 
                        src={event.imageUrl} 
                        alt={event.title}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute top-4 left-4">
                        <Badge className="bg-white text-village-wine">
                          {getEventIcon(event.eventType)}
                          <span className="ml-1 capitalize">
                            {event.eventType.replace('-', ' ')}
                          </span>
                        </Badge>
                      </div>
                    </div>
                  )}
                  
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-xl text-village-wine mb-2">
                          {event.title}
                        </CardTitle>
                        <CardDescription className="text-sm">
                          {event.description}
                        </CardDescription>
                      </div>
                      
                      <div className="text-center min-w-[60px]">
                        <div className="text-xs text-gray-500 uppercase">
                          {eventDate.day}
                        </div>
                        <div className="text-2xl font-bold text-village-wine">
                          {eventDate.date}
                        </div>
                        <div className="text-xs text-gray-500 uppercase">
                          {eventDate.month}
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center gap-4 text-sm text-gray-600">
                        <div className="flex items-center gap-1">
                          <Clock className="w-4 h-4" />
                          <span>{eventDate.time}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <MapPin className="w-4 h-4" />
                          <span>{event.location}</span>
                        </div>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-1 text-sm text-gray-600">
                          <Users className="w-4 h-4" />
                          <span>{event.currentAttendees}/{event.maxAttendees} attending</span>
                        </div>
                        
                        {event.requiresSubscription && (
                          <Badge variant="outline" className="text-purple-700 border-purple-200">
                            Members Only
                          </Badge>
                        )}
                      </div>
                      
                      {(() => {
                        console.log('Event debug:', { 
                          id: event.id, 
                          title: event.title,
                          lumaEventId: event.lumaEventId, 
                          lumaUrl: event.lumaUrl,
                          isBooked, 
                          isFull,
                          hasLuma: !!(event.lumaEventId && event.lumaUrl)
                        });
                        return null;
                      })()}
                      {isBooked ? (
                        <Badge className="w-full justify-center bg-green-100 text-green-800">
                          <Check className="w-4 h-4 mr-1" />
                          You're attending!
                        </Badge>
                      ) : isFull ? (
                        <Button disabled className="w-full">
                          Event Full
                        </Button>
                      ) : event.title === "Coffee & Connect" ? (
                        <a
                          href="https://lu.ma/7uwn20vy"
                          target="_blank"
                          rel="noopener noreferrer"
                          className="w-full inline-flex items-center justify-center px-4 py-2 bg-village-wine hover:bg-village-wine/90 text-white font-medium rounded-md transition-colors focus:outline-none focus:ring-2 focus:ring-village-wine focus:ring-offset-2"
                          onClick={(e) => {
                            console.log('Lu.ma link clicked directly');
                          }}
                        >
                          Register for Event
                        </a>
                      ) : (
                        <Button
                          className="w-full bg-village-wine hover:bg-village-wine/90"
                          onClick={() => bookEventMutation.mutate({ eventId: event.id, attendees: 1 })}
                          disabled={bookEventMutation.isPending}
                        >
                          Save My Spot
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* Event Types Info */}
      <div className="mt-12">
        <h2 className="text-2xl font-bold text-village-wine mb-6">Event Types</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-village-wine">
                <Coffee className="w-5 h-5" />
                Coffee & Connect
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Casual morning meetups for parents to connect over coffee while 
                children play in a safe, supervised environment.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-village-wine">
                <Baby className="w-5 h-5" />
                Family Playdates
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Structured playdate sessions with age-appropriate activities 
                and professional childcare support for all families.
              </p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-village-wine">
                <Star className="w-5 h-5" />
                Parent Workshops
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600">
                Educational workshops on parenting topics, child development, 
                and family wellness — with childcare included.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}