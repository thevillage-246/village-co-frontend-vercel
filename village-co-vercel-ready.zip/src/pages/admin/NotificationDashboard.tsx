import { Link } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Bell, UserX, UserMinus, AlertCircle } from 'lucide-react';
import AdminSidebar from '@/components/AdminSidebar';

export default function NotificationDashboard() {
  return (
    <div className="flex min-h-screen">
      <AdminSidebar />
      <main className="flex-1 p-4 md:p-6">
        <Card className="mb-6 md:mb-8">
          <CardHeader className="pb-4">
            <CardTitle className="text-2xl md:text-3xl">Notification Dashboard</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm md:text-base text-muted-foreground mb-6">
              Manage user engagement and send targeted notifications to different user segments
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
              <Link href="/admin-notify">
                <a className="flex flex-col h-32 md:h-40 p-4 md:p-6 bg-eucalyptus text-white rounded-lg shadow hover:bg-eucalyptus/90 transition-colors">
                  <div className="flex items-center mb-3 md:mb-4">
                    <Bell className="h-5 w-5 md:h-6 md:w-6 mr-2" />
                    <h3 className="text-lg md:text-xl font-semibold">Notify All Sitters</h3>
                  </div>
                  <p className="text-white/90 flex-grow text-sm md:text-base">
                    Send notifications to all active sitters about new bookings and opportunities
                  </p>
                </a>
              </Link>
              
              <Link href="/admin-inactive">
                <a className="flex flex-col h-32 md:h-40 p-4 md:p-6 bg-wine text-white rounded-lg shadow hover:bg-wine/90 transition-colors">
                  <div className="flex items-center mb-3 md:mb-4">
                    <UserX className="h-5 w-5 md:h-6 md:w-6 mr-2" />
                    <h3 className="text-lg md:text-xl font-semibold">Inactive Sitters</h3>
                  </div>
                  <p className="text-white/90 flex-grow text-sm md:text-base">
                    Re-engage sitters who haven't been active in the last 30 days
                  </p>
                </a>
              </Link>
              
              <Link href="/admin-inactive-parents">
                <a className="flex flex-col h-32 md:h-40 p-4 md:p-6 bg-rose text-white rounded-lg shadow hover:bg-rose/90 transition-colors">
                  <div className="flex items-center mb-3 md:mb-4">
                    <UserMinus className="h-5 w-5 md:h-6 md:w-6 mr-2" />
                    <h3 className="text-lg md:text-xl font-semibold">Inactive Parents</h3>
                  </div>
                  <p className="text-white/90 flex-grow text-sm md:text-base">
                    Reconnect with parents who haven't booked a sitter in the last 30 days
                  </p>
                </a>
              </Link>
              
              <Link href="/admin-at-risk">
                <a className="flex flex-col h-32 md:h-40 p-4 md:p-6 bg-gray-700 text-white rounded-lg shadow hover:bg-gray-800 transition-colors">
                  <div className="flex items-center mb-3 md:mb-4">
                    <AlertCircle className="h-5 w-5 md:h-6 md:w-6 mr-2" />
                    <h3 className="text-lg md:text-xl font-semibold">At-Risk Users</h3>
                  </div>
                  <p className="text-white/90 flex-grow text-sm md:text-base">
                    Reach out to users with no bookings and no reviews who might be at risk of churning
                  </p>
                </a>
              </Link>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}