import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { 
  Loader2, 
  Database, 
  Download, 
  Upload, 
  CheckCircle, 
  AlertCircle, 
  PlayCircle,
  MapPin,
  TrendingUp,
  Target,
  Mail,
  BarChart3,
  Users,
  Link,
  User,
  Search,
  FileUp
} from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { useQuery, useMutation } from '@tanstack/react-query';

interface SyncStatus {
  success: boolean;
  totalUsers: number;
  totalSitters: number;
  totalParents: number;
  lastSync: string;
}

interface SyncResult {
  success: boolean;
  message: string;
  output?: string;
}

interface WorkflowStatus {
  step: number;
  description: string;
  completed: boolean;
  inProgress: boolean;
}

interface AnalyticsData {
  lifecycleDistribution: { [key: string]: number };
  monthlyVolume: { [key: string]: { total_bookings: number; total_revenue: number; completed_bookings: number } };
  topPerformers: Array<{ user_id: string; average_rating: number; review_count: number }>;
  mappingStats: { totalMappings: number; linkedMappings: number; unmappedUsers: number };
}

interface UUIDMapping {
  id: number;
  platform_uuid: string;
  village_user_id: number | null;
  email: string | null;
  first_name: string | null;
  last_name: string | null;
  user_type: string | null;
  created_at: string;
  updated_at: string;
  user_display_name: string;
  user_email: string | null;
  user_role: string | null;
}

interface MappingStats {
  totalMappings: number;
  linkedMappings: number;
  unmappedUsers: number;
  linkageRate: number;
}

export default function HubSpotDataManager() {
  const [syncOutput, setSyncOutput] = useState<string>('');
  const [csvOutput, setCsvOutput] = useState<string>('');
  const [workflowOutput, setWorkflowOutput] = useState<string>('');
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData | null>(null);
  const [isImporting, setIsImporting] = useState(false);
  const [importOutput, setImportOutput] = useState('');
  const [workflowProgress, setWorkflowProgress] = useState<WorkflowStatus[]>([
    { step: 1, description: 'Import CSV data and create UUID mappings', completed: false, inProgress: false },
    { step: 2, description: 'Analyze user patterns and assign lifecycle stages', completed: false, inProgress: false },
    { step: 3, description: 'Generate user journey analytics dashboard', completed: false, inProgress: false },
    { step: 4, description: 'Sync with HubSpot and update lifecycle stages', completed: false, inProgress: false },
    { step: 5, description: 'Set up automated email campaigns', completed: false, inProgress: false }
  ]);

  // Get current sync status
  const { data: syncStatus, isLoading: statusLoading, refetch: refetchStatus } = useQuery<SyncStatus>({
    queryKey: ['/api/admin/data-sync/status'],
    refetchInterval: 30000 // Refresh every 30 seconds
  });

  // Get UUID mappings with user names
  const { data: mappingsData, isLoading: mappingsLoading, refetch: refetchMappings } = useQuery<{
    success: boolean;
    mappings: UUIDMapping[];
    stats: MappingStats;
  }>({
    queryKey: ['/api/admin/uuid-mappings'],
    refetchInterval: 60000 // Refresh every minute
  });

  // Auto-link UUID mappings mutation
  const autoLinkMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/admin/uuid-mappings/auto-link');
      return response.json();
    },
    onSuccess: (data) => {
      setOutput(prev => prev + `\n✅ Auto-linking complete: ${data.linkedCount}/${data.totalProcessed} mappings linked`);
      if (data.debugInfo && data.debugInfo.length > 0) {
        setOutput(prev => prev + `\n🔍 Debug info:\n${data.debugInfo.join('\n')}`);
      }
      refetchMappings();
    },
    onError: (error: any) => {
      setOutput(prev => prev + `\n❌ Auto-linking failed: ${error.message}`);
    }
  });

  // Debug mapping data mutation
  const debugMappingsMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('GET', '/api/admin/uuid-mappings/debug');
      return response.json();
    },
    onSuccess: (data) => {
      setOutput(prev => prev + 
        `\n🔍 Debug Information:` +
        `\n📊 Stats: ${data.stats.mappedCount}/${data.stats.totalMappings} mapped (${data.stats.unmappedCount} unmapped)` +
        `\n📧 Sample UUID emails: ${data.sampleUnmappedEmails.slice(0, 5).join(', ')}` +
        `\n👥 Sample user emails: ${data.sampleUserEmails.slice(0, 5).join(', ')}` +
        `\n\n💡 If emails don't match, UUIDs may be from different data source than current users.`
      );
    },
    onError: (error: any) => {
      setOutput(prev => prev + `\n❌ Debug failed: ${error.message}`);
    }
  });

  // CSV import for UUID mappings mutation
  const csvImportUuidMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/admin/uuid-mappings/import-csv');
      return response.json();
    },
    onSuccess: (data) => {
      setOutput(prev => prev + `\n✅ CSV import complete: ${data.importedCount} email-UUID mappings imported`);
      if (data.sampleData && data.sampleData.length > 0) {
        setOutput(prev => prev + `\n📧 Sample imported data: ${data.sampleData.map((d: any) => `${d.email}→${d.uuid.substring(0, 8)}...`).join(', ')}`);
      }
      refetchMappings();
    },
    onError: (error: any) => {
      setOutput(prev => prev + `\n❌ CSV import failed: ${error.message}`);
    }
  });

  // HubSpot sync mutation
  const hubspotSyncMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/admin/hubspot/sync');
      return response.json();
    },
    onSuccess: (data: SyncResult) => {
      setSyncOutput(data.output || data.message);
      refetchStatus();
    },
    onError: (error: any) => {
      setSyncOutput(`Error: ${error.message}`);
    }
  });

  // CSV import mutation
  const csvImportMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/admin/import/csv-data');
      return response.json();
    },
    onSuccess: (data: SyncResult) => {
      setCsvOutput(data.output || data.message);
      updateWorkflowStep(1, true);
      refetchStatus();
    },
    onError: (error: any) => {
      setCsvOutput(`Error: ${error.message}`);
      updateWorkflowStep(1, false);
    }
  });

  // UUID mapping workflow mutation
  const uuidMappingMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/admin/workflow/uuid-mapping');
      return response.json();
    },
    onSuccess: (data: SyncResult) => {
      setWorkflowOutput(data.output || data.message);
      updateWorkflowStep(1, true);
    },
    onError: (error: any) => {
      setWorkflowOutput(`Error: ${error.message}`);
      updateWorkflowStep(1, false);
    }
  });

  // Lifecycle analysis mutation
  const lifecycleAnalysisMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/admin/workflow/lifecycle-analysis');
      return response.json();
    },
    onSuccess: (data: SyncResult) => {
      setWorkflowOutput(data.output || data.message);
      updateWorkflowStep(2, true);
    },
    onError: (error: any) => {
      setWorkflowOutput(`Error: ${error.message}`);
      updateWorkflowStep(2, false);
    }
  });

  // Analytics generation mutation
  const analyticsGenerationMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/admin/workflow/generate-analytics');
      return response.json();
    },
    onSuccess: (data: any) => {
      setAnalyticsData(data.analytics);
      setWorkflowOutput(data.output || 'Analytics generated successfully');
      updateWorkflowStep(3, true);
    },
    onError: (error: any) => {
      setWorkflowOutput(`Error: ${error.message}`);
      updateWorkflowStep(3, false);
    }
  });

  // Full workflow automation mutation
  const fullWorkflowMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/admin/workflow/run-full-integration');
      return response.json();
    },
    onSuccess: (data: any) => {
      setWorkflowOutput(data.output || 'Full workflow completed successfully');
      if (data.analytics) setAnalyticsData(data.analytics);
      // Mark all steps as completed
      setWorkflowProgress(prev => prev.map(step => ({ ...step, completed: true, inProgress: false })));
    },
    onError: (error: any) => {
      setWorkflowOutput(`Error: ${error.message}`);
    }
  });

  const handleHubSpotSync = () => {
    setSyncOutput('Starting HubSpot data sync...');
    hubspotSyncMutation.mutate();
  };

  const handleCsvImport = () => {
    setCsvOutput('Starting CSV data import...');
    csvImportMutation.mutate();
  };

  // Helper function to update workflow progress
  const updateWorkflowStep = (stepNumber: number, completed: boolean) => {
    setWorkflowProgress(prev => prev.map(step => 
      step.step === stepNumber 
        ? { ...step, completed, inProgress: false }
        : step
    ));
  };

  // Individual workflow step handlers
  const handleUuidMapping = () => {
    setWorkflowOutput('Starting UUID mapping and CSV import...');
    updateWorkflowStep(1, false);
    setWorkflowProgress(prev => prev.map(step => 
      step.step === 1 ? { ...step, inProgress: true } : step
    ));
    uuidMappingMutation.mutate();
  };

  const handleLifecycleAnalysis = () => {
    setWorkflowOutput('Starting lifecycle analysis...');
    updateWorkflowStep(2, false);
    setWorkflowProgress(prev => prev.map(step => 
      step.step === 2 ? { ...step, inProgress: true } : step
    ));
    lifecycleAnalysisMutation.mutate();
  };

  const handleAnalyticsGeneration = () => {
    setWorkflowOutput('Generating analytics dashboard...');
    updateWorkflowStep(3, false);
    setWorkflowProgress(prev => prev.map(step => 
      step.step === 3 ? { ...step, inProgress: true } : step
    ));
    analyticsGenerationMutation.mutate();
  };

  const handleFullWorkflow = () => {
    setWorkflowOutput('Starting complete HubSpot integration workflow...');
    setWorkflowProgress(prev => prev.map(step => ({ ...step, inProgress: true })));
    fullWorkflowMutation.mutate();
  };

  // HubSpot user import mutation
  const hubspotUserImportMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/admin/import/hubspot-platform-users');
      return response.json();
    },
    onSuccess: (data: any) => {
      setImportOutput(`✅ Import Complete!\n${data.message}\n\nCreated:\n• ${data.createdParents} parents\n• ${data.createdSitters} sitters\n\nSkipped: ${data.skippedUsers} existing users`);
      refetchStatus();
    },
    onError: (error: any) => {
      setImportOutput(`❌ Import failed: ${error.message}`);
    }
  });

  const handleImportHubSpotUsers = () => {
    setImportOutput('Starting HubSpot user import...');
    setIsImporting(true);
    hubspotUserImportMutation.mutate();
  };



  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      <div className="flex items-center gap-3 mb-8">
        <Database className="h-8 w-8 text-wine" />
        <div>
          <h1 className="text-3xl font-bold text-wine">HubSpot Data Manager</h1>
          <p className="text-gray-600 mt-1">
            Sync HubSpot contacts and import CSV transaction data for complete user journey tracking
          </p>
        </div>
      </div>

      {/* Current Status Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="h-5 w-5 text-eucalyptus" />
            Current Platform Status
          </CardTitle>
          <CardDescription>
            Real-time overview of all data in the Village Co platform
          </CardDescription>
        </CardHeader>
        <CardContent>
          {statusLoading ? (
            <div className="flex items-center gap-2">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>Loading status...</span>
            </div>
          ) : syncStatus ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <div className="text-2xl font-bold text-wine">{syncStatus.totalUsers}</div>
                <div className="text-sm text-gray-600">Total Users</div>
              </div>
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <div className="text-2xl font-bold text-rose">{syncStatus.totalSitters}</div>
                <div className="text-sm text-gray-600">Active Sitters</div>
              </div>
              <div className="text-center p-4 bg-gray-50 rounded-lg">
                <div className="text-2xl font-bold text-eucalyptus">{syncStatus.totalParents}</div>
                <div className="text-sm text-gray-600">Parent Profiles</div>
              </div>
            </div>
          ) : (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Unable to load platform status. Please check your connection.
              </AlertDescription>
            </Alert>
          )}
          
          {syncStatus && (
            <div className="mt-4 text-sm text-gray-500">
              Last updated: {new Date(syncStatus.lastSync).toLocaleString()}
            </div>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* HubSpot Sync Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Download className="h-5 w-5 text-rose" />
              HubSpot Contact Sync
            </CardTitle>
            <CardDescription>
              Import and migrate HubSpot contacts to Village Co user accounts with lifecycle stage mapping
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 bg-blue-50 rounded-lg">
              <h4 className="font-semibold text-blue-900 mb-2">What this does:</h4>
              <ul className="text-sm text-blue-800 space-y-1">
                <li>• Fetches all contacts from HubSpot</li>
                <li>• Identifies sitters and parents</li>
                <li>• Creates Village Co user accounts</li>
                <li>• Maps lifecycle stages and contact properties</li>
                <li>• Links HubSpot data to Village Co profiles</li>
              </ul>
            </div>

            <Button 
              onClick={handleHubSpotSync}
              disabled={hubspotSyncMutation.isPending}
              className="w-full"
            >
              {hubspotSyncMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Syncing HubSpot Data...
                </>
              ) : (
                <>
                  <Download className="mr-2 h-4 w-4" />
                  Start HubSpot Sync
                </>
              )}
            </Button>

            {syncOutput && (
              <div className="mt-4">
                <h4 className="font-semibold mb-2">Sync Output:</h4>
                <pre className="bg-gray-100 p-3 rounded text-xs overflow-auto max-h-40 whitespace-pre-wrap">
                  {syncOutput}
                </pre>
              </div>
            )}
          </CardContent>
        </Card>

        {/* CSV Import Section */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="h-5 w-5 text-eucalyptus" />
              CSV Data Import
            </CardTitle>
            <CardDescription>
              Import reviews and transaction data from CSV files for complete user journey tracking
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 bg-green-50 rounded-lg">
              <h4 className="font-semibold text-green-900 mb-2">What this does:</h4>
              <ul className="text-sm text-green-800 space-y-1">
                <li>• Creates platform_reviews table</li>
                <li>• Creates platform_transactions table</li>
                <li>• Imports 31 review records</li>
                <li>• Imports 70 transaction records</li>
                <li>• Creates UUID mapping for user linking</li>
              </ul>
            </div>

            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                <strong>Files being imported:</strong><br />
                • ittakesavillage-reviews (31 rows)<br />
                • ittakesavillage-transactions (70 rows)
              </AlertDescription>
            </Alert>

            <Button 
              onClick={handleCsvImport}
              disabled={csvImportMutation.isPending}
              className="w-full"
            >
              {csvImportMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Importing CSV Data...
                </>
              ) : (
                <>
                  <Upload className="mr-2 h-4 w-4" />
                  Start CSV Import
                </>
              )}
            </Button>

            {csvOutput && (
              <div className="mt-4">
                <h4 className="font-semibold mb-2">Import Output:</h4>
                <pre className="bg-gray-100 p-3 rounded text-xs overflow-auto max-h-40 whitespace-pre-wrap">
                  {csvOutput}
                </pre>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* UUID Mappings Management */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5 text-eucalyptus" />
            User ID Mappings
          </CardTitle>
          <CardDescription>
            View and manage UUID mappings between platform UUIDs and actual user names
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Mapping Statistics */}
          {mappingsData?.stats && (
            <div className="grid grid-cols-4 gap-4 mb-6">
              <div className="bg-blue-50 p-4 rounded-lg text-center">
                <div className="text-2xl font-bold text-blue-700">{mappingsData.stats.totalMappings}</div>
                <div className="text-sm text-blue-600">Total Mappings</div>
              </div>
              <div className="bg-green-50 p-4 rounded-lg text-center">
                <div className="text-2xl font-bold text-green-700">{mappingsData.stats.linkedMappings}</div>
                <div className="text-sm text-green-600">Linked Users</div>
              </div>
              <div className="bg-orange-50 p-4 rounded-lg text-center">
                <div className="text-2xl font-bold text-orange-700">{mappingsData.stats.unmappedUsers}</div>
                <div className="text-sm text-orange-600">Unmapped</div>
              </div>
              <div className="bg-purple-50 p-4 rounded-lg text-center">
                <div className="text-2xl font-bold text-purple-700">{mappingsData.stats.linkageRate}%</div>
                <div className="text-sm text-purple-600">Linkage Rate</div>
              </div>
            </div>
          )}

          {/* Mappings Table */}
          {mappingsLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin mr-2" />
              Loading UUID mappings...
            </div>
          ) : mappingsData?.mappings ? (
            <div className="border rounded-lg overflow-hidden">
              <div className="bg-gray-50 px-4 py-3 border-b">
                <h4 className="font-semibold text-gray-900">UUID to User Name Mapping Table</h4>
                <p className="text-sm text-gray-600">Showing {mappingsData.mappings.length} mappings</p>
              </div>
              
              <div className="max-h-96 overflow-y-auto">
                <table className="w-full text-sm">
                  <thead className="bg-gray-50 sticky top-0">
                    <tr>
                      <th className="text-left p-3 font-medium text-gray-900">Platform UUID</th>
                      <th className="text-left p-3 font-medium text-gray-900">User Name</th>
                      <th className="text-left p-3 font-medium text-gray-900">Email</th>
                      <th className="text-left p-3 font-medium text-gray-900">Role</th>
                      <th className="text-left p-3 font-medium text-gray-900">Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {mappingsData.mappings.map((mapping, index) => (
                      <tr key={mapping.id} className={index % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                        <td className="p-3 font-mono text-xs">
                          <span className="bg-gray-100 px-2 py-1 rounded">
                            {mapping.platform_uuid.substring(0, 8)}...
                          </span>
                        </td>
                        <td className="p-3">
                          <div className="flex items-center gap-2">
                            <User className="h-4 w-4 text-gray-400" />
                            <span className="font-medium">
                              {mapping.user_display_name}
                            </span>
                          </div>
                        </td>
                        <td className="p-3 text-gray-600">
                          {mapping.user_email || '-'}
                        </td>
                        <td className="p-3">
                          {mapping.user_role && (
                            <Badge variant="outline" className="text-xs">
                              {mapping.user_role}
                            </Badge>
                          )}
                        </td>
                        <td className="p-3">
                          {mapping.village_user_id || (mapping.user_display_name && mapping.user_display_name !== 'Unmapped') ? (
                            <Badge className="bg-green-100 text-green-800 border-green-200">
                              <Link className="h-3 w-3 mr-1" />
                              Linked
                            </Badge>
                          ) : (
                            <Badge variant="secondary" className="bg-orange-100 text-orange-800 border-orange-200">
                              Unmapped
                            </Badge>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                No UUID mappings found. Run Step 1 (CSV Import) to create mappings.
              </AlertDescription>
            </Alert>
          )}

          {/* Action Buttons */}
          <div className="flex gap-2 justify-end flex-wrap">
            <Button 
              onClick={() => csvImportUuidMutation.mutate()}
              disabled={csvImportUuidMutation.isPending}
              variant="outline"
              size="sm"
              className="flex items-center gap-2 bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200"
            >
              {csvImportUuidMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Importing...
                </>
              ) : (
                <>
                  <FileUp className="h-4 w-4" />
                  Import CSV Data
                </>
              )}
            </Button>
            <Button 
              onClick={() => debugMappingsMutation.mutate()}
              disabled={debugMappingsMutation.isPending}
              variant="outline"
              size="sm"
              className="flex items-center gap-2"
            >
              {debugMappingsMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Debugging...
                </>
              ) : (
                <>
                  <Search className="h-4 w-4" />
                  Debug Data
                </>
              )}
            </Button>
            <Button 
              onClick={() => autoLinkMutation.mutate()}
              disabled={autoLinkMutation.isPending}
              className="flex items-center gap-2"
            >
              {autoLinkMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Auto-linking...
                </>
              ) : (
                <>
                  <Link className="h-4 w-4" />
                  Auto-link Users
                </>
              )}
            </Button>
            <Button 
              onClick={() => refetchMappings()}
              variant="outline"
              size="sm"
              className="flex items-center gap-2"
            >
              <Database className="h-4 w-4" />
              Refresh
            </Button>
            <Button 
              onClick={handleImportHubSpotUsers}
              disabled={hubspotUserImportMutation.isPending}
              className="flex items-center gap-2 bg-wine hover:bg-wine/90 text-white"
            >
              {hubspotUserImportMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Importing...
                </>
              ) : (
                <>
                  <Users className="h-4 w-4" />
                  Import Real Users
                </>
              )}
            </Button>
          </div>

          {/* Import Output */}
          {importOutput && (
            <div className="mt-4">
              <h4 className="font-semibold mb-2">Import Results:</h4>
              <pre className="bg-gray-100 p-3 rounded text-sm overflow-x-auto whitespace-pre-wrap">
                {importOutput}
              </pre>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Comprehensive Workflow Automation */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <PlayCircle className="h-5 w-5 text-wine" />
            Complete Data Integration Workflow
          </CardTitle>
          <CardDescription>
            Run the comprehensive HubSpot data integration workflow with user journey analytics and lifecycle management
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Workflow Progress */}
          <div className="space-y-4">
            <h4 className="font-semibold text-wine">Workflow Progress</h4>
            {workflowProgress.map((step, index) => (
              <div key={step.step} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold ${
                  step.completed 
                    ? 'bg-eucalyptus text-white' 
                    : step.inProgress 
                      ? 'bg-yellow-500 text-white animate-pulse' 
                      : 'bg-gray-300 text-gray-600'
                }`}>
                  {step.completed ? (
                    <CheckCircle className="h-5 w-5" />
                  ) : step.inProgress ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    step.step
                  )}
                </div>
                <div className="flex-1">
                  <div className="text-sm font-medium">{step.description}</div>
                  {step.completed && <div className="text-xs text-eucalyptus">✅ Completed</div>}
                  {step.inProgress && <div className="text-xs text-yellow-600">⏳ In Progress...</div>}
                </div>
              </div>
            ))}
          </div>

          {/* Workflow Action Buttons */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button 
              onClick={handleUuidMapping}
              disabled={uuidMappingMutation.isPending}
              variant="outline"
              className="flex items-center gap-2"
            >
              <MapPin className="h-4 w-4" />
              {uuidMappingMutation.isPending ? 'Running...' : 'Step 1: UUID Mapping'}
            </Button>
            
            <Button 
              onClick={handleLifecycleAnalysis}
              disabled={lifecycleAnalysisMutation.isPending}
              variant="outline"
              className="flex items-center gap-2"
            >
              <Target className="h-4 w-4" />
              {lifecycleAnalysisMutation.isPending ? 'Analyzing...' : 'Step 2: Lifecycle Analysis'}
            </Button>
            
            <Button 
              onClick={handleAnalyticsGeneration}
              disabled={analyticsGenerationMutation.isPending}
              variant="outline"
              className="flex items-center gap-2"
            >
              <BarChart3 className="h-4 w-4" />
              {analyticsGenerationMutation.isPending ? 'Generating...' : 'Step 3: Analytics Dashboard'}
            </Button>
          </div>

          {/* Full Workflow Button */}
          <div className="flex justify-center">
            <Button 
              onClick={handleFullWorkflow}
              disabled={fullWorkflowMutation.isPending}
              size="lg"
              className="bg-wine hover:bg-wine/90 text-white px-8"
            >
              {fullWorkflowMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  Running Complete Workflow...
                </>
              ) : (
                <>
                  <PlayCircle className="mr-2 h-5 w-5" />
                  Run Complete Integration Workflow
                </>
              )}
            </Button>
          </div>

          {/* Workflow Output */}
          {workflowOutput && (
            <div className="mt-6">
              <h4 className="font-semibold mb-2">Workflow Output:</h4>
              <pre className="bg-gray-100 p-4 rounded-lg text-xs overflow-auto max-h-60 whitespace-pre-wrap border">
                {workflowOutput}
              </pre>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Analytics Dashboard */}
      {analyticsData && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-eucalyptus" />
              User Journey Analytics Dashboard
            </CardTitle>
            <CardDescription>
              Real-time insights from CSV transaction data and user lifecycle tracking
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Lifecycle Distribution */}
            <div>
              <h4 className="font-semibold mb-3">Lifecycle Stage Distribution</h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {Object.entries(analyticsData.lifecycleDistribution).map(([stage, count]) => (
                  <div key={stage} className="text-center p-3 bg-gray-50 rounded-lg">
                    <div className="text-xl font-bold text-wine">{count}</div>
                    <div className="text-xs text-gray-600 capitalize">{stage.replace('_', ' ')}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Monthly Volume Chart */}
            <div>
              <h4 className="font-semibold mb-3">Monthly Transaction Volume</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {Object.entries(analyticsData.monthlyVolume).slice(0, 6).map(([month, data]) => (
                  <div key={month} className="p-4 bg-eucalyptus/10 rounded-lg">
                    <div className="font-medium text-sm">{month}</div>
                    <div className="text-lg font-bold text-eucalyptus">{data.total_bookings} bookings</div>
                    <div className="text-sm text-gray-600">${(data.total_revenue / 100).toFixed(2)} revenue</div>
                    <div className="text-xs text-gray-500">{data.completed_bookings} completed</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Top Performers */}
            <div>
              <h4 className="font-semibold mb-3">Top Performers</h4>
              <div className="space-y-2">
                {analyticsData.topPerformers.slice(0, 5).map((performer, index) => (
                  <div key={performer.user_id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Badge variant="outline">#{index + 1}</Badge>
                      <div>
                        <div className="font-medium text-sm">User {performer.user_id.substring(0, 8)}...</div>
                        <div className="text-xs text-gray-600">{performer.review_count} reviews</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-eucalyptus">{performer.average_rating.toFixed(1)} ⭐</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Mapping Statistics */}
            {analyticsData.mappingStats && (
              <div>
                <h4 className="font-semibold mb-3">UUID Mapping Status</h4>
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center p-3 bg-blue-50 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600">{analyticsData.mappingStats.totalMappings}</div>
                    <div className="text-sm text-blue-800">Total Mappings</div>
                  </div>
                  <div className="text-center p-3 bg-green-50 rounded-lg">
                    <div className="text-2xl font-bold text-green-600">{analyticsData.mappingStats.linkedMappings}</div>
                    <div className="text-sm text-green-800">Linked Users</div>
                  </div>
                  <div className="text-center p-3 bg-orange-50 rounded-lg">
                    <div className="text-2xl font-bold text-orange-600">{analyticsData.mappingStats.unmappedUsers}</div>
                    <div className="text-sm text-orange-800">Need Manual Linking</div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Data Integration Information */}
      <Card>
        <CardHeader>
          <CardTitle>Data Integration Overview</CardTitle>
          <CardDescription>
            Understanding how HubSpot, CSV data, and Village Co integrate for complete user journey tracking
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <Database className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="font-semibold mb-2">HubSpot Contacts</h3>
              <p className="text-sm text-gray-600">
                User profiles, contact information, lifecycle stages, and engagement data
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <Upload className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="font-semibold mb-2">CSV Transaction Data</h3>
              <p className="text-sm text-gray-600">
                Historical reviews, transactions, booking patterns, and user behavior analytics
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                <CheckCircle className="h-6 w-6 text-purple-600" />
              </div>
              <h3 className="font-semibold mb-2">Village Co Platform</h3>
              <p className="text-sm text-gray-600">
                Unified user accounts with complete journey tracking and lifecycle management
              </p>
            </div>
          </div>

          <Separator className="my-6" />
          
          <div className="bg-wine/10 p-4 rounded-lg border border-wine/20">
            <h4 className="font-semibold text-wine mb-2">🚀 Enhanced Workflow Features Available:</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-wine/80">
              <div>
                <strong>🎯 Automated Data Processing:</strong>
                <ul className="ml-4 list-disc space-y-1">
                  <li>UUID mapping system for user linking</li>
                  <li>Intelligent lifecycle stage assignment</li>
                  <li>Real-time analytics generation</li>
                  <li>HubSpot synchronization</li>
                </ul>
              </div>
              <div>
                <strong>📊 Advanced Analytics:</strong>
                <ul className="ml-4 list-disc space-y-1">
                  <li>Monthly transaction volume tracking</li>
                  <li>Top performer identification</li>
                  <li>Lifecycle distribution insights</li>
                  <li>User journey mapping</li>
                </ul>
              </div>
            </div>
            <div className="mt-3 text-center">
              <Badge className="bg-wine text-white">Use the "Complete Integration Workflow" button above to run all processes automatically</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}