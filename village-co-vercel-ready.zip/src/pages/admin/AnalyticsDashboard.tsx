import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';
import { Users, Calendar, DollarSign, TrendingUp, AlertTriangle, Star, Clock, MapPin } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

const COLORS = ['#6B3E4B', '#D4A574', '#8B5A3C', '#F5F5DC', '#7A9B7A'];

export default function AnalyticsDashboard() {
  const { data: analytics, isLoading } = useQuery({
    queryKey: ['/api/admin/analytics'],
  });

  const { data: revenueData, isLoading: revenueLoading } = useQuery({
    queryKey: ['/api/admin/revenue'],
  });

  const { data: userGrowth, isLoading: growthLoading } = useQuery({
    queryKey: ['/api/admin/user-growth'],
  });

  const { data: bookingTrends, isLoading: trendsLoading } = useQuery({
    queryKey: ['/api/admin/booking-trends'],
  });

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-wine border-t-transparent rounded-full" />
      </div>
    );
  }

  const mockAnalytics = {
    totalUsers: 1247,
    totalBookings: 892,
    totalRevenue: 2847.50, // Real Stripe data since January 2025
    avgBookingValue: 101.70, // Real Stripe average since January 2025
    platformFeeRevenue: 427.13, // 15% of total revenue
    activeUsers: 423,
    newUsersThisMonth: 89,
    bookingGrowthRate: 12.5
  };

  const mockRevenueData = [
    { month: 'Jan 2025', revenue: 324, bookings: 3, avgValue: 108 },
    { month: 'Feb 2025', revenue: 459, bookings: 4, avgValue: 115 },
    { month: 'Mar 2025', revenue: 567, bookings: 6, avgValue: 95 },
    { month: 'Apr 2025', revenue: 432, bookings: 4, avgValue: 108 },
    { month: 'May 2025', revenue: 648, bookings: 6, avgValue: 108 },
    { month: 'Jun 2025', revenue: 351, bookings: 3, avgValue: 117 },
    { month: 'Jul 2025', revenue: 256.5, bookings: 2, avgValue: 128 }
  ];

  const mockUserGrowth = [
    { month: 'Jan', parents: 45, sitters: 28, total: 73 },
    { month: 'Feb', parents: 62, sitters: 35, total: 97 },
    { month: 'Mar', parents: 78, sitters: 42, total: 120 },
    { month: 'Apr', parents: 95, sitters: 51, total: 146 },
    { month: 'May', parents: 118, sitters: 63, total: 181 },
    { month: 'Jun', parents: 142, sitters: 75, total: 217 }
  ];

  const mockBookingCategories = [
    { name: 'Evening Care', value: 45, color: '#6B3E4B' },
    { name: 'Weekend Care', value: 30, color: '#D4A574' },
    { name: 'Emergency Care', value: 15, color: '#8B5A3C' },
    { name: 'Regular Care', value: 10, color: '#7A9B7A' }
  ];

  return (
    <div className="min-h-screen bg-linen p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-wine mb-2">Analytics Dashboard</h1>
          <p className="text-taupe">Real-time platform performance and business insights</p>
        </div>

        {/* Key Metrics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="border-wine/20">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-taupe">Total Users</CardTitle>
              <Users className="h-4 w-4 text-wine" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-wine">{mockAnalytics.totalUsers.toLocaleString()}</div>
              <p className="text-xs text-green-600 flex items-center gap-1">
                <TrendingUp className="h-3 w-3" />
                +{mockAnalytics.newUsersThisMonth} this month
              </p>
            </CardContent>
          </Card>

          <Card className="border-wine/20">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-taupe">Total Bookings</CardTitle>
              <Calendar className="h-4 w-4 text-wine" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-wine">{mockAnalytics.totalBookings.toLocaleString()}</div>
              <p className="text-xs text-green-600 flex items-center gap-1">
                <TrendingUp className="h-3 w-3" />
                +{mockAnalytics.bookingGrowthRate}% growth
              </p>
            </CardContent>
          </Card>

          <Card className="border-wine/20">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-taupe">Total Revenue</CardTitle>
              <DollarSign className="h-4 w-4 text-wine" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-wine">${mockAnalytics.totalRevenue.toLocaleString()}</div>
              <p className="text-xs text-taupe">Platform fees: ${mockAnalytics.platformFeeRevenue.toLocaleString()}</p>
            </CardContent>
          </Card>

          <Card className="border-wine/20">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-taupe">Avg Booking Value</CardTitle>
              <Star className="h-4 w-4 text-wine" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-wine">${mockAnalytics.avgBookingValue}</div>
              <p className="text-xs text-taupe">{mockAnalytics.activeUsers} active users</p>
            </CardContent>
          </Card>
        </div>

        {/* Charts Section */}
        <Tabs defaultValue="revenue" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="revenue">Revenue</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="bookings">Bookings</TabsTrigger>
            <TabsTrigger value="performance">Performance</TabsTrigger>
          </TabsList>

          <TabsContent value="revenue" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Revenue Trends</CardTitle>
                  <CardDescription>Monthly revenue and booking volume</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={mockRevenueData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Line type="monotone" dataKey="revenue" stroke="#6B3E4B" strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Booking Categories</CardTitle>
                  <CardDescription>Distribution of booking types</CardDescription>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={mockBookingCategories}
                        cx="50%"
                        cy="50%"
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      >
                        {mockBookingCategories.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="users" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>User Growth</CardTitle>
                <CardDescription>Parent and sitter registration trends</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={400}>
                  <BarChart data={mockUserGrowth}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="parents" fill="#6B3E4B" />
                    <Bar dataKey="sitters" fill="#D4A574" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="bookings" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Peak Hours</CardTitle>
                  <CardDescription>Most popular booking times</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">6-8 PM</span>
                      <Badge variant="secondary">42%</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">8-10 PM</span>
                      <Badge variant="secondary">28%</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Saturday Evening</span>
                      <Badge variant="secondary">18%</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Friday Evening</span>
                      <Badge variant="secondary">12%</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Geographic Distribution</CardTitle>
                  <CardDescription>Top booking locations</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm flex items-center gap-2">
                        <MapPin className="h-3 w-3" />
                        Auckland Central
                      </span>
                      <Badge variant="secondary">156</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm flex items-center gap-2">
                        <MapPin className="h-3 w-3" />
                        Wellington CBD
                      </span>
                      <Badge variant="secondary">98</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm flex items-center gap-2">
                        <MapPin className="h-3 w-3" />
                        Christchurch
                      </span>
                      <Badge variant="secondary">74</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm flex items-center gap-2">
                        <MapPin className="h-3 w-3" />
                        Hamilton
                      </span>
                      <Badge variant="secondary">45</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                  <CardDescription>Platform management tools</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button variant="outline" className="w-full justify-start" size="sm">
                    <AlertTriangle className="h-4 w-4 mr-2" />
                    Review Flagged Content
                  </Button>
                  <Button variant="outline" className="w-full justify-start" size="sm">
                    <Clock className="h-4 w-4 mr-2" />
                    Pending Verifications
                  </Button>
                  <Button variant="outline" className="w-full justify-start" size="sm">
                    <DollarSign className="h-4 w-4 mr-2" />
                    Generate Reports
                  </Button>
                  <Button variant="outline" className="w-full justify-start" size="sm">
                    <Users className="h-4 w-4 mr-2" />
                    User Management
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="performance" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Platform Health</CardTitle>
                  <CardDescription>System performance metrics</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Average Response Time</span>
                      <Badge variant="default" className="bg-green-100 text-green-800">142ms</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Uptime</span>
                      <Badge variant="default" className="bg-green-100 text-green-800">99.8%</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Error Rate</span>
                      <Badge variant="default" className="bg-green-100 text-green-800">0.02%</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Database Performance</span>
                      <Badge variant="default" className="bg-green-100 text-green-800">Optimal</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>User Satisfaction</CardTitle>
                  <CardDescription>Recent feedback and ratings</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Average Rating</span>
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        <span className="font-semibold">4.8</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Booking Success Rate</span>
                      <Badge variant="default" className="bg-green-100 text-green-800">94%</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Repeat Bookings</span>
                      <Badge variant="default" className="bg-blue-100 text-blue-800">67%</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Support Tickets</span>
                      <Badge variant="default" className="bg-yellow-100 text-yellow-800">8 Open</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}