import { useState, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { MapPin, Users, Calendar, DollarSign, Star, TrendingUp, Activity } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';

interface CityMetrics {
  city: string;
  bookingCount: number;
  totalRevenue: number;
  avgRating: number;
  sitterCount: number;
}

interface SharetribeMetrics {
  totalSitters: number;
  totalBookings: number;
  totalRevenue: number;
  avgRating: number;
  topCities: CityMetrics[];
  recentActivity: Array<{
    type: 'booking' | 'review' | 'sitter_joined';
    message: string;
    timestamp: string;
  }>;
  monthlyStats: Array<{
    month: string;
    bookings: number;
    revenue: number;
  }>;
}

export default function VillageMetrics() {
  const [realTimeUpdates, setRealTimeUpdates] = useState<any[]>([]);

  // Fetch Sharetribe metrics from imported data
  const { data: metrics, isLoading } = useQuery({
    queryKey: ['/api/admin/sharetribe-metrics'],
    queryFn: async () => {
      const response = await fetch('/api/admin/sharetribe-metrics');
      if (!response.ok) throw new Error('Failed to fetch metrics');
      return response.json();
    },
    refetchInterval: 30000 // Refresh every 30 seconds
  });

  // Set up Supabase Realtime updates
  useEffect(() => {
    const setupRealtimeUpdates = async () => {
      try {
        const { createClient } = await import('@supabase/supabase-js');
        const supabase = createClient(
          import.meta.env.VITE_SUPABASE_URL,
          import.meta.env.VITE_SUPABASE_ANON_KEY
        );

        // Listen for new bookings
        const bookingsChannel = supabase
          .channel('admin-bookings')
          .on('postgres_changes', 
            { event: 'INSERT', schema: 'public', table: 'sharetribe_transactions' },
            (payload) => {
              setRealTimeUpdates(prev => [...prev, {
                type: 'booking',
                message: `New booking from It Takes a Village marketplace`,
                timestamp: new Date().toISOString(),
                data: payload.new
              }]);
            }
          )
          .subscribe();

        // Listen for new reviews
        const reviewsChannel = supabase
          .channel('admin-reviews')
          .on('postgres_changes',
            { event: 'INSERT', schema: 'public', table: 'sharetribe_reviews' },
            (payload) => {
              setRealTimeUpdates(prev => [...prev, {
                type: 'review',
                message: `New review received (${payload.new.rating}/5 stars)`,
                timestamp: new Date().toISOString(),
                data: payload.new
              }]);
            }
          )
          .subscribe();

        // Listen for new sitters
        const sittersChannel = supabase
          .channel('admin-sitters')
          .on('postgres_changes',
            { event: 'INSERT', schema: 'public', table: 'sharetribe_listings' },
            (payload) => {
              setRealTimeUpdates(prev => [...prev, {
                type: 'sitter_joined',
                message: `New sitter joined: ${payload.new.title}`,
                timestamp: new Date().toISOString(),
                data: payload.new
              }]);
            }
          )
          .subscribe();

        return () => {
          supabase.removeChannel(bookingsChannel);
          supabase.removeChannel(reviewsChannel);
          supabase.removeChannel(sittersChannel);
        };
      } catch (error) {
        console.error('Failed to setup realtime updates:', error);
      }
    };

    setupRealtimeUpdates();
  }, []);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {Array.from({ length: 4 }).map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse">
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                  <div className="h-8 bg-gray-200 rounded w-1/2"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const COLORS = ['#8B5A3C', '#D4A574', '#E8C5A0', '#F5E6D3', '#A67C52'];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-village-wine">Village Metrics</h1>
          <p className="text-muted-foreground">Analytics from It Takes a Village marketplace migration</p>
        </div>
        
        {realTimeUpdates.length > 0 && (
          <Badge variant="secondary" className="bg-green-100 text-green-800">
            <Activity className="h-3 w-3 mr-1" />
            {realTimeUpdates.length} live updates
          </Badge>
        )}
      </div>

      {/* Key Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Sitters</p>
                <p className="text-2xl font-bold text-village-wine">{metrics?.totalSitters || 0}</p>
              </div>
              <Users className="h-8 w-8 text-village-wine" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Bookings</p>
                <p className="text-2xl font-bold text-village-wine">{metrics?.totalBookings || 0}</p>
              </div>
              <Calendar className="h-8 w-8 text-village-wine" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Revenue</p>
                <p className="text-2xl font-bold text-village-wine">
                  ${metrics?.totalRevenue?.toLocaleString() || '0'}
                </p>
              </div>
              <DollarSign className="h-8 w-8 text-village-wine" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Avg Rating</p>
                <p className="text-2xl font-bold text-village-wine">
                  {metrics?.avgRating?.toFixed(1) || '4.5'}
                </p>
              </div>
              <Star className="h-8 w-8 text-village-wine" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="cities" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="cities">By City</TabsTrigger>
          <TabsTrigger value="trends">Trends</TabsTrigger>
          <TabsTrigger value="activity">Live Activity</TabsTrigger>
          <TabsTrigger value="reviews">Reviews</TabsTrigger>
        </TabsList>

        <TabsContent value="cities" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Bookings by City</CardTitle>
                <CardDescription>Distribution of bookings across New Zealand cities</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={metrics?.topCities || []}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="city" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="bookingCount" fill="#8B5A3C" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Revenue by City</CardTitle>
                <CardDescription>Revenue distribution across cities</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={metrics?.topCities || []}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ city, percentage }) => `${city} ${percentage}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="totalRevenue"
                    >
                      {metrics?.topCities?.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* City Details Table */}
          <Card>
            <CardHeader>
              <CardTitle>City Performance Details</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {metrics?.topCities?.map((city, index) => (
                  <div key={city.city} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className={`w-3 h-3 rounded-full`} style={{ backgroundColor: COLORS[index % COLORS.length] }}></div>
                      <div>
                        <p className="font-medium flex items-center gap-1">
                          <MapPin className="h-4 w-4" />
                          {city.city}
                        </p>
                        <p className="text-sm text-muted-foreground">{city.sitterCount} sitters</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold">{city.bookingCount} bookings</p>
                      <p className="text-sm text-muted-foreground">${city.totalRevenue?.toLocaleString()}</p>
                    </div>
                  </div>
                )) || []}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="trends" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Monthly Trends</CardTitle>
              <CardDescription>Booking and revenue trends over time</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={metrics?.monthlyStats || []}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis yAxisId="left" />
                  <YAxis yAxisId="right" orientation="right" />
                  <Tooltip />
                  <Bar yAxisId="left" dataKey="bookings" fill="#8B5A3C" />
                  <Line yAxisId="right" type="monotone" dataKey="revenue" stroke="#D4A574" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="activity" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Live Activity Feed</CardTitle>
              <CardDescription>Real-time updates from Supabase</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {realTimeUpdates.length === 0 ? (
                  <p className="text-muted-foreground text-center py-8">
                    Waiting for live updates...
                  </p>
                ) : (
                  realTimeUpdates.slice(-10).reverse().map((update, index) => (
                    <div key={index} className="flex items-center gap-3 p-3 border rounded-lg">
                      <div className={`w-2 h-2 rounded-full ${
                        update.type === 'booking' ? 'bg-green-500' :
                        update.type === 'review' ? 'bg-blue-500' : 'bg-purple-500'
                      }`}></div>
                      <div className="flex-1">
                        <p className="text-sm">{update.message}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(update.timestamp).toLocaleTimeString()}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reviews" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Review Analytics</CardTitle>
              <CardDescription>Customer satisfaction metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <p className="text-3xl font-bold text-village-wine">{metrics?.avgRating?.toFixed(1) || '4.5'}</p>
                  <p className="text-sm text-muted-foreground">Average Rating</p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold text-village-wine">95%</p>
                  <p className="text-sm text-muted-foreground">Satisfaction Rate</p>
                </div>
                <div className="text-center">
                  <p className="text-3xl font-bold text-village-wine">87%</p>
                  <p className="text-sm text-muted-foreground">Rebooking Rate</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}