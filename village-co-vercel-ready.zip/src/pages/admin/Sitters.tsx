import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Users, 
  CheckCircle, 
  XCircle, 
  Clock, 
  User,
  Badge as BadgeIcon
} from "lucide-react";
import { Progress } from "@/components/ui/progress";

interface SitterWithUser {
  id: number;
  userId: number;
  bio: string | null;
  experience: string | null;
  hourlyRate: string | null;
  isActive: boolean;
  identityVerified: boolean;
  policeCheckVerified: boolean;
  verificationStatus?: string;
  onboardingStep?: number;
  onboardingComplete?: boolean;
  profileComplete?: boolean;
  photoUrl: string | null;
  qualifications: string[];
  availabilityTags: string[];
  okWithPets: boolean | null;
  languagesSpoken: string | null;
  user: {
    id: number;
    firstName: string;
    lastName: string;
    email: string;
    role: string;
    createdAt: string;
  };
}

export default function AdminSitters() {
  const { data: sitters, isLoading } = useQuery<SitterWithUser[]>({
    queryKey: ["/api/admin/sitters"],
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  const getOnboardingStepName = (step: number | undefined): string => {
    if (!step) return "Not Started";
    
    const stepNames = {
      1: "Profile",
      2: "Qualifications", 
      3: "Availability",
      4: "Media",
      5: "Payout",
      6: "Verify",
      7: "Complete"
    };
    
    return stepNames[step as keyof typeof stepNames] || `Step ${step}`;
  };

  const getVerificationStatusBadge = (status: string | undefined) => {
    switch (status) {
      case "verified":
        return <Badge className="bg-emerald-100 text-emerald-800 border-emerald-200">Verified</Badge>;
      case "pending_review":
        return <Badge className="bg-amber-100 text-amber-800 border-amber-200">Pending Review</Badge>;
      case "rejected":
        return <Badge className="bg-red-100 text-red-800 border-red-200">Rejected</Badge>;
      case "not_started":
      default:
        return <Badge className="bg-gray-100 text-gray-800 border-gray-200">Not Started</Badge>;
    }
  };

  const getOnboardingProgress = (sitter: SitterWithUser): number => {
    if (sitter.onboardingComplete) return 100;
    
    const step = sitter.onboardingStep || 1;
    return Math.min((step / 7) * 100, 100);
  };

  const getProfileCompletionScore = (sitter: SitterWithUser): number => {
    let score = 0;
    const fields = [
      sitter.bio,
      sitter.experience, 
      sitter.hourlyRate,
      sitter.photoUrl,
      sitter.qualifications?.length > 0,
      sitter.availabilityTags?.length > 0
    ];
    
    const completedFields = fields.filter(field => !!field).length;
    return Math.round((completedFields / fields.length) * 100);
  };

  const totalSitters = sitters?.length || 0;
  const onboardingComplete = sitters?.filter(s => s.onboardingComplete).length || 0;
  const verified = sitters?.filter(s => s.verificationStatus === "verified").length || 0;
  const activeCount = sitters?.filter(s => s.isActive).length || 0;

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Sitter Management</h1>
          <p className="text-gray-600 mt-1">Monitor onboarding progress and verification status</p>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Sitters</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalSitters}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Onboarding Complete</CardTitle>
            <CheckCircle className="h-4 w-4 text-emerald-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{onboardingComplete}</div>
            <p className="text-xs text-muted-foreground">
              {totalSitters > 0 ? Math.round((onboardingComplete / totalSitters) * 100) : 0}% completion rate
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Verified</CardTitle>
            <BadgeIcon className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{verified}</div>
            <p className="text-xs text-muted-foreground">
              {totalSitters > 0 ? Math.round((verified / totalSitters) * 100) : 0}% verified
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Sitters</CardTitle>
            <User className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeCount}</div>
            <p className="text-xs text-muted-foreground">
              {totalSitters > 0 ? Math.round((activeCount / totalSitters) * 100) : 0}% active
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Sitters Table */}
      <Card>
        <CardHeader>
          <CardTitle>All Sitters</CardTitle>
          <CardDescription>
            Monitor sitter onboarding progress, verification status, and profile completion
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Onboarding Step</TableHead>
                <TableHead>Progress</TableHead>
                <TableHead>Complete</TableHead>
                <TableHead>Verification Status</TableHead>
                <TableHead>Profile Score</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {sitters?.map((sitter) => (
                <TableRow key={sitter.id}>
                  <TableCell className="font-medium">
                    {sitter.user.firstName} {sitter.user.lastName}
                  </TableCell>
                  
                  <TableCell className="text-sm text-gray-600">
                    {sitter.user.email}
                  </TableCell>

                  <TableCell>
                    <Badge variant="outline">
                      {getOnboardingStepName(sitter.onboardingStep)}
                    </Badge>
                  </TableCell>

                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <Progress 
                        value={getOnboardingProgress(sitter)} 
                        className="w-16 h-2"
                      />
                      <span className="text-xs text-gray-500">
                        {Math.round(getOnboardingProgress(sitter))}%
                      </span>
                    </div>
                  </TableCell>

                  <TableCell>
                    {sitter.onboardingComplete ? (
                      <CheckCircle className="h-4 w-4 text-emerald-500" />
                    ) : (
                      <XCircle className="h-4 w-4 text-gray-400" />
                    )}
                  </TableCell>

                  <TableCell>
                    {getVerificationStatusBadge(sitter.verificationStatus)}
                  </TableCell>

                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <Progress 
                        value={getProfileCompletionScore(sitter)} 
                        className="w-16 h-2"
                      />
                      <span className="text-xs text-gray-500">
                        {getProfileCompletionScore(sitter)}%
                      </span>
                    </div>
                  </TableCell>

                  <TableCell>
                    <Badge 
                      className={sitter.isActive 
                        ? "bg-emerald-100 text-emerald-800 border-emerald-200" 
                        : "bg-gray-100 text-gray-800 border-gray-200"
                      }
                    >
                      {sitter.isActive ? "Active" : "Inactive"}
                    </Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          {!sitters || sitters.length === 0 && (
            <div className="text-center py-8">
              <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">No sitters found</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}