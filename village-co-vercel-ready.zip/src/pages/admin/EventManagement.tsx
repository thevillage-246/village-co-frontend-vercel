import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '@/components/ui/dialog';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Calendar, Clock, MapPin, Users, ExternalLink, Plus, Edit, Trash2 } from 'lucide-react';
import { format } from 'date-fns';
import { insertEventSchema, type CommunityEvent } from '@shared/schema';
import AdminSidebar from '@/components/AdminSidebar';
import { apiRequest } from '@/lib/queryClient';

// Form validation schema
const eventFormSchema = insertEventSchema.extend({
  eventDate: z.string().min(1, 'Event date is required'),
  endDate: z.string().optional(),
});

type EventFormData = z.infer<typeof eventFormSchema>;

const EVENT_TYPES = [
  { value: 'workshop', label: 'Workshop' },
  { value: 'meetup', label: 'Meetup' },
  { value: 'training', label: 'Training' },
  { value: 'social', label: 'Social Event' },
  { value: 'webinar', label: 'Webinar' },
];

const TARGET_AUDIENCES = [
  { value: 'parents', label: 'Parents' },
  { value: 'sitters', label: 'Sitters' },
  { value: 'both', label: 'Parents & Sitters' },
  { value: 'community', label: 'Community' },
];

export default function EventManagement() {
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState<CommunityEvent | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch events
  const { data: events, isLoading, error } = useQuery({
    queryKey: ['/api/admin/events'],
  });

  // Form setup
  const form = useForm<EventFormData>({
    resolver: zodResolver(eventFormSchema),
    defaultValues: {
      title: '',
      description: '',
      eventDate: '',
      endDate: '',
      location: '',
      lumaUrl: '',
      maxAttendees: undefined,
      eventType: 'meetup',
      targetAudience: 'both',
      isActive: true,
      isFeatured: false,
      registrationRequired: true,
      cost: 'Free',
      organizerName: '',
      organizerEmail: '',
      tags: [],
      imageUrl: '',
    },
  });

  // Create/Update event mutation
  const createEventMutation = useMutation({
    mutationFn: async (data: EventFormData) => {
      const endpoint = editingEvent ? `/api/admin/events/${editingEvent.id}` : '/api/admin/events';
      const method = editingEvent ? 'PUT' : 'POST';
      
      const eventData = {
        ...data,
        eventDate: new Date(data.eventDate).toISOString(),
        endDate: data.endDate ? new Date(data.endDate).toISOString() : null,
        tags: data.tags || [],
      };

      return apiRequest(method, endpoint, eventData);
    },
    onSuccess: () => {
      toast({
        title: editingEvent ? 'Event Updated' : 'Event Created',
        description: editingEvent ? 'Event has been updated successfully.' : 'Event has been created successfully.',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/events'] });
      setIsCreateDialogOpen(false);
      setEditingEvent(null);
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to save event',
        variant: 'destructive',
      });
    },
  });

  // Delete event mutation
  const deleteEventMutation = useMutation({
    mutationFn: async (eventId: number) => {
      return apiRequest('DELETE', `/api/admin/events/${eventId}`);
    },
    onSuccess: () => {
      toast({
        title: 'Event Deleted',
        description: 'Event has been deleted successfully.',
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/events'] });
    },
    onError: (error: any) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to delete event',
        variant: 'destructive',
      });
    },
  });

  const handleEdit = (event: CommunityEvent) => {
    setEditingEvent(event);
    form.reset({
      title: event.title,
      description: event.description,
      eventDate: new Date(event.eventDate).toISOString().slice(0, 16),
      endDate: event.endDate ? new Date(event.endDate).toISOString().slice(0, 16) : '',
      location: event.location || '',
      lumaUrl: event.lumaUrl || '',
      maxAttendees: event.maxAttendees || undefined,
      eventType: event.eventType,
      targetAudience: event.targetAudience,
      isActive: event.isActive,
      isFeatured: event.isFeatured,
      registrationRequired: event.registrationRequired,
      cost: event.cost,
      organizerName: event.organizerName,
      organizerEmail: event.organizerEmail,
      tags: event.tags || [],
      imageUrl: event.imageUrl || '',
    });
    setIsCreateDialogOpen(true);
  };

  const handleDelete = (eventId: number) => {
    if (confirm('Are you sure you want to delete this event?')) {
      deleteEventMutation.mutate(eventId);
    }
  };

  const onSubmit = (data: EventFormData) => {
    createEventMutation.mutate(data);
  };

  return (
    <div className="flex flex-col lg:flex-row min-h-screen">
      <AdminSidebar />
      <main className="flex-1 p-6">
        <div className="mb-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold">Event Management</h1>
              <p className="text-gray-600 mt-1">Manage community events with Lu.ma integration</p>
            </div>
            <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
              <DialogTrigger asChild>
                <Button onClick={() => { setEditingEvent(null); form.reset(); }}>
                  <Plus className="w-4 h-4 mr-2" />
                  Create Event
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>{editingEvent ? 'Edit Event' : 'Create New Event'}</DialogTitle>
                  <DialogDescription>
                    Create events for the Village Co community with Lu.ma integration for registrations.
                  </DialogDescription>
                </DialogHeader>
                
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="col-span-2">
                      <Label htmlFor="title">Event Title</Label>
                      <Input
                        id="title"
                        {...form.register('title')}
                        placeholder="Parent & Sitter Meetup"
                      />
                      {form.formState.errors.title && (
                        <p className="text-sm text-red-500">{form.formState.errors.title.message}</p>
                      )}
                    </div>

                    <div className="col-span-2">
                      <Label htmlFor="description">Description</Label>
                      <Textarea
                        id="description"
                        {...form.register('description')}
                        placeholder="Join us for an evening of networking and community building..."
                        rows={3}
                      />
                    </div>

                    <div>
                      <Label htmlFor="eventType">Event Type</Label>
                      <Select value={form.watch('eventType')} onValueChange={(value) => form.setValue('eventType', value)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {EVENT_TYPES.map((type) => (
                            <SelectItem key={type.value} value={type.value}>
                              {type.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="targetAudience">Target Audience</Label>
                      <Select value={form.watch('targetAudience')} onValueChange={(value) => form.setValue('targetAudience', value)}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {TARGET_AUDIENCES.map((audience) => (
                            <SelectItem key={audience.value} value={audience.value}>
                              {audience.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="eventDate">Event Date & Time</Label>
                      <Input
                        id="eventDate"
                        type="datetime-local"
                        {...form.register('eventDate')}
                      />
                    </div>

                    <div>
                      <Label htmlFor="endDate">End Date & Time (Optional)</Label>
                      <Input
                        id="endDate"
                        type="datetime-local"
                        {...form.register('endDate')}
                      />
                    </div>

                    <div>
                      <Label htmlFor="location">Location</Label>
                      <Input
                        id="location"
                        {...form.register('location')}
                        placeholder="Auckland Community Centre or Online"
                      />
                    </div>

                    <div>
                      <Label htmlFor="cost">Cost</Label>
                      <Input
                        id="cost"
                        {...form.register('cost')}
                        placeholder="Free or $25"
                      />
                    </div>

                    <div className="col-span-2">
                      <Label htmlFor="lumaUrl">Lu.ma Event Page URL</Label>
                      <Input
                        id="lumaUrl"
                        {...form.register('lumaUrl')}
                        placeholder="https://lu.ma/your-event"
                      />
                      <p className="text-sm text-gray-500 mt-1">
                        Create your event on Lu.ma and paste the URL here for seamless registration
                      </p>
                    </div>

                    <div>
                      <Label htmlFor="maxAttendees">Max Attendees</Label>
                      <Input
                        id="maxAttendees"
                        type="number"
                        {...form.register('maxAttendees', { valueAsNumber: true })}
                        placeholder="50"
                      />
                    </div>

                    <div>
                      <Label htmlFor="imageUrl">Event Image URL</Label>
                      <Input
                        id="imageUrl"
                        {...form.register('imageUrl')}
                        placeholder="https://example.com/event-image.jpg"
                      />
                    </div>

                    <div>
                      <Label htmlFor="organizerName">Organizer Name</Label>
                      <Input
                        id="organizerName"
                        {...form.register('organizerName')}
                        placeholder="The Village Co Team"
                      />
                    </div>

                    <div>
                      <Label htmlFor="organizerEmail">Organizer Email</Label>
                      <Input
                        id="organizerEmail"
                        type="email"
                        {...form.register('organizerEmail')}
                        placeholder="events@thevillageco.nz"
                      />
                    </div>

                    <div className="flex items-center space-x-2">
                      <Switch
                        id="isActive"
                        checked={form.watch('isActive') ?? true}
                        onCheckedChange={(checked) => form.setValue('isActive', checked)}
                      />
                      <Label htmlFor="isActive">Active</Label>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Switch
                        id="isFeatured"
                        checked={form.watch('isFeatured') ?? false}
                        onCheckedChange={(checked) => form.setValue('isFeatured', checked)}
                      />
                      <Label htmlFor="isFeatured">Featured Event</Label>
                    </div>

                    <div className="flex items-center space-x-2">
                      <Switch
                        id="registrationRequired"
                        checked={form.watch('registrationRequired') ?? true}
                        onCheckedChange={(checked) => form.setValue('registrationRequired', checked)}
                      />
                      <Label htmlFor="registrationRequired">Registration Required</Label>
                    </div>
                  </div>

                  <div className="flex justify-end space-x-2 pt-4">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setIsCreateDialogOpen(false)}
                    >
                      Cancel
                    </Button>
                    <Button type="submit" disabled={createEventMutation.isPending}>
                      {createEventMutation.isPending ? 'Saving...' : editingEvent ? 'Update Event' : 'Create Event'}
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {isLoading ? (
          <div className="text-center py-8">Loading events...</div>
        ) : error ? (
          <div className="text-center py-8 text-red-500">
            Error loading events: {error?.message || 'Unknown error'}
          </div>
        ) : (
          <div className="grid gap-6">
            {events?.length === 0 ? (
              <Card>
                <CardContent className="text-center py-8">
                  <Calendar className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium mb-2">No Events Yet</h3>
                  <p className="text-gray-600 mb-4">Create your first community event to get started.</p>
                  <Button onClick={() => setIsCreateDialogOpen(true)}>
                    <Plus className="w-4 h-4 mr-2" />
                    Create Event
                  </Button>
                </CardContent>
              </Card>
            ) : (
              events?.map((event: CommunityEvent) => (
                <Card key={event.id} className="overflow-hidden">
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <CardTitle className="text-xl">{event.title}</CardTitle>
                        <CardDescription className="mt-1">
                          {event.description}
                        </CardDescription>
                        <div className="flex flex-wrap gap-2 mt-3">
                          <Badge variant={event.isActive ? "default" : "secondary"}>
                            {event.isActive ? 'Active' : 'Inactive'}
                          </Badge>
                          {event.isFeatured && (
                            <Badge variant="outline">Featured</Badge>
                          )}
                          <Badge variant="outline">{event.eventType}</Badge>
                          <Badge variant="outline">{event.targetAudience}</Badge>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEdit(event)}
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDelete(event.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
                      <div className="flex items-center text-gray-600">
                        <Calendar className="w-4 h-4 mr-2" />
                        {format(new Date(event.eventDate), 'MMM d, yyyy')}
                      </div>
                      <div className="flex items-center text-gray-600">
                        <Clock className="w-4 h-4 mr-2" />
                        {format(new Date(event.eventDate), 'h:mm a')}
                      </div>
                      {event.location && (
                        <div className="flex items-center text-gray-600">
                          <MapPin className="w-4 h-4 mr-2" />
                          {event.location}
                        </div>
                      )}
                      {event.maxAttendees && (
                        <div className="flex items-center text-gray-600">
                          <Users className="w-4 h-4 mr-2" />
                          {event.currentAttendees || 0} / {event.maxAttendees}
                        </div>
                      )}
                    </div>
                    
                    {event.lumaUrl && (
                      <div className="mt-4">
                        <a
                          href={event.lumaUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center text-blue-600 hover:text-blue-800"
                        >
                          <ExternalLink className="w-4 h-4 mr-2" />
                          Register on Lu.ma
                        </a>
                      </div>
                    )}

                    <div className="mt-4 pt-4 border-t border-gray-100">
                      <div className="flex justify-between items-center text-sm text-gray-600">
                        <span>Organized by: {event.organizerName}</span>
                        <span>{event.cost}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        )}
      </main>
    </div>
  );
}