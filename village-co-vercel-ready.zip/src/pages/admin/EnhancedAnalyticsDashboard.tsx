import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { 
  BarChart3, 
  Users, 
  MapPin, 
  TrendingUp, 
  Star, 
  AlertTriangle,
  Activity,
  Clock,
  Target,
  Download,
  RefreshCw
} from 'lucide-react';
import SitterEngagementDashboard from '@/components/admin/SitterEngagementDashboard';
import DemandHeatmapDashboard from '@/components/admin/DemandHeatmapDashboard';

export default function EnhancedAnalyticsDashboard() {
  const [activeTab, setActiveTab] = useState('engagement');
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    // Simulate refresh delay
    setTimeout(() => {
      setIsRefreshing(false);
    }, 1000);
  };

  const handleExport = () => {
    // Export functionality would go here
    console.log('Exporting analytics data...');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="py-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  Admin Analytics Dashboard
                </h1>
                <p className="text-gray-600 mt-1">
                  Actionable insights for sitter quality and geographic demand
                </p>
              </div>
              <div className="flex gap-3">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={handleRefresh}
                  disabled={isRefreshing}
                >
                  <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
                  Refresh
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={handleExport}
                >
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Quick Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Active Sitters</p>
                  <p className="text-3xl font-bold text-blue-600">47</p>
                  <p className="text-xs text-green-600 mt-1">↑ 12% from last month</p>
                </div>
                <div className="p-3 bg-blue-100 rounded-lg">
                  <Users className="h-6 w-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">High Performers</p>
                  <p className="text-3xl font-bold text-green-600">12</p>
                  <p className="text-xs text-green-600 mt-1">↑ 3 new this month</p>
                </div>
                <div className="p-3 bg-green-100 rounded-lg">
                  <Star className="h-6 w-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Supply Gaps</p>
                  <p className="text-3xl font-bold text-red-600">8</p>
                  <p className="text-xs text-red-600 mt-1">↑ 2 areas need attention</p>
                </div>
                <div className="p-3 bg-red-100 rounded-lg">
                  <AlertTriangle className="h-6 w-6 text-red-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Conversion Rate</p>
                  <p className="text-3xl font-bold text-purple-600">73%</p>
                  <p className="text-xs text-green-600 mt-1">↑ 5% improvement</p>
                </div>
                <div className="p-3 bg-purple-100 rounded-lg">
                  <Target className="h-6 w-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Analytics Tabs */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Detailed Analytics</CardTitle>
              <div className="flex gap-2">
                <Badge variant="secondary" className="text-xs">
                  Live Data
                </Badge>
                <Badge variant="outline" className="text-xs">
                  Last updated: {new Date().toLocaleTimeString()}
                </Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="engagement" className="flex items-center gap-2">
                  <Activity className="h-4 w-4" />
                  Sitter Engagement
                </TabsTrigger>
                <TabsTrigger value="demand" className="flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  Geographic Demand
                </TabsTrigger>
              </TabsList>

              <TabsContent value="engagement" className="mt-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold">Sitter Performance Analytics</h3>
                    <div className="flex gap-2">
                      <Badge className="bg-green-100 text-green-800 border-green-200">
                        ⭐ High Performers: Track top-rated, most active sitters
                      </Badge>
                      <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200">
                        🟡 Under-engaged: Active logins but few bookings
                      </Badge>
                      <Badge className="bg-red-100 text-red-800 border-red-200">
                        🔴 Inactive: No login in 14+ days
                      </Badge>
                    </div>
                  </div>
                  <SitterEngagementDashboard />
                </div>
              </TabsContent>

              <TabsContent value="demand" className="mt-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold">Geographic Demand & Supply Analysis</h3>
                    <div className="flex gap-2">
                      <Badge className="bg-red-100 text-red-800 border-red-200">
                        🔴 Critical Gaps: High searches, low sitter availability
                      </Badge>
                      <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200">
                        🟡 Supply Gaps: Moderate imbalance areas
                      </Badge>
                      <Badge className="bg-green-100 text-green-800 border-green-200">
                        🟢 Balanced: Healthy supply-demand ratio
                      </Badge>
                    </div>
                  </div>
                  <DemandHeatmapDashboard />
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Action Items */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5" />
              Recommended Actions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-3">
                <h4 className="font-medium text-gray-900">Sitter Engagement</h4>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 p-3 bg-red-50 rounded-lg">
                    <AlertTriangle className="h-4 w-4 text-red-500" />
                    <span className="text-sm">Contact 5 inactive sitters (14+ days)</span>
                    <Button size="sm" variant="outline" className="ml-auto">
                      Send Reminders
                    </Button>
                  </div>
                  <div className="flex items-center gap-2 p-3 bg-yellow-50 rounded-lg">
                    <Clock className="h-4 w-4 text-yellow-500" />
                    <span className="text-sm">Follow up with 8 under-engaged sitters</span>
                    <Button size="sm" variant="outline" className="ml-auto">
                      Send Support
                    </Button>
                  </div>
                  <div className="flex items-center gap-2 p-3 bg-green-50 rounded-lg">
                    <Star className="h-4 w-4 text-green-500" />
                    <span className="text-sm">Recognize 12 high performers</span>
                    <Button size="sm" variant="outline" className="ml-auto">
                      Send Rewards
                    </Button>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <h4 className="font-medium text-gray-900">Geographic Coverage</h4>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 p-3 bg-red-50 rounded-lg">
                    <MapPin className="h-4 w-4 text-red-500" />
                    <span className="text-sm">Recruit sitters in 3 high-demand areas</span>
                    <Button size="sm" variant="outline" className="ml-auto">
                      Start Campaign
                    </Button>
                  </div>
                  <div className="flex items-center gap-2 p-3 bg-blue-50 rounded-lg">
                    <TrendingUp className="h-4 w-4 text-blue-500" />
                    <span className="text-sm">Increase marketing in Rototuna & Te Rapa</span>
                    <Button size="sm" variant="outline" className="ml-auto">
                      Boost Ads
                    </Button>
                  </div>
                  <div className="flex items-center gap-2 p-3 bg-purple-50 rounded-lg">
                    <BarChart3 className="h-4 w-4 text-purple-500" />
                    <span className="text-sm">Peak demand: 6-8 PM weekdays</span>
                    <Button size="sm" variant="outline" className="ml-auto">
                      Optimise
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}