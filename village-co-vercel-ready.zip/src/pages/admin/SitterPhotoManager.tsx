import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, Upload, Check, X, Eye, Save, RefreshCw } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';

interface SitterProfile {
  id: number;
  userId: number;
  firstName: string;
  lastName: string;
  photoUrl?: string;
  email?: string;
  isApproved: boolean;
}

interface AvailablePhoto {
  filename: string;
  path: string;
  preview: string;
}

const availablePhotos: AvailablePhoto[] = [
  { filename: 'Photo 1', path: '/attached_assets/67160a4a-a075-4057-9902-8f21c4498eba_1752453806143.avif', preview: '/attached_assets/67160a4a-a075-4057-9902-8f21c4498eba_1752453806143.avif' },
  { filename: 'Photo 2', path: '/attached_assets/675f2abe-2dcd-442c-809c-4575d34ff224_1752227885718.avif', preview: '/attached_assets/675f2abe-2dcd-442c-809c-4575d34ff224_1752227885718.avif' },
  { filename: 'Photo 3', path: '/attached_assets/6791e531-7e13-464e-ae10-a6eb130ac85b_1752227989362.avif', preview: '/attached_assets/6791e531-7e13-464e-ae10-a6eb130ac85b_1752227989362.avif' },
  { filename: 'Photo 4', path: '/attached_assets/6791e53a-8d30-4ced-8eca-7fef5d0746d1_1752227991644.avif', preview: '/attached_assets/6791e53a-8d30-4ced-8eca-7fef5d0746d1_1752227991644.avif' },
  { filename: 'Photo 5', path: '/attached_assets/6791e546-08ab-4249-a2fa-ac5fa7a0ddc4_1752227994482.avif', preview: '/attached_assets/6791e546-08ab-4249-a2fa-ac5fa7a0ddc4_1752227994482.avif' },
  { filename: 'Photo 6', path: '/attached_assets/67a5beb4-3317-41e4-90e3-9d03978caea6_1752228020386.avif', preview: '/attached_assets/67a5beb4-3317-41e4-90e3-9d03978caea6_1752228020386.avif' },
  { filename: 'Photo 7', path: '/attached_assets/67a5bee0-36d0-4577-b5d3-62724421e2d6_1752228024048.avif', preview: '/attached_assets/67a5bee0-36d0-4577-b5d3-62724421e2d6_1752228024048.avif' },
  { filename: 'Photo 8', path: '/attached_assets/67a836ba-e765-4360-8f35-4d442654eb2d_1752227958640.avif', preview: '/attached_assets/67a836ba-e765-4360-8f35-4d442654eb2d_1752227958640.avif' },
  { filename: 'Photo 9', path: '/attached_assets/67ad32b2-a3f5-4d5a-8860-9bd5d86e4f98_1752228056407.avif', preview: '/attached_assets/67ad32b2-a3f5-4d5a-8860-9bd5d86e4f98_1752228056407.avif' },
  { filename: 'Photo 10', path: '/attached_assets/67ad39ed-bedf-40e9-8a83-830d443e1016_1752228058535.avif', preview: '/attached_assets/67ad39ed-bedf-40e9-8a83-830d443e1016_1752228058535.avif' },
  { filename: 'Photo 11', path: '/attached_assets/67e0876a-5d89-45fa-8947-f3f88f429314_1752227819872.avif', preview: '/attached_assets/67e0876a-5d89-45fa-8947-f3f88f429314_1752227819872.avif' },
  { filename: 'Photo 12', path: '/attached_assets/67e08776-54f6-4dec-94e4-c150437450c6_1752227823104.avif', preview: '/attached_assets/67e08776-54f6-4dec-94e4-c150437450c6_1752227823104.avif' },
  { filename: 'Photo 13', path: '/attached_assets/67e087a1-bd33-4c0e-9133-43824691dbda_1752227837844.avif', preview: '/attached_assets/67e087a1-bd33-4c0e-9133-43824691dbda_1752227837844.avif' },
  { filename: 'Photo 14', path: '/attached_assets/67e0cfdb-d37c-49dc-a642-bbe20472e8c4_1752228084048.avif', preview: '/attached_assets/67e0cfdb-d37c-49dc-a642-bbe20472e8c4_1752228084048.avif' },
  { filename: 'Photo 15', path: '/attached_assets/67e36fbc-6163-447f-949a-4681db8316e8_1752228086696.avif', preview: '/attached_assets/67e36fbc-6163-447f-949a-4681db8316e8_1752228086696.avif' },
  { filename: 'Photo 16', path: '/attached_assets/67e49c59-3508-4140-969b-68fd7eebcf90_1752227724331.avif', preview: '/attached_assets/67e49c59-3508-4140-969b-68fd7eebcf90_1752227724331.avif' },
  { filename: 'Photo 17', path: '/attached_assets/67e4a3cb-6fe9-4a8a-a21b-72569496d26e_1752227729053.avif', preview: '/attached_assets/67e4a3cb-6fe9-4a8a-a21b-72569496d26e_1752227729053.avif' },
  { filename: 'Photo 18', path: '/attached_assets/67f58b01-d7cd-4930-b9c4-8f4921fb3463_1752227890469.avif', preview: '/attached_assets/67f58b01-d7cd-4930-b9c4-8f4921fb3463_1752227890469.avif' },
  { filename: 'Photo 19', path: '/attached_assets/67f58b0d-951b-411e-81d7-b69d3f3f3e27_1752227892875.avif', preview: '/attached_assets/67f58b0d-951b-411e-81d7-b69d3f3f3e27_1752227892875.avif' },
  { filename: 'Photo 20', path: '/attached_assets/67f58b1f-f74e-4b28-82ae-dcb5ca1a3276_1752227896599.avif', preview: '/attached_assets/67f58b1f-f74e-4b28-82ae-dcb5ca1a3276_1752227896599.avif' }
];

export default function SitterPhotoManager() {
  const [sitters, setSitters] = useState<SitterProfile[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedSitter, setSelectedSitter] = useState<SitterProfile | null>(null);
  const [selectedPhoto, setSelectedPhoto] = useState<string>('');
  const [isUpdating, setIsUpdating] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadSitters();
  }, []);

  const loadSitters = async () => {
    try {
      setIsLoading(true);
      
      // Check authentication - multiple token locations for compatibility
      const token = localStorage.getItem('auth_token') || 
                    localStorage.getItem('authToken') || 
                    localStorage.getItem('sb-localhost-auth-token');
      
      console.log('Token check:', { 
        auth_token: !!localStorage.getItem('auth_token'),
        authToken: !!localStorage.getItem('authToken'),
        sb_token: !!localStorage.getItem('sb-localhost-auth-token'),
        found_token: !!token
      });
      
      if (!token) {
        throw new Error('Authentication required for admin access');
      }
      
      const response = await apiRequest('GET', '/api/sitters/all');
      const responseData = await response.json();
      console.log('Photo Manager API Response:', responseData);
      
      // Handle response format: { success: true, data: sitters }
      const sittersData = responseData?.success ? responseData.data : (Array.isArray(responseData) ? responseData : []);
      console.log('Processed sitters data:', sittersData);
      console.log('Number of sitters:', sittersData.length);
      
      setSitters(sittersData);
    } catch (error: any) {
      console.error('Photo Manager Load Error:', error);
      
      // Handle auth errors specifically
      if (error.message.includes('401') || error.message.includes('Unauthorized') || error.message.includes('Authentication required')) {
        toast({
          title: 'Authentication Required',
          description: 'Please log in as admin to access photo management',
          variant: 'destructive',
        });
        window.location.href = '/direct-login';
        return;
      }
      
      toast({
        title: 'Error',
        description: 'Failed to load sitters: ' + error.message,
        variant: 'destructive',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const updateSitterPhoto = async (sitterId: number, photoUrl: string) => {
    try {
      setIsUpdating(true);
      
      await apiRequest('PUT', `/api/sitters/${sitterId}/photo`, {
        photoUrl: photoUrl
      });

      // Update local state
      setSitters(sitters.map(sitter => 
        sitter.id === sitterId 
          ? { ...sitter, photoUrl: photoUrl }
          : sitter
      ));

      toast({
        title: 'Success',
        description: 'Sitter photo updated successfully',
      });

      setSelectedSitter(null);
      setSelectedPhoto('');
    } catch (error: any) {
      toast({
        title: 'Error',
        description: 'Failed to update photo: ' + error.message,
        variant: 'destructive',
      });
    } finally {
      setIsUpdating(false);
    }
  };

  const handleSitterSelect = (sitter: SitterProfile) => {
    setSelectedSitter(sitter);
    setSelectedPhoto(sitter.photoUrl || '');
  };

  const handlePhotoSelect = (photoPath: string) => {
    setSelectedPhoto(photoPath);
  };

  const handleSavePhoto = async () => {
    if (selectedSitter && selectedPhoto) {
      await updateSitterPhoto(selectedSitter.id, selectedPhoto);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin" />
        <span className="ml-2">Loading sitters...</span>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-village-wine">Sitter Photo Manager</h1>
        <p className="text-almond-frost mt-2">Update profile photos for all sitters</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Sitters List */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Avatar className="h-5 w-5" />
              All Sitters ({sitters.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {sitters.map((sitter) => (
                <div
                  key={sitter.id}
                  className={`flex items-center gap-3 p-3 rounded-lg border cursor-pointer transition-colors ${
                    selectedSitter?.id === sitter.id 
                      ? 'border-village-wine bg-village-linen' 
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => handleSitterSelect(sitter)}
                >
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={sitter.photoUrl} alt={sitter.firstName} />
                    <AvatarFallback>
                      {sitter.firstName?.[0]}{sitter.lastName?.[0]}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <h3 className="font-medium">
                      <a 
                        href={`/profile/${sitter.userId}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-village-wine hover:text-village-wine/80 underline"
                      >
                        {sitter.firstName} {sitter.lastName}
                      </a>
                    </h3>
                    <p className="text-sm text-gray-500">ID: {sitter.userId}</p>
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    {sitter.isApproved && (
                      <Badge variant="secondary" className="text-xs">
                        Approved
                      </Badge>
                    )}
                    {sitter.photoUrl ? (
                      <Badge variant="outline" className="text-xs text-green-600">
                        <Check className="h-3 w-3 mr-1" />
                        Has Photo
                      </Badge>
                    ) : (
                      <Badge variant="outline" className="text-xs text-red-600">
                        <X className="h-3 w-3 mr-1" />
                        No Photo
                      </Badge>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Photo Selection */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="h-5 w-5" />
              Photo Selection
              {selectedSitter && (
                <span className="text-sm font-normal text-gray-500">
                  for {selectedSitter.firstName} {selectedSitter.lastName}
                </span>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {selectedSitter ? (
              <div className="space-y-4">
                {/* Current Photo Preview */}
                <div className="text-center">
                  <Label className="text-sm font-medium">Current Photo</Label>
                  <div className="mt-2">
                    <Avatar className="h-24 w-24 mx-auto">
                      <AvatarImage src={selectedPhoto} alt={selectedSitter.firstName} />
                      <AvatarFallback className="text-2xl">
                        {selectedSitter.firstName?.[0]}{selectedSitter.lastName?.[0]}
                      </AvatarFallback>
                    </Avatar>
                  </div>
                </div>

                {/* Available Photos Grid */}
                <div>
                  <Label className="text-sm font-medium">Available Photos</Label>
                  <div className="grid grid-cols-4 gap-2 mt-2 max-h-64 overflow-y-auto">
                    {availablePhotos.map((photo, index) => (
                      <div
                        key={index}
                        className={`relative aspect-square rounded-lg overflow-hidden cursor-pointer border-2 transition-colors ${
                          selectedPhoto === photo.path
                            ? 'border-village-wine'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                        onClick={() => handlePhotoSelect(photo.path)}
                      >
                        <img
                          src={photo.preview}
                          alt={photo.filename}
                          className="w-full h-full object-cover"
                        />
                        {selectedPhoto === photo.path && (
                          <div className="absolute inset-0 bg-village-wine bg-opacity-20 flex items-center justify-center">
                            <Check className="h-6 w-6 text-village-wine" />
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3 pt-4">
                  <Button
                    onClick={handleSavePhoto}
                    disabled={!selectedPhoto || isUpdating}
                    className="flex-1"
                  >
                    {isUpdating ? (
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    ) : (
                      <Save className="h-4 w-4 mr-2" />
                    )}
                    Save Photo
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setSelectedSitter(null);
                      setSelectedPhoto('');
                    }}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <Upload className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Select a sitter from the list to update their photo</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}