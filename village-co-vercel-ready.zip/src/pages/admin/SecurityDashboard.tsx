import { SecurityDashboard } from "@/components/admin/SecurityDashboard";

export default function SecurityDashboardPage() {
  return <SecurityDashboard />;
}