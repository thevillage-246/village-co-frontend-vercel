import React from 'react';
import { useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/contexts/AuthContext';
import { USER_ROLES, BOOKING_STATUS } from '@shared/schema';
import AdminSidebar from '@/components/AdminSidebar';
import DragDropQuickActions from '@/components/admin/DragDropQuickActions';
import ReferralStats from '@/components/admin/ReferralStats';
import StripeAnalytics from '@/components/admin/StripeAnalytics';
import BookOnBehalfOfParent from '@/components/admin/BookOnBehalfOfParent';
import RebookingLeaderboard from '@/components/admin/RebookingLeaderboard';
import VeriffNotifications from '@/components/admin/VeriffNotifications';
import EmailManager from '@/components/admin/EmailManager';

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { 
  ArrowRight, 
  UserCheck, 
  Users, 
  Briefcase, 
  Clock, 
  DollarSign, 
  Star, 
  CheckSquare, 
  HelpCircle
} from 'lucide-react';

const AdminDashboard: React.FC = () => {
  const { user } = useAuth();
  const [, navigate] = useLocation();

  // Verify admin role
  if (user?.role !== USER_ROLES.ADMIN) {
    navigate('/');
    return null;
  }

  // Fetch sitters pending approval
  const { data: response, isLoading: loadingSitters } = useQuery({
    queryKey: ['/api/sitters/all'],
    queryFn: async () => {
      const response = await fetch('/api/sitters/all', {
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch sitters');
      }
      
      return response.json();
    }
  });

  // Filter for pending sitters
  const pendingSitters = response?.data?.filter((sitter: any) => !sitter.isApproved) || [];

  // Fetch concierge requests
  const { data: conciergeRequests, isLoading: loadingRequests } = useQuery({
    queryKey: ['/api/admin/concierge-requests'],
    queryFn: async () => {
      const response = await fetch('/api/admin/concierge-requests', {
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch concierge requests');
      }
      
      return response.json();
    }
  });

  // Simple stats
  const totalPendingSitters = pendingSitters.length;
  const totalConciergeRequests = conciergeRequests?.length || 0;

  return (
    <div className="flex flex-col lg:flex-row min-h-screen">
      <AdminSidebar />
      <main className="flex-1 p-3 md:p-6 lg:ml-0">
        <div className="mb-4 md:mb-6">
          <h1 className="text-xl md:text-2xl lg:text-3xl font-bold">Admin Dashboard</h1>
          <p className="text-gray-500 mt-1 text-sm md:text-base">Manage sitter approvals, concierge requests, and platform data</p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-6 md:mb-8">
        <Card>
          <CardContent className="p-4 md:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs md:text-sm text-muted-foreground">Pending Sitters</p>
                <p className="text-2xl md:text-3xl font-bold mt-1">{totalPendingSitters}</p>
              </div>
              <div className="h-12 w-12 bg-primary/10 rounded-full flex items-center justify-center">
                <UserCheck className="h-6 w-6 text-primary" />
              </div>
            </div>
            {totalPendingSitters > 0 && (
              <Button 
                variant="link" 
                className="p-0 h-auto text-primary mt-2"
                onClick={() => navigate('/admin/sitter-approvals')}
              >
                Review Applications
              </Button>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 md:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs md:text-sm text-muted-foreground">Concierge Requests</p>
                <p className="text-2xl md:text-3xl font-bold mt-1">{totalConciergeRequests}</p>
              </div>
              <div className="h-12 w-12 bg-amber-100 rounded-full flex items-center justify-center">
                <HelpCircle className="h-6 w-6 text-amber-500" />
              </div>
            </div>
            {totalConciergeRequests > 0 && (
              <Button 
                variant="link" 
                className="p-0 h-auto text-primary mt-2"
                onClick={() => navigate('/admin/concierge-requests')}
              >
                Manage Requests
              </Button>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 md:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs md:text-sm text-muted-foreground">Total Sitters</p>
                <p className="text-2xl md:text-3xl font-bold mt-1">-</p>
              </div>
              <div className="h-12 w-12 bg-blue-100 rounded-full flex items-center justify-center">
                <Users className="h-6 w-6 text-blue-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4 md:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs md:text-sm text-muted-foreground">Total Bookings</p>
                <p className="text-2xl md:text-3xl font-bold mt-1">-</p>
              </div>
              <div className="h-12 w-12 bg-green-100 rounded-full flex items-center justify-center">
                <Briefcase className="h-6 w-6 text-green-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Sitter Approvals */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Pending Sitter Approvals</CardTitle>
            <CardDescription>
              Review and approve new sitter applications
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loadingSitters ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
              </div>
            ) : pendingSitters.length > 0 ? (
              <div className="space-y-4">
                {pendingSitters.slice(0, 5).map((sitter: any) => (
                  <div key={sitter.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center">
                      <Avatar className="h-10 w-10 mr-4">
                        <AvatarImage src={sitter.photoUrl} alt={`${sitter.firstName} ${sitter.lastName}`} />
                        <AvatarFallback>
                          {sitter.firstName?.[0]}{sitter.lastName?.[0]}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium">{sitter.firstName} {sitter.lastName ? sitter.lastName.charAt(0) + '.' : ''}</p>
                        <p className="text-sm text-muted-foreground">
                          {sitter.age ? `${sitter.age} years old • ` : ''}${parseFloat(sitter.hourlyRate).toFixed(2)}/hr
                        </p>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      onClick={() => navigate(`/profile/${sitter.userId}`)}
                    >
                      Review
                    </Button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No pending sitter applications.</p>
              </div>
            )}
          </CardContent>
          {pendingSitters.length > 0 && (
            <CardFooter className="border-t bg-muted/50 px-6">
              <Button 
                variant="ghost" 
                className="ml-auto"
                onClick={() => navigate('/admin/sitter-approvals')}
              >
                View All Applications
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardFooter>
          )}
        </Card>

        {/* Concierge Requests */}
        <Card>
          <CardHeader>
            <CardTitle>Concierge Requests</CardTitle>
            <CardDescription>
              Help parents find suitable sitters
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loadingRequests ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
              </div>
            ) : conciergeRequests && conciergeRequests.length > 0 ? (
              <div className="space-y-4">
                {conciergeRequests.slice(0, 3).map((request: any) => (
                  <div key={request.id} className="p-4 border rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <div className="font-medium">
                        {request.parent?.firstName} {request.parent?.lastName}
                      </div>
                      <Badge variant="secondary">Concierge</Badge>
                    </div>
                    <div className="text-sm text-muted-foreground mb-3">
                      <div className="flex items-center">
                        <Clock className="h-4 w-4 mr-1" />
                        <span>
                          {new Date(request.startTime).toLocaleDateString()} at{' '}
                          {new Date(request.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    </div>
                    <Button
                      size="sm"
                      className="w-full"
                      onClick={() => navigate(`/booking/${request.id}`)}
                    >
                      Match Sitter
                    </Button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No concierge requests.</p>
              </div>
            )}
          </CardContent>
          {conciergeRequests && conciergeRequests.length > 0 && (
            <CardFooter className="border-t bg-muted/50 px-6">
              <Button 
                variant="ghost" 
                className="ml-auto"
                onClick={() => navigate('/admin/concierge-requests')}
              >
                View All Requests
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardFooter>
          )}
        </Card>
      </div>

      {/* Stripe Payment Analytics */}
      <div className="mb-8">
        <StripeAnalytics />
      </div>

      {/* Referral Program Statistics */}
      <div className="mb-8">
        <ReferralStats />
      </div>

      {/* Rebooking Analytics */}
      <div className="mb-8">
        <RebookingLeaderboard />
      </div>

      {/* Veriff Verification Notifications */}
      <div className="mb-8">
        <VeriffNotifications />
      </div>

      {/* Data Management */}
      <div className="mb-8">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Data Management
            </CardTitle>
            <CardDescription>
              Upload and manage parent and sitter data
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Button
                variant="outline"
                className="h-20 flex flex-col items-center justify-center gap-2"
                onClick={() => navigate('/admin/upload-parents')}
              >
                <Users className="h-6 w-6" />
                <span className="text-sm font-medium">Upload Parents</span>
              </Button>
              <Button
                variant="outline"
                className="h-20 flex flex-col items-center justify-center gap-2"
                onClick={() => navigate('/admin/upload-sitters')}
              >
                <UserCheck className="h-6 w-6" />
                <span className="text-sm font-medium">Upload Sitters</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Email Management */}
      <div className="mb-8">
        <EmailManager />
      </div>

      {/* Admin Tools Tabs */}
      <div className="mb-8">
        <Tabs defaultValue="quick-actions" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="quick-actions">Quick Actions</TabsTrigger>
            <TabsTrigger value="book-on-behalf">Book on Behalf</TabsTrigger>
          </TabsList>
          <TabsContent value="quick-actions" className="space-y-4">
            <DragDropQuickActions />
          </TabsContent>
          <TabsContent value="book-on-behalf" className="space-y-4">
            <BookOnBehalfOfParent />
          </TabsContent>
        </Tabs>
      </div>
      </main>
    </div>
  );
};

export default AdminDashboard;
