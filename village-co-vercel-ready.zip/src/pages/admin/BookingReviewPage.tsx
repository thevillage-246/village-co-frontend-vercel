import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { useAuth } from '@/contexts/AuthContext';
import { USER_ROLES } from '@shared/schema';
import AdminSidebar from '@/components/AdminSidebar';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Calendar, 
  Clock, 
  Search, 
  Filter, 
  AlertTriangle, 
  CheckCircle, 
  DollarSign,
  ArrowUp,
  ArrowDown,
  User,
  Home
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export default function BookingReviewPage() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [searchQuery, setSearchQuery] = useState('');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  const [sortField, setSortField] = useState<string>('created_at');

  // Verify admin role
  if (user?.role !== USER_ROLES.ADMIN) {
    navigate('/');
    return null;
  }

  // Fetch flagged bookings
  const { data: flaggedBookings, isLoading } = useQuery({
    queryKey: ['/api/admin/flagged-bookings'],
    queryFn: async () => {
      const response = await fetch('/api/admin/flagged-bookings', {
        credentials: 'include'
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch flagged bookings');
      }
      
      return response.json();
    }
  });

  // Handle sorting
  const toggleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('desc');
    }
  };

  // Filter and sort bookings
  const filteredBookings = flaggedBookings
    ? flaggedBookings.filter((booking: any) => {
        if (!searchQuery) return true;
        
        const searchLower = searchQuery.toLowerCase();
        return (
          booking.parent_name?.toLowerCase().includes(searchLower) ||
          booking.sitter_name?.toLowerCase().includes(searchLower) ||
          booking.review_reason?.toLowerCase().includes(searchLower) ||
          booking.address?.toLowerCase().includes(searchLower)
        );
      })
    : [];

  const sortedBookings = [...filteredBookings].sort((a, b) => {
    let valA, valB;
    
    switch (sortField) {
      case 'additionalFees':
        valA = a.additional_fees || 0;
        valB = b.additional_fees || 0;
        break;
      case 'parent_name':
        valA = a.parent_name || '';
        valB = b.parent_name || '';
        break;
      case 'sitter_name': 
        valA = a.sitter_name || '';
        valB = b.sitter_name || '';
        break;
      case 'start_time':
        valA = new Date(a.start_time || 0).getTime();
        valB = new Date(b.start_time || 0).getTime();
        break;
      default: // created_at
        valA = new Date(a.created_at || 0).getTime();
        valB = new Date(b.created_at || 0).getTime();
    }
    
    if (typeof valA === 'string' && typeof valB === 'string') {
      return sortDirection === 'asc'
        ? valA.localeCompare(valB)
        : valB.localeCompare(valA);
    } else {
      return sortDirection === 'asc'
        ? Number(valA) - Number(valB)
        : Number(valB) - Number(valA);
    }
  });

  // Render sort arrow for a column
  const getSortArrow = (field: string) => {
    if (sortField !== field) return null;
    return sortDirection === 'asc' ? <ArrowUp className="h-4 w-4 ml-1" /> : <ArrowDown className="h-4 w-4 ml-1" />;
  };

  // Format price with NZD
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-NZ', {
      style: 'currency',
      currency: 'NZD',
    }).format(price);
  };

  return (
    <div className="flex min-h-screen">
      <AdminSidebar />
      <main className="flex-1 p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold">Bookings Flagged for Review</h1>
          <p className="text-gray-500 mt-1">
            Review bookings that need attention due to special requests or circumstances
          </p>
        </div>

        {/* Search and Filter */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <Input
              placeholder="Search by parent, sitter, or keywords..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div className="flex gap-2">
            <Button variant="outline" className="flex items-center gap-1">
              <Filter className="h-4 w-4" />
              <span>Filter</span>
            </Button>
            <Button variant="outline" className="flex items-center gap-1">
              <Calendar className="h-4 w-4" />
              <span>Date Range</span>
            </Button>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Flagged Bookings</CardTitle>
            <CardDescription>
              {filteredBookings.length} booking{filteredBookings.length !== 1 ? 's' : ''} need{filteredBookings.length === 1 ? 's' : ''} review
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
              </div>
            ) : sortedBookings.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full border-collapse">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4">
                        <button 
                          className="flex items-center font-semibold hover:text-primary"
                          onClick={() => toggleSort('created_at')}
                        >
                          Date
                          {getSortArrow('created_at')}
                        </button>
                      </th>
                      <th className="text-left py-3 px-4">
                        <button 
                          className="flex items-center font-semibold hover:text-primary"
                          onClick={() => toggleSort('parent_name')}
                        >
                          Parent
                          {getSortArrow('parent_name')}
                        </button>
                      </th>
                      <th className="text-left py-3 px-4">
                        <button 
                          className="flex items-center font-semibold hover:text-primary"
                          onClick={() => toggleSort('sitter_name')}
                        >
                          Sitter
                          {getSortArrow('sitter_name')}
                        </button>
                      </th>
                      <th className="text-left py-3 px-4">
                        <button 
                          className="flex items-center font-semibold hover:text-primary"
                          onClick={() => toggleSort('start_time')}
                        >
                          Booking Time
                          {getSortArrow('start_time')}
                        </button>
                      </th>
                      <th className="text-left py-3 px-4">
                        <button 
                          className="flex items-center font-semibold hover:text-primary"
                          onClick={() => toggleSort('additionalFees')}
                        >
                          Additional Fees
                          {getSortArrow('additionalFees')}
                        </button>
                      </th>
                      <th className="text-left py-3 px-4">Review Reason</th>
                      <th className="text-left py-3 px-4">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {sortedBookings.map((booking: any) => (
                      <tr key={booking.id} className="border-b hover:bg-muted/50">
                        <td className="py-3 px-4">
                          {formatDistanceToNow(new Date(booking.created_at), { addSuffix: true })}
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center">
                            <User className="h-4 w-4 mr-2 text-gray-500" />
                            <span>{booking.parent_name}</span>
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center">
                            <User className="h-4 w-4 mr-2 text-gray-500" />
                            <span>{booking.sitter_name}</span>
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex flex-col">
                            <div className="flex items-center text-sm">
                              <Calendar className="h-4 w-4 mr-1 text-gray-500" />
                              <span>{new Date(booking.start_time).toLocaleDateString()}</span>
                            </div>
                            <div className="flex items-center text-sm text-gray-500">
                              <Clock className="h-4 w-4 mr-1" />
                              <span>
                                {new Date(booking.start_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                {' - '}
                                {new Date(booking.end_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </div>
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center">
                            <DollarSign className="h-4 w-4 mr-1 text-green-600" />
                            <span className="font-medium text-green-600">
                              {formatPrice(booking.additional_fees || 0)}
                            </span>
                          </div>
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-start gap-1.5">
                            <AlertTriangle className="h-4 w-4 text-amber-500 mt-0.5 flex-shrink-0" />
                            <span className="text-sm">
                              {booking.review_reason || "Needs manual review"}
                            </span>
                          </div>
                          {booking.fee_breakdown && booking.fee_breakdown.length > 0 && (
                            <div className="mt-2 flex flex-wrap gap-1">
                              {booking.fee_breakdown.map((fee: any, index: number) => (
                                <Badge key={index} variant="outline" className="text-xs">
                                  {fee.reason}: {formatPrice(fee.amount)}
                                </Badge>
                              ))}
                            </div>
                          )}
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline" onClick={() => navigate(`/booking/${booking.id}`)}>
                              View
                            </Button>
                            <Button 
                              size="sm" 
                              variant="default" 
                              className="bg-green-600 hover:bg-green-700"
                              onClick={() => {
                                // Here you would call an API to approve the booking with fees
                                console.log(`Approving booking ${booking.id}`);
                              }}
                            >
                              <CheckCircle className="h-4 w-4 mr-1" />
                              Approve
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-8">
                <AlertTriangle className="mx-auto h-12 w-12 text-muted-foreground" />
                <h3 className="mt-4 text-lg font-medium">No Flagged Bookings</h3>
                <p className="mt-2 text-muted-foreground">
                  There are currently no bookings that require review.
                </p>
              </div>
            )}
          </CardContent>
          {sortedBookings.length > 0 && (
            <CardFooter className="flex justify-between border-t py-4">
              <div className="text-sm text-muted-foreground">
                Showing {sortedBookings.length} of {flaggedBookings?.length || 0} bookings
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" disabled>
                  Previous
                </Button>
                <Button variant="outline" size="sm" disabled>
                  Next
                </Button>
              </div>
            </CardFooter>
          )}
        </Card>
      </main>
    </div>
  );
}