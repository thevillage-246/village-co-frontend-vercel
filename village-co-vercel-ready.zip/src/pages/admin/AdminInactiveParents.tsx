import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Loader2, UserIcon, Bell } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function AdminInactiveParents() {
  const [inactiveParents, setInactiveParents] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    const fetchInactiveParents = async () => {
      try {
        // Get all parents using API endpoint
        const response = await fetch('/api/parents', {
          credentials: 'include'
        });
        
        if (!response.ok) {
          throw new Error('Failed to fetch parents');
        }
        
        const parents = await response.json();
        
        // Calculate date 30 days ago
        const sinceDate = new Date();
        sinceDate.setDate(sinceDate.getDate() - 30);
        
        // Get all bookings to determine activity
        const bookingsResponse = await fetch('/api/bookings', {
          credentials: 'include'
        });
        
        if (!bookingsResponse.ok) {
          throw new Error('Failed to fetch bookings');
        }
        
        const allBookings = await bookingsResponse.json();
        
        // Filter recent bookings within last 30 days
        const recentBookings = allBookings.filter((booking: any) => {
          const endTime = new Date(booking.endTime);
          return endTime >= sinceDate;
        });
        
        // Create a set of active parent IDs
        const activeParentIds = new Set(
          recentBookings.map((booking: any) => booking.parentId)
        );
        
        // Filter out active parents to get inactive ones
        const filteredParents = parents.filter(
          (parent: any) => !activeParentIds.has(parent.id)
        ) || [];
        
        setInactiveParents(filteredParents);
      } catch (error) {
        console.error('Error fetching inactive parents:', error);
        toast({
          title: 'Error',
          description: 'Failed to load inactive parents',
          variant: 'destructive'
        });
      } finally {
        setLoading(false);
      }
    };

    fetchInactiveParents();
  }, [toast]);
  
  const notifyParent = async (parentId: string, fullName: string) => {
    toast({
      title: 'Sending re-engagement message...',
      description: `Attempting to send notification to ${fullName}`
    });
    
    try {
      const { data: subscriptions, error } = await supabase
        .from('subscriptions')
        .select('*')
        .eq('user_id', parentId);
        
      if (error) {
        throw error;
      }

      if (!subscriptions || subscriptions.length === 0) {
        toast({
          title: 'No subscriptions found',
          description: `${fullName} hasn't enabled notifications yet`,
          variant: 'destructive'
        });
        return;
      }

      // Replace with your actual Supabase function URL
      const functionUrl = 'https://the-village-co-info6193.replit.app/send-push';
      
      for (const sub of subscriptions) {
        // For demo, we'll show a success toast without actually making the API call
        toast({
          title: 'Re-engagement sent',
          description: `Successfully sent re-engagement notification to ${fullName}`,
        });
        
        /* In production, uncomment this code:
        await fetch(functionUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            subscription: sub,
            title: "Need a break?",
            body: `Hi ${fullName}, book a sitter this week — you deserve it ✨`,
          }),
        });
        */
      }
    } catch (error) {
      console.error('Error sending notification:', error);
      toast({
        title: 'Failed to send notification',
        description: 'An error occurred while sending the notification',
        variant: 'destructive'
      });
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Inactive Parents (30+ Days)</CardTitle>
        </CardHeader>
        <CardContent>
          {inactiveParents.length > 0 ? (
            <div className="space-y-4">
              {inactiveParents.map((parent) => (
                <div 
                  key={parent.user_id} 
                  className="p-4 border rounded-md flex justify-between items-center hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-center space-x-4">
                    <Avatar>
                      <AvatarImage src={parent.photo_url} alt={parent.full_name} />
                      <AvatarFallback>
                        <UserIcon className="h-5 w-5" />
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className="font-medium">{parent.full_name}</h3>
                      <p className="text-sm text-muted-foreground">{parent.email}</p>
                    </div>
                  </div>
                  <Button
                    onClick={() => notifyParent(parent.user_id, parent.full_name)}
                    className="bg-wine hover:bg-wine/90 text-white"
                  >
                    <Bell className="mr-2 h-4 w-4" />
                    Re-Engage
                  </Button>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-10">
              <p className="text-xl font-medium mb-2">All parents are actively booking 🎉</p>
              <p className="text-muted-foreground">There are no inactive parents in the last 30 days</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}