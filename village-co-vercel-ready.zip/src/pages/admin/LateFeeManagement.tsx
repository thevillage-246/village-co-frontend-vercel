import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { formatDistance, format } from "date-fns";

interface Booking {
  id: number;
  parentId: number;
  sitterId: number;
  status: string;
  startTime: string;
  endTime: string;
  completedAt: string | null;
  totalAmount: string;
  platformFee: string;
  lateFeeApplied: boolean;
  lateFeeAmount: string | null;
  lateFeeReason: string | null;
  lateFeeOverriddenBy: number | null;
  parent?: {
    id: number;
    firstName: string;
    lastName: string;
  };
  sitter?: {
    id: number;
    firstName: string;
    lastName: string;
  };
}

export default function LateFeeManagement() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedBooking, setSelectedBooking] = useState<Booking | null>(null);
  const [overrideDialogOpen, setOverrideDialogOpen] = useState(false);
  
  // Fetch bookings with late fees
  const { data: bookings, isLoading } = useQuery({
    queryKey: ['/api/admin/bookings/late-fees'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });
  
  // Override late fee mutation
  const overrideLateFee = useMutation({
    mutationFn: async (bookingId: number) => {
      const response = await apiRequest("POST", `/api/bookings/${bookingId}/override-late-fee`, { adminId: 1 });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/bookings/late-fees'] });
      toast({
        title: "Late fee overridden",
        description: "The late fee has been removed from the booking successfully.",
      });
      setOverrideDialogOpen(false);
    },
    onError: (error) => {
      toast({
        title: "Error overriding late fee",
        description: `Failed to override late fee: ${error.toString()}`,
        variant: "destructive",
      });
    }
  });
  
  // Handle opening override dialog
  const handleOverrideClick = (booking: Booking) => {
    setSelectedBooking(booking);
    setOverrideDialogOpen(true);
  };
  
  // Handle confirming override
  const handleConfirmOverride = () => {
    if (selectedBooking) {
      overrideLateFee.mutate(selectedBooking.id);
    }
  };
  
  // Format date for display
  const formatDate = (dateString: string) => {
    return format(new Date(dateString), "MMM dd, yyyy h:mm a");
  };

  if (isLoading) {
    return (
      <div className="container mx-auto py-10">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-10">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Late Fee Management</h1>
        <p className="text-muted-foreground mt-2">
          Review and manage late fees applied to bookings
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Bookings with Late Fees</CardTitle>
          <CardDescription>
            Parents who were late for pickup and incurred fees
          </CardDescription>
        </CardHeader>
        <CardContent>
          {bookings && bookings.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Booking ID</TableHead>
                  <TableHead>Parent</TableHead>
                  <TableHead>Sitter</TableHead>
                  <TableHead>Booking End</TableHead>
                  <TableHead>Pickup Time</TableHead>
                  <TableHead>Fee Amount</TableHead>
                  <TableHead>Reason</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {bookings.map((booking: Booking) => (
                  <TableRow key={booking.id}>
                    <TableCell className="font-medium">#{booking.id}</TableCell>
                    <TableCell>
                      {booking.parent ? `${booking.parent.firstName} ${booking.parent.lastName}` : "Unknown"}
                    </TableCell>
                    <TableCell>
                      {booking.sitter ? `${booking.sitter.firstName} ${booking.sitter.lastName}` : "Unknown"}
                    </TableCell>
                    <TableCell>{formatDate(booking.endTime)}</TableCell>
                    <TableCell>
                      {booking.completedAt ? formatDate(booking.completedAt) : "Not completed"}
                      {booking.completedAt && (
                        <Badge variant="outline" className="ml-2">
                          {formatDistance(new Date(booking.completedAt), new Date(booking.endTime), { addSuffix: true })}
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell>${booking.lateFeeAmount}</TableCell>
                    <TableCell>
                      <span className="text-sm text-muted-foreground">{booking.lateFeeReason}</span>
                    </TableCell>
                    <TableCell>
                      {!booking.lateFeeOverriddenBy && (
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleOverrideClick(booking)}
                        >
                          Override Fee
                        </Button>
                      )}
                      {booking.lateFeeOverriddenBy && (
                        <Badge variant="outline">Fee Overridden</Badge>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-10">
              <p className="text-muted-foreground">No bookings with late fees found</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Override confirmation dialog */}
      <Dialog open={overrideDialogOpen} onOpenChange={setOverrideDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Late Fee Override</DialogTitle>
            <DialogDescription>
              Are you sure you want to override the late fee for this booking? This will remove the fee amount from the parent's total.
            </DialogDescription>
          </DialogHeader>

          {selectedBooking && (
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Booking ID</Label>
                  <p>#{selectedBooking.id}</p>
                </div>
                <div>
                  <Label>Parent</Label>
                  <p>{selectedBooking.parent ? `${selectedBooking.parent.firstName} ${selectedBooking.parent.lastName}` : "Unknown"}</p>
                </div>
              </div>
              <div>
                <Label>Current Fee Amount</Label>
                <p className="font-semibold">${selectedBooking.lateFeeAmount}</p>
              </div>
              <div>
                <Label>Reason for Fee</Label>
                <p>{selectedBooking.lateFeeReason}</p>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setOverrideDialogOpen(false)}>Cancel</Button>
            <Button 
              onClick={handleConfirmOverride}
              disabled={overrideLateFee.isPending}
            >
              {overrideLateFee.isPending ? "Processing..." : "Confirm Override"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}