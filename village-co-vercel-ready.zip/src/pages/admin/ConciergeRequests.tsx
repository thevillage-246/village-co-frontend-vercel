import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient } from '@/lib/queryClient';
import { useLocation } from 'wouter';
import { format, parseISO } from 'date-fns';
import { apiRequest } from '@/lib/queryClient';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { 
  Calendar, 
  Clock, 
  Users, 
  MessageSquare, 
  AlertCircle, 
  Loader2, 
  CheckCircle, 
  ArrowLeftCircle
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { BOOKING_STATUS } from '@shared/schema';

const ConciergeRequests: React.FC = () => {
  const [, navigate] = useLocation();
  const [selectedSitters, setSelectedSitters] = useState<Record<number, number>>({});

  const { data: requests, isLoading: loadingRequests } = useQuery({
    queryKey: ['/api/admin/concierge-requests'],
  });

  const { data: sitters, isLoading: loadingSitters } = useQuery({
    queryKey: ['/api/sitters?approved=true'],
  });

  const assignMutation = useMutation({
    mutationFn: async ({ bookingId, sitterId }: { bookingId: number, sitterId: number }) => {
      await apiRequest('PATCH', `/api/bookings/${bookingId}`, { 
        sitterId,
        status: BOOKING_STATUS.ACCEPTED 
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/concierge-requests'] });
    },
  });

  if (loadingRequests || loadingSitters) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // Format booking time
  const formatBookingTime = (booking: any) => {
    const start = parseISO(booking.startTime);
    const end = parseISO(booking.endTime);
    const date = format(start, 'EEEE, MMMM d, yyyy');
    const timeRange = `${format(start, 'h:mm a')} - ${format(end, 'h:mm a')}`;
    
    return { date, timeRange };
  };

  const handleAssign = (bookingId: number) => {
    const sitterId = selectedSitters[bookingId];
    if (!sitterId) return;
    
    assignMutation.mutate({ bookingId, sitterId });
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold">Concierge Requests</h1>
            <p className="text-gray-500 mt-1">Match parents with the right sitters</p>
          </div>
          <Button 
            onClick={() => navigate('/admin')}
            variant="outline" 
            className="mt-4 sm:mt-0 flex items-center"
          >
            <ArrowLeftCircle className="mr-2 h-4 w-4" />
            Back to Dashboard
          </Button>
        </div>
      </div>

      {requests && requests.length > 0 ? (
        <div className="space-y-6">
          {requests.map((request: any) => {
            const { date, timeRange } = formatBookingTime(request);
            
            return (
              <Card key={request.id} className="overflow-hidden">
                <CardHeader className="bg-muted pb-4">
                  <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
                    <div>
                      <CardTitle>Request from {request.parent?.firstName} {request.parent?.lastName}</CardTitle>
                      <CardDescription>Submitted {format(parseISO(request.createdAt), 'MMM d, yyyy')}</CardDescription>
                    </div>
                    <Badge className="sm:ml-auto bg-orange-500 hover:bg-orange-600">Concierge Request</Badge>
                  </div>
                </CardHeader>
                
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-2 text-muted-foreground" />
                        <span>{date}</span>
                      </div>
                      
                      <div className="flex items-center">
                        <Clock className="h-4 w-4 mr-2 text-muted-foreground" />
                        <span>{timeRange}</span>
                      </div>
                      
                      <div className="flex items-center">
                        <Users className="h-4 w-4 mr-2 text-muted-foreground" />
                        <span>{request.childCount || '1'} {request.childCount === 1 ? 'child' : 'children'}</span>
                      </div>
                      
                      {request.specialRequests && (
                        <div className="flex items-start">
                          <MessageSquare className="h-4 w-4 mr-2 text-muted-foreground mt-1" />
                          <span className="text-sm">{request.specialRequests}</span>
                        </div>
                      )}
                    </div>
                    
                    <div className="space-y-4">
                      <h3 className="font-medium">Assign a Sitter</h3>
                      {sitters && sitters.length > 0 ? (
                        <>
                          <Select 
                            onValueChange={(value) => setSelectedSitters({
                              ...selectedSitters,
                              [request.id]: parseInt(value)
                            })}
                            value={selectedSitters[request.id]?.toString()}
                          >
                            <SelectTrigger className="w-full">
                              <SelectValue placeholder="Select a sitter..." />
                            </SelectTrigger>
                            <SelectContent>
                              {sitters.map((sitter: any) => (
                                <SelectItem key={sitter.id} value={sitter.id.toString()}>
                                  {sitter.firstName} {sitter.lastName} - ${parseFloat(sitter.hourlyRate).toFixed(2)}/hr
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          
                          <Button 
                            className="w-full" 
                            disabled={!selectedSitters[request.id] || assignMutation.isPending}
                            onClick={() => handleAssign(request.id)}
                          >
                            {assignMutation.isPending && assignMutation.variables?.bookingId === request.id ? (
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            ) : (
                              <CheckCircle className="mr-2 h-4 w-4" />
                            )}
                            Assign and Confirm
                          </Button>
                        </>
                      ) : (
                        <div className="flex items-center text-amber-500">
                          <AlertCircle className="h-4 w-4 mr-2" />
                          <span>No approved sitters available</span>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16">
            <CheckCircle className="h-12 w-12 text-green-500 mb-4" />
            <h3 className="text-lg font-medium mb-2">No Pending Concierge Requests</h3>
            <p className="text-muted-foreground text-center max-w-md">
              There are no concierge booking requests that need your attention right now.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default ConciergeRequests;