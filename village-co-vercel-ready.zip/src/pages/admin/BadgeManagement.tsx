import React, { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, apiRequest } from '@/lib/queryClient';
import { User, BADGE_TYPES, BADGE_DESCRIPTIONS } from '@/lib/types';
import { BadgeDisplay } from '@/components/badges/BadgeDisplay';
import { DataTable } from '@/components/ui/data-table';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { 
  RefreshCcw, 
  Medal, 
  Award, 
  Users,
  CheckCircle,
  XCircle
} from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useToast } from '@/hooks/use-toast';
import { ColumnDef } from '@tanstack/react-table';

const BadgeManagement = () => {
  const { toast } = useToast();
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [selectedBadgeType, setSelectedBadgeType] = useState<'badge' | 'referralBadge'>('badge');
  const [selectedBadgeValue, setSelectedBadgeValue] = useState<string | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  // Fetch all users
  const { data: users = [], isLoading, isError } = useQuery<User[]>({
    queryKey: ['/api/admin/users'],
  });

  // Mutation to update a user's badge
  const updateBadgeMutation = useMutation({
    mutationFn: async ({ userId, badgeType, value }: { userId: number, badgeType: string, value: string | null }) => {
      return apiRequest('PATCH', `/api/admin/users/${userId}/badge`, { badgeType, value });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/users'] });
      toast({
        title: 'Badge updated successfully',
        description: 'The user badge has been updated.',
        variant: 'default',
      });
      setDialogOpen(false);
    },
    onError: (error) => {
      console.error('Error updating badge:', error);
      toast({
        title: 'Failed to update badge',
        description: 'There was an error updating the badge. Please try again.',
        variant: 'destructive',
      });
    },
  });

  // Mutation to run the badge update process
  const runBadgeUpdatesMutation = useMutation({
    mutationFn: async () => {
      return apiRequest('POST', '/api/admin/run-badge-updates', {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/users'] });
      toast({
        title: 'Badge update process completed',
        description: 'All badges have been recalculated and updated.',
        variant: 'default',
      });
    },
    onError: (error) => {
      console.error('Error running badge updates:', error);
      toast({
        title: 'Failed to run badge updates',
        description: 'There was an error running the badge update process. Please try again.',
        variant: 'destructive',
      });
    },
  });

  // Open badge edit dialog
  const handleOpenBadgeDialog = (user: User, badgeType: 'badge' | 'referralBadge') => {
    setSelectedUser(user);
    setSelectedBadgeType(badgeType);
    setSelectedBadgeValue(user[badgeType] || null);
    setDialogOpen(true);
  };

  // Submit badge update
  const handleSubmitBadgeUpdate = () => {
    if (!selectedUser) return;
    
    updateBadgeMutation.mutate({
      userId: selectedUser.id,
      badgeType: selectedBadgeType,
      value: selectedBadgeValue,
    });
  };

  // Handle running the badge updates
  const handleRunBadgeUpdates = () => {
    runBadgeUpdatesMutation.mutate();
  };

  // Table columns definition
  const columns: ColumnDef<User>[] = [
    {
      accessorKey: 'id',
      header: 'ID',
    },
    {
      accessorKey: 'fullName',
      header: 'Name',
      cell: ({ row }) => (
        <div>
          {row.original.firstName} {row.original.lastName}
        </div>
      ),
    },
    {
      accessorKey: 'email',
      header: 'Email',
    },
    {
      accessorKey: 'role',
      header: 'Role',
      cell: ({ row }) => (
        <div className="capitalize">{row.original.role}</div>
      ),
    },
    {
      accessorKey: 'badge',
      header: 'Sitter Badge',
      cell: ({ row }) => (
        <div className="flex items-center gap-2">
          {row.original.badge ? (
            <BadgeDisplay badgeType="badge" value={row.original.badge} />
          ) : (
            <span className="text-muted-foreground text-sm">None</span>
          )}
          {row.original.role === 'sitter' && (
            <Button 
              variant="ghost" 
              size="sm" 
              className="h-8 ml-2"
              onClick={() => handleOpenBadgeDialog(row.original, 'badge')}
            >
              Edit
            </Button>
          )}
        </div>
      ),
    },
    {
      accessorKey: 'referralBadge',
      header: 'Referral Badge',
      cell: ({ row }) => (
        <div className="flex items-center gap-2">
          {row.original.referralBadge ? (
            <BadgeDisplay badgeType="referralBadge" value={row.original.referralBadge} />
          ) : (
            <span className="text-muted-foreground text-sm">None</span>
          )}
          <Button 
            variant="ghost" 
            size="sm" 
            className="h-8 ml-2"
            onClick={() => handleOpenBadgeDialog(row.original, 'referralBadge')}
          >
            Edit
          </Button>
        </div>
      ),
    },
  ];

  if (isLoading) {
    return <div className="flex items-center justify-center h-screen">Loading...</div>;
  }

  if (isError) {
    return (
      <Alert variant="destructive">
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>
          Failed to load users. Please try refreshing the page.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="container mx-auto py-10">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Badge Management</h1>
          <p className="text-muted-foreground mt-2">
            Manage user badges and trigger badge update processes
          </p>
        </div>
        <Button 
          onClick={handleRunBadgeUpdates} 
          className="flex items-center gap-2" 
          disabled={runBadgeUpdatesMutation.isPending}
        >
          <RefreshCcw className="h-4 w-4" />
          {runBadgeUpdatesMutation.isPending ? 'Updating...' : 'Update All Badges'}
        </Button>
      </div>

      <div className="flex flex-col gap-4 mb-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-blue-50 border border-blue-100 rounded-lg p-4 flex items-center gap-3">
            <Award className="h-10 w-10 text-blue-500" />
            <div>
              <h2 className="font-semibold text-blue-800">Sitter Badges</h2>
              <p className="text-sm text-blue-600">Recognition for sitter performance</p>
            </div>
          </div>
          <div className="bg-amber-50 border border-amber-100 rounded-lg p-4 flex items-center gap-3">
            <Medal className="h-10 w-10 text-amber-500" />
            <div>
              <h2 className="font-semibold text-amber-800">Referral Badges</h2>
              <p className="text-sm text-amber-600">Based on successful referrals</p>
            </div>
          </div>
          <div className="bg-green-50 border border-green-100 rounded-lg p-4 flex items-center gap-3">
            <Users className="h-10 w-10 text-green-500" />
            <div>
              <h2 className="font-semibold text-green-800">Automatic Updates</h2>
              <p className="text-sm text-green-600">Badges update based on activity</p>
            </div>
          </div>
        </div>
      </div>

      <DataTable 
        columns={columns} 
        data={users} 
        searchKey="email"
        searchPlaceholder="Search users by email..."
      />

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit User Badge</DialogTitle>
            <DialogDescription>
              {selectedBadgeType === 'badge' 
                ? "Update this user's sitter badge." 
                : "Update this user's referral badge."}
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid gap-4 py-4">
            <div className="flex items-center gap-4">
              <span className="text-sm font-medium">User:</span>
              <span>
                {selectedUser?.firstName} {selectedUser?.lastName} ({selectedUser?.email})
              </span>
            </div>
            
            <div className="flex items-center gap-4">
              <span className="text-sm font-medium">Badge Type:</span>
              <span className="capitalize">{selectedBadgeType === 'badge' ? 'Sitter Badge' : 'Referral Badge'}</span>
            </div>
            
            <div className="flex flex-col gap-2">
              <span className="text-sm font-medium">Badge Value:</span>
              <Select 
                value={selectedBadgeValue || "none"} 
                onValueChange={(value) => setSelectedBadgeValue(value === "none" ? null : value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a badge" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  {selectedBadgeType === 'badge'
                    ? BADGE_TYPES.SITTER_BADGES.map((badge) => (
                        <SelectItem key={badge} value={badge}>
                          {badge}
                        </SelectItem>
                      ))
                    : BADGE_TYPES.REFERRAL_BADGES.map((badge) => (
                        <SelectItem key={badge} value={badge}>
                          {badge}
                        </SelectItem>
                      ))
                  }
                </SelectContent>
              </Select>
              
              {selectedBadgeValue && (
                <p className="text-xs text-muted-foreground mt-1">
                  {Object.prototype.hasOwnProperty.call(BADGE_DESCRIPTIONS, selectedBadgeValue) 
                    ? BADGE_DESCRIPTIONS[selectedBadgeValue as keyof typeof BADGE_DESCRIPTIONS]
                    : 'Badge description'}
                </p>
              )}
            </div>
          </div>
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleSubmitBadgeUpdate} 
              disabled={updateBadgeMutation.isPending}
              className="flex items-center gap-2"
            >
              {updateBadgeMutation.isPending ? (
                <>
                  <div className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
                  Updating...
                </>
              ) : (
                <>
                  <CheckCircle className="h-4 w-4" />
                  Update Badge
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default BadgeManagement;