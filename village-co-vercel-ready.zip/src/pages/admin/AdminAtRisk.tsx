import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Loader2, UserIcon, Bell } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';

export default function AdminAtRisk() {
  const [atRiskUsers, setAtRiskUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    const loadData = async () => {
      try {
        const sinceDate = new Date();
        sinceDate.setDate(sinceDate.getDate() - 30);

        // Get all users using API endpoints
        const [usersResponse, bookingsResponse, reviewsResponse] = await Promise.all([
          fetch('/api/users', { credentials: 'include' }),
          fetch('/api/bookings', { credentials: 'include' }),
          fetch('/api/reviews', { credentials: 'include' })
        ]);

        if (!usersResponse.ok || !bookingsResponse.ok || !reviewsResponse.ok) {
          throw new Error('Failed to fetch data');
        }

        const users = await usersResponse.json();
        const allBookings = await bookingsResponse.json();
        const reviews = await reviewsResponse.json();

        // Filter recent bookings within last 30 days
        const recentBookings = allBookings.filter((booking: any) => {
          const endTime = new Date(booking.endTime);
          return endTime >= sinceDate;
        });

        // Create a set of active user IDs (users with recent bookings)
        const activeUserIds = new Set([
          ...recentBookings.map((b: any) => b.sitterId),
          ...recentBookings.map((b: any) => b.parentId)
        ].filter(Boolean)); // Filter out any undefined IDs

        // Create a set of users who have left or received reviews
        const reviewedUserIds = new Set();

        for (const booking of recentBookings) {
          const hasReview = reviews.some((r: any) => r.bookingId === booking.id);
          if (hasReview) {
            if (booking.parentId) reviewedUserIds.add(booking.parentId);
            if (booking.sitterId) reviewedUserIds.add(booking.sitterId);
          }
        }

        // Filter for at-risk users (not active and not reviewed)
        const atRisk = users.filter((user: any) =>
          !activeUserIds.has(user.id) &&
          !reviewedUserIds.has(user.id)
        ) || [];

        setAtRiskUsers(atRisk);
      } catch (error) {
        console.error('Error loading at-risk users:', error);
        toast({
          title: 'Error',
          description: 'Failed to load at-risk users',
          variant: 'destructive'
        });
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, [toast]);
  
  const notifyUser = async (userId: string, fullName: string, role: string) => {
    toast({
      title: 'Sending re-engagement message...',
      description: `Attempting to send notification to ${fullName}`
    });
    
    try {
      const { data: subscriptions, error } = await supabase
        .from('subscriptions')
        .select('*')
        .eq('user_id', userId);
        
      if (error) {
        throw error;
      }

      if (!subscriptions || subscriptions.length === 0) {
        toast({
          title: 'No subscriptions found',
          description: `${fullName} hasn't enabled notifications yet`,
          variant: 'destructive'
        });
        return;
      }

      // Create appropriate message based on user role
      const message = role === 'sitter' 
        ? `Hi ${fullName}, we miss you! Log in and reconnect with a family 💛`
        : `Hi ${fullName}, time for a break? Book a sitter and breathe again ✨`;

      // Replace with your actual Supabase function URL
      const functionUrl = 'https://the-village-co-info6193.replit.app/send-push';
      
      for (const sub of subscriptions) {
        // For demo, we'll show a success toast without actually making the API call
        toast({
          title: 'Re-engagement sent',
          description: `Successfully sent re-engagement notification to ${fullName}`,
        });
        
        /* In production, uncomment this code:
        await fetch(functionUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            subscription: sub,
            title: "Let's get you back on track 💬",
            body: message,
          }),
        });
        */
      }
    } catch (error) {
      console.error('Error sending notification:', error);
      toast({
        title: 'Failed to send notification',
        description: 'An error occurred while sending the notification',
        variant: 'destructive'
      });
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">At-Risk Users</CardTitle>
          <p className="text-sm text-muted-foreground">Users with no recent bookings or reviews in the last 30 days</p>
        </CardHeader>
        <CardContent>
          {atRiskUsers.length > 0 ? (
            <div className="space-y-4">
              {atRiskUsers.map((user) => (
                <div 
                  key={user.user_id} 
                  className="p-4 border rounded-md flex justify-between items-center hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-center space-x-4">
                    <Avatar>
                      <AvatarImage src={user.photo_url} alt={user.full_name} />
                      <AvatarFallback>
                        <UserIcon className="h-5 w-5" />
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="flex items-center space-x-2">
                        <h3 className="font-medium">{user.full_name}</h3>
                        <Badge variant="outline" className="capitalize">{user.role}</Badge>
                        {user.badge && (
                          <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100">
                            {user.badge}
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">{user.email}</p>
                    </div>
                  </div>
                  <Button
                    onClick={() => notifyUser(user.user_id, user.full_name, user.role)}
                    className="bg-rose hover:bg-rose/90 text-white"
                  >
                    <Bell className="mr-2 h-4 w-4" />
                    Reconnect
                  </Button>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-10">
              <p className="text-xl font-medium mb-2">All users are active or recently engaged 🙌</p>
              <p className="text-muted-foreground">There are no at-risk users at the moment</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}