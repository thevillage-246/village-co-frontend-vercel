import { useEffect, useState, useMemo } from 'react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Loader2, UserIcon, Bell, ArrowUpDown } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { SearchAndFilterBar, SearchAndFilterState } from '@/components/admin/SearchAndFilterBar';
import { FilterOption } from '@/components/admin/FilterControls';

export default function AdminNotify() {
  const [sitters, setSitters] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();
  
  // Search and filter state
  const [filterState, setFilterState] = useState<SearchAndFilterState>({
    searchTerm: '',
    filters: {},
    sortBy: 'name-asc'
  });
  
  // Define filter options
  const filterOptions: FilterOption[] = [
    {
      type: 'checkbox',
      key: 'badge',
      label: 'Badge',
      options: [
        { value: 'Top Sitter', label: 'Top Sitter' },
        { value: 'Verified', label: 'Verified' },
        { value: 'New', label: 'New' }
      ],
      selectedValues: (filterState.filters.badge as string[]) || []
    },
    {
      type: 'radio',
      key: 'active',
      label: 'Activity Status',
      options: [
        { value: 'active', label: 'Active' },
        { value: 'inactive', label: 'Inactive' }
      ],
      selectedValue: filterState.filters.active as string || null
    },
    {
      type: 'range',
      key: 'bookings',
      label: 'Booking Count',
      minValue: filterState.filters.bookings?.min as number || null,
      maxValue: filterState.filters.bookings?.max as number || null
    }
  ];
  
  // Define sort options
  const sortOptions = [
    { value: 'name-asc', label: 'Name A-Z' },
    { value: 'name-desc', label: 'Name Z-A' },
    { value: 'bookings-asc', label: 'Bookings (Low to High)' },
    { value: 'bookings-desc', label: 'Bookings (High to Low)' }
  ];

  useEffect(() => {
    const fetchSitters = async () => {
      try {
        // Get sitter profiles
        const { data: sitterProfiles, error } = await supabase
          .from('user_profiles')
          .select('user_id, full_name, email, photo_url, badge, role')
          .eq('role', 'sitter');
          
        if (error) {
          throw error;
        }
        
        // Get booking counts for each sitter
        const { data: bookings, error: bookingsError } = await supabase
          .from('bookings')
          .select('sitter_id');
          
        if (bookingsError) {
          throw bookingsError;
        }
        
        // Create a map of booking counts per sitter
        const bookingCounts: Record<string, number> = {};
        bookings?.forEach((booking: any) => {
          if (booking.sitter_id) {
            bookingCounts[booking.sitter_id] = (bookingCounts[booking.sitter_id] || 0) + 1;
          }
        });
        
        // Enrich sitter data with booking counts
        const enrichedSitters = sitterProfiles?.map((sitter: any) => ({
          ...sitter,
          bookingCount: bookingCounts[sitter.user_id] || 0
        })) || [];
        
        setSitters(enrichedSitters);
      } catch (error) {
        console.error('Error fetching sitters:', error);
        toast({
          title: 'Error',
          description: 'Failed to load sitters',
          variant: 'destructive'
        });
      } finally {
        setLoading(false);
      }
    };

    fetchSitters();
  }, [toast]);

  const notifySitter = async (sitterId: string, fullName: string) => {
    toast({
      title: 'Sending notification...',
      description: `Attempting to send notification to ${fullName}`
    });
    
    try {
      const { data: subscriptions, error } = await supabase
        .from('subscriptions')
        .select('*')
        .eq('user_id', sitterId);
        
      if (error) {
        throw error;
      }

      if (!subscriptions || subscriptions.length === 0) {
        toast({
          title: 'No subscriptions found',
          description: `${fullName} hasn't enabled notifications yet`,
          variant: 'destructive'
        });
        return;
      }

      // Replace with your actual Supabase project URL
      const functionUrl = 'https://the-village-co-info6193.replit.app/send-push';
      
      for (const sub of subscriptions) {
        // For demo, we'll show a success toast without actually making the API call
        toast({
          title: 'Notification sent',
          description: `Successfully sent notification to ${fullName}`,
        });
        
        /* In production, uncomment this code:
        await fetch(functionUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            subscription: sub,
            title: "New Booking Available",
            body: `Hi ${fullName}, check your dashboard for a new booking 🎉`,
          }),
        });
        */
      }
    } catch (error) {
      console.error('Error sending notification:', error);
      toast({
        title: 'Failed to send notification',
        description: 'An error occurred while sending the notification',
        variant: 'destructive'
      });
    }
  };

  // Handle filter changes
  const handleFilterChange = (newState: SearchAndFilterState) => {
    setFilterState(newState);
  };

  // Filter and sort sitters based on current filter state
  const filteredSitters = useMemo(() => {
    if (!sitters.length) return [];
    
    return sitters.filter(sitter => {
      // Text search filter
      if (filterState.searchTerm) {
        const searchTerm = filterState.searchTerm.toLowerCase();
        const name = (sitter.full_name || '').toLowerCase();
        const email = (sitter.email || '').toLowerCase();
        
        if (!name.includes(searchTerm) && !email.includes(searchTerm)) {
          return false;
        }
      }
      
      // Badge filter
      if (
        filterState.filters.badge && 
        Array.isArray(filterState.filters.badge) && 
        filterState.filters.badge.length > 0
      ) {
        if (!sitter.badge || !filterState.filters.badge.includes(sitter.badge)) {
          return false;
        }
      }
      
      // Activity status filter
      if (filterState.filters.active) {
        const isActive = filterState.filters.active === 'active';
        // For this demo, let's consider a sitter active if they've had at least one booking
        const hasBookings = sitter.bookingCount > 0;
        
        if (isActive !== hasBookings) {
          return false;
        }
      }
      
      // Booking count range filter
      if (filterState.filters.bookings) {
        const { min, max } = filterState.filters.bookings;
        const bookingCount = sitter.bookingCount || 0;
        
        if (min !== null && bookingCount < min) {
          return false;
        }
        
        if (max !== null && bookingCount > max) {
          return false;
        }
      }
      
      return true;
    }).sort((a, b) => {
      switch (filterState.sortBy) {
        case 'name-asc':
          return (a.full_name || '').localeCompare(b.full_name || '');
        case 'name-desc':
          return (b.full_name || '').localeCompare(a.full_name || '');
        case 'bookings-asc':
          return (a.bookingCount || 0) - (b.bookingCount || 0);
        case 'bookings-desc':
          return (b.bookingCount || 0) - (a.bookingCount || 0);
        default:
          return 0;
      }
    });
  }, [sitters, filterState]);

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Notify Sitters</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-6">
            <SearchAndFilterBar
              initialState={filterState}
              onStateChange={handleFilterChange}
              filterOptions={filterOptions}
              sortOptions={sortOptions}
            />
          </div>
          
          {filteredSitters.length > 0 ? (
            <div className="space-y-4">
              {filteredSitters.map((sitter) => (
                <div 
                  key={sitter.user_id} 
                  className="p-4 border rounded-md flex justify-between items-center hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-center space-x-4">
                    <Avatar>
                      <AvatarImage src={sitter.photo_url} alt={sitter.full_name} />
                      <AvatarFallback>
                        <UserIcon className="h-5 w-5" />
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="flex items-center">
                        <h3 className="font-medium">{sitter.full_name}</h3>
                        {sitter.badge && (
                          <span className="ml-2 px-2 py-0.5 bg-amber-100 text-amber-800 text-xs rounded-full">
                            {sitter.badge}
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">{sitter.email}</p>
                      <div className="flex space-x-4 mt-1 text-xs text-muted-foreground">
                        <span>Bookings: {sitter.bookingCount || 0}</span>
                      </div>
                    </div>
                  </div>
                  <Button
                    onClick={() => notifySitter(sitter.user_id, sitter.full_name)}
                    className="bg-eucalyptus hover:bg-eucalyptus/90 text-white"
                  >
                    <Bell className="mr-2 h-4 w-4" />
                    Notify
                  </Button>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              {sitters.length > 0 ? (
                <div>
                  <p className="text-muted-foreground">No sitters match your filters</p>
                  <Button 
                    variant="link" 
                    onClick={() => setFilterState({
                      searchTerm: '',
                      filters: {},
                      sortBy: 'name-asc'
                    })}
                  >
                    Clear all filters
                  </Button>
                </div>
              ) : (
                <p className="text-muted-foreground">No sitters found in the system</p>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}