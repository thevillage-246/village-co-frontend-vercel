import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  CreditCard, 
  DollarSign, 
  Users, 
  Link2, 
  ExternalLink, 
  RefreshCw,
  TrendingUp,
  Search,
  Filter
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface StripeTransaction {
  id: number;
  stripeTransactionId: string;
  customerEmail: string;
  amount: number;
  currency: string;
  status: string;
  description: string | null;
  date: string;
  receiptUrl: string | null;
  userId: number | null;
  bookingId: number | null;
  linked: boolean;
  refunded: boolean;
  refundAmount: number | null;
  paymentMethodType: string | null;
}

interface TransactionAnalytics {
  totalRevenue: number;
  totalTransactions: number;
  averageTransactionAmount: number;
  linkedTransactions: number;
  unlinkedTransactions: number;
  recentTransactions: StripeTransaction[];
  topCustomers: Array<{
    email: string;
    total: number;
    count: number;
    linked: boolean;
  }>;
}

interface User {
  id: number;
  email: string;
  firstName: string;
  lastName: string;
}

export default function StripeTransactions() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [linkFilter, setLinkFilter] = useState("all");
  const [selectedTransaction, setSelectedTransaction] = useState<StripeTransaction | null>(null);
  const [selectedUserId, setSelectedUserId] = useState<string>("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch transaction analytics
  const { data: analytics, isLoading: analyticsLoading } = useQuery({
    queryKey: ["/api/admin/stripe/analytics"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Fetch all transactions
  const { data: transactionsData, isLoading: transactionsLoading } = useQuery({
    queryKey: ["/api/admin/stripe/transactions"],
    refetchInterval: 30000,
  });

  // Fetch all users for linking
  const { data: usersData } = useQuery({
    queryKey: ["/api/admin/users"],
  });

  // Sync Stripe transactions mutation
  const syncMutation = useMutation({
    mutationFn: async (limit: number = 100) => {
      return apiRequest("POST", "/api/admin/stripe/sync", { limit });
    },
    onSuccess: (data) => {
      toast({
        title: "Stripe Sync Complete",
        description: data.message || "Transactions synced successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stripe/analytics"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stripe/transactions"] });
    },
    onError: (error: any) => {
      toast({
        title: "Sync Failed",
        description: error.message || "Failed to sync Stripe transactions",
        variant: "destructive",
      });
    },
  });

  // Link transaction to user mutation
  const linkMutation = useMutation({
    mutationFn: async ({ stripeTransactionId, userId }: { stripeTransactionId: string; userId: number }) => {
      return apiRequest("POST", `/api/admin/stripe/transactions/${stripeTransactionId}/link`, { userId });
    },
    onSuccess: () => {
      toast({
        title: "Transaction Linked",
        description: "Transaction successfully linked to user",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stripe/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stripe/analytics"] });
      setSelectedTransaction(null);
      setSelectedUserId("");
    },
    onError: (error: any) => {
      toast({
        title: "Link Failed",
        description: error.message || "Failed to link transaction",
        variant: "destructive",
      });
    },
  });

  const transactions = transactionsData?.transactions || [];
  const users = usersData?.users || [];

  // Filter transactions
  const filteredTransactions = transactions.filter((transaction: StripeTransaction) => {
    const matchesSearch = 
      transaction.customerEmail.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.stripeTransactionId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (transaction.description && transaction.description.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesStatus = statusFilter === "all" || transaction.status === statusFilter;
    const matchesLink = linkFilter === "all" || 
      (linkFilter === "linked" && transaction.linked) ||
      (linkFilter === "unlinked" && !transaction.linked);

    return matchesSearch && matchesStatus && matchesLink;
  });

  const handleLinkTransaction = () => {
    if (selectedTransaction && selectedUserId) {
      linkMutation.mutate({
        stripeTransactionId: selectedTransaction.stripeTransactionId,
        userId: parseInt(selectedUserId)
      });
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Stripe Transaction History</h1>
          <p className="text-muted-foreground">
            Manage Stripe payment history and link transactions to platform users
          </p>
        </div>
        <Button 
          onClick={() => syncMutation.mutate(100)} 
          disabled={syncMutation.isPending}
          className="flex items-center gap-2"
        >
          <RefreshCw className={`w-4 h-4 ${syncMutation.isPending ? 'animate-spin' : ''}`} />
          {syncMutation.isPending ? 'Syncing...' : 'Sync Stripe'}
        </Button>
      </div>

      {/* Analytics Cards */}
      {analyticsLoading ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-8 bg-gray-200 rounded w-1/2"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : analytics ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                ${analytics.totalRevenue?.toFixed(2) || '0.00'} NZD
              </div>
              <p className="text-xs text-muted-foreground">
                From {analytics.totalTransactions} transactions
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Transactions</CardTitle>
              <CreditCard className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{analytics.totalTransactions}</div>
              <p className="text-xs text-muted-foreground">
                Avg: ${analytics.averageTransactionAmount?.toFixed(2) || '0.00'}
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Linked Transactions</CardTitle>
              <Link2 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{analytics.linkedTransactions}</div>
              <p className="text-xs text-muted-foreground">
                {analytics.totalTransactions > 0 ? 
                  Math.round((analytics.linkedTransactions / analytics.totalTransactions) * 100) : 0}% linked
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Unlinked Transactions</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">{analytics.unlinkedTransactions}</div>
              <p className="text-xs text-muted-foreground">
                Need user linking
              </p>
            </CardContent>
          </Card>
        </div>
      ) : null}

      {/* Filters */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search by email, transaction ID, or description..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="succeeded">Succeeded</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="failed">Failed</SelectItem>
                  <SelectItem value="canceled">Canceled</SelectItem>
                </SelectContent>
              </Select>

              <Select value={linkFilter} onValueChange={setLinkFilter}>
                <SelectTrigger className="w-[150px]">
                  <SelectValue placeholder="Link Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All</SelectItem>
                  <SelectItem value="linked">Linked</SelectItem>
                  <SelectItem value="unlinked">Unlinked</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Transactions Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CreditCard className="w-5 h-5" />
            Transactions ({filteredTransactions.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {transactionsLoading ? (
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="animate-pulse h-12 bg-gray-200 rounded"></div>
              ))}
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Transaction ID</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>User Link</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredTransactions.map((transaction: StripeTransaction) => (
                    <TableRow key={transaction.id}>
                      <TableCell className="font-mono text-xs">
                        {transaction.stripeTransactionId}
                      </TableCell>
                      <TableCell>
                        <div>
                          <div className="font-medium">{transaction.customerEmail}</div>
                          {transaction.description && (
                            <div className="text-sm text-muted-foreground">
                              {transaction.description}
                            </div>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span className="font-medium">
                            ${transaction.amount.toFixed(2)} {transaction.currency.toUpperCase()}
                          </span>
                          {transaction.refunded && (
                            <Badge variant="destructive" className="text-xs w-fit">
                              Refunded: ${transaction.refundAmount?.toFixed(2) || '0.00'}
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge 
                          variant={
                            transaction.status === 'succeeded' ? 'default' :
                            transaction.status === 'pending' ? 'secondary' :
                            transaction.status === 'failed' ? 'destructive' : 'outline'
                          }
                        >
                          {transaction.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {new Date(transaction.date).toLocaleDateString('en-NZ', {
                          year: 'numeric',
                          month: 'short',
                          day: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </TableCell>
                      <TableCell>
                        {transaction.linked ? (
                          <Badge variant="default" className="bg-green-100 text-green-800">
                            <Link2 className="w-3 h-3 mr-1" />
                            Linked (ID: {transaction.userId})
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="text-orange-600">
                            Unlinked
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          {!transaction.linked && (
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button 
                                  size="sm" 
                                  variant="outline"
                                  onClick={() => setSelectedTransaction(transaction)}
                                >
                                  <Link2 className="w-4 h-4" />
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Link Transaction to User</DialogTitle>
                                  <DialogDescription>
                                    Link transaction {transaction.stripeTransactionId} ({transaction.customerEmail}) to a platform user.
                                  </DialogDescription>
                                </DialogHeader>
                                <div className="space-y-4">
                                  <div>
                                    <label className="text-sm font-medium">Select User</label>
                                    <Select value={selectedUserId} onValueChange={setSelectedUserId}>
                                      <SelectTrigger>
                                        <SelectValue placeholder="Choose a user..." />
                                      </SelectTrigger>
                                      <SelectContent>
                                        {users
                                          .filter((user: User) => 
                                            user.email.toLowerCase().includes(transaction.customerEmail.toLowerCase()) ||
                                            transaction.customerEmail.toLowerCase().includes(user.email.toLowerCase())
                                          )
                                          .map((user: User) => (
                                            <SelectItem key={user.id} value={user.id.toString()}>
                                              {user.firstName} {user.lastName} ({user.email})
                                            </SelectItem>
                                          ))
                                        }
                                        {users
                                          .filter((user: User) => 
                                            !user.email.toLowerCase().includes(transaction.customerEmail.toLowerCase()) &&
                                            !transaction.customerEmail.toLowerCase().includes(user.email.toLowerCase())
                                          )
                                          .map((user: User) => (
                                            <SelectItem key={user.id} value={user.id.toString()}>
                                              {user.firstName} {user.lastName} ({user.email})
                                            </SelectItem>
                                          ))
                                        }
                                      </SelectContent>
                                    </Select>
                                  </div>
                                  <Button 
                                    onClick={handleLinkTransaction}
                                    disabled={!selectedUserId || linkMutation.isPending}
                                    className="w-full"
                                  >
                                    {linkMutation.isPending ? 'Linking...' : 'Link Transaction'}
                                  </Button>
                                </div>
                              </DialogContent>
                            </Dialog>
                          )}
                          {transaction.receiptUrl && (
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => window.open(transaction.receiptUrl!, '_blank')}
                            >
                              <ExternalLink className="w-4 h-4" />
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Top Customers */}
      {analytics?.topCustomers && analytics.topCustomers.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5" />
              Top Customers
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {analytics.topCustomers.slice(0, 5).map((customer, index) => (
                <div key={customer.email} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center text-sm font-medium">
                      {index + 1}
                    </div>
                    <div>
                      <div className="font-medium">{customer.email}</div>
                      <div className="text-sm text-muted-foreground">
                        {customer.count} transaction{customer.count !== 1 ? 's' : ''}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium">${customer.total.toFixed(2)} NZD</div>
                    <Badge variant={customer.linked ? "default" : "outline"} className="text-xs">
                      {customer.linked ? "Linked" : "Unlinked"}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}