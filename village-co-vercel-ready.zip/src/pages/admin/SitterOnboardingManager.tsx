import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { 
  CheckCircle2, 
  Clock, 
  XCircle, 
  Phone, 
  Video, 
  Shield,
  Search,
  Filter
} from 'lucide-react';

export default function SitterOnboardingManager() {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get all sitters with onboarding status
  const { data: sitters = [], isLoading } = useQuery({
    queryKey: ['/api/admin/sitters-onboarding-status'],
  });

  // Mark intro call complete mutation
  const markCallCompleteMutation = useMutation({
    mutationFn: (sitterId: number) => 
      apiRequest('POST', `/api/admin/sitter/${sitterId}/mark-call-complete`),
    onSuccess: (data, sitterId) => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/sitters-onboarding-status'] });
      toast({
        title: 'Call Marked Complete',
        description: `Sitter intro call completed. ${data.canBeBooked ? 'They can now receive bookings!' : ''}`,
      });
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Failed to mark call complete. Please try again.',
        variant: 'destructive',
      });
    },
  });

  // Filter sitters based on search and status
  const filteredSitters = sitters.filter((sitter: any) => {
    const matchesSearch = 
      sitter.firstName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sitter.lastName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sitter.email?.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'all' || 
      (statusFilter === 'pending-call' && !sitter.introCallCompleted && sitter.verificationStatus === 'verified') ||
      (statusFilter === 'needs-verification' && sitter.verificationStatus !== 'verified') ||
      (statusFilter === 'ready-to-book' && sitter.canBeBooked) ||
      (statusFilter === 'incomplete-profile' && !sitter.profileComplete);

    return matchesSearch && matchesStatus;
  });

  const getOnboardingStatus = (sitter: any) => {
    if (!sitter.profileComplete) {
      return { status: 'incomplete-profile', label: 'Profile Incomplete', color: 'bg-gray-500' };
    }
    if (sitter.verificationStatus !== 'verified') {
      return { status: 'needs-verification', label: 'Needs Verification', color: 'bg-yellow-500' };
    }
    if (!sitter.introCallCompleted) {
      return { status: 'pending-call', label: 'Pending Call', color: 'bg-blue-500' };
    }
    if (sitter.canBeBooked) {
      return { status: 'ready-to-book', label: 'Ready to Book', color: 'bg-green-500' };
    }
    return { status: 'review', label: 'Under Review', color: 'bg-orange-500' };
  };

  const getProgressPercentage = (sitter: any) => {
    let completed = 0;
    const total = 4;

    if (sitter.profileComplete) completed++;
    if (sitter.verificationStatus === 'verified') completed++;
    if (sitter.introVideoUrl) completed++;
    if (sitter.introCallCompleted) completed++;

    return Math.round((completed / total) * 100);
  };

  return (
    <div className="container mx-auto p-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Sitter Onboarding Manager</h1>
        <p className="text-gray-600">Manage sitter verification progress and intro calls</p>
      </div>

      {/* Filters and Search */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Filter className="w-5 h-5" />
            <span>Filters</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-2">Search Sitters</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search by name or email..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Status Filter</label>
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">All Statuses</option>
                <option value="incomplete-profile">Incomplete Profile</option>
                <option value="needs-verification">Needs Verification</option>
                <option value="pending-call">Pending Call</option>
                <option value="ready-to-book">Ready to Book</option>
              </select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Sitters Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-4 bg-gray-200 rounded mb-4"></div>
                <div className="h-3 bg-gray-200 rounded mb-2"></div>
                <div className="h-3 bg-gray-200 rounded"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredSitters.map((sitter: any) => {
              const onboardingStatus = getOnboardingStatus(sitter);
              const progress = getProgressPercentage(sitter);

              return (
                <Card key={sitter.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">
                        {sitter.firstName} {sitter.lastName}
                      </CardTitle>
                      <Badge className={`${onboardingStatus.color} text-white`}>
                        {onboardingStatus.label}
                      </Badge>
                    </div>
                    <CardDescription>{sitter.email}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {/* Progress Bar */}
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Onboarding Progress</span>
                          <span>{progress}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                            style={{ width: `${progress}%` }}
                          ></div>
                        </div>
                      </div>

                      {/* Checklist */}
                      <div className="space-y-2">
                        <div className="flex items-center space-x-2">
                          {sitter.profileComplete ? (
                            <CheckCircle2 className="w-4 h-4 text-green-600" />
                          ) : (
                            <XCircle className="w-4 h-4 text-red-500" />
                          )}
                          <span className="text-sm">Profile Complete</span>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          {sitter.verificationStatus === 'verified' ? (
                            <CheckCircle2 className="w-4 h-4 text-green-600" />
                          ) : sitter.verificationStatus === 'pending' ? (
                            <Clock className="w-4 h-4 text-yellow-500" />
                          ) : (
                            <XCircle className="w-4 h-4 text-red-500" />
                          )}
                          <span className="text-sm">ID Verification</span>
                          <Shield className="w-3 h-3 text-gray-400" />
                        </div>

                        <div className="flex items-center space-x-2">
                          {sitter.introVideoUrl ? (
                            <CheckCircle2 className="w-4 h-4 text-green-600" />
                          ) : (
                            <XCircle className="w-4 h-4 text-red-500" />
                          )}
                          <span className="text-sm">Intro Video</span>
                          <Video className="w-3 h-3 text-gray-400" />
                        </div>

                        <div className="flex items-center space-x-2">
                          {sitter.introCallCompleted ? (
                            <CheckCircle2 className="w-4 h-4 text-green-600" />
                          ) : (
                            <XCircle className="w-4 h-4 text-red-500" />
                          )}
                          <span className="text-sm">Intro Call</span>
                          <Phone className="w-3 h-3 text-gray-400" />
                        </div>
                      </div>

                      {/* Action Button */}
                      {!sitter.introCallCompleted && 
                       sitter.verificationStatus === 'verified' && 
                       sitter.profileComplete && (
                        <Button
                          onClick={() => markCallCompleteMutation.mutate(sitter.id)}
                          disabled={markCallCompleteMutation.isPending}
                          className="w-full"
                          size="sm"
                        >
                          {markCallCompleteMutation.isPending ? (
                            'Marking Complete...'
                          ) : (
                            'Mark Call Complete'
                          )}
                        </Button>
                      )}

                      {sitter.canBeBooked && (
                        <div className="text-center p-2 bg-green-50 rounded-md">
                          <span className="text-sm text-green-700 font-medium">
                            ✓ Ready to receive bookings
                          </span>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {filteredSitters.length === 0 && (
            <Card>
              <CardContent className="text-center py-12">
                <p className="text-gray-500">No sitters match your current filters.</p>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
}