import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Loader2, Download, Shield, AlertTriangle, CheckCircle, XCircle, User, Clock, Globe } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';

interface AuthLog {
  id: string;
  timestamp: string;
  event: 'login_success' | 'login_failure' | 'registration_success' | 'registration_failure' | 'logout';
  userId?: number;
  email: string;
  ipAddress?: string;
  userAgent?: string;
  details?: Record<string, any>;
  sessionId?: string;
  role?: string;
  success: boolean;
}

interface AuthMetrics {
  totalLogins: number;
  successfulLogins: number;
  failedLogins: number;
  totalRegistrations: number;
  successfulRegistrations: number;
  failedRegistrations: number;
  uniqueUsers: Set<string>;
  recentActivity: AuthLog[];
}

interface FailedAttempt {
  email: string;
  attempts: number;
  lastAttempt: string;
}

export default function AuthenticationLogsPage() {
  const [logs, setLogs] = useState<AuthLog[]>([]);
  const [metrics, setMetrics] = useState<AuthMetrics | null>(null);
  const [failedAttempts, setFailedAttempts] = useState<FailedAttempt[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [timeframe, setTimeframe] = useState('today');
  const [searchEmail, setSearchEmail] = useState('');
  const [userLogs, setUserLogs] = useState<AuthLog[]>([]);
  const [isExporting, setIsExporting] = useState(false);

  const fetchAuthLogs = async () => {
    setIsLoading(true);
    try {
      const response = await apiRequest('GET', `/api/admin/auth-logs?timeframe=${timeframe}&limit=100`);
      if (response.ok) {
        const data = await response.json();
        setLogs(data.logs);
        setMetrics({
          ...data.metrics,
          uniqueUsers: new Set(Array.from(data.metrics.uniqueUsers || []))
        });
      }
    } catch (error) {
      console.error('Failed to fetch authentication logs:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchFailedAttempts = async () => {
    try {
      const response = await apiRequest('GET', '/api/admin/auth-logs/failed-attempts?timeframe=hour&threshold=3');
      if (response.ok) {
        const data = await response.json();
        setFailedAttempts(data.failedAttempts);
      }
    } catch (error) {
      console.error('Failed to fetch failed attempts:', error);
    }
  };

  const searchUserLogs = async () => {
    if (!searchEmail.trim()) return;
    
    try {
      const response = await apiRequest('GET', `/api/admin/auth-logs/user/${encodeURIComponent(searchEmail)}`);
      if (response.ok) {
        const data = await response.json();
        setUserLogs(data.logs);
      }
    } catch (error) {
      console.error('Failed to fetch user logs:', error);
    }
  };

  const exportLogs = async (format: 'json' | 'csv') => {
    setIsExporting(true);
    try {
      const response = await apiRequest('GET', `/api/admin/auth-logs/export?format=${format}`);
      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        a.download = `auth-logs.${format}`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      }
    } catch (error) {
      console.error('Failed to export logs:', error);
    } finally {
      setIsExporting(false);
    }
  };

  useEffect(() => {
    fetchAuthLogs();
    fetchFailedAttempts();
  }, [timeframe]);

  const getEventBadge = (event: string, success: boolean) => {
    if (event.includes('login')) {
      return success ? 
        <Badge variant="secondary" className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" />Login Success</Badge> :
        <Badge variant="destructive"><XCircle className="w-3 h-3 mr-1" />Login Failed</Badge>;
    }
    if (event.includes('registration')) {
      return success ? 
        <Badge variant="secondary" className="bg-blue-100 text-blue-800"><User className="w-3 h-3 mr-1" />Registration Success</Badge> :
        <Badge variant="destructive"><XCircle className="w-3 h-3 mr-1" />Registration Failed</Badge>;
    }
    if (event === 'logout') {
      return <Badge variant="outline"><Shield className="w-3 h-3 mr-1" />Logout</Badge>;
    }
    return <Badge variant="outline">{event}</Badge>;
  };

  const formatTimestamp = (timestamp: string) => {
    return new Date(timestamp).toLocaleString();
  };

  const formatUserAgent = (userAgent?: string) => {
    if (!userAgent || userAgent === 'unknown') return 'Unknown Browser';
    
    // Simple user agent parsing
    if (userAgent.includes('Chrome')) return 'Chrome';
    if (userAgent.includes('Firefox')) return 'Firefox';
    if (userAgent.includes('Safari')) return 'Safari';
    if (userAgent.includes('Edge')) return 'Edge';
    
    return 'Other Browser';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Authentication Logs</h1>
          <p className="text-muted-foreground">Monitor user authentication activities and security events</p>
        </div>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            onClick={() => exportLogs('csv')}
            disabled={isExporting}
          >
            {isExporting ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Download className="w-4 h-4 mr-2" />}
            Export CSV
          </Button>
          <Button 
            variant="outline" 
            onClick={() => exportLogs('json')}
            disabled={isExporting}
          >
            <Download className="w-4 h-4 mr-2" />
            Export JSON
          </Button>
        </div>
      </div>

      {/* Metrics Overview */}
      {metrics && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Logins</CardTitle>
              <CheckCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{metrics.totalLogins}</div>
              <p className="text-xs text-muted-foreground">
                {metrics.successfulLogins} successful, {metrics.failedLogins} failed
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Registrations</CardTitle>
              <User className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{metrics.totalRegistrations}</div>
              <p className="text-xs text-muted-foreground">
                {metrics.successfulRegistrations} successful, {metrics.failedRegistrations} failed
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Unique Users</CardTitle>
              <Shield className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{metrics.uniqueUsers.size}</div>
              <p className="text-xs text-muted-foreground">Active in selected timeframe</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Failed Attempts</CardTitle>
              <AlertTriangle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{failedAttempts.length}</div>
              <p className="text-xs text-muted-foreground">Suspicious activity detected</p>
            </CardContent>
          </Card>
        </div>
      )}

      <Tabs defaultValue="recent" className="space-y-4">
        <TabsList>
          <TabsTrigger value="recent">Recent Activity</TabsTrigger>
          <TabsTrigger value="search">Search User</TabsTrigger>
          <TabsTrigger value="security">Security Alerts</TabsTrigger>
        </TabsList>

        <TabsContent value="recent" className="space-y-4">
          <div className="flex items-center gap-4">
            <Select value={timeframe} onValueChange={setTimeframe}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Select timeframe" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="week">Last Week</SelectItem>
                <SelectItem value="month">Last Month</SelectItem>
                <SelectItem value="all">All Time</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" onClick={fetchAuthLogs} disabled={isLoading}>
              {isLoading ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}
              Refresh
            </Button>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Authentication Events</CardTitle>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex items-center justify-center p-8">
                  <Loader2 className="w-8 h-8 animate-spin" />
                </div>
              ) : logs.length === 0 ? (
                <p className="text-center py-8 text-muted-foreground">No authentication events found</p>
              ) : (
                <div className="space-y-4">
                  {logs.map((log) => (
                    <div key={log.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center gap-4">
                        {getEventBadge(log.event, log.success)}
                        <div>
                          <p className="font-medium">{log.email}</p>
                          {log.role && <p className="text-sm text-muted-foreground">Role: {log.role}</p>}
                        </div>
                      </div>
                      <div className="text-right text-sm text-muted-foreground">
                        <div className="flex items-center gap-2 mb-1">
                          <Clock className="w-3 h-3" />
                          {formatTimestamp(log.timestamp)}
                        </div>
                        <div className="flex items-center gap-2">
                          <Globe className="w-3 h-3" />
                          {log.ipAddress || 'Unknown IP'} • {formatUserAgent(log.userAgent)}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="search" className="space-y-4">
          <div className="flex gap-4">
            <Input
              placeholder="Enter user email address"
              value={searchEmail}
              onChange={(e) => setSearchEmail(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && searchUserLogs()}
            />
            <Button onClick={searchUserLogs}>Search</Button>
          </div>

          {userLogs.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Activity for {searchEmail}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {userLogs.map((log) => (
                    <div key={log.id} className="flex items-center justify-between p-3 border rounded">
                      <div className="flex items-center gap-3">
                        {getEventBadge(log.event, log.success)}
                        {log.details?.reason && (
                          <span className="text-sm text-muted-foreground">• {log.details.reason}</span>
                        )}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {formatTimestamp(log.timestamp)}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="security" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-orange-500" />
                Failed Login Attempts (Last Hour)
              </CardTitle>
            </CardHeader>
            <CardContent>
              {failedAttempts.length === 0 ? (
                <p className="text-center py-4 text-muted-foreground">No suspicious activity detected</p>
              ) : (
                <div className="space-y-3">
                  {failedAttempts.map((attempt, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded bg-red-50">
                      <div>
                        <p className="font-medium">{attempt.email}</p>
                        <p className="text-sm text-muted-foreground">{attempt.attempts} failed attempts</p>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Last attempt: {formatTimestamp(attempt.lastAttempt)}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}