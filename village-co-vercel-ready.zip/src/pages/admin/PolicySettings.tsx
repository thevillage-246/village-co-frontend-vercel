import { useState, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Switch } from "@/components/ui/switch";

interface PolicySetting {
  key: string;
  value: string;
  description: string;
}

export default function PolicySettings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Create state to track form changes
  const [lateFeeAmount, setLateFeeAmount] = useState<string>("");
  const [lateFeeTimeThreshold, setLateFeeTimeThreshold] = useState<string>("");
  const [lateFeeEnabled, setLateFeeEnabled] = useState<boolean>(false);
  
  // Fetch current policy settings
  const { data: policySettings, isLoading } = useQuery<PolicySetting[]>({
    queryKey: ['/api/policies'],
  });

  // Set initial form values when policy data loads
  useEffect(() => {
    if (policySettings && Array.isArray(policySettings)) {
      // Set initial form values from policy settings
      const lateFeePolicies = policySettings.reduce((acc: Record<string, string>, policy: PolicySetting) => {
        acc[policy.key] = policy.value;
        return acc;
      }, {});
      
      setLateFeeAmount(lateFeePolicies['LATE_FEE_AMOUNT'] || "10");
      setLateFeeTimeThreshold(lateFeePolicies['LATE_FEE_GRACE_PERIOD_MINUTES'] || "10");
      setLateFeeEnabled(lateFeePolicies['LATE_FEE_ENABLED'] === 'true');
    }
  }, [policySettings]);
  
  // Update policy setting mutation
  const updatePolicySetting = useMutation({
    mutationFn: async (data: { key: string; value: string }) => {
      const response = await apiRequest("POST", `/api/policy`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/policies'] });
      toast({
        title: "Policy updated",
        description: "The policy has been updated successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error updating policy",
        description: `Failed to update policy: ${error.toString()}`,
        variant: "destructive",
      });
    }
  });
  
  // Handle form submission
  const handleSaveSettings = () => {
    updatePolicySetting.mutate({ key: 'LATE_FEE_AMOUNT', value: lateFeeAmount });
    updatePolicySetting.mutate({ key: 'LATE_FEE_GRACE_PERIOD_MINUTES', value: lateFeeTimeThreshold });
    updatePolicySetting.mutate({ key: 'LATE_FEE_ENABLED', value: lateFeeEnabled.toString() });
  };

  if (isLoading) {
    return (
      <div className="container mx-auto py-10">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-10">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Policy Settings</h1>
        <p className="text-muted-foreground mt-2">
          Configure platform-wide policies and settings
        </p>
      </div>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Late Fee Policy</CardTitle>
          <CardDescription>
            Configure when and how much to charge parents who are late for pickup
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6">
            <div className="flex items-center justify-between">
              <Label htmlFor="late-fee-enabled" className="text-base">
                Enable Late Fee Charging
              </Label>
              <Switch 
                id="late-fee-enabled" 
                checked={lateFeeEnabled} 
                onCheckedChange={setLateFeeEnabled} 
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label htmlFor="late-fee-amount">Late Fee Amount ($)</Label>
                <div className="flex">
                  <span className="flex items-center justify-center px-3 border border-r-0 rounded-l-md border-input bg-muted text-muted-foreground">$</span>
                  <Input
                    id="late-fee-amount"
                    type="number"
                    value={lateFeeAmount}
                    onChange={(e) => setLateFeeAmount(e.target.value)}
                    min="0"
                    step="0.01"
                    className="rounded-l-none"
                    disabled={!lateFeeEnabled}
                  />
                </div>
                <p className="text-sm text-muted-foreground">
                  Amount charged to parents when they're late
                </p>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="late-fee-threshold">Time Threshold (minutes)</Label>
                <div className="flex">
                  <Input
                    id="late-fee-threshold"
                    type="number"
                    value={lateFeeTimeThreshold}
                    onChange={(e) => setLateFeeTimeThreshold(e.target.value)}
                    min="0"
                    className="rounded-r-none"
                    disabled={!lateFeeEnabled}
                  />
                  <span className="flex items-center justify-center px-3 border border-l-0 rounded-r-md border-input bg-muted text-muted-foreground">min</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  How many minutes late triggers the fee
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Platform Fee Policy</CardTitle>
          <CardDescription>
            Configure the platform fee percentage taken from bookings
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6">
            <div className="space-y-2">
              <Label>Platform Fee Percentage</Label>
              <RadioGroup defaultValue="15" className="flex gap-4">
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="10" id="fee-10" />
                  <Label htmlFor="fee-10">10%</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="15" id="fee-15" />
                  <Label htmlFor="fee-15">15%</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="20" id="fee-20" />
                  <Label htmlFor="fee-20">20%</Label>
                </div>
              </RadioGroup>
              <p className="text-sm text-muted-foreground">
                Percentage of each booking payment kept by the platform
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button 
          onClick={handleSaveSettings}
          disabled={updatePolicySetting.isPending}
        >
          {updatePolicySetting.isPending ? "Saving..." : "Save Settings"}
        </Button>
      </div>
    </div>
  );
}