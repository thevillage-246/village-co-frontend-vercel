import { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { MessageSquare, Mail, Bell, Send, Users, CheckCircle } from 'lucide-react';
import SendSmsForm from '@/components/admin/SendSmsForm';
import AdminSidebar from '@/components/admin/AdminSidebar';

// Sitter messaging component with email alerts
function SitterMessagingForm() {
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [targetType, setTargetType] = useState('all');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!subject.trim() || !message.trim()) {
      toast({
        title: "Error",
        description: "Subject and message are required",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    
    try {
      const response = await apiRequest('POST', '/api/admin/notify-sitters', {
        subject: subject.trim(),
        message: message.trim(),
        targetType
      });

      if (response.ok) {
        const data = await response.json();
        toast({
          title: "Message Sent",
          description: `Message sent to ${data.recipientCount} sitters. Admin email notification sent to info@thevillageco.nz`,
        });
        setSubject('');
        setMessage('');
      } else {
        throw new Error('Failed to send message');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send message to sitters",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MessageSquare className="h-5 w-5" />
          Message Sitters
        </CardTitle>
        <CardDescription>
          Send messages to sitters with automatic email alerts to admin
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="target-type">Target Audience</Label>
            <Select value={targetType} onValueChange={setTargetType}>
              <SelectTrigger>
                <SelectValue placeholder="Select target audience" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Sitters</SelectItem>
                <SelectItem value="verified">Verified Sitters Only</SelectItem>
                <SelectItem value="active">Active Sitters</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="subject">Subject</Label>
            <Input
              id="subject"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="Enter message subject"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="message">Message</Label>
            <Textarea
              id="message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Enter your message to sitters..."
              rows={6}
              required
            />
          </div>

          <div className="flex items-center gap-2 p-3 bg-blue-50 rounded-lg border border-blue-200">
            <Mail className="h-4 w-4 text-blue-600" />
            <p className="text-sm text-blue-700">
              Admin will receive email confirmation at info@thevillageco.nz
            </p>
          </div>

          <Button type="submit" disabled={isLoading} className="w-full">
            {isLoading ? (
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Sending...
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Send className="h-4 w-4" />
                Send Message
              </div>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}

// Parent verification notification component
function ParentVerificationForm() {
  const [parentId, setParentId] = useState('');
  const [status, setStatus] = useState('');
  const [message, setMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!parentId || !status) {
      toast({
        title: "Error", 
        description: "Parent ID and status are required",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    
    try {
      const response = await apiRequest('POST', '/api/admin/notify-parent-verification', {
        parentId: parseInt(parentId),
        status,
        message
      });

      if (response.ok) {
        toast({
          title: "Notification Sent",
          description: "Parent verification notification sent and admin alerted",
        });
        setParentId('');
        setStatus('');
        setMessage('');
      } else {
        throw new Error('Failed to send notification');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send parent verification notification",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CheckCircle className="h-5 w-5" />
          Parent Verification Updates
        </CardTitle>
        <CardDescription>
          Send verification status updates to parents
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="parent-id">Parent ID</Label>
            <Input
              id="parent-id"
              value={parentId}
              onChange={(e) => setParentId(e.target.value)}
              placeholder="Enter parent user ID"
              type="number"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="verification-status">Verification Status</Label>
            <Select value={status} onValueChange={setStatus}>
              <SelectTrigger>
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="declined">Declined</SelectItem>
                <SelectItem value="pending">Pending Review</SelectItem>
                <SelectItem value="expired">Expired</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="verification-message">Additional Message (Optional)</Label>
            <Textarea
              id="verification-message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Additional message to parent..."
              rows={3}
            />
          </div>

          <Button type="submit" disabled={isLoading} className="w-full">
            {isLoading ? (
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Sending...
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Bell className="h-4 w-4" />
                Send Notification
              </div>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
}

export default function AdminNotificationsPage() {
  const [activeTab, setActiveTab] = useState('message');
  
  return (
    <>
      <Helmet>
        <title>Notifications | Admin - The Village Co</title>
      </Helmet>

      <div className="flex min-h-screen bg-gray-50">
        <AdminSidebar />
        
        <main className="flex-1 p-4 md:p-6">
          <div className="mb-6">
            <h1 className="text-xl md:text-2xl font-bold text-gray-900">Notification Center</h1>
            <p className="text-sm md:text-base text-gray-600">
              Send messages and notifications with automatic email alerts to info@thevillageco.nz
            </p>
          </div>
          
          <Tabs defaultValue="message" value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-4 lg:w-auto lg:grid-cols-none lg:flex">
              <TabsTrigger value="message" className="text-xs md:text-sm">
                <MessageSquare className="h-4 w-4 mr-1" />
                <span className="hidden sm:inline">Message Sitters</span>
                <span className="sm:hidden">Message</span>
              </TabsTrigger>
              <TabsTrigger value="verification" className="text-xs md:text-sm">
                <CheckCircle className="h-4 w-4 mr-1" />
                <span className="hidden sm:inline">Parent Verification</span>
                <span className="sm:hidden">Verify</span>
              </TabsTrigger>
              <TabsTrigger value="sms" className="text-xs md:text-sm">
                <Bell className="h-4 w-4 mr-1" />
                SMS
              </TabsTrigger>
              <TabsTrigger value="support" className="text-xs md:text-sm">
                <Users className="h-4 w-4 mr-1" />
                <span className="hidden sm:inline">Support</span>
                <span className="sm:hidden">Help</span>
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="message" className="mt-4">
              <div className="grid gap-6 lg:grid-cols-2">
                <SitterMessagingForm />
                
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Mail className="h-5 w-5" />
                      Recent Messages
                    </CardTitle>
                    <CardDescription>
                      Recently sent sitter messages
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium text-sm">Platform Update</p>
                          <p className="text-xs text-gray-600">Sent to all sitters</p>
                        </div>
                        <Badge variant="secondary">Today</Badge>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium text-sm">Verification Reminder</p>
                          <p className="text-xs text-gray-600">Sent to 12 sitters</p>
                        </div>
                        <Badge variant="secondary">Yesterday</Badge>
                      </div>
                      <div className="text-center py-4">
                        <p className="text-sm text-gray-500">All messages are logged with email alerts</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="verification" className="mt-4">
              <div className="grid gap-6 lg:grid-cols-2">
                <ParentVerificationForm />
                
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <CheckCircle className="h-5 w-5" />
                      Verification Status Guide
                    </CardTitle>
                    <CardDescription>
                      Status definitions for parent verification
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="p-3 border rounded-lg">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant="default">Approved</Badge>
                        </div>
                        <p className="text-sm text-gray-600">
                          Identity verification successfully completed
                        </p>
                      </div>
                      
                      <div className="p-3 border rounded-lg">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant="destructive">Declined</Badge>
                        </div>
                        <p className="text-sm text-gray-600">
                          Verification failed or documents rejected
                        </p>
                      </div>
                      
                      <div className="p-3 border rounded-lg">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant="secondary">Pending</Badge>
                        </div>
                        <p className="text-sm text-gray-600">
                          Under review by verification team
                        </p>
                      </div>
                      
                      <div className="p-3 border rounded-lg">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant="outline">Expired</Badge>
                        </div>
                        <p className="text-sm text-gray-600">
                          Verification session expired, needs restart
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="sms" className="mt-4">
              <div className="grid gap-6 lg:grid-cols-2">
                <SendSmsForm />
                
                <Card>
                  <CardHeader>
                    <CardTitle>SMS Templates</CardTitle>
                    <CardDescription>
                      Pre-made templates for common notifications
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="border rounded-md p-3 cursor-pointer hover:bg-gray-50">
                        <h4 className="font-medium text-sm">Verification Reminder</h4>
                        <p className="text-xs text-gray-600 truncate">
                          Hi [Name], please complete your identity verification...
                        </p>
                      </div>
                      
                      <div className="border rounded-md p-3 cursor-pointer hover:bg-gray-50">
                        <h4 className="font-medium text-sm">Booking Confirmation</h4>
                        <p className="text-xs text-gray-600 truncate">
                          Hi [Name], your booking has been confirmed for [Date]...
                        </p>
                      </div>
                      
                      <div className="border rounded-md p-3 cursor-pointer hover:bg-gray-50">
                        <h4 className="font-medium text-sm">Account Activation</h4>
                        <p className="text-xs text-gray-600 truncate">
                          Welcome to The Village Co! Your account is now active...
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="support" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5" />
                    Support Contact Tracking
                  </CardTitle>
                  <CardDescription>
                    Monitor and track user support interactions
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                    <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                      <div className="flex items-center gap-2 mb-2">
                        <Mail className="h-4 w-4 text-blue-600" />
                        <h4 className="font-medium text-blue-900">Email Support</h4>
                      </div>
                      <p className="text-sm text-blue-700">info@thevillageco.nz</p>
                      <p className="text-xs text-blue-600 mt-1">All emails automatically tracked</p>
                    </div>
                    
                    <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                      <div className="flex items-center gap-2 mb-2">
                        <Bell className="h-4 w-4 text-green-600" />
                        <h4 className="font-medium text-green-900">Live Chat</h4>
                      </div>
                      <p className="text-sm text-green-700">Available 9am-5pm NZST</p>
                      <p className="text-xs text-green-600 mt-1">Automated logging enabled</p>
                    </div>
                    
                    <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                      <div className="flex items-center gap-2 mb-2">
                        <CheckCircle className="h-4 w-4 text-purple-600" />
                        <h4 className="font-medium text-purple-900">Priority Alerts</h4>
                      </div>
                      <p className="text-sm text-purple-700">Emergency notifications</p>
                      <p className="text-xs text-purple-600 mt-1">Instant admin email alerts</p>
                    </div>
                  </div>
                  
                  <div className="mt-6 p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                    <div className="flex items-center gap-2 mb-2">
                      <Mail className="h-4 w-4 text-yellow-600" />
                      <h4 className="font-medium text-yellow-900">Admin Email Notifications</h4>
                    </div>
                    <p className="text-sm text-yellow-700">
                      All support contacts, sitter messages, and verification updates automatically send email alerts to info@thevillageco.nz for immediate admin visibility.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </>
  );
}