/**
 * SMS Dashboard Page - Admin interface for comprehensive SMS monitoring
 */
import React from 'react';
import SMSDashboard from '../../components/admin/SMSDashboard';

export default function SMSDashboardPage() {
  return (
    <div className="container mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">SMS Dashboard</h1>
        <p className="mt-2 text-gray-600">Monitor SMS activity and delivery statistics</p>
      </div>
      <SMSDashboard />
    </div>
  );
}