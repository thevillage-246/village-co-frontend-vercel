import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';
import { 
  Mail, 
  Send, 
  Eye, 
  Edit3, 
  Save, 
  Copy, 
  FileText,
  Users,
  Calendar,
  Sparkles
} from 'lucide-react';

interface EmailTemplate {
  id: string;
  subject: string;
  preview: string;
  body: string;
  emailNumber: number;
  cta: string;
  variables: string[];
}

const sitterWelcomeEmails: EmailTemplate[] = [
  {
    id: 'sitter-welcome',
    emailNumber: 1,
    subject: "Welcome to your next adventure 🧡",
    preview: "You just joined a sitter crew like no other.",
    body: `Hi [Sitter First Name],

You're in! And around here, that means something.

You're not just a name on a list — you're part of a community where sitters are supported, valued, and trusted with one of the most important jobs there is: giving parents a break and kids a good time.

Whether you're studying, building your career, or just love working with little humans — we've got your back.

Next step? Build your sitter profile so families can find and book you.`,
    cta: "[Create Your Sitter Profile]",
    variables: ['Sitter First Name']
  },
  {
    id: 'sitter-stand-out',
    emailNumber: 2,
    subject: "Want more bookings? Start here.",
    preview: "Your sitter profile is your superpower — let's make it shine.",
    body: `The best sitters in The Village don't just "get by" — they stand out.

✨ Here's how to get noticed (and booked!):

Add a friendly profile photo (smiling, clear, confident)

Record a short intro video — so parents can see your vibe

Share what makes you great with kids (experience, interests, energy)

Remember, families aren't just looking for experience — they're looking for someone they trust. Show them why that's you.`,
    cta: "[Edit My Profile Now]",
    variables: []
  },
  {
    id: 'sitter-verification',
    emailNumber: 3,
    subject: "Verified sitters = more bookings ✅",
    preview: "Families trust you faster when you're fully verified.",
    body: `Want to boost your chances of getting booked? Get your Verified Sitter badge.

To get verified:

Upload a clear photo ID

Add your referee contacts

Book your video call with our team

(Optional but awesome) Upload a first aid cert

We personally call and support every sitter — because you're not just a username to us. You're part of the Village.

And yes — verified sitters appear first in search. 📍`,
    cta: "[Start My Verification]",
    variables: []
  },
  {
    id: 'sitter-first-booking',
    emailNumber: 4,
    subject: "First family = first win 💛",
    preview: "It only takes one booking to start something big.",
    body: `The best way to build your Village rep? Land your first booking.

We'll guide you:

Set your availability and hourly rate

Turn on notifications so you never miss a request

Text us if you need help — we're real humans, not robots

You're not alone here. We support every sitter through their first job (and every one after that).

Let's get you booked!`,
    cta: "[Set Availability Now]",
    variables: []
  },
  {
    id: 'sitter-ready',
    emailNumber: 5,
    subject: "Your next booking could happen today ✨",
    preview: "You've done the work. Let the bookings roll in.",
    body: `You're verified, profile-ready, and set to go. So what's next?

Keep your profile fresh and friendly

Respond fast to messages — parents notice!

Share your link to get referrals + reviews

And most of all, be yourself — kind, calm, confident

Whether it's your first or fiftieth booking, you've got our full support.

And if you ever feel stuck? Message us. You're never doing this alone.`,
    cta: "[See New Booking Requests]",
    variables: []
  }
];

const sitterBookingEmails: EmailTemplate[] = [
  {
    id: 'booking-opportunity',
    emailNumber: 1,
    subject: "New booking opportunity near you! 👶",
    preview: "Log in now to see if it's a fit.",
    body: `Hey [Sitter First Name],

There's a family browsing sitters like you right now — and we think you could be the perfect match.

✅ Check your availability
✅ Turn on notifications
✅ Message parents quickly (they love fast replies!)

You've got this — and we're right here if you need help.`,
    cta: "[View Booking Requests]",
    variables: ['Sitter First Name']
  },
  {
    id: 'first-booking-help',
    emailNumber: 2,
    subject: "Want your first babysitting job? Let's make it happen.",
    preview: "We'll support you every step of the way.",
    body: `We know the first booking can feel like a big step. But you don't have to do it alone.

We're here to:

Recommend families based on your vibe

Check over your profile with tips

Boost you to the top of search results once you're verified

You've got this. Let's get you that first booking — and that first amazing review.`,
    cta: "[Update My Profile]",
    variables: []
  },
  {
    id: 'booking-complete',
    emailNumber: 3,
    subject: "First job done 🙌 Time to reflect (and get your next one)",
    preview: "We'd love your feedback — and so would the family.",
    body: `Hi [Sitter First Name],

You just completed a booking! 🎉 How did it go?

Leave a quick note or rating — it helps build your rep and keeps the Village honest and transparent.

And psst… we'll boost your profile once you start getting great reviews 😉`,
    cta: "[Leave Feedback]",
    variables: ['Sitter First Name']
  },
  {
    id: 'rebooking-opportunity',
    emailNumber: 4,
    subject: "Rebooking in 3... 2... 1…",
    preview: "Like the family? Let them know you're keen to return.",
    body: `Had a great time with a family? Let them know you're open to future bookings.

✨ Sitters with repeat families get more jobs, better reviews, and higher trust.

Pop into your dashboard, send a message to the family, and keep the magic going.`,
    cta: "[Message the Family]",
    variables: []
  }
];

const parentBookingEmails: EmailTemplate[] = [
  {
    id: 'choosing-sitter',
    emailNumber: 1,
    subject: "Let's find the perfect sitter for your first booking 💛",
    preview: "You don't have to wing it. We're here to help.",
    body: `Hi [Parent First Name],

It's totally normal to feel a little nervous before your first booking — you're not just hiring a sitter, you're handing over your whole world.

But you're not doing this alone. Every sitter on The Village Co. has been personally vetted, interviewed, and supported by our team.

Not sure who to choose? We can:

Recommend sitters based on your child's age and personality

Offer a quick intro call before you book

Or just book it all for you (yep, concierge style)

Let's take the pressure off.`,
    cta: "[Help Me Choose]",
    variables: ['Parent First Name']
  },
  {
    id: 'booking-encouragement',
    emailNumber: 2,
    subject: "Still thinking about booking? This is your sign. ✨",
    preview: "A sitter can give you a break. You deserve it.",
    body: `Hi [First Name],

We see you. Holding everything together, running on caffeine and chaos. It's a lot. And it's okay to need a break — in fact, it's necessary.

✨ Book a sitter this week and get:

A moment to yourself

A guilt-free break

Peace of mind knowing your kids are safe and happy

Whether it's a date night, a yoga class, or just quiet, your first booking starts with one click.`,
    cta: "[Book a Sitter Now]",
    variables: ['First Name']
  },
  {
    id: 'booking-feedback',
    emailNumber: 3,
    subject: "You did it! Now tell us how it went 🙌",
    preview: "We'd love your feedback (and your sitter would too).",
    body: `Hi [First Name],

We hope your first booking felt like a breath of fresh air.

Now we'd love to hear how it went — your review helps other parents choose with confidence, and it helps great sitters keep shining.

Tell us: did your sitter make the kids smile? Did you get the break you needed?

Your feedback = your Village in action.`,
    cta: "[Leave a Review]",
    variables: ['First Name']
  },
  {
    id: 'rebooking-suggestion',
    emailNumber: 4,
    subject: "Rebooking takes 10 seconds 💫",
    preview: "Keep the good vibes going with your favourite sitter.",
    body: `Loved your sitter? You can book them again — fast.

You already know your kids like them. You already trust them. Why not lock in a weekly breather or that upcoming event?

Great sitters book out quickly — we recommend securing the ones you love before someone else does.`,
    cta: "[Rebook My Sitter]",
    variables: []
  }
];

const parentWelcomeEmails: EmailTemplate[] = [
  {
    id: 'welcome',
    emailNumber: 1,
    subject: "You're in. Welcome to The Village Co. 🤍",
    preview: "Babysitting, but actually smart. Let's get you set up.",
    body: `Hi [Parent First Name],

You just joined a community of parents who are done doing it all, all the time. At The Village Co., we're making babysitting feel effortless — like finishing a coffee while it's still hot kind of effortless.

Every sitter is vetted. Every booking is backed. And every parent deserves a break without the guilt.

Here's how to get started:

Fill out your parent profile (so sitters know your kiddo isn't a fan of peas or Peppa).

Browse our trusted sitters.

Book with confidence. Your break is waiting.

💡 Tip: Want us to do the legwork? Tap the concierge button below.`,
    cta: "[Let's Do This] or [Try Concierge Booking]",
    variables: ['Parent First Name']
  },
  {
    id: 'how-it-works',
    emailNumber: 2,
    subject: "Book your sitter in 3 easy steps 👏",
    preview: "Because parenting doesn't come with a pause button — but we do.",
    body: `Here's the deal, [Parent First Name]:

We've made booking babysitting smoother than bedtime on a good night (read: miracle). Just follow these 3 steps:

Set Up Your Profile
Allergies? Nap quirks? Favourite snack? Sitters love details.

Find Your Match
Use filters to search availability, rate, and experience. Choose your sitter — you're in control.

Book & Breathe
Secure payment. Instant confirmation. Insurance-backed. Guilt-free.

✨ Your first booking could happen in under 5 minutes. How's that for "me time"?`,
    cta: "[Book a Sitter Now]",
    variables: ['Parent First Name']
  },
  {
    id: 'testimonials',
    emailNumber: 3,
    subject: '"I cried tears of joy after my first night off." – real mum',
    preview: "Spoiler: you're going to love it here.",
    body: `We could talk all day, but we'd rather show you what real Village parents are saying:

🗣 "It felt like someone finally saw me. Not just the mum, but me."
🗣 "Our sitter played piano, danced, and even cleaned the dishes. My kids begged for her back."
🗣 "I didn't know I needed this until I had it."

Why does it feel so different? Because we're not just a platform. We're a movement. Built by mums, for mums. And we don't play when it comes to safety, trust, and peace of mind.

Still waiting to book? You're one click away.`,
    cta: "[Find Your Sitter]",
    variables: []
  },
  {
    id: 'first-break',
    emailNumber: 4,
    subject: "What's your reason for a night off? 🥂",
    preview: "Date night? Gym? Silence? We've got your back.",
    body: `Hey [First Name],

Got something coming up — or just need a break because your toddler's been on a 3-day jam-only diet?

Whatever your why, we'll help you make it happen.

Our concierge service can:
✅ Match you with the right sitter
✅ Recommend options based on your vibe
✅ Book it all for you (yes, really)

This isn't just babysitting. It's "you" time — on your terms.`,
    cta: "[Try the Concierge Option]",
    variables: ['First Name']
  },
  {
    id: 'booking-checklist',
    emailNumber: 5,
    subject: "What to leave out for your sitter (and what to actually do during your break)",
    preview: "The essential sitter checklist — and your permission slip to relax.",
    body: `Here's what we recommend you leave out for your sitter:
✅ Nappies & wipes
✅ Bedtime rundown (yes, they know about the 3rd water cup)
✅ Emergency contact info
✅ Your kid's fave comfort toy

Now here's what you should do:
✨ Grab a glass of wine
✨ Leave the house guilt-free
✨ Or take a nap like a damn queen

We'll handle the rest. Because you deserve a sitter who shows up, so you can check out.`,
    cta: "[See Sitter Profiles]",
    variables: []
  }
];

export default function LoopsContentManager() {
  const [selectedCategory, setSelectedCategory] = useState<'parent-welcome' | 'parent-booking' | 'sitter-welcome' | 'sitter-booking'>('parent-welcome');
  const [selectedEmail, setSelectedEmail] = useState<EmailTemplate>(parentWelcomeEmails[0]);
  const [editMode, setEditMode] = useState(false);
  const [editedContent, setEditedContent] = useState<EmailTemplate>(selectedEmail);
  const [previewMode, setPreviewMode] = useState(false);
  const [previewData, setPreviewData] = useState({
    'Parent First Name': 'Sarah',
    'First Name': 'Sarah',
    'Sitter First Name': 'Emma'
  });
  const { toast } = useToast();

  const getEmailsByCategory = () => {
    switch (selectedCategory) {
      case 'parent-welcome':
        return parentWelcomeEmails;
      case 'parent-booking':
        return parentBookingEmails;
      case 'sitter-welcome':
        return sitterWelcomeEmails;
      case 'sitter-booking':
        return sitterBookingEmails;
      default:
        return parentWelcomeEmails;
    }
  };

  const getCategoryTitle = () => {
    switch (selectedCategory) {
      case 'parent-welcome':
        return 'Parent Welcome & Onboarding Flow';
      case 'parent-booking':
        return 'Parent Booking Flow Emails';
      case 'sitter-welcome':
        return 'Sitter Welcome & Onboarding Flow';
      case 'sitter-booking':
        return 'Sitter Booking Flow Emails';
      default:
        return 'Email Templates';
    }
  };

  useEffect(() => {
    const emailsByCategory = getEmailsByCategory();
    setSelectedEmail(emailsByCategory[0]);
    setEditedContent(emailsByCategory[0]);
    setEditMode(false);
  }, [selectedCategory]);

  useEffect(() => {
    setEditedContent(selectedEmail);
    setEditMode(false);
  }, [selectedEmail]);

  const handleSave = () => {
    // In a real implementation, this would save to Loops via API
    toast({
      title: "Email Template Saved",
      description: `"${editedContent.subject}" has been updated in Loops.`,
    });
    setEditMode(false);
  };

  const handleCopyToClipboard = (content: string) => {
    navigator.clipboard.writeText(content);
    toast({
      title: "Copied to Clipboard",
      description: "Content copied successfully.",
    });
  };

  const renderPreview = (text: string) => {
    let preview = text;
    Object.entries(previewData).forEach(([variable, value]) => {
      preview = preview.replace(new RegExp(`\\[${variable}\\]`, 'g'), value);
    });
    return preview;
  };

  const exportForLoops = () => {
    const categoryPrefix = selectedCategory.replace('-', '_');
    const loopsFormat = {
      transactionalId: `${categoryPrefix}_${selectedEmail.id}`,
      name: `${getCategoryTitle()} ${selectedEmail.emailNumber}: ${selectedEmail.id}`,
      subject: editedContent.subject,
      body: editedContent.body,
      variables: editedContent.variables,
      settings: {
        type: 'transactional',
        category: selectedCategory,
        sequence: selectedEmail.emailNumber
      }
    };
    
    handleCopyToClipboard(JSON.stringify(loopsFormat, null, 2));
    toast({
      title: "Loops JSON Exported",
      description: "Email template formatted for Loops API import.",
    });
  };

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900" style={{ fontFamily: 'Satoshi, sans-serif' }}>
            Loops Content Manager
          </h1>
          <p className="text-gray-600 mt-2" style={{ fontFamily: 'DM Sans, sans-serif' }}>
            Manage parent onboarding email templates for The Village Co.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Badge variant="outline" className="flex items-center gap-2">
            <Mail className="w-4 h-4" />
            {getEmailsByCategory().length} Email Templates
          </Badge>
          <Badge variant="outline" className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            {getCategoryTitle()}
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Email List Sidebar */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="w-5 h-5" />
                Email Templates
              </CardTitle>
              <CardDescription>
                {getCategoryTitle()}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Category Selector */}
              <div className="space-y-2">
                <Label className="text-xs font-medium text-gray-500">Email Category</Label>
                <div className="grid grid-cols-1 gap-2">
                  {[
                    { key: 'parent-welcome', label: 'Parent Welcome' },
                    { key: 'parent-booking', label: 'Parent Booking' },
                    { key: 'sitter-welcome', label: 'Sitter Welcome' },
                    { key: 'sitter-booking', label: 'Sitter Booking' }
                  ].map((category) => (
                    <button
                      key={category.key}
                      className={`p-2 text-left text-sm rounded border transition-all ${
                        selectedCategory === category.key
                          ? 'border-village-wine bg-village-wine/10 text-village-wine font-medium'
                          : 'border-gray-200 hover:border-gray-300 text-gray-700'
                      }`}
                      onClick={() => setSelectedCategory(category.key as any)}
                    >
                      {category.label}
                    </button>
                  ))}
                </div>
              </div>
              
              {/* Email List */}
              <div className="space-y-3">
                {getEmailsByCategory().map((email) => (
                <div
                  key={email.id}
                  className={`p-3 rounded-lg border cursor-pointer transition-all ${
                    selectedEmail.id === email.id
                      ? 'border-village-wine bg-village-wine/5'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => setSelectedEmail(email)}
                >
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant="secondary" className="text-xs">
                      Email {email.emailNumber}
                    </Badge>
                    <Calendar className="w-4 h-4 text-gray-400" />
                  </div>
                  <h3 className="font-medium text-sm mb-1" style={{ fontFamily: 'Satoshi, sans-serif' }}>
                    {email.subject.length > 40 ? `${email.subject.substring(0, 40)}...` : email.subject}
                  </h3>
                  <p className="text-xs text-gray-600" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                    {email.preview.length > 60 ? `${email.preview.substring(0, 60)}...` : email.preview}
                  </p>
                </div>
              ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Area */}
        <div className="lg:col-span-2">
          <Card className="h-full">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Mail className="w-5 h-5 text-village-wine" />
                    Email {selectedEmail.emailNumber}: {selectedEmail.id}
                  </CardTitle>
                  <CardDescription>
                    {selectedEmail.preview}
                  </CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setPreviewMode(!previewMode)}
                    className="flex items-center gap-2"
                  >
                    <Eye className="w-4 h-4" />
                    {previewMode ? 'Edit' : 'Preview'}
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={exportForLoops}
                    className="flex items-center gap-2"
                  >
                    <Copy className="w-4 h-4" />
                    Export
                  </Button>
                  {editMode ? (
                    <Button
                      onClick={handleSave}
                      size="sm"
                      className="flex items-center gap-2"
                    >
                      <Save className="w-4 h-4" />
                      Save
                    </Button>
                  ) : (
                    <Button
                      onClick={() => setEditMode(true)}
                      size="sm"
                      className="flex items-center gap-2"
                    >
                      <Edit3 className="w-4 h-4" />
                      Edit
                    </Button>
                  )}
                </div>
              </div>
            </CardHeader>
            
            <CardContent>
              <Tabs defaultValue="content" className="space-y-4">
                <TabsList>
                  <TabsTrigger value="content">Content</TabsTrigger>
                  <TabsTrigger value="settings">Settings</TabsTrigger>
                  <TabsTrigger value="variables">Variables</TabsTrigger>
                </TabsList>

                <TabsContent value="content" className="space-y-4">
                  {previewMode ? (
                    /* Preview Mode */
                    <div className="space-y-4">
                      <div className="bg-gray-50 rounded-lg p-4">
                        <h3 className="font-medium mb-2">Email Preview</h3>
                        <div className="bg-white rounded border p-4 space-y-3">
                          <div>
                            <Label className="text-xs text-gray-500">Subject:</Label>
                            <p className="font-medium">{renderPreview(editedContent.subject)}</p>
                          </div>
                          <div>
                            <Label className="text-xs text-gray-500">Preview Text:</Label>
                            <p className="text-sm text-gray-600">{renderPreview(editedContent.preview)}</p>
                          </div>
                          <div>
                            <Label className="text-xs text-gray-500">Body:</Label>
                            <div className="whitespace-pre-wrap text-sm">{renderPreview(editedContent.body)}</div>
                          </div>
                          <div className="pt-2 border-t">
                            <Label className="text-xs text-gray-500">Call to Action:</Label>
                            <p className="font-medium text-village-wine">{editedContent.cta}</p>
                          </div>
                        </div>
                      </div>
                      
                      {/* Preview Variables */}
                      {editedContent.variables.length > 0 && (
                        <div className="bg-blue-50 rounded-lg p-4">
                          <h4 className="font-medium mb-3 flex items-center gap-2">
                            <Sparkles className="w-4 h-4" />
                            Preview Variables
                          </h4>
                          <div className="grid grid-cols-2 gap-3">
                            {editedContent.variables.map((variable) => (
                              <div key={variable}>
                                <Label className="text-xs">{variable}</Label>
                                <Input
                                  value={previewData[variable] || ''}
                                  onChange={(e) => setPreviewData(prev => ({
                                    ...prev,
                                    [variable]: e.target.value
                                  }))}
                                  className="h-8"
                                />
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  ) : (
                    /* Edit Mode */
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="subject">Subject Line</Label>
                        <Input
                          id="subject"
                          value={editMode ? editedContent.subject : selectedEmail.subject}
                          onChange={(e) => setEditedContent(prev => ({ ...prev, subject: e.target.value }))}
                          disabled={!editMode}
                          className="mt-1"
                        />
                      </div>

                      <div>
                        <Label htmlFor="preview">Preview Text</Label>
                        <Input
                          id="preview"
                          value={editMode ? editedContent.preview : selectedEmail.preview}
                          onChange={(e) => setEditedContent(prev => ({ ...prev, preview: e.target.value }))}
                          disabled={!editMode}
                          className="mt-1"
                        />
                      </div>

                      <div>
                        <Label htmlFor="body">Email Body</Label>
                        <Textarea
                          id="body"
                          value={editMode ? editedContent.body : selectedEmail.body}
                          onChange={(e) => setEditedContent(prev => ({ ...prev, body: e.target.value }))}
                          disabled={!editMode}
                          className="mt-1 min-h-[300px] font-mono text-sm"
                          placeholder="Enter email content..."
                        />
                      </div>

                      <div>
                        <Label htmlFor="cta">Call to Action</Label>
                        <Input
                          id="cta"
                          value={editMode ? editedContent.cta : selectedEmail.cta}
                          onChange={(e) => setEditedContent(prev => ({ ...prev, cta: e.target.value }))}
                          disabled={!editMode}
                          className="mt-1"
                        />
                      </div>
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="settings" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>Email Sequence Position</Label>
                      <Input value={`${selectedEmail.emailNumber} of 5`} disabled />
                    </div>
                    <div>
                      <Label>Email Type</Label>
                      <Input value="Transactional/Onboarding" disabled />
                    </div>
                    <div>
                      <Label>Category</Label>
                      <Input value="Parent Welcome Flow" disabled />
                    </div>
                    <div>
                      <Label>Trigger</Label>
                      <Input value="User Registration" disabled />
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="variables" className="space-y-4">
                  <div>
                    <h3 className="font-medium mb-3">Available Variables</h3>
                    <div className="space-y-2">
                      {selectedEmail.variables.length > 0 ? (
                        selectedEmail.variables.map((variable) => (
                          <div key={variable} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                            <span className="font-mono text-sm">[{variable}]</span>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleCopyToClipboard(`[${variable}]`)}
                            >
                              <Copy className="w-4 h-4" />
                            </Button>
                          </div>
                        ))
                      ) : (
                        <p className="text-gray-500 text-sm">No variables used in this email.</p>
                      )}
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}