import React from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient } from '@/lib/queryClient';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { apiRequest } from '@/lib/queryClient';
import { Loader2, CheckCircle, XCircle, UserIcon, Bell } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';

const SitterApprovals: React.FC = () => {
  const { toast } = useToast();
  const { data: response, isLoading } = useQuery({
    queryKey: ['/api/sitters/all'],
    queryFn: () => apiRequest('GET', '/api/sitters/all'),
  });

  // Filter for non-approved sitters and add name formatting
  const sitters = response?.data?.filter((sitter: any) => !sitter.isApproved).map((sitter: any) => ({
    ...sitter,
    firstName: sitter.firstName || 'Unknown',
    lastName: sitter.lastName || 'User',
    displayName: sitter.firstName && sitter.lastName 
      ? `${sitter.firstName} ${sitter.lastName.charAt(0)}.`
      : sitter.firstName || 'Unknown User'
  })) || [];

  const approveMutation = useMutation({
    mutationFn: async (sitterId: number) => {
      await apiRequest('POST', `/api/sitters/${sitterId}/approve`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sitters'] });
      toast({
        title: "Sitter Approved",
        description: "The sitter has been approved and notified via email.",
      });
    },
    onError: () => {
      toast({
        title: "Approval Failed",
        description: "Failed to approve sitter. Please try again.",
        variant: "destructive",
      });
    },
  });

  const rejectMutation = useMutation({
    mutationFn: async ({ sitterId, reason }: { sitterId: number; reason?: string }) => {
      await apiRequest('POST', `/api/sitters/${sitterId}/reject`, { reason });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sitters'] });
      toast({
        title: "Sitter Rejected",
        description: "The sitter has been rejected and notified via email.",
      });
    },
    onError: () => {
      toast({
        title: "Rejection Failed",
        description: "Failed to reject sitter. Please try again.",
        variant: "destructive",
      });
    },
  });
  
  const notifySitter = async (sitterId: string) => {
    toast({
      title: "Sending notification...",
      description: "Attempting to send push notification to sitter"
    });
    
    try {
      // Get subscription for this sitter
      const { data: subscriptions } = await supabase
        .from('subscriptions')
        .select('*')
        .eq('user_id', sitterId);
      
      if (!subscriptions || subscriptions.length === 0) {
        toast({
          title: "No subscriptions found",
          description: "This sitter hasn't enabled push notifications yet",
          variant: "destructive"
        });
        return;
      }
      
      // For each subscription, send a push notification
      for (const sub of subscriptions) {
        // In a real implementation, this would point to your Supabase function URL
        const functionUrl = 'https://your-project-id.functions.supabase.co/send-push';
        
        // For demo purposes, just show a success toast
        toast({
          title: "Notification sent",
          description: "Push notification sent successfully",
          variant: "default"
        });
        
        /* In production, uncomment this:
        await fetch(functionUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            subscription: sub,
            title: "New Booking Alert",
            body: "You've got a new booking request! 🎉 Check your dashboard.",
          }),
        });
        */
      }
    } catch (error) {
      console.error('Error sending notification:', error);
      toast({
        title: "Failed to send notification",
        description: "There was an error sending the push notification",
        variant: "destructive"
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Sitter Approvals</h1>
      
      {sitters && sitters.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sitters.map((sitter: any) => (
            <Card key={sitter.id} className="overflow-hidden">
              <CardHeader className="bg-muted pb-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center space-x-4">
                    <Avatar className="h-10 w-10">
                      <AvatarImage src={sitter.photoUrl} alt={`${sitter.firstName} ${sitter.lastName}`} />
                      <AvatarFallback>
                        <UserIcon className="h-6 w-6" />
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <CardTitle className="text-lg">
                        {sitter.displayName}
                      </CardTitle>
                      <p className="text-sm text-muted-foreground">{sitter.email}</p>
                    </div>
                  </div>
                  <Badge variant="outline">Pending</Badge>
                </div>
              </CardHeader>
              
              <CardContent className="p-6">
                <div className="space-y-4">
                  <div>
                    <p className="text-sm font-medium mb-1">Hourly Rate:</p>
                    <p className="text-lg font-semibold">${parseFloat(sitter.hourlyRate).toFixed(2)}</p>
                  </div>
                  
                  {sitter.bio && (
                    <div>
                      <p className="text-sm font-medium mb-1">Bio:</p>
                      <p className="text-sm">{sitter.bio}</p>
                    </div>
                  )}
                  
                  {sitter.experience && (
                    <div>
                      <p className="text-sm font-medium mb-1">Experience:</p>
                      <p className="text-sm">{sitter.experience}</p>
                    </div>
                  )}
                  
                  <div className="grid grid-cols-1 gap-2 pt-4">
                    <Button 
                      variant="secondary"
                      className="w-full flex items-center bg-eucalyptus text-white hover:bg-eucalyptus/90"
                      onClick={() => notifySitter(sitter.id)}
                    >
                      <Bell className="mr-2 h-4 w-4" />
                      Notify Sitter
                    </Button>
                    
                    <div className="flex justify-between space-x-4">
                      <Button 
                        variant="outline" 
                        className="w-full flex items-center" 
                        onClick={() => rejectMutation.mutate({ sitterId: sitter.id })}
                        disabled={rejectMutation.isPending}
                      >
                        {rejectMutation.isPending ? (
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        ) : (
                          <XCircle className="mr-2 h-4 w-4" />
                        )}
                        Reject
                      </Button>
                      <Button 
                        className="w-full flex items-center"
                        onClick={() => approveMutation.mutate(sitter.id)}
                        disabled={approveMutation.isPending}
                      >
                        {approveMutation.isPending ? (
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        ) : (
                          <CheckCircle className="mr-2 h-4 w-4" />
                        )}
                        Approve
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16">
            <CheckCircle className="h-12 w-12 text-primary mb-4" />
            <h3 className="text-lg font-medium mb-2">No Pending Approvals</h3>
            <p className="text-muted-foreground text-center max-w-md">
              There are no sitters waiting for approval at the moment.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default SitterApprovals;