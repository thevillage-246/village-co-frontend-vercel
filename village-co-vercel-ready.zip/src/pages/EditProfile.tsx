import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useUser } from '@/hooks/use-user';
import { useLocation } from 'wouter';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { ArrowLeft, Save, User, MapPin, Settings, Shield, Camera } from 'lucide-react';
import EditSitterProfileForm from '@/components/sitters/EditSitterProfileForm';
import EditParentProfileForm from '@/components/parents/EditParentProfileForm';
import EditUserAccountForm from '@/components/shared/EditUserAccountForm';
import PhotoUpload from '@/components/shared/PhotoUpload';

export default function EditProfile() {
  const [activeTab, setActiveTab] = useState('basic');
  const [, navigate] = useLocation();
  const { user } = useUser();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: userProfile, isLoading: userLoading } = useQuery({
    queryKey: ['/api/auth/me'],
    queryFn: () => apiRequest('GET', '/api/auth/me').then(res => res.json()),
    retry: 3
  });

  const { data: profile, isLoading: profileLoading } = useQuery({
    queryKey: user?.role === 'sitter' ? ['/api/sitter/profile'] : ['/api/parent/profile'],
    queryFn: () => {
      const endpoint = user?.role === 'sitter' ? '/api/sitter/profile' : '/api/parent/profile';
      return apiRequest('GET', endpoint).then(res => res.json());
    },
    enabled: !!user?.role
  });

  const updatePhotoMutation = useMutation({
    mutationFn: (photoData: { photoUrl: string }) => 
      apiRequest('PUT', '/api/auth/profile-photo', photoData),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
      if (user?.role === 'sitter') {
        queryClient.invalidateQueries({ queryKey: ['/api/sitter/profile'] });
      }
      toast({
        title: "Photo Updated",
        description: "Your profile photo has been updated successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Update Failed",
        description: "Failed to update profile photo. Please try again.",
        variant: "destructive",
      });
    }
  });

  if (userLoading || profileLoading) {
    return (
      <div className="min-h-screen bg-[#F9F5F0] p-4">
        <div className="max-w-4xl mx-auto">
          <div className="animate-pulse space-y-6">
            <div className="h-8 bg-white rounded-xl w-1/3"></div>
            <div className="h-96 bg-white rounded-xl"></div>
          </div>
        </div>
      </div>
    );
  }

  // Handle case where user profile might be null or missing firstName/lastName
  if (!userProfile) {
    return (
      <div className="min-h-screen bg-[#F9F5F0] p-4">
        <div className="max-w-4xl mx-auto">
          <Card className="bg-white rounded-xl shadow-lg border-0">
            <CardContent className="p-6">
              <div className="text-center">
                <p className="text-gray-600">Unable to load user profile. Please try refreshing the page.</p>
                <Button 
                  onClick={() => window.location.reload()} 
                  className="mt-4 bg-[#6B3E4B] hover:bg-[#5A334A] text-white"
                >
                  Refresh Page
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const handleGoBack = () => {
    if (user?.role === 'sitter') {
      navigate('/sitter/dashboard');
    } else {
      navigate('/parent/dashboard');
    }
  };

  return (
    <div className="min-h-screen bg-[#F9F5F0] p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <Button
            variant="ghost"
            onClick={handleGoBack}
            className="flex items-center gap-2 text-[#6B3E4B] hover:bg-white/50"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Dashboard
          </Button>
          <h1 className="text-2xl font-bold text-[#6B3E4B] font-['Satoshi']">
            Edit Profile
          </h1>
        </div>

        {/* Profile Photo Section */}
        <Card className="bg-white rounded-xl shadow-lg border-0">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-[#6B3E4B] font-['Satoshi']">
              <Camera className="h-5 w-5" />
              Profile Photo
            </CardTitle>
            <CardDescription className="font-['DM_Sans']">
              Update your profile picture
            </CardDescription>
          </CardHeader>
          <CardContent>
            <PhotoUpload
              currentPhotoUrl={userProfile?.photoUrl}
              onPhotoUpdate={(photoUrl) => updatePhotoMutation.mutate({ photoUrl })}
              isLoading={updatePhotoMutation.isPending}
            />
          </CardContent>
        </Card>

        {/* Edit Forms */}
        <Card className="bg-white rounded-xl shadow-lg border-0">
          <CardContent className="p-0">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <div className="border-b px-6 pt-6">
                <TabsList className="grid w-full grid-cols-3 bg-[#F9F5F0]">
                  <TabsTrigger 
                    value="basic" 
                    className="flex items-center gap-2 data-[state=active]:bg-white data-[state=active]:text-[#6B3E4B]"
                  >
                    <User className="h-4 w-4" />
                    Basic Info
                  </TabsTrigger>
                  <TabsTrigger 
                    value="profile" 
                    className="flex items-center gap-2 data-[state=active]:bg-white data-[state=active]:text-[#6B3E4B]"
                  >
                    <MapPin className="h-4 w-4" />
                    {user?.role === 'sitter' ? 'Sitter Profile' : 'Family Profile'}
                  </TabsTrigger>
                  <TabsTrigger 
                    value="account" 
                    className="flex items-center gap-2 data-[state=active]:bg-white data-[state=active]:text-[#6B3E4B]"
                  >
                    <Settings className="h-4 w-4" />
                    Account Settings
                  </TabsTrigger>
                </TabsList>
              </div>

              <div className="p-6">
                <TabsContent value="basic" className="mt-0">
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-[#6B3E4B] font-['Satoshi']">
                      Personal Information
                    </h3>
                    <EditUserAccountForm 
                      userProfile={userProfile} 
                      onSuccess={() => queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] })}
                    />
                  </div>
                </TabsContent>

                <TabsContent value="profile" className="mt-0">
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-[#6B3E4B] font-['Satoshi']">
                      {user?.role === 'sitter' ? 'Sitter Profile Details' : 'Family Profile Details'}
                    </h3>
                    {user?.role === 'sitter' ? (
                      <EditSitterProfileForm 
                        profile={profile} 
                        onSuccess={() => queryClient.invalidateQueries({ queryKey: ['/api/sitter/profile'] })}
                      />
                    ) : (
                      <EditParentProfileForm 
                        profile={profile} 
                        onSuccess={() => queryClient.invalidateQueries({ queryKey: ['/api/parent/profile'] })}
                      />
                    )}
                  </div>
                </TabsContent>

                <TabsContent value="account" className="mt-0">
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-[#6B3E4B] font-['Satoshi']">
                      Account & Privacy Settings
                    </h3>
                    <div className="p-4 bg-[#F9F5F0] rounded-xl">
                      <p className="text-sm text-gray-600 font-['DM_Sans']">
                        Password and security settings can be accessed from your main dashboard.
                      </p>
                      <Button
                        onClick={() => navigate(user?.role === 'sitter' ? '/sitter/dashboard' : '/parent/dashboard')}
                        className="mt-3 bg-[#6B3E4B] hover:bg-[#5A334A] text-white"
                      >
                        Go to Security Settings
                      </Button>
                    </div>
                  </div>
                </TabsContent>
              </div>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}