import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CheckCircle, Calendar, Shield, Heart, Phone } from 'lucide-react';
import { Link } from 'wouter';

export default function SitterOnboardingThankYou() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-linen via-brushed-pink/20 to-white">
      <div className="container mx-auto px-4 py-12 max-w-2xl">
        {/* Success Header */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-6">
            <div className="bg-gradient-to-br from-green-500 to-green-600 p-4 rounded-full">
              <CheckCircle className="h-12 w-12 text-white" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-village-wine mb-4">
            Thank You for Applying!
          </h1>
          <p className="text-xl text-taupe mb-2">
            Welcome to The Village Co. family
          </p>
          <p className="text-gray-600 max-w-lg mx-auto">
            Your application has been received and added to our review process. We're excited to have you join our community of trusted sitters.
          </p>
        </div>

        {/* Application Status Card */}
        <Card className="mb-8 border-village-wine/20 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-village-wine">
              <Calendar className="h-5 w-5" />
              What Happens Next?
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Step 1 */}
            <div className="flex items-start gap-4">
              <div className="bg-village-wine/10 p-2 rounded-full flex-shrink-0">
                <Shield className="h-5 w-5 text-village-wine" />
              </div>
              <div>
                <h3 className="font-semibold text-village-wine mb-1">
                  1. Application Review (1-2 business days)
                </h3>
                <p className="text-sm text-gray-600">
                  Our team will review your application, verify your documents, and check your references. We'll keep you updated via email throughout the process.
                </p>
              </div>
            </div>

            {/* Step 2 */}
            <div className="flex items-start gap-4">
              <div className="bg-village-wine/10 p-2 rounded-full flex-shrink-0">
                <Phone className="h-5 w-5 text-village-wine" />
              </div>
              <div>
                <h3 className="font-semibold text-village-wine mb-1">
                  2. Welcome Call with Our Team
                </h3>
                <p className="text-sm text-gray-600 mb-3">
                  Once approved, we'll schedule a friendly 15-minute welcome call to introduce you to the platform and answer any questions.
                </p>
                <Button 
                  asChild
                  className="bg-village-wine hover:bg-village-wine/90 text-white"
                >
                  <a 
                    href="https://babysitting.thevillageco.nz/meetings/nikki209" 
                    target="_blank" 
                    rel="noopener noreferrer"
                  >
                    <Calendar className="h-4 w-4 mr-2" />
                    Book Your Welcome Call
                  </a>
                </Button>
              </div>
            </div>

            {/* Step 3 */}
            <div className="flex items-start gap-4">
              <div className="bg-village-wine/10 p-2 rounded-full flex-shrink-0">
                <Heart className="h-5 w-5 text-village-wine" />
              </div>
              <div>
                <h3 className="font-semibold text-village-wine mb-1">
                  3. Start Receiving Booking Requests
                </h3>
                <p className="text-sm text-gray-600">
                  After your welcome call, your profile will go live and you'll start receiving booking requests from families in your area.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Contact Information */}
        <Card className="mb-8 bg-village-wine/5 border-village-wine/20">
          <CardContent className="pt-6">
            <div className="text-center">
              <h3 className="font-semibold text-village-wine mb-2">
                Questions or Need Help?
              </h3>
              <p className="text-sm text-gray-600 mb-4">
                Our team is here to support you every step of the way
              </p>
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <Button variant="outline" asChild>
                  <a href="mailto:info@thevillageco.nz">
                    Email Support
                  </a>
                </Button>
                <Button variant="outline" asChild>
                  <Link href="/faq">
                    View FAQ
                  </Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Return to Home */}
        <div className="text-center">
          <Button 
            asChild
            variant="outline" 
            className="border-village-wine text-village-wine hover:bg-village-wine hover:text-white"
          >
            <Link href="/">
              Return to Home
            </Link>
          </Button>
        </div>
      </div>
    </div>
  );
}