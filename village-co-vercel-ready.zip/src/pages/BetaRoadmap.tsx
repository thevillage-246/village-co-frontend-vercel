import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  CheckCircle, 
  Clock, 
  Zap, 
  Shield, 
  Crown, 
  Globe,
  Calendar,
  ArrowRight
} from "lucide-react";
import { Link } from "wouter";
import SEO from "@/components/SEO";

export default function BetaRoadmap() {
  const roadmapPhases = [
    {
      phase: "July 2025",
      title: "Beta Launch",
      status: "complete",
      icon: <CheckCircle className="h-6 w-6 text-green-600" />,
      features: [
        "Core booking platform live",
        "10+ verified sitters per city", 
        "Real-time messaging",
        "Mobile-optimized experience",
        "Secure Stripe payments",
        "$2M liability insurance"
      ],
      description: "Foundation platform with essential booking and communication features"
    },
    {
      phase: "August 2025", 
      title: "Smart Matching",
      status: "in-progress",
      icon: <Zap className="h-6 w-6 text-blue-600" />,
      features: [
        "AI-powered sitter recommendations",
        "Recurring booking templates",
        "Enhanced search filters", 
        "In-app video calling",
        "Advanced availability matching",
        "Family preference learning"
      ],
      description: "Intelligent features that learn your family's needs and preferences"
    },
    {
      phase: "September 2025",
      title: "Safety Plus",
      status: "planned",
      icon: <Shield className="h-6 w-6 text-purple-600" />,
      features: [
        "Live location tracking during sits",
        "Child update photos and notes",
        "Emergency contact automation",
        "Advanced verification workflows",
        "Mood tracking for children",
        "Safety protocol reminders"
      ],
      description: "Enhanced safety features for ultimate peace of mind"
    },
    {
      phase: "October 2025",
      title: "Village Plans Launch", 
      status: "planned",
      icon: <Crown className="h-6 w-6 text-yellow-600" />,
      features: [
        "Subscription tiers with perks",
        "Priority booking access",
        "Family events and workshops",
        "Loyalty rewards program",
        "Exclusive sitter network",
        "Advanced booking analytics"
      ],
      description: "Premium membership with exclusive benefits and community features"
    },
    {
      phase: "November 2025",
      title: "Expansion Ready",
      status: "planned", 
      icon: <Globe className="h-6 w-6 text-indigo-600" />,
      features: [
        "Melbourne and Sydney launch",
        "Corporate partnerships",
        "Hotel babysitting services",
        "Advanced analytics dashboard",
        "Multi-language support",
        "International payment methods"
      ],
      description: "Scale across Australia and establish enterprise partnerships"
    }
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'complete':
        return <Badge className="bg-green-100 text-green-800">Complete</Badge>;
      case 'in-progress':
        return <Badge className="bg-blue-100 text-blue-800">In Progress</Badge>;
      case 'planned':
        return <Badge className="bg-gray-100 text-gray-700">Planned</Badge>;
      default:
        return null;
    }
  };

  return (
    <>
      <SEO 
        title="Beta Roadmap - The Village Co. Development Timeline"
        description="See what's coming next for The Village Co. babysitting platform. From smart matching to safety features and expansion plans."
      />
      
      <div className="min-h-screen bg-bone">
        {/* Hero Section */}
        <section className="bg-village-wine text-white py-16">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="w-16 h-16 bg-linen/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Calendar className="h-8 w-8 text-linen" />
            </div>
            
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              The Village Co. Roadmap
            </h1>
            
            <p className="text-xl text-brushed-pink mb-8 max-w-2xl mx-auto">
              See what's coming next as we build New Zealand's most trusted 
              babysitting platform together with our beta families.
            </p>
            
            <div className="flex justify-center gap-4">
              <Link href="/beta-welcome">
                <button className="text-linen hover:text-white transition-colors">
                  ← Back to Beta Welcome
                </button>
              </Link>
            </div>
          </div>
        </section>

        {/* Progress Overview */}
        <section className="py-12 bg-gray-50">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card className="border-green-200 bg-green-50">
                <CardContent className="p-6 text-center">
                  <CheckCircle className="h-8 w-8 text-green-600 mx-auto mb-3" />
                  <h3 className="font-bold text-green-800 text-xl mb-2">1</h3>
                  <p className="text-green-700">Phase Complete</p>
                </CardContent>
              </Card>
              
              <Card className="border-blue-200 bg-blue-50">
                <CardContent className="p-6 text-center">
                  <Clock className="h-8 w-8 text-blue-600 mx-auto mb-3" />
                  <h3 className="font-bold text-blue-800 text-xl mb-2">1</h3>
                  <p className="text-blue-700">Phase In Progress</p>
                </CardContent>
              </Card>
              
              <Card className="border-purple-200 bg-purple-50">
                <CardContent className="p-6 text-center">
                  <Calendar className="h-8 w-8 text-purple-600 mx-auto mb-3" />
                  <h3 className="font-bold text-purple-800 text-xl mb-2">3</h3>
                  <p className="text-purple-700">Phases Planned</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* Roadmap Timeline */}
        <section className="py-16">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="space-y-8">
              {roadmapPhases.map((phase, index) => (
                <Card key={index} className={`border-l-4 ${
                  phase.status === 'complete' ? 'border-l-green-500' :
                  phase.status === 'in-progress' ? 'border-l-blue-500' :
                  'border-l-gray-300'
                }`}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        {phase.icon}
                        <div>
                          <CardTitle className="text-village-wine">{phase.title}</CardTitle>
                          <p className="text-sm text-gray-600">{phase.phase}</p>
                        </div>
                      </div>
                      {getStatusBadge(phase.status)}
                    </div>
                  </CardHeader>
                  
                  <CardContent>
                    <p className="text-gray-700 mb-4">{phase.description}</p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {phase.features.map((feature, featureIndex) => (
                        <div key={featureIndex} className="flex items-center gap-2">
                          <div className={`w-2 h-2 rounded-full ${
                            phase.status === 'complete' ? 'bg-green-500' :
                            phase.status === 'in-progress' ? 'bg-blue-500' :
                            'bg-gray-400'
                          }`}></div>
                          <span className="text-sm text-gray-700">{feature}</span>
                        </div>
                      ))}
                    </div>
                    
                    {index < roadmapPhases.length - 1 && (
                      <div className="flex justify-center mt-6">
                        <ArrowRight className="h-6 w-6 text-gray-400" />
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Beta Feedback CTA */}
        <section className="py-16 bg-village-wine text-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl font-bold mb-6">Help Shape Our Future</h2>
            <p className="text-xl text-brushed-pink mb-8">
              Your feedback as a beta tester directly influences what we build next. 
              Which features excite you most?
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button 
                onClick={() => window.open('mailto:beta@thevillageco.nz?subject=Roadmap Feedback')}
                className="bg-linen text-village-wine hover:bg-almond-frost px-6 py-3 rounded-lg font-medium transition-colors"
              >
                Share Feedback
              </button>
              
              <Link href="/find-sitter">
                <button className="border border-linen text-linen hover:bg-linen hover:text-village-wine px-6 py-3 rounded-lg font-medium transition-colors">
                  Try Current Features
                </button>
              </Link>
            </div>
          </div>
        </section>

        {/* Updates Section */}
        <section className="py-12 bg-gray-50">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h3 className="text-xl font-semibold text-village-wine mb-4">Stay Updated</h3>
            <p className="text-gray-600 mb-6">
              We'll send weekly updates on our progress and new feature releases
            </p>
            
            <div className="flex justify-center gap-6">
              <a href="mailto:beta@thevillageco.nz" className="text-village-wine hover:underline">
                Email Updates
              </a>
              <span className="text-gray-400">•</span>
              <a href="https://instagram.com/thevillageco.nz" className="text-village-wine hover:underline">
                Instagram
              </a>
              <span className="text-gray-400">•</span>
              <Link href="/support">
                <span className="text-village-wine hover:underline cursor-pointer">
                  Support
                </span>
              </Link>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}