import React from "react";
import { Helmet } from "react-helmet";
import { useAuth } from "@/contexts/AuthContext";
import VillageAIAssistant from "@/components/VillageAIAssistant";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Heart } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function AIAssistantPage() {
  const { currentUser } = useAuth();

  if (!currentUser) {
    return (
      <>
        <Helmet>
          <title>AI Assistant - Your Parenting Co-pilot | The Village Co.</title>
          <meta name="description" content="Your AI-powered parenting assistant that thinks like a village, not an algorithm. Get smart childcare insights, booking analysis, and personalised recommendations in New Zealand." />
          <meta property="og:title" content="AI Assistant - Your Parenting Co-pilot | The Village Co." />
          <meta property="og:description" content="AI-powered parenting support with smart matching, safety analysis, and personalised childcare recommendations for New Zealand families." />
          <meta property="og:type" content="website" />
        </Helmet>
        <div className="min-h-screen bg-gradient-to-br from-rose-50 to-orange-50 flex items-center justify-center p-6">
          <Card className="max-w-md w-full">
            <CardHeader className="text-center">
              <Heart className="h-12 w-12 text-[#8B4B5C] mx-auto mb-4" />
              <CardTitle>Your Village Assistant</CardTitle>
              <CardDescription>
                Please sign in to access your personal parenting sidekick and lifestyle assistant.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button className="w-full bg-[#8B4B5C] hover:bg-[#7A4051]" onClick={() => window.location.href = "/login"}>
                Sign In to Your Village
              </Button>
            </CardContent>
          </Card>
        </div>
      </>
    );
  }

  return (
    <>
      <Helmet>
        <title>AI Assistant - Your Parenting Co-pilot | The Village Co.</title>
        <meta name="description" content="Your AI-powered parenting assistant that thinks like a village, not an algorithm. Get smart childcare insights, booking analysis, and personalised recommendations in New Zealand." />
        <meta property="og:title" content="AI Assistant - Your Parenting Co-pilot | The Village Co." />
        <meta property="og:description" content="AI-powered parenting support with smart matching, safety analysis, and personalised childcare recommendations for New Zealand families." />
        <meta property="og:type" content="website" />
      </Helmet>
      <VillageAIAssistant userRole={currentUser.role} />
    </>
  );
}