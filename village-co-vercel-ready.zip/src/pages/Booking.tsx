import React, { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient } from '@/lib/queryClient';
import { format, parseISO } from 'date-fns';
import { useParams, useLocation } from 'wouter';
import { useAuth } from '@/contexts/AuthContext';
import { apiRequest } from '@/lib/queryClient';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription, 
  CardFooter 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import { 
  AlertDialog, 
  AlertDialogAction, 
  AlertDialogCancel, 
  AlertDialogContent, 
  AlertDialogDescription, 
  AlertDialogFooter, 
  AlertDialogHeader, 
  AlertDialogTitle 
} from '@/components/ui/alert-dialog';
import {
  Clock,
  Calendar,
  MapPin,
  DollarSign,
  Users,
  MessageSquare,
  User,
  ChevronLeft,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Send,
  Baby
} from 'lucide-react';
import { USER_ROLES, BOOKING_STATUS } from '@shared/schema';
import { useToast } from '@/hooks/use-toast';

const Booking: React.FC = () => {
  const { id } = useParams();
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [showAcceptDialog, setShowAcceptDialog] = useState(false);
  const [showDeclineDialog, setShowDeclineDialog] = useState(false);
  const [showCompleteDialog, setShowCompleteDialog] = useState(false);
  const [reviewDialogOpen, setReviewDialogOpen] = useState(false);
  const [reviewMessage, setReviewMessage] = useState('');
  const [rating, setRating] = useState(5);
  const [messageText, setMessageText] = useState('');

  const bookingId = id ? parseInt(id) : 0;

  // Fetch booking details
  const { data: booking, isLoading: loadingBooking } = useQuery({
    queryKey: [`/api/bookings/${bookingId}`],
    enabled: !!bookingId,
  });

  // Fetch parent or sitter details
  const { data: parentProfile, isLoading: loadingParent } = useQuery({
    queryKey: [`/api/parents/${booking?.parentId}/profile`],
    enabled: !!booking?.parentId && user?.role === USER_ROLES.SITTER,
  });

  const { data: sitterProfile, isLoading: loadingSitter } = useQuery({
    queryKey: [`/api/sitters/${booking?.sitterId}/profile`],
    enabled: !!booking?.sitterId && user?.role === USER_ROLES.PARENT,
  });

  // Fetch parent user
  const { data: parentUser, isLoading: loadingParentUser } = useQuery({
    queryKey: [`/api/users/${parentProfile?.userId}`],
    enabled: !!parentProfile?.userId,
  });

  // Fetch sitter user
  const { data: sitterUser, isLoading: loadingSitterUser } = useQuery({
    queryKey: [`/api/users/${sitterProfile?.userId}`],
    enabled: !!sitterProfile?.userId,
  });

  // Fetch children
  const { data: children, isLoading: loadingChildren } = useQuery({
    queryKey: [`/api/parents/${booking?.parentId}/children`],
    enabled: !!booking?.parentId,
  });

  // Fetch messages
  const { data: messages, isLoading: loadingMessages } = useQuery({
    queryKey: [`/api/bookings/${bookingId}/messages`],
    enabled: !!bookingId && booking?.status === BOOKING_STATUS.ACCEPTED,
    refetchInterval: 3000, // Poll every 3 seconds for new messages
  });

  // Mutations
  const acceptMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('POST', `/api/bookings/${bookingId}/accept`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/bookings/${bookingId}`] });
      toast({
        title: 'Booking Accepted',
        description: 'The booking has been accepted successfully.',
      });
      setShowAcceptDialog(false);
    },
    onError: (error: any) => {
      toast({
        title: 'Error Accepting Booking',
        description: error.message || 'There was an error accepting the booking.',
        variant: 'destructive',
      });
    },
  });

  const declineMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('POST', `/api/bookings/${bookingId}/decline`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/bookings/${bookingId}`] });
      toast({
        title: 'Booking Declined',
        description: 'The booking has been declined.',
      });
      setShowDeclineDialog(false);
    },
    onError: (error: any) => {
      toast({
        title: 'Error Declining Booking',
        description: error.message || 'There was an error declining the booking.',
        variant: 'destructive',
      });
    },
  });

  const completeMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('POST', `/api/bookings/${bookingId}/complete`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/bookings/${bookingId}`] });
      toast({
        title: 'Booking Completed',
        description: 'The booking has been marked as completed.',
      });
      setShowCompleteDialog(false);
      setReviewDialogOpen(true);
    },
    onError: (error: any) => {
      toast({
        title: 'Error Completing Booking',
        description: error.message || 'There was an error completing the booking.',
        variant: 'destructive',
      });
    },
  });

  const messageMutation = useMutation({
    mutationFn: async (message: string) => {
      await apiRequest('POST', `/api/bookings/${bookingId}/messages`, {
        senderId: user?.id,
        content: message,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/bookings/${bookingId}/messages`] });
      setMessageText('');
    },
    onError: (error: any) => {
      toast({
        title: 'Error Sending Message',
        description: error.message || 'There was an error sending your message.',
        variant: 'destructive',
      });
    },
  });

  const reviewMutation = useMutation({
    mutationFn: async () => {
      // Determine reviewee - if user is parent, review the sitter and vice versa
      const revieweeId = user?.role === USER_ROLES.PARENT 
        ? sitterProfile?.userId 
        : parentProfile?.userId;
      
      if (!revieweeId) throw new Error('Could not determine who to review');
      
      await apiRequest('POST', `/api/bookings/${bookingId}/reviews`, {
        reviewerId: user?.id,
        revieweeId,
        rating,
        comment: reviewMessage,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/sitters/${booking?.sitterId}/reviews`] });
      toast({
        title: 'Review Submitted',
        description: 'Thank you for your feedback!',
      });
      setReviewDialogOpen(false);
      setReviewMessage('');
      setRating(5);
    },
    onError: (error: any) => {
      toast({
        title: 'Error Submitting Review',
        description: error.message || 'There was an error submitting your review.',
        variant: 'destructive',
      });
    },
  });

  // Check if current user is the sitter for this booking
  const isUserTheSitter = user?.id === sitterProfile?.userId;
  
  // Check if current user is the parent for this booking
  const isUserTheParent = user?.id === parentProfile?.userId;

  // Format times
  const formatBookingTime = () => {
    if (!booking) return { date: '', timeRange: '' };
    
    const startTime = parseISO(booking.startTime);
    const endTime = parseISO(booking.endTime);
    const date = format(startTime, 'EEEE, MMMM d, yyyy');
    const timeRange = `${format(startTime, 'h:mm a')} - ${format(endTime, 'h:mm a')}`;
    
    return { date, timeRange };
  };

  // Calculate duration
  const calculateDuration = () => {
    if (!booking) return 0;
    
    const startTime = parseISO(booking.startTime);
    const endTime = parseISO(booking.endTime);
    return Math.round((endTime.getTime() - startTime.getTime()) / (1000 * 60 * 60) * 10) / 10;
  };

  // Get status badge color
  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case BOOKING_STATUS.PENDING:
        return 'warning';
      case BOOKING_STATUS.ACCEPTED:
        return 'success';
      case BOOKING_STATUS.DECLINED:
        return 'destructive';
      case BOOKING_STATUS.COMPLETED:
        return 'default';
      case BOOKING_STATUS.CANCELLED:
        return 'secondary';
      default:
        return 'default';
    }
  };

  const handleSendMessage = () => {
    if (!messageText.trim()) return;
    messageMutation.mutate(messageText);
  };

  const handleSubmitReview = () => {
    if (!reviewMessage.trim()) {
      toast({
        title: 'Review Required',
        description: 'Please provide some feedback in your review.',
        variant: 'destructive',
      });
      return;
    }
    
    reviewMutation.mutate();
  };

  if (loadingBooking || loadingParent || loadingSitter || loadingParentUser || loadingSitterUser || loadingChildren) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!booking) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16">
            <AlertTriangle className="h-12 w-12 text-warning mb-4" />
            <h3 className="text-lg font-medium mb-2">Booking Not Found</h3>
            <p className="text-muted-foreground text-center max-w-md mb-6">
              The booking you're looking for could not be found or may have been deleted.
            </p>
            <Button onClick={() => navigate('/')}>
              Return Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { date, timeRange } = formatBookingTime();
  const durationHours = calculateDuration();

  // Determine who the other person is
  const otherPerson = isUserTheSitter
    ? { name: `${parentUser?.firstName} ${parentUser?.lastName}`, role: 'Parent' }
    : { name: `${sitterUser?.firstName} ${sitterUser?.lastName}`, role: 'Sitter' };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Button
          variant="ghost"
          className="mb-4"
          onClick={() => window.history.back()}
        >
          <ChevronLeft className="mr-2 h-4 w-4" />
          Back
        </Button>
        
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold">Booking Details</h1>
            <p className="text-muted-foreground mt-1">
              Booking with {otherPerson.name} ({otherPerson.role})
            </p>
          </div>
          <Badge 
            className="mt-2 sm:mt-0 self-start sm:self-auto"
            variant={getStatusBadgeVariant(booking.status)}
          >
            {booking.status}
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Main content */}
        <div className="md:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Booking Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div className="flex items-center">
                    <Calendar className="h-4 w-4 mr-2 text-muted-foreground" />
                    <span>{date}</span>
                  </div>
                  
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-2 text-muted-foreground" />
                    <span>{timeRange} ({durationHours} hours)</span>
                  </div>
                  
                  {booking.location && (
                    <div className="flex items-center">
                      <MapPin className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span>{booking.location}</span>
                    </div>
                  )}
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center">
                    <DollarSign className="h-4 w-4 mr-2 text-muted-foreground" />
                    <span className="font-medium">${parseFloat(booking.totalAmount).toFixed(2)}</span>
                  </div>
                  
                  <div className="flex items-center">
                    <Users className="h-4 w-4 mr-2 text-muted-foreground" />
                    <span>
                      {children?.length || 0} {children?.length === 1 ? 'child' : 'children'}
                    </span>
                  </div>
                  
                  {booking.createdAt && (
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-2 text-muted-foreground" />
                      <span className="text-sm text-muted-foreground">
                        Requested on {format(parseISO(booking.createdAt), 'MMM d, yyyy h:mm a')}
                      </span>
                    </div>
                  )}
                </div>
              </div>
              
              {booking.specialRequests && (
                <div className="mt-4 pt-4 border-t">
                  <h3 className="text-sm font-medium mb-2">Special Requests:</h3>
                  <p className="text-sm">{booking.specialRequests}</p>
                </div>
              )}
              
              {booking.sitNotes && (
                <div className="mt-4 pt-4 border-t">
                  <div className="bg-rose/10 text-rose px-4 py-3 rounded">
                    <h4 className="font-semibold mb-1">Additional Sit Details</h4>
                    <p className="text-sm">{booking.sitNotes}</p>
                  </div>
                </div>
              )}
            </CardContent>
            
            {/* Actions available based on status */}
            {booking.status === BOOKING_STATUS.PENDING && isUserTheSitter && (
              <CardFooter className="border-t bg-muted/50 flex justify-end space-x-4">
                <Button 
                  variant="outline" 
                  onClick={() => setShowDeclineDialog(true)}
                >
                  <XCircle className="mr-2 h-4 w-4" />
                  Decline
                </Button>
                <Button 
                  onClick={() => setShowAcceptDialog(true)}
                >
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Accept
                </Button>
              </CardFooter>
            )}
            
            {booking.status === BOOKING_STATUS.ACCEPTED && (
              <CardFooter className="border-t bg-muted/50 flex justify-end">
                <Button 
                  onClick={() => setShowCompleteDialog(true)}
                >
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Mark as Completed
                </Button>
              </CardFooter>
            )}
          </Card>

          {/* Children Section */}
          {children && children.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Children</CardTitle>
                <CardDescription>Information about the children</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {children.map((child: any) => (
                    <div key={child.id} className="border p-4 rounded-md">
                      <div className="flex items-center mb-2">
                        <Baby className="h-5 w-5 mr-2 text-primary" />
                        <h3 className="font-medium">{child.firstName} {child.lastName}</h3>
                      </div>
                      
                      {child.birthDate && (
                        <p className="text-sm text-muted-foreground mb-2">
                          Born: {format(parseISO(child.birthDate), 'MMM d, yyyy')}
                        </p>
                      )}
                      
                      <div className="space-y-2 text-sm">
                        {child.specialNeeds && (
                          <div>
                            <span className="font-medium">Special Needs:</span> {child.specialNeeds}
                          </div>
                        )}
                        
                        {child.allergies && (
                          <div>
                            <span className="font-medium">Allergies:</span> {child.allergies}
                          </div>
                        )}
                        
                        {child.notes && (
                          <div>
                            <span className="font-medium">Notes:</span> {child.notes}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Messages Section - only show when booking is confirmed */}
          {booking.status === BOOKING_STATUS.ACCEPTED && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MessageSquare className="h-5 w-5 mr-2" />
                  Messages
                </CardTitle>
                <CardDescription>
                  Communication between you and {otherPerson.name}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {loadingMessages ? (
                  <div className="flex justify-center py-4">
                    <div className="animate-spin h-6 w-6 border-4 border-primary border-t-transparent rounded-full"></div>
                  </div>
                ) : messages && messages.length > 0 ? (
                  <div className="space-y-4 max-h-[400px] overflow-y-auto p-2 mb-4">
                    {messages.map((message: any) => {
                      const isCurrentUser = message.senderId === user?.id;
                      
                      return (
                        <div 
                          key={message.id} 
                          className={`flex ${isCurrentUser ? 'justify-end' : 'justify-start'}`}
                        >
                          <div 
                            className={`max-w-[80%] p-3 rounded-lg ${
                              isCurrentUser 
                                ? 'bg-primary text-primary-foreground rounded-br-none' 
                                : 'bg-muted rounded-bl-none'
                            }`}
                          >
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-xs font-medium">
                                {isCurrentUser ? 'You' : message.sender?.firstName}
                              </span>
                              <span className="text-xs opacity-70">
                                {format(parseISO(message.createdAt), 'h:mm a')}
                              </span>
                            </div>
                            <p>{message.content}</p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">
                    <MessageSquare className="h-12 w-12 mx-auto opacity-20 mb-2" />
                    <p>No messages yet. Start the conversation!</p>
                  </div>
                )}
                
                <div className="flex mt-4">
                  <Textarea
                    placeholder={`Message ${otherPerson.name}...`}
                    value={messageText}
                    onChange={(e) => setMessageText(e.target.value)}
                    className="min-h-[60px] flex-1 resize-none"
                  />
                  <Button 
                    className="ml-2 self-end" 
                    disabled={!messageText.trim() || messageMutation.isPending}
                    onClick={handleSendMessage}
                  >
                    {messageMutation.isPending ? (
                      <div className="animate-spin h-4 w-4 border-2 border-foreground border-t-transparent rounded-full" />
                    ) : (
                      <Send className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{otherPerson.role} Details</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-4 mb-4">
                <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center">
                  <User className="h-6 w-6 text-muted-foreground" />
                </div>
                <div>
                  <p className="font-medium">{otherPerson.name}</p>
                  <p className="text-sm text-muted-foreground">
                    {isUserTheSitter ? parentUser?.email : sitterUser?.email}
                  </p>
                </div>
              </div>
              
              {isUserTheParent && sitterProfile && (
                <div className="space-y-3 mt-4 pt-4 border-t">
                  <p className="font-medium text-sm">Sitter Information:</p>
                  <div className="text-sm">
                    <p><span className="font-medium">Hourly Rate:</span> ${parseFloat(sitterProfile.hourlyRate).toFixed(2)}</p>
                    {sitterProfile.experience && (
                      <p className="mt-1"><span className="font-medium">Experience:</span> {sitterProfile.experience}</p>
                    )}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Payment Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Hourly Rate</span>
                  <span>
                    ${isUserTheParent 
                      ? parseFloat(sitterProfile?.hourlyRate).toFixed(2) 
                      : (parseFloat(booking.totalAmount) / durationHours).toFixed(2)
                    }
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Duration</span>
                  <span>{durationHours} hours</span>
                </div>
                {isUserTheSitter && (
                  <div className="flex justify-between text-destructive">
                    <span>Platform Fee (10%)</span>
                    <span>-${parseFloat(booking.platformFee).toFixed(2)}</span>
                  </div>
                )}
                <div className="border-t pt-2 mt-2">
                  <div className="flex justify-between font-bold">
                    <span>{isUserTheSitter ? 'You Receive' : 'Total'}</span>
                    <span>
                      ${isUserTheSitter 
                        ? (parseFloat(booking.totalAmount) - parseFloat(booking.platformFee)).toFixed(2)
                        : parseFloat(booking.totalAmount).toFixed(2)
                      }
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-6 text-sm">
                <p className="text-muted-foreground">
                  {booking.status === BOOKING_STATUS.PENDING && 'Payment will be processed upon acceptance.'}
                  {booking.status === BOOKING_STATUS.ACCEPTED && 'Payment will be captured after job completion.'}
                  {booking.status === BOOKING_STATUS.COMPLETED && 'Payment has been processed.'}
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Support/Help Card */}
          <Card>
            <CardHeader>
              <CardTitle>Need Help?</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                If you have any questions or issues with this booking, our support team is here to help.
              </p>
              <Button variant="outline" className="w-full">
                Contact Support
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Accept Booking Dialog */}
      <AlertDialog open={showAcceptDialog} onOpenChange={setShowAcceptDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Accept Booking Request</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to accept this booking request? This will charge the parent and commit you to the scheduled time.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={() => acceptMutation.mutate()}
              disabled={acceptMutation.isPending}
            >
              {acceptMutation.isPending ? (
                <div className="animate-spin h-4 w-4 border-2 border-foreground border-t-transparent rounded-full mr-2" />
              ) : null}
              Accept Booking
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Decline Booking Dialog */}
      <AlertDialog open={showDeclineDialog} onOpenChange={setShowDeclineDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Decline Booking Request</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to decline this booking request? The parent will be notified and will need to find another sitter.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={() => declineMutation.mutate()}
              disabled={declineMutation.isPending}
              className="bg-destructive hover:bg-destructive/90"
            >
              {declineMutation.isPending ? (
                <div className="animate-spin h-4 w-4 border-2 border-foreground border-t-transparent rounded-full mr-2" />
              ) : null}
              Decline Booking
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Complete Booking Dialog */}
      <AlertDialog open={showCompleteDialog} onOpenChange={setShowCompleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Complete Booking</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to mark this booking as completed? This will process the payment and finalize the booking.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={() => completeMutation.mutate()}
              disabled={completeMutation.isPending}
            >
              {completeMutation.isPending ? (
                <div className="animate-spin h-4 w-4 border-2 border-foreground border-t-transparent rounded-full mr-2" />
              ) : null}
              Complete Booking
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Review Dialog */}
      <Dialog open={reviewDialogOpen} onOpenChange={setReviewDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Leave a Review</DialogTitle>
            <DialogDescription>
              Share your experience with {otherPerson.name}. Your feedback helps others in the community.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <div className="font-medium">Rating</div>
              <div className="flex items-center space-x-1">
                {[1, 2, 3, 4, 5].map(star => (
                  <button
                    key={star}
                    type="button"
                    className={`text-2xl ${rating >= star ? 'text-yellow-400' : 'text-gray-300'}`}
                    onClick={() => setRating(star)}
                  >
                    ★
                  </button>
                ))}
              </div>
            </div>
            <div className="space-y-2">
              <label htmlFor="review" className="font-medium">
                Your Review
              </label>
              <Textarea
                id="review"
                placeholder="Write your thoughts about the experience..."
                value={reviewMessage}
                onChange={e => setReviewMessage(e.target.value)}
                className="min-h-[120px]"
              />
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">Cancel</Button>
            </DialogClose>
            <Button 
              type="submit" 
              onClick={handleSubmitReview}
              disabled={reviewMutation.isPending}
            >
              {reviewMutation.isPending ? (
                <div className="animate-spin h-4 w-4 border-2 border-foreground border-t-transparent rounded-full mr-2" />
              ) : null}
              Submit Review
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Booking;