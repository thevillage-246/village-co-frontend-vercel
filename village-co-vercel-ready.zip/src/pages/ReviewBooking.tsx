import { useParams, useLocation } from 'wouter';
import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Star } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

export default function ReviewBooking() {
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const { bookingId } = useParams();
  const [, setLocation] = useLocation();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const submitReview = async () => {
    if (!comment.trim()) {
      toast({
        title: "Review required",
        description: "Please share your experience with this sitter.",
        variant: "destructive"
      });
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Get booking details with profile relationships
      const { data: booking, error: bookingError } = await supabase
        .from('bookings')
        .select('parent_id, sitter_id')
        .eq('id', parseInt(bookingId))
        .single();

      if (bookingError || !booking) {
        throw new Error('Booking not found');
      }

      // Get user IDs from profile IDs
      const { data: parentProfile } = await supabase
        .from('parent_profiles')
        .select('userId')
        .eq('id', booking.parent_id)
        .single();

      const { data: sitterProfile } = await supabase
        .from('sitter_profiles')
        .select('userId')
        .eq('id', booking.sitter_id)
        .single();

      if (!parentProfile || !sitterProfile) {
        throw new Error('User profiles not found');
      }

      await supabase.from('reviews').insert({
        booking_id: parseInt(bookingId),
        reviewer_id: parentProfile.userId, // Parent user ID as reviewer
        reviewee_id: sitterProfile.userId, // Sitter user ID as reviewee
        rating,
        comment,
      });
      
      toast({
        title: "Review submitted",
        description: "Thank you for your feedback!",
      });
      
      setLocation('/dashboard');
    } catch (error) {
      console.error('Error submitting review:', error);
      toast({
        title: "Something went wrong",
        description: "We couldn't submit your review. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="container max-w-md py-8">
      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-bold text-center">How was your experience?</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="rating">Rating</Label>
            <div className="flex items-center space-x-2">
              {[1, 2, 3, 4, 5].map((value) => (
                <button
                  key={value}
                  type="button"
                  onClick={() => setRating(value)}
                  className="focus:outline-none"
                >
                  <Star 
                    className={`h-8 w-8 ${value <= rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
                  />
                </button>
              ))}
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="comment">Your Review</Label>
            <Textarea
              id="comment"
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="What did you love about this sitter? What could they improve on?"
              className="min-h-[120px]"
            />
          </div>
        </CardContent>
        <CardFooter>
          <Button 
            onClick={submitReview} 
            className="w-full bg-wine hover:bg-wine/90"
            disabled={isSubmitting}
          >
            {isSubmitting ? 'Submitting...' : 'Submit Review'}
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}