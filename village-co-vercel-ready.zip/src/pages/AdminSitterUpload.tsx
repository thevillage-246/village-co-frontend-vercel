import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Upload, Download, Users, AlertCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

export default function AdminSitterUpload() {
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [results, setResults] = useState<any>(null);
  const { toast } = useToast();

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    if (selectedFile && selectedFile.type === 'text/csv') {
      setFile(selectedFile);
      setResults(null);
    } else {
      toast({
        title: "Invalid file type",
        description: "Please select a CSV file",
        variant: "destructive"
      });
    }
  };

  const handleUpload = async () => {
    if (!file) return;

    setUploading(true);
    const formData = new FormData();
    formData.append('csv', file);

    try {
      const response = await fetch('/api/admin/upload-sitters', {
        method: 'POST',
        body: formData,
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('authToken') || localStorage.getItem('auth_token')}`
        }
      });

      const result = await response.json();

      if (response.ok) {
        setResults(result);
        toast({
          title: "Upload successful",
          description: `${result.successful} sitters imported successfully`
        });
      } else {
        throw new Error(result.message || 'Upload failed');
      }
    } catch (error: any) {
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setUploading(false);
    }
  };

  const downloadTemplate = () => {
    const link = document.createElement('a');
    link.href = '/api/admin/sitter-template';
    link.download = 'sitter-upload-template.csv';
    link.click();
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <div className="flex items-center gap-3">
        <Users className="h-8 w-8 text-village-wine" />
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Upload Sitters</h1>
          <p className="text-gray-600">Import sitters from CSV file</p>
        </div>
      </div>

      {/* Template Download */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Download className="h-5 w-5" />
            Download Template
          </CardTitle>
          <CardDescription>
            Download the CSV template with the correct format and example data
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button onClick={downloadTemplate} variant="outline" className="w-full sm:w-auto">
            <Download className="h-4 w-4 mr-2" />
            Download CSV Template
          </Button>
        </CardContent>
      </Card>

      {/* File Upload */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Upload Sitters CSV
          </CardTitle>
          <CardDescription>
            Select your completed CSV file to import sitters into the platform
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <input
              type="file"
              accept=".csv"
              onChange={handleFileSelect}
              className="flex-1 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-village-wine file:text-white hover:file:bg-village-wine/90"
            />
            <Button 
              onClick={handleUpload} 
              disabled={!file || uploading}
              className="min-w-[120px]"
            >
              {uploading ? "Uploading..." : "Upload CSV"}
            </Button>
          </div>

          {file && (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                Selected file: {file.name} ({Math.round(file.size / 1024)}KB)
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Results */}
      {results && (
        <Card>
          <CardHeader>
            <CardTitle className="text-green-700">Upload Results</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-green-50 p-4 rounded-lg">
                <div className="text-2xl font-bold text-green-700">{results.successful}</div>
                <div className="text-green-600">Successful</div>
              </div>
              <div className="bg-red-50 p-4 rounded-lg">
                <div className="text-2xl font-bold text-red-700">{results.failed}</div>
                <div className="text-red-600">Failed</div>
              </div>
              <div className="bg-blue-50 p-4 rounded-lg">
                <div className="text-2xl font-bold text-blue-700">{results.total}</div>
                <div className="text-blue-600">Total Processed</div>
              </div>
            </div>

            {results.errors && results.errors.length > 0 && (
              <div>
                <h4 className="font-semibold text-red-700 mb-2">Errors:</h4>
                <div className="bg-red-50 p-4 rounded-lg max-h-40 overflow-y-auto">
                  {results.errors.map((error: string, index: number) => (
                    <div key={index} className="text-sm text-red-600 mb-1">
                      {error}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {results.warnings && results.warnings.length > 0 && (
              <div>
                <h4 className="font-semibold text-yellow-700 mb-2">Warnings:</h4>
                <div className="bg-yellow-50 p-4 rounded-lg max-h-40 overflow-y-auto">
                  {results.warnings.map((warning: string, index: number) => (
                    <div key={index} className="text-sm text-yellow-600 mb-1">
                      {warning}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Instructions */}
      <Card>
        <CardHeader>
          <CardTitle>CSV Format Instructions</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-sm text-gray-600 space-y-2">
            <p><strong>Required fields:</strong> first_name, last_name, email, hourly_rate, address</p>
            <p><strong>Availability format:</strong> Use comma-separated values: "morning,afternoon,evening" or leave blank for none</p>
            <p><strong>Qualifications format:</strong> Use comma-separated values: "First Aid,CPR,Police Check"</p>
            <p><strong>Languages format:</strong> Use comma-separated values: "English,Spanish,French"</p>
            <p><strong>Age field:</strong> Numeric value (optional)</p>
            <p><strong>Hourly rate:</strong> Numeric value in NZD (required)</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}