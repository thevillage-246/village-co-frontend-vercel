import React, { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import { Loader2 } from "lucide-react";
import BookingFeedbackComponent from "@/components/parents/BookingFeedback";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function BookingFeedbackPage() {
  const [, params] = useRoute<{ id: string }>("/parent/booking/:id/feedback");
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [bookingId, setBookingId] = useState<number | null>(null);

  useEffect(() => {
    if (params?.id) {
      setBookingId(parseInt(params.id, 10));
    }
  }, [params]);

  const { data: booking, isLoading, error } = useQuery({
    queryKey: ['/api/bookings', bookingId],
    queryFn: () => {
      if (!bookingId) return null;
      return apiRequest("GET", `/api/bookings/${bookingId}`).then(res => res.json());
    },
    enabled: !!bookingId
  });

  const { data: sitter } = useQuery({
    queryKey: ['/api/sitters', booking?.sitterId],
    queryFn: () => {
      if (!booking?.sitterId) return null;
      return apiRequest("GET", `/api/sitters/${booking.sitterId}`).then(res => res.json());
    },
    enabled: !!booking?.sitterId
  });

  const handleFeedbackComplete = () => {
    // Set a short delay before redirecting to dashboard to allow user to see completion message
    setTimeout(() => {
      navigate("/parent/dashboard");
    }, 2000);
  };

  // Check if the booking already has a review
  const { data: existingReviews } = useQuery({
    queryKey: ['/api/reviews/booking', bookingId],
    queryFn: () => {
      if (!bookingId) return [];
      return apiRequest("GET", `/api/reviews/booking/${bookingId}`).then(res => res.json());
    },
    enabled: !!bookingId
  });

  const hasExistingReview = existingReviews && existingReviews.length > 0;

  useEffect(() => {
    // If booking doesn't exist or isn't completed, redirect to dashboard
    if (!isLoading && !booking) {
      toast({
        title: "Booking not found",
        description: "The booking you're looking for doesn't exist.",
        variant: "destructive",
      });
      navigate("/parent/dashboard");
      return;
    }

    if (booking && booking.status !== "completed") {
      toast({
        title: "Cannot review yet",
        description: "You can only provide feedback for completed bookings.",
        variant: "destructive",
      });
      navigate("/parent/dashboard");
      return;
    }

    // If booking already has a review, show a message and redirect
    if (hasExistingReview) {
      toast({
        title: "Already reviewed",
        description: "You've already provided feedback for this booking.",
      });
      navigate("/parent/dashboard");
    }
  }, [booking, isLoading, hasExistingReview, navigate, toast]);

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-wine" />
      </div>
    );
  }

  if (error || !booking || !sitter) {
    return (
      <div className="h-screen flex flex-col items-center justify-center p-4">
        <h1 className="text-2xl font-bold text-wine mb-4">Something went wrong</h1>
        <p className="text-gray-600 mb-6">We couldn't load the booking information. Please try again later.</p>
        <Button onClick={() => navigate("/parent/dashboard")}>Return to Dashboard</Button>
      </div>
    );
  }

  // Format sitter name for display
  const sitterName = `${sitter.firstName} ${sitter.lastName}`;

  return (
    <div className="container max-w-4xl mx-auto py-8 px-4">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-wine">Review Your Babysitting Experience</h1>
        <p className="text-gray-600">
          Your feedback helps other parents in our community and helps {sitterName} improve.
        </p>
      </div>
      
      <div className="mb-6 p-4 bg-linen/50 rounded-lg">
        <h2 className="font-semibold mb-2">Booking Details</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm">
          <div>
            <span className="font-medium">Date:</span> {new Date(booking.startTime).toLocaleDateString()}
          </div>
          <div>
            <span className="font-medium">Time:</span> {new Date(booking.startTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} - {new Date(booking.endTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </div>
          <div className="md:col-span-2">
            <span className="font-medium">Sitter:</span> {sitterName}
          </div>
        </div>
      </div>

      <BookingFeedbackComponent 
        bookingId={booking.id} 
        sitterName={sitterName}
        onComplete={handleFeedbackComplete}
      />

      <div className="mt-6 text-center">
        <Button variant="outline" onClick={() => navigate("/parent/dashboard")}>
          Skip for now
        </Button>
      </div>
    </div>
  );
}