import React, { useEffect } from 'react';
import { useRoute, useLocation } from 'wouter';
import { useAuth } from '@/contexts/AuthContext';
import GoogleMapSearch from '@/components/sitters/GoogleMapSearch';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';

export default function MapSearch() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const [, params] = useRoute('/map-search/:location?');
  
  useEffect(() => {
    if (!user) {
      navigate('/login');
    } else if (user.role !== 'parent') {
      navigate('/dashboard');
    }
  }, [user, navigate]);

  // Parse location from URL if provided
  const getInitialLocation = (): [number, number] | undefined => {
    if (params?.location) {
      try {
        const [lat, lng] = params.location.split(',').map(parseFloat);
        if (!isNaN(lat) && !isNaN(lng)) {
          return [lat, lng];
        }
      } catch (error) {
        console.error('Error parsing location from URL:', error);
      }
    }
    return undefined;
  };

  return (
    <div className="min-h-screen bg-linen/30">
      <div className="container mx-auto px-4 py-6">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => navigate('/dashboard')}
          className="mb-4"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Dashboard
        </Button>
        
        <GoogleMapSearch initialLocation={getInitialLocation()} />
      </div>
    </div>
  );
}