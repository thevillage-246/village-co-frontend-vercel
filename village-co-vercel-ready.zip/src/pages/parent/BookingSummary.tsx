import React, { useState } from 'react';
import { useRoute, useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { format, parseISO } from 'date-fns';
import { useAuth } from '@/contexts/AuthContext';
import { BOOKING_STATUS } from '@shared/schema';
import { createPaymentIntent, getStripe } from '@/lib/stripe';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { 
  Calendar, 
  CheckCircle, 
  Clock, 
  DollarSign,
  Info,
  MessageCircle, 
  ShieldCheck
} from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';

const BookingSummary: React.FC = () => {
  const [match, params] = useRoute('/booking-summary/:id');
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [isPaymentLoading, setIsPaymentLoading] = useState(false);
  const bookingId = match ? parseInt(params.id) : null;

  // Fetch booking details
  const { data: booking, isLoading } = useQuery({
    queryKey: [`/api/bookings/${bookingId}`],
    enabled: !!bookingId,
  });

  // Fetch sitter profile
  const { data: sitterProfile, isLoading: loadingSitter } = useQuery({
    queryKey: [`/api/sitters/${booking?.sitterId}/profile`],
    enabled: !!booking?.sitterId,
  });

  const handlePayment = async () => {
    if (!booking) return;
    
    try {
      setIsPaymentLoading(true);
      
      // Create payment intent
      const clientSecret = await createPaymentIntent(booking.id);
      
      // Load Stripe
      const stripe = await getStripe();
      
      if (!stripe) {
        throw new Error('Failed to load Stripe');
      }
      
      // Redirect to checkout
      const { error } = await stripe.redirectToCheckout({
        clientSecret,
      });
      
      if (error) {
        throw error;
      }
    } catch (error: any) {
      toast({
        title: 'Payment Error',
        description: error.message || 'There was an error processing your payment.',
        variant: 'destructive',
      });
    } finally {
      setIsPaymentLoading(false);
    }
  };

  const formatDateTime = (dateStr: string) => {
    const date = parseISO(dateStr);
    return format(date, 'EEEE, MMMM d, yyyy h:mm a');
  };

  if (isLoading || loadingSitter) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!booking || !sitterProfile) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16">
            <Info className="h-12 w-12 text-muted-foreground mb-4" />
            <h2 className="text-xl font-semibold mb-2">Booking Not Found</h2>
            <p className="text-muted-foreground mb-6">The booking you're looking for doesn't exist or you don't have permission to view it.</p>
            <Button onClick={() => navigate('/dashboard')}>
              Return to Dashboard
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Format time
  const startTime = parseISO(booking.startTime);
  const endTime = parseISO(booking.endTime);
  const bookingDate = format(startTime, 'EEEE, MMMM d, yyyy');
  const timeRange = `${format(startTime, 'h:mm a')} - ${format(endTime, 'h:mm a')}`;
  const totalHours = (new Date(endTime).getTime() - new Date(startTime).getTime()) / (1000 * 60 * 60);

  return (
    <div className="container mx-auto px-4 py-8">
      <Card className="max-w-4xl mx-auto">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4">
            {booking.status === BOOKING_STATUS.PENDING ? (
              <Badge variant="warning" className="text-base px-4 py-1">Request Pending</Badge>
            ) : booking.status === BOOKING_STATUS.ACCEPTED ? (
              <Badge variant="success" className="text-base px-4 py-1">Booking Confirmed</Badge>
            ) : (
              <Badge className="text-base px-4 py-1">{booking.status}</Badge>
            )}
          </div>
          <CardTitle className="text-2xl">Booking Summary</CardTitle>
          <CardDescription>
            Your booking request has been submitted successfully
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-6">
          {/* Sitter Information */}
          <div className="flex flex-col sm:flex-row items-center gap-4 p-4 bg-muted/30 rounded-lg">
            <Avatar className="h-16 w-16">
              <AvatarImage src={sitterProfile.photoUrl} alt={`${sitterProfile.firstName} ${sitterProfile.lastName}`} />
              <AvatarFallback className="text-lg">
                {sitterProfile.firstName?.[0]}{sitterProfile.lastName?.[0]}
              </AvatarFallback>
            </Avatar>
            
            <div className="text-center sm:text-left">
              <h3 className="text-lg font-medium">{sitterProfile.firstName} {sitterProfile.lastName}</h3>
              <p className="text-muted-foreground">{sitterProfile.bio?.substring(0, 100)}...</p>
            </div>
          </div>
          
          <Separator />
          
          {/* Booking Details */}
          <div className="space-y-3">
            <h3 className="font-medium text-lg">Booking Details</h3>
            
            <div className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-muted-foreground" />
              <span>{bookingDate}</span>
            </div>
            
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-muted-foreground" />
              <span>{timeRange} ({totalHours} hours)</span>
            </div>
            
            {booking.specialRequests && (
              <div className="mt-4">
                <h4 className="font-medium">Special Requests:</h4>
                <p className="text-muted-foreground mt-1">{booking.specialRequests}</p>
              </div>
            )}
          </div>
          
          <Separator />
          
          {/* Payment Summary */}
          <div className="space-y-3">
            <h3 className="font-medium text-lg">Payment Details</h3>
            
            <div className="bg-muted p-4 rounded-md">
              <div className="flex justify-between items-center mb-2">
                <span>Hourly Rate</span>
                <span>${parseFloat(sitterProfile.hourlyRate).toFixed(2)}/hr</span>
              </div>
              
              <div className="flex justify-between items-center mb-2">
                <span>Duration</span>
                <span>{totalHours} hours</span>
              </div>
              
              <Separator className="my-2" />
              
              <div className="flex justify-between items-center font-medium">
                <span>Total</span>
                <span>${parseFloat(booking.totalAmount).toFixed(2)}</span>
              </div>
              
              <div className="text-xs text-muted-foreground mt-2">
                <p>Payment will be processed after the service is completed.</p>
              </div>
            </div>
          </div>
          
          <Separator />
          
          {/* Next Steps */}
          <div className="space-y-4">
            <h3 className="font-medium text-lg">Next Steps</h3>
            
            <div className="space-y-2">
              {booking.status === BOOKING_STATUS.PENDING ? (
                <>
                  <div className="flex items-start gap-2">
                    <div className="bg-primary/10 p-1 rounded-full mt-0.5">
                      <Clock className="h-4 w-4 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium">Awaiting Sitter Confirmation</p>
                      <p className="text-sm text-muted-foreground">
                        {sitterProfile.firstName} will review your request and respond soon.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-2">
                    <div className="bg-muted p-1 rounded-full mt-0.5">
                      <MessageCircle className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="font-medium text-muted-foreground">Message Your Sitter</p>
                      <p className="text-sm text-muted-foreground">
                        Once confirmed, you'll be able to message your sitter.
                      </p>
                    </div>
                  </div>
                </>
              ) : booking.status === BOOKING_STATUS.ACCEPTED ? (
                <>
                  <div className="flex items-start gap-2">
                    <div className="bg-success/10 p-1 rounded-full mt-0.5">
                      <CheckCircle className="h-4 w-4 text-success" />
                    </div>
                    <div>
                      <p className="font-medium">Booking Confirmed</p>
                      <p className="text-sm text-muted-foreground">
                        {sitterProfile.firstName} has accepted your booking request.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-2">
                    <div className="bg-primary/10 p-1 rounded-full mt-0.5">
                      <MessageCircle className="h-4 w-4 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium">Message Your Sitter</p>
                      <p className="text-sm text-muted-foreground">
                        You can now communicate with {sitterProfile.firstName} through our messaging system.
                      </p>
                    </div>
                  </div>
                </>
              ) : (
                <div className="flex items-start gap-2">
                  <div className="bg-muted p-1 rounded-full mt-0.5">
                    <Info className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="font-medium">Booking {booking.status}</p>
                    <p className="text-sm text-muted-foreground">
                      This booking has been {booking.status.toLowerCase()}.
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
          
          <div className="rounded-lg border bg-card p-4">
            <div className="flex items-start gap-4">
              <ShieldCheck className="h-10 w-10 text-primary flex-shrink-0" />
              <div>
                <h4 className="font-medium">Trust & Safety Guarantee</h4>
                <p className="text-sm text-muted-foreground">
                  All sitters on The Village Co. are thoroughly vetted, background-checked, and have undergone extensive interviews. Your family's safety is our top priority.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
        
        <CardFooter className="flex flex-col sm:flex-row sm:justify-between gap-4 pt-6 border-t">
          <Button variant="outline" onClick={() => navigate('/dashboard')}>
            Return to Dashboard
          </Button>
          
          {booking.status === BOOKING_STATUS.ACCEPTED && (
            <Button 
              onClick={() => navigate(`/booking/${booking.id}`)}
              className="sm:ml-auto"
            >
              View Booking Details
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  );
};

export default BookingSummary;
