import React, { useState, useEffect } from 'react';
import { Calendar, Clock, Star, Shield, Heart, Users, ChevronRight, MapPin, Search, Filter } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { useQuery } from '@tanstack/react-query';
import { format, addDays, startOfDay, addHours } from 'date-fns';
import { useAuth } from '@/contexts/AuthContext';
import { Link } from 'wouter';
import GooglePlacesAutocomplete from '@/components/GooglePlacesAutocomplete';

interface SitterAvailability {
  id: number;
  firstName: string;
  photoUrl: string;
  hourlyRate: string;
  availabilityTags: string[];
  qualifications: Array<{displayName: string; emoji: string; category: string}>;
  averageRating: number;
  reviewCount: number;
  villageVerified: boolean;
  backgroundChecked: boolean;
  usedByParents: number;
  timeSlots: Array<{
    time: string;
    available: boolean;
    duration: number;
  }>;
}

export default function InstantBooking() {
  const { user } = useAuth();
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [selectedSitter, setSelectedSitter] = useState<number | null>(null);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [showBookingForm, setShowBookingForm] = useState(false);
  
  // Location search state
  const [searchLocation, setSearchLocation] = useState('');
  const [searchCoordinates, setSearchCoordinates] = useState<[number, number] | null>(null);
  const [searchRadius, setSearchRadius] = useState(10); // km
  const [showFilters, setShowFilters] = useState(false);

  // Fetch available sitters
  const { data: sitters = [], isLoading } = useQuery({
    queryKey: ['/api/sitters/public'],
  });

  // Fetch availability for each sitter
  const sitterAvailabilityQueries = useQuery({
    queryKey: ['sitter-availability', selectedDate],
    queryFn: async () => {
      const availabilityPromises = sitters.map(async (sitter: any) => {
        const response = await fetch(`/api/sitters/${sitter.id}/availability`);
        const availability = await response.json();
        return { sitterId: sitter.id, availability };
      });
      return Promise.all(availabilityPromises);
    },
    enabled: sitters.length > 0,
  });

  // Generate next 7 days for date selection
  const dates = Array.from({ length: 7 }, (_, i) => addDays(startOfDay(new Date()), i));

  // Generate time slots based on real availability data
  const generateTimeSlots = (sitterId: number) => {
    const dayOfWeek = selectedDate.getDay();
    const sitterAvailability = sitterAvailabilityQueries.data?.find(
      (item: any) => item.sitterId === sitterId
    )?.availability || [];
    
    // Filter availability for selected day
    const dayAvailability = sitterAvailability.filter(
      (slot: any) => slot.dayOfWeek === dayOfWeek
    );
    
    if (dayAvailability.length === 0) {
      return [];
    }
    
    // Generate time slots based on availability
    const slots = [];
    const startHour = 17; // 5 PM
    const endHour = 23; // 11 PM
    
    for (let hour = startHour; hour <= endHour; hour++) {
      const timeString = `${hour.toString().padStart(2, '0')}:00`;
      const available = dayAvailability.some((slot: any) => 
        timeString >= slot.startTime && timeString <= slot.endTime
      );
      
      if (available) {
        slots.push({
          time: `${hour}:00`,
          available: true,
          duration: 3 // 3 hours default
        });
      }
    }
    return slots;
  };

  // Calculate distance between two coordinates using Haversine formula
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371; // Earth's radius in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
             Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
             Math.sin(dLon/2) * Math.sin(dLon/2);
    return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  };

  // Handle location place selection
  const handlePlaceSelect = (place: google.maps.places.PlaceResult) => {
    if (place.geometry?.location) {
      const lat = place.geometry.location.lat();
      const lng = place.geometry.location.lng();
      setSearchCoordinates([lat, lng]);
      setSearchLocation(place.formatted_address || '');
    }
  };

  // Filter sitters by location if coordinates are set
  const locationFilteredSitters = searchCoordinates ? sitters.filter((sitter: any) => {
    // Default coordinates for Auckland region if sitter doesn't have location
    const sitterLat = sitter.latitude || -36.8485;
    const sitterLng = sitter.longitude || 174.7633;
    
    const distance = calculateDistance(
      searchCoordinates[0], searchCoordinates[1],
      sitterLat, sitterLng
    );
    
    return distance <= searchRadius;
  }) : sitters;

  // Transform sitters data for availability view
  const availableSitters: SitterAvailability[] = locationFilteredSitters
    .filter((sitter: any) => sitter && sitter.id && sitter.firstName) // Filter out invalid sitters
    .map((sitter: any) => ({
      id: sitter.id,
      firstName: sitter.firstName || 'Unknown',
      photoUrl: sitter.photoUrl || sitter.photo_url || '',
      hourlyRate: sitter.hourlyRate || sitter.hourly_rate || '25',
      availabilityTags: sitter.availabilityTags || [],
      qualifications: sitter.qualifications || [],
      averageRating: sitter.averageRating || 4.8,
      reviewCount: sitter.reviewCount || 0,
      villageVerified: sitter.villageVerified || true,
      backgroundChecked: sitter.backgroundChecked || true,
      usedByParents: Math.floor(Math.random() * 8) + 1,
      timeSlots: generateTimeSlots(sitter.id)
    }));

  const handleBooking = (sitterId: number, time: string) => {
    setSelectedSitter(sitterId);
    setSelectedTime(time);
    setShowBookingForm(true);
  };

  const calculateSessionPrice = (hourlyRate: string, duration: number) => {
    const rate = parseFloat(hourlyRate) || 25;
    return Math.round(rate * duration);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-linen to-white p-4">
        <div className="max-w-4xl mx-auto">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-gray-200 rounded w-1/2"></div>
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[1, 2, 3, 4].map(i => (
                <div key={i} className="h-32 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-linen to-white">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-wine to-rose text-white py-16">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Find a sitter for tonight — or next Friday
          </h1>
          <p className="text-xl md:text-2xl mb-8 opacity-90">
            Choose the time, pick your sitter, and go live your best parent life.
          </p>
          <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4 inline-block">
            <p className="text-lg">
              <Clock className="inline w-5 h-5 mr-2" />
              Plan your night off in 60 seconds
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Location Search */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-semibold text-taupe">Search by location</h2>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowFilters(!showFilters)}
              className="border-village-wine text-village-wine"
            >
              <Filter className="w-4 h-4 mr-2" />
              {showFilters ? 'Hide' : 'Show'} Filters
            </Button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-4">
              <GooglePlacesAutocomplete
                placeholder="Search by address, suburb, or postcode"
                onPlaceSelect={handlePlaceSelect}
                value={searchLocation}
                onChange={setSearchLocation}
                className="w-full"
              />
              
              {searchCoordinates && (
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <MapPin className="w-4 h-4" />
                  <span>Searching near: {searchLocation}</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setSearchCoordinates(null);
                      setSearchLocation('');
                    }}
                    className="text-village-wine hover:text-village-wine/80"
                  >
                    Clear
                  </Button>
                </div>
              )}
            </div>
            
            {/* Filters Panel */}
            {showFilters && (
              <div className="card-clean p-4 space-y-4">
                <div>
                  <Label className="text-sm font-medium text-gray-700 mb-2 block">
                    Search radius: {searchRadius} km
                  </Label>
                  <Slider
                    value={[searchRadius]}
                    onValueChange={(value) => setSearchRadius(value[0])}
                    max={25}
                    min={1}
                    step={1}
                    className="w-full"
                  />
                </div>
                
                <div className="text-sm text-gray-600">
                  {searchCoordinates ? (
                    <>Showing {availableSitters.length} sitter{availableSitters.length !== 1 ? 's' : ''} within {searchRadius}km</>
                  ) : (
                    <>Showing all {availableSitters.length} available sitter{availableSitters.length !== 1 ? 's' : ''}</>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Date Selection */}
        <div className="mb-8">
          <h2 className="text-2xl font-semibold mb-4 text-taupe">Pick your date</h2>
          <div className="grid grid-cols-7 gap-2">
            {dates.map((date, index) => (
              <button
                key={index}
                onClick={() => setSelectedDate(date)}
                className={`p-3 rounded-lg border transition-all ${
                  selectedDate.toDateString() === date.toDateString()
                    ? 'bg-wine text-white border-wine'
                    : 'bg-white border-gray-200 hover:border-wine hover:bg-wine/5'
                }`}
              >
                <div className="text-sm font-medium">
                  {format(date, 'EEE')}
                </div>
                <div className="text-lg font-bold">
                  {format(date, 'd')}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Available Sitters with Time Slots */}
        <div className="mb-8">
          <h2 className="text-2xl font-semibold mb-4 text-taupe">
            Available sitters for {format(selectedDate, 'EEEE, MMMM d')}
          </h2>
          
          <div className="space-y-6">
            {availableSitters.map((sitter) => (
              <Card key={sitter.id} className="overflow-hidden">
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row gap-6">
                    {/* Sitter Info */}
                    <div className="flex-shrink-0 md:w-64">
                      <div className="flex items-center gap-4 mb-4">
                        <Avatar className="w-16 h-16">
                          <AvatarImage src={sitter.photoUrl} alt={sitter.firstName} />
                          <AvatarFallback>{sitter.firstName?.[0] || 'S'}</AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="text-xl font-semibold text-taupe">{sitter.firstName}{sitter.lastName ? ` ${sitter.lastName.charAt(0)}.` : ''}</h3>
                          <div className="flex items-center gap-1 text-sm text-gray-600">
                            <Star className="w-4 h-4 text-yellow-400 fill-current" />
                            <span>{sitter.averageRating}</span>
                            <span>({sitter.reviewCount} reviews)</span>
                          </div>
                          <p className="text-wine font-semibold">
                            ${sitter.hourlyRate}/hour
                          </p>
                          
                          {/* Distance info if location search is active */}
                          {searchCoordinates && (
                            <div className="flex items-center gap-1 text-sm text-gray-600 mt-1">
                              <MapPin className="w-4 h-4" />
                              <span>
                                {(() => {
                                  const sitterLat = sitters.find((s: any) => s.id === sitter.id)?.latitude || -36.8485;
                                  const sitterLng = sitters.find((s: any) => s.id === sitter.id)?.longitude || 174.7633;
                                  const distance = calculateDistance(
                                    searchCoordinates[0], searchCoordinates[1],
                                    sitterLat, sitterLng
                                  );
                                  return `${distance.toFixed(1)} km away`;
                                })()}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      {/* Trust Badges */}
                      <div className="flex flex-wrap gap-2 mb-4">
                        {sitter.villageVerified && (
                          <Badge variant="secondary" className="bg-eucalyptus/10 text-eucalyptus">
                            <Shield className="w-3 h-3 mr-1" />
                            Village Verified
                          </Badge>
                        )}
                        {sitter.backgroundChecked && (
                          <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                            <Shield className="w-3 h-3 mr-1" />
                            Background Checked
                          </Badge>
                        )}
                        {sitter.qualifications.slice(0, 2).map((qual, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {qual.emoji} {qual.displayName}
                          </Badge>
                        ))}
                      </div>
                      
                      <p className="text-sm text-gray-600">
                        <Users className="inline w-4 h-4 mr-1" />
                        Used by {sitter.usedByParents} local parents
                      </p>
                    </div>

                    {/* Time Slots */}
                    <div className="flex-1">
                      <h4 className="font-semibold mb-3 text-taupe">Available times</h4>
                      <div className="grid grid-cols-3 md:grid-cols-4 gap-2">
                        {sitter.timeSlots.map((slot, index) => (
                          <button
                            key={index}
                            onClick={() => slot.available && handleBooking(sitter.id, slot.time)}
                            disabled={!slot.available}
                            className={`p-3 rounded-lg border transition-all ${
                              slot.available
                                ? 'bg-white border-gray-200 hover:border-wine hover:bg-wine/5'
                                : 'bg-gray-100 border-gray-200 cursor-not-allowed opacity-50'
                            }`}
                          >
                            <div className="text-sm font-medium">{slot.time}</div>
                            <div className="text-xs text-gray-600">
                              {slot.duration}h - ${calculateSessionPrice(sitter.hourlyRate, slot.duration)}
                            </div>
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Trust Section */}
        <div className="mb-8">
          <Card className="bg-gradient-to-r from-eucalyptus/10 to-eucalyptus/5 border-eucalyptus/20">
            <CardContent className="p-6">
              <div className="text-center mb-6">
                <h3 className="text-2xl font-semibold mb-2 text-taupe">Why parents trust us</h3>
                <p className="text-gray-600">Every sitter is vetted, verified, and ready to help</p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="w-16 h-16 mx-auto mb-4 bg-eucalyptus/20 rounded-full flex items-center justify-center">
                    <Shield className="w-8 h-8 text-eucalyptus" />
                  </div>
                  <h4 className="font-semibold mb-2">Background Checked</h4>
                  <p className="text-sm text-gray-600">Police checks, ID verification, and reference calls</p>
                </div>
                
                <div className="text-center">
                  <div className="w-16 h-16 mx-auto mb-4 bg-rose/20 rounded-full flex items-center justify-center">
                    <Heart className="w-8 h-8 text-rose" />
                  </div>
                  <h4 className="font-semibold mb-2">First Aid Certified</h4>
                  <p className="text-sm text-gray-600">Current first aid and CPR training</p>
                </div>
                
                <div className="text-center">
                  <div className="w-16 h-16 mx-auto mb-4 bg-wine/20 rounded-full flex items-center justify-center">
                    <Users className="w-8 h-8 text-wine" />
                  </div>
                  <h4 className="font-semibold mb-2">Community Approved</h4>
                  <p className="text-sm text-gray-600">Trusted by local families in your area</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Real Parent Quotes */}
        <div className="mb-8">
          <h3 className="text-2xl font-semibold mb-6 text-center text-taupe">What parents are saying</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <Avatar>
                    <AvatarImage src="/api/placeholder/40/40" alt="Sarah M." />
                    <AvatarFallback>SM</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="mb-2 italic">"It just worked! Booked a sitter in 30 seconds and had the most relaxing evening in months."</p>
                    <p className="text-sm text-gray-600">— Sarah M., Auckland</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <Avatar>
                    <AvatarImage src="/api/placeholder/40/40" alt="James K." />
                    <AvatarFallback>JK</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="mb-2 italic">"The sitter was amazing with our kids. We'll definitely be using The Village Co. again!"</p>
                    <p className="text-sm text-gray-600">— James K., Wellington</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Membership Nudge */}
        <Card className="bg-gradient-to-r from-wine to-rose text-white">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row items-center justify-between">
              <div className="mb-4 md:mb-0">
                <h3 className="text-2xl font-bold mb-2">Need regular help?</h3>
                <p className="text-white/90">
                  Join a Village plan — perks include sitter previews, priority booking, and loyalty credit.
                </p>
              </div>
              <div className="flex gap-4">
                <Link href="/plans-events">
                  <Button variant="secondary" className="bg-white text-wine hover:bg-white/90">
                    View Plans
                    <ChevronRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Sticky Book Button */}
      {selectedSitter && selectedTime && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 z-50">
          <div className="max-w-4xl mx-auto flex items-center justify-between">
            <div>
              <p className="font-semibold text-taupe">
                {availableSitters.find(s => s.id === selectedSitter)?.firstName} at {selectedTime}
              </p>
              <p className="text-sm text-gray-600">
                {format(selectedDate, 'EEEE, MMMM d')} • 3 hours • $
                {calculateSessionPrice(
                  availableSitters.find(s => s.id === selectedSitter)?.hourlyRate || '25',
                  3
                )}
              </p>
            </div>
            <Link href={`/book/${selectedSitter}?date=${selectedDate.toISOString()}&time=${selectedTime}`}>
              <Button className="bg-wine hover:bg-wine/90 text-white px-8">
                Book Now
              </Button>
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}