import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, CreditCard, Shield, CheckCircle, Plus, Trash2, Edit3 } from 'lucide-react';
import { useLocation } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Elements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import EmbeddedPaymentSetup from '@/components/payment/EmbeddedPaymentSetup';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';

// Load Stripe
const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

export default function ParentPaymentPage() {
  const [, setLocation] = useLocation();
  const [clientSecret, setClientSecret] = useState<string>('');
  const [showAddPaymentDialog, setShowAddPaymentDialog] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Check if user already has payment method
  const { data: user, isLoading: userLoading } = useQuery({
    queryKey: ['/api/auth/user'],
  });

  // Get payment methods
  const { data: paymentMethodsData, isLoading: paymentMethodsLoading } = useQuery({
    queryKey: ['/api/stripe/payment-methods'],
    enabled: !!user?.stripeCustomerId,
  });

  const paymentMethods = paymentMethodsData?.paymentMethods || [];

  // Create setup intent when adding new payment method
  const createSetupIntent = async () => {
    try {
      const response = await apiRequest('POST', '/api/stripe/create-setup-intent');
      const data = await response.json();
      
      if (data.clientSecret) {
        setClientSecret(data.clientSecret);
        setShowAddPaymentDialog(true);
      } else {
        throw new Error('Failed to create setup intent');
      }
    } catch (error) {
      console.error('Setup intent error:', error);
      toast({
        title: "Setup Failed",
        description: "Unable to initialize payment setup. Please try again.",
        variant: "destructive"
      });
    }
  };

  // Delete payment method mutation
  const deletePaymentMethodMutation = useMutation({
    mutationFn: async (paymentMethodId: string) => {
      const response = await apiRequest('DELETE', `/api/stripe/payment-methods/${paymentMethodId}`);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Payment Method Removed",
        description: "Your payment method has been successfully removed.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/stripe/payment-methods'] });
    },
    onError: (error: any) => {
      toast({
        title: "Removal Failed",
        description: error.message || "Failed to remove payment method. Please try again.",
        variant: "destructive"
      });
    },
  });

  const handlePaymentSuccess = () => {
    toast({
      title: "Payment Method Added",
      description: "Your payment method has been securely saved.",
    });
    setShowAddPaymentDialog(false);
    setClientSecret('');
    queryClient.invalidateQueries({ queryKey: ['/api/stripe/payment-methods'] });
    queryClient.invalidateQueries({ queryKey: ['/api/auth/user'] });
  };

  const handleRemovePaymentMethod = (paymentMethodId: string) => {
    deletePaymentMethodMutation.mutate(paymentMethodId);
  };

  const getCardBrandIcon = (brand: string) => {
    switch (brand.toLowerCase()) {
      case 'visa':
        return '💳';
      case 'mastercard':
        return '💳';
      case 'amex':
        return '💳';
      default:
        return '💳';
    }
  };

  const formatCardBrand = (brand: string) => {
    return brand.charAt(0).toUpperCase() + brand.slice(1);
  };

  if (userLoading || paymentMethodsLoading) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-2xl mx-auto px-4">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-gray-200 rounded w-1/4"></div>
            <div className="h-64 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-2xl mx-auto px-4">
        <div className="mb-6">
          <Button
            variant="ghost"
            onClick={() => setLocation('/parent/dashboard')}
            className="flex items-center gap-2 text-village-wine hover:text-village-wine/80"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Dashboard
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-village-wine flex items-center gap-2">
              <CreditCard className="w-5 h-5" />
              Payment Methods
            </CardTitle>
            <p className="text-gray-600">
              Manage your payment methods for booking trusted sitters.
            </p>
          </CardHeader>
          <CardContent className="space-y-6">
            {paymentMethods.length > 0 ? (
              <div className="space-y-4">
                {paymentMethods.map((paymentMethod: any) => (
                  <div 
                    key={paymentMethod.id}
                    className="flex items-center justify-between p-4 border border-gray-200 rounded-lg bg-white"
                  >
                    <div className="flex items-center gap-3">
                      <div className="text-2xl">
                        {getCardBrandIcon(paymentMethod.card.brand)}
                      </div>
                      <div>
                        <div className="font-medium">
                          {formatCardBrand(paymentMethod.card.brand)} •••• {paymentMethod.card.last4}
                        </div>
                        <div className="text-sm text-gray-500">
                          Expires {paymentMethod.card.exp_month.toString().padStart(2, '0')}/{paymentMethod.card.exp_year}
                        </div>
                        {paymentMethod.billing_details.name && (
                          <div className="text-sm text-gray-500">
                            {paymentMethod.billing_details.name}
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary" className="bg-green-100 text-green-800">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Active
                      </Badge>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleRemovePaymentMethod(paymentMethod.id)}
                        disabled={deletePaymentMethodMutation.isPending}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}

                <div className="flex justify-between items-center pt-4 border-t">
                  <Button
                    variant="outline"
                    onClick={createSetupIntent}
                    className="flex items-center gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    Add New Payment Method
                  </Button>
                  <Button
                    onClick={() => setLocation('/find-sitter')}
                    className="bg-village-wine hover:bg-village-wine/90"
                  >
                    Find Sitters to Book
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <Alert>
                  <Shield className="w-4 h-4" />
                  <AlertDescription>
                    Add a secure payment method to start booking trusted sitters. Your card details are encrypted and secure.
                  </AlertDescription>
                </Alert>

                <div className="text-center">
                  <Button
                    onClick={createSetupIntent}
                    className="bg-village-wine hover:bg-village-wine/90 flex items-center gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    Add Payment Method
                  </Button>
                </div>

                <div className="text-center">
                  <Button
                    variant="ghost"
                    onClick={() => setLocation('/parent/dashboard')}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    I'll add this later
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Add Payment Method Dialog */}
        <Dialog open={showAddPaymentDialog} onOpenChange={setShowAddPaymentDialog}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-village-wine">Add Payment Method</DialogTitle>
            </DialogHeader>
            <div className="overflow-y-auto max-h-[70vh]">
              {clientSecret && (
                <Elements 
                  stripe={stripePromise} 
                  options={{ 
                    clientSecret,
                    appearance: {
                      theme: 'stripe',
                      variables: {
                        colorPrimary: '#8b1538', // village-wine color
                      }
                    }
                  }}
                >
                  <EmbeddedPaymentSetup 
                    onSuccess={handlePaymentSuccess} 
                    onCancel={() => setShowAddPaymentDialog(false)}
                  />
                </Elements>
              )}
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}