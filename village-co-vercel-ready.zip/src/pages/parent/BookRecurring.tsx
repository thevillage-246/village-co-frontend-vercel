import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Star, MapPin, Shield, CheckCircle, Award } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import RecurringBookingForm from '@/components/booking/RecurringBookingForm';
import { useToast } from '@/hooks/use-toast';

export default function BookRecurringPage() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [selectedSitterId, setSelectedSitterId] = useState<number | null>(null);

  // Get sitter ID from URL params
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const sitterId = urlParams.get('sitterId');
    if (sitterId) {
      setSelectedSitterId(parseInt(sitterId));
    }
  }, []);

  // Fetch sitters data
  const { data: sitters, isLoading } = useQuery({
    queryKey: ['/api/sitters'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/sitters');
      return response.json();
    },
  });

  // Find the selected sitter
  const selectedSitter = sitters?.find((s: any) => s.id === selectedSitterId);

  // Function to render rating stars
  const renderStars = (rating = 5) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star 
        key={i}
        className={`h-4 w-4 ${i < rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
      />
    ));
  };

  const handleBookingSubmit = async (seriesId: string, bookingCount: number) => {
    toast({
      title: "Recurring Booking Created!",
      description: `Created ${bookingCount} recurring bookings. Your sitter will be notified to approve the series.`,
    });
    
    // Navigate to booking series management
    navigate('/parent/bookings');
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-1/3 mb-6"></div>
            <div className="h-64 bg-gray-200 rounded mb-6"></div>
            <div className="h-96 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!selectedSitter) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/find-sitter')}
            className="mb-6"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Find Sitter
          </Button>
          
          <Card>
            <CardContent className="p-8 text-center">
              <h2 className="text-xl font-semibold mb-2">Sitter Not Found</h2>
              <p className="text-muted-foreground mb-4">
                The sitter you're looking for could not be found.
              </p>
              <Button onClick={() => navigate('/find-sitter')}>
                Browse All Sitters
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <Button 
          variant="ghost" 
          onClick={() => navigate('/find-sitter')}
          className="mb-6"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Find Sitter
        </Button>

        {/* Sitter Profile Summary */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="text-xl text-wine">Book Recurring Care</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-6">
              <Avatar className="h-20 w-20 border-2 border-linen">
                <AvatarImage src={selectedSitter.photoUrl || ''} alt={selectedSitter.firstName} />
                <AvatarFallback className="bg-rose text-wine text-lg">
                  {selectedSitter.firstName?.[0]}{selectedSitter.lastName?.[0]}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <h2 className="text-2xl font-semibold">
                    {selectedSitter.firstName} {selectedSitter.lastName}
                  </h2>
                  {selectedSitter.badge && (
                    <Badge variant="secondary" className="bg-eucalyptus/20 text-eucalyptus">
                      {selectedSitter.badge}
                    </Badge>
                  )}
                </div>
                
                <div className="flex items-center gap-4 mb-3">
                  <div className="flex items-center">
                    {renderStars(selectedSitter.rating || 5)}
                    <span className="ml-2 text-sm text-muted-foreground">
                      ({selectedSitter.reviewCount || 0} reviews)
                    </span>
                  </div>
                  <div className="font-semibold text-wine">
                    ${selectedSitter.hourlyRate}/hr
                  </div>
                </div>

                {selectedSitter.location && (
                  <p className="text-sm text-muted-foreground flex items-center mb-3">
                    <MapPin className="h-4 w-4 mr-1" />
                    {selectedSitter.location}
                  </p>
                )}

                {/* Trust Indicators */}
                <div className="flex flex-wrap gap-2">
                  <div className="flex items-center text-xs bg-green-50 text-green-700 px-2 py-1 rounded-full">
                    <Shield className="w-3 h-3 mr-1" />
                    ID Verified
                  </div>
                  <div className="flex items-center text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded-full">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    First Aid
                  </div>
                  <div className="flex items-center text-xs bg-purple-50 text-purple-700 px-2 py-1 rounded-full">
                    <Award className="w-3 h-3 mr-1" />
                    Village Verified
                  </div>
                </div>

                {selectedSitter.bio && (
                  <p className="text-sm text-muted-foreground mt-3 line-clamp-2">
                    {selectedSitter.bio}
                  </p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recurring Booking Form */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Create Your Recurring Schedule</CardTitle>
            <p className="text-muted-foreground">
              Set up regular childcare with {selectedSitter.firstName}. Perfect for after-school care, 
              date nights, or any recurring childcare needs.
            </p>
          </CardHeader>
          <CardContent>
            <RecurringBookingForm
              sitter={{
                id: selectedSitter.id,
                name: `${selectedSitter.firstName} ${selectedSitter.lastName}`,
                photoUrl: selectedSitter.photoUrl,
                hourlyRate: selectedSitter.hourlyRate,
                rating: selectedSitter.rating || 5,
                reviewCount: selectedSitter.reviewCount || 0,
                isFlexibleForRecurring: selectedSitter.isFlexibleForRecurring
              }}
              onSubmit={handleBookingSubmit}
              onCancel={() => navigate('/find-sitter')}
            />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}