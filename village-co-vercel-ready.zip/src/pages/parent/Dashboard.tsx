import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link, useLocation } from 'wouter';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { RebookPrompt } from '@/components/bookings';
import { TrustBar } from '@/components/profiles';
import InvitePartner from '@/components/parents/InvitePartner';
import TrustedAccountsList from '@/components/parents/TrustedAccountsList';
import VillageEditIntelligent from '@/components/parents/VillageEditIntelligent';
import ParentVerification from '@/components/parents/ParentVerification';
import ParentVeriffVerification from '@/components/parents/ParentVeriffVerification';
import { ProgressList } from '@/components/parents/ProgressList';
import { Calendar, Users, Clock, Star, UserPlus, Shield, MapPin, Sparkles } from 'lucide-react';
import EmergencyContactsManager from '@/components/EmergencyContactsManager';
import ReferAFriend from '@/components/parents/ReferAFriend';
import GrowSurfReferral from '@/components/parents/GrowSurfReferral';
import PersonalizedDashboard from '@/components/ai/PersonalizedDashboard';
import AiNotificationBadge from '@/components/ai/AiNotificationBadge';
import TrustedPartnerInvite from '@/components/TrustedPartnerInvite';



export default function ParentDashboard() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState('upcoming');

  // Check if parent profile exists
  const { data: parentProfile, isLoading: profileLoading } = useQuery({
    queryKey: ['/api/parents', user?.id, 'profile'],
    queryFn: async () => {
      const token = localStorage.getItem('authToken') || localStorage.getItem('auth_token');
      const response = await fetch(`/api/parents/${user?.id}/profile`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });
      if (!response.ok) {
        // If profile doesn't exist, that's expected and not an error
        if (response.status === 404) {
          return null;
        }
        throw new Error('Failed to fetch profile');
      }
      return response.json();
    },
    enabled: !!user?.id,
    retry: false
  });

  // Redirect to create profile if no profile exists and we've confirmed loading is complete
  useEffect(() => {
    if (!profileLoading && user && parentProfile === null) {
      console.log('No parent profile found, redirecting to create profile');
      setLocation('/create-profile');
    }
  }, [profileLoading, user, parentProfile, setLocation]);
  
  // Define types for our data
  interface Booking {
    id: number;
    start_time: string;
    end_time: string;
    sit_notes?: string;
    sitter: {
      id: number;
      first_name: string;
      verified?: boolean;
      first_aid_certified?: boolean;
      background_checked?: boolean;
    };
    review?: {
      rating: number;
    };
  }
  
  interface Sitter {
    id: number;
    first_name: string;
  }

  // Fetch upcoming bookings
  const { data: upcomingBookings = [] as Booking[], isLoading: loadingUpcoming } = useQuery<Booking[]>({
    queryKey: ['/api/bookings/upcoming'],
    enabled: !!user
  });
  
  // Fetch past bookings
  const { data: pastBookings = [] as Booking[], isLoading: loadingPast } = useQuery<Booking[]>({
    queryKey: ['/api/bookings/past'],
    enabled: !!user
  });
  
  // Fetch favorite sitters
  const { data: favoriteSitters = [] as Sitter[], isLoading: loadingFavorites } = useQuery<Sitter[]>({
    queryKey: ['/api/parent/favorites'],
    enabled: !!user
  });



  // Fetch parent verification status
  const { data: verificationStatus } = useQuery({
    queryKey: ['/api/veriff/parent-status'],
    enabled: !!user && user.role === 'parent'
  });

  // Check if parent is verified (either through Veriff or admin)
  const isParentVerified = verificationStatus?.status === 'approved' || parentProfile?.manuallyVerified === true;

  // Handle rebooking
  const handleRebook = (sitterId: string) => {
    if (!isParentVerified) {
      alert('Please complete your identity verification before booking sitters. This helps keep all families and sitters safe.');
      return;
    }
    // Navigate to booking page with pre-selected sitter
    window.location.href = `/book?sitter=${sitterId}`;
  };

  // Handle find sitter navigation with verification check
  const handleFindSitter = () => {
    if (!isParentVerified) {
      alert('Please complete your identity verification before booking sitters. This helps keep all families and sitters safe.');
      return;
    }
    window.location.href = '/find-sitter';
  };
  
  return (
    <div className="min-h-screen" style={{ backgroundColor: '#F9F5F0' }}>
      <div className="container max-w-6xl mx-auto py-4 sm:py-8 px-4">
        <div className="text-center mb-6 sm:mb-8">
          <div className="flex flex-col items-center mb-4">
            <div className="text-center mb-4 relative">
              <div className="absolute top-0 right-0 sm:right-4">
                <AiNotificationBadge userId={user?.id} />
              </div>
              <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-gray-900 mb-2" style={{ fontFamily: 'Satoshi, sans-serif' }}>Hey {user?.first_name || user?.firstName || 'there'}, ready for your next break?</h1>
              <p className="text-lg sm:text-xl text-gray-600" style={{ fontFamily: 'DM Sans, sans-serif' }}>Your Village Co. dashboard — where me-time begins</p>
            </div>
          </div>
        </div>
        
        {/* AI-Powered Personalized Dashboard */}
        <PersonalizedDashboard className="mb-8" />
        
        {/* Trusted Partner Invite */}
        <div className="mb-8">
          <TrustedPartnerInvite>
            <Button variant="outline" className="w-full">
              <UserPlus className="w-4 h-4 mr-2" />
              Invite a Trusted Partner
            </Button>
          </TrustedPartnerInvite>
        </div>
        
        {/* Founder Welcome Note */}
        <Card className="mb-6 bg-gradient-to-r from-village-wine/5 to-brushed-pink/10 rounded-xl shadow-lg border border-village-wine/20 overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="p-3 rounded-full bg-village-wine/10">
                <span className="text-2xl">👋</span>
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold text-village-wine mb-2" style={{ fontFamily: 'Satoshi, sans-serif' }}>
                  Welcome to The Village Co. Beta
                </h3>
                <p className="text-gray-700 mb-3 leading-relaxed" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                  You're part of the first wave of families trying our new platform — built by parents, for parents.
                </p>
                <p className="text-gray-700 mb-4 leading-relaxed" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                  Any bugs, questions, or thoughts? We're listening. This is your Village.
                </p>
                <div className="flex flex-col sm:flex-row gap-2 items-start">
                  <p className="text-village-wine font-semibold" style={{ fontFamily: 'Satoshi, sans-serif' }}>
                    — Nikki + Sophia ❤️
                  </p>
                  <div className="flex flex-wrap gap-2">
                    <Button 
                      asChild 
                      variant="outline" 
                      size="sm" 
                      className="text-xs border-village-wine/30 text-village-wine hover:bg-village-wine/10"
                    >
                      <a href="mailto:info@thevillageco.nz">Email us at info@thevillageco.nz</a>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Modern Parent Profile Card */}
        {parentProfile && (
          <Card className="mb-6 bg-white rounded-xl shadow-lg border-0 overflow-hidden">
            <CardHeader className="bg-white border-b border-gray-100">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-full" style={{ backgroundColor: '#6B3E4B', color: 'white' }}>
                    <Users className="w-6 h-6" />
                  </div>
                  <div>
                    <CardTitle className="text-xl text-gray-900" style={{ fontFamily: 'Satoshi, sans-serif' }}>Your Parent Profile</CardTitle>
                    <CardDescription className="text-gray-600" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                      What sitters see when you book
                    </CardDescription>
                  </div>
                </div>
                <Button asChild variant="outline" size="sm" className="rounded-lg" style={{ borderColor: '#6B3E4B', color: '#6B3E4B' }}>
                  <Link to="/parent/edit-profile">Edit</Link>
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-6">
                {/* About Section */}
                {parentProfile.bio && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-village-wine font-semibold">
                      <Sparkles className="w-4 h-4" />
                      About Me
                    </div>
                    <p className="text-gray-700 leading-relaxed bg-white/50 p-4 rounded-lg border-l-4 border-village-wine/20">
                      {parentProfile.bio}
                    </p>
                  </div>
                )}

                {/* Location Section */}
                {parentProfile.address && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-village-wine font-semibold">
                      <MapPin className="w-4 h-4" />
                      Location
                    </div>
                    <p className="text-gray-700 bg-white/50 p-3 rounded-lg">
                      {parentProfile.address}
                    </p>
                  </div>
                )}

                {/* Children Section */}
                {parentProfile.children && Array.isArray(parentProfile.children) && parentProfile.children.length > 0 && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-village-wine font-semibold">
                      <Users className="w-4 h-4" />
                      My Little Ones
                    </div>
                    <div className="bg-gradient-to-r from-brushed-pink/20 to-village-wine/10 p-4 rounded-lg border border-village-wine/10">
                      <div className="space-y-2">
                        {parentProfile.children.map((child: any, index: number) => (
                          <div key={index} className="text-gray-700 leading-relaxed">
                            <span className="font-medium">{child.name}</span>
                            {child.age && <span className="text-gray-600 ml-2">({child.age} years old)</span>}
                            {child.notes && <div className="text-sm text-gray-600 mt-1">{child.notes}</div>}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Progress List - Getting Started */}
        <div className="mb-6">
          <ProgressList 
            user={user} 
            parentProfile={parentProfile} 
            verificationStatus={verificationStatus?.status} 
          />
        </div>

        <div className="flex flex-col space-y-4 lg:flex-row lg:space-y-0 lg:space-x-4 mb-8">
          <Card className="flex-1 bg-white rounded-xl shadow-lg border-0">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg sm:text-xl text-gray-900" style={{ fontFamily: 'Satoshi, sans-serif' }}>Your Village Activity</CardTitle>
              <CardDescription className="text-sm text-gray-600" style={{ fontFamily: 'DM Sans, sans-serif' }}>Building trust, one sit at a time</CardDescription>
            </CardHeader>
            <CardContent>
            <div className="grid grid-cols-2 gap-3 sm:gap-4">
              <div className="flex flex-col items-center justify-center p-3 sm:p-4 rounded-xl" style={{ backgroundColor: '#6B3E4B20' }}>
                <Calendar className="h-6 w-6 sm:h-8 sm:w-8 mb-2" style={{ color: '#6B3E4B' }} />
                <span className="text-xl sm:text-2xl font-bold" style={{ color: '#6B3E4B', fontFamily: 'Satoshi, sans-serif' }}>{upcomingBookings.length}</span>
                <span className="text-xs sm:text-sm text-gray-600 text-center" style={{ fontFamily: 'DM Sans, sans-serif' }}>Upcoming Sits</span>
              </div>
              <div className="flex flex-col items-center justify-center p-3 sm:p-4 rounded-xl" style={{ backgroundColor: '#FDF2F8' }}>
                <Users className="h-6 w-6 sm:h-8 sm:w-8 mb-2" style={{ color: '#6B3E4B' }} />
                <span className="text-xl sm:text-2xl font-bold" style={{ color: '#6B3E4B', fontFamily: 'Satoshi, sans-serif' }}>{favoriteSitters.length}</span>
                <span className="text-xs sm:text-sm text-gray-600 text-center" style={{ fontFamily: 'DM Sans, sans-serif' }}>Favourite Sitters</span>
              </div>
            </div>
          </CardContent>
          <CardFooter className="pt-4">
            <Button 
              onClick={handleFindSitter}
              className="w-full rounded-lg text-white text-sm sm:text-base"
              style={{ 
                backgroundColor: isParentVerified ? '#6B3E4B' : '#9CA3AF',
                fontFamily: 'DM Sans, sans-serif'
              }}
              disabled={!isParentVerified}
            >
              {isParentVerified ? 'Find a Sitter' : 'Complete Verification to Book'}
            </Button>
          </CardFooter>
        </Card>
        
        {favoriteSitters.length > 0 && (
          <Card className="flex-1 bg-white rounded-xl shadow-lg border-0">
            <CardHeader className="pb-2">
              <CardTitle className="text-xl text-gray-900" style={{ fontFamily: 'Satoshi, sans-serif' }}>Book Again</CardTitle>
              <CardDescription className="text-gray-600" style={{ fontFamily: 'DM Sans, sans-serif' }}>Your recent sitters are available</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {(favoriteSitters as Sitter[]).slice(0, 1).map((sitter) => (
                <RebookPrompt 
                  key={sitter.id}
                  sitterName={sitter.first_name}
                  onRebook={() => handleRebook(sitter.id.toString())}
                />
              ))}
            </CardContent>
          </Card>
        )}
      </div>
      
      {/* Smart Feed and Trusted Accounts Section */}
      {/* Main Content - Responsive Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6 lg:gap-8 mb-6 lg:mb-8">
        {/* Main Content Area */}
        <div className="lg:col-span-2 space-y-4 sm:space-y-6">
          <VillageEditIntelligent />
        </div>
        
        {/* Sidebar */}
        <div className="lg:col-span-1 space-y-4 sm:space-y-6">
          <ParentVeriffVerification />
          
          {/* Trusted Partner Invite System */}
          <TrustedPartnerInvite />
          
          {/* GrowSurf Referral System */}
          <GrowSurfReferral />
          
          {/* Plans & Events */}
          <Card className="bg-white rounded-xl shadow-lg border-0">
            <CardHeader className="pb-3">
              <CardTitle className="text-base sm:text-lg text-gray-900 flex items-center gap-2" style={{ fontFamily: 'Satoshi, sans-serif' }}>
                <Sparkles className="w-4 h-4 sm:w-5 sm:h-5" style={{ color: '#6B3E4B' }} />
                Village Plans & Events
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xs sm:text-sm text-gray-600 mb-3" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                Join our monthly subscription plans and community events for a better village experience.
              </p>
              <Button 
                asChild
                size="sm"
                className="w-full text-sm text-white rounded-lg"
                style={{ backgroundColor: '#6B3E4B', fontFamily: 'DM Sans, sans-serif' }}
              >
                <Link to="/plans-events">View Plans & Events</Link>
              </Button>
            </CardContent>
          </Card>
          

          
          {/* Family Access Section */}
          <Card className="bg-white rounded-xl shadow-lg border-0">
            <CardHeader className="pb-3">
              <CardTitle className="text-base sm:text-lg text-gray-900 flex items-center gap-2" style={{ fontFamily: 'Satoshi, sans-serif' }}>
                <UserPlus className="w-4 h-4 sm:w-5 sm:h-5" style={{ color: '#6B3E4B' }} />
                Family Access
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <InvitePartner />
              <TrustedAccountsList />
            </CardContent>
          </Card>
        </div>
      </div>
      
      <Tabs defaultValue="upcoming" value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 mb-6 lg:mb-8">
          <TabsTrigger value="upcoming" className="text-sm px-2 sm:px-4">Upcoming Sits</TabsTrigger>
          <TabsTrigger value="past" className="text-sm px-2 sm:px-4">Past Sits</TabsTrigger>
          <TabsTrigger value="emergency" className="text-sm px-2 sm:px-4">Emergency Contacts</TabsTrigger>
        </TabsList>
        
        <TabsContent value="upcoming" className="space-y-4 sm:space-y-6">
          {loadingUpcoming ? (
            <div className="flex justify-center p-8">
              <div className="animate-spin h-8 w-8 border-4 border-village-wine border-t-transparent rounded-full"></div>
            </div>
          ) : upcomingBookings.length === 0 ? (
            <Card className="bg-white rounded-xl shadow-lg border-0">
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Calendar className="h-12 w-12 mb-4" style={{ color: '#6B3E4B' }} />
                <p className="text-gray-600 text-center" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                  You don't have any upcoming sits scheduled.
                </p>
                <Button 
                  onClick={handleFindSitter}
                  className="mt-4 rounded-lg text-white"
                  style={{ 
                    backgroundColor: isParentVerified ? '#6B3E4B' : '#9CA3AF',
                    fontFamily: 'DM Sans, sans-serif'
                  }}
                  disabled={!isParentVerified}
                >
                  {isParentVerified ? 'Find a Sitter' : 'Complete Verification to Book'}
                </Button>
              </CardContent>
            </Card>
          ) : (
            (upcomingBookings as Booking[]).map((booking) => (
              <Card key={booking.id} className="overflow-hidden bg-white rounded-xl shadow-lg border-0">
                <div className="flex flex-col md:flex-row">
                  <div className="p-4 flex items-center justify-center bg-brushed-pink md:w-1/4">
                    <div className="text-center">
                      <p className="text-sm uppercase tracking-wide text-muted-foreground">
                        {new Date(booking.start_time).toLocaleDateString('en-NZ', { weekday: 'short' })}
                      </p>
                      <p className="text-3xl font-bold">
                        {new Date(booking.start_time).getDate()}
                      </p>
                      <p className="text-sm font-medium">
                        {new Date(booking.start_time).toLocaleDateString('en-NZ', { month: 'short' })}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex flex-col justify-between p-4 md:flex-1">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="text-lg font-semibold">{booking.sitter.first_name}</h3>
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 text-muted-foreground mr-1" />
                          <span className="text-sm text-muted-foreground">
                            {new Date(booking.start_time).toLocaleTimeString('en-NZ', {
                              hour: '2-digit',
                              minute: '2-digit',
                              hour12: true
                            })} - {new Date(booking.end_time).toLocaleTimeString('en-NZ', {
                              hour: '2-digit',
                              minute: '2-digit',
                              hour12: true
                            })}
                          </span>
                        </div>
                      </div>
                      
                      <TrustBar
                        verified={booking.sitter.verified}
                        firstAid={booking.sitter.first_aid_certified}
                        background={booking.sitter.background_checked}
                      />
                      
                      <p className="mt-4 text-sm">
                        {booking.sit_notes || 'No special instructions provided.'}
                      </p>
                    </div>
                    
                    <div className="flex justify-end mt-4 gap-2">
                      <Button variant="outline" asChild>
                        <Link to={`/messages?sitterId=${booking.sitter.id}`}>Message</Link>
                      </Button>
                      <Button className="bg-village-wine hover:bg-village-wine/90" asChild>
                        <Link to={`/book-sitter/${booking.sitter.id}`}>Book Again</Link>
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            ))
          )}
        </TabsContent>
        
        <TabsContent value="past" className="space-y-4 sm:space-y-6">
          {loadingPast ? (
            <div className="flex justify-center p-8">
              <div className="animate-spin h-8 w-8 border-4 border-wine border-t-transparent rounded-full"></div>
            </div>
          ) : pastBookings.length === 0 ? (
            <Card className="bg-white rounded-xl shadow-lg border-0">
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Clock className="h-12 w-12 text-gray-400 mb-4" />
                <p className="text-gray-600 text-center" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                  You don't have any past sits to display.
                </p>
              </CardContent>
            </Card>
          ) : (
            (pastBookings as Booking[]).map((booking) => (
              <Card key={booking.id} className="overflow-hidden bg-white rounded-xl shadow-lg border-0">
                <div className="flex flex-col md:flex-row">
                  <div className="p-4 flex items-center justify-center bg-brushed-pink md:w-1/4">
                    <div className="text-center">
                      <p className="text-sm uppercase tracking-wide text-muted-foreground">
                        {new Date(booking.start_time).toLocaleDateString('en-NZ', { weekday: 'short' })}
                      </p>
                      <p className="text-3xl font-bold">
                        {new Date(booking.start_time).getDate()}
                      </p>
                      <p className="text-sm font-medium">
                        {new Date(booking.start_time).toLocaleDateString('en-NZ', { month: 'short' })}
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex flex-col justify-between p-4 md:flex-1">
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="text-lg font-semibold">{booking.sitter.first_name}</h3>
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 text-muted-foreground mr-1" />
                          <span className="text-sm text-muted-foreground">
                            {new Date(booking.start_time).toLocaleTimeString('en-NZ', {
                              hour: '2-digit',
                              minute: '2-digit',
                              hour12: true
                            })} - {new Date(booking.end_time).toLocaleTimeString('en-NZ', {
                              hour: '2-digit',
                              minute: '2-digit',
                              hour12: true
                            })}
                          </span>
                        </div>
                      </div>
                      
                      {booking.review ? (
                        <div className="flex items-center mt-2">
                          <Star className="h-4 w-4 text-amber-500 mr-1" />
                          <span className="text-sm font-medium">Your rating: {booking.review.rating}/5</span>
                        </div>
                      ) : (
                        <Button variant="outline" size="sm" className="mt-2" asChild>
                          <Link to={`/bookings/${booking.id}/review`}>Leave a Review</Link>
                        </Button>
                      )}
                    </div>
                    
                    <div className="flex justify-end mt-4 gap-2">
                      <Button 
                        onClick={() => handleRebook(booking.sitter.id.toString())}
                        className="bg-village-wine hover:bg-village-wine/90 rounded-xl"
                      >
                        Book Again
                      </Button>
                    </div>
                  </div>
                </div>
              </Card>
            ))
          )}
        </TabsContent>
        
        <TabsContent value="emergency" className="space-y-4">
          <EmergencyContactsManager />
        </TabsContent>
      </Tabs>
      </div>
    </div>
  );
}