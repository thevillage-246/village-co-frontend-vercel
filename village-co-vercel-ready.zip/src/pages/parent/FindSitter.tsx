import { useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { supabase } from '@/lib/supabase';
import SEO, { SEOConfigs } from '@/components/SEO';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { Slider } from '@/components/ui/slider';
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Star, Calendar, MapPin, Filter, Heart, Coffee, Briefcase, Sparkles, Shield, CheckCircle, Award, Wine, Gift, ExternalLink, Search, X, Clock, Repeat, Map } from 'lucide-react';
import { USER_ROLES } from '@shared/schema';
import { Skeleton } from '@/components/ui/skeleton';
import { Link } from 'wouter';
import SitterCard from '@/components/SitterCard';
// import EnhancedSitterCard from '@/components/sitters/EnhancedSitterCard'; // Temporarily disabled - has broken API calls
import FavoriteSittersSection from '@/components/FavoriteSittersSection';
import { GooglePlacesAutocomplete } from '@/components/GooglePlacesAutocomplete';
import { SittersMap } from '@/components/SittersMap';
import { calculateDistance } from '@/lib/googleMaps';
import { format } from 'date-fns';

export default function FindSitterPage() {
  const [sitters, setSitters] = useState<any[]>([]);
  const [filteredSitters, setFilteredSitters] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [, navigate] = useLocation();

  // Filter states
  const [searchRadius, setSearchRadius] = useState(25);
  const [locationQuery, setLocationQuery] = useState('');
  const [selectedLocation, setSelectedLocation] = useState<{ lat: number; lng: number; address: string } | null>(null);
  const [mapCenter, setMapCenter] = useState({ lat: -37.7870, lng: 175.2793 }); // Hamilton, NZ
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');
  const [mapsAvailable, setMapsAvailable] = useState(true);
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [selectedTime, setSelectedTime] = useState('');
  const [priceRange, setPriceRange] = useState([10, 80]);
  const [nameSearch, setNameSearch] = useState(''); // Add name search filter
  const [verificationFilters, setVerificationFilters] = useState({
    idVerified: false,
    firstAid: false,
    backgroundCheck: false,
    villageVerified: false,
  });
  const [badgeFilters, setBadgeFilters] = useState({
    villageVerified: false,
    topSitter: false,
    superSitter: false,
    policeChecked: false,
    firstAidCertified: false,
  });
  const [qualificationFilters, setQualificationFilters] = useState({
    // Health & Safety
    firstAidCert: false,
    cprCert: false,
    policeCheck: false,
    childProtection: false,
    // Education & Experience
    earlyChildhood: false,
    teachingDegree: false,
    montessori: false,
    specialNeeds: false,
    // Additional Skills
    swimming: false,
    music: false,
    languages: false,
  });
  const [ratingFilter, setRatingFilter] = useState(0);
  const [showFilters, setShowFilters] = useState(false);
  const [instantBookOnly, setInstantBookOnly] = useState(false);



  useEffect(() => {
    const loadSitters = async () => {
      try {
        setIsLoading(true);
        
        // Load public sitter listings with privacy protection
        const response = await fetch('/api/sitters/public');
        
        if (response.ok) {
          const sittersData = await response.json();
          setSitters(sittersData);
          console.log(`✅ Loaded ${sittersData.length} verified sitters from API`);
          console.log('Sitters data:', sittersData);
        } else {
          throw new Error(`Failed to load sitters: ${response.status}`);
        }
      } catch (err: any) {
        console.error('Error loading sitters:', err);
        setError(err.message);
      } finally {
        setIsLoading(false);
      }
    };
    
    // Set SEO meta tags for Find Sitter page
    document.title = "Find a Babysitter - Browse Trusted Sitters | The Village Co.";
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute('content', 'Browse and book trusted, verified babysitters in New Zealand. Filter by location, price, qualifications, and availability. Find your perfect sitter with The Village Co.');
    }
    
    loadSitters();
  }, []);

  // Check Google Maps availability and handle API errors
  useEffect(() => {
    const checkMapsAvailability = () => {
      if (!import.meta.env.VITE_GOOGLE_MAPS_API_KEY) {
        setMapsAvailable(false);
        return;
      }
      
      // Listen for Google Maps API errors in console
      const originalError = console.error;
      console.error = (...args) => {
        if (args[0]?.includes?.('Google Maps JavaScript API error') || 
            args[0]?.includes?.('RefererNotAllowedMapError')) {
          setMapsAvailable(false);
          if (viewMode === 'map') {
            setViewMode('list'); // Switch back to list view
          }
        }
        originalError(...args);
      };
    };

    checkMapsAvailability();
  }, [viewMode]);

  // Handler for location selection from Google Places
  const handleLocationSelect = (place: google.maps.places.PlaceResult) => {
    if (place.geometry?.location && place.formatted_address) {
      const location = {
        lat: place.geometry.location.lat(),
        lng: place.geometry.location.lng(),
        address: place.formatted_address
      };
      setSelectedLocation(location);
      setMapCenter({ lat: location.lat, lng: location.lng });
      setLocationQuery(place.formatted_address);
    }
  };

  // Filter sitters when filters change
  useEffect(() => {
    console.log('Filtering sitters, total:', sitters.length);
    let filtered = [...sitters];

    // Apply location-based filtering if location is selected
    if (selectedLocation && searchRadius > 0) {
      filtered = filtered.filter(sitter => {
        // Use actual sitter coordinates if available, otherwise skip location filtering for this sitter
        if (sitter.latitude && sitter.longitude) {
          const distance = calculateDistance(
            selectedLocation.lat,
            selectedLocation.lng,
            sitter.latitude,
            sitter.longitude
          );
          return distance <= searchRadius;
        }
        // Include sitters without coordinates in results (for now)
        return true;
      });
    } else if (locationQuery.trim() && !selectedLocation) {
      // Fallback text-based filtering
      filtered = filtered.filter(sitter => 
        sitter.location?.toLowerCase().includes(locationQuery.toLowerCase()) ||
        sitter.full_name?.toLowerCase().includes(locationQuery.toLowerCase()) ||
        (sitter.firstName && sitter.lastName && `${sitter.firstName} ${sitter.lastName}`.toLowerCase().includes(locationQuery.toLowerCase()))
      );
    }

    // Apply name search filter
    if (nameSearch.trim()) {
      filtered = filtered.filter(sitter => {
        const searchTerm = nameSearch.toLowerCase().trim();
        const firstName = sitter.firstName?.toLowerCase() || '';
        const lastName = sitter.lastName?.toLowerCase() || '';
        const fullName = `${firstName} ${lastName}`.trim();
        
        return firstName.includes(searchTerm) || 
               lastName.includes(searchTerm) || 
               fullName.includes(searchTerm);
      });
    }

    // Apply price range filter
    if (priceRange[0] > 10 || priceRange[1] < 80) {
      filtered = filtered.filter(sitter => {
        const rate = typeof sitter.hourlyRate === 'string' ? parseFloat(sitter.hourlyRate) : sitter.hourlyRate;
        return rate >= priceRange[0] && rate <= priceRange[1];
      });
    }

    // Apply rating filter
    if (ratingFilter > 0) {
      filtered = filtered.filter(sitter => sitter.rating >= ratingFilter);
    }

    // Apply verification filters
    if (verificationFilters.idVerified || verificationFilters.firstAid || verificationFilters.backgroundCheck || verificationFilters.villageVerified) {
      filtered = filtered.filter(sitter => {
        if (verificationFilters.idVerified && sitter.veriffStatus !== 'approved') return false;
        if (verificationFilters.firstAid && !sitter.skills?.some((skill: any) => skill.name === 'First Aid')) return false;
        if (verificationFilters.backgroundCheck && !sitter.backgroundCheckDate) return false;
        if (verificationFilters.villageVerified && !sitter.isApproved) return false;
        return true;
      });
    }

    // Apply badge filters
    if (Object.values(badgeFilters).some(Boolean)) {
      filtered = filtered.filter(sitter => {
        if (badgeFilters.villageVerified && sitter.badge !== 'Village Verified' && !sitter.introCallCompleted) return false;
        if (badgeFilters.topSitter && sitter.badge !== 'Top Sitter') return false;
        if (badgeFilters.superSitter && sitter.badge !== 'Super Sitter') return false;
        if (badgeFilters.policeChecked && !sitter.backgroundCheckDate) return false;
        if (badgeFilters.firstAidCertified && !sitter.firstAidCertDate) return false;
        
        return true;
      });
    }

    // Apply qualification filters
    if (Object.values(qualificationFilters).some(Boolean)) {
      filtered = filtered.filter(sitter => {
        // Helper function to check qualifications (handles both string and object formats)
        const hasQualification = (searchTerms: string[]) => {
          return sitter.qualifications?.some((qual: any) => {
            if (typeof qual === 'string') {
              return searchTerms.some(term => qual.includes(term));
            } else if (qual && typeof qual === 'object' && qual.displayName) {
              return searchTerms.some(term => qual.displayName.includes(term));
            }
            return false;
          });
        };

        // Check Health & Safety qualifications
        if (qualificationFilters.firstAidCert && !hasQualification(['First Aid'])) return false;
        if (qualificationFilters.cprCert && !hasQualification(['CPR'])) return false;
        if (qualificationFilters.policeCheck && !hasQualification(['Police', 'Background'])) return false;
        if (qualificationFilters.childProtection && !hasQualification(['Child Protection'])) return false;
        
        // Check Education & Experience qualifications
        if (qualificationFilters.earlyChildhood && !hasQualification(['Early Childhood', 'Education'])) return false;
        if (qualificationFilters.teachingDegree && !hasQualification(['Teaching', 'Degree'])) return false;
        if (qualificationFilters.montessori && !hasQualification(['Montessori'])) return false;
        if (qualificationFilters.specialNeeds && !hasQualification(['Special Needs'])) return false;
        
        // Check Additional Skills qualifications
        if (qualificationFilters.swimming && !hasQualification(['Swimming'])) return false;
        if (qualificationFilters.music && !hasQualification(['Music'])) return false;
        if (qualificationFilters.languages && !hasQualification(['Multilingual', 'Language'])) return false;
        
        return true;
      });
    }

    // Apply instant book filter
    if (instantBookOnly) {
      filtered = filtered.filter(sitter => {
        // Check if sitter is available for instant booking
        // This checks for canBeBooked field and active status
        return sitter.canBeBooked === true && sitter.isActive === true;
      });
    }

    console.log('Filtered sitters count:', filtered.length);
    setFilteredSitters(filtered);
  }, [sitters, locationQuery, selectedLocation, searchRadius, selectedDate, selectedTime, priceRange, nameSearch, verificationFilters, badgeFilters, qualificationFilters, ratingFilter, instantBookOnly]);

  // Function to clear all filters
  const clearFilters = () => {
    setLocationQuery('');
    setSelectedLocation(null);
    setMapCenter({ lat: -37.7870, lng: 175.2793 }); // Reset to Hamilton default
    setSelectedDate(undefined);
    setSelectedTime('');
    setPriceRange([10, 80]);
    setVerificationFilters({
      idVerified: false,
      firstAid: false,
      backgroundCheck: false,
      villageVerified: false,
    });
    setBadgeFilters({
      villageVerified: false,
      topSitter: false,
      superSitter: false,
      policeChecked: false,
      firstAidCertified: false,
    });
    setQualificationFilters({
      // Health & Safety
      firstAidCert: false,
      cprCert: false,
      policeCheck: false,
      childProtection: false,
      // Education & Experience
      earlyChildhood: false,
      teachingDegree: false,
      montessori: false,
      specialNeeds: false,
      // Additional Skills
      swimming: false,
      music: false,
      languages: false,
    });
    setRatingFilter(0);
    setSearchRadius(25);
    setInstantBookOnly(false);
    setNameSearch(''); // Clear name search
  };

  // Handle sitter selection from map
  const handleSitterSelect = (sitter: any) => {
    navigate(`/profile/${sitter.userId || sitter.user_id}`);
  };

  // Function to expand search area
  const expandSearchArea = () => {
    setSearchRadius(prev => Math.min(prev + 10, 100));
  };

  // Function to render rating stars
  const renderStars = (rating = 5) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star 
        key={i}
        className={`h-4 w-4 ${i < rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
      />
    ));
  };

  // Filter Panel Component
  const FilterPanel = () => (
    <div className="space-y-6">
      <div>
        <h3 className="font-semibold mb-3">Search by Name</h3>
        <div className="relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search sitters by first name..."
            value={nameSearch}
            onChange={(e) => setNameSearch(e.target.value)}
            className="pl-10"
          />
          {nameSearch && (
            <button
              onClick={() => setNameSearch('')}
              className="absolute right-3 top-3 text-gray-400 hover:text-gray-600"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
      </div>

      <div>
        <h3 className="font-semibold mb-3">Search Area</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label className="text-sm">Within {searchRadius} km</Label>
            <span className="text-xs text-muted-foreground">{searchRadius}km</span>
          </div>
          <Slider
            value={[searchRadius]}
            onValueChange={(value) => setSearchRadius(value[0])}
            max={100}
            min={5}
            step={5}
            className="w-full"
          />
        </div>
      </div>

      <div>
        <h3 className="font-semibold mb-3">Price Range</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label className="text-sm">${priceRange[0]} - ${priceRange[1]} per hour</Label>
          </div>
          <Slider
            value={priceRange}
            onValueChange={setPriceRange}
            max={80}
            min={10}
            step={5}
            className="w-full"
          />
        </div>
      </div>

      <div>
        <h3 className="font-semibold mb-3">Booking Options</h3>
        <div className="grid grid-cols-2 gap-3">
          <button
            onClick={() => setInstantBookOnly(!instantBookOnly)}
            className={`p-4 rounded-lg border-2 text-left transition-all ${
              instantBookOnly 
                ? 'border-village-wine bg-village-wine/5' 
                : 'border-gray-200 hover:border-gray-300'
            }`}
          >
            <div className="flex flex-col items-center space-y-2">
              <div className={`p-2 rounded-lg ${instantBookOnly ? 'bg-village-wine/10' : 'bg-gray-100'}`}>
                <Clock className={`h-6 w-6 ${instantBookOnly ? 'text-village-wine' : 'text-gray-600'}`} />
              </div>
              <div className="text-center">
                <div className="font-medium text-sm">Instant Book</div>
                <div className="text-xs text-gray-500">Book immediately</div>
              </div>
            </div>
          </button>
        </div>
      </div>

      <div>
        <h3 className="font-semibold mb-3">Minimum Rating</h3>
        <div className="flex items-center gap-2">
          {[1, 2, 3, 4, 5].map((rating) => (
            <button
              key={rating}
              onClick={() => setRatingFilter(rating === ratingFilter ? 0 : rating)}
              className={`p-1 rounded ${rating <= ratingFilter ? 'text-yellow-400' : 'text-gray-300'}`}
            >
              <Star className="h-5 w-5 fill-current" />
            </button>
          ))}
          <span className="text-sm text-muted-foreground ml-2">
            {ratingFilter > 0 ? `${ratingFilter}+ stars` : 'Any rating'}
          </span>
        </div>
      </div>

      <div>
        <h3 className="font-semibold mb-3">Verifications</h3>
        <div className="space-y-3">
          <div className="flex items-center space-x-2">
            <Checkbox
              id="id-verified"
              checked={verificationFilters.idVerified}
              onCheckedChange={(checked) =>
                setVerificationFilters(prev => ({ ...prev, idVerified: checked as boolean }))
              }
            />
            <Label htmlFor="id-verified" className="text-sm flex items-center gap-2">
              <Shield className="h-4 w-4 text-green-600" />
              ID Verified
            </Label>
          </div>
          
          <div className="flex items-center space-x-2">
            <Checkbox
              id="first-aid"
              checked={verificationFilters.firstAid}
              onCheckedChange={(checked) =>
                setVerificationFilters(prev => ({ ...prev, firstAid: checked as boolean }))
              }
            />
            <Label htmlFor="first-aid" className="text-sm flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-blue-600" />
              First Aid Certified
            </Label>
          </div>
          
          <div className="flex items-center space-x-2">
            <Checkbox
              id="background-check"
              checked={verificationFilters.backgroundCheck}
              onCheckedChange={(checked) =>
                setVerificationFilters(prev => ({ ...prev, backgroundCheck: checked as boolean }))
              }
            />
            <Label htmlFor="background-check" className="text-sm flex items-center gap-2">
              <Shield className="h-4 w-4 text-purple-600" />
              Background Checked
            </Label>
          </div>
          
          <div className="flex items-center space-x-2">
            <Checkbox
              id="village-verified"
              checked={verificationFilters.villageVerified}
              onCheckedChange={(checked) =>
                setVerificationFilters(prev => ({ ...prev, villageVerified: checked as boolean }))
              }
            />
            <Label htmlFor="village-verified" className="text-sm flex items-center gap-2">
              <Award className="h-4 w-4 text-village-wine" />
              Village Verified
            </Label>
          </div>
        </div>
      </div>

      <div>
        <h3 className="font-semibold mb-3">Sitter Badges</h3>
        <div className="space-y-2">
          <div className="flex items-center space-x-2">
            <Checkbox
              id="badge-village-verified"
              checked={badgeFilters.villageVerified}
              onCheckedChange={(checked) =>
                setBadgeFilters(prev => ({ ...prev, villageVerified: checked as boolean }))
              }
            />
            <Label htmlFor="badge-village-verified" className="text-sm flex items-center gap-2">
              <Award className="h-4 w-4 text-green-600" />
              Village Verified
            </Label>
          </div>
          
          <div className="flex items-center space-x-2">
            <Checkbox
              id="badge-top-sitter"
              checked={badgeFilters.topSitter}
              onCheckedChange={(checked) =>
                setBadgeFilters(prev => ({ ...prev, topSitter: checked as boolean }))
              }
            />
            <Label htmlFor="badge-top-sitter" className="text-sm flex items-center gap-2">
              <Star className="h-4 w-4 text-yellow-600" />
              Top Sitter
            </Label>
          </div>
          
          <div className="flex items-center space-x-2">
            <Checkbox
              id="badge-super-sitter"
              checked={badgeFilters.superSitter}
              onCheckedChange={(checked) =>
                setBadgeFilters(prev => ({ ...prev, superSitter: checked as boolean }))
              }
            />
            <Label htmlFor="badge-super-sitter" className="text-sm flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-purple-600" />
              Super Sitter
            </Label>
          </div>
          
          <div className="flex items-center space-x-2">
            <Checkbox
              id="badge-police-checked"
              checked={badgeFilters.policeChecked}
              onCheckedChange={(checked) =>
                setBadgeFilters(prev => ({ ...prev, policeChecked: checked as boolean }))
              }
            />
            <Label htmlFor="badge-police-checked" className="text-sm flex items-center gap-2">
              <Shield className="h-4 w-4 text-blue-600" />
              Police Checked
            </Label>
          </div>
          
          <div className="flex items-center space-x-2">
            <Checkbox
              id="badge-first-aid-certified"
              checked={badgeFilters.firstAidCertified}
              onCheckedChange={(checked) =>
                setBadgeFilters(prev => ({ ...prev, firstAidCertified: checked as boolean }))
              }
            />
            <Label htmlFor="badge-first-aid-certified" className="text-sm flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-red-600" />
              First Aid Certified
            </Label>
          </div>
        </div>
        
        {/* Badge Descriptions */}
        <div className="mt-3 p-3 bg-gray-50 rounded-lg text-xs text-gray-600 space-y-1">
          <p><strong>Village Verified:</strong> Completed full onboarding call and ID verification</p>
          <p><strong>Top Sitter:</strong> Completed over 5 bookings and loved by local families</p>
          <p><strong>Super Sitter:</strong> 10+ bookings, 5-star feedback, quick to respond</p>
          <p><strong>Police Checked:</strong> Official NZ police check submitted and approved</p>
          <p><strong>First Aid Certified:</strong> Uploaded first aid certificate, verified by team</p>
        </div>
      </div>

      <div>
        <h3 className="font-semibold mb-3">Qualifications</h3>
        
        {/* Health & Safety */}
        <div className="mb-4">
          <h4 className="text-sm font-medium text-muted-foreground mb-2">Health & Safety</h4>
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="first-aid-cert"
                checked={qualificationFilters.firstAidCert}
                onCheckedChange={(checked) =>
                  setQualificationFilters(prev => ({ ...prev, firstAidCert: checked as boolean }))
                }
              />
              <Label htmlFor="first-aid-cert" className="text-sm">
                🏥 First Aid Certified
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="cpr-cert"
                checked={qualificationFilters.cprCert}
                onCheckedChange={(checked) =>
                  setQualificationFilters(prev => ({ ...prev, cprCert: checked as boolean }))
                }
              />
              <Label htmlFor="cpr-cert" className="text-sm">
                ❤️ CPR Certified
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="police-check"
                checked={qualificationFilters.policeCheck}
                onCheckedChange={(checked) =>
                  setQualificationFilters(prev => ({ ...prev, policeCheck: checked as boolean }))
                }
              />
              <Label htmlFor="police-check" className="text-sm">
                🛡️ Police Background Check
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="child-protection"
                checked={qualificationFilters.childProtection}
                onCheckedChange={(checked) =>
                  setQualificationFilters(prev => ({ ...prev, childProtection: checked as boolean }))
                }
              />
              <Label htmlFor="child-protection" className="text-sm">
                🔒 Child Protection Training
              </Label>
            </div>
          </div>
        </div>

        {/* Education & Experience */}
        <div className="mb-4">
          <h4 className="text-sm font-medium text-muted-foreground mb-2">Education & Experience</h4>
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="early-childhood"
                checked={qualificationFilters.earlyChildhood}
                onCheckedChange={(checked) =>
                  setQualificationFilters(prev => ({ ...prev, earlyChildhood: checked as boolean }))
                }
              />
              <Label htmlFor="early-childhood" className="text-sm">
                🎓 Early Childhood Education
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="teaching-degree"
                checked={qualificationFilters.teachingDegree}
                onCheckedChange={(checked) =>
                  setQualificationFilters(prev => ({ ...prev, teachingDegree: checked as boolean }))
                }
              />
              <Label htmlFor="teaching-degree" className="text-sm">
                📚 Teaching Degree
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="montessori"
                checked={qualificationFilters.montessori}
                onCheckedChange={(checked) =>
                  setQualificationFilters(prev => ({ ...prev, montessori: checked as boolean }))
                }
              />
              <Label htmlFor="montessori" className="text-sm">
                🧩 Montessori Training
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="special-needs"
                checked={qualificationFilters.specialNeeds}
                onCheckedChange={(checked) =>
                  setQualificationFilters(prev => ({ ...prev, specialNeeds: checked as boolean }))
                }
              />
              <Label htmlFor="special-needs" className="text-sm">
                🌟 Special Needs Training
              </Label>
            </div>
          </div>
        </div>

        {/* Additional Skills */}
        <div className="mb-4">
          <h4 className="text-sm font-medium text-muted-foreground mb-2">Additional Skills</h4>
          <div className="space-y-2">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="swimming"
                checked={qualificationFilters.swimming}
                onCheckedChange={(checked) =>
                  setQualificationFilters(prev => ({ ...prev, swimming: checked as boolean }))
                }
              />
              <Label htmlFor="swimming" className="text-sm">
                🏊 Swimming Instructor
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="music"
                checked={qualificationFilters.music}
                onCheckedChange={(checked) =>
                  setQualificationFilters(prev => ({ ...prev, music: checked as boolean }))
                }
              />
              <Label htmlFor="music" className="text-sm">
                🎵 Music Education
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="languages"
                checked={qualificationFilters.languages}
                onCheckedChange={(checked) =>
                  setQualificationFilters(prev => ({ ...prev, languages: checked as boolean }))
                }
              />
              <Label htmlFor="languages" className="text-sm">
                🌍 Multilingual
              </Label>
            </div>
          </div>
        </div>
      </div>

      <div className="pt-4 border-t">
        <Button
          variant="outline"
          onClick={clearFilters}
          className="w-full"
        >
          Clear All Filters
        </Button>
      </div>
    </div>
  );

  return (
    <>
      <SEO {...SEOConfigs.findSitter} />
      <div className="min-h-screen bg-[#F9F5F0]">
        <div className="container mx-auto px-4 py-8">
          <div className="mb-8">
            <h1 className="text-4xl lg:text-5xl font-bold text-[#6B3E4B] mb-4" style={{ fontFamily: 'Satoshi, sans-serif' }}>Your Village Awaits</h1>
            <p className="text-xl text-gray-600" style={{ fontFamily: 'DM Sans, sans-serif' }}>Pick your perfect sitter and get your life back</p>
          </div>
      

      
      {/* Premium Plan My Night Feature */}
      <Card className="mb-8 bg-gradient-to-r from-wine/10 via-rose/5 to-eucalyptus/10 border-wine/20">
        <CardContent className="p-4 md:p-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
            <div className="flex flex-col md:flex-row md:items-center space-y-3 md:space-y-0 md:space-x-4">
              <div className="bg-wine/10 p-3 rounded-full w-fit">
                <Sparkles className="w-6 h-6 md:w-8 md:h-8 text-wine" />
              </div>
              <div className="flex-1">
                <h2 className="text-xl md:text-2xl font-bold text-wine mb-2">Plan My Perfect Night</h2>
                <p className="text-muted-foreground mb-3 text-sm md:text-base">
                  We'll find your perfect sitter, through our matching service. And if you want more - our concierge team can also plan your perfect night whether it's booking a table at the perfect restaurant, or getting tickets to that show you have been dying to go to - just let us know what you need.
                </p>
                <div className="flex flex-col md:flex-row md:items-center space-y-2 md:space-y-0 md:space-x-4 text-sm text-muted-foreground">
                  <div className="flex items-center">
                    <Wine className="w-4 h-4 mr-2 text-wine" />
                    Wine delivery
                  </div>
                  <div className="flex items-center">
                    <Calendar className="w-4 h-4 mr-2 text-wine" />
                    Restaurant bookings
                  </div>
                  <div className="flex items-center">
                    <Gift className="w-4 h-4 mr-2 text-wine" />
                    Gift experiences
                  </div>
                </div>
              </div>
            </div>
            <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
              <Button asChild size="lg" className="bg-wine hover:bg-wine/90 text-white w-full sm:w-auto">
                <Link to="/plan-my-night">
                  Plan My Night
                </Link>
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-wine text-wine hover:bg-wine/10 w-full sm:w-auto"
                onClick={() => window.open('https://il1f953ou3r.typeform.com/to/oIem5tW8', '_blank')}
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Get Concierge Help
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Hotel & Employer Services - Village Style */}
      <div className="grid md:grid-cols-2 gap-6 mb-8">
        {/* Hotels Section */}
        <Card className="bg-gradient-to-br from-linen/50 via-rose/5 to-eucalyptus/10 border-rose/20 hover:shadow-lg transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-start space-x-4">
              <div className="bg-rose/20 p-3 rounded-full">
                <Coffee className="w-8 h-8 text-rose" />
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold text-wine mb-2">Hotels That Get It</h3>
                <p className="text-muted-foreground mb-4 text-sm">
                  Because nothing says 'luxury resort experience' like wondering if your toddler is currently dismantling the minibar. Let us handle the kids while you handle the relaxation.
                </p>
                <div className="space-y-2 text-sm text-muted-foreground mb-4">
                  <div className="flex items-center">
                    <Heart className="w-4 h-4 mr-2 text-rose" />
                    Happy parents = glowing reviews
                  </div>
                  <div className="flex items-center">
                    <Heart className="w-4 h-4 mr-2 text-rose" />
                    Trusted Village sitters
                  </div>
                  <div className="flex items-center">
                    <Heart className="w-4 h-4 mr-2 text-rose" />
                    Zero fuss booking
                  </div>
                </div>
                <Button asChild className="bg-rose hover:bg-rose/90 text-white w-full">
                  <Link to="/hotels">
                    Partner With Us
                  </Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Employers Section */}
        <Card className="bg-gradient-to-br from-eucalyptus/10 via-linen/30 to-taupe/5 border-eucalyptus/20 hover:shadow-lg transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-start space-x-4">
              <div className="bg-eucalyptus/20 p-3 rounded-full">
                <Briefcase className="w-8 h-8 text-eucalyptus" />
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold text-wine mb-2">Workplaces That Support Parents Win</h3>
                <p className="text-muted-foreground mb-4 text-sm">
                  When childcare plans fall apart, productivity doesn't have to. Give your team the backup they need so they can show up as their best selves.
                </p>
                <div className="space-y-2 text-sm text-muted-foreground mb-4">
                  <div className="flex items-center">
                    <Sparkles className="w-4 h-4 mr-2 text-eucalyptus" />
                    Less stress, more focus
                  </div>
                  <div className="flex items-center">
                    <Sparkles className="w-4 h-4 mr-2 text-eucalyptus" />
                    Flexible care solutions
                  </div>
                  <div className="flex items-center">
                    <Sparkles className="w-4 h-4 mr-2 text-eucalyptus" />
                    Custom support packages
                  </div>
                </div>
                <Button asChild className="bg-eucalyptus hover:bg-eucalyptus/90 text-white w-full">
                  <Link to="/employers">
                    Let's Chat
                  </Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Simplified header section */}
      <div className="mb-6">
        <h2 className="text-xl font-semibold mb-4 text-wine">Plan Your Perfect Break</h2>
        <p className="text-muted-foreground mb-6">Book ahead for the best sitters and peace of mind. Quality childcare takes time to arrange properly.</p>
        
        {/* Selected Filters */}
        {instantBookOnly && (
          <div className="mb-4">
            <h3 className="text-sm font-medium text-gray-900 mb-2">Selected</h3>
            <div className="flex flex-wrap gap-2">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-gray-100 rounded-full text-sm">
                <Clock className="h-4 w-4 text-village-wine" />
                Instant Book
                <button
                  onClick={() => setInstantBookOnly(false)}
                  className="ml-1 hover:bg-gray-200 rounded-full p-0.5"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Search Filters */}
        <div className="flex flex-wrap gap-2 mb-4">
          {/* Location Search with Google Places */}
          <div className="relative">
            <GooglePlacesAutocomplete
              onPlaceSelect={handleLocationSelect}
              placeholder="Search location..."
              value={locationQuery}
              onChange={setLocationQuery}
              className="w-64"
            />
          </div>

          {/* Date & Time Picker */}
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm" className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                <span>{selectedDate ? format(selectedDate, 'MMM dd') : 'Any Date'}</span>
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <CalendarComponent
                mode="single"
                selected={selectedDate}
                onSelect={setSelectedDate}
                disabled={(date) => date < new Date()}
                initialFocus
              />
              {selectedDate && (
                <div className="p-3 border-t">
                  <Label htmlFor="time-select" className="text-sm font-medium">
                    Preferred Time
                  </Label>
                  <Select value={selectedTime} onValueChange={setSelectedTime}>
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select time" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="morning">Morning (6-12pm)</SelectItem>
                      <SelectItem value="afternoon">Afternoon (12-6pm)</SelectItem>
                      <SelectItem value="evening">Evening (6-11pm)</SelectItem>
                      <SelectItem value="overnight">Overnight</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
            </PopoverContent>
          </Popover>

          {/* Mobile Filter Button */}
          <Sheet open={showFilters} onOpenChange={setShowFilters}>
            <SheetTrigger asChild>
              <Button variant="outline" size="sm" className="flex items-center gap-2 md:hidden">
                <Filter className="h-4 w-4" />
                <span>Filters</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-80">
              <FilterPanel />
            </SheetContent>
          </Sheet>

          {/* Desktop Filter Button */}
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm" className="hidden md:flex items-center gap-2">
                <Filter className="h-4 w-4" />
                <span>More Filters</span>
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80" align="end">
              <FilterPanel />
            </PopoverContent>
          </Popover>

          {/* Clear Filters Button */}
          {(locationQuery || selectedDate || selectedTime || 
            Object.values(verificationFilters).some(Boolean) || 
            Object.values(qualificationFilters).some(Boolean) ||
            ratingFilter > 0 || searchRadius !== 25) && (
            <Button
              variant="ghost"
              size="sm"
              onClick={clearFilters}
              className="flex items-center gap-2 text-village-wine hover:text-village-wine/80"
            >
              <X className="h-4 w-4" />
              Clear Filters
            </Button>
          )}
        </div>
      </div>

      {/* Results count and active filters */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-3">
        <div className="text-sm text-muted-foreground">
          {isLoading ? (
            <Skeleton className="h-4 w-32" />
          ) : (
            <>Showing {filteredSitters.length} of {sitters.length} sitters</>
          )}
        </div>
        
        {/* Active filter tags */}
        <div className="flex flex-wrap gap-2">
          {locationQuery && (
            <Badge variant="secondary" className="flex items-center gap-1">
              <Search className="h-3 w-3" />
              {locationQuery}
              <X className="h-3 w-3 cursor-pointer" onClick={() => setLocationQuery('')} />
            </Badge>
          )}
          {selectedDate && (
            <Badge variant="secondary" className="flex items-center gap-1">
              <Calendar className="h-3 w-3" />
              {format(selectedDate, 'MMM dd')}
              <X className="h-3 w-3 cursor-pointer" onClick={() => setSelectedDate(undefined)} />
            </Badge>
          )}
          {selectedTime && (
            <Badge variant="secondary" className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              {selectedTime}
              <X className="h-3 w-3 cursor-pointer" onClick={() => setSelectedTime('')} />
            </Badge>
          )}
          {ratingFilter > 0 && (
            <Badge variant="secondary" className="flex items-center gap-1">
              <Star className="h-3 w-3" />
              {ratingFilter}+ stars
              <X className="h-3 w-3 cursor-pointer" onClick={() => setRatingFilter(0)} />
            </Badge>
          )}
        </div>
      </div>
      
      {/* View Mode Toggle */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Button
            variant={viewMode === 'list' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setViewMode('list')}
            className="flex items-center gap-2"
          >
            <Search className="h-4 w-4" />
            List View
          </Button>
          <div className="relative">
            <Button
              variant={viewMode === 'map' ? 'default' : 'outline'}
              size="sm"
              onClick={() => mapsAvailable ? setViewMode('map') : null}
              disabled={!mapsAvailable}
              className={`flex items-center gap-2 ${!mapsAvailable ? 'opacity-50 cursor-not-allowed' : ''}`}
              title={!mapsAvailable ? 'Map view unavailable - Google Maps API needs domain authorization' : 'Map View'}
            >
              <Map className="h-4 w-4" />
              Map View
            </Button>
            {!mapsAvailable && (
              <div className="absolute top-full left-0 mt-1 text-xs text-muted-foreground max-w-48">
                Map requires API setup
              </div>
            )}
          </div>
        </div>
        {selectedLocation && (
          <div className="text-sm text-muted-foreground">
            Showing sitters within {searchRadius}km of {selectedLocation.address}
          </div>
        )}
      </div>
        
      {/* Results Display */}
      {viewMode === 'map' ? (
        mapsAvailable ? (
          <div className="h-[600px] w-full">
            <SittersMap
              sitters={filteredSitters.map(sitter => ({
                ...sitter,
                rating: sitter.rating || 4.8,
                reviewCount: sitter.reviewCount || Math.floor(Math.random() * 20) + 5
              }))}
              center={mapCenter}
              onSitterSelect={handleSitterSelect}
              className="h-full"
            />
          </div>
        ) : (
          <div className="h-[600px] w-full flex items-center justify-center bg-muted/20 rounded-lg border-2 border-dashed border-muted-foreground/20">
            <div className="text-center space-y-3">
              <Map className="h-12 w-12 mx-auto text-muted-foreground/50" />
              <div>
                <h3 className="font-medium text-muted-foreground">Map View Unavailable</h3>
                <p className="text-sm text-muted-foreground/70 mt-1">
                  Google Maps API requires domain authorization
                </p>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setViewMode('list')}
                className="mt-3"
              >
                Switch to List View
              </Button>
            </div>
          </div>
        )
      ) : (
        <div className="mt-6">
          {/* Favourites Section */}
          <div className="mb-8">
            <FavoriteSittersSection className="bg-white rounded-xl shadow-lg border-0" />
          </div>
          
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array.from({ length: 6 }).map((_, index) => (
                <Card key={index} className="overflow-hidden">
                  <div className="p-6">
                    <div className="flex items-center space-x-4">
                      <Skeleton className="h-12 w-12 rounded-full" />
                      <div className="space-y-2">
                        <Skeleton className="h-4 w-[200px]" />
                        <Skeleton className="h-4 w-[150px]" />
                      </div>
                    </div>
                    <div className="mt-4 space-y-2">
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-2/3" />
                    </div>
                    <div className="mt-4">
                      <Skeleton className="h-9 w-full rounded" />
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          ) : error ? (
            <div className="p-6 text-center">
              <p className="text-destructive">Error loading sitters: {error}</p>
              <Button variant="outline" className="mt-4" onClick={() => window.location.reload()}>
                Try Again
              </Button>
            </div>
          ) : filteredSitters.length === 0 ? (
            <div className="p-6 text-center">
              <p className="text-muted-foreground">
                {sitters.length === 0 
                  ? "No sitters available in your area." 
                  : "No sitters match your current filters."}
              </p>
              <div className="flex gap-2 justify-center mt-4">
                {sitters.length === 0 ? (
                  <Button variant="outline" onClick={expandSearchArea}>
                    Expand to {searchRadius + 10}km
                  </Button>
                ) : (
                  <Button variant="outline" onClick={clearFilters}>
                    Clear Filters
                  </Button>
                )}
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredSitters.map((sitter) => {
                // Transform sitter data to match SitterCard interface
                const transformedSitter = {
                  id: sitter.id || sitter.userId || sitter.user_id || sitter.sharetribeId,
                  userId: sitter.userId || sitter.user_id,
                  firstName: sitter.firstName || sitter.first_name || (sitter.full_name ? sitter.full_name.split(' ')[0] : '') || (sitter.email ? sitter.email.split('.')[0] : 'Sitter'),
                  lastName: sitter.lastName || sitter.last_name || (sitter.full_name ? sitter.full_name.split(' ').slice(1).join(' ') : '') || '',
                  full_name: sitter.full_name || `${sitter.firstName || ''} ${sitter.lastName || ''}`.trim() || sitter.email?.split('@')[0] || 'Village Sitter',
                  title: sitter.title || sitter.full_name || `${sitter.firstName || ''} ${sitter.lastName || ''}`.trim() || 'Village Sitter',
                  age: sitter.age,
                  hourlyRate: sitter.hourlyRate || sitter.hourly_rate || 25,
                  hourly_rate: sitter.hourlyRate || sitter.hourly_rate || 25,
                  bio: sitter.bio || sitter.description || sitter.experience || "Experienced babysitter available in your area.",
                  description: sitter.bio || sitter.description || sitter.experience || "Experienced babysitter available in your area.",
                  experience: sitter.experience || sitter.bio || "Experienced babysitter available in your area.",
                  photoUrl: sitter.photoUrl || sitter.profile_image || sitter.avatar_url || sitter.profileImage,
                  profile_image: sitter.photoUrl || sitter.profile_image || sitter.avatar_url || sitter.profileImage,
                  avatar_url: sitter.photoUrl || sitter.profile_image || sitter.avatar_url || sitter.profileImage,
                  profileImage: sitter.photoUrl || sitter.profile_image || sitter.avatar_url || sitter.profileImage,
                  isApproved: sitter.isApproved,
                  skills: sitter.skills || [],
                  rating: sitter.rating || 4.5,
                  reviewCount: sitter.reviewCount || 0,
                  reviews: sitter.reviews || [],
                  location: sitter.location || sitter.address || 'Hamilton, New Zealand',
                  address: sitter.address || sitter.location || 'Hamilton, New Zealand',
                  latitude: sitter.latitude,
                  longitude: sitter.longitude,
                  phone: sitter.phone || '',
                  email: sitter.email || '',
                  qualifications: sitter.qualifications || [],
                  languages: sitter.languages || 'English',
                  verificationStatus: sitter.verificationStatus || 'verified',
                  availability: sitter.availability || {},
                  createdAt: sitter.createdAt,
                  villageVerified: sitter.verificationStatus === 'verified',
                  backgroundChecked: sitter.qualifications?.some((q: any) => {
                    if (typeof q === 'string') return q.includes('Police') || q.includes('Background');
                    if (q && typeof q === 'object' && q.displayName) return q.displayName.includes('Police') || q.displayName.includes('Background');
                    return false;
                  }),
                  firstAidCertified: sitter.qualifications?.some((q: any) => {
                    if (typeof q === 'string') return q.includes('First Aid');
                    if (q && typeof q === 'object' && q.displayName) return q.displayName.includes('First Aid');
                    return false;
                  }),
                  badge: sitter.badge
                };
                
                return (
                  <SitterCard 
                    key={transformedSitter.id || Math.random()} 
                    sitter={transformedSitter} 
                  />
                );
              })}
            </div>
          )}
        </div>
      )}
        </div>
      </div>
    </>
  );
}