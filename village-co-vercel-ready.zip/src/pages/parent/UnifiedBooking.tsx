import { useState, useEffect } from 'react';
import { useLocation, useParams } from 'wouter';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { ChevronLeft, Heart, MapPin, Car, Star, Shield, Clock, Calendar, Users, Briefcase, Coffee, MoreHorizontal, Filter, ChevronDown } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useQuery } from '@tanstack/react-query';
import InstantBookingModal from '@/components/booking/InstantBookingModal';
import ModernSitterCard from '@/components/sitters/ModernSitterCard';

type CareReason = 'night-out' | 'work' | 'regular' | 'other';
type BookingStyle = 'smart-match' | 'browse';

interface ParentPreferences {
  sitterGender: 'any' | 'female' | 'male';
  requiresDriver: boolean;
  specialNeedsTrained: boolean;
  firstAidRequired: boolean;
  minRating: number;
  maxHourlyRate: number;
}

interface UnifiedBookingState {
  step: 1 | 2 | 3;
  careReason: CareReason | null;
  bookingStyle: BookingStyle | null;
  selectedDateTime: string | null;
  selectedDuration: number | null;
  preferences: ParentPreferences;
}

interface SitterCard {
  id: number;
  firstName: string;
  lastName: string;
  photoUrl: string;
  hourlyRate: number;
  rating: number;
  reviewCount: number;
  bio: string;
  availabilityTags: string[];
  canBeBooked: boolean;
  identityVerified: boolean;
  firstAidCertDate: string | null;
  badge: string | null;
  isDriver: boolean;
  specialNeeds: boolean;
  hasVideoIntro: boolean;
  lastReview?: string;
}

const careReasonOptions = [
  {
    id: 'night-out',
    icon: Heart,
    title: 'A night out',
    subtitle: 'Date night, dinner, social events'
  },
  {
    id: 'work',
    icon: Briefcase,
    title: 'A work commitment',
    subtitle: 'Meetings, travel, overtime'
  },
  {
    id: 'regular',
    icon: Calendar,
    title: 'Regular help',
    subtitle: 'Weekly care, after school'
  },
  {
    id: 'other',
    icon: MoreHorizontal,
    title: 'Something else',
    subtitle: 'Appointments, errands, emergencies'
  }
];

const bookingStyleOptions = [
  {
    id: 'smart-match',
    title: 'Smart Match',
    subtitle: 'Show me who\'s available right now – I want this sorted quickly.',
    description: 'Filters sitters with real-time availability + verified + instant book enabled'
  },
  {
    id: 'browse',
    title: 'Browse & Choose',
    subtitle: 'Let me browse profiles and request a booking.',
    description: 'Full sitter directory with richer filters and request flow'
  }
];

export default function UnifiedBooking() {
  const [, navigate] = useLocation();
  const { currentUser } = useAuth();
  const { toast } = useToast();
  
  const [state, setState] = useState<UnifiedBookingState>({
    step: 1,
    careReason: null,
    bookingStyle: null,
    selectedDateTime: null,
    selectedDuration: null,
    preferences: {
      sitterGender: 'any',
      requiresDriver: false,
      specialNeedsTrained: false,
      firstAidRequired: false,
      minRating: 0,
      maxHourlyRate: 50
    }
  });

  const [showPreferences, setShowPreferences] = useState(false);

  const [showBookingModal, setShowBookingModal] = useState(false);
  const [selectedSitter, setSelectedSitter] = useState<SitterCard | null>(null);

  // Fetch sitters based on booking style and preferences
  const { data: sitters = [], isLoading } = useQuery({
    queryKey: ['/api/sitters', state.bookingStyle, state.preferences],
    enabled: state.step === 3,
    select: (data: any[]) => {
      let filteredSitters = data;

      // Base filter based on booking style
      if (state.bookingStyle === 'smart-match') {
        // Filter for instant book sitters with real-time availability
        filteredSitters = filteredSitters.filter(sitter => 
          sitter.canBeBooked && 
          sitter.identityVerified && 
          sitter.isActive
        );
      } else {
        // For browse mode, return all approved sitters
        filteredSitters = filteredSitters.filter(sitter => sitter.isApproved);
      }

      // Apply parent preferences
      const { preferences } = state;
      
      // Gender preference (if sitter has gender info)
      if (preferences.sitterGender !== 'any' && filteredSitters[0]?.gender) {
        filteredSitters = filteredSitters.filter(sitter => 
          sitter.gender === preferences.sitterGender
        );
      }

      // Driver requirement
      if (preferences.requiresDriver) {
        filteredSitters = filteredSitters.filter(sitter => sitter.isDriver);
      }

      // Special needs training
      if (preferences.specialNeedsTrained) {
        filteredSitters = filteredSitters.filter(sitter => sitter.specialNeeds);
      }

      // First aid requirement
      if (preferences.firstAidRequired) {
        filteredSitters = filteredSitters.filter(sitter => sitter.firstAidCertDate);
      }

      // Rating filter
      if (preferences.minRating > 0) {
        filteredSitters = filteredSitters.filter(sitter => 
          sitter.rating >= preferences.minRating
        );
      }

      // Hourly rate filter
      filteredSitters = filteredSitters.filter(sitter => 
        sitter.hourlyRate <= preferences.maxHourlyRate
      );

      return filteredSitters;
    }
  });

  const handleCareReasonSelect = (reason: CareReason) => {
    setState(prev => ({ 
      ...prev, 
      careReason: reason, 
      step: 2 
    }));
  };

  const handleBookingStyleSelect = (style: BookingStyle) => {
    setState(prev => ({ 
      ...prev, 
      bookingStyle: style, 
      step: 3 
    }));
  };

  const updatePreferences = (updates: Partial<ParentPreferences>) => {
    setState(prev => ({
      ...prev,
      preferences: { ...prev.preferences, ...updates }
    }));
  };

  const handleSitterSelect = (sitter: SitterCard) => {
    if (state.bookingStyle === 'smart-match') {
      // Instant booking flow
      setSelectedSitter(sitter);
      setShowBookingModal(true);
    } else {
      // Request booking flow
      navigate(`/book/${sitter.id}?reason=${state.careReason}`);
    }
  };

  const handleBack = () => {
    if (state.step > 1) {
      setState(prev => ({ ...prev, step: (prev.step - 1) as 1 | 2 | 3 }));
    } else {
      navigate('/parent/dashboard');
    }
  };

  const getProgressPercentage = () => {
    return (state.step / 3) * 100;
  };

  const renderStep1 = () => (
    <div className="space-y-6">
      <div className="text-center space-y-4">
        <h2 className="text-2xl font-bold" style={{ color: '#6B3E4B', fontFamily: 'Satoshi, sans-serif' }}>What do you need care for?</h2>
        <p className="text-gray-600" style={{ fontFamily: 'DM Sans, sans-serif' }}>
          Need a break? We've got you. Find trusted, vetted sitters with just a few taps — 
          book for tonight, plan ahead, or browse the best of your village.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {careReasonOptions.map((option) => {
          const IconComponent = option.icon;
          return (
            <Card 
              key={option.id}
              className="cursor-pointer hover:shadow-md transition-all bg-white rounded-xl shadow-lg border-0 hover:shadow-xl"
              onClick={() => handleCareReasonSelect(option.id as CareReason)}
            >
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <div className="p-3 rounded-lg" style={{ backgroundColor: '#FDF2F8' }}>
                    <IconComponent className="h-6 w-6" style={{ color: '#6B3E4B' }} />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg text-gray-900" style={{ fontFamily: 'Satoshi, sans-serif' }}>{option.title}</h3>
                    <p className="text-sm text-gray-500" style={{ fontFamily: 'DM Sans, sans-serif' }}>{option.subtitle}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-6">
      <div className="text-center space-y-4">
        <h2 className="text-2xl font-bold" style={{ color: '#6B3E4B', fontFamily: 'Satoshi, sans-serif' }}>How would you like to book?</h2>
        <p className="text-gray-600" style={{ fontFamily: 'DM Sans, sans-serif' }}>
          Choose your booking style based on how quickly you need care arranged.
        </p>
      </div>

      <div className="space-y-4">
        {bookingStyleOptions.map((option) => (
          <Card 
            key={option.id}
            className="cursor-pointer hover:shadow-md transition-all bg-white rounded-xl shadow-lg border-0 hover:shadow-xl"
            onClick={() => handleBookingStyleSelect(option.id as BookingStyle)}
          >
            <CardContent className="p-6">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-lg" style={{ color: '#6B3E4B', fontFamily: 'Satoshi, sans-serif' }}>{option.title}</h3>
                  {option.id === 'smart-match' && (
                    <Badge variant="secondary" style={{ backgroundColor: '#FDF2F8', color: '#6B3E4B' }}>
                      <Clock className="h-3 w-3 mr-1" />
                      Instant
                    </Badge>
                  )}
                </div>
                <p className="text-gray-700" style={{ fontFamily: 'DM Sans, sans-serif' }}>{option.subtitle}</p>
                <p className="text-sm text-gray-500" style={{ fontFamily: 'DM Sans, sans-serif' }}>{option.description}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );

  const renderStep3SmartMatch = () => (
    <div className="space-y-6">
      <div className="text-center space-y-4">
        <h2 className="text-2xl font-bold" style={{ color: '#6B3E4B', fontFamily: 'Satoshi, sans-serif' }}>Sitters available right now</h2>
        <p className="text-gray-600" style={{ fontFamily: 'DM Sans, sans-serif' }}>
          These sitters are verified, available, and ready for instant booking.
        </p>
      </div>

      {/* Smart match also gets preferences */}
      {renderPreferencesPanel()}

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="animate-pulse bg-white rounded-xl shadow-lg border-0">
              <CardContent className="p-6">
                <div className="space-y-4">
                  <div className="h-16 w-16 bg-gray-200 rounded-full mx-auto"></div>
                  <div className="h-4 bg-gray-200 rounded w-3/4 mx-auto"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2 mx-auto"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : sitters.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-gray-600 text-lg mb-4">
            Looks like your Village is growing – we'll text you as soon as someone pops up!
          </p>
          <Button 
            variant="outline" 
            onClick={() => setState(prev => ({ ...prev, bookingStyle: 'browse' }))}
            className="cta-btn bg-transparent text-village-wine border-village-wine hover:bg-village-wine hover:text-white"
          >
            Browse All Sitters
          </Button>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="text-center mb-6">
            <h3 className="text-2xl font-semibold mb-2" style={{ color: '#6B3E4B', fontFamily: 'Satoshi, sans-serif' }}>
              Meet the magic-makers
            </h3>
            <p className="text-gray-600" style={{ fontFamily: 'DM Sans, sans-serif' }}>
              {sitters.length} sitter{sitters.length === 1 ? '' : 's'} available for instant booking
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {sitters.map((sitter) => (
              <ModernSitterCard
                key={sitter.id}
                sitter={sitter}
                onBookingComplete={() => {
                  toast({
                    title: "Go enjoy your time — we've got the kids.",
                    description: `Your booking with ${sitter.firstName} is confirmed!`,
                  });
                }}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );

  const renderPreferencesPanel = () => (
    <Collapsible open={showPreferences} onOpenChange={setShowPreferences}>
      <CollapsibleTrigger asChild>
        <Button variant="outline" className="w-full mb-4" style={{ fontFamily: 'DM Sans, sans-serif' }}>
          <Filter className="h-4 w-4 mr-2" />
          Preferences & Filters
          <ChevronDown className={`h-4 w-4 ml-2 transition-transform ${showPreferences ? 'rotate-180' : ''}`} />
        </Button>
      </CollapsibleTrigger>
      <CollapsibleContent className="space-y-4 mb-6">
        <Card className="bg-white rounded-xl shadow-lg border-0">
          <CardHeader>
            <CardTitle className="text-lg" style={{ color: '#6B3E4B', fontFamily: 'Satoshi, sans-serif' }}>Your Sitter Preferences</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Gender Preference */}
            <div className="space-y-2">
              <Label style={{ fontFamily: 'DM Sans, sans-serif' }}>Sitter Gender</Label>
              <Select
                value={state.preferences.sitterGender}
                onValueChange={(value: 'any' | 'female' | 'male') => 
                  updatePreferences({ sitterGender: value })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="any">No preference</SelectItem>
                  <SelectItem value="female">Female</SelectItem>
                  <SelectItem value="male">Male</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Driver Requirement */}
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label style={{ fontFamily: 'DM Sans, sans-serif' }}>Must have own transport</Label>
                <p className="text-sm text-gray-500" style={{ fontFamily: 'DM Sans, sans-serif' }}>For pickups and outings</p>
              </div>
              <Switch
                checked={state.preferences.requiresDriver}
                onCheckedChange={(checked) => updatePreferences({ requiresDriver: checked })}
              />
            </div>

            {/* Special Needs Training */}
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label style={{ fontFamily: 'DM Sans, sans-serif' }}>Special needs experience</Label>
                <p className="text-sm text-gray-500" style={{ fontFamily: 'DM Sans, sans-serif' }}>Trained in special needs care</p>
              </div>
              <Switch
                checked={state.preferences.specialNeedsTrained}
                onCheckedChange={(checked) => updatePreferences({ specialNeedsTrained: checked })}
              />
            </div>

            {/* First Aid Requirement */}
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label style={{ fontFamily: 'DM Sans, sans-serif' }}>First Aid certified</Label>
                <p className="text-sm text-gray-500" style={{ fontFamily: 'DM Sans, sans-serif' }}>Current first aid certification</p>
              </div>
              <Switch
                checked={state.preferences.firstAidRequired}
                onCheckedChange={(checked) => updatePreferences({ firstAidRequired: checked })}
              />
            </div>

            {/* Minimum Rating */}
            <div className="space-y-2">
              <Label style={{ fontFamily: 'DM Sans, sans-serif' }}>Minimum Rating</Label>
              <div className="px-4">
                <Slider
                  value={[state.preferences.minRating]}
                  onValueChange={([value]) => updatePreferences({ minRating: value })}
                  max={5}
                  min={0}
                  step={0.5}
                  className="w-full"
                />
                <div className="flex justify-between text-sm text-gray-500 mt-1">
                  <span>Any rating</span>
                  <span>{state.preferences.minRating}+ stars</span>
                </div>
              </div>
            </div>

            {/* Maximum Hourly Rate */}
            <div className="space-y-2">
              <Label style={{ fontFamily: 'DM Sans, sans-serif' }}>Maximum Hourly Rate</Label>
              <div className="px-4">
                <Slider
                  value={[state.preferences.maxHourlyRate]}
                  onValueChange={([value]) => updatePreferences({ maxHourlyRate: value })}
                  max={60}
                  min={20}
                  step={5}
                  className="w-full"
                />
                <div className="flex justify-between text-sm text-gray-500 mt-1">
                  <span>$20/hr</span>
                  <span>${state.preferences.maxHourlyRate}/hr</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </CollapsibleContent>
    </Collapsible>
  );

  const renderStep3Browse = () => (
    <div className="space-y-6">
      <div className="text-center space-y-4">
        <h2 className="text-2xl font-bold" style={{ color: '#6B3E4B', fontFamily: 'Satoshi, sans-serif' }}>Browse sitters near you</h2>
        <p className="text-gray-600" style={{ fontFamily: 'DM Sans, sans-serif' }}>
          Explore detailed profiles and send booking requests.
        </p>
      </div>

      {/* Enhanced filters for browse mode */}
      {renderPreferencesPanel()}
      
      {isLoading ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="animate-pulse bg-white rounded-xl shadow-lg border-0">
              <CardContent className="p-6">
                <div className="flex space-x-4">
                  <div className="h-20 w-20 bg-gray-200 rounded-full"></div>
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-gray-200 rounded w-1/3"></div>
                    <div className="h-3 bg-gray-200 rounded w-1/2"></div>
                    <div className="h-3 bg-gray-200 rounded w-3/4"></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : sitters.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-gray-600 text-lg" style={{ fontFamily: 'DM Sans, sans-serif' }}>
            Looks like your Village is growing – we'll text you as soon as someone pops up!
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="text-center mb-6">
            <h3 className="text-2xl font-semibold mb-2" style={{ color: '#6B3E4B', fontFamily: 'Satoshi, sans-serif' }}>
              Meet the magic-makers
            </h3>
            <p className="text-gray-600" style={{ fontFamily: 'DM Sans, sans-serif' }}>
              {sitters.length} sitter{sitters.length === 1 ? '' : 's'} ready to help your family
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {sitters.map((sitter) => (
              <ModernSitterCard
                key={sitter.id}
                sitter={sitter}
                onBookingComplete={() => {
                  toast({
                    title: "Go enjoy your time — we've got the kids.",
                    description: `Your booking with ${sitter.firstName} is confirmed!`,
                  });
                }}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#F9F5F0' }}>
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleBack}
              className="flex items-center"
            >
              <ChevronLeft className="h-4 w-4 mr-1" />
              Back
            </Button>
            <div className="text-center">
              <h1 className="text-lg font-semibold" style={{ fontFamily: 'Satoshi, sans-serif' }}>✨ Match Me With a Sitter</h1>
              <p className="text-sm text-gray-500" style={{ fontFamily: 'DM Sans, sans-serif' }}>Step {state.step} of 3</p>
            </div>
            <div className="w-16"> {/* Spacer */}</div>
          </div>
          <div className="mt-4">
            <Progress value={getProgressPercentage()} className="h-2" />
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 py-8">
        {state.step === 1 && renderStep1()}
        {state.step === 2 && renderStep2()}
        {state.step === 3 && state.bookingStyle === 'smart-match' && renderStep3SmartMatch()}
        {state.step === 3 && state.bookingStyle === 'browse' && renderStep3Browse()}
      </div>

      {/* Instant Booking Modal */}
      {selectedSitter && (
        <InstantBookingModal
          isOpen={showBookingModal}
          onClose={() => {
            setShowBookingModal(false);
            setSelectedSitter(null);
          }}
          sitter={selectedSitter}
          onSuccess={() => {
            setShowBookingModal(false);
            setSelectedSitter(null);
            toast({
              title: "Go enjoy your time — we've got the kids.",
              description: `Your booking with ${selectedSitter.firstName} is confirmed!`,
            });
            navigate('/parent/dashboard');
          }}
        />
      )}
    </div>
  );
}