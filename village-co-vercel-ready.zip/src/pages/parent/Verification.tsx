import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ArrowLeft } from 'lucide-react';
import { useLocation } from 'wouter';
import ParentVerification from '@/components/parents/ParentVerification';

export default function ParentVerificationPage() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-2xl mx-auto px-4">
        <div className="mb-6">
          <Button
            variant="ghost"
            onClick={() => setLocation('/parent/dashboard')}
            className="flex items-center gap-2 text-village-wine hover:text-village-wine/80"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Dashboard
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-village-wine">Identity Verification</CardTitle>
            <p className="text-gray-600">
              Complete your identity verification to build trust in our community and unlock full platform features.
            </p>
          </CardHeader>
          <CardContent>
            <ParentVerification />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}