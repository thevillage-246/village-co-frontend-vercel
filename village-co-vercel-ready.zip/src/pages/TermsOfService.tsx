import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, FileText, Scale } from "lucide-react";
import { Link } from "wouter";
import SEO, { SEOConfigs } from "@/components/SEO";

function TermsOfService() {
  return (
    <>
      <SEO {...SEOConfigs.termsOfService} />
      <div className="min-h-screen bg-bone">
      {/* Hero Section */}
      <section className="bg-village-wine text-white py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center mb-6">
            <Link href="/">
              <button className="flex items-center text-linen hover:text-white transition-colors mr-4">
                <ArrowLeft className="h-5 w-5 mr-2" />
                Back to Home
              </button>
            </Link>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 bg-linen/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Scale className="h-8 w-8 text-linen" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Terms of Service
            </h1>
            <p className="text-xl text-brushed-pink">
              Your agreement for using The Village Co. platform
            </p>
            <p className="text-sm text-linen/80 mt-4">
              Last updated: September 9, 2024 • Please read carefully
            </p>
          </div>
        </div>
      </section>

      {/* Terms Content */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="border-almond-frost/20 shadow-sm">
            <CardContent className="p-8 space-y-8">
              <div>
                <p className="text-gray-700 leading-relaxed">
                  These Terms of Use (Terms) apply to your access and use of the website located at www.thevillageco.nz (Website) and any mobile application (App) or other tools through which It Takes A Village Babysitting Limited (called we, us or our below) makes its online marketplace services accessible (Platform).
                </p>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-village-wine mb-4">Acceptance of these Terms</h2>
                <p className="text-gray-700 leading-relaxed">
                  By applying for an account with us, accessing the Platform, downloading the App or using the Website you (you, your) agree to be bound by these Terms. If you do not wish to agree to these Terms, including any updated version of these Terms, you must stop using the Platform and the Website.
                </p>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-village-wine mb-4">How the Platform works</h2>
                <p className="text-gray-700 leading-relaxed mb-4">Our Platform facilitates:</p>
                <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4 mb-4">
                  <li>the connection of member parents or guardians (Families or Family) with member babysitters, childcarers and nannies (Caregivers) in their local area through viewing profiles and interaction via a private messaging platform, and</li>
                  <li>booking and payment between Families and Caregivers for care services provided by Caregivers to Families (Caregiver Services).</li>
                </ul>
                <p className="text-gray-700 leading-relaxed mb-4">
                  When Caregiver Services are booked and confirmed by the Caregiver, a binding agreement is created between the Caregiver and the Family. We are not a party to that agreement.
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  The public area of the Website is open to all website visitors.
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  We offer Families the ability to create a profile, request a babysitter, search for Caregivers in their area, view Caregiver profiles, check Caregiver availability, read reviews and request to be connected with a Caregiver. We offer Caregivers the ability to create a profile, apply for jobs, view Family profiles, determine their availability and hourly rate, and respond to requests to be connected with a Family.
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  We carry out an initial background check on each person applying to be a member Caregiver on our Platform through a third party. We do not carry out any checks on Families. This check is limited and we recommend that Caregivers and Families interview each other before scheduling Caregiver Services to ensure the right fit.
                </p>
                <p className="text-gray-700 leading-relaxed">
                  We may make changes to the Platform, its functionality or features at any time.
                </p>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-village-wine mb-4">What the Platform does not offer</h2>
                <p className="text-gray-700 leading-relaxed mb-4">
                  We do not introduce or supply Caregivers to Families. We do not select or propose specific Caregivers to Families, or Families to Caregivers. We do not employ any Caregivers nor are we an employment agency or a recruitment agency for any Caregiver or Family.
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  Except as described in these Terms, we do not verify, review, evaluate, interview, screen, vet or perform background checks on Families or Caregivers nor do we verify or edit any content posted to the Platform by a Caregiver or Family.
                </p>
                <p className="text-gray-700 leading-relaxed">
                  We are not a party to any agreement between a Caregiver and a Family. Families are the potential employers of Caregivers and are responsible for compliance with all applicable employment and other laws in connection with any employment relationship they establish (such as applicable employment standards legislation (including minimum wage laws), occupational health and safety legislation and accident compensation).
                </p>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-village-wine mb-4">How to become a member</h2>
                <p className="text-gray-700 leading-relaxed mb-4">
                  You must be a member to use the services of the Platform (Member). You become a member by accepting these Terms and our Privacy Policy, and by applying online. All Members must:
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4 mb-4">
                  <li>be aged 16 and over</li>
                  <li>have a valid email address</li>
                  <li>have the legal capacity to form a contract with us under law</li>
                  <li>not have been convicted of any criminal offence (and in the case of Families, no one in their household has been convicted of any criminal offence), and</li>
                  <li>pay the applicable membership fee for the membership tier selected.</li>
                </ul>
                <p className="text-gray-700 leading-relaxed mb-4">
                  Caregivers must also: be legally able to work in New Zealand and meet the requirements of our vetting process, which includes an interview by us and submitting documents for us to verify their identity, work experience, references, criminal record and to otherwise assist us in evaluating their suitability to be a Member. Membership will not be active until this process is complete. All Caregiver applicants consent to us carrying out checks on such documents and information, including by the use of third parties. Caregivers acknowledge their personal information may be displayed on the Platform and visible to other Members (other than address, contact phone number and email).
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  All Caregivers and Families warrant the details provided to us when applying for an account are accurate and up to date.
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  We may, at our sole discretion, decline an application by a Caregiver to register an account with us.
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  You must not attempt to re-register an account with us if we have terminated your account for any or no reason.
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  You are responsible for safeguarding your account password and any other credentials used to access that account. You must keep your account password secure, not let anyone else use your account, and notify us of any unauthorised use of your account.
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  Families should note that while we strive to maintain a rigorous vetting process for applicant Caregivers, this process is not exhaustive and should not be relied on by Families. It is essential for Families to conduct their own due diligence to ensure the suitability of a Caregiver to provide babysitting services.
                </p>
                <p className="text-gray-700 leading-relaxed">
                  Caregivers should note that we rely on Families to provide us with accurate information when setting up an account. We do not verify or check the information provided by Families, for example whether a Family member has been convicted of a criminal offence, and we don't make any representation relating to the accuracy of this information.
                </p>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-village-wine mb-4">Payment of membership fee</h2>
                <p className="text-gray-700 leading-relaxed mb-4">
                  Some of our membership tiers require payment of a membership fee. This section of the Terms covers payment of membership fees for the applicable membership tiers. Our membership fees are as displayed on the Website in New Zealand dollars (exclusive of Goods and Services Tax) and may be changed by us at any time provided we give you at least 30 days' advance notice. The change will become effective at the end of the then-current billing cycle. If you do not agree to the change in membership fee, you may cancel your membership before the change takes effect.
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  Membership fees are billed in advance on a recurring, periodic basis (each period is called a "billing cycle"). Billing cycles are monthly or yearly, depending on what subscription plan you select when registering your account. Your membership will automatically renew at the end of each billing cycle unless you cancel no later than 10 days prior to the end of the billing cycle in which case your membership (and the obligation to pay the membership fee) will continue until the end of that billing cycle.
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  If you cancel your membership before the end of the billing cycle, you will not be entitled to any refund of any membership fees already paid for that billing cycle, prorated or otherwise.
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  You will be billed using the billing method you select when registering your account. You may be directed to our payment provider's website to complete payment. Their terms and conditions will also apply to your transaction, and if you pay by credit card you may be charged an additional fee. All billing information (including credit card details) is collected by our third-party payment processor, and we do not have access to any credit card information.
                </p>
                <p className="text-gray-700 leading-relaxed">
                  Should automatic payment of any membership fees fail to occur for any reason, your account will be suspended, until full payment is received.
                </p>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-village-wine mb-4">Booking, fees and Payment for Caregiver Services</h2>
                <p className="text-gray-700 leading-relaxed mb-4">
                  Following a booking request by a Family for Caregiver Services, Caregivers must respond within 2 hours otherwise the booking will be deemed to be rejected.
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  Once a Family has been connected with a Caregiver through the Platform, all bookings and payments between Families and Caregivers must be made through the Platform. We facilitate payment via our third-party payment provider. You will be required to accept the terms and conditions applicable to that third-party payment provider.
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  We charge Families a booking fee (Booking Fee). The Booking Fee is calculated as a percentage of the amount payable to the Caregiver for the booked Caregiver Services. The percentage will be clearly displayed to Families in their account settings. We may change the amount of the Booking Fee from time to time.
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  We also charge a fee to Caregivers for facilitating payment (Platform Fee). The Platform Fee is calculated as a percentage of the amount payable to the Caregiver for the booked Caregiver Services. The percentage will be clearly displayed to Caregivers in their account settings. We may change the Platform Fee from time to time.
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  Families are required to supply valid credit card details at the time of making a booking request for Caregiver Services (Family Card). The Family Card will be pre-authorised to cover the total value of the booking (being the number of minutes duration of the booked Caregiver Services multiplied by the Caregiver's hourly rate, plus the Booking Fee) (Total Booking Payment). If the Family Card is not able to be pre-authorised the booking request will be declined.
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  Upon completion of the Caregiver Services, we will collect from the Family Card the amount due, being the number of minutes duration of the Caregiver Services as stated in the Platform at the end of the engagement, multiplied by the Caregiver's hourly rate as stated at the time the booking is confirmed, plus the Booking Fee (Actual Services Payment).
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  If Caregiver Services are provided and the Family Card is not able to be charged for any reason, the Family will make payment to an account nominated by us within 24 hours of notification.
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  The Platform Fee and Booking Fee will be deducted from the Actual Services Payment, and payment of the balance will be made by us to Caregivers within three working days of receiving payment from the relevant Family. Caregivers need to hold valid accounts with Stripe to receive payments from us.
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  We are not a party to the payment for any services provided by a Caregiver to a Family. Our obligation to pay Caregivers is subject to receipt of the corresponding amount from Families.
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  If the Caregiver requests to end the booking early due to an unforeseen personal emergency or circumstances that are beyond their control, the Family will only be charged for the amount of time that was completed. For example, if only 2 out of 4 hours were completed, the Family would pay 50% of the booking amount.
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  If the Caregiver is late to arrive for the booking, the Family will only be charged for the amount of time that was completed.
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  If the Caregiver requests an early end to the booking due to reasonable circumstances (e.g., unsafe or uncomfortable conditions in the home), we may, at our discretion, determine that the full Total Booking Payment remains payable.
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  If the Family arrives home after the agreed end time, the Family will be charged for the additional time at the Caregiver's agreed hourly rate. If the Family does not communicate the lateness to the Caregiver in advance, a late fee will be charged. The amount of the late fee will be displayed on the Platform.
                </p>
                <p className="text-gray-700 leading-relaxed">
                  Families agree to treat Caregivers courteously and lawfully and to provide a safe and appropriate environment for them in compliance with all applicable laws and regulations. Families also agree to provide Caregivers with all reasonable information and cooperation required to enable them to provide the booked Caregiver Services.
                </p>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-village-wine mb-4">Booking cancellations and refunds</h2>
                <p className="text-gray-700 leading-relaxed mb-4">
                  Families or Caregivers may cancel a confirmed booking at any time before the agreed start time within their account on the Platform.
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  If a Family cancels a confirmed booking within 24 hours of the agreed start time, the Total Booking Payment will be charged to the Family and the Caregiver will receive that amount less the Booking Fee and Platform Fee. However, if the cancellation is due to a genuine emergency outside of the Family's control and has been notified to us as soon as reasonably possible, we may (at our discretion) waive part of the Total Booking Payment.
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  If a Family cancels a confirmed booking between 24-72 hours before the agreed start time, 25% of the Total Booking Payment will be charged to the Family, and the Caregiver will receive that amount less the Booking Fee and Platform Fee.
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  If a Caregiver cancels a confirmed booking within 24 hours of the agreed start time (or fails to show up), the Caregiver will be charged a cancellation fee and will not be entitled to receive any payment from us. The amount of the cancellation fee will be displayed on the Platform. The cancellation fee will be deducted from future payments due to the Caregiver. The Family will not be charged for the booking. We will attempt to arrange a replacement Caregiver for the Family. If the cancellation is due to the Caregiver's sickness or a genuine personal emergency outside of the Caregiver's control and has been notified to us as soon as reasonably possible, we may (at our discretion) agree that the cancellation fee is not payable.
                </p>
                <p className="text-gray-700 leading-relaxed">
                  Multiple cancellations by a Caregiver or Family may result in a warning, and persistent cancellations may result in the suspension of their account for a period of time (to be determined by us) or permanent cancellation of their account.
                </p>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-village-wine mb-4">Reviews and other user content</h2>
                <p className="text-gray-700 leading-relaxed mb-4">The following user-generated content (User Content) may be uploaded to the Platform:</p>
                <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4 mb-4">
                  <li>photos and information (about yourself if you are a Caregiver, or about your children and family if you are a Family) when creating your profile</li>
                  <li>reviews and ratings of Caregivers</li>
                  <li>reviews and ratings of Families</li>
                  <li>Member testimonials</li>
                  <li>questions and answers</li>
                </ul>
                <p className="text-gray-700 leading-relaxed mb-4">
                  You give us indefinite, worldwide rights to use, copy, change, display or share (free of charge) all User Content for the purposes of operating, improving, developing, marketing and promoting the Platform.
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  Where a Family posts a review of a Caregiver, you must not post any review that is offensive, discriminatory, threatening or harmful. Caregivers agree that we are not required to moderate, verify or remove any reviews posted on the Platform about you.
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  Where a Caregiver posts a review of a Family, you must not post any review that is offensive, discriminatory, threatening or harmful. Families agree that we are not required to moderate, verify or remove any reviews posted on the Platform about you.
                </p>
                <p className="text-gray-700 leading-relaxed mb-4">
                  You may not cancel your registration and re-register in order to prevent a review or rating from being associated with your account.
                </p>
                <p className="text-gray-700 leading-relaxed">
                  Any reviews or ratings posted by other users are the views of that person based on their experience. You may not experience the same results.
                </p>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-village-wine mb-4">Disputes between Caregivers and Families</h2>
                <p className="text-gray-700 leading-relaxed">
                  If any disputes or disagreements arise between Caregivers and Families relating to the services provided by Caregivers or payments made by or due from Families, the Families and Caregivers are responsible for resolving any such disputes directly with each other. While we will not be a party to any such dispute, we may facilitate communication between Caregivers and Families and, if necessary, offer assistance in dispute resolution.
                </p>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-village-wine mb-4">Privacy, data security and data use</h2>
                <p className="text-gray-700 leading-relaxed mb-4">
                  All personal information collected by us will be stored, used and shared in accordance with our Privacy Policy, which is incorporated into these Terms.
                </p>
                <p className="text-gray-700 leading-relaxed">
                  We will store and process your data in a manner consistent with industry security standards. We have implemented appropriate technical, organisational, and administrative systems, policies, and procedures.
                </p>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-village-wine mb-4">Our intellectual property rights</h2>
                <p className="text-gray-700 leading-relaxed mb-4">
                  Unless stated otherwise, neither these Terms nor your use of the Platform or the Website grant you intellectual property rights in the content, images, text, arrangement, layout or functionality of the Website and the Platform (other than your User Content).
                </p>
                <p className="text-gray-700 leading-relaxed">
                  These Terms do not grant you any right to use our trademarks.
                </p>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-village-wine mb-4">Contact Information</h2>
                <p className="text-gray-700 leading-relaxed">
                  If you have any questions about these Terms of Service, please contact us at info@thevillageco.nz or call 07 807 9114.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
      </div>
    </>
  );
}

export default TermsOfService;