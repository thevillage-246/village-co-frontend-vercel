import { useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import AdminDashboard from './admin/Dashboard';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

export default function DirectAdminRoute() {
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [, navigate] = useLocation();

  useEffect(() => {
    // Check if there's user data in localStorage
    const userDataStr = localStorage.getItem('userData');
    
    if (userDataStr) {
      try {
        const userData = JSON.parse(userDataStr);
        
        // Check if the user has admin role
        if (userData.role === 'admin') {
          setIsAuthorized(true);
        } else {
          // Not an admin, show the error card
          setIsAuthorized(false);
        }
      } catch (error) {
        console.error('Failed to parse user data:', error);
        setIsAuthorized(false);
      }
    } else {
      // No user data found
      setIsAuthorized(false);
    }
  }, []);

  const handleBackToLogin = () => {
    navigate('/direct-login');
  };

  if (!isAuthorized) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-linen p-4">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6 flex flex-col items-center">
            <h2 className="text-2xl font-bold text-red-600 mb-4">Access Denied</h2>
            <p className="text-center mb-6">
              You need to be logged in as an admin to access this page.
            </p>
            <Button 
              onClick={handleBackToLogin}
              className="bg-wine hover:bg-wine/90"
            >
              Back to Login
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // If authorized, render the admin dashboard
  return <AdminDashboard />;
}