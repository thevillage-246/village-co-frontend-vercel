import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, FileText, Shield, Eye } from "lucide-react";
import { Link } from "wouter";
import SEO, { SEOConfigs } from "@/components/SEO";

function PrivacyPolicy() {
  return (
    <>
      <SEO {...SEOConfigs.privacyPolicy} />
      <div className="min-h-screen bg-bone">
      {/* Hero Section */}
      <section className="bg-village-wine text-white py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center mb-6">
            <Link href="/">
              <button className="flex items-center text-linen hover:text-white transition-colors mr-4">
                <ArrowLeft className="h-5 w-5 mr-2" />
                Back to Home
              </button>
            </Link>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 bg-linen/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Shield className="h-8 w-8 text-linen" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Privacy Policy
            </h1>
            <p className="text-xl text-brushed-pink">
              How The Village Co. collects, uses, and protects your personal information
            </p>
            <p className="text-sm text-linen/80 mt-4">
              Last updated: September 9, 2024 • Effective immediately
            </p>
          </div>
        </div>
      </section>

      {/* Privacy Policy Content */}
      <section className="py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <Card className="border-almond-frost/20 shadow-sm">
            <CardContent className="p-8 space-y-8">
              <div>
                <p className="text-gray-700 leading-relaxed mb-6">
                  This Privacy Policy tells you how It Takes a Village Babysitting Limited (New Zealand Business Number: 9429052218101) (called we, us or our below) collects, uses, shares and protects your personal information. It applies to the information and data we collect from you (called you or your below) including when you use our website, access our products or services through our app, portal or otherwise (Services), or interact with us through social media or our marketing activities. By visiting our website, using our Services or otherwise interacting with us, you agree to us processing your personal information in accordance with this Privacy Policy.
                </p>
                <p className="text-gray-700 leading-relaxed">
                  We are committed to complying with the New Zealand Privacy Act 2020.
                </p>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-village-wine mb-4">What personal information do we collect?</h2>
                <p className="text-gray-700 leading-relaxed mb-4">
                  "Personal information" is any information about an identifiable individual. It does not include data that cannot identify an individual. Personal information we collect through your use of our Services or otherwise, may include:
                </p>
                <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                  <li><strong>Contact data:</strong> your name, email address, phone number, address</li>
                  <li><strong>Verification data:</strong> images of your passport or drivers licence, criminal record check, work visa information</li>
                  <li><strong>Profile data:</strong> user name and password, date of birth, photograph, qualifications, languages spoken, work experience, skills, certificates, and any other information you add to your account profile</li>
                  <li><strong>Payment and transaction data:</strong> payment card and billing information</li>
                  <li><strong>User-generated content:</strong> such as profile pictures, images, comments, reviews, and other content or information that you generate, transmit, or otherwise make available on the Service</li>
                  <li><strong>Family data:</strong> such as information provided about your child (such as name, birthday, school, allergies, disabilities, medical information) if you are a parent</li>
                  <li><strong>Device and online activity data:</strong> data about visitors to our website and their use and behaviour while using our website, and device and browser data – see the Cookies and other tracking technologies section below</li>
                </ul>
                <p className="text-gray-700 leading-relaxed mt-4">
                  Our Services are intended to be used by persons over 16 years. If you're under the age of 16, you may not register an account with us or use our Services.
                </p>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-village-wine mb-4">How do we collect your personal information?</h2>
                <p className="text-gray-700 leading-relaxed">
                  We collect your personal information directly from you, such as when you set up an account, contact us via email, phone, use our website or social media, post content or access or use our Services. We may also collect personal information from publicly available information, and data providers (such as identity verification services, background check providers) and other people you have authorised us to collect it from. We may also collect information while you use our Services using technology like cookies, in accordance with the section below. Please only give us up-to-date and correct information. Please don't give us personal information about someone else unless they have consented to you sharing their personal information with us and have agreed to this Privacy Policy.
                </p>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-village-wine mb-4">Cookies and other tracking technologies</h2>
                <p className="text-gray-700 leading-relaxed">
                  We use cookies and similar tracking technologies to monitor your activity on our Website and store certain information. Cookies are small data files placed on your device that enable us to enhance and personalise your online experience, understand website usage, and improve our services. The cookies we use may include: essential cookies necessary for the functioning of the Website; performance cookies to monitor site usage; functional cookies that remember your preferences; and targeting or advertising cookies to deliver personalised content and advertisements. You can manage your preferences at any time to withdraw your consent to our use of cookies by either accessing the cookie settings on our Website or directly through your web browser. For more information on how to manage and delete cookies, visit https://www.aboutcookies.org/ or www.allaboutcookies.org. Withdrawing your consent may impact your user experience and prevent you from using certain parts of our Website. Essential cookies, necessary for the operation of the website, cannot be rejected as they are required for website security and accessibility.
                </p>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-village-wine mb-4">For what purposes do we use your personal information?</h2>
                <p className="text-gray-700 leading-relaxed mb-4">We may use personal information collected from you to:</p>
                <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                  <li>provide or improve our Services to you</li>
                  <li>conduct background checks</li>
                  <li>set up and administer your account with us</li>
                  <li>communicate with you including responding to questions from you</li>
                  <li>improve your personal experience on our website or app</li>
                  <li>get feedback to improve our Services collect any money you owe us</li>
                  <li>handle complaints and disputes</li>
                  <li>comply with our legal and contractual obligations or enforce our legal rights</li>
                  <li>promote our products or services to you and provide other information we think you may find interesting (including information promoting our business partners)</li>
                  <li>by aggregating and de-identifying with other data to analyse, improve and promote our business</li>
                  <li>for any other purposes authorised in writing by you or by law</li>
                </ul>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-village-wine mb-4">Disclosure of your personal information</h2>
                <p className="text-gray-700 leading-relaxed mb-4">We may disclose your personal information to others for the purposes specified above. This may include:</p>
                <ul className="list-disc list-inside text-gray-700 space-y-2 ml-4">
                  <li>any business that helps us or works with us to provide our products or services or operate our business (for example, service providers, identity verification providers, background check providers, technology providers, cloud-providers, product usage analytics data storage and back-up, payment providers or processors)</li>
                  <li>any other person as required or authorised by law</li>
                  <li>in connection with, or during negotiations of, any sale of our assets or all or a portion of our business</li>
                  <li>anyone else, as explicitly authorised by you in writing</li>
                </ul>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-village-wine mb-4">International Data Transfers</h2>
                <p className="text-gray-700 leading-relaxed">
                  We might transfer to and store your personal information in countries outside of New Zealand, such as countries in which our service providers are located or have servers. These countries may not have the same data protection regulations as New Zealand. We will only transfer your information outside New Zealand where the person we disclose it to: (i) is doing business in New Zealand (and must comply with the Privacy Act 2020); (ii) will, we believe, adequately protect the information; (iii) must comply with similar privacy laws to the Privacy Act 2020; or (iv) where you have told us we can.
                </p>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-village-wine mb-4">How we keep your personal information safe and secure</h2>
                <p className="text-gray-700 leading-relaxed">
                  We have implemented suitable physical, electronic, and managerial procedures to keep personal information safe and secure and protect it from misuse, interference, loss, or unauthorised access, modification, and disclosure. However, security risk is inherent in all internet and information technologies and we cannot guarantee the security of your personal information.
                </p>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-village-wine mb-4">Retention of personal information</h2>
                <p className="text-gray-700 leading-relaxed">
                  We will retain your personal information only for as long as it is necessary for the purposes for which it may be used, after which we will delete it from our systems.
                </p>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-village-wine mb-4">How you can access and correct your personal information</h2>
                <p className="text-gray-700 leading-relaxed">
                  You can ask us to show you what personal information we hold about you and to correct any mistakes by emailing info@thevillageco.nz. If there is a legal reason we can't let you see the information, or if we don't agree with your correction, we will give you our reasons and note your requested correction to the information.
                </p>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-village-wine mb-4">Direct Marketing</h2>
                <p className="text-gray-700 leading-relaxed">
                  We may contact you by telephone, regular mail, or electronically (email, SMS or via other electronic means) with promotional material and offers of products or services from us and our related companies, as well as offers from our business partners that we consider may be relevant and of interest to you. You can unsubscribe from receiving these messages at any time by using the opt-out function provided with the message.
                </p>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-village-wine mb-4">How to make a privacy complaint</h2>
                <p className="text-gray-700 leading-relaxed">
                  If you think we have not followed our privacy obligations, you can make a complaint by contacting us at info@thevillageco.nz. You can also make a complaint to the New Zealand Privacy Commissioner by emailing enquiries@privacy.org.nz.
                </p>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-village-wine mb-4">Changes to this Privacy Policy</h2>
                <p className="text-gray-700 leading-relaxed">
                  We may change this Privacy Policy at any time. We will publish the updated policy on our website. If the changes are significant we will notify you of those changes. If you have any questions about this policy, please contact us at info@thevillageco.nz.
                </p>
                <p className="text-gray-700 leading-relaxed mt-4">
                  <strong>Effective date of policy:</strong> 09 September 2024
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
      </div>
    </>
  );
}

export default PrivacyPolicy;