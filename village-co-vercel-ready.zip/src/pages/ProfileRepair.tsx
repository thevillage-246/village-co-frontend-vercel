import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

export default function ProfileRepair() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    displayName: 'Nikki P',
    phoneNumber: '',
    bio: 'none that I can think of at the moment',
    address: 'Harrowfield, Hamilton, New Zealand',
    children: 'Jess, 3, no allergies. Sassy but wonderfully cute. She loves reading and baking.; Ollie, 1, no allergies. Walking but not talking yet. He does understand what we are saying though. Has a little separation anxiety but he relaxes quite quickly after I have left.',
    emergencyContactName: 'Jeremy Pak',
    emergencyContactPhone: '0211997760'
  });

  const handleSubmit = async () => {
    setLoading(true);
    console.log('🔧 DIRECT PROFILE REPAIR - BYPASSING ALL FORM COMPLEXITY');
    
    try {
      const token = localStorage.getItem('auth_token') || localStorage.getItem('authToken');
      
      // Update user data
      const userResponse = await fetch('/api/users/251591', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          username: formData.displayName
        })
      });

      if (!userResponse.ok) {
        throw new Error(`User update failed: ${userResponse.status}`);
      }

      // Update parent profile  
      const parentResponse = await fetch('/api/parents/251591/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          phone: formData.phoneNumber,
          address: formData.address,
          bio: formData.bio,
          children: formData.children,
          emergencyContact: `${formData.emergencyContactName} - ${formData.emergencyContactPhone}`,
          schoolDaycare: ''
        })
      });

      if (!parentResponse.ok) {
        throw new Error(`Parent profile update failed: ${parentResponse.status}`);
      }

      console.log('✅ Direct profile repair successful');
      
      toast({
        title: "Profile Updated Successfully!",
        description: "All data has been saved correctly.",
      });

      setTimeout(() => {
        setLocation('/dashboard');
      }, 1500);

    } catch (error) {
      console.error('❌ Direct repair failed:', error);
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-linen">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl text-center">Profile Repair Tool</CardTitle>
              <p className="text-center text-muted-foreground">
                Direct profile update to fix data inconsistency issues
              </p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <label className="text-sm font-medium">Display Name</label>
                <Input
                  value={formData.displayName}
                  onChange={(e) => setFormData(prev => ({ ...prev, displayName: e.target.value }))}
                  placeholder="Enter your display name"
                />
              </div>

              <div>
                <label className="text-sm font-medium">Phone Number</label>
                <Input
                  value={formData.phoneNumber}
                  onChange={(e) => setFormData(prev => ({ ...prev, phoneNumber: e.target.value }))}
                  placeholder="Enter your phone number"
                />
              </div>

              <div>
                <label className="text-sm font-medium">Bio</label>
                <Textarea
                  value={formData.bio}
                  onChange={(e) => setFormData(prev => ({ ...prev, bio: e.target.value }))}
                  rows={3}
                />
              </div>

              <div>
                <label className="text-sm font-medium">Address</label>
                <Input
                  value={formData.address}
                  onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
                />
              </div>

              <div>
                <label className="text-sm font-medium">Children Information</label>
                <Textarea
                  value={formData.children}
                  onChange={(e) => setFormData(prev => ({ ...prev, children: e.target.value }))}
                  rows={4}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Emergency Contact Name</label>
                  <Input
                    value={formData.emergencyContactName}
                    onChange={(e) => setFormData(prev => ({ ...prev, emergencyContactName: e.target.value }))}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Emergency Contact Phone</label>
                  <Input
                    value={formData.emergencyContactPhone}
                    onChange={(e) => setFormData(prev => ({ ...prev, emergencyContactPhone: e.target.value }))}
                  />
                </div>
              </div>

              <div className="flex gap-4 pt-4">
                <Button
                  variant="outline"
                  onClick={() => setLocation('/dashboard')}
                  className="flex-1"
                  disabled={loading}
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleSubmit}
                  disabled={loading}
                  className="flex-1"
                >
                  {loading ? 'Saving...' : 'Save Profile'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}