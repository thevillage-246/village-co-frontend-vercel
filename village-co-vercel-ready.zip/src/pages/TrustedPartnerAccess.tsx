import React, { useEffect, useState } from 'react';
import { useRoute, useLocation } from 'wouter';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Shield, Calendar, MapPin, Clock, Phone, MessageCircle, ArrowLeft } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface TrustedPartnerData {
  family: {
    parentName: string;
    parentEmail: string;
    parentPhone?: string;
    children: Array<{
      name: string;
      age: number;
      notes?: string;
    }>;
    emergencyContact: {
      name: string;
      phone: string;
    };
  };
  currentBooking?: {
    id: number;
    sitterName: string;
    sitterPhone: string;
    startTime: string;
    endTime: string;
    status: string;
    sitNotes?: string;
    location: string;
  };
  upcomingBookings: Array<{
    id: number;
    sitterName: string;
    startTime: string;
    endTime: string;
    status: string;
  }>;
  permission: 'viewer' | 'manager';
}

export default function TrustedPartnerAccess() {
  const [, params] = useRoute('/trusted-partner/:token');
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [accessGranted, setAccessGranted] = useState(false);

  const { data: partnerData, isLoading, error } = useQuery({
    queryKey: [`/api/trusted-partners/access/${params?.token}`],
    enabled: !!params?.token,
    retry: false,
  });

  useEffect(() => {
    if (partnerData) {
      setAccessGranted(true);
    } else if (error) {
      toast({
        title: "Access Denied",
        description: "This link is invalid or has expired. Please contact the family for a new invitation.",
        variant: "destructive",
      });
    }
  }, [partnerData, error, toast]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-linen/30 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-village-wine border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!accessGranted || !partnerData) {
    return (
      <div className="min-h-screen bg-linen/30 flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-600">
              <Shield className="h-5 w-5" />
              Access Denied
            </CardTitle>
            <CardDescription>
              This trusted partner link is invalid or has expired. 
              Please contact the family for a new invitation.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => navigate('/')} className="w-full">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Go to Homepage
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const { family, currentBooking, upcomingBookings, permission } = partnerData;

  return (
    <div className="min-h-screen bg-linen/30">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="mb-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-village-wine mb-2">
                  Family Dashboard
                </h1>
                <p className="text-gray-600">
                  Trusted partner access for {family.parentName}'s family
                </p>
              </div>
              <Badge variant="secondary" className="flex items-center gap-1">
                <Shield className="h-3 w-3" />
                {permission === 'viewer' ? 'View Only' : 'Manager Access'}
              </Badge>
            </div>
          </div>

          {/* Current Booking */}
          {currentBooking && (
            <Card className="mb-6 border-green-200 bg-green-50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-green-700">
                  <Clock className="h-5 w-5" />
                  Active Booking
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="font-semibold text-green-700">Sitter: {currentBooking.sitterName}</p>
                    <p className="text-sm text-gray-600 flex items-center gap-1">
                      <Phone className="h-3 w-3" />
                      {currentBooking.sitterPhone}
                    </p>
                    <p className="text-sm text-gray-600 flex items-center gap-1">
                      <MapPin className="h-3 w-3" />
                      {currentBooking.location}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">
                      {new Date(currentBooking.startTime).toLocaleString()} - 
                      {new Date(currentBooking.endTime).toLocaleString()}
                    </p>
                    {currentBooking.sitNotes && (
                      <p className="text-sm text-gray-600 mt-2">
                        <strong>Notes:</strong> {currentBooking.sitNotes}
                      </p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Family Information */}
            <Card>
              <CardHeader>
                <CardTitle>Family Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold">Parent</h4>
                  <p>{family.parentName}</p>
                  <p className="text-sm text-gray-600">{family.parentEmail}</p>
                  {family.parentPhone && (
                    <p className="text-sm text-gray-600 flex items-center gap-1">
                      <Phone className="h-3 w-3" />
                      {family.parentPhone}
                    </p>
                  )}
                </div>

                <div>
                  <h4 className="font-semibold">Children</h4>
                  <div className="space-y-2">
                    {family.children.map((child, index) => (
                      <div key={index} className="p-2 bg-gray-50 rounded">
                        <p className="font-medium">{child.name}, {child.age} years old</p>
                        {child.notes && (
                          <p className="text-sm text-gray-600">{child.notes}</p>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold">Emergency Contact</h4>
                  <p>{family.emergencyContact.name}</p>
                  <p className="text-sm text-gray-600 flex items-center gap-1">
                    <Phone className="h-3 w-3" />
                    {family.emergencyContact.phone}
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Upcoming Bookings */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  Upcoming Bookings
                </CardTitle>
              </CardHeader>
              <CardContent>
                {upcomingBookings.length === 0 ? (
                  <p className="text-gray-500">No upcoming bookings</p>
                ) : (
                  <div className="space-y-3">
                    {upcomingBookings.map((booking) => (
                      <div key={booking.id} className="p-3 border rounded-lg">
                        <div className="flex justify-between items-start">
                          <div>
                            <p className="font-medium">{booking.sitterName}</p>
                            <p className="text-sm text-gray-600">
                              {new Date(booking.startTime).toLocaleDateString()} at{' '}
                              {new Date(booking.startTime).toLocaleTimeString([], { 
                                hour: '2-digit', 
                                minute: '2-digit' 
                              })}
                            </p>
                          </div>
                          <Badge variant="outline">{booking.status}</Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Contact Actions */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Need Help?</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4">
                <Button 
                  variant="outline" 
                  onClick={() => window.location.href = `tel:${family.parentPhone}`}
                  disabled={!family.parentPhone}
                >
                  <Phone className="h-4 w-4 mr-2" />
                  Call Parent
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => window.location.href = `mailto:${family.parentEmail}`}
                >
                  <MessageCircle className="h-4 w-4 mr-2" />
                  Email Parent
                </Button>
                {currentBooking && (
                  <Button 
                    variant="outline"
                    onClick={() => window.location.href = `tel:${currentBooking.sitterPhone}`}
                  >
                    <Phone className="h-4 w-4 mr-2" />
                    Call Sitter
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}