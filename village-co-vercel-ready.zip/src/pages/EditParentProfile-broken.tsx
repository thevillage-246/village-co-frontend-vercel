import React, { useState, useRef } from 'react';
import { useLocation } from 'wouter';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useAuth } from '@/contexts/AuthContext';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { SearchableSchoolSelect } from '@/components/ui/searchable-school-select';
import { ChevronLeft, Camera, Upload, User } from 'lucide-react';

const editProfileSchema = z.object({
  displayName: z.string().min(1, "Display name is required"),
  address: z.string().optional(),
  bio: z.string().optional(),
  children: z.string().optional(),
  schoolDaycare: z.string().optional(),
});

const EditParentProfile = () => {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [initialDataLoaded, setInitialDataLoaded] = useState(false);
  
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Fetch current user profile
  const { data: userProfile, isLoading: loadingUser } = useQuery({
    queryKey: ['/api/users', user?.id],
    enabled: !!user?.id,
  });

  // Fetch parent profile
  const { data: parentProfile, isLoading: loadingParent } = useQuery({
    queryKey: ['/api/parents', user?.id, 'profile'],
    queryFn: async () => {
      const response = await fetch(`/api/parents/${user?.id}/profile`, {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('auth_token') || localStorage.getItem('authToken')}`
        }
      });
      if (!response.ok) throw new Error('Failed to fetch profile');
      return response.json();
    },
    enabled: !!user?.id,
  });

  // Fetch children to get first child's school
  const { data: children } = useQuery({
    queryKey: [`/api/parents/${user?.id}/children`],
    enabled: !!user?.id,
  });

  const form = useForm({
    resolver: zodResolver(editProfileSchema),
    defaultValues: {
      displayName: '',
      address: '',
      bio: '',
      children: '',
      schoolDaycare: '',
    },
  });

  // Update form when data loads for the first time
  React.useEffect(() => {
    if (userProfile && parentProfile && !initialDataLoaded) {
      const firstChild = (children as any)?.[0];
      const currentSchool = firstChild?.schoolOrDaycare || (parentProfile as any)?.schoolDaycare || '';
      
      // Handle userProfile being an array and extract username properly
      const userDataArray = Array.isArray(userProfile) ? userProfile : [userProfile];
      const userData = userDataArray[0] || userProfile;
      const username = userData?.username || '';
      const nameParts = username.split(' ');
      const firstName = nameParts[0] || '';
      const lastName = nameParts.slice(1).join(' ') || '';
      
      form.reset({
        displayName: username,
        address: (parentProfile as any)?.address || '',
        bio: (parentProfile as any)?.bio || '',
        children: (parentProfile as any)?.children || '',
        schoolDaycare: currentSchool,
      });
      setInitialDataLoaded(true);
    }
  }, [userProfile, parentProfile, children, form, initialDataLoaded]);

  // Update form when userProfile or parentProfile changes (after mutations)
  React.useEffect(() => {
    if (userProfile && parentProfile && initialDataLoaded) {
      const currentFormData = form.getValues();
      
      // Handle userProfile being an array (from the logs it shows as array)
      const userDataArray = Array.isArray(userProfile) ? userProfile : [userProfile];
      const userData = userDataArray[0] || userProfile;
      const newDisplayName = userData?.username || '';
      
      // Get updated parent profile data
      const parentData = Array.isArray(parentProfile) ? parentProfile[0] : parentProfile;
      const newBio = parentData?.bio || '';
      const newAddress = parentData?.address || '';
      const newChildren = parentData?.children || '';
      const newSchoolDaycare = parentData?.schoolDaycare || '';
      
      // Update form values if they've changed
      if (currentFormData.displayName !== newDisplayName) {
        form.setValue('displayName', newDisplayName);
      }
      if (currentFormData.bio !== newBio) {
        form.setValue('bio', newBio);
      }
      if (currentFormData.address !== newAddress) {
        form.setValue('address', newAddress);
      }
      if (currentFormData.children !== newChildren) {
        form.setValue('children', newChildren);
      }
      if (currentFormData.schoolDaycare !== newSchoolDaycare) {
        form.setValue('schoolDaycare', newSchoolDaycare);
      }
    }
  }, [userProfile, parentProfile, form, initialDataLoaded]);

  // Update user mutation
  const updateUserMutation = useMutation({
    mutationFn: async (data: { username: string; profileImage?: string }) => {
      console.log('🚀 Making PUT request to:', `/api/users/${user?.id}`);
      console.log('🚀 Request data:', data);
      const response = await apiRequest('PUT', `/api/users/${user?.id}`, data);
      const result = await response.json();
      console.log('🚀 API response:', result);
      return result;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users', user?.id] });
      queryClient.invalidateQueries({ queryKey: ['/api/parents', user?.id, 'profile'] });
      // Force refetch current user data
      queryClient.refetchQueries({ queryKey: ['/api/users', user?.id] });
    },
  });

  // Update parent profile mutation
  const updateParentMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest('PUT', `/api/parents/${user?.id}/profile`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/parents/${user?.id}/profile`] });
      toast({
        title: "Profile Updated",
        description: "Your profile has been updated successfully.",
      });
      setLocation('/dashboard');
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update profile",
        variant: "destructive",
      });
    },
  });

  // Upload photo mutation
  const uploadPhotoMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('photo', file);
      
      // Get JWT token from localStorage (check both locations)
      const token = localStorage.getItem('auth_token') || localStorage.getItem('authToken');
      
      const headers: Record<string, string> = {};
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
      
      const response = await fetch('/api/upload/profile-photo', {
        method: 'POST',
        body: formData,
        headers,
        credentials: 'include', // Include session cookies as fallback
      });
      
      if (!response.ok) {
        const errorData = await response.text();
        throw new Error(errorData || 'Failed to upload photo');
      }
      return response.json();
    },
  });

  const handlePhotoSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
    }
  };

  const handleCameraCapture = () => {
    if (cameraInputRef.current) {
      cameraInputRef.current.click();
    }
  };

  const handleGallerySelect = () => {
    if (galleryInputRef.current) {
      galleryInputRef.current.click();
    }
  };





  const onSubmit = async (data: any) => {
    setIsSubmitting(true);
    
    console.log('🚀 === PROFILE SAVE DEBUG START ===');
    console.log('🚀 Form data received:', JSON.stringify(data, null, 2));
    console.log('🚀 Form validation state:', form.formState.errors);
    console.log('🚀 User context:', user);
    console.log('🚀 Selected file:', selectedFile);
    console.log('🚀 Current userProfile:', userProfile);
    console.log('🚀 Current parentProfile:', parentProfile);
    
    try {

      let profileImageUrl = (userProfile as any)?.profileImage;

      // Upload photo if selected
      if (selectedFile) {

        console.log('📸 File details:', {
          name: selectedFile.name,
          size: selectedFile.size,
          type: selectedFile.type
        });
        
        try {
          const photoResult = await uploadPhotoMutation.mutateAsync(selectedFile);
          profileImageUrl = photoResult.url;
          addDebugStep('✅ STEP 2A SUCCESS: Photo uploaded');
          console.log('✅ STEP 2A SUCCESS: Photo uploaded:', photoResult);
        } catch (photoError) {
          addDebugStep('❌ STEP 2A FAILED: Photo upload error');
          console.error('❌ STEP 2A FAILED: Photo upload error:', photoError);
          throw new Error(`Photo upload failed: ${photoError.message}`);
        }
      } else {
        addDebugStep('⏭️ STEP 2A SKIPPED: No photo selected');
      }

      // Update user profile - use displayName as username
      addDebugStep('✅ STEP 3: Updating user profile...');
      console.log('👤 New username will be:', data.displayName);
      
      const userUpdateData = {
        username: data.displayName,
        profileImage: profileImageUrl,
      };
      console.log('👤 User update payload:', userUpdateData);
      
      try {
        const userUpdateResult = await updateUserMutation.mutateAsync(userUpdateData);
        addDebugStep('✅ STEP 3 SUCCESS: User profile updated');
        console.log('✅ STEP 3 SUCCESS: User profile updated:', userUpdateResult);
      } catch (userError) {
        addDebugStep('❌ STEP 3 FAILED: User update error');
        console.error('❌ STEP 3 FAILED: User update error:', userError);
        throw new Error(`User profile update failed: ${userError.message}`);
      }

      // Update parent profile
      addDebugStep('✅ STEP 4: Updating parent profile...');
      const parentProfileData = {
        address: data.address,
        bio: data.bio,
        children: data.children,
        schoolDaycare: data.schoolDaycare,
      };
      
      console.log('👨‍👩‍👧‍👦 Parent profile payload:', JSON.stringify(parentProfileData, null, 2));
      
      try {
        const parentUpdateResult = await updateParentMutation.mutateAsync(parentProfileData);
        addDebugStep('✅ STEP 4 SUCCESS: Parent profile updated');
        console.log('✅ STEP 4 SUCCESS: Parent profile updated:', parentUpdateResult);
        
        // Show success message
        addDebugStep('✅ SUCCESS: Showing success message');
        toast({
          title: "Profile Updated Successfully!",
          description: "Your profile has been saved and updated.",
        });
        
        console.log('✅ === PROFILE SAVE COMPLETED SUCCESSFULLY ===');
        
        // Reset form state
        setIsSubmitting(false);
        
        // Redirect after success (with delay to show toast)
        setTimeout(() => {
          setLocation('/dashboard');
        }, 1500);
        
      } catch (parentError) {
        addDebugStep('❌ STEP 4 FAILED: Parent profile update error');
        console.error('❌ STEP 4 FAILED: Parent profile update error:', parentError);
        throw new Error(`Parent profile update failed: ${parentError.message}`);
      }

    } catch (error: any) {
      addDebugStep('❌ PROFILE SAVE FAILED');
      console.error('❌ === PROFILE SAVE FAILED ===');
      console.error('❌ Error details:', error);
      console.error('❌ Error stack:', error.stack);
      
      setIsSubmitting(false);
      
      toast({
        title: "Profile Save Failed",
        description: error.message || "Failed to update profile. Please try again.",
        variant: "destructive",
      });
    }
    
    console.log('🏁 === PROFILE SAVE DEBUG END ===');
  };

  if (loadingUser || loadingParent) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }




  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center mb-6">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => setLocation('/dashboard')}
            className="mr-4"
          >
            <ChevronLeft className="h-4 w-4 mr-1" />
            Back to Dashboard
          </Button>
          <h1 className="text-2xl font-bold text-gray-900">Edit Profile</h1>
        </div>

        <div className="max-w-2xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="h-5 w-5" />
                Update Your Information
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  {/* Profile Photo Section */}
                  <div className="flex flex-col items-center space-y-4">
                    <Avatar className="h-24 w-24">
                      <AvatarImage 
                        src={previewUrl || (userProfile as any)?.profileImage} 
                        alt="Profile" 
                      />
                      <AvatarFallback className="text-xl">
                        {(userProfile as any)?.firstName?.charAt(0)}
                        {(userProfile as any)?.lastName?.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    
                    <div className="flex gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={handleCameraCapture}
                        className="flex items-center gap-2"
                      >
                        <Camera className="h-4 w-4" />
                        Camera
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={handleGallerySelect}
                        className="flex items-center gap-2"
                      >
                        <Upload className="h-4 w-4" />
                        Gallery
                      </Button>
                    </div>
                    
                    {/* Camera input with capture for camera */}
                    <input
                      ref={cameraInputRef}
                      type="file"
                      accept="image/*"
                      capture="environment"
                      onChange={handlePhotoSelect}
                      className="hidden"
                    />
                    
                    {/* Gallery input without capture for gallery selection */}
                    <input
                      ref={galleryInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handlePhotoSelect}
                      className="hidden"
                    />
                  </div>

                  {/* Display Name Field */}
                  <FormField
                    control={form.control}
                    name="displayName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Display Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter your display name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Address */}
                  <FormField
                    control={form.control}
                    name="address"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Address</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter your address" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Children */}
                  <FormField
                    control={form.control}
                    name="children"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Children</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Tell us about your children" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* School/Daycare Field */}
                  <FormField
                    control={form.control}
                    name="schoolDaycare"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Child's School or Daycare (Optional)</FormLabel>
                        <FormControl>
                          <SearchableSchoolSelect
                            value={field.value || ''}
                            onChange={(value) => {
                              const schoolValue = value === 'none' ? '' : value;
                              field.onChange(schoolValue);
                            }}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Bio */}
                  <FormField
                    control={form.control}
                    name="bio"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Bio / Preferences (Optional)</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Tell us about yourself, your family, or any specific preferences..."
                            className="min-h-[100px]"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Debug Panel - Only show during submission */}
                  {isSubmitting && debugSteps.length > 0 && (
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                      <h4 className="font-medium text-blue-900 mb-2">🔍 Form Submission Progress</h4>
                      <div className="space-y-1">
                        {debugSteps.map((step, index) => (
                          <div key={index} className="text-sm text-blue-800 font-mono">
                            {step}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Submit Button */}
                  <div className="flex gap-4 pt-4">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setLocation('/dashboard')}
                      className="flex-1"
                      disabled={isSubmitting}
                    >
                      Cancel
                    </Button>
                    <Button
                      type="submit"
                      disabled={updateParentMutation.isPending || uploadPhotoMutation.isPending || isSubmitting}
                      className="flex-1"
                    >
                      {isSubmitting || updateParentMutation.isPending || uploadPhotoMutation.isPending
                        ? 'Saving...'
                        : 'Save Profile'
                      }
                    </Button>
                  </div>


                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default EditParentProfile;