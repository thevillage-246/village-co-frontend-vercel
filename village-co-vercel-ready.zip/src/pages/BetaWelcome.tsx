import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Heart, 
  Shield, 
  MessageCircle, 
  Star, 
  Users, 
  Clock,
  CheckCircle,
  Sparkles,
  Gift,
  Mail
} from "lucide-react";
import { Link } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import SEO from "@/components/SEO";

export default function BetaWelcome() {
  const { user } = useAuth();

  const betaFeatures = [
    {
      icon: <Shield className="h-6 w-6 text-village-wine" />,
      title: "Verified Sitters",
      description: "All sitters are background-checked and identity verified"
    },
    {
      icon: <MessageCircle className="h-6 w-6 text-village-wine" />,
      title: "Real-Time Messaging",
      description: "Chat directly with sitters before and during bookings"
    },
    {
      icon: <Star className="h-6 w-6 text-village-wine" />,
      title: "Review System",
      description: "Rate your experience and see what other families say"
    },
    {
      icon: <Clock className="h-6 w-6 text-village-wine" />,
      title: "Instant Booking",
      description: "Book trusted childcare in just a few clicks"
    }
  ];

  const comingSoon = [
    "AI-powered sitter matching",
    "Recurring booking templates", 
    "In-app video calling",
    "Live location sharing",
    "Village subscription plans"
  ];

  return (
    <>
      <SEO 
        title="Welcome to The Village Co. Beta - Trusted Childcare"
        description="You're part of something special! Join New Zealand's most trusted babysitting platform beta and help us build the future of family care."
      />
      
      <div className="min-h-screen bg-bone">
        {/* Hero Section */}
        <section className="bg-village-wine text-white py-16">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <div className="w-20 h-20 bg-linen/20 rounded-full flex items-center justify-center mx-auto mb-6">
              <Sparkles className="h-10 w-10 text-linen" />
            </div>
            
            <Badge className="bg-linen/20 text-linen mb-6 px-4 py-2">
              Beta Tester - Founding Family
            </Badge>
            
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Welcome to Something Special
            </h1>
            
            <p className="text-xl text-brushed-pink mb-8 max-w-2xl mx-auto">
              You're now part of The Village Co. beta family - New Zealand's most trusted 
              babysitting platform built by parents, for parents.
            </p>
            
            {user && (
              <div className="bg-linen/10 rounded-lg p-4 mb-6 text-left max-w-md mx-auto">
                <p className="text-sm">
                  <strong>Welcome, {user.firstName}!</strong><br />
                  Your beta access is active and ready to use.
                </p>
              </div>
            )}
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/find-sitter">
                <Button size="lg" className="bg-linen text-village-wine hover:bg-almond-frost font-medium">
                  <Heart className="h-5 w-5 mr-2" />
                  Start Browsing Sitters
                </Button>
              </Link>
              
              <Button 
                variant="outline" 
                size="lg" 
                className="border-linen text-linen hover:bg-linen hover:text-village-wine"
                onClick={() => window.open('mailto:beta@thevillageco.nz')}
              >
                <Mail className="h-5 w-5 mr-2" />
                Contact Beta Support
              </Button>
            </div>
          </div>
        </section>

        {/* What's Ready Now */}
        <section className="py-16">
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-village-wine mb-4">What's Ready Now</h2>
              <p className="text-gray-600 text-lg">
                Complete booking experience with verified sitters and secure payments
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
              {betaFeatures.map((feature, index) => (
                <Card key={index} className="border-almond-frost/20 hover:shadow-md transition-shadow">
                  <CardContent className="p-6 text-center">
                    <div className="w-12 h-12 bg-village-wine/10 rounded-full flex items-center justify-center mx-auto mb-4">
                      {feature.icon}
                    </div>
                    <h3 className="font-semibold text-village-wine mb-2">{feature.title}</h3>
                    <p className="text-sm text-gray-600">{feature.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Beta Perks */}
            <Card className="border-green-200 bg-green-50 mb-8">
              <CardHeader>
                <CardTitle className="text-green-800 flex items-center gap-2">
                  <Gift className="h-6 w-6" />
                  Your Beta Tester Perks
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-green-800">50% off your first booking</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-green-800">Direct line to founders</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-green-800">Early access to new features</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="text-green-800">Lifetime "Founding Family" status</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Coming Soon */}
        <section className="py-16 bg-gray-50">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-village-wine mb-4">Coming Soon</h2>
              <p className="text-gray-600">
                Exciting features we're building based on your feedback
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {comingSoon.map((feature, index) => (
                <div key={index} className="flex items-center gap-3 bg-white p-4 rounded-lg border border-almond-frost/20">
                  <div className="w-2 h-2 bg-village-wine rounded-full"></div>
                  <span className="text-gray-700">{feature}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Feedback Section */}
        <section className="py-16">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl font-bold text-village-wine mb-6">We Want Your Feedback</h2>
            
            <p className="text-gray-600 text-lg mb-8">
              This is beta, which means we're learning and improving every day. 
              Your experience matters more than anything else.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <Card className="border-blue-200 bg-blue-50">
                <CardContent className="p-6 text-center">
                  <Mail className="h-8 w-8 text-blue-600 mx-auto mb-3" />
                  <h3 className="font-semibold text-blue-800 mb-2">Email Us</h3>
                  <p className="text-sm text-blue-700">beta@thevillageco.nz</p>
                </CardContent>
              </Card>
              
              <Card className="border-blue-200 bg-blue-50">
                <CardContent className="p-6 text-center">
                  <MessageCircle className="h-8 w-8 text-blue-600 mx-auto mb-3" />
                  <h3 className="font-semibold text-blue-800 mb-2">Call Us</h3>
                  <p className="text-sm text-blue-700">07 807 9114</p>
                </CardContent>
              </Card>
              
              <Card className="border-blue-200 bg-blue-50">
                <CardContent className="p-6 text-center">
                  <Star className="h-8 w-8 text-blue-600 mx-auto mb-3" />
                  <h3 className="font-semibold text-blue-800 mb-2">In-App</h3>
                  <p className="text-sm text-blue-700">Use "Contact Support"</p>
                </CardContent>
              </Card>
            </div>
            
            <div className="bg-village-wine/5 rounded-lg p-6">
              <h3 className="font-semibold text-village-wine mb-4">What We're Most Curious About:</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-left">
                <div>• How easy was your first booking?</div>
                <div>• Did the sitter communication feel natural?</div>
                <div>• Any features missing for your family?</div>
                <div>• Would you recommend us to other parents?</div>
              </div>
            </div>
          </div>
        </section>

        {/* Get Started CTA */}
        <section className="py-16 bg-village-wine text-white">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl font-bold mb-6">Ready to Book Your First Sitter?</h2>
            <p className="text-xl text-brushed-pink mb-8">
              Join the families already loving their Village Co. experience
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/find-sitter">
                <Button size="lg" className="bg-linen text-village-wine hover:bg-almond-frost font-medium">
                  <Users className="h-5 w-5 mr-2" />
                  Browse Sitters
                </Button>
              </Link>
              
              <Link href="/book">
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="border-linen text-linen hover:bg-linen hover:text-village-wine"
                >
                  <Clock className="h-5 w-5 mr-2" />
                  Book Now
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}