import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { apiRequest } from '@/lib/queryClient';
import SitterOnboardingStep1 from '@/components/onboarding/SitterOnboardingStep1';
import SitterOnboardingStep2 from '@/components/onboarding/SitterOnboardingStep2';
import SitterOnboardingStep3 from '@/components/onboarding/SitterOnboardingStep3';
import SitterOnboardingStep4 from '@/components/onboarding/SitterOnboardingStep4';

export interface SitterOnboardingData {
  // Step 1: Basic info
  firstName: string;
  email: string;
  mobile: string;
  howHeardAbout: string;
  whyBabysit: string;
  
  // Step 2: Profile building
  profilePhoto?: File;
  bio: string;
  experienceLevel: string;
  availability: {
    monday: boolean;
    tuesday: boolean;
    wednesday: boolean;
    thursday: boolean;
    friday: boolean;
    saturday: boolean;
    sunday: boolean;
  };
  preferredTimes: string[];
  suburbs: string[];
  
  // Step 3: Qualifications
  qualifications: string[];
  qualificationFiles: File[];
  
  // Step 4: Verification
  videoIntro?: File;
  idDocument?: File;
  backgroundCheckConsent: boolean;
  referees: {
    name: string;
    email: string;
  }[];
  firstAidCertificate?: File;
  codeOfCareAgreement: boolean;
}

export default function SitterOnboarding() {
  const [, setLocation] = useLocation();
  const [currentStep, setCurrentStep] = useState(1);
  const [onboardingData, setOnboardingData] = useState<SitterOnboardingData>({
    firstName: '',
    email: '',
    mobile: '',
    howHeardAbout: '',
    whyBabysit: '',
    bio: '',
    experienceLevel: '',
    availability: {
      monday: false,
      tuesday: false,
      wednesday: false,
      thursday: false,
      friday: false,
      saturday: false,
      sunday: false,
    },
    preferredTimes: [],
    suburbs: [],
    qualifications: [],
    qualificationFiles: [],
    backgroundCheckConsent: false,
    referees: [
      { name: '', email: '' }
    ],
    codeOfCareAgreement: false,
  });

  const updateData = (data: Partial<SitterOnboardingData>) => {
    setOnboardingData(prev => ({ ...prev, ...data }));
  };

  const nextStep = () => {
    if (currentStep < 4) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleComplete = async () => {
    try {
      console.log('🎯 Submitting sitter onboarding data:', onboardingData);
      
      // Call the complete onboarding API endpoint
      const response = await apiRequest('/api/sitter/complete-onboarding', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(onboardingData),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to complete onboarding');
      }

      const result = await response.json();
      console.log('✅ Onboarding completed successfully:', result);
      
      // Navigate to thank you page
      setLocation('/sitter-onboarding-thank-you');
    } catch (error) {
      console.error('❌ Error completing sitter onboarding:', error);
      // You might want to show an error toast or message here
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-linen via-brushed-pink/20 to-white">
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-village-wine">
              Step {currentStep} of 4
            </span>
            <span className="text-sm text-taupe">
              {currentStep === 1 && "You've got this!"}
              {currentStep === 2 && "Looking good..."}
              {currentStep === 3 && "Nearly there..."}
              {currentStep === 4 && "Final step!"}
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-village-wine to-rose h-2 rounded-full transition-all duration-500"
              style={{ width: `${(currentStep / 4) * 100}%` }}
            />
          </div>
        </div>

        {/* Step Content */}
        {currentStep === 1 && (
          <SitterOnboardingStep1
            data={onboardingData}
            updateData={updateData}
            onNext={nextStep}
          />
        )}

        {currentStep === 2 && (
          <SitterOnboardingStep2
            data={onboardingData}
            updateData={updateData}
            onNext={nextStep}
            onBack={prevStep}
          />
        )}

        {currentStep === 3 && (
          <SitterOnboardingStep3
            data={onboardingData}
            updateData={updateData}
            onNext={nextStep}
            onBack={prevStep}
          />
        )}

        {currentStep === 4 && (
          <SitterOnboardingStep4
            data={onboardingData}
            updateData={updateData}
            onComplete={handleComplete}
            onBack={prevStep}
          />
        )}
      </div>
    </div>
  );
}