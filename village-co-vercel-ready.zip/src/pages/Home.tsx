import { Link, useLocation } from 'wouter';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Star, Shield, MessageSquare, ArrowRight, Heart, Clock, Users, UserCheck, Search, CreditCard } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { useEffect } from 'react';
import SEO, { SEOConfigs } from '@/components/SEO';
const heroImage = "/images/village-hero-clean.png";


function Home() {
  const [, navigate] = useLocation();
  const { user } = useAuth();





  const testimonials = [
    {
      id: 1,
      name: 'Ellen',
      role: 'Mum of 2',
      image: '/images/parent-testimonial.jpg',
      comment: 'Nicci was absolutely amazing! We will definitely book her again. The boys had a great time and we had a great break!'
    },
    {
      id: 2,
      name: 'Jamie',
      role: 'Parent',
      image: '/images/parent-testimonial.jpg',
      comment: 'Niamh was excellent. Quickly built a rapport with the kids and put them at ease. Communicated perfectly both before and during the night. We had a great night out and look forward to using the service again soon.'
    },
    {
      id: 3,
      name: 'Angela',
      role: 'Parent',
      image: '/images/parent-testimonial.jpg',
      comment: 'Shavaughn was punctual, had an instant easy rapport with our tama and even though he had never been babysat by someone he had not met before, he was happy to stay with her (no clinging as we left) and has asked when he can have Shavaughn babysit again. A total success! Thank you Shavaughn.'
    }
  ];

  return (
    <>
      <SEO {...SEOConfigs.homepage} />

      
      {/* Hero Section - Modern Parent Care Design */}
      <section className="bg-[#F9F5F0] py-20 lg:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
            <div className="text-left space-y-8">
              <div className="space-y-6">
                <h1 className="text-5xl lg:text-6xl xl:text-7xl font-bold leading-tight text-[#6B3E4B]" style={{ fontFamily: 'Satoshi, sans-serif' }}>
                  We've Got the Kids.
                </h1>
                <p className="text-xl text-gray-600 leading-relaxed max-w-xl" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                  The Village Co. is your modern babysitting platform, built by mums, backed by real people, and trusted by families across New Zealand.
                </p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4">
                {user ? (
                  <>
                    <Button 
                      size="lg"
                      onClick={() => navigate('/book')}
                      className="bg-[#6B3E4B] hover:bg-[#6B3E4B]/90 text-white px-8 py-4 text-lg rounded-xl shadow-lg group"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      Book a Sitter
                      <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </>
                ) : (
                  <>
                    <Button 
                      size="lg"
                      onClick={() => navigate('/register')}
                      className="bg-[#6B3E4B] hover:bg-[#6B3E4B]/90 text-white px-8 py-4 text-lg rounded-xl shadow-lg group"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      <UserCheck className="w-5 h-5 mr-2" />
                      Join the Village
                    </Button>
                    <Button 
                      size="lg"
                      onClick={() => navigate('/login')}
                      variant="outline"
                      className="border-[#6B3E4B] text-[#6B3E4B] hover:bg-[#6B3E4B] hover:text-white px-8 py-4 text-lg rounded-xl shadow-lg"
                      style={{ fontFamily: 'DM Sans, sans-serif' }}
                    >
                      Sign In
                      <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5 ml-2" />
                    </Button>
                  </>
                )}
              </div>
              

              <div className="mt-8 sm:mt-12 flex items-center space-x-4 sm:space-x-8">
                <div className="flex items-center">
                  <div className="flex -space-x-2">
                    <div className="w-10 h-10 rounded-full bg-village-wine border-2 border-white"></div>
                    <div className="w-10 h-10 rounded-full bg-almond-frost border-2 border-white"></div>
                    <div className="w-10 h-10 rounded-full bg-sleepy-blue border-2 border-white"></div>
                    <div className="w-10 h-10 rounded-full bg-brushed-pink border-2 border-white flex items-center justify-center text-village-wine text-sm font-medium">
                      +12
                    </div>
                  </div>
                  <span className="ml-3 text-almond-frost text-sm">Sitters available now</span>
                </div>
              </div>
            </div>
            <div className="lg:block">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-br from-village-wine/10 to-sleepy-blue/20 rounded-3xl transform rotate-3"></div>
                <img 
                  src={heroImage} 
                  alt="A relaxed parent enjoying a peaceful moment with coffee"
                  className="relative rounded-3xl shadow-2xl w-full h-auto object-cover transform hover:scale-105 transition-transform duration-300"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Trust Elements Section */}
      <section className="py-16 bg-white border-t border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
            <div className="text-center md:text-left">
              <div className="flex items-center justify-center md:justify-start space-x-2 mb-2">
                <Shield className="w-5 h-5 text-village-wine" />
                <span className="text-sm font-medium text-gray-900">Insurance-backed</span>
              </div>
              <p className="text-sm text-gray-600">Background-checked. Real human support.</p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <div className="flex text-yellow-400">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-current" />
                  ))}
                </div>
                <span className="ml-2 text-sm font-medium text-gray-900">4.8 rating</span>
              </div>
              <p className="text-sm text-gray-600">from local parents</p>
            </div>
            <div className="text-center md:text-right">
              <p className="text-sm text-gray-600 italic">
                "As seen in NZ Entrepreneur & Natural Parenting"
              </p>
            </div>
          </div>
        </div>
      </section>
      


      {/* Why We Started This Section */}
      <section id="why-we-started" className="py-24 bg-gradient-to-br from-bone to-brushed-pink">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-village-wine mb-6">Why We Started This</h2>
            <div className="mb-8">
              <img 
                src="/images/founders-family.jpg" 
                alt="Village Co founders and their families"
                className="rounded-3xl shadow-xl mx-auto max-w-2xl w-full object-cover"
              />
            </div>
            <p className="text-xl text-gray-700 max-w-4xl mx-auto leading-relaxed">
              "We started this in the middle of the chaos, mascara half-done, a toddler on one hip, and dinner reservations we were about to miss… again. We didn't need another app. We needed a village."
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h3 className="text-2xl font-bold text-village-wine mb-6">Our Story</h3>
              <div className="space-y-4 text-gray-600">
                <p className="leading-relaxed">
                  So we built it. The Village Co.
                </p>
                <p className="leading-relaxed">
                  A babysitting platform made for parents like us, the ones who plan ahead, juggle a million tabs, and still want space to breathe.
                </p>
                <p className="leading-relaxed">
                  Every sitter is verified, every booking backed by real support.
                  Because we're not just finding childcare, we're finding freedom, one night off at a time.
                </p>
              </div>
            </div>
            
            <div className="bg-white rounded-3xl p-8 shadow-xl">
              <h3 className="text-xl font-bold text-village-wine mb-6">What Makes The Village Co. Different</h3>
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="w-6 h-6 bg-village-wine/10 rounded-full flex items-center justify-center mr-3 mt-1">
                    <div className="w-2 h-2 bg-village-wine rounded-full"></div>
                  </div>
                  <div>
                    <h4 className="font-semibold text-village-wine">Built by parents, for parents</h4>
                    <p className="text-gray-600 text-sm">We've lived the juggle, the mental load, the "can we just get a break?" moments. This isn't theory, it's real life.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-6 h-6 bg-village-wine/10 rounded-full flex items-center justify-center mr-3 mt-1">
                    <div className="w-2 h-2 bg-village-wine rounded-full"></div>
                  </div>
                  <div>
                    <h4 className="font-semibold text-village-wine">Made for Kiwi families</h4>
                    <p className="text-gray-600 text-sm">From Auckland to Invercargill, we're built for Kiwi parents who want trusted, flexible support without the mum guilt.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-6 h-6 bg-village-wine/10 rounded-full flex items-center justify-center mr-3 mt-1">
                    <div className="w-2 h-2 bg-village-wine rounded-full"></div>
                  </div>
                  <div>
                    <h4 className="font-semibold text-village-wine">Safety you don't have to second-guess</h4>
                    <p className="text-gray-600 text-sm">Every sitter is interviewed, verified, and backed by our team. No shortcuts. No stress. Just peace of mind.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="w-6 h-6 bg-village-wine/10 rounded-full flex items-center justify-center mr-3 mt-1">
                    <div className="w-2 h-2 bg-village-wine rounded-full"></div>
                  </div>
                  <div>
                    <h4 className="font-semibold text-village-wine">A community, not a marketplace</h4>
                    <p className="text-gray-600 text-sm">You're not just booking childcare. You're joining a village, one that shows up, gets it, and has your back.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How We Match You Section */}
      <section id="for-parents" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="flex justify-center mb-4">
              <div className="w-16 h-16 bg-village-wine/10 rounded-full flex items-center justify-center">
                <Users className="w-8 h-8 text-village-wine" />
              </div>
            </div>
            <h2 className="text-4xl font-bold text-village-wine mb-6">How We Match You With the Right Sitter</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Because every family, and every child, is different.
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto mb-16">
            <p className="text-lg text-gray-700 leading-relaxed text-center">
              At The Village Co., we don't just throw a list of names at you and hope for the best. We've created a matching system that blends human connection with smart tech, so finding your perfect sitter actually feels... easy.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 mb-16">
            <div>
              <div className="mb-8">
                <h3 className="text-3xl font-bold text-village-wine mb-4">Here's How It Works</h3>
                <p className="text-lg text-gray-600">Because finding a sitter shouldn't feel like a full-time job.</p>
              </div>
              
              <div className="grid gap-8">
                <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
                  <div className="flex items-start gap-4">
                    <div className="bg-gradient-to-br from-village-wine to-village-wine/80 text-white font-bold text-lg w-12 h-12 rounded-xl flex items-center justify-center shrink-0">
                      1
                    </div>
                    <div>
                      <h4 className="text-xl font-bold text-village-wine mb-3">You tell us what matters</h4>
                      <p className="text-gray-700 leading-relaxed">
                        Every family profile starts with the important stuff: your child's needs, routines, quirks, allergies, and the kind of vibe you want in a sitter. (Chill uni student? Former ECE teacher? Someone who knows all the Bluey episodes by heart?)
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
                  <div className="flex items-start gap-4">
                    <div className="bg-gradient-to-br from-rose to-rose/80 text-white font-bold text-lg w-12 h-12 rounded-xl flex items-center justify-center shrink-0">
                      2
                    </div>
                    <div>
                      <h4 className="text-xl font-bold text-village-wine mb-3">We get to know our sitters, personally</h4>
                      <p className="text-gray-700 leading-relaxed">
                        Every sitter on our platform is background-checked, reference-verified, and personally called by a member of our team. No shortcuts, no strangers.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
                  <div className="flex items-start gap-4">
                    <div className="bg-gradient-to-br from-eucalyptus to-eucalyptus/80 text-white font-bold text-lg w-12 h-12 rounded-xl flex items-center justify-center shrink-0">
                      3
                    </div>
                    <div>
                      <h4 className="text-xl font-bold text-village-wine mb-3">Our system suggests your best fit</h4>
                      <p className="text-gray-700 leading-relaxed">
                        Our algorithm matches your preferences with sitter profiles, availability, experience, personality match, and more. You'll get sitters who actually suit your family, not whoever's online.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
                  <div className="flex items-start gap-4">
                    <div className="bg-gradient-to-br from-taupe to-taupe/80 text-white font-bold text-lg w-12 h-12 rounded-xl flex items-center justify-center shrink-0">
                      4
                    </div>
                    <div>
                      <h4 className="text-xl font-bold text-village-wine mb-3">You choose who feels right</h4>
                      <p className="text-gray-700 leading-relaxed">
                        You're in the driver's seat. Read reviews, watch video intros, and message sitters before booking. Or, let us guide you with curated matches if you'd rather not scroll.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-bone to-brushed-pink rounded-3xl p-8">
              <div className="flex items-center mb-6">
                <div className="w-8 h-8 bg-village-wine rounded-full flex items-center justify-center mr-3">
                  <Heart className="w-4 h-4 text-white fill-current" />
                </div>
                <h3 className="text-xl font-bold text-village-wine">Matching Filters We Use:</h3>
              </div>
              
              <div className="space-y-3">
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-village-wine rounded-full mr-3"></div>
                  <span className="text-gray-700">Suburb & travel preferences</span>
                </div>
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-village-wine rounded-full mr-3"></div>
                  <span className="text-gray-700">Child age/needs fit</span>
                </div>
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-village-wine rounded-full mr-3"></div>
                  <span className="text-gray-700">Sitter experience level (e.g. infants, neurodiverse support, twins)</span>
                </div>
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-village-wine rounded-full mr-3"></div>
                  <span className="text-gray-700">Availability (evenings, school holidays, ad hoc)</span>
                </div>
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-village-wine rounded-full mr-3"></div>
                  <span className="text-gray-700">Personality tags (gentle, energetic, creative, calm, etc.)</span>
                </div>
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-village-wine rounded-full mr-3"></div>
                  <span className="text-gray-700">Repeat bookings and review history</span>
                </div>
                <div className="flex items-center">
                  <div className="w-2 h-2 bg-village-wine rounded-full mr-3"></div>
                  <span className="text-gray-700">Parent–sitter compatibility score (coming soon)</span>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-3xl p-8 shadow-xl border-2 border-village-wine/10 max-w-4xl mx-auto">
            <div className="flex items-center mb-6">
              <div className="flex justify-center items-center mr-3">
                <div className="w-10 h-10 bg-village-wine/10 rounded-full flex items-center justify-center">
                  <Star className="w-5 h-5 text-village-wine" />
                </div>
              </div>
              <h3 className="text-2xl font-bold text-village-wine">Our Promise</h3>
            </div>
            <p className="text-gray-700 leading-relaxed mb-6">
              No bots. No guessing games. Just a smarter, safer way to find someone your kids will love, and someone you can trust.
            </p>
            <p className="text-gray-700 leading-relaxed mb-6">
              Because this isn't just babysitting. It's your life.
            </p>
            <p className="text-village-wine font-semibold text-lg">
              And we're here to help you live it, fully, freely, and with your village by your side.
            </p>
          </div>
        </div>
      </section>

      {/* For Sitters Section */}
      <section id="for-sitters" className="py-24 bg-gradient-to-br from-bone to-brushed-pink">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-village-wine mb-6">For Sitters</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Join The Village Co. and make a real difference in families' lives, all while earning great money doing something you love.
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h3 className="text-2xl font-bold text-village-wine mb-6">Why Sitters Choose Us</h3>
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="w-8 h-8 bg-village-wine/10 rounded-full flex items-center justify-center mr-4 mt-1">
                    <Heart className="w-4 h-4 text-village-wine" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-village-wine mb-2">Quality families, quality pay</h4>
                    <p className="text-gray-600 leading-relaxed">
                      Work with families who value what you do. Competitive rates, prompt payments, and families who appreciate great childcare.
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="w-8 h-8 bg-village-wine/10 rounded-full flex items-center justify-center mr-4 mt-1">
                    <Shield className="w-4 h-4 text-village-wine" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-village-wine mb-2">Your safety matters</h4>
                    <p className="text-gray-600 leading-relaxed">
                      All parents are verified too. Insurance coverage, background checks both ways, and a support team that has your back.
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="w-8 h-8 bg-village-wine/10 rounded-full flex items-center justify-center mr-4 mt-1">
                    <Clock className="w-4 h-4 text-village-wine" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-village-wine mb-2">Work on your terms</h4>
                    <p className="text-gray-600 leading-relaxed">
                      Set your own schedule, choose your families, work when it suits you. Flexible earning that fits your life.
                    </p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="w-8 h-8 bg-village-wine/10 rounded-full flex items-center justify-center mr-4 mt-1">
                    <Users className="w-4 h-4 text-village-wine" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-village-wine mb-2">Join the village</h4>
                    <p className="text-gray-600 leading-relaxed">
                      Connect with other sitters, ongoing training, and support from a team that actually gets childcare.
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-3xl p-8 shadow-xl">
              <h3 className="text-xl font-bold text-village-wine mb-6">Ready to Join?</h3>
              <p className="text-gray-600 mb-6 leading-relaxed">
                We're looking for caring, reliable sitters who love working with children. Background checks, references, and a quick chat with our team, that's it.
              </p>
              <div className="space-y-4">
                <Button 
                  size="lg"
                  onClick={() => navigate('/sitter-onboarding')}
                  className="w-full bg-village-wine hover:bg-village-wine/90 text-white py-4 text-lg rounded-xl"
                >
                  Apply to Be a Sitter
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
                <p className="text-sm text-gray-500 text-center">
                  Application takes about 5 minutes. Most sitters are approved within 48 hours.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Parents Love Us Section */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-village-wine mb-4">Why parents love us</h2>
            <p className="text-xl text-almond-frost max-w-3xl mx-auto">
              Because your freedom shouldn't come with guilt
            </p>
          </div>
          
          {/* Brand Voice Images Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
            <div className="relative group">
              <div className="relative overflow-hidden rounded-3xl shadow-xl">
                <img 
                  src="/images/1.png" 
                  alt="Parent and child sharing a peaceful moment"
                  className="w-full h-64 object-cover transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-village-wine/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </div>
              <div className="text-center mt-6">
                <h3 className="text-xl font-semibold text-village-wine mb-2">Quality time that matters</h3>
                <p className="text-gray-600">Your kids get amazing care while you get the break you deserve</p>
              </div>
            </div>
            
            <div className="relative group">
              <div className="relative overflow-hidden rounded-3xl shadow-xl">
                <img 
                  src="/images/3.png" 
                  alt="Couple enjoying a romantic evening together"
                  className="w-full h-64 object-cover transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-village-wine/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </div>
              <div className="text-center mt-6">
                <h3 className="text-xl font-semibold text-village-wine mb-2">Date nights, guilt-free</h3>
                <p className="text-gray-600">Reconnect with your partner knowing the kids are in excellent hands</p>
              </div>
            </div>
            
            <div className="relative group">
              <div className="relative overflow-hidden rounded-3xl shadow-xl">
                <img 
                  src="/images/5.png" 
                  alt="Parent enjoying a peaceful coffee moment"
                  className="w-full h-64 object-cover transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-village-wine/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </div>
              <div className="text-center mt-6">
                <h3 className="text-xl font-semibold text-village-wine mb-2">Me time, finally</h3>
                <p className="text-gray-600">That coffee while it's hot. That workout. That breath of fresh air</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-village-wine mb-4">Why we're different</h2>
            <p className="text-xl text-almond-frost max-w-3xl mx-auto">
              Because your kids deserve more than "good enough"
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-village-wine/10 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Shield className="w-8 h-8 text-village-wine" />
              </div>
              <h3 className="text-lg font-semibold text-village-wine mb-3">Properly vetted</h3>
              <p className="text-gray-600">Every sitter is interviewed, ID verified, and background checked. No shortcuts.</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-sleepy-blue/20 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Clock className="w-8 h-8 text-village-wine" />
              </div>
              <h3 className="text-lg font-semibold text-village-wine mb-3">Always available</h3>
              <p className="text-gray-600">Last-minute crisis or planned night out - our sitters are ready when you are</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-brushed-pink/30 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <MessageSquare className="w-8 h-8 text-village-wine" />
              </div>
              <h3 className="text-lg font-semibold text-village-wine mb-3">Stay connected</h3>
              <p className="text-gray-600">Live updates and pics so you know the kids are having a blast</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-almond-frost/20 rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Heart className="w-8 h-8 text-village-wine" />
              </div>
              <h3 className="text-lg font-semibold text-village-wine mb-3">Totally covered</h3>
              <p className="text-gray-600">$2 million insurance on every booking. Because worry is not the vibe</p>
            </div>
          </div>
        </div>
      </section>
      








      {/* Testimonials Section */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-village-wine mb-4">What families are saying</h2>
            <p className="text-xl text-almond-frost max-w-3xl mx-auto">
              Real stories from New Zealand families who've found their village
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-bone rounded-2xl p-8 shadow-lg">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-village-wine rounded-full flex items-center justify-center text-white font-bold text-lg">
                  E
                </div>
                <div className="ml-4">
                  <h4 className="font-semibold text-village-wine">Ellen</h4>
                  <p className="text-gray-600 text-sm">Mum of 2</p>
                </div>
              </div>
              <p className="text-gray-700 leading-relaxed mb-4">
                "Nicci was absolutely amazing! We will definitely book her again. The boys had a great time and we had a great break!"
              </p>
              <div className="flex text-yellow-400">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-4 w-4" fill="currentColor" />
                ))}
              </div>
            </div>
            
            <div className="bg-brushed-pink rounded-2xl p-8 shadow-lg">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-village-wine rounded-full flex items-center justify-center text-white font-bold text-lg">
                  J
                </div>
                <div className="ml-4">
                  <h4 className="font-semibold text-village-wine">Jamie</h4>
                  <p className="text-gray-600 text-sm">Parent</p>
                </div>
              </div>
              <p className="text-gray-700 leading-relaxed mb-4">
                "Niamh was excellent. Quickly built a rapport with the kids and put them at ease. Communicated perfectly both before and during the night. We had a great night out and look forward to using the service again soon."
              </p>
              <div className="flex text-yellow-400">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-4 w-4" fill="currentColor" />
                ))}
              </div>
            </div>
            
            <div className="bg-sleepy-blue/20 rounded-2xl p-8 shadow-lg">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 bg-village-wine rounded-full flex items-center justify-center text-white font-bold text-lg">
                  A
                </div>
                <div className="ml-4">
                  <h4 className="font-semibold text-village-wine">Angela</h4>
                  <p className="text-gray-600 text-sm">Parent</p>
                </div>
              </div>
              <p className="text-gray-700 leading-relaxed mb-4">
                "Shavaughn was punctual, had an instant easy rapport with our tama and even though he had never been babysat by someone he had not met before, he was happy to stay with her (no clinging as we left) and has asked when he can have Shavaughn babysit again. A total success! Thank you Shavaughn."
              </p>
              <div className="flex text-yellow-400">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-4 w-4" fill="currentColor" />
                ))}
              </div>
            </div>
          </div>
          
          <div className="text-center mt-12">
            <p className="text-gray-600 mb-6">Join hundreds of families across New Zealand</p>
            <Button 
              size="lg"
              onClick={() => navigate('/register')}
              className="bg-village-wine hover:bg-village-wine/90 text-white px-8 py-4 text-lg rounded-xl font-semibold"
            >
              Start Your Journey
            </Button>
          </div>
        </div>
      </section>



    </>
  );
}

export default Home;
