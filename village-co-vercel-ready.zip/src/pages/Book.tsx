import { useState, useEffect } from 'react';
import { useLocation, useParams } from 'wouter';
import { loadStripe } from '@stripe/stripe-js';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Info, ArrowLeft, User, Lock, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';

export default function Book() {
  const [, navigate] = useLocation();
  const params = useParams();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const { currentUser, isLoading: authLoading, isAuthenticated } = useAuth();
  
  // Verification status
  const [parentVerified, setParentVerified] = useState(false);
  const [sitterVerified, setSitterVerified] = useState(false);
  const [checkingVerification, setCheckingVerification] = useState(true);
  
  // User profile data
  const [parentProfile, setParentProfile] = useState<any>(null);
  const [children, setChildren] = useState<any[]>([]);
  
  // Booking fields
  const [date, setDate] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [location, setLocation] = useState('');
  const [specialInstructions, setSpecialInstructions] = useState('');
  const [sitDetails, setSitDetails] = useState('');
  const [sitterId, setSitterId] = useState('');
  const [sitterName, setSitterName] = useState('');
  
  // Available sitters
  const [sitters, setSitters] = useState<any[]>([]);
  
  // Payment calculation
  const [hourlyRate, setHourlyRate] = useState(25);
  const [duration, setDuration] = useState(0);
  const [subtotal, setSubtotal] = useState(0);
  const [serviceFee, setServiceFee] = useState(0);
  const [total, setTotal] = useState(0);

  // Helper function to calculate age from birthdate
  const calculateAge = (birthDate: string | Date) => {
    const today = new Date();
    const birth = new Date(birthDate);
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--;
    }
    
    return age;
  };

  // Load parent profile and children when user is authenticated
  useEffect(() => {
    const loadParentData = async () => {
      if (!currentUser || currentUser.role !== 'parent') return;

      try {
        // Check parent verification status
        const parentVerification = await fetch('/api/veriff/parent-status');
        if (parentVerification.ok) {
          const verifyData = await parentVerification.json();
          setParentVerified(verifyData.status === 'approved' || currentUser.manuallyVerified === true);
        } else {
          setParentVerified(currentUser.manuallyVerified === true);
        }

        // Load parent profile
        const profileResponse = await fetch(`/api/parents/${currentUser.id}/profile`);
        if (profileResponse.ok) {
          const profile = await profileResponse.json();
          setParentProfile(profile);
          
          // Auto-populate address
          if (profile.address) {
            setLocation(profile.address);
          }
          
          // Pre-populate with saved defaults from profile
          if (profile.childrenInfo) {
            setSitDetails(profile.childrenInfo);
          } else {
            // Fallback: Generate from children data if no saved default
            const childrenResponse = await fetch(`/api/parents/${currentUser.id}/children`);
            if (childrenResponse.ok) {
              const childrenData = await childrenResponse.json();
              setChildren(childrenData);
              
              if (childrenData.length > 0) {
                const childInfo = childrenData.map((child: any) => {
                  const details = [];
                  details.push(`${child.firstName} (${calculateAge(child.birthDate)} years old)`);
                  if (child.allergies) details.push(`Allergies: ${child.allergies}`);
                  if (child.specialNeeds) details.push(`Special needs: ${child.specialNeeds}`);
                  if (child.notes) details.push(`Notes: ${child.notes}`);
                  return details.join(', ');
                }).join('\n\n');
                
                setSitDetails(childInfo);
              }
            }
          }
          
          // Pre-populate default special instructions
          if (profile.defaultSpecialInstructions) {
            setSpecialInstructions(profile.defaultSpecialInstructions);
          }
        }

        setCheckingVerification(false);
      } catch (error) {
        console.error('Error loading parent data:', error);
        setCheckingVerification(false);
      }
    };

    if (isAuthenticated && currentUser) {
      loadParentData();
    }
  }, [isAuthenticated, currentUser]);

  // Load sitters data
  useEffect(() => {
    const loadSitters = async () => {
      try {
        const response = await fetch('/api/sitters');
        if (response.ok) {
          const sittersData = await response.json();
          setSitters(sittersData);
        }
      } catch (error) {
        console.error('Error loading sitters:', error);
      }
    };

    loadSitters();
  }, []);

  // Check for sitter ID in URL parameters and pre-populate
  useEffect(() => {
    // Check URL path params first (for routes like /book-sitter/2)
    const pathSitterId = params.id;
    // Check query params as fallback (for routes like /book?sitterId=2)
    const urlParams = new URLSearchParams(window.location.search);
    const queryParamSitterId = urlParams.get('sitterId');
    
    const urlSitterId = pathSitterId || queryParamSitterId;
    
    if (urlSitterId && sitters.length > 0) {
      setSitterId(urlSitterId);
      const selectedSitter = sitters.find(s => s.id === parseInt(urlSitterId));
      if (selectedSitter) {
        setHourlyRate(parseFloat(selectedSitter.hourlyRate) || 25);
        setSitterName(`${selectedSitter.firstName} ${selectedSitter.lastName || ''}`);
        setSitterVerified(selectedSitter.verificationStatus === 'approved' || selectedSitter.manuallyVerified === true);
        console.log('🎯 Selected sitter:', selectedSitter.firstName, 'Rate:', selectedSitter.hourlyRate, 'Verified:', selectedSitter.verificationStatus);
      }
    }
  }, [sitters, params.id]);

  // Calculate booking cost whenever relevant fields change
  useEffect(() => {
    if (startTime && endTime) {
      const start = new Date(`2000-01-01 ${startTime}`);
      const end = new Date(`2000-01-01 ${endTime}`);
      
      if (start < end) {
        const durationHours = (end.getTime() - start.getTime()) / (1000 * 60 * 60);
        setDuration(durationHours);
        
        const cost = durationHours * hourlyRate;
        setSubtotal(cost);
        
        const fee = cost * 0.10; // 10% service fee for parents
        setServiceFee(fee);
        
        setTotal(cost + fee);
      }
    }
  }, [startTime, endTime, hourlyRate]);

  // Handle booking submission
  const handleBookingSubmit = async () => {
    if (!currentUser) {
      toast({
        title: "Authentication Required",
        description: "Please sign in to book a sitter.",
        variant: "destructive",
      });
      navigate('/login');
      return;
    }

    if (!parentVerified) {
      toast({
        title: "Verification Required",
        description: "Please complete your identity verification before booking sitters. This helps keep all families and sitters safe.",
        variant: "destructive",
      });
      navigate('/parent/dashboard');
      return;
    }

    if (!sitterVerified) {
      toast({
        title: "Sitter Not Verified",
        description: "This sitter has not completed identity verification yet. Please choose a verified sitter.",
        variant: "destructive",
      });
      navigate('/find-sitter');
      return;
    }

    if (!sitterId) {
      toast({
        title: "Sitter Information Missing",
        description: "Unable to identify the sitter for this booking. Please try again from the Find Sitter page.",
        variant: "destructive",
      });
      return;
    }

    if (!date || !startTime || !endTime) {
      toast({
        title: "Missing Information",
        description: "Please fill in date, start time, and end time.",
        variant: "destructive",
      });
      return;
    }

    if (duration <= 0) {
      toast({
        title: "Invalid Duration",
        description: "End time must be after start time.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);

    try {
      const startDateTime = new Date(`${date} ${startTime}`);
      const endDateTime = new Date(`${date} ${endTime}`);

      // First, get or create parent profile to get parentId
      let parentProfileId = parentProfile?.id;
      
      if (!parentProfileId) {
        try {
          const createProfileResponse = await fetch(`/api/parents`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${localStorage.getItem('authToken')}`,
            },
            body: JSON.stringify({
              userId: currentUser.id,
              bio: '',
              address: location || '',
              phone: '',
              emergencyContact: '',
              preferences: '',
              children: '[]',
              schoolDaycare: '',
              childrenInfo: sitDetails || '',
              defaultSpecialInstructions: specialInstructions || '',
            }),
          });
          
          if (createProfileResponse.ok) {
            const newProfile = await createProfileResponse.json();
            parentProfileId = newProfile.id;
          }
        } catch (profileError) {
          console.error('Error creating parent profile:', profileError);
        }
      }

      const bookingData = {
        parentId: parentProfileId || currentUser.id,
        sitterId: parseInt(sitterId),
        startTime: startDateTime.toISOString(),
        endTime: endDateTime.toISOString(),
        hourlyRate: hourlyRate.toString(),
        sitNotes: sitDetails,
        specialRequests: specialInstructions,
        totalAmount: total.toString(),
        platformFee: serviceFee.toString(),
        status: 'pending'
      };
      
      console.log('🚀 Submitting booking with data:', bookingData);

      const response = await fetch('/api/bookings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('authToken')}`,
        },
        body: JSON.stringify(bookingData),
      });

      if (response.ok) {
        const booking = await response.json();
        toast({
          title: "Booking Requested",
          description: "Your booking request has been sent to the sitter.",
        });
        navigate(`/booking-confirmation/${booking.id}`);
      } else {
        const error = await response.json();
        toast({
          title: "Booking Failed",
          description: error.message || "Unable to create booking. Please try again.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Booking error:', error);
      toast({
        title: "Booking Failed",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  // Show loading state while checking authentication OR if we have a token but user data is still loading
  const hasToken = localStorage.getItem('authToken');
  const shouldShowLoading = authLoading || (hasToken && !currentUser);
  
  if (shouldShowLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-linen to-rose-50 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-village-wine border-t-transparent rounded-full" />
      </div>
    );
  }

  // Only show sign-in prompt if definitely not authenticated (no token and auth loading complete)
  if (!isAuthenticated && !hasToken && !authLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-linen to-rose-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-village-wine/20">
          <CardHeader className="text-center">
            <div className="mx-auto w-16 h-16 bg-village-wine/10 rounded-full flex items-center justify-center mb-4">
              <Lock className="w-8 h-8 text-village-wine" />
            </div>
            <CardTitle className="text-2xl text-village-wine">Sign in to book a sitter</CardTitle>
            <p className="text-taupe">You need to be logged in to book a sitter for your family.</p>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button 
              onClick={() => navigate('/login')}
              className="w-full bg-village-wine hover:bg-village-wine/90"
            >
              <User className="w-4 h-4 mr-2" />
              Sign In
            </Button>
            <Button 
              variant="outline" 
              onClick={() => navigate('/register')}
              className="w-full border-village-wine/30 text-village-wine hover:bg-village-wine/5"
            >
              Create Account
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Main booking form for authenticated users
  return (
    <div className="min-h-screen bg-gradient-to-br from-linen to-rose-50 py-8">
      <div className="container mx-auto px-4 max-w-2xl">
        {/* Header */}
        <div className="mb-6">
          <Button
            variant="ghost"
            onClick={() => navigate('/find-sitter')}
            className="mb-4 text-village-wine hover:bg-village-wine/10"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Find Sitter
          </Button>
          <h1 className="text-3xl font-bold text-village-wine mb-2">
            {sitterName ? `When do you need ${sitterName}?` : 'Book a Sitter'}
          </h1>
          <p className="text-taupe">Fill in the details for your booking request</p>
        </div>

        <div className="space-y-6">
          {/* Verification Status Warning */}
          {checkingVerification ? (
            <Card className="border-gray-200">
              <CardContent className="p-4">
                <div className="flex items-center justify-center">
                  <div className="animate-spin w-4 h-4 border-2 border-village-wine border-t-transparent rounded-full mr-2"></div>
                  <span className="text-sm text-gray-600">Checking verification status...</span>
                </div>
              </CardContent>
            </Card>
          ) : (
            <>
              {!parentVerified && (
                <Card className="border-red-200 bg-red-50">
                  <CardContent className="p-4">
                    <div className="flex items-start space-x-3">
                      <AlertCircle className="w-5 h-5 text-red-600 mt-0.5" />
                      <div>
                        <h3 className="font-medium text-red-900">Identity Verification Required</h3>
                        <p className="text-sm text-red-700 mt-1">
                          Please complete your identity verification before booking sitters. This helps keep all families and sitters safe.
                        </p>
                        <Button
                          onClick={() => navigate('/parent/dashboard')}
                          className="mt-2 bg-red-600 hover:bg-red-700 text-white text-sm"
                          size="sm"
                        >
                          Complete Verification
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
              {sitterId && !sitterVerified && (
                <Card className="border-amber-200 bg-amber-50">
                  <CardContent className="p-4">
                    <div className="flex items-start space-x-3">
                      <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5" />
                      <div>
                        <h3 className="font-medium text-amber-900">Sitter Not Verified</h3>
                        <p className="text-sm text-amber-700 mt-1">
                          This sitter has not completed identity verification yet. Please choose a verified sitter for your booking.
                        </p>
                        <Button
                          onClick={() => navigate('/find-sitter')}
                          className="mt-2 bg-amber-600 hover:bg-amber-700 text-white text-sm"
                          size="sm"
                        >
                          Choose Verified Sitter
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </>
          )}

          {/* Date and Time */}
          <Card className="border-village-wine/20">
            <CardHeader>
              <CardTitle className="text-village-wine">Date & Time</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="date">Date</Label>
                  <Input
                    id="date"
                    type="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    min={new Date().toISOString().split('T')[0]}
                  />
                </div>
                <div>
                  <Label htmlFor="startTime">Start Time</Label>
                  <Input
                    id="startTime"
                    type="time"
                    value={startTime}
                    onChange={(e) => setStartTime(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="endTime">End Time</Label>
                  <Input
                    id="endTime"
                    type="time"
                    value={endTime}
                    onChange={(e) => setEndTime(e.target.value)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Location */}
          <Card className="border-village-wine/20">
            <CardHeader>
              <CardTitle className="text-village-wine">Location</CardTitle>
            </CardHeader>
            <CardContent>
              <Input
                placeholder="Enter your address"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
              />
            </CardContent>
          </Card>

          {/* Sit Details */}
          <Card className="border-village-wine/20">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-village-wine">About Your Children</CardTitle>
              {sitDetails && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={async () => {
                    try {
                      await fetch(`/api/parents/${currentUser?.id}/profile`, {
                        method: 'PATCH',
                        headers: {
                          'Content-Type': 'application/json',
                          'Authorization': `Bearer ${localStorage.getItem('authToken')}`
                        },
                        body: JSON.stringify({ childrenInfo: sitDetails })
                      });
                      toast({
                        title: "Saved as Default",
                        description: "Children info saved for future bookings",
                      });
                    } catch (error) {
                      toast({
                        title: "Save Failed",
                        description: "Could not save children info",
                        variant: "destructive",
                      });
                    }
                  }}
                  className="text-xs"
                >
                  Save as Default
                </Button>
              )}
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="Tell us about your children (ages, allergies, special needs, etc.)"
                value={sitDetails}
                onChange={(e) => setSitDetails(e.target.value)}
                rows={4}
              />
              <p className="text-sm text-taupe mt-2">
                This information will be shared with your sitter to help them prepare for the visit.
              </p>
            </CardContent>
          </Card>

          {/* Special Instructions */}
          <Card className="border-village-wine/20">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-village-wine">Special Instructions</CardTitle>
              {specialInstructions && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={async () => {
                    try {
                      await fetch(`/api/parents/${currentUser?.id}/profile`, {
                        method: 'PATCH',
                        headers: {
                          'Content-Type': 'application/json',
                          'Authorization': `Bearer ${localStorage.getItem('authToken')}`
                        },
                        body: JSON.stringify({ defaultSpecialInstructions: specialInstructions })
                      });
                      toast({
                        title: "Saved as Default",
                        description: "Special instructions saved for future bookings",
                      });
                    } catch (error) {
                      toast({
                        title: "Save Failed",
                        description: "Could not save instructions",
                        variant: "destructive",
                      });
                    }
                  }}
                  className="text-xs"
                >
                  Save as Default
                </Button>
              )}
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="Any specific instructions for the sitter?"
                value={specialInstructions}
                onChange={(e) => setSpecialInstructions(e.target.value)}
                rows={3}
              />
              <p className="text-sm text-taupe mt-2">
                These instructions will be included with every booking unless you change them.
              </p>
            </CardContent>
          </Card>

          {/* Booking Summary */}
          {duration > 0 && (
            <Card className="border-village-wine/20 bg-village-wine/5">
              <CardHeader>
                <CardTitle className="text-village-wine">Booking Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between">
                  <span>Duration:</span>
                  <span>{duration} hours</span>
                </div>
                <div className="flex justify-between">
                  <span>Rate:</span>
                  <span>${hourlyRate}/hour</span>
                </div>
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Service Fee (10%):</span>
                  <span>${serviceFee.toFixed(2)}</span>
                </div>
                <div className="border-t pt-2 flex justify-between font-bold text-village-wine">
                  <span>Total:</span>
                  <span>${total.toFixed(2)}</span>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Submit Button */}
          <Button
            onClick={handleBookingSubmit}
            disabled={loading || !date || !startTime || !endTime || !sitterId || !parentVerified || !sitterVerified || checkingVerification}
            className={`w-full py-6 text-lg ${
              !parentVerified || !sitterVerified || checkingVerification
                ? 'bg-gray-400 hover:bg-gray-500 cursor-not-allowed'
                : 'bg-village-wine hover:bg-village-wine/90'
            }`}
          >
            {loading ? 'Creating Booking...' : 
             checkingVerification ? 'Checking Verification...' :
             !parentVerified ? 'Complete Your Verification to Book' :
             !sitterVerified ? 'Choose a Verified Sitter' :
             'Request Booking'}
          </Button>
        </div>
      </div>
    </div>
  );
}