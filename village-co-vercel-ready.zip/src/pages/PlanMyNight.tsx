import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import PlanMyNight from '@/components/parents/PlanMyNight';
import { ArrowLeft, Sparkles } from 'lucide-react';
import { Link } from 'wouter';
import { apiRequest } from '@/lib/queryClient';

export default function PlanMyNightPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isBooking, setIsBooking] = useState(false);
  const [bookingComplete, setBookingComplete] = useState(false);

  const handleBookingComplete = async (bookingData: any) => {
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please log in to book your perfect night.",
        variant: "destructive"
      });
      return;
    }

    setIsBooking(true);
    
    try {
      // Create the booking with concierge services
      const response = await apiRequest('POST', '/api/bookings/plan-my-night', {
        ...bookingData,
        parentId: user.id
      });

      if (response.ok) {
        setBookingComplete(true);
        toast({
          title: "Perfect Night Planned!",
          description: "Your concierge team is coordinating your evening. Check your email for details.",
        });
      } else {
        throw new Error('Booking failed');
      }
    } catch (error) {
      console.error('Booking error:', error);
      toast({
        title: "Booking Error",
        description: "We couldn't complete your booking. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsBooking(false);
    }
  };

  if (bookingComplete) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <Card className="bg-gradient-to-r from-wine/10 to-rose/10 border-wine/20">
            <CardContent className="p-8 text-center">
              <div className="mb-6">
                <Sparkles className="w-16 h-16 mx-auto text-wine mb-4" />
                <h1 className="text-3xl font-bold text-wine mb-2">
                  Your Perfect Night is Planned!
                </h1>
                <p className="text-lg text-muted-foreground">
                  Our concierge team is coordinating all the details for your special evening.
                </p>
              </div>
              
              <div className="space-y-4 text-left mb-8">
                <div className="bg-white/50 p-4 rounded-lg">
                  <h3 className="font-semibold mb-2">What happens next?</h3>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li>• You'll receive a detailed confirmation email within 15 minutes</li>
                    <li>• Our team will coordinate restaurant reservations and deliveries</li>
                    <li>• Your sitter will arrive 15 minutes early for a smooth handover</li>
                    <li>• Enjoy your perfectly planned evening!</li>
                  </ul>
                </div>
              </div>

              <div className="flex gap-4">
                <Button asChild variant="outline" className="flex-1">
                  <Link to="/parent/dashboard">
                    View Dashboard
                  </Link>
                </Button>
                <Button asChild className="flex-1 bg-wine hover:bg-wine/90">
                  <Link to="/find-sitter">
                    Plan Another Night
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <Button asChild variant="ghost" className="mb-4">
            <Link to="/find-sitter">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Find Sitter
            </Link>
          </Button>
          
          <div className="text-center">
            <h1 className="text-4xl font-bold text-wine mb-4">
              Plan My Perfect Night
            </h1>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Let our concierge team create the perfect evening for you. From sitter coordination 
              to restaurant reservations and premium add-ons, we handle every detail.
            </p>
          </div>
        </div>

        {/* Main Planning Component */}
        {isBooking ? (
          <div className="flex justify-center items-center py-16">
            <div className="text-center">
              <div className="animate-spin w-12 h-12 border-4 border-wine border-t-transparent rounded-full mx-auto mb-4"></div>
              <h3 className="text-lg font-semibold text-wine mb-2">
                Planning Your Perfect Night...
              </h3>
              <p className="text-muted-foreground">
                Our concierge team is coordinating all the details
              </p>
            </div>
          </div>
        ) : (
          <PlanMyNight onComplete={handleBookingComplete} />
        )}
      </div>
    </div>
  );
}