import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon, Clock, MapPin, Star, Wine, Music, Heart, Camera } from "lucide-react";
import { format } from "date-fns";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

const hotelBookingSchema = z.object({
  hotelName: z.string().min(1, "Hotel name is required"),
  hotelConfirmationNumber: z.string().min(1, "Confirmation number is required"),
  guestName: z.string().min(1, "Guest name is required"),
  guestEmail: z.string().email("Valid email is required"),
  guestPhone: z.string().min(1, "Phone number is required"),
  roomNumber: z.string().min(1, "Room number is required"),
  checkInDate: z.date(),
  checkOutDate: z.date(),
  startDate: z.date(),
  startTime: z.string().min(1, "Start time is required"),
  endDate: z.date(),
  endTime: z.string().min(1, "End time is required"),
  numberOfChildren: z.number().min(1, "At least 1 child is required"),
  childrenAges: z.string().min(1, "Children ages are required"),
  specialRequests: z.string().optional(),
  emergencyContact: z.string().min(1, "Emergency contact is required"),
  // Standard add-ons
  booksActivitiesKit: z.boolean().default(false),
});

type HotelBookingForm = z.infer<typeof hotelBookingSchema>;

export default function BookHotelSitter() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showCalendar, setShowCalendar] = useState<'start' | 'end' | null>(null);
  const { toast } = useToast();

  const form = useForm<HotelBookingForm>({
    resolver: zodResolver(hotelBookingSchema),
    defaultValues: {
      numberOfChildren: 1,
      booksActivitiesKit: false,
    },
  });

  const watchedValues = form.watch();

  const calculateCost = () => {
    const hourlyRate = 28;
    
    // Check if all required fields are filled
    if (!watchedValues.startDate || !watchedValues.endDate || !watchedValues.startTime || !watchedValues.endTime) {
      return { 
        hours: 0, 
        totalCost: 0,
        baseRate: hourlyRate,
        extraChildrenCost: 0
      };
    }
    
    const startDateTime = new Date(`${format(watchedValues.startDate, 'yyyy-MM-dd')}T${watchedValues.startTime}`);
    const endDateTime = new Date(`${format(watchedValues.endDate, 'yyyy-MM-dd')}T${watchedValues.endTime}`);
    
    // Calculate hours with minimum 2 hour booking
    let hoursCalc = (endDateTime.getTime() - startDateTime.getTime()) / (1000 * 60 * 60);
    
    // Handle negative time (end time before start time)
    if (hoursCalc <= 0) {
      return { 
        hours: 0, 
        totalCost: 0,
        baseRate: hourlyRate,
        extraChildrenCost: 0
      };
    }
    
    hoursCalc = Math.max(2, hoursCalc); // Minimum 2 hours
    
    // Base cost calculation
    let totalCostCalc = hourlyRate * hoursCalc;
    
    // Extra children cost ($8/hour per additional child)
    const extraChildren = Math.max(0, (watchedValues.numberOfChildren || 1) - 1);
    if (extraChildren > 0) {
      totalCostCalc += extraChildren * 8 * hoursCalc;
    }
    
    // Standard add-ons
    if (watchedValues.booksActivitiesKit) {
      totalCostCalc += 15;
    }
    
    return { 
      hours: Math.round(hoursCalc * 10) / 10, 
      totalCost: Math.round(totalCostCalc * 100) / 100,
      baseRate: hourlyRate,
      extraChildrenCost: extraChildren * 8 * hoursCalc
    };
  };

  // Calculate cost in real-time based on form values
  const { hours, totalCost, baseRate, extraChildrenCost } = calculateCost();

  const onSubmit = async (data: HotelBookingForm) => {
    setIsSubmitting(true);
    try {
      const { hours: submitHours, totalCost: submitTotalCost } = calculateCost();
      
      const hotelBookingData = {
        ...data,
        totalHours: submitHours,
        totalCost: submitTotalCost,
        status: 'pending',
        createdAt: new Date(),
      };

      await apiRequest("POST", "/api/hotel-bookings", hotelBookingData);
      
      toast({
        title: "Hotel Booking Submitted",
        description: "Your hotel babysitting request has been submitted. Our team will contact you within 30 minutes to confirm details.",
      });
      
      form.reset();
    } catch (error) {
      console.error("Submit hotel booking error:", error);
      toast({
        title: "Booking Failed",
        description: "There was an error submitting your booking. Please try again or call us directly.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#eae1d6] to-white">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Header */}
        <div className="text-center mb-8">
          <Badge variant="secondary" className="mb-4 bg-[#ebd3cb] text-[#6b3e4b] border-[#92836c]">
            Hotel Concierge Service
          </Badge>
          <h1 className="text-3xl md:text-4xl font-bold text-[#6b3e4b] mb-4">
            Book Hotel Babysitting
          </h1>
          <p className="text-lg text-gray-700 mb-6">
            Professional childcare for hotel guests with luxury concierge add-ons
          </p>
          <Link href="/hotels">
            <Button variant="outline" className="border-[#6b3e4b] text-[#6b3e4b] hover:bg-[#6b3e4b] hover:text-white">
              ← Back to Hotel Services
            </Button>
          </Link>
        </div>

        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          {/* Hotel Details */}
          <Card className="border-[#ebd3cb] shadow-lg">
            <CardHeader>
              <CardTitle className="text-[#6b3e4b] flex items-center gap-2">
                <MapPin className="w-5 h-5" />
                Hotel Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="hotelName">Hotel Name</Label>
                  <Input
                    id="hotelName"
                    {...form.register("hotelName")}
                    placeholder="e.g. The Heritage Auckland"
                  />
                  {form.formState.errors.hotelName && (
                    <p className="text-red-500 text-sm mt-1">{form.formState.errors.hotelName.message}</p>
                  )}
                </div>
                <div>
                  <Label htmlFor="hotelConfirmationNumber">Confirmation Number</Label>
                  <Input
                    id="hotelConfirmationNumber"
                    {...form.register("hotelConfirmationNumber")}
                    placeholder="Hotel booking confirmation"
                  />
                  {form.formState.errors.hotelConfirmationNumber && (
                    <p className="text-red-500 text-sm mt-1">{form.formState.errors.hotelConfirmationNumber.message}</p>
                  )}
                </div>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="roomNumber">Room Number</Label>
                  <Input
                    id="roomNumber"
                    {...form.register("roomNumber")}
                    placeholder="e.g. 1205"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <Label>Check-in Date</Label>
                    <Popover open={showCalendar === 'start'} onOpenChange={(open) => setShowCalendar(open ? 'start' : null)}>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="w-full justify-start text-left font-normal">
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {watchedValues.checkInDate ? format(watchedValues.checkInDate, "MMM dd") : "Select"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={watchedValues.checkInDate}
                          onSelect={(date) => {
                            form.setValue("checkInDate", date!);
                            setShowCalendar(null);
                          }}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                  <div>
                    <Label>Check-out Date</Label>
                    <Popover open={showCalendar === 'end'} onOpenChange={(open) => setShowCalendar(open ? 'end' : null)}>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="w-full justify-start text-left font-normal">
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {watchedValues.checkOutDate ? format(watchedValues.checkOutDate, "MMM dd") : "Select"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={watchedValues.checkOutDate}
                          onSelect={(date) => {
                            form.setValue("checkOutDate", date!);
                            setShowCalendar(null);
                          }}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Guest Information */}
          <Card className="border-[#ebd3cb] shadow-lg">
            <CardHeader>
              <CardTitle className="text-[#6b3e4b]">Contact Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="guestName">Full Name</Label>
                  <Input
                    id="guestName"
                    {...form.register("guestName")}
                    placeholder="Primary guest name"
                  />
                </div>
                <div>
                  <Label htmlFor="guestEmail">Email</Label>
                  <Input
                    id="guestEmail"
                    type="email"
                    {...form.register("guestEmail")}
                    placeholder="your.email@example.com"
                  />
                </div>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="guestPhone">Phone Number</Label>
                  <Input
                    id="guestPhone"
                    {...form.register("guestPhone")}
                    placeholder="+64 21 123 4567"
                  />
                </div>
                <div>
                  <Label htmlFor="emergencyContact">Emergency Contact</Label>
                  <Input
                    id="emergencyContact"
                    {...form.register("emergencyContact")}
                    placeholder="Name and phone number"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Babysitting Details */}
          <Card className="border-[#ebd3cb] shadow-lg">
            <CardHeader>
              <CardTitle className="text-[#6b3e4b] flex items-center gap-2">
                <Clock className="w-5 h-5" />
                Babysitting Schedule
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label>Start Date & Time</Label>
                  <div className="flex gap-2">
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="flex-1 justify-start text-left font-normal">
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {watchedValues.startDate ? format(watchedValues.startDate, "MMM dd") : "Date"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={watchedValues.startDate}
                          onSelect={(date) => form.setValue("startDate", date!)}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <Input
                      type="time"
                      {...form.register("startTime")}
                      className="w-32"
                    />
                  </div>
                </div>
                <div>
                  <Label>End Date & Time</Label>
                  <div className="flex gap-2">
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="flex-1 justify-start text-left font-normal">
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {watchedValues.endDate ? format(watchedValues.endDate, "MMM dd") : "Date"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={watchedValues.endDate}
                          onSelect={(date) => form.setValue("endDate", date!)}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                    <Input
                      type="time"
                      {...form.register("endTime")}
                      className="w-32"
                    />
                  </div>
                </div>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="numberOfChildren">Number of Children</Label>
                  <Input
                    id="numberOfChildren"
                    type="number"
                    min="1"
                    {...form.register("numberOfChildren", { valueAsNumber: true })}
                  />
                </div>
                <div>
                  <Label htmlFor="childrenAges">Children's Ages</Label>
                  <Input
                    id="childrenAges"
                    {...form.register("childrenAges")}
                    placeholder="e.g. 3, 7, 10"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="specialRequests">Special Requests</Label>
                <Textarea
                  id="specialRequests"
                  {...form.register("specialRequests")}
                  placeholder="Any specific needs, allergies, or special instructions"
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          {/* Standard Add-Ons */}
          <Card className="border-[#ebd3cb] shadow-lg">
            <CardHeader>
              <CardTitle className="text-[#6b3e4b] flex items-center gap-2">
                <Star className="w-5 h-5" />
                Standard Add-Ons
              </CardTitle>
              <CardDescription>Enhance your children's experience</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="booksActivitiesKit"
                    checked={watchedValues.booksActivitiesKit}
                    onCheckedChange={(checked) => form.setValue("booksActivitiesKit", !!checked)}
                  />
                  <Label htmlFor="booksActivitiesKit" className="flex-1">
                    Books & Activities Kit (+$15)
                  </Label>
                </div>
              </div>
            </CardContent>
          </Card>



          {/* Cost Summary */}
          <Card className="border-[#6b3e4b] shadow-lg bg-[#eae1d6]">
            <CardHeader>
              <CardTitle className="text-[#6b3e4b]">Booking Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Date:</span>
                  <span className="font-semibold">
                    {watchedValues.startDate ? format(watchedValues.startDate, 'MMM d, yyyy') : 'Not selected'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Time:</span>
                  <span className="font-semibold">
                    {watchedValues.startTime || 'Not selected'} - {watchedValues.endTime || 'Not selected'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Duration:</span>
                  <span className="font-semibold">{hours > 0 ? `${hours} hours` : 'Not calculated'}</span>
                </div>
                <div className="flex justify-between">
                  <span>Children:</span>
                  <span className="font-semibold">{watchedValues.numberOfChildren}</span>
                </div>
                {watchedValues.booksActivitiesKit && (
                  <div className="flex justify-between text-sm">
                    <span>Books & Activities Kit:</span>
                    <span className="font-semibold">+$15</span>
                  </div>
                )}
                <div className="border-t border-[#92836c] pt-2 flex justify-between text-lg">
                  <span className="font-semibold">Total Cost:</span>
                  <span className="font-bold text-[#6b3e4b]">{totalCost > 0 ? `$${totalCost}` : 'Not calculated'}</span>
                </div>
                <p className="text-sm text-gray-600 mt-2">
                  Payment is processed upon confirmation. Cancellation policy applies.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Submit */}
          <div className="text-center">
            <Button
              type="submit"
              size="lg"
              disabled={isSubmitting}
              className="bg-[#6b3e4b] hover:bg-[#5a3340] text-white px-12 py-4 text-lg"
            >
              {isSubmitting ? "Submitting..." : "Submit Booking Request"}
            </Button>
            <p className="text-sm text-gray-600 mt-3">
              Our team will contact you within 30 minutes to confirm details and process payment.
            </p>
          </div>
        </form>
      </div>
    </div>
  );
}