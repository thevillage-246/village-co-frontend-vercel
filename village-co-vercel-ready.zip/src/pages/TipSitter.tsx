import React, { useState } from 'react';
import { useParams } from 'wouter';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Heart, DollarSign, Star, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { formatAucklandTime } from '@/utils/timezone';

const TipSitter: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const bookingId = parseInt(id!);
  const [selectedAmount, setSelectedAmount] = useState<number | null>(null);
  const [customAmount, setCustomAmount] = useState('');
  const [message, setMessage] = useState('');
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: booking, isLoading } = useQuery({
    queryKey: [`/api/bookings/${bookingId}`],
    enabled: !!bookingId,
  });

  const tipMutation = useMutation({
    mutationFn: async (data: { amount: number; message?: string }) => {
      return apiRequest('POST', `/api/bookings/${bookingId}/tip`, data);
    },
    onSuccess: () => {
      toast({
        title: "Tip Sent Successfully! 💖",
        description: "Your sitter will receive 100% of the tip. Thank you for your kindness!",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/bookings/${bookingId}`] });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to Send Tip",
        description: error.message || "Please try again or contact support.",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#F9F5F0] flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-4 border-[#6B3E4B] border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!booking) {
    return (
      <div className="min-h-screen bg-[#F9F5F0] p-4">
        <div className="max-w-md mx-auto pt-20">
          <Card className="shadow-lg">
            <CardContent className="p-8 text-center">
              <AlertCircle className="h-12 w-12 text-[#6B3E4B] mx-auto mb-4" />
              <h2 className="text-xl font-semibold mb-2">Booking Not Found</h2>
              <p className="text-muted-foreground">This booking could not be found.</p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const quickTipAmounts = [5, 10, 20, 30];
  
  const getSelectedAmount = () => {
    if (selectedAmount === -1) {
      const custom = parseFloat(customAmount);
      return isNaN(custom) ? 0 : custom;
    }
    return selectedAmount || 0;
  };

  const handleTipSubmit = () => {
    const amount = getSelectedAmount();
    if (amount <= 0) {
      toast({
        title: "Please select an amount",
        description: "Choose a tip amount to continue.",
        variant: "destructive",
      });
      return;
    }

    tipMutation.mutate({
      amount,
      message: message.trim() || undefined
    });
  };

  const startTime = booking.startTime ? formatAucklandTime(new Date(booking.startTime), 'h:mm a') : 'Unknown';
  const endTime = booking.endTime ? formatAucklandTime(new Date(booking.endTime), 'h:mm a') : 'Unknown';

  return (
    <div className="min-h-screen bg-[#F9F5F0] p-4">
      <div className="max-w-2xl mx-auto pt-8">
        <Card className="shadow-lg">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 p-4 bg-[#6B3E4B]/10 rounded-full w-fit">
              <Heart className="h-8 w-8 text-[#6B3E4B]" />
            </div>
            <CardTitle className="text-2xl text-[#6B3E4B] font-satoshi">
              Show Some Love 💖
            </CardTitle>
            <CardDescription className="text-lg">
              Add a tip for {booking.sitterName} — 100% goes straight to them
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Booking summary */}
            <div className="bg-[#F9F5F0] rounded-xl p-4">
              <h3 className="font-semibold text-[#6B3E4B] mb-2 flex items-center">
                <Star className="h-5 w-5 mr-1" />
                Recent Booking
              </h3>
              <div className="space-y-1 text-sm">
                <p><strong>Sitter:</strong> {booking.sitterName}</p>
                <p><strong>Date:</strong> {startTime} - {endTime}</p>
                <p><strong>Duration:</strong> {booking.duration} minutes</p>
              </div>
            </div>

            {/* Quick tip amounts */}
            <div>
              <h3 className="font-semibold text-[#6B3E4B] mb-4">Choose an amount</h3>
              <div className="grid grid-cols-2 gap-3">
                {quickTipAmounts.map((amount) => (
                  <button
                    key={amount}
                    onClick={() => {
                      setSelectedAmount(amount);
                      setCustomAmount('');
                    }}
                    className={`p-4 rounded-xl border-2 transition-all ${
                      selectedAmount === amount
                        ? 'border-[#6B3E4B] bg-[#6B3E4B]/5'
                        : 'border-gray-200 hover:border-[#6B3E4B]/50'
                    }`}
                  >
                    <div className="text-center">
                      <div className="flex items-center justify-center mb-1">
                        <DollarSign className="h-5 w-5 text-[#6B3E4B]" />
                        <span className="text-xl font-bold">{amount}</span>
                      </div>
                      <div className="text-sm text-gray-600">Great tip!</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Custom amount */}
            <div>
              <h3 className="font-semibold text-[#6B3E4B] mb-3">Or enter a custom amount</h3>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <Input
                  type="number"
                  placeholder="0.00"
                  value={customAmount}
                  onChange={(e) => {
                    setCustomAmount(e.target.value);
                    setSelectedAmount(-1);
                  }}
                  className="pl-10 text-lg"
                  min="0"
                  step="0.01"
                />
              </div>
            </div>

            {/* Optional message */}
            <div>
              <h3 className="font-semibold text-[#6B3E4B] mb-3">Add a message (optional)</h3>
              <textarea
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Thank you for taking such great care of the kids! ✨"
                className="w-full p-3 border border-gray-200 rounded-xl resize-none focus:outline-none focus:ring-2 focus:ring-[#6B3E4B]/20 focus:border-[#6B3E4B]"
                rows={3}
                maxLength={200}
              />
              <div className="text-sm text-gray-500 mt-1">{message.length}/200 characters</div>
            </div>

            {/* Total display */}
            {getSelectedAmount() > 0 && (
              <div className="bg-white rounded-xl border-2 border-[#6B3E4B]/20 p-4">
                <h3 className="font-semibold text-[#6B3E4B] mb-2">Tip Summary</h3>
                <div className="flex justify-between items-center text-lg">
                  <span>Tip amount:</span>
                  <span className="font-bold text-[#6B3E4B]">${getSelectedAmount().toFixed(2)}</span>
                </div>
                <div className="text-sm text-gray-600 mt-2">
                  100% goes to {booking.sitterName} ✨
                </div>
              </div>
            )}

            {/* Action buttons */}
            <div className="flex gap-3">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => window.history.back()}
              >
                Maybe Later
              </Button>
              <Button
                className="flex-1 bg-[#6B3E4B] hover:bg-[#6B3E4B]/90"
                disabled={getSelectedAmount() <= 0 || tipMutation.isPending}
                onClick={handleTipSubmit}
              >
                {tipMutation.isPending ? 'Processing...' : `Send $${getSelectedAmount().toFixed(2)} Tip`}
              </Button>
            </div>

            {/* Info note */}
            <div className="bg-green-50 rounded-xl p-4">
              <div className="flex items-start">
                <Heart className="h-5 w-5 text-green-600 mr-2 mt-0.5 flex-shrink-0" />
                <div className="text-sm text-green-800">
                  <p className="font-medium mb-1">Tips make a difference</p>
                  <p>Your tip shows appreciation for great care and helps support our sitters. Tips are processed securely and 100% goes to your sitter.</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default TipSitter;