import React, { useState, useEffect } from 'react';
import { useParams, useLocation } from 'wouter';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useAuth } from '@/contexts/AuthContext';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { USER_ROLES } from '@shared/schema';
import { z } from 'zod';

import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { User, Upload, Briefcase, Star, Users, Clock, DollarSign, Shield, ChevronLeft, CheckCircle, Award, Heart, MapPin, Car, GraduationCap } from 'lucide-react';
import { SearchableSchoolSelect } from '@/components/ui/searchable-school-select';
import PhoneNumberVerification from '@/components/profile/PhoneNumberVerification';
import IDVerification from '@/components/profile/IDVerification';
import QualificationChecklist from '@/components/profile/QualificationChecklist';

// Form schemas
const parentProfileSchema = z.object({
  address: z.string().min(1, 'Address is required'),
  phoneNumber: z.string().min(10, 'Valid phone number is required'),
  emergencyContactName: z.string().min(1, 'Emergency contact name is required'),
  emergencyContactPhone: z.string().min(10, 'Valid phone number is required'),
});

const sitterProfileSchema = z.object({
  bio: z.string().min(10, 'Bio must be at least 10 characters'),
  experience: z.string().min(10, 'Experience must be at least 10 characters'),
  hourlyRate: z.string().min(1, 'Hourly rate is required')
    .refine(val => !isNaN(parseFloat(val)), {
      message: 'Hourly rate must be a valid number',
    })
    .refine(val => parseFloat(val) >= 10, {
      message: 'Hourly rate must be at least $10.00',
    }),
});

const childSchema = z.object({
  firstName: z.string().min(1, 'First name is required'),
  lastName: z.string().min(1, 'Last name is required'),
  birthDate: z.string().optional(),
  allergies: z.string().optional(),
  specialNeeds: z.string().optional(),
  notes: z.string().optional(),
  schoolOrDaycare: z.string().optional(),
});

const Profile: React.FC = () => {
  const { id } = useParams();
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('profile');
  const [addingChild, setAddingChild] = useState(false);

  const canEdit = user?.id.toString() === id;
  
  // User data - try public sitter profile first if not authenticated or if accessing someone else's profile
  const shouldFetchUser = Boolean(id && canEdit);
  const { data: profileUser, isLoading: loadingUser } = useQuery({
    queryKey: [`/api/users/${id}`],
    enabled: shouldFetchUser, // Only fetch user data if we can edit (viewing own profile)
  });

  // For sitter profiles, try to get public sitter data
  const shouldFetchPublicSitters = Boolean(id && !canEdit);
  const { data: publicSitter, isLoading: loadingPublicSitter } = useQuery({
    queryKey: [`/api/sitters/public`],
    select: (data) => {
      // Find the sitter with matching userId
      return Array.isArray(data) ? data.find((s: any) => s.userId.toString() === id) : null;
    },
    enabled: shouldFetchPublicSitters, // Only fetch public data if viewing someone else's profile
  });

  // Fetch parent profile if user is a parent
  const shouldFetchParentProfile = Boolean(id && profileUser?.role === USER_ROLES.PARENT);
  const { data: parentProfile, isLoading: loadingParentProfile } = useQuery({
    queryKey: [`/api/parents/${id}/profile`],
    enabled: shouldFetchParentProfile,
  });

  // Fetch sitter profile if user is a sitter
  const shouldFetchSitterProfile = Boolean(id && (profileUser?.role === USER_ROLES.SITTER || publicSitter));
  const { data: sitterProfile, isLoading: loadingSitterProfile } = useQuery({
    queryKey: [`/api/sitters/${id}/profile`],
    enabled: shouldFetchSitterProfile,
  });

  // Fetch children if user is a parent
  const shouldFetchChildren = Boolean(id && profileUser?.role === USER_ROLES.PARENT);
  const { data: children, isLoading: loadingChildren } = useQuery({
    queryKey: [`/api/parents/${id}/children`],
    enabled: shouldFetchChildren,
  });

  // Fetch reviews if user is a sitter
  const shouldFetchReviews = Boolean(id && (profileUser?.role === USER_ROLES.SITTER || publicSitter));
  const { data: reviews, isLoading: loadingReviews } = useQuery({
    queryKey: [`/api/sitters/${id}/reviews`],
    enabled: shouldFetchReviews,
  });

  // Fetch schools for dropdown
  const { data: schools } = useQuery({
    queryKey: ['/api/schools'],
  });

  // Forms
  const parentProfileForm = useForm<z.infer<typeof parentProfileSchema>>({
    resolver: zodResolver(parentProfileSchema),
    defaultValues: {
      address: parentProfile?.address || '',
      phoneNumber: parentProfile?.phoneNumber || '',
      emergencyContactName: parentProfile?.emergencyContactName || '',
      emergencyContactPhone: parentProfile?.emergencyContactPhone || '',
    },
  });

  const sitterProfileForm = useForm<z.infer<typeof sitterProfileSchema>>({
    resolver: zodResolver(sitterProfileSchema),
    defaultValues: {
      bio: sitterProfile?.bio || '',
      experience: sitterProfile?.experience || '',
      hourlyRate: sitterProfile?.hourly_rate || '',
    },
  });

  const childForm = useForm<z.infer<typeof childSchema>>({
    resolver: zodResolver(childSchema),
    defaultValues: {
      firstName: '',
      lastName: '',
      birthDate: '',
      allergies: '',
      specialNeeds: '',
      notes: '',
      schoolOrDaycare: '',
    },
  });

  // Update parent profile when data loads
  useEffect(() => {
    if (parentProfile) {
      parentProfileForm.reset({
        address: parentProfile.address || '',
        phoneNumber: parentProfile.phoneNumber || '',
        emergencyContactName: parentProfile.emergencyContactName || '',
        emergencyContactPhone: parentProfile.emergencyContactPhone || '',
      });
    }
  }, [parentProfile, parentProfileForm]);

  // Update sitter profile when data loads
  useEffect(() => {
    if (sitterProfile) {
      sitterProfileForm.reset({
        bio: sitterProfile.bio || '',
        experience: sitterProfile.experience || '',
        hourlyRate: sitterProfile.hourly_rate || '',
      });
    }
  }, [sitterProfile, sitterProfileForm]);

  // Mutations
  const updateParentProfile = useMutation({
    mutationFn: async (data: z.infer<typeof parentProfileSchema>) => {
      if (!parentProfile) {
        // Create new profile
        await apiRequest('POST', `/api/parents`, {
          userId: user?.id,
          ...data,
        });
      } else {
        // Update existing profile
        await apiRequest('PATCH', `/api/parents/${parentProfile.id}`, data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/parents/${id}/profile`] });
      toast({
        title: 'Profile Updated',
        description: 'Your parent profile has been updated successfully.',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Update Failed',
        description: error.message || 'Failed to update profile',
        variant: 'destructive',
      });
    },
  });

  const updateSitterProfile = useMutation({
    mutationFn: async (data: z.infer<typeof sitterProfileSchema>) => {
      // Map frontend fields to backend schema
      const formattedData = {
        bio: data.bio,
        experience: data.experience,
        hourly_rate: data.hourlyRate, // Map hourlyRate to hourly_rate and keep as text
        // Only include fields that exist in the database schema
      };

      if (!sitterProfile) {
        // Create new profile using the correct endpoint
        await apiRequest('POST', `/api/sitters/${user?.id}/profile`, formattedData);
      } else {
        // Update existing profile using the correct PATCH endpoint
        await apiRequest('PATCH', `/api/sitters/${sitterProfile.id}/profile`, formattedData);
      }
    },
    onSuccess: () => {
      // Invalidate both the profile query and any related queries
      queryClient.invalidateQueries({ queryKey: [`/api/sitters/${id}/profile`] });
      queryClient.invalidateQueries({ queryKey: [`/api/users/${id}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/sitters/public`] });
      
      toast({
        title: 'Profile Saved Successfully',
        description: 'Your sitter profile has been saved successfully.',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Update Failed',
        description: error.message || 'Failed to update profile',
        variant: 'destructive',
      });
    },
  });

  const addChild = useMutation({
    mutationFn: async (data: z.infer<typeof childSchema>) => {
      const formattedData = {
        ...data,
        schoolOrDaycare: data.schoolOrDaycare === 'none' ? null : data.schoolOrDaycare,
      };
      await apiRequest('POST', `/api/parents/${parentProfile?.id}/children`, formattedData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/parents/${id}/children`] });
      childForm.reset();
      setAddingChild(false);
      toast({
        title: 'Child Added',
        description: 'Child has been added to your profile.',
      });
    },
    onError: (error: any) => {
      toast({
        title: 'Failed to Add Child',
        description: error.message || 'An error occurred while adding child',
        variant: 'destructive',
      });
    },
  });

  const onSubmitParentProfile = (data: z.infer<typeof parentProfileSchema>) => {
    updateParentProfile.mutate(data);
  };

  const onSubmitSitterProfile = (data: z.infer<typeof sitterProfileSchema>) => {
    updateSitterProfile.mutate(data);
  };

  const onSubmitChild = (data: z.infer<typeof childSchema>) => {
    addChild.mutate(data);
  };

  // Show loading state
  if (loadingUser || 
      (profileUser?.role === USER_ROLES.PARENT && loadingParentProfile) ||
      (profileUser?.role === USER_ROLES.SITTER && loadingSitterProfile)) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  // Format average rating
  const getAverageRating = () => {
    if (!reviews || reviews.length === 0) return 'Not rated yet';
    
    const sum = reviews.reduce((total: number, review: any) => total + review.rating, 0);
    return (sum / reviews.length).toFixed(1);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <Button
        variant="ghost"
        className="mb-6"
        onClick={() => navigate('/')}
      >
        <ChevronLeft className="mr-2 h-4 w-4" />
        Back
      </Button>

      <div className="flex flex-col md:flex-row gap-6">
        {/* Sidebar with user info */}
        <div className="w-full md:w-1/3 lg:w-1/4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex flex-col items-center text-center">
                <Avatar className="h-24 w-24 mb-4">
                  <AvatarImage src={profileUser?.profileImage} />
                  <AvatarFallback className="text-2xl">
                    {(profileUser?.firstName || publicSitter?.firstName)?.charAt(0)}{(profileUser?.lastName || publicSitter?.lastName)?.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <h2 className="text-xl font-bold mb-1">
                  {(profileUser?.firstName || publicSitter?.firstName || 'User')} {(profileUser?.lastName || publicSitter?.lastName || '')}
                </h2>
                <p className="text-muted-foreground text-sm mb-2">{profileUser?.email || ''}</p>
                <div className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary/10 text-primary mb-4">
                  {profileUser?.role || (publicSitter ? 'sitter' : 'user')}
                </div>

                {(profileUser?.role === USER_ROLES.SITTER || publicSitter) && (
                  <div className="w-full space-y-4">
                    {/* Verification Badges */}
                    <div className="space-y-2">
                      <h3 className="text-sm font-semibold text-muted-foreground mb-2">Trust & Safety</h3>
                      <div className="flex flex-wrap gap-1.5">
                        <div className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          ID Verified
                        </div>
                        <div className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                          <Shield className="w-3 h-3 mr-1" />
                          Background Check
                        </div>
                        <div className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">
                          <Heart className="w-3 h-3 mr-1" />
                          First Aid
                        </div>
                        {sitterProfile?.approved && (
                          <div className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
                            <Award className="w-3 h-3 mr-1" />
                            Village Verified
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Rating and Rate Card */}
                    <div className="bg-gradient-to-r from-village-wine/10 to-brushed-pink/30 rounded-lg p-4 border border-village-wine/30 shadow-sm">
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm font-medium text-village-wine">Rating</span>
                        <div className="flex items-center">
                          <span className="text-lg font-bold text-village-wine mr-1">{getAverageRating()}</span>
                          <Star className="h-4 w-4 text-yellow-400" fill="currentColor" />
                        </div>
                      </div>
                      {sitterProfile?.hourlyRate && (
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium text-village-wine">Rate</span>
                          <span className="text-lg font-bold text-village-wine">
                            {parseFloat(sitterProfile.hourlyRate).toLocaleString('en-NZ', { style: 'currency', currency: 'NZD' })}/hr
                          </span>
                        </div>
                      )}
                    </div>

                    {/* Qualifications */}
                    {sitterProfile?.qualifications && (
                      <div className="space-y-2">
                        <h3 className="text-sm font-semibold text-muted-foreground">Qualifications</h3>
                        <div className="flex flex-wrap gap-1.5">
                          {sitterProfile.qualifications.split(',').map((qual: string, index: number) => (
                            <div key={index} className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                              <Award className="w-3 h-3 mr-1" />
                              {qual.trim()}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}


                  </div>
                )}

                {canEdit && (
                  <Button variant="outline" className="w-full mt-4" onClick={() => {}}>
                    <Upload className="h-4 w-4 mr-2" />
                    Change Photo
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main content area */}
        <div className="w-full md:w-2/3 lg:w-3/4">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="profile">Profile</TabsTrigger>
              {profileUser?.role === USER_ROLES.PARENT ? (
                <TabsTrigger value="children">Children</TabsTrigger>
              ) : (
                <TabsTrigger value="reviews">Reviews</TabsTrigger>
              )}
            </TabsList>

            {/* Profile Tab */}
            <TabsContent value="profile" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Profile Information</CardTitle>
                  <CardDescription>
                    {canEdit 
                      ? 'Update your profile information' 
                      : `View ${(profileUser?.firstName || publicSitter?.firstName || 'user')}'s profile information`}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {profileUser?.role === USER_ROLES.PARENT ? (
                    <Form {...parentProfileForm}>
                      <form onSubmit={parentProfileForm.handleSubmit(onSubmitParentProfile)} className="space-y-6">
                        <FormField
                          control={parentProfileForm.control}
                          name="address"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Address</FormLabel>
                              <FormControl>
                                <Input placeholder="Your address" {...field} disabled={!canEdit} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={parentProfileForm.control}
                          name="phoneNumber"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Phone Number</FormLabel>
                              <FormControl>
                                <Input placeholder="Your phone number" {...field} disabled={!canEdit} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <Separator className="my-6" />
                        <h3 className="text-lg font-medium mb-4">Emergency Contact</h3>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={parentProfileForm.control}
                            name="emergencyContactName"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Emergency Contact Name</FormLabel>
                                <FormControl>
                                  <Input placeholder="Emergency contact name" {...field} disabled={!canEdit} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={parentProfileForm.control}
                            name="emergencyContactPhone"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Emergency Contact Phone</FormLabel>
                                <FormControl>
                                  <Input placeholder="Emergency contact phone" {...field} disabled={!canEdit} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        {canEdit && (
                          <Button 
                            type="submit" 
                            className="w-full md:w-auto" 
                            disabled={updateParentProfile.isPending}
                          >
                            {updateParentProfile.isPending ? 'Saving...' : 'Save Changes'}
                          </Button>
                        )}
                      </form>
                    </Form>
                  ) : (
                    <Form {...sitterProfileForm}>
                      <form onSubmit={sitterProfileForm.handleSubmit(onSubmitSitterProfile)} className="space-y-6">
                        <FormField
                          control={sitterProfileForm.control}
                          name="bio"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Bio</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="Tell parents about yourself" 
                                  {...field} 
                                  disabled={!canEdit}
                                  className="min-h-[120px]" 
                                />
                              </FormControl>

                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={sitterProfileForm.control}
                          name="experience"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Experience</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="Your experience with childcare" 
                                  {...field} 
                                  disabled={!canEdit}
                                  className="min-h-[100px]" 
                                />
                              </FormControl>

                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <FormField
                            control={sitterProfileForm.control}
                            name="hourlyRate"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Hourly Rate (NZD)</FormLabel>
                                <FormControl>
                                  <div className="relative">
                                    <span className="absolute left-3 top-3">$</span>
                                    <Input 
                                      type="number" 
                                      step="0.01" 
                                      min="10" 
                                      className="pl-7" 
                                      {...field} 
                                      disabled={!canEdit} 
                                    />
                                  </div>
                                </FormControl>

                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                        </div>
                        

                        
                        {canEdit && (
                          <Button 
                            type="submit" 
                            className="w-full md:w-auto" 
                            disabled={updateSitterProfile.isPending}
                          >
                            {updateSitterProfile.isPending ? 'Saving...' : 'Save Changes'}
                          </Button>
                        )}
                      </form>
                    </Form>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Children Tab (for Parents) */}
            {profileUser?.role === USER_ROLES.PARENT && (
              <TabsContent value="children" className="mt-6 space-y-6">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-bold">Children</h2>
                  {canEdit && !addingChild && (
                    <Button onClick={() => setAddingChild(true)}>
                      Add Child
                    </Button>
                  )}
                </div>

                {/* Add Child Form */}
                {canEdit && addingChild && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Add New Child</CardTitle>
                      <CardDescription>
                        Add information about your child
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Form {...childForm}>
                        <form onSubmit={childForm.handleSubmit(onSubmitChild)} className="space-y-6">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <FormField
                              control={childForm.control}
                              name="firstName"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>First Name</FormLabel>
                                  <FormControl>
                                    <Input placeholder="First name" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                            
                            <FormField
                              control={childForm.control}
                              name="lastName"
                              render={({ field }) => (
                                <FormItem>
                                  <FormLabel>Last Name</FormLabel>
                                  <FormControl>
                                    <Input placeholder="Last name" {...field} />
                                  </FormControl>
                                  <FormMessage />
                                </FormItem>
                              )}
                            />
                          </div>
                          
                          <FormField
                            control={childForm.control}
                            name="birthDate"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Birth Date</FormLabel>
                                <FormControl>
                                  <Input type="date" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={childForm.control}
                            name="allergies"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Allergies</FormLabel>
                                <FormControl>
                                  <Input placeholder="List allergies (if any)" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={childForm.control}
                            name="specialNeeds"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Special Needs</FormLabel>
                                <FormControl>
                                  <Input placeholder="Any special needs or requirements" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={childForm.control}
                            name="schoolOrDaycare"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>School or Daycare</FormLabel>
                                <FormControl>
                                  <SearchableSchoolSelect
                                    value={field.value || ""}
                                    onChange={field.onChange}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <FormField
                            control={childForm.control}
                            name="notes"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Additional Notes</FormLabel>
                                <FormControl>
                                  <Textarea 
                                    placeholder="Any other important information" 
                                    {...field} 
                                    className="min-h-[80px]" 
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          
                          <div className="flex justify-end space-x-4">
                            <Button 
                              variant="outline" 
                              type="button" 
                              onClick={() => setAddingChild(false)}
                            >
                              Cancel
                            </Button>
                            <Button 
                              type="submit" 
                              disabled={addChild.isPending}
                            >
                              {addChild.isPending ? 'Adding...' : 'Add Child'}
                            </Button>
                          </div>
                        </form>
                      </Form>
                    </CardContent>
                  </Card>
                )}

                {!loadingChildren && (
                  <>
                    {children && children.length > 0 ? (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {children.map((child: any) => (
                          <Card key={child.id}>
                            <CardHeader className="pb-2">
                              <CardTitle className="text-lg">{child.firstName} {child.lastName}</CardTitle>
                              {child.birthDate && (
                                <CardDescription>
                                  Birth Date: {new Date(child.birthDate).toLocaleDateString()}
                                </CardDescription>
                              )}
                            </CardHeader>
                            <CardContent>
                              <div className="space-y-2 text-sm">
                                {child.allergies && (
                                  <div>
                                    <span className="font-medium">Allergies:</span> {child.allergies}
                                  </div>
                                )}
                                
                                {child.specialNeeds && (
                                  <div>
                                    <span className="font-medium">Special Needs:</span> {child.specialNeeds}
                                  </div>
                                )}
                                
                                {child.schoolOrDaycare && (
                                  <div className="flex items-center gap-2">
                                    <GraduationCap className="h-4 w-4" />
                                    <span className="font-medium">School/Daycare:</span> {child.schoolOrDaycare}
                                  </div>
                                )}
                                
                                {child.notes && (
                                  <div>
                                    <span className="font-medium">Notes:</span> {child.notes}
                                  </div>
                                )}
                              </div>
                            </CardContent>
                            {canEdit && (
                              <CardFooter className="border-t pt-4">
                                <Button variant="outline" size="sm" className="ml-auto">
                                  Edit
                                </Button>
                              </CardFooter>
                            )}
                          </Card>
                        ))}
                      </div>
                    ) : (
                      <Card>
                        <CardContent className="flex flex-col items-center justify-center py-12">
                          <Users className="h-12 w-12 text-muted-foreground mb-4" />
                          <h3 className="text-lg font-medium mb-2">No Children Added</h3>
                          <p className="text-muted-foreground text-center max-w-md mb-6">
                            {canEdit 
                              ? "You haven't added any children to your profile yet. Add children to make booking easier."
                              : "This parent hasn't added any children to their profile yet."}
                          </p>
                          {canEdit && !addingChild && (
                            <Button onClick={() => setAddingChild(true)}>
                              Add Child
                            </Button>
                          )}
                        </CardContent>
                      </Card>
                    )}
                  </>
                )}
              </TabsContent>
            )}

            {/* Reviews Tab (for Sitters) */}
            {profileUser?.role === USER_ROLES.SITTER && (
              <TabsContent value="reviews" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Reviews</CardTitle>
                    <CardDescription>
                      What parents are saying
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {!loadingReviews && (
                      <>
                        {reviews && reviews.length > 0 ? (
                          <div className="space-y-6">
                            {reviews.map((review: any) => (
                              <div key={review.id} className="border-b pb-4 mb-4 last:border-0">
                                <div className="flex justify-between mb-2">
                                  <div className="flex items-center">
                                    <Avatar className="h-8 w-8 mr-2">
                                      <AvatarFallback className="text-xs">
                                        {review.reviewer?.firstName?.charAt(0)}
                                        {review.reviewer?.lastName?.charAt(0)}
                                      </AvatarFallback>
                                    </Avatar>
                                    <span className="font-medium">
                                      {review.reviewer?.firstName} {review.reviewer?.lastName}
                                    </span>
                                  </div>
                                  <div className="flex items-center">
                                    <span className="font-medium mr-1">{review.rating}</span>
                                    <Star className="h-4 w-4 text-yellow-400" fill="currentColor" />
                                  </div>
                                </div>
                                <p className="text-sm text-muted-foreground">{review.comment}</p>
                                <p className="text-xs text-muted-foreground mt-2">
                                  {new Date(review.createdAt).toLocaleDateString()}
                                </p>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="flex flex-col items-center justify-center py-12">
                            <Star className="h-12 w-12 text-muted-foreground mb-4" />
                            <h3 className="text-lg font-medium mb-2">No Reviews Yet</h3>
                            <p className="text-muted-foreground text-center max-w-md">
                              {profileUser?.firstName} hasn't received any reviews yet. Reviews will appear here after completed bookings.
                            </p>
                          </div>
                        )}
                      </>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            )}
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default Profile;