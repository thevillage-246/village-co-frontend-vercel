import { useLocation } from 'wouter';
import { useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

export default function PostSignupRedirect() {
  const [location, navigate] = useLocation();
  const { toast } = useToast();

  useEffect(() => {
    const checkProfile = async () => {
      try {
        const { data: { user }, error: authError } = await supabase.auth.getUser();
        
        if (authError || !user) {
          toast({
            title: "Authentication Error",
            description: "Please sign in to continue",
            variant: "destructive"
          });
          navigate('/auth');
          return;
        }
        
        const { data: profile, error: profileError } = await supabase
          .from('user_profiles')
          .select('*')
          .eq('user_id', user.id)
          .single();

        if (profileError || !profile) {
          navigate('/onboarding');
        } else {
          if (profile.role === 'parent') {
            navigate('/dashboard');
          } else if (profile.role === 'sitter') {
            navigate('/sitter-dashboard');
          } else {
            navigate('/admin');
          }
        }
      } catch (error) {
        console.error("Error checking profile:", error);
        toast({
          title: "Error",
          description: "Something went wrong. Please try again.",
          variant: "destructive"
        });
      }
    };
    
    checkProfile();
  }, [navigate, toast]);

  return (
    <div className="flex items-center justify-center h-screen">
      <div className="flex flex-col items-center">
        <div className="animate-spin w-10 h-10 border-4 border-primary border-t-transparent rounded-full mb-4"></div>
        <p className="text-lg">Redirecting...</p>
      </div>
    </div>
  );
}