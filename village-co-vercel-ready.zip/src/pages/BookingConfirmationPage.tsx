import React, { useEffect, useState } from 'react';
import { useParams, useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { BookingConfirmation } from '@/components/bookings';
import { queryClient } from '@/lib/queryClient';

export default function BookingConfirmationPage() {
  const params = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const [isLoading, setIsLoading] = useState(true);
  
  // Get booking info from the booking id
  const { data: booking, isLoading: bookingLoading } = useQuery({
    queryKey: ['/api/bookings', params.id],
    enabled: !!params.id,
  });

  useEffect(() => {
    // If booking doesn't exist after loading, redirect to dashboard
    if (!bookingLoading && !booking) {
      navigate('/dashboard');
    } else if (booking) {
      setIsLoading(false);
    }
    
    // Force a refresh of the bookings data when navigating away from this page
    return () => {
      queryClient.invalidateQueries({
        queryKey: ['/api/bookings/upcoming'],
      });
    };
  }, [booking, bookingLoading, navigate]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="animate-spin h-8 w-8 border-4 border-wine border-t-transparent rounded-full"></div>
          <p className="text-muted-foreground">Loading your booking...</p>
        </div>
      </div>
    );
  }

  // Format rate label
  const getSessionLabel = () => {
    const hours = Math.round((new Date(booking.end_time).getTime() - new Date(booking.start_time).getTime()) / 3600000);
    return `${hours} hour${hours !== 1 ? 's' : ''} session`;
  };

  return (
    <BookingConfirmation
      sitterName={booking.sitter.first_name || 'Your Sitter'}
      rateLabel={getSessionLabel()}
      startTime={booking.start_time}
      bookingId={booking.id}
    />
  );
}