import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function Terms() {
  return (
    <div className="container mx-auto py-10 px-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl text-center text-wine">Terms of Service</CardTitle>
        </CardHeader>
        <CardContent className="prose max-w-none">
          <p>Last Updated: May 10, 2025</p>
          
          <h2>1. Acceptance of Terms</h2>
          <p>By accessing or using The Village Co. platform ("the Platform"), you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use the Platform.</p>
          
          <h2>2. Description of Services</h2>
          <p>The Village Co. provides a platform connecting parents with babysitters. The Platform facilitates bookings, payments, and communication between users but does not provide babysitting services directly.</p>
          
          <h2>3. Membership Requirements</h2>
          <p><strong>All Members must:</strong></p>
          <ul>
            <li>be aged 18 and over</li>
            <li>have a valid email address</li>
            <li>have the legal capacity to form a contract with us under law</li>
            <li>not have been convicted of any criminal offence (and in the case of Families, no one in their household has been convicted of any criminal offence), and</li>
            <li>pay the membership fee for the membership tier selected (if applicable).</li>
          </ul>
          
          <p><strong>Sitters must also:</strong> be legally able to work in New Zealand and meet the requirements of our vetting process, which includes an interview by us and submitting documents for us to verify their identity, work experience, references, criminal record and to otherwise assist us in evaluating their suitability to be a Member. Membership will not be active until this process is complete. All Sitter applicants consent to us carrying out checks on such documents and information, including by the use of third parties. Sitters acknowledge their personal information may be displayed on the Platform and visible to other Members (other than address, contact phone number and email).</p>
          
          <h2>4. User Accounts</h2>
          <p>Users must create an account to access the Platform's features. You are responsible for maintaining the confidentiality of your account information and for all activities that occur under your account.</p>
          
          <h2>5. Verification Process</h2>
          <p>Sitters listed on our platform undergo a verification process. However, The Village Co. does not guarantee the conduct of any user and is not responsible for the actions of users.</p>
          
          <h2>5. Booking and Payment Terms</h2>
          <p>All bookings and payments are processed through the Platform. The Village Co. charges a 10% service fee to parents on all bookings and a 5% platform fee to sitters. Users agree not to circumvent the Platform's payment system.</p>
          
          <h2>6. Cancellation Policy</h2>
          <p>Cancellations made more than 24 hours before a booking start time receive a full refund. Cancellations within 24 hours may be subject to a cancellation fee of up to 50% of the booking total.</p>
          
          <h2>7. Insurance</h2>
          <p>The Village Co. provides limited insurance coverage for bookings made through the Platform. Details of coverage are available upon request.</p>
          
          <h2>8. Reviews and Ratings</h2>
          <p>Users may leave reviews and ratings for others. Reviews must be accurate and may not contain offensive or inappropriate content.</p>
          
          <h2>9. Privacy</h2>
          <p>Your use of the Platform is subject to our Privacy Policy, which is incorporated by reference into these Terms.</p>
          
          <h2>10. Termination</h2>
          <p>The Village Co. reserves the right to terminate any user account at its discretion, with or without notice.</p>
          
          <h2>11. Modifications to Terms</h2>
          <p>The Village Co. may modify these Terms at any time. Continued use of the Platform after any changes constitutes acceptance of the modified Terms.</p>
          
          <h2>12. Governing Law</h2>
          <p>These Terms are governed by the laws of New Zealand, without regard to its conflict of law provisions.</p>
          
          <h2>13. Contact Information</h2>
          <p>For questions about these Terms, please contact us at help@ittakesavillage.nz.</p>
        </CardContent>
      </Card>
    </div>
  );
}