import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { toast } from '@/hooks/use-toast';
import { HeartHandshake, Phone, Mail, MessageSquare } from 'lucide-react';

export default function Support() {
  const [category, setCategory] = useState('urgent');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { user } = useAuth();

  const submit = async () => {
    if (!message.trim()) {
      toast({
        title: "Message required",
        description: "Please describe your issue so we can help you better.",
        variant: "destructive"
      });
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      await supabase.from('support_requests').insert({
        user_id: user?.id,
        category,
        message,
        user_role: user?.role || 'parent',
      });
      
      setSubmitted(true);
      toast({
        title: "Request sent",
        description: "We'll get back to you as soon as possible.",
      });
    } catch (error) {
      console.error('Error submitting support request:', error);
      toast({
        title: "Something went wrong",
        description: "We couldn't send your request. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="container py-6 sm:py-8 px-4 sm:px-6">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-6 sm:mb-8">
          <h1 className="text-2xl font-bold mb-2">Need help?</h1>
          <p className="text-sm sm:text-base">
            For urgent questions or insurance claims, {' '}
            <a href="mailto:info@thevillageco.nz" className="text-wine underline">
              email us
            </a>
            {' '} or submit a support request.
          </p>
        </div>
        
        {submitted ? (
          <Card className="bg-green-50 border-green-100">
            <CardContent className="pt-6 text-center">
              <div className="flex justify-center mb-4">
                <HeartHandshake className="h-12 w-12 text-green-600" />
              </div>
              <h2 className="text-xl font-semibold text-green-800 mb-2">We've Got You Covered!</h2>
              <p className="text-green-700 mb-4">
                Your message has been sent to our support team. We'll be in touch via email shortly.
              </p>
              <p className="text-sm text-green-600">
                Our typical response time is under 2 hours during business hours.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6">
            <div className="md:col-span-1 order-2 md:order-1">
              <div className="space-y-4">
                <Card>
                  <CardContent className="pt-6">
                    <h3 className="text-lg font-semibold mb-3">Quick Contact</h3>
                    <div className="space-y-3">
                      <div className="flex items-center">
                        <Phone className="h-5 w-5 text-wine mr-2 flex-shrink-0" />
                        <div>
                          <div>+64 7 807 9114</div>
                          <div className="text-xs text-gray-500">(directs to mobile after business hours)</div>
                        </div>
                      </div>
                      <div className="flex items-center">
                        <Mail className="h-5 w-5 text-wine mr-2 flex-shrink-0" />
                        <span>support@ittakesavillage.nz</span>
                      </div>
                      <div className="flex items-center">
                        <MessageSquare className="h-5 w-5 text-wine mr-2 flex-shrink-0" />
                        <span>WhatsApp Support</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <div className="bg-eucalyptus text-white p-4 rounded-md text-sm">
                  <p className="mb-2 font-medium">Emergency?</p>
                  <p>For urgent booking issues, call us directly for the fastest response.</p>
                </div>
              </div>
            </div>
            
            <div className="md:col-span-2 order-1 md:order-2">
              <Card>
                <CardHeader className="pb-2 sm:pb-4">
                  <CardTitle>Send a Support Request</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="category">Request Type</Label>
                    <Select
                      defaultValue={category}
                      onValueChange={setCategory}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select request type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="urgent">Urgent Support</SelectItem>
                        <SelectItem value="insurance_claim">Insurance Claim</SelectItem>
                        <SelectItem value="technical_issue">Technical Issue</SelectItem>
                        <SelectItem value="feedback">Feedback</SelectItem>
                        <SelectItem value="billing">Billing Question</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="message">Your Message</Label>
                    <Textarea
                      id="message"
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="Please describe your issue or question in detail"
                      className="min-h-[120px] sm:min-h-[150px]"
                    />
                  </div>
                </CardContent>
                <CardFooter>
                  <Button 
                    onClick={submit} 
                    className="w-full bg-wine hover:bg-wine/90"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? 'Sending...' : 'Send Request'}
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}