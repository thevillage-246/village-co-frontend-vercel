import { useQuery, useMutation } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import SEO, { SEOConfigs } from '@/components/SEO';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar, Clock, MapPin, Users, Sparkles, Coffee, Heart, Palette, Edit, Plus } from "lucide-react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface VillagePlan {
  id: number;
  name: string;
  price: string;
  monthlyHours: number;
  freeEvents: number;
  features: string[];
  isActive: boolean;
  stripeProductId: string;
  stripePriceId: string;
  stripeCheckoutUrl: string;
  hasStripeIntegration?: boolean;
  createdAt: string;
  updatedAt: string;
}

interface VillageEvent {
  id: number;
  title: string;
  description: string;
  eventDate: string;
  location: string;
  maxAttendees: number;
  currentAttendees: number;
  requiresSubscription: boolean;
  eventType: string;
  imageUrl: string;
  createdAt: string;
  updatedAt: string;
}

export default function PlansEvents() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [editingPlan, setEditingPlan] = useState<VillagePlan | null>(null);
  const [editingEvent, setEditingEvent] = useState<VillageEvent | null>(null);
  const [showNewPlanDialog, setShowNewPlanDialog] = useState(false);
  const [showNewEventDialog, setShowNewEventDialog] = useState(false);
  const { toast } = useToast();

  // Stripe subscription handler
  const handleSubscription = async (planId: number, planName: string) => {
    try {
      const response = await apiRequest("POST", "/api/stripe/create-subscription", {
        planId,
        planName
      });
      
      if (response.ok) {
        const { clientSecret, subscriptionId } = await response.json();
        
        // Open mailto link for subscription requests
        const subject = encodeURIComponent("add me to your mailing list");
        const mailtoUrl = `mailto:subscribe@thevillageco.nz?subject=${subject}`;
        window.location.href = mailtoUrl;
        
        toast({
          title: "Subscription Started",
          description: `${planName} subscription process initiated. You'll be contacted to complete setup.`,
        });
      } else {
        throw new Error("Failed to create subscription");
      }
    } catch (error) {
      toast({
        title: "Subscription Error",
        description: "Unable to start subscription. Please try again or contact support.",
        variant: "destructive",
      });
    }
  };

  // Check admin status and set SEO meta tags
  useEffect(() => {
    // Set SEO meta tags for Plans & Events page
    document.title = "Village Plans & Events - Subscription Babysitting | The Village Co.";
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute('content', 'Discover Village Plans and community events. Subscription-based childcare with monthly hours and exclusive access to parent events. Join The Village Co. community in New Zealand.');
    }

    const userDataStr = localStorage.getItem('userData');
    if (userDataStr) {
      try {
        const userData = JSON.parse(userDataStr);
        setIsAdmin(userData.role === 'admin');
      } catch (error) {
        console.error('Failed to parse user data:', error);
      }
    }
  }, []);

  const { data: plans = [], isLoading: plansLoading, error: plansError } = useQuery<VillagePlan[]>({
    queryKey: ["/api/village-plans/with-stripe"],
    retry: false,
  });

  const { data: events = [], isLoading: eventsLoading, error: eventsError } = useQuery<VillageEvent[]>({
    queryKey: ["/api/village-events"],
    retry: false,
  });

  // Mutations for admin editing
  const updatePlanMutation = useMutation({
    mutationFn: async (planData: Partial<VillagePlan>) => {
      const { id, ...updateData } = planData;
      return await apiRequest("PUT", `/api/village-plans/${id}`, updateData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/village-plans/with-stripe"] });
      toast({ title: "Plan updated successfully" });
      setEditingPlan(null);
    },
    onError: () => {
      toast({ title: "Failed to update plan", variant: "destructive" });
    },
  });

  const createPlanMutation = useMutation({
    mutationFn: async (planData: Omit<VillagePlan, 'id' | 'createdAt' | 'updatedAt'>) => {
      return await apiRequest("POST", "/api/village-plans", planData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/village-plans/with-stripe"] });
      toast({ title: "Plan created successfully" });
      setShowNewPlanDialog(false);
    },
    onError: () => {
      toast({ title: "Failed to create plan", variant: "destructive" });
    },
  });

  const updateEventMutation = useMutation({
    mutationFn: async (eventData: Partial<VillageEvent>) => {
      const { id, ...updateData } = eventData;
      return await apiRequest("PUT", `/api/village-events/${id}`, updateData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/village-events"] });
      toast({ title: "Event updated successfully" });
      setEditingEvent(null);
    },
    onError: () => {
      toast({ title: "Failed to update event", variant: "destructive" });
    },
  });

  const createEventMutation = useMutation({
    mutationFn: async (eventData: Omit<VillageEvent, 'id' | 'createdAt' | 'updatedAt'>) => {
      return await apiRequest("POST", "/api/village-events", eventData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/village-events"] });
      toast({ title: "Event created successfully" });
      setShowNewEventDialog(false);
    },
    onError: () => {
      toast({ title: "Failed to create event", variant: "destructive" });
    },
  });

  if (plansLoading || eventsLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  const formatEventDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-NZ', { 
      weekday: 'long',
      month: 'long', 
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
      timeZone: 'Pacific/Auckland'
    });
  };

  const getEventIcon = (eventType: string) => {
    switch (eventType) {
      case 'social':
        return <Coffee className="w-6 h-6" />;
      case 'family':
        return <Heart className="w-6 h-6" />;
      case 'workshop':
        return <Palette className="w-6 h-6" />;
      default:
        return <Calendar className="w-6 h-6" />;
    }
  };

  return (
    <>
      <SEO {...SEOConfigs.villagePlans} />
      <div className="min-h-screen bg-gradient-to-br from-bone to-almond-frost">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-village-wine text-white">
        <div className="absolute inset-0 bg-gradient-to-r from-village-wine/90 to-village-wine/70" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center max-w-4xl mx-auto">
            <div className="flex justify-center mb-6">
              <Sparkles className="w-12 h-12 text-brushed-pink" />
            </div>
            <h1 className="text-5xl sm:text-6xl font-bold mb-6 leading-tight">
              Babysitting, but make it a <span className="text-brushed-pink">lifestyle</span>.
            </h1>
            <p className="text-xl sm:text-2xl mb-8 text-white/90 leading-relaxed">
              Whether you need a break, a moment, or a full-blown float at O Studio — we've got you.<br />
              Sitters you trust. Events you actually want to go to. Subscriptions that feel like self-care.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                className="bg-brushed-pink text-village-wine hover:bg-brushed-pink/90 text-lg px-8 py-3 font-bold shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
                onClick={() => document.getElementById('plans')?.scrollIntoView({ behavior: 'smooth' })}
              >
                Explore Plans
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-2 border-white text-white hover:bg-white hover:text-village-wine text-lg px-8 py-3 font-bold shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 bg-white/10 backdrop-blur-sm"
                onClick={() => document.getElementById('events')?.scrollIntoView({ behavior: 'smooth' })}
              >
                See Events
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Subscription Plans Section */}
      <section id="plans" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="flex justify-between items-center mb-6">
              <div className="flex-1"></div>
              <h2 className="text-4xl sm:text-5xl font-bold text-village-wine">
                Your Village, On Demand.
              </h2>
              <div className="flex-1 flex justify-end">
                {isAdmin && (
                  <Button
                    onClick={() => setShowNewPlanDialog(true)}
                    className="bg-village-wine text-white hover:bg-village-wine/90"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Plan
                  </Button>
                )}
              </div>
            </div>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              ✨ Your Time, On Your Terms<br />
              Our monthly plans give you peace of mind (and a few hours back) — for less than our standard hourly rates.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {plans.map((plan: VillagePlan, index: number) => {
              const planColors = [
                { bg: 'bg-sleepy-blue/10', border: 'border-sleepy-blue', text: 'text-sleepy-blue', icon: '🪴' },
                { bg: 'bg-brushed-pink/10', border: 'border-brushed-pink', text: 'text-brushed-pink', icon: '💖' },
                { bg: 'bg-village-wine/10', border: 'border-village-wine', text: 'text-village-wine', icon: '🍷' }
              ];
              const colors = planColors[index] || planColors[0];
              
              const planCopy = [
                "Perfect for a quick solo coffee or Pilates session.",
                "Date nights. Work catch-ups. Guilt-free me-time.",
                "Your week, your way — with full flexibility and sitter priority."
              ];

              return (
                <Card key={plan.id} className={`relative overflow-hidden ${colors.bg} ${colors.border} border-2 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2`}>
                  {isAdmin && (
                    <Button
                      size="sm"
                      variant="outline"
                      className="absolute top-2 right-2 z-10"
                      onClick={() => setEditingPlan(plan)}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                  )}
                  <CardHeader className="text-center pb-4">
                    <div className="text-4xl mb-4">{colors.icon}</div>
                    <CardTitle className={`text-2xl font-bold ${colors.text}`}>
                      Village {plan.name}
                    </CardTitle>
                    <div className="text-4xl font-bold text-gray-900 mb-2">
                      {plan.price}<span className="text-lg text-gray-600">/mo</span>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <ul className="space-y-3">
                      {plan.features.map((feature: string, idx: number) => (
                        <li key={idx} className="flex items-start gap-3">
                          <div className={`w-2 h-2 rounded-full ${colors.text.replace('text-', 'bg-')} mt-2 flex-shrink-0`} />
                          <span className="text-gray-700">{feature}</span>
                        </li>
                      ))}
                    </ul>
                    <div className="pt-4">
                      <p className="text-sm text-gray-600 italic text-center mb-6">
                        {planCopy[index]}
                      </p>
                      <Button 
                        className={`w-full ${colors.text.replace('text-', 'bg-')} text-white hover:opacity-90 font-bold py-3 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105`}
                        onClick={() => {
                          // Use dynamic Stripe checkout URL from backend
                          if (plan.stripeCheckoutUrl) {
                            window.open(plan.stripeCheckoutUrl, '_blank');
                          } else {
                            toast({
                              title: "Checkout Unavailable",
                              description: "This subscription option is temporarily unavailable. Please contact support.",
                              variant: "destructive",
                            });
                          }
                        }}
                      >
                        Choose {plan.name}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>


        </div>
      </section>

      {/* Events Section */}
      <section id="events" className="py-24 bg-gradient-to-br from-almond-frost/20 to-sleepy-blue/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="flex justify-between items-center mb-6">
              <div className="flex-1"></div>
              <h2 className="text-4xl sm:text-5xl font-bold text-village-wine">
                Village Events — For You, Not Just the Kids
              </h2>
              <div className="flex-1 flex justify-end">
                {isAdmin && (
                  <Button
                    onClick={() => setShowNewEventDialog(true)}
                    className="bg-village-wine text-white hover:bg-village-wine/90"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Event
                  </Button>
                )}
              </div>
            </div>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              These aren't baby singalongs.<br />
              Our events are made for connection, calm, and reclaiming your "you" time.<br />
              <span className="font-medium">(And yes — sitters are always included.)</span>
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {events.map((event: VillageEvent) => (
              <Card key={event.id} className="relative overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 bg-white">
                {isAdmin && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="absolute top-2 right-2 z-10"
                    onClick={() => setEditingEvent(event)}
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                )}
                <CardHeader className="pb-4">
                  <div className="flex items-center gap-3 mb-3">
                    <div className="p-2 rounded-full bg-village-wine/10 text-village-wine">
                      {getEventIcon(event.eventType)}
                    </div>
                    {event.requiresSubscription && (
                      <Badge variant="secondary" className="bg-brushed-pink/20 text-village-wine">
                        Members Only
                      </Badge>
                    )}
                  </div>
                  <CardTitle className="text-xl font-bold text-village-wine leading-tight">
                    {event.title}
                  </CardTitle>
                  <CardDescription className="text-gray-600 leading-relaxed">
                    {event.description}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3 text-sm text-gray-600">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-village-wine" />
                      <span>{formatEventDate(event.eventDate)}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-village-wine" />
                      <span>{event.location}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="w-4 h-4 text-village-wine" />
                      <span>{event.currentAttendees}/{event.maxAttendees} spots filled</span>
                    </div>
                  </div>
                  
                  <Button 
                    className="w-full bg-village-wine text-white hover:bg-village-wine/90 font-bold py-3 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105"
                    asChild
                  >
                    <a href="https://lu.ma/7uwn20vy" target="_blank" rel="noopener noreferrer">
                      Save My Spot
                    </a>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button size="lg" variant="outline" className="border-2 border-village-wine text-village-wine hover:bg-village-wine hover:text-white font-bold px-8 py-3 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 bg-white" asChild>
              <a href="https://snr0w.share.hsforms.com/2JNZTGx1_QsOuz44ErWalaA" target="_blank" rel="noopener noreferrer">Subscribe for Free Access</a>
            </Button>
          </div>
        </div>
      </section>

      {/* Admin Edit Plan Dialog */}
      {isAdmin && editingPlan && (
        <Dialog open={!!editingPlan} onOpenChange={() => setEditingPlan(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Edit Village Plan</DialogTitle>
            </DialogHeader>
            <EditPlanForm 
              plan={editingPlan} 
              onSave={(updatedPlan) => updatePlanMutation.mutate(updatedPlan)}
              onCancel={() => setEditingPlan(null)}
              isLoading={updatePlanMutation.isPending}
            />
          </DialogContent>
        </Dialog>
      )}

      {/* Admin Edit Event Dialog */}
      {isAdmin && editingEvent && (
        <Dialog open={!!editingEvent} onOpenChange={() => setEditingEvent(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Edit Village Event</DialogTitle>
            </DialogHeader>
            <EditEventForm 
              event={editingEvent} 
              onSave={(updatedEvent) => updateEventMutation.mutate(updatedEvent)}
              onCancel={() => setEditingEvent(null)}
              isLoading={updateEventMutation.isPending}
            />
          </DialogContent>
        </Dialog>
      )}

      {/* Admin Create Plan Dialog */}
      {isAdmin && showNewPlanDialog && (
        <Dialog open={showNewPlanDialog} onOpenChange={setShowNewPlanDialog}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create New Village Plan</DialogTitle>
            </DialogHeader>
            <CreatePlanForm 
              onSave={(newPlan) => createPlanMutation.mutate(newPlan)}
              onCancel={() => setShowNewPlanDialog(false)}
              isLoading={createPlanMutation.isPending}
            />
          </DialogContent>
        </Dialog>
      )}

      {/* Admin Create Event Dialog */}
      {isAdmin && showNewEventDialog && (
        <Dialog open={showNewEventDialog} onOpenChange={setShowNewEventDialog}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create New Village Event</DialogTitle>
            </DialogHeader>
            <CreateEventForm 
              onSave={(newEvent) => createEventMutation.mutate(newEvent)}
              onCancel={() => setShowNewEventDialog(false)}
              isLoading={createEventMutation.isPending}
            />
          </DialogContent>
        </Dialog>
      )}
      </div>
    </>
  );
}

// Edit Plan Form Component
function EditPlanForm({ plan, onSave, onCancel, isLoading }: {
  plan: VillagePlan;
  onSave: (plan: Partial<VillagePlan>) => void;
  onCancel: () => void;
  isLoading: boolean;
}) {
  const [formData, setFormData] = useState({
    name: plan.name,
    price: plan.price,
    monthlyHours: plan.monthlyHours.toString(),
    freeEvents: plan.freeEvents.toString(),
    features: plan.features.join('\n'),
    isActive: plan.isActive,
    stripeProductId: plan.stripeProductId,
    stripePriceId: plan.stripePriceId,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      id: plan.id,
      ...formData,
      monthlyHours: parseInt(formData.monthlyHours),
      freeEvents: parseInt(formData.freeEvents),
      features: formData.features.split('\n').filter(f => f.trim()),
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="name">Plan Name</Label>
          <Input
            id="name"
            value={formData.name}
            onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
            required
          />
        </div>
        <div>
          <Label htmlFor="price">Price</Label>
          <Input
            id="price"
            value={formData.price}
            onChange={(e) => setFormData(prev => ({ ...prev, price: e.target.value }))}
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="monthlyHours">Monthly Hours</Label>
          <Input
            id="monthlyHours"
            type="number"
            value={formData.monthlyHours}
            onChange={(e) => setFormData(prev => ({ ...prev, monthlyHours: e.target.value }))}
            required
          />
        </div>
        <div>
          <Label htmlFor="freeEvents">Free Events</Label>
          <Input
            id="freeEvents"
            type="number"
            value={formData.freeEvents}
            onChange={(e) => setFormData(prev => ({ ...prev, freeEvents: e.target.value }))}
            required
          />
        </div>
      </div>

      <div>
        <Label htmlFor="features">Features (one per line)</Label>
        <Textarea
          id="features"
          value={formData.features}
          onChange={(e) => setFormData(prev => ({ ...prev, features: e.target.value }))}
          rows={5}
          required
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="stripeProductId">Stripe Product ID</Label>
          <Input
            id="stripeProductId"
            value={formData.stripeProductId}
            onChange={(e) => setFormData(prev => ({ ...prev, stripeProductId: e.target.value }))}
            required
          />
        </div>
        <div>
          <Label htmlFor="stripePriceId">Stripe Price ID</Label>
          <Input
            id="stripePriceId"
            value={formData.stripePriceId}
            onChange={(e) => setFormData(prev => ({ ...prev, stripePriceId: e.target.value }))}
            required
          />
        </div>
      </div>

      <div className="flex items-center space-x-2">
        <Switch
          id="isActive"
          checked={formData.isActive}
          onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isActive: checked }))}
        />
        <Label htmlFor="isActive">Active Plan</Label>
      </div>

      <div className="flex justify-end space-x-2 pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" disabled={isLoading}>
          {isLoading ? 'Saving...' : 'Save Changes'}
        </Button>
      </div>
    </form>
  );
}

// Edit Event Form Component
function EditEventForm({ event, onSave, onCancel, isLoading }: {
  event: VillageEvent;
  onSave: (event: Partial<VillageEvent>) => void;
  onCancel: () => void;
  isLoading: boolean;
}) {
  const [formData, setFormData] = useState({
    title: event.title,
    description: event.description,
    eventDate: new Date(event.eventDate).toISOString().slice(0, 16),
    location: event.location,
    maxAttendees: event.maxAttendees.toString(),
    requiresSubscription: event.requiresSubscription,
    eventType: event.eventType,
    imageUrl: event.imageUrl,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      id: event.id,
      ...formData,
      eventDate: new Date(formData.eventDate).toISOString(),
      maxAttendees: parseInt(formData.maxAttendees),
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="title">Event Title</Label>
        <Input
          id="title"
          value={formData.title}
          onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
          required
        />
      </div>

      <div>
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
          rows={3}
          required
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="eventDate">Event Date & Time</Label>
          <Input
            id="eventDate"
            type="datetime-local"
            value={formData.eventDate}
            onChange={(e) => setFormData(prev => ({ ...prev, eventDate: e.target.value }))}
            required
          />
        </div>
        <div>
          <Label htmlFor="location">Location</Label>
          <Input
            id="location"
            value={formData.location}
            onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="maxAttendees">Max Attendees</Label>
          <Input
            id="maxAttendees"
            type="number"
            value={formData.maxAttendees}
            onChange={(e) => setFormData(prev => ({ ...prev, maxAttendees: e.target.value }))}
            required
          />
        </div>
        <div>
          <Label htmlFor="eventType">Event Type</Label>
          <Select value={formData.eventType} onValueChange={(value) => setFormData(prev => ({ ...prev, eventType: value }))}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="social">Social</SelectItem>
              <SelectItem value="family">Family</SelectItem>
              <SelectItem value="workshop">Workshop</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div>
        <Label htmlFor="imageUrl">Image URL</Label>
        <Input
          id="imageUrl"
          value={formData.imageUrl}
          onChange={(e) => setFormData(prev => ({ ...prev, imageUrl: e.target.value }))}
        />
      </div>

      <div className="flex items-center space-x-2">
        <Switch
          id="requiresSubscription"
          checked={formData.requiresSubscription}
          onCheckedChange={(checked) => setFormData(prev => ({ ...prev, requiresSubscription: checked }))}
        />
        <Label htmlFor="requiresSubscription">Requires Subscription</Label>
      </div>

      <div className="flex justify-end space-x-2 pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" disabled={isLoading}>
          {isLoading ? 'Saving...' : 'Save Changes'}
        </Button>
      </div>
    </form>
  );
}

// Create Plan Form Component
function CreatePlanForm({ onSave, onCancel, isLoading }: {
  onSave: (plan: Omit<VillagePlan, 'id' | 'createdAt' | 'updatedAt'>) => void;
  onCancel: () => void;
  isLoading: boolean;
}) {
  const [formData, setFormData] = useState({
    name: '',
    price: '',
    monthlyHours: '',
    freeEvents: '',
    features: '',
    isActive: true,
    stripeProductId: '',
    stripePriceId: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...formData,
      monthlyHours: parseInt(formData.monthlyHours),
      freeEvents: parseInt(formData.freeEvents),
      features: formData.features.split('\n').filter(f => f.trim()),
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="name">Plan Name</Label>
          <Input
            id="name"
            value={formData.name}
            onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
            required
          />
        </div>
        <div>
          <Label htmlFor="price">Price</Label>
          <Input
            id="price"
            value={formData.price}
            onChange={(e) => setFormData(prev => ({ ...prev, price: e.target.value }))}
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="monthlyHours">Monthly Hours</Label>
          <Input
            id="monthlyHours"
            type="number"
            value={formData.monthlyHours}
            onChange={(e) => setFormData(prev => ({ ...prev, monthlyHours: e.target.value }))}
            required
          />
        </div>
        <div>
          <Label htmlFor="freeEvents">Free Events</Label>
          <Input
            id="freeEvents"
            type="number"
            value={formData.freeEvents}
            onChange={(e) => setFormData(prev => ({ ...prev, freeEvents: e.target.value }))}
            required
          />
        </div>
      </div>

      <div>
        <Label htmlFor="features">Features (one per line)</Label>
        <Textarea
          id="features"
          value={formData.features}
          onChange={(e) => setFormData(prev => ({ ...prev, features: e.target.value }))}
          rows={5}
          required
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="stripeProductId">Stripe Product ID</Label>
          <Input
            id="stripeProductId"
            value={formData.stripeProductId}
            onChange={(e) => setFormData(prev => ({ ...prev, stripeProductId: e.target.value }))}
            required
          />
        </div>
        <div>
          <Label htmlFor="stripePriceId">Stripe Price ID</Label>
          <Input
            id="stripePriceId"
            value={formData.stripePriceId}
            onChange={(e) => setFormData(prev => ({ ...prev, stripePriceId: e.target.value }))}
            required
          />
        </div>
      </div>

      <div className="flex items-center space-x-2">
        <Switch
          id="isActive"
          checked={formData.isActive}
          onCheckedChange={(checked) => setFormData(prev => ({ ...prev, isActive: checked }))}
        />
        <Label htmlFor="isActive">Active Plan</Label>
      </div>

      <div className="flex justify-end space-x-2 pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" disabled={isLoading}>
          {isLoading ? 'Creating...' : 'Create Plan'}
        </Button>
      </div>
    </form>
  );
}

// Create Event Form Component
function CreateEventForm({ onSave, onCancel, isLoading }: {
  onSave: (event: Omit<VillageEvent, 'id' | 'createdAt' | 'updatedAt'>) => void;
  onCancel: () => void;
  isLoading: boolean;
}) {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    eventDate: '',
    location: '',
    maxAttendees: '',
    currentAttendees: 0,
    requiresSubscription: false,
    eventType: 'social',
    imageUrl: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...formData,
      eventDate: new Date(formData.eventDate).toISOString(),
      maxAttendees: parseInt(formData.maxAttendees),
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="title">Event Title</Label>
        <Input
          id="title"
          value={formData.title}
          onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
          required
        />
      </div>

      <div>
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
          rows={3}
          required
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="eventDate">Event Date & Time</Label>
          <Input
            id="eventDate"
            type="datetime-local"
            value={formData.eventDate}
            onChange={(e) => setFormData(prev => ({ ...prev, eventDate: e.target.value }))}
            required
          />
        </div>
        <div>
          <Label htmlFor="location">Location</Label>
          <Input
            id="location"
            value={formData.location}
            onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="maxAttendees">Max Attendees</Label>
          <Input
            id="maxAttendees"
            type="number"
            value={formData.maxAttendees}
            onChange={(e) => setFormData(prev => ({ ...prev, maxAttendees: e.target.value }))}
            required
          />
        </div>
        <div>
          <Label htmlFor="eventType">Event Type</Label>
          <Select value={formData.eventType} onValueChange={(value) => setFormData(prev => ({ ...prev, eventType: value }))}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="social">Social</SelectItem>
              <SelectItem value="family">Family</SelectItem>
              <SelectItem value="workshop">Workshop</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div>
        <Label htmlFor="imageUrl">Image URL</Label>
        <Input
          id="imageUrl"
          value={formData.imageUrl}
          onChange={(e) => setFormData(prev => ({ ...prev, imageUrl: e.target.value }))}
        />
      </div>

      <div className="flex items-center space-x-2">
        <Switch
          id="requiresSubscription"
          checked={formData.requiresSubscription}
          onCheckedChange={(checked) => setFormData(prev => ({ ...prev, requiresSubscription: checked }))}
        />
        <Label htmlFor="requiresSubscription">Requires Subscription</Label>
      </div>

      <div className="flex justify-end space-x-2 pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" disabled={isLoading}>
          {isLoading ? 'Creating...' : 'Create Event'}
        </Button>
      </div>
    </form>
  );
}