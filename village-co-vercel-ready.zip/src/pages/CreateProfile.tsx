import { useState, useEffect, useCallback } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useMutation, useQuery } from '@tanstack/react-query';
import { debounce } from 'lodash';
import { useAuth } from '@/contexts/AuthContext';

export default function CreateProfile() {
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  
  // Check if user already has a profile - if so, redirect them to edit instead
  const { data: profileExists, isLoading: profileCheckLoading } = useQuery({
    queryKey: ['/api/parent/profile/exists'],
    enabled: !!user,
  });

  // Form state
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [bio, setBio] = useState('');
  const [children, setChildren] = useState('');

  // Redirect existing users with profiles to edit their profile instead
  useEffect(() => {
    if (profileExists?.hasProfile) {
      toast({
        title: "Profile Already Exists",
        description: "You already have a profile. Redirecting to edit your profile instead.",
      });
      setLocation('/parent/edit-profile');
    }
  }, [profileExists, setLocation, toast]);

  const createProfileMutation = useMutation({
    mutationFn: async (profileData: any) => {
      // Use the same token checking logic as queryClient with debug logging
      const auth_token = localStorage.getItem('auth_token');
      const authToken = localStorage.getItem('authToken');
      const token = auth_token || authToken;
      
      console.log('CreateProfile token check:', { auth_token: !!auth_token, authToken: !!authToken, token: !!token });
      
      if (!token) {
        // Check all possible token storage locations for debugging
        const allTokens = {
          auth_token: localStorage.getItem('auth_token'),
          authToken: localStorage.getItem('authToken'),
          token: localStorage.getItem('token'),
          'village-co-auth-token': localStorage.getItem('village-co-auth-token')
        };
        console.error('No token found. Available tokens:', allTokens);
        throw new Error('No authentication token found. Please log in again.');
      }
      
      // Use the fixed profile creation endpoint that matches the database schema
      const response = await apiRequest('POST', '/api/profile/create', {
        firstName: profileData.firstName,
        lastName: profileData.lastName,
        phone: profileData.phone,
        address: profileData.address,
        bio: profileData.bio,
        children: profileData.children,
        emergencyContact: {
          name: profileData.firstName + ' ' + profileData.lastName,
          phone: profileData.phone
        }
      });
      
      return response;
    },
    onSuccess: (data) => {
      toast({
        title: "Profile Created Successfully!",
        description: "All your information has been saved. Welcome to The Village Co!",
      });
      
      // Redirect to dashboard
      setTimeout(() => {
        setLocation('/parent/dashboard');
      }, 1500);
    },
    onError: (error: any) => {
      toast({
        title: "Error Creating Profile", 
        description: error.message || "Failed to create profile. Please try again.",
        variant: "destructive",
      });
      console.error('Profile creation error:', error);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!firstName || !lastName || !phone || !address) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    const profileData = {
      firstName,
      lastName,
      phone,
      address,
      bio,
      children
    };

    createProfileMutation.mutate(profileData);
  };

  // Show loading while checking if user has existing profile
  if (profileCheckLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-linen via-rose/5 to-wine/10 py-8 flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="animate-spin h-8 w-8 border-4 border-wine border-t-transparent rounded-full"></div>
          <p className="text-gray-600">Checking your profile status...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-linen via-rose/5 to-wine/10 py-8">
      <div className="container max-w-2xl mx-auto px-4">
        <Card className="shadow-lg border-0 bg-white/95 backdrop-blur-sm">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold bg-gradient-to-r from-wine to-eucalyptus bg-clip-text text-transparent">
              Create Your Profile
            </CardTitle>
            <p className="text-gray-600 mt-2">
              Let's set up your Village Co. profile so you can start finding amazing sitters!
            </p>
          </CardHeader>
          
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              
              {/* Personal Information */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-wine">Personal Information</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName">First Name *</Label>
                    <Input
                      id="firstName"
                      value={firstName}
                      onChange={(e) => setFirstName(e.target.value)}
                      placeholder="Enter your first name"
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="lastName">Last Name *</Label>
                    <Input
                      id="lastName"
                      value={lastName}
                      onChange={(e) => setLastName(e.target.value)}
                      placeholder="Enter your last name"
                      required
                    />
                  </div>
                </div>
                
                <div>
                  <Label htmlFor="phone">Phone Number *</Label>
                  <Input
                    id="phone"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="e.g., +64 21 123 4567"
                    required
                  />
                </div>
                
                <div>
                  <Label htmlFor="address">Address *</Label>
                  <Input
                    id="address"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="Enter your address"
                    required
                  />
                </div>
              </div>

              {/* About You */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-wine">About You</h3>
                
                <div>
                  <Label htmlFor="bio">Bio (Optional)</Label>
                  <Textarea
                    id="bio"
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    placeholder="Tell us a bit about yourself and your family..."
                    rows={3}
                  />
                </div>
                
                <div>
                  <Label htmlFor="children">Children Information (Optional)</Label>
                  <Textarea
                    id="children"
                    value={children}
                    onChange={(e) => setChildren(e.target.value)}
                    placeholder="Tell us about your children (names, ages, any special notes)..."
                    rows={3}
                  />
                </div>
              </div>



              {/* Submit Button */}
              <div className="pt-6 border-t">
                <Button
                  type="submit"
                  disabled={createProfileMutation.isPending}
                  className="w-full bg-gradient-to-r from-wine to-rose hover:from-wine/90 hover:to-rose/90 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 shadow-md hover:shadow-lg"
                >
                  {createProfileMutation.isPending ? 'Creating Profile...' : 'Create Profile'}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}