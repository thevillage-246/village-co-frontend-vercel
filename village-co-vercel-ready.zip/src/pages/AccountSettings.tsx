import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { 
  User as UserIcon, 
  Shield, 
  CreditCard, 
  Settings, 
  Heart, 
  Trash2, 
  Bell, 
  Download,
  ExternalLink,
  AlertTriangle,
  Mail,
  Phone,
  Lock,
  Eye,
  EyeOff,
  Users,
  DollarSign,
  FileText,
  UserX,
  Clock,
  Copy,
  CheckCircle,
  XCircle,
  AlertCircle,
  Receipt,
  UserPlus,
  Send,
  Loader2
} from 'lucide-react';
import { Link } from 'wouter';
import { apiRequest } from '@/lib/queryClient';
import TrustedAccountsList from '@/components/parents/TrustedAccountsList';
import InvitePartner from '@/components/parents/InvitePartner';

interface AccountUser {
  id: number;
  email: string;
  firstName: string;
  lastName: string;
  phone?: string;
  role: string;
  profileVisibility?: boolean;
  bookingHistoryVisible?: boolean;
  defaultBookingDuration?: number;
  wantsSitterSuggestions?: boolean;
  wantsDateNightReminders?: boolean;
  pushNotificationsEnabled?: boolean;
}

interface TrustedAccount {
  id: string;
  invitedEmail: string;
  role: string;
  accepted: boolean;
  createdAt: string;
  revokedAt?: string;
}

interface Credit {
  id: number;
  amount: string;
  description: string;
  createdAt: string;
}

interface Referral {
  id: string;
  code: string;
  status: string;
  referredEmail?: string;
  completedAt?: string;
  createdAt: string;
}

export default function AccountSettings() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('account');
  const [showDeactivateDialog, setShowDeactivateDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [deactivationReason, setDeactivationReason] = useState('');
  const [newTrustedEmail, setNewTrustedEmail] = useState('');
  const [inviteEmailSending, setInviteEmailSending] = useState(false);
  
  // Password change state
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  // Fetch account settings data
  const { data: accountData, isLoading } = useQuery({
    queryKey: ['/api/account/settings'],
  });

  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: (profileData: any) => 
      apiRequest('PUT', '/api/account/profile', profileData),
    onSuccess: () => {
      toast({
        title: "Profile Updated",
        description: "Your profile information has been successfully updated.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/account/settings'] });
    },
    onError: () => {
      toast({
        title: "Update Failed",
        description: "Failed to update profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Password change mutation
  const changePasswordMutation = useMutation({
    mutationFn: (passwordData: { currentPassword: string; newPassword: string }) => 
      apiRequest('PUT', '/api/account/change-password', passwordData),
    onSuccess: () => {
      toast({
        title: "Password Changed",
        description: "Your password has been successfully updated.",
      });
      // Clear password fields
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    },
    onError: (error: any) => {
      toast({
        title: "Password Change Failed",
        description: error.message || "Failed to change password. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Update preferences mutation
  const updatePreferencesMutation = useMutation({
    mutationFn: (preferences: any) => 
      apiRequest('PUT', '/api/account/preferences', preferences),
    onSuccess: () => {
      toast({
        title: "Preferences Updated",
        description: "Your account preferences have been successfully updated.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/account/settings'] });
    },
    onError: () => {
      toast({
        title: "Update Failed",
        description: "Failed to update preferences. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Deactivate account mutation
  const deactivateAccountMutation = useMutation({
    mutationFn: () => apiRequest('DELETE', '/api/account/deactivate'),
    onSuccess: () => {
      toast({
        title: "Account Deactivated",
        description: "Your account has been deactivated. You can reactivate it by logging in again.",
      });
      // Redirect to login page
      window.location.href = '/login';
    },
    onError: () => {
      toast({
        title: "Deactivation Failed",
        description: "Failed to deactivate account. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Invite trusted parent mutation
  const inviteTrustedParentMutation = useMutation({
    mutationFn: (email: string) => 
      apiRequest('POST', '/api/trusted-accounts/invite', { email, role: 'parent' }),
    onSuccess: () => {
      toast({
        title: "Invitation Sent",
        description: `Trusted parent invitation sent to ${newTrustedEmail}`,
      });
      setNewTrustedEmail('');
      queryClient.invalidateQueries({ queryKey: ['/api/account/settings'] });
    },
    onError: () => {
      toast({
        title: "Invitation Failed",
        description: "Failed to send invitation. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleInviteTrustedParent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTrustedEmail.trim()) return;
    
    setInviteEmailSending(true);
    try {
      await inviteTrustedParentMutation.mutateAsync(newTrustedEmail);
    } finally {
      setInviteEmailSending(false);
    }
  };

  const copyReferralCode = (code: string) => {
    navigator.clipboard.writeText(code);
    toast({
      title: "Copied!",
      description: "Referral code copied to clipboard",
    });
  };

  const downloadReceipt = (creditId: number) => {
    // Generate receipt download link
    const link = document.createElement('a');
    link.href = `/api/receipts/${creditId}`;
    link.download = `village-co-receipt-${creditId}.pdf`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-6 max-w-4xl">
        <div className="space-y-6">
          <div className="h-8 bg-gray-200 rounded animate-pulse"></div>
          <div className="h-96 bg-gray-200 rounded animate-pulse"></div>
        </div>
      </div>
    );
  }

  const userData = (accountData as any)?.user as AccountUser;
  const credits = (accountData as any)?.credits?.details || [];
  const totalCredits = (accountData as any)?.credits?.total || 0;
  const trustedAccounts = (accountData as any)?.trustedAccounts || [];
  const referrals = (accountData as any)?.referrals || [];
  
  // Determine if user is a sitter
  const isSitter = userData?.role === 'sitter';

  return (
    <div className="container mx-auto p-4 sm:p-6 max-w-4xl">
      <div className="space-y-4 sm:space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl sm:text-3xl font-bold text-village-wine">Account Settings</h1>
          <p className="text-muted-foreground mt-2 text-sm sm:text-base">
            Manage your account information, privacy settings, and preferences
          </p>
        </div>

        {/* Settings Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <div className="w-full overflow-x-auto">
            <TabsList className={`grid w-full min-w-max ${isSitter ? 'grid-cols-5' : 'grid-cols-7'} gap-1 h-auto p-1`}>
              <TabsTrigger value="account" className="flex flex-col sm:flex-row items-center gap-1 sm:gap-2 text-xs sm:text-sm p-2 sm:p-3 min-h-[3rem] sm:min-h-[2.5rem] whitespace-nowrap">
                <UserIcon className="w-4 h-4 flex-shrink-0" />
                <span className="hidden xs:inline sm:hidden lg:inline">Profile</span>
                <span className="hidden sm:inline lg:hidden">Profile Settings</span>
              </TabsTrigger>
              <TabsTrigger value="security" className="flex flex-col sm:flex-row items-center gap-1 sm:gap-2 text-xs sm:text-sm p-2 sm:p-3 min-h-[3rem] sm:min-h-[2.5rem] whitespace-nowrap">
                <Lock className="w-4 h-4 flex-shrink-0" />
                <span className="hidden xs:inline sm:hidden lg:inline">Security</span>
                <span className="hidden sm:inline lg:hidden">Security & Password</span>
              </TabsTrigger>
              {!isSitter && (
                <>
                  <TabsTrigger value="privacy" className="flex flex-col sm:flex-row items-center gap-1 sm:gap-2 text-xs sm:text-sm p-2 sm:p-3 min-h-[3rem] sm:min-h-[2.5rem] whitespace-nowrap">
                    <Shield className="w-4 h-4 flex-shrink-0" />
                    <span className="hidden xs:inline sm:hidden lg:inline">Privacy</span>
                    <span className="hidden sm:inline lg:hidden">Privacy & Trust</span>
                  </TabsTrigger>
                  <TabsTrigger value="payment" className="flex flex-col sm:flex-row items-center gap-1 sm:gap-2 text-xs sm:text-sm p-2 sm:p-3 min-h-[3rem] sm:min-h-[2.5rem] whitespace-nowrap">
                    <CreditCard className="w-4 h-4 flex-shrink-0" />
                    <span className="hidden xs:inline sm:hidden lg:inline">Credits</span>
                    <span className="hidden sm:inline lg:hidden">Credits & Payments</span>
                  </TabsTrigger>
                </>
              )}
              {isSitter && (
                <TabsTrigger value="payment" className="flex flex-col sm:flex-row items-center gap-1 sm:gap-2 text-xs sm:text-sm p-2 sm:p-3 min-h-[3rem] sm:min-h-[2.5rem] whitespace-nowrap">
                  <CreditCard className="w-4 h-4 flex-shrink-0" />
                  <span className="hidden xs:inline sm:hidden lg:inline">Payment</span>
                  <span className="hidden sm:inline lg:hidden">Payment Methods</span>
                </TabsTrigger>
              )}
              <TabsTrigger value="safety" className="flex flex-col sm:flex-row items-center gap-1 sm:gap-2 text-xs sm:text-sm p-2 sm:p-3 min-h-[3rem] sm:min-h-[2.5rem] whitespace-nowrap">
                <Heart className="w-4 h-4 flex-shrink-0" />
                <span className="hidden xs:inline sm:hidden lg:inline">Safety</span>
                <span className="hidden sm:inline lg:hidden">Safety & Support</span>
              </TabsTrigger>
              <TabsTrigger value="newsletter" className="flex flex-col sm:flex-row items-center gap-1 sm:gap-2 text-xs sm:text-sm p-2 sm:p-3 min-h-[3rem] sm:min-h-[2.5rem] whitespace-nowrap">
                <Bell className="w-4 h-4 flex-shrink-0" />
                <span className="hidden xs:inline sm:hidden lg:inline">Newsletter</span>
                <span className="hidden sm:inline lg:hidden">Newsletter & Notifications</span>
              </TabsTrigger>
              <TabsTrigger value="danger" className="flex flex-col sm:flex-row items-center gap-1 sm:gap-2 text-xs sm:text-sm p-2 sm:p-3 min-h-[3rem] sm:min-h-[2.5rem] whitespace-nowrap">
                <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                <span className="hidden xs:inline sm:hidden lg:inline">Account</span>
                <span className="hidden sm:inline lg:hidden">Account Cancellation</span>
              </TabsTrigger>
            </TabsList>
          </div>

          {/* Account Information */}
          <TabsContent value="account" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <UserIcon className="w-5 h-5" />
                  Personal Information
                </CardTitle>
                <CardDescription>
                  Update your basic account information and contact details
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">First Name</Label>
                    <Input
                      id="firstName"
                      defaultValue={userData?.firstName}
                      placeholder="Enter your first name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input
                      id="lastName"
                      defaultValue={userData?.lastName}
                      placeholder="Enter your last name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address</Label>
                    <Input
                      id="email"
                      type="email"
                      defaultValue={userData?.email}
                      placeholder="Enter your email"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      type="tel"
                      defaultValue={userData?.phone || ''}
                      placeholder="Enter your phone number"
                    />
                  </div>
                </div>
                <Separator />
                <div className="flex items-center gap-4">
                  <Button 
                    onClick={() => {
                      const firstName = (document.getElementById('firstName') as HTMLInputElement)?.value;
                      const lastName = (document.getElementById('lastName') as HTMLInputElement)?.value;
                      const email = (document.getElementById('email') as HTMLInputElement)?.value;
                      const phone = (document.getElementById('phone') as HTMLInputElement)?.value;
                      
                      updateProfileMutation.mutate({ firstName, lastName, email, phone });
                    }}
                    disabled={updateProfileMutation.isPending}
                  >
                    {updateProfileMutation.isPending ? 'Updating...' : 'Save Changes'}
                  </Button>
                  <Button 
                    variant="outline"
                    onClick={() => setActiveTab('security')}
                  >
                    <Lock className="w-4 h-4 mr-2" />
                    Change Password
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Security & Password */}
          <TabsContent value="security" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lock className="w-5 h-5" />
                  Change Password
                </CardTitle>
                <CardDescription>
                  Update your password to keep your account secure
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="currentPassword">Current Password</Label>
                    <div className="relative">
                      <Input
                        id="currentPassword"
                        type={showCurrentPassword ? "text" : "password"}
                        value={currentPassword}
                        onChange={(e) => setCurrentPassword(e.target.value)}
                        placeholder="Enter your current password"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-2 top-1/2 -translate-y-1/2 h-7 w-7 p-0"
                        onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                      >
                        {showCurrentPassword ? (
                          <EyeOff className="h-4 w-4" />
                        ) : (
                          <Eye className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="newPassword">New Password</Label>
                    <div className="relative">
                      <Input
                        id="newPassword"
                        type={showNewPassword ? "text" : "password"}
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        placeholder="Enter your new password"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-2 top-1/2 -translate-y-1/2 h-7 w-7 p-0"
                        onClick={() => setShowNewPassword(!showNewPassword)}
                      >
                        {showNewPassword ? (
                          <EyeOff className="h-4 w-4" />
                        ) : (
                          <Eye className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="confirmPassword">Confirm New Password</Label>
                    <div className="relative">
                      <Input
                        id="confirmPassword"
                        type={showConfirmPassword ? "text" : "password"}
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        placeholder="Confirm your new password"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-2 top-1/2 -translate-y-1/2 h-7 w-7 p-0"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      >
                        {showConfirmPassword ? (
                          <EyeOff className="h-4 w-4" />
                        ) : (
                          <Eye className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                </div>
                
                <div className="bg-muted p-4 rounded-lg">
                  <h4 className="font-medium mb-2">Password Requirements:</h4>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• At least 8 characters long</li>
                    <li>• Contains both letters and numbers</li>
                    <li>• Use a unique password not used elsewhere</li>
                  </ul>
                </div>
                
                <Separator />
                
                <div className="flex gap-4">
                  <Button 
                    onClick={() => {
                      if (newPassword !== confirmPassword) {
                        toast({
                          title: "Password Mismatch",
                          description: "New password and confirmation don't match.",
                          variant: "destructive",
                        });
                        return;
                      }
                      if (newPassword.length < 8) {
                        toast({
                          title: "Password Too Short",
                          description: "Password must be at least 8 characters long.",
                          variant: "destructive",
                        });
                        return;
                      }
                      changePasswordMutation.mutate({
                        currentPassword,
                        newPassword
                      });
                    }}
                    disabled={changePasswordMutation.isPending || !currentPassword || !newPassword || !confirmPassword}
                    className="bg-village-wine hover:bg-village-wine/90"
                  >
                    {changePasswordMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Changing Password...
                      </>
                    ) : (
                      <>
                        <Lock className="mr-2 h-4 w-4" />
                        Change Password
                      </>
                    )}
                  </Button>
                  
                  <Button
                    variant="outline"
                    onClick={() => {
                      setCurrentPassword('');
                      setNewPassword('');
                      setConfirmPassword('');
                    }}
                  >
                    Clear Form
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Privacy & Access - Parent Only */}
          {!isSitter && (
            <TabsContent value="privacy" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="w-5 h-5" />
                  Privacy & Access Control
                </CardTitle>
                <CardDescription>
                  Manage who can see your information and access your account
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Profile Visibility */}
                <div className="space-y-4">
                  <h4 className="font-medium">Profile Visibility</h4>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Booking History Visible</p>
                      <p className="text-sm text-muted-foreground">
                        Show your booking history to trusted sitters
                      </p>
                    </div>
                    <Switch 
                      checked={userData?.bookingHistoryVisible}
                      onCheckedChange={(checked) => 
                        updatePreferencesMutation.mutate({ bookingHistoryVisible: checked })
                      }
                    />
                  </div>
                </div>

                <Separator />

                {/* Trusted Partners - Invite and Manage */}
                <div className="space-y-4">
                  <h4 className="font-medium">Trusted Partners</h4>
                  <p className="text-sm text-muted-foreground">
                    Grant other parents access to book sitters on your behalf and manage your children's care
                  </p>
                  
                  {/* Invite Component */}
                  <InvitePartner onInviteSent={() => queryClient.invalidateQueries({ queryKey: ['/api/account/settings'] })} />
                  
                  {/* Trusted Accounts List with Revoke Functionality */}
                  <TrustedAccountsList />
                </div>

                <Separator />

                {/* Referrals */}
                <div className="space-y-4">
                  <h4 className="font-medium">Referral Program</h4>
                  {referrals.length > 0 ? (
                    <div className="space-y-2">
                      {referrals.map((referral: any) => (
                        <div key={referral.id} className="flex items-center justify-between p-3 border rounded-lg">
                          <div>
                            <p className="text-sm font-medium">Code: {referral.code}</p>
                            <p className="text-xs text-muted-foreground">
                              {referral.status === 'completed' ? 'Completed' : 'Active'}
                              {referral.referredEmail && ` • ${referral.referredEmail}`}
                            </p>
                          </div>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => copyReferralCode(referral.code)}
                          >
                            <Copy className="w-4 h-4 mr-2" />
                            Copy
                          </Button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground">No active referrals</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          )}

          {/* Payment & Credits - Parent Only */}
          {!isSitter && (
            <TabsContent value="payment" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CreditCard className="w-5 h-5" />
                  Payment & Credits
                </CardTitle>
                <CardDescription>
                  Manage your payment methods, credits, and download receipts
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Credit Balance */}
                <div className="p-4 bg-village-wine/5 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Available Credits</h4>
                      <p className="text-2xl font-bold text-village-wine">${totalCredits.toFixed(2)}</p>
                    </div>
                    <div className="w-12 h-12 bg-village-wine/10 rounded-full flex items-center justify-center">
                      <DollarSign className="w-6 h-6 text-village-wine" />
                    </div>
                  </div>
                </div>

                {/* Credit History */}
                <div className="space-y-4">
                  <h4 className="font-medium">Credit History</h4>
                  {credits.length > 0 ? (
                    <div className="space-y-2">
                      {credits.map((credit: any) => (
                        <div key={credit.id} className="flex items-center justify-between p-3 border rounded-lg">
                          <div>
                            <p className="text-sm font-medium">{credit.description}</p>
                            <p className="text-xs text-muted-foreground">
                              {new Date(credit.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-medium text-green-600">
                              +${parseFloat(credit.amount).toFixed(2)}
                            </span>
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => downloadReceipt(credit.id)}
                            >
                              <Download className="w-4 h-4 mr-2" />
                              Receipt
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground">No credit history</p>
                  )}
                </div>

                <Separator />

                {/* Payment Methods */}
                <div className="space-y-4">
                  <h4 className="font-medium">Payment Methods</h4>
                  {isSitter ? (
                    <Button 
                      variant="outline" 
                      onClick={() => {
                        toast({
                          title: "Payment Setup",
                          description: "Stripe Connect integration will be available soon. Contact support for early access.",
                        });
                      }}
                    >
                      <CreditCard className="w-4 h-4 mr-2" />
                      Set Up Bank Account
                    </Button>
                  ) : (
                    <Link href="/parent/payment">
                      <Button variant="outline">
                        <CreditCard className="w-4 h-4 mr-2" />
                        Manage Payment Methods
                      </Button>
                    </Link>
                  )}
                </div>

                <Separator />

                {/* Receipt Downloads */}
                <div className="space-y-4">
                  <h4 className="font-medium">Receipt Downloads</h4>
                  <p className="text-sm text-muted-foreground">
                    Download receipts for workplace subsidies and corporate reimbursements
                  </p>
                  <div className="flex gap-2">
                    <Button variant="outline" onClick={() => {
                      const url = '/api/receipts/download?period=last-month';
                      window.open(url, '_blank');
                    }}>
                      <Download className="w-4 h-4 mr-2" />
                      Last Month
                    </Button>
                    <Button variant="outline" onClick={() => {
                      const url = '/api/receipts/download?period=last-quarter';
                      window.open(url, '_blank');
                    }}>
                      <Download className="w-4 h-4 mr-2" />
                      Last Quarter
                    </Button>
                    <Button variant="outline" onClick={() => {
                      const url = '/api/receipts/download?period=last-year';
                      window.open(url, '_blank');
                    }}>
                      <Download className="w-4 h-4 mr-2" />
                      Last Year
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          )}

          {/* Payment Methods - Sitter Only */}
          {isSitter && (
            <TabsContent value="payment" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CreditCard className="w-5 h-5" />
                  Payment Methods
                </CardTitle>
                <CardDescription>
                  Set up your bank account to receive payments from completed bookings
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="p-4 bg-village-wine/5 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium">Bank Account Setup</h4>
                      <p className="text-sm text-muted-foreground mt-1">
                        Connect your bank account to receive payments directly
                      </p>
                    </div>
                    <div className="w-12 h-12 bg-village-wine/10 rounded-full flex items-center justify-center">
                      <CreditCard className="w-6 h-6 text-village-wine" />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <h4 className="font-medium">Connect Bank Account</h4>
                        <p className="text-sm text-muted-foreground">
                          Securely link your bank account through Stripe to receive payments for completed sits. 
                          Your banking information is encrypted and never stored on our servers.
                        </p>
                      </div>
                      <Button 
                        className="bg-village-wine hover:bg-village-wine/90"
                        onClick={() => {
                          // Redirect to Stripe Connect onboarding
                          window.open('https://connect.stripe.com/express/oauth/authorize?redirect_uri=' + 
                            encodeURIComponent(window.location.origin + '/stripe-connect-return') + 
                            '&client_id=' + import.meta.env.VITE_STRIPE_CONNECT_CLIENT_ID || 'ca_QM8VZcQ8VZwQM8VZcQ8VZ', '_blank');
                        }}
                      >
                        Connect Account
                      </Button>
                    </div>
                  </div>

                  <div className="p-4 border rounded-lg bg-blue-50">
                    <div className="flex items-start gap-3">
                      <div className="w-5 h-5 bg-blue-100 rounded-full flex items-center justify-center mt-0.5">
                        <Shield className="w-3 h-3 text-blue-600" />
                      </div>
                      <div className="space-y-1">
                        <h4 className="font-medium text-blue-900">Secure & Protected</h4>
                        <p className="text-sm text-blue-700">
                          We use Stripe's bank-grade security to protect your financial information. 
                          Payments are processed directly to your account within 2-3 business days.
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <h4 className="font-medium">Payment Schedule</h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                      <div className="p-3 bg-gray-50 rounded">
                        <strong>Processing Time:</strong> 2-3 business days
                      </div>
                      <div className="p-3 bg-gray-50 rounded">
                        <strong>Payment Method:</strong> Direct bank transfer
                      </div>
                      <div className="p-3 bg-gray-50 rounded">
                        <strong>Minimum Payout:</strong> $10 NZD
                      </div>
                      <div className="p-3 bg-gray-50 rounded">
                        <strong>Platform Fee:</strong> 5% (already deducted)
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          )}

          {/* Booking Preferences - Parent Only */}
          {!isSitter && (
            <TabsContent value="booking" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="w-5 h-5" />
                  Booking Preferences
                </CardTitle>
                <CardDescription>
                  Set your default booking preferences and notification settings
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="defaultDuration">Default Booking Duration (hours)</Label>
                    <Select 
                      defaultValue={userData?.defaultBookingDuration?.toString() || '3'}
                      onValueChange={(value) => 
                        updatePreferencesMutation.mutate({ defaultBookingDuration: parseInt(value) })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">1 hour</SelectItem>
                        <SelectItem value="2">2 hours</SelectItem>
                        <SelectItem value="3">3 hours</SelectItem>
                        <SelectItem value="4">4 hours</SelectItem>
                        <SelectItem value="6">6 hours</SelectItem>
                        <SelectItem value="8">8 hours</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Sitter Suggestions</p>
                      <p className="text-sm text-muted-foreground">
                        Receive suggestions for new sitters in your area
                      </p>
                    </div>
                    <Switch 
                      checked={userData?.wantsSitterSuggestions}
                      onCheckedChange={(checked) => 
                        updatePreferencesMutation.mutate({ wantsSitterSuggestions: checked })
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Date Night Reminders</p>
                      <p className="text-sm text-muted-foreground">
                        Get reminded to book regular date nights
                      </p>
                    </div>
                    <Switch 
                      checked={userData?.wantsDateNightReminders}
                      onCheckedChange={(checked) => 
                        updatePreferencesMutation.mutate({ wantsDateNightReminders: checked })
                      }
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          )}

          {/* Safety & Support - Available to All Users */}
          <TabsContent value="safety" className="space-y-6">
              <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Heart className="w-5 h-5" />
                  Safety & Support
                </CardTitle>
                <CardDescription>
                  Access safety resources, report issues, and review policies
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Button variant="outline" className="justify-start h-auto p-4">
                    <div className="flex items-start gap-3">
                      <AlertCircle className="w-5 h-5 text-orange-500 mt-0.5" />
                      <div className="text-left">
                        <p className="font-medium">Report an Issue</p>
                        <p className="text-xs text-muted-foreground">
                          Report safety concerns or problems
                        </p>
                      </div>
                    </div>
                  </Button>

                  <Button variant="outline" className="justify-start h-auto p-4">
                    <div className="flex items-start gap-3">
                      <FileText className="w-5 h-5 text-blue-500 mt-0.5" />
                      <div className="text-left">
                        <p className="font-medium">Safety Guidelines</p>
                        <p className="text-xs text-muted-foreground">
                          Review our safety protocols
                        </p>
                      </div>
                    </div>
                  </Button>

                  <Button variant="outline" className="justify-start h-auto p-4">
                    <div className="flex items-start gap-3">
                      <Heart className="w-5 h-5 text-red-500 mt-0.5" />
                      <div className="text-left">
                        <p className="font-medium">First Aid Resources</p>
                        <p className="text-xs text-muted-foreground">
                          Access emergency procedures
                        </p>
                      </div>
                    </div>
                  </Button>

                  <Button variant="outline" className="justify-start h-auto p-4">
                    <div className="flex items-start gap-3">
                      <ExternalLink className="w-5 h-5 text-green-500 mt-0.5" />
                      <div className="text-left">
                        <p className="font-medium">Contact Support</p>
                        <p className="text-xs text-muted-foreground">
                          Get help from our team
                        </p>
                      </div>
                    </div>
                  </Button>
                </div>

                <Separator />

                <div className="space-y-2">
                  <h4 className="font-medium">Legal & Policies</h4>
                  <div className="space-y-2">
                    <Link href="/terms">
                      <Button variant="ghost" className="justify-start w-full">
                        <FileText className="w-4 h-4 mr-2" />
                        Terms of Service
                      </Button>
                    </Link>
                    <Link href="/privacy">
                      <Button variant="ghost" className="justify-start w-full">
                        <Shield className="w-4 h-4 mr-2" />
                        Privacy Policy
                      </Button>
                    </Link>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Newsletter Preferences */}
          <TabsContent value="newsletter" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell className="w-5 h-5" />
                  Newsletter & Notifications
                </CardTitle>
                <CardDescription>
                  Manage your communication preferences and notification settings
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Push Notifications</p>
                      <p className="text-sm text-muted-foreground">
                        Receive instant notifications for booking updates
                      </p>
                    </div>
                    <Switch 
                      checked={userData?.pushNotificationsEnabled}
                      onCheckedChange={(checked) => 
                        updatePreferencesMutation.mutate({ pushNotificationsEnabled: checked })
                      }
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Weekly Newsletter</p>
                      <p className="text-sm text-muted-foreground">
                        Get weekly tips and updates from The Village Co
                      </p>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Booking Reminders</p>
                      <p className="text-sm text-muted-foreground">
                        Receive reminders about upcoming bookings
                      </p>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Special Offers</p>
                      <p className="text-sm text-muted-foreground">
                        Get notified about promotions and special events
                      </p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Danger Zone */}
          <TabsContent value="danger" className="space-y-6">
            <Card className="border-red-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-red-600">
                  <AlertTriangle className="w-5 h-5" />
                  Account Cancellation
                </CardTitle>
                <CardDescription>
                  Manage your account status and data
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    These actions cannot be undone. Please proceed with caution.
                  </AlertDescription>
                </Alert>

                <div className="space-y-4">
                  <div className="p-4 border border-red-200 rounded-lg">
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <h4 className="font-medium text-red-900">Deactivate Account</h4>
                        <p className="text-sm text-red-700">
                          Temporarily disable your account. You can reactivate it by logging in again.
                        </p>
                      </div>
                      <Dialog open={showDeactivateDialog} onOpenChange={setShowDeactivateDialog}>
                        <DialogTrigger asChild>
                          <Button variant="outline" className="border-red-200 text-red-600 hover:bg-red-50">
                            Deactivate
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Deactivate Account</DialogTitle>
                            <DialogDescription>
                              Are you sure you want to deactivate your account? You can reactivate it by logging in again.
                            </DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4">
                            <div className="space-y-2">
                              <Label htmlFor="reason">Reason for deactivation (optional)</Label>
                              <Select onValueChange={setDeactivationReason}>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select a reason" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="break">Taking a break</SelectItem>
                                  <SelectItem value="privacy">Privacy concerns</SelectItem>
                                  <SelectItem value="cost">Cost concerns</SelectItem>
                                  <SelectItem value="other">Other</SelectItem>
                                </SelectContent>
                              </Select>
                            </div>
                          </div>
                          <DialogFooter>
                            <Button variant="outline" onClick={() => setShowDeactivateDialog(false)}>
                              Cancel
                            </Button>
                            <Button 
                              variant="destructive"
                              onClick={() => {
                                deactivateAccountMutation.mutate();
                                setShowDeactivateDialog(false);
                              }}
                              disabled={deactivateAccountMutation.isPending}
                            >
                              {deactivateAccountMutation.isPending ? 'Deactivating...' : 'Deactivate Account'}
                            </Button>
                          </DialogFooter>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </div>

                  <div className="p-4 border border-red-300 rounded-lg bg-red-50">
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <h4 className="font-medium text-red-900">Delete Account</h4>
                        <p className="text-sm text-red-700">
                          Permanently delete your account and all associated data. This action cannot be undone.
                        </p>
                      </div>
                      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
                        <DialogTrigger asChild>
                          <Button variant="destructive">
                            <Trash2 className="w-4 h-4 mr-2" />
                            Delete
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Delete Account Permanently</DialogTitle>
                            <DialogDescription>
                              This action cannot be undone. This will permanently delete your account and remove all your data.
                            </DialogDescription>
                          </DialogHeader>
                          <Alert className="border-red-200 bg-red-50">
                            <AlertTriangle className="h-4 w-4 text-red-600" />
                            <AlertDescription className="text-red-700">
                              All your bookings, messages, and account data will be permanently lost.
                            </AlertDescription>
                          </Alert>
                          <DialogFooter>
                            <Button variant="outline" onClick={() => setShowDeleteDialog(false)}>
                              Cancel
                            </Button>
                            <Button variant="destructive">
                              <Trash2 className="w-4 h-4 mr-2" />
                              Delete Account Forever
                            </Button>
                          </DialogFooter>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}