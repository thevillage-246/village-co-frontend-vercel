import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, Users, Shield, Calendar } from "lucide-react";
import { Link } from "wouter";

export default function WelcomeRealUsers() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 to-orange-50 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <Heart className="h-16 w-16 text-[#8B4B5C] mx-auto mb-6" />
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Welcome to The Village Co.
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Your trusted community for babysitting in New Zealand
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              className="bg-[#8B4B5C] hover:bg-[#7A4051] text-white px-8 py-3"
              onClick={() => window.location.href = "/signup"}
            >
              Join as a Parent
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="border-[#8B4B5C] text-[#8B4B5C] hover:bg-[#8B4B5C] hover:text-white px-8 py-3"
              onClick={() => window.location.href = "/sitter/signup"}
            >
              Become a Sitter
            </Button>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <Card className="text-center">
            <CardHeader>
              <Shield className="h-12 w-12 text-[#8B4B5C] mx-auto mb-4" />
              <CardTitle className="text-lg">Safety First</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                All sitters are verified with background checks and identity verification through Veriff
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <Users className="h-12 w-12 text-[#8B4B5C] mx-auto mb-4" />
              <CardTitle className="text-lg">Trusted Community</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Connect with verified sitters in your local area, recommended by other parents
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <Calendar className="h-12 w-12 text-[#8B4B5C] mx-auto mb-4" />
              <CardTitle className="text-lg">Easy Booking</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Book trusted sitters with just a few taps. Real-time messaging and secure payments
              </CardDescription>
            </CardContent>
          </Card>
        </div>

        {/* Call to Action */}
        <Card className="bg-[#8B4B5C] text-white">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl mb-4">Ready to Get Started?</CardTitle>
            <CardDescription className="text-white/90 text-lg">
              Join thousands of families across New Zealand who trust The Village Co. for their childcare needs
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/signup">
              <Button size="lg" variant="secondary" className="w-full sm:w-auto">
                Create Parent Account
              </Button>
            </Link>
            <Link href="/login">
              <Button size="lg" variant="outline" className="w-full sm:w-auto border-white text-white hover:bg-white hover:text-[#8B4B5C]">
                Already Have an Account?
              </Button>
            </Link>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center mt-12 text-gray-600">
          <p className="text-sm">
            Questions? Contact us at <a href="mailto:hello@thevillageco.nz" className="text-[#8B4B5C] hover:underline">hello@thevillageco.nz</a>
          </p>
        </div>
      </div>
    </div>
  );
}