import { useState, useCallback } from "react";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Shield, ArrowRight, ArrowLeft } from "lucide-react";
import OnboardingStep1 from "@/components/onboarding/OnboardingStep1New";
import OnboardingStep2 from "@/components/onboarding/OnboardingStep2";
import OnboardingStep3 from "@/components/onboarding/OnboardingStep3";
import { CARE_NEEDS } from "@shared/schema";

export interface OnboardingData {
  // Step 1 data
  firstName: string;
  email: string;
  phoneNumber: string;
  city: string;
  suburb?: string; // Keep for backward compatibility
  careNeeds: string[];
  
  // Step 2 data
  selectedSitterId?: number;
  
  // Step 3 data
  children: Array<{
    name: string;
    age: number;
    allergies?: string;
    notes?: string;
  }>;
  emergencyContactName: string;
  emergencyContactPhone: string;
  familyPhoto?: string;
}

export default function Onboarding() {
  const [, navigate] = useLocation();
  const [currentStep, setCurrentStep] = useState(1);
  const [onboardingData, setOnboardingData] = useState<OnboardingData>({
    firstName: "",
    email: "",
    phoneNumber: "",
    city: "",
    careNeeds: [],
    children: [],
    emergencyContactName: "",
    emergencyContactPhone: ""
  });

  const totalSteps = 3;
  const progress = (currentStep / totalSteps) * 100;

  const updateData = useCallback((stepData: Partial<OnboardingData>) => {
    setOnboardingData(prev => ({ ...prev, ...stepData }));
  }, []);

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleComplete = async () => {
    try {
      console.log('🚀 Starting onboarding completion with data:', onboardingData);
      
      // First try to register a new account
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: onboardingData.email,
          password: 'village2025!', // Temporary password, user will be prompted to change
          username: onboardingData.firstName,
          role: 'parent'
        })
      });

      console.log('📝 Registration response status:', response.status);
      
      if (response.ok) {
        const user = await response.json();
        console.log('✅ User created successfully:', user);
        
        // Create parent profile
        const profileResponse = await fetch(`/api/parents/${user.id}/profile`, {
          method: 'POST',
          headers: { 
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${user.token}`
          },
          body: JSON.stringify({
            bio: `Parent from ${onboardingData.city} looking for reliable childcare support.`,
            address: onboardingData.city,
            phone: onboardingData.phoneNumber,
            emergencyContactName: onboardingData.emergencyContactName,
            emergencyContactPhone: onboardingData.emergencyContactPhone,
            children: onboardingData.children.map(child => 
              `${child.name} (${child.age} years old)${child.allergies ? ` - Allergies: ${child.allergies}` : ''}${child.notes ? ` - Notes: ${child.notes}` : ''}`
            ).join('; '),
            preferences: `Care needs: ${onboardingData.careNeeds.join(', ')}`
          })
        });

        console.log('👤 Profile creation response status:', profileResponse.status);

        // Redirect based on selected sitter or to dashboard
        if (onboardingData.selectedSitterId) {
          console.log('🎯 Redirecting to book sitter:', onboardingData.selectedSitterId);
          navigate(`/book/${onboardingData.selectedSitterId}`);
        } else {
          console.log('🏠 Redirecting to parent dashboard');
          navigate('/parent/dashboard');
        }
      } else {
        const errorData = await response.json();
        console.error('❌ Registration failed:', response.status, errorData);
        
        // If account already exists, try to log them in automatically
        if (errorData.message && errorData.message.includes('already exists')) {
          console.log('🔄 Account exists, attempting automatic login...');
          
          // Try to login with the default password
          const loginResponse = await fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              email: onboardingData.email,
              password: 'welcome2025!' // Try with the standard password
            })
          });

          if (loginResponse.ok) {
            const loginData = await loginResponse.json();
            console.log('✅ Auto-login successful, redirecting to dashboard');
            
            // Store auth token
            localStorage.setItem('authToken', loginData.token);
            
            // Redirect to dashboard or booking
            if (onboardingData.selectedSitterId) {
              navigate(`/book/${onboardingData.selectedSitterId}`);
            } else {
              navigate('/parent/dashboard');
            }
          } else {
            // Auto-login failed, ask user to log in manually
            const shouldLogin = confirm(`An account with ${onboardingData.email} already exists. Would you like to log in?`);
            if (shouldLogin) {
              navigate('/login');
            }
          }
        } else {
          alert(`Registration failed: ${errorData.message || 'Unknown error'}`);
        }
      }
    } catch (error) {
      console.error('❌ Onboarding completion failed:', error);
      alert('Something went wrong during registration. Please try again.');
    }
  };

  const getStepTitle = () => {
    switch (currentStep) {
      case 1: return "Tell Us About You";
      case 2: return "Meet Your Sitters";
      case 3: return "Create Your Family Profile";
      default: return "";
    }
  };

  const getStepSubtitle = () => {
    switch (currentStep) {
      case 1: return "We start with you—not your calendar. Let's build your trusted village.";
      case 2: return "These sitters passed our background checks, got to know us, and are ready to support your family.";
      case 3: return "This info helps your sitter know what matters most—so you can relax.";
      default: return "";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-village-linen to-village-rose/10">
      <div className="container max-w-4xl mx-auto px-3 sm:px-4 py-4 sm:py-8">
        {/* Header */}
        <div className="text-center mb-6 sm:mb-8">
          <div className="flex flex-col sm:flex-row items-center justify-center gap-2 mb-3 sm:mb-4">
            <h1 className="text-2xl sm:text-3xl font-bold text-village-wine">The Village Co</h1>
            <Badge variant="secondary" className="bg-village-eucalyptus/20 text-village-eucalyptus border-village-eucalyptus/30 text-xs sm:text-sm">
              <Shield className="w-3 h-3 mr-1" />
              The Village Promise
            </Badge>
          </div>
          <p className="text-village-taupe/80 text-xs sm:text-sm">Every sitter vetted. Every booking insured.</p>
        </div>

        {/* Progress Bar */}
        <div className="mb-6 sm:mb-8">
          <div className="flex justify-between items-center mb-2">
            <span className="text-xs sm:text-sm font-medium text-village-wine">Step {currentStep} of {totalSteps}</span>
            <span className="text-xs sm:text-sm text-village-taupe/70">{Math.round(progress)}% complete</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Step Content */}
        <Card className="border-village-wine/20 shadow-lg">
          <CardContent className="p-4 sm:p-6 lg:p-8">
            <div className="text-center mb-6 sm:mb-8">
              <h2 className="text-xl sm:text-2xl font-bold text-village-wine mb-2">{getStepTitle()}</h2>
              <p className="text-village-taupe/80 max-w-2xl mx-auto text-sm sm:text-base">{getStepSubtitle()}</p>
            </div>

            {currentStep === 1 && (
              <OnboardingStep1 
                data={onboardingData} 
                updateData={updateData}
                onNext={handleNext}
              />
            )}

            {currentStep === 2 && (
              <OnboardingStep2 
                data={onboardingData} 
                updateData={updateData}
                onNext={handleNext}
              />
            )}

            {currentStep === 3 && (
              <OnboardingStep3 
                data={onboardingData} 
                updateData={updateData}
                onComplete={handleComplete}
              />
            )}
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="mt-6 sm:mt-8">
          {/* Mobile: Stack vertically */}
          <div className="block sm:hidden space-y-4">
            <div className="text-center">
              <p className="text-sm text-village-taupe/70 mb-1">
                "I didn't just find childcare—I found myself again."
              </p>
              <p className="text-xs text-village-taupe/50">— Sarah, Village Co parent</p>
            </div>
            
            {currentStep > 1 && (
              <div className="flex justify-center">
                <Button
                  variant="outline"
                  onClick={handleBack}
                  className="border-village-wine/30 text-village-wine hover:bg-village-wine/10"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back
                </Button>
              </div>
            )}
          </div>

          {/* Desktop: Side by side layout */}
          <div className="hidden sm:flex justify-between items-center">
            <Button
              variant="outline"
              onClick={handleBack}
              disabled={currentStep === 1}
              className="border-village-wine/30 text-village-wine hover:bg-village-wine/10"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>

            <div className="text-center">
              <p className="text-sm text-village-taupe/70 mb-2">
                "I didn't just find childcare—I found myself again."
              </p>
              <p className="text-xs text-village-taupe/50">— Sarah, Village Co parent</p>
            </div>

            <div className="w-20" /> {/* Spacer to balance layout */}
          </div>
        </div>
      </div>
    </div>
  );
}