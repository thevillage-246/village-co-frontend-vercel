import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Smartphone, 
  Download, 
  CheckCircle, 
  ExternalLink,
  Zap,
  Shield,
  Globe
} from 'lucide-react';
import { MobileAppFeatures } from '@/components/MobileAppFeatures';
import { PWAFeatures } from '@/components/PWAFeatures';
import { useCapacitor } from '@/hooks/useCapacitor';

const MobileAppTest: React.FC = () => {
  const { isNative, platform, isReady } = useCapacitor();

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 space-y-8">
        {/* Header */}
        <div className="text-center">
          <h1 className="text-3xl font-bold text-village-wine mb-4">
            The Village Co. Mobile App
          </h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Experience The Village Co. as a native mobile app with enhanced features, 
            offline support, and seamless device integration.
          </p>
        </div>

        {/* App Status */}
        <Card className="max-w-4xl mx-auto">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Smartphone className="w-5 h-5" />
              Current Environment
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="font-semibold text-lg">
                  {isNative ? '🎉 Native Mobile App' : '🌐 Progressive Web App'}
                </h3>
                <p className="text-gray-600">
                  {isNative 
                    ? 'You\'re running the native mobile app with full device integration.' 
                    : 'You\'re using the web version. Install the mobile app for the best experience.'
                  }
                </p>
              </div>
              <Badge variant={isNative ? "default" : "secondary"} className="text-sm">
                {platform} {isNative ? "(Native)" : "(Web)"}
              </Badge>
            </div>

            {!isNative && (
              <div className="bg-village-linen p-4 rounded-lg">
                <h4 className="font-semibold mb-2 flex items-center gap-2">
                  <Download className="w-4 h-4" />
                  Install Mobile App
                </h4>
                <p className="text-sm text-gray-600 mb-3">
                  Get the full Village Co experience with:
                </p>
                <ul className="text-sm space-y-1 mb-4">
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-3 h-3 text-green-600" />
                    Offline access to bookings and messages
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-3 h-3 text-green-600" />
                    Push notifications for real-time updates
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-3 h-3 text-green-600" />
                    Camera access for verification photos
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle className="w-3 h-3 text-green-600" />
                    Location services for finding nearby sitters
                  </li>
                </ul>
                <div className="flex gap-2">
                  <Button size="sm" className="flex items-center gap-2">
                    <Download className="w-3 h-3" />
                    Download for iOS
                    <ExternalLink className="w-3 h-3" />
                  </Button>
                  <Button size="sm" variant="outline" className="flex items-center gap-2">
                    <Download className="w-3 h-3" />
                    Download for Android
                    <ExternalLink className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Mobile Features Test */}
        <MobileAppFeatures />

        {/* PWA Features */}
        <PWAFeatures showTitle={false} />

        {/* Technical Information */}
        <Card className="max-w-4xl mx-auto">
          <CardHeader>
            <CardTitle>Technical Implementation</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-12 h-12 bg-village-wine/10 rounded-lg flex items-center justify-center mx-auto mb-3">
                  <Zap className="w-6 h-6 text-village-wine" />
                </div>
                <h3 className="font-semibold mb-2">Capacitor Framework</h3>
                <p className="text-sm text-gray-600">
                  Cross-platform native app development with web technologies
                </p>
              </div>
              
              <div className="text-center">
                <div className="w-12 h-12 bg-village-wine/10 rounded-lg flex items-center justify-center mx-auto mb-3">
                  <Shield className="w-6 h-6 text-village-wine" />
                </div>
                <h3 className="font-semibold mb-2">Native Plugins</h3>
                <p className="text-sm text-gray-600">
                  Camera, geolocation, notifications, and device integration
                </p>
              </div>
              
              <div className="text-center">
                <div className="w-12 h-12 bg-village-wine/10 rounded-lg flex items-center justify-center mx-auto mb-3">
                  <Globe className="w-6 h-6 text-village-wine" />
                </div>
                <h3 className="font-semibold mb-2">PWA Compatible</h3>
                <p className="text-sm text-gray-600">
                  Works as both native app and progressive web app
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* App Store Information */}
        <Card className="max-w-4xl mx-auto">
          <CardHeader>
            <CardTitle>App Store Deployment</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <h4 className="font-semibold text-green-800 mb-2">✅ Android Ready</h4>
                <p className="text-sm text-green-700">
                  Android build configuration complete with all Capacitor plugins installed and synced.
                  Ready for Google Play Store deployment.
                </p>
              </div>
              
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <h4 className="font-semibold text-yellow-800 mb-2">⚠️ iOS Configuration</h4>
                <p className="text-sm text-yellow-700">
                  iOS platform ready with minor Podfile configuration needed. 
                  Requires Xcode on macOS for final build and App Store deployment.
                </p>
              </div>
              
              <div className="text-sm text-gray-600">
                <p><strong>App Details:</strong></p>
                <ul className="mt-2 space-y-1">
                  <li>• <strong>Name:</strong> The Village Co.</li>
                  <li>• <strong>Bundle ID:</strong> nz.thevillageco.app</li>
                  <li>• <strong>Version:</strong> 1.0.0</li>
                  <li>• <strong>Target Platforms:</strong> iOS 13+, Android 7+</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default MobileAppTest;