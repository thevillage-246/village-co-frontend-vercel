import { useEffect } from "react";

export default function Subscribe() {
  useEffect(() => {
    // Create mailto link for subscription requests
    const subject = encodeURIComponent("add me to your mailing list");
    const mailtoUrl = `mailto:subscribe@thevillageco.nz?subject=${subject}`;
    window.location.href = mailtoUrl;
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-rose-50 to-orange-50">
      <div className="text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-rose-600 mx-auto mb-4"></div>
        <p className="text-gray-600">Opening your email client for subscription...</p>
      </div>
    </div>
  );
}