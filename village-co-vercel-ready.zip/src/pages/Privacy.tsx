import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export default function Privacy() {
  return (
    <div className="container mx-auto py-10 px-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl text-center text-wine">Privacy Policy</CardTitle>
        </CardHeader>
        <CardContent className="prose max-w-none">
          <p>Last Updated: May 10, 2025</p>
          
          <p>At The Village Co., we take your privacy seriously. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our platform.</p>
          
          <h2>Information We Collect</h2>
          <p>We collect information you provide directly to us, including:</p>
          <ul>
            <li>Personal identification information (name, email address, phone number)</li>
            <li>Profile information (profile photos, biographies)</li>
            <li>Verification documents for sitters</li>
            <li>Payment information</li>
            <li>Communications between users</li>
            <li>Ratings and reviews</li>
          </ul>
          
          <h2>How We Use Your Information</h2>
          <p>We use the information we collect to:</p>
          <ul>
            <li>Provide, maintain, and improve our platform</li>
            <li>Process transactions and send related information</li>
            <li>Verify sitter identities and qualifications</li>
            <li>Send you technical notices, updates, and administrative messages</li>
            <li>Respond to your comments, questions, and customer service requests</li>
            <li>Monitor and analyze trends, usage, and activities</li>
            <li>Detect, investigate, and prevent fraudulent transactions and other illegal activities</li>
          </ul>
          
          <h2>Information Sharing</h2>
          <p>We may share your information with:</p>
          <ul>
            <li>Other users as necessary to facilitate bookings</li>
            <li>Third-party vendors, consultants, and service providers</li>
            <li>Law enforcement agencies when required by law</li>
          </ul>
          
          <h2>Data Retention</h2>
          <p>We retain your information for as long as your account is active or as needed to provide services. We may retain certain information to prevent fraud, collect fees, resolve disputes, assist with investigations, enforce our terms, and take other actions permitted by law.</p>
          
          <h2>Security</h2>
          <p>We implement reasonable measures to help protect your information from loss, theft, misuse, and unauthorized access, disclosure, alteration, and destruction.</p>
          
          <h2>Your Choices</h2>
          <p>You can access, update, or delete your account information at any time by logging into your account settings. You may also contact us directly to request deletion of your personal information.</p>
          
          <h2>Children's Privacy</h2>
          <p>Our platform is not intended for children under 18 years of age, and we do not knowingly collect personal information from children under 18.</p>
          
          <h2>Changes to This Privacy Policy</h2>
          <p>We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last Updated" date.</p>
          
          <h2>Contact Us</h2>
          <p>If you have any questions about this Privacy Policy, please contact us at privacy@ittakesavillage.nz.</p>
        </CardContent>
      </Card>
    </div>
  );
}