import { Button } from "@/components/ui/button";
import SEO, { SEOConfigs } from '@/components/SEO';

export default function Hotels() {
  return (
    <>
      <SEO {...SEOConfigs.hotels} />
      <div className="min-h-screen bg-[#F9F5F0]">
      {/* Hero Section */}
      <section className="px-4 py-24 bg-[#6B3E4B] text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6" style={{ fontFamily: 'Satoshi, sans-serif' }}>
            Luxury for the whole family.
          </h1>
          <p className="text-xl md:text-2xl mb-8 leading-relaxed max-w-3xl mx-auto" style={{ fontFamily: 'DM Sans, sans-serif' }}>
            Premium childcare your guests will trust without leaving the room.
          </p>
          <p className="text-lg leading-relaxed max-w-3xl mx-auto mb-8" style={{ fontFamily: 'DM Sans, sans-serif' }}>
            We partner with leading hotels to offer a bespoke babysitting experience that matches your brand's standard of care. 
            Whether it's a parent needing a solo spa moment or a couple planning a night out, we make sure they can do it, worry-free.
          </p>
        </div>
      </section>

      {/* What Makes Us Different */}
      <section className="px-4 py-20 bg-white">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#6B3E4B] mb-12" style={{ fontFamily: 'Satoshi, sans-serif' }}>
            What Makes Us Different
          </h2>
          
          <div className="bg-white rounded-xl shadow-lg p-8 border-0">
            <div className="space-y-6 text-lg text-gray-700">
              <div className="flex items-start">
                <div className="w-2 h-2 bg-[#6B3E4B] rounded-full mt-3 mr-4 flex-shrink-0"></div>
                <span style={{ fontFamily: 'DM Sans, sans-serif' }}>Discreet, elegant childcare that blends seamlessly into the guest experience.</span>
              </div>
              <div className="flex items-start">
                <div className="w-2 h-2 bg-[#6B3E4B] rounded-full mt-3 mr-4 flex-shrink-0"></div>
                <span style={{ fontFamily: 'DM Sans, sans-serif' }}>Vetted, verified sitters trained to deliver peace of mind, not just playtime.</span>
              </div>
              <div className="flex items-start">
                <div className="w-2 h-2 bg-[#6B3E4B] rounded-full mt-3 mr-4 flex-shrink-0"></div>
                <span style={{ fontFamily: 'DM Sans, sans-serif' }}>Curated packages available by request, including wellness, concierge coordination, and more.</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Not Just a Babysitter */}
      <section className="px-4 py-20">
        <div className="max-w-4xl mx-auto text-center">
          <div className="bg-white rounded-xl shadow-lg p-8 border-0">
            <h2 className="text-3xl md:text-4xl font-bold text-[#6B3E4B] mb-8" style={{ fontFamily: 'Satoshi, sans-serif' }}>
              Not Just a Babysitter.
            </h2>
            <div className="space-y-6 text-lg text-gray-700 max-w-3xl mx-auto">
              <p style={{ fontFamily: 'DM Sans, sans-serif' }}>
                This isn't a listing site. And it's not a generic agency.
              </p>
              <p style={{ fontFamily: 'DM Sans, sans-serif' }}>
                We provide a curated guest amenity that aligns with the kind of experience your hotel is known for.
              </p>
              <p style={{ fontFamily: 'DM Sans, sans-serif' }}>
                We don't share all our methods online because the magic is in the model.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="px-4 py-20 bg-[#6B3E4B] text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6" style={{ fontFamily: 'Satoshi, sans-serif' }}>
            Want to elevate your family offering?
          </h2>
          <p className="text-xl mb-8" style={{ fontFamily: 'DM Sans, sans-serif' }}>
            We'd love to design something special for your guests.
          </p>
          <Button 
            size="lg" 
            className="bg-white text-[#6B3E4B] hover:bg-gray-100 px-8 py-4 text-lg rounded-xl shadow-lg"
            style={{ fontFamily: 'DM Sans, sans-serif' }}
            onClick={() => window.location.href = 'mailto:partnerships@thevillageco.nz?subject=Hotel Partnership Enquiry'}
          >
            Enquire about partnerships →
          </Button>
        </div>
      </section>
      </div>
    </>
  );
}