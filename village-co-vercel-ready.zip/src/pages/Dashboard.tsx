import React, { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/contexts/AuthContext';
import { USER_ROLES } from '@shared/schema';

export default function Dashboard() {
  const { currentUser, isLoading: authLoading } = useAuth();
  const [isLoading, setIsLoading] = useState(true);
  const [, navigate] = useLocation();
  
  useEffect(() => {
    const handleRedirect = async () => {
      // Set loading to false once auth state is determined
      if (!authLoading) {
        // Small delay for smoother UI transition
        const timer = setTimeout(async () => {
          setIsLoading(false);
          
          // Auto-redirect based on user role
          if (currentUser) {
            switch (currentUser.role) {
              case USER_ROLES.PARENT:
                // For parents, check if they have a profile first
                try {
                  const response = await fetch('/api/parent/profile/exists', {
                    headers: {
                      'Authorization': `Bearer ${localStorage.getItem('auth_token') || localStorage.getItem('authToken')}`,
                      'Content-Type': 'application/json'
                    }
                  });
                  
                  if (response.ok) {
                    const { hasProfile } = await response.json();
                    if (hasProfile) {
                      navigate('/parent/dashboard');
                    } else {
                      navigate('/create-profile');
                    }
                  } else {
                    // If we can't check profile status, default to dashboard
                    navigate('/parent/dashboard');
                  }
                } catch (error) {
                  console.error('Error checking parent profile:', error);
                  navigate('/parent/dashboard');
                }
                break;
              case USER_ROLES.SITTER:
                navigate('/sitter/dashboard');
                break;
              case USER_ROLES.ADMIN:
                navigate('/admin');
                break;
              default:
                console.log('Unknown role, defaulting to parent dashboard');
                navigate('/parent/dashboard');
            }
          } else {
            // Not logged in
            navigate('/login');
          }
        }, 500);
        
        return () => clearTimeout(timer);
      }
    };
    
    handleRedirect();
  }, [currentUser, authLoading, navigate]);
  
  // Loading state
  return (
    <div className="min-h-screen bg-gradient-to-br from-bone to-brushed-pink flex items-center justify-center">
      <div className="flex flex-col items-center gap-4">
        <div className="animate-spin h-8 w-8 border-4 border-village-wine border-t-transparent rounded-full"></div>
        <p className="text-almond-frost">Loading your Village Co. dashboard...</p>
      </div>
    </div>
  );
}