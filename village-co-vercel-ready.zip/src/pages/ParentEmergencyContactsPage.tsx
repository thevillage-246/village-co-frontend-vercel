import { useParams } from 'wouter';
import EmergencyContactQuickAdd from '@/components/parents/EmergencyContactQuickAdd';
import EmergencyContactsList from '@/components/parents/EmergencyContactsList';
import { Card, CardContent } from '@/components/ui/card';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Plus, X } from 'lucide-react';

export default function ParentEmergencyContactsPage() {
  const { parentId } = useParams<{ parentId: string }>();
  const [showAddForm, setShowAddForm] = useState(false);
  
  const handleSuccessfulAdd = () => {
    setShowAddForm(false);
  };
  
  const parentIdNumber = parseInt(parentId);
  
  return (
    <div className="container mx-auto px-4 py-4 md:py-8">
      <h1 className="text-2xl md:text-3xl font-bold text-wine mb-4 md:mb-6">Emergency Contacts</h1>
      <p className="text-sm text-gray-600 mb-6">Manage your emergency contacts for babysitting bookings</p>
      
      <div className="flex flex-col gap-6">
        {/* Mobile-first layout */}
        <div className="order-2 md:order-1">
          <EmergencyContactsList parentId={parentIdNumber} />
        </div>
        
        <div className="order-1 md:order-2">
          {showAddForm ? (
            <Card className="bg-white border-2 border-village-wine/20">
              <CardContent className="p-4">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="font-semibold text-village-wine">Add New Contact</h3>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="h-8 w-8 p-0 text-gray-500 hover:text-gray-700"
                    onClick={() => setShowAddForm(false)}
                  >
                    <X size={16} />
                  </Button>
                </div>
                <EmergencyContactQuickAdd 
                  parentId={parentIdNumber} 
                  onSuccess={handleSuccessfulAdd}
                />
              </CardContent>
            </Card>
          ) : (
            <Card className="bg-gradient-to-br from-village-wine/5 to-rose-50 border-2 border-village-wine/20">
              <CardContent className="p-6 text-center">
                <div className="flex flex-col items-center space-y-4">
                  <div className="w-12 h-12 bg-village-wine/10 rounded-full flex items-center justify-center">
                    <Plus size={20} className="text-village-wine" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-village-wine mb-2">Add Emergency Contact</h3>
                    <p className="text-sm text-gray-600 leading-relaxed">
                      Add trusted contacts that sitters can reach during babysitting sessions if needed.
                    </p>
                  </div>
                  <Button 
                    className="w-full bg-village-wine hover:bg-village-wine/90 text-white font-medium py-3" 
                    onClick={() => setShowAddForm(true)}
                  >
                    <Plus size={16} className="mr-2" /> 
                    Add Contact
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}