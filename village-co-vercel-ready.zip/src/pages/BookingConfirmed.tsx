import { useLocation } from 'wouter';
import { useEffect, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { apiRequest } from '@/lib/queryClient';
import { CalendarCheck, Clock, MapPin, AlertCircle, CheckCircle2 } from 'lucide-react';
import { formatDate, formatTime } from '@/lib/utils';

export default function BookingConfirmed() {
  const [, navigate] = useLocation();
  const [booking, setBooking] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  
  // Get the booking ID from the URL search params
  const searchParams = new URLSearchParams(window.location.search);
  const bookingId = searchParams.get('id');
  
  useEffect(() => {
    if (!bookingId) {
      setError('No booking ID provided');
      setLoading(false);
      return;
    }
    
    const fetchBooking = async () => {
      try {
        const response = await apiRequest('GET', `/api/bookings/${bookingId}`);
        const data = await response.json();
        setBooking(data);
      } catch (err) {
        setError('Failed to load booking details');
        console.error('Error fetching booking:', err);
      } finally {
        setLoading(false);
      }
    };
    
    fetchBooking();
  }, [bookingId]);
  
  if (loading) {
    return (
      <div className="container max-w-md py-12 flex flex-col items-center justify-center">
        <div className="w-8 h-8 border-4 rounded-full border-wine border-t-transparent animate-spin"></div>
        <p className="mt-4 text-gray-600">Loading booking details...</p>
      </div>
    );
  }
  
  if (error || !booking) {
    return (
      <div className="container max-w-md py-12">
        <Card className="border-red-200">
          <CardContent className="pt-6 flex flex-col items-center">
            <AlertCircle className="h-12 w-12 text-red-500 mb-4" />
            <h1 className="text-xl font-bold text-gray-900 mb-2">Booking Not Found</h1>
            <p className="text-gray-600 mb-6 text-center">
              {error || "We couldn't find the booking details you're looking for."}
            </p>
            <Button 
              onClick={() => navigate('/')}
              className="w-full bg-wine hover:bg-wine/90"
            >
              Go to Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }
  
  return (
    <div className="container max-w-md py-12">
      <Card className="border-green-200">
        <CardContent className="pt-6">
          <div className="flex flex-col items-center mb-6">
            <div className="h-16 w-16 rounded-full bg-green-100 flex items-center justify-center mb-4">
              <CheckCircle2 className="h-10 w-10 text-green-600" />
            </div>
            <h1 className="text-2xl font-bold text-center text-gray-900">Booking Confirmed!</h1>
            <p className="text-gray-600 text-center mt-2">
              Your booking has been confirmed and payment processed successfully.
            </p>
          </div>
          
          <div className="border-t border-gray-100 pt-6 mb-6">
            <h2 className="text-lg font-semibold mb-4">Booking Details</h2>
            
            <div className="space-y-4">
              <div className="flex items-start">
                <CalendarCheck className="h-5 w-5 text-wine mr-3 mt-0.5" />
                <div>
                  <p className="font-medium">Date</p>
                  <p className="text-gray-600">{formatDate(new Date(booking.date))}</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <Clock className="h-5 w-5 text-wine mr-3 mt-0.5" />
                <div>
                  <p className="font-medium">Time</p>
                  <p className="text-gray-600">
                    {formatTime(new Date(booking.startTime))} - {formatTime(new Date(booking.endTime))}
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <MapPin className="h-5 w-5 text-wine mr-3 mt-0.5" />
                <div>
                  <p className="font-medium">Location</p>
                  <p className="text-gray-600">{booking.location}</p>
                </div>
              </div>
              
              {booking.specialInstructions && (
                <div className="bg-linen p-3 rounded-md mb-3">
                  <p className="font-medium mb-1">Special Instructions</p>
                  <p className="text-gray-600 text-sm">{booking.specialInstructions}</p>
                </div>
              )}
              
              {booking.sitNotes && (
                <div className="bg-rose/10 text-rose px-4 py-3 rounded mb-4">
                  <h4 className="font-semibold">Additional Sit Details</h4>
                  <p className="text-sm">{booking.sitNotes}</p>
                </div>
              )}
            </div>
          </div>
          
          <div className="space-y-3">
            <Button 
              onClick={() => navigate(`/booking/${booking.id}`)}
              className="w-full bg-wine hover:bg-wine/90"
            >
              View Full Details
            </Button>
            <Button
              variant="outline"
              onClick={() => navigate('/messages')}
              className="w-full border-wine text-wine hover:bg-wine/10"
            >
              Message Your Sitter
            </Button>
            <Button
              variant="link"
              onClick={() => navigate('/')}
              className="w-full text-gray-500"
            >
              Return to Home
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}