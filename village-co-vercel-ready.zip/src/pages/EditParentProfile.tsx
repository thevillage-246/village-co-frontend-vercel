import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useLocation } from 'wouter';
import { Camera, Upload, Plus, Trash2, MapPin } from 'lucide-react';
import { SearchableSchoolSelect } from '@/components/ui/searchable-school-select';
import { GooglePlacesAutocomplete } from '@/components/GooglePlacesAutocomplete';

const editProfileSchema = z.object({
  displayName: z.string().optional(),
  bio: z.string().optional(),
  address: z.string().optional(),
  children: z.array(z.object({
    name: z.string().min(1, 'Child name is required'),
    age: z.number().min(0).max(18),
    needsAttention: z.boolean().optional(),
    notes: z.string().optional(),
  })).optional(),
  schoolDaycare: z.string().optional(),
  childrenInfo: z.string().optional(),
  defaultSpecialInstructions: z.string().optional(),
});

type FormData = z.infer<typeof editProfileSchema>;

const EditParentProfile = () => {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);

  const form = useForm<FormData>({
    resolver: zodResolver(editProfileSchema),
    defaultValues: {
      displayName: '',
      bio: '',
      address: '',
      children: [],
      schoolDaycare: '',
      childrenInfo: '',
      defaultSpecialInstructions: '',
    },
  });

  // Fetch user profile
  const { data: userProfile } = useQuery({
    queryKey: ['/api/auth/me'],
    enabled: !!user,
  });

  // Fetch parent profile
  const { data: parentProfile, refetch: refetchParentProfile } = useQuery({
    queryKey: [`/api/parents/${user?.id}/profile`],
    enabled: !!user?.id,
  });

  // Update form when data loads - prevent premature resets during save operations
  useEffect(() => {
    console.log('🔄 useEffect triggered - userProfile:', !!userProfile, 'parentProfile:', !!parentProfile, 'isSaving:', isSaving);
    if (userProfile && parentProfile !== undefined && !isSaving) {
      
      console.log('🔄 Raw parentProfile data:', parentProfile);

      const formData = {
        displayName: userProfile?.user?.first_name || userProfile?.user?.firstName || user?.first_name || user?.firstName || '',
        bio: (parentProfile as any)?.bio || '',
        address: (parentProfile as any)?.address || '',
        children: (() => {
          const childrenData = (parentProfile as any)?.children;
          console.log('🔄 Processing children data:', childrenData, 'type:', typeof childrenData);
          
          if (Array.isArray(childrenData)) {
            console.log('🔄 Children data is array:', childrenData);
            return childrenData;
          }
          if (typeof childrenData === 'string' && childrenData.trim()) {
            try {
              const parsed = JSON.parse(childrenData);
              console.log('🔄 Parsed children data from string:', parsed);
              return Array.isArray(parsed) ? parsed : [];
            } catch (e) {
              console.warn('🔄 Failed to parse children JSON:', e);
              return [];
            }
          }
          console.log('🔄 No valid children data, returning empty array');
          return [];
        })(),
        schoolDaycare: (parentProfile as any)?.schoolDaycare || '',
        childrenInfo: (parentProfile as any)?.childrenInfo || '',
        defaultSpecialInstructions: (parentProfile as any)?.defaultSpecialInstructions || '',
      };

      console.log('🔄 Setting form data with children:', formData);
      form.reset(formData);
    }
  }, [userProfile, parentProfile, form, isSaving]);

  // Upload photo mutation
  const uploadPhotoMutation = useMutation({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append('photo', file);
      
      const token = localStorage.getItem('auth_token') || localStorage.getItem('authToken');
      const response = await fetch('/api/upload/profile-photo', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        },
        body: formData,
      });
      
      if (!response.ok) {
        throw new Error('Photo upload failed');
      }
      
      return response.json();
    },
  });

  // Update user mutation
  const updateUserMutation = useMutation({
    mutationFn: async (data: { username: string; profileImage?: string }) => {
      return apiRequest('PUT', `/api/users/${user?.id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
    },
  });

  // Update parent profile mutation
  const updateParentMutation = useMutation({
    mutationFn: async (data: any) => {
      console.log('🔥 MUTATION STARTING - URL:', `/api/parents/${user?.id}/profile`);
      console.log('🔥 MUTATION DATA:', data);
      
      try {
        const result = await apiRequest('PUT', `/api/parents/${user?.id}/profile`, data);
        console.log('🔥 MUTATION RESULT:', result);
        return result;
      } catch (error) {
        console.error('🔥 MUTATION ERROR:', error);
        throw error;
      }
    },
    onSuccess: async (data) => {
      console.log('🔄 Parent mutation SUCCESS - invalidating queries and updating form');
      console.log('🔄 Mutation success data:', data);
      
      // Get current form values before setting save flag
      const currentFormValues = form.getValues();
      console.log('🔄 Current form values before save:', currentFormValues);
      
      // Set saving flag to prevent form reset
      setIsSaving(true);
      
      // Invalidate queries and refetch to get fresh data
      await queryClient.invalidateQueries({ queryKey: [`/api/parents/${user?.id}/profile`] });
      await queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
      
      // Force refetch parent profile data
      setTimeout(async () => {
        const freshData = await refetchParentProfile();
        console.log('🔄 Parent profile data refetched after save:', freshData.data);
        
        // Wait a bit more then allow form to update with fresh data
        setTimeout(() => {
          setIsSaving(false);
          console.log('🔄 Allowing form to update with fresh data');
        }, 500);
      }, 500);
      
      // Show success message
      toast({
        title: "Profile Saved", 
        description: "Your profile has been updated successfully!",
        variant: "default",
      });
    },
  });

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
    }
  };

  const handleCameraClick = () => {
    if (cameraInputRef.current) {
      cameraInputRef.current.click();
    }
  };

  const handleGalleryClick = () => {
    if (galleryInputRef.current) {
      galleryInputRef.current.click();
    }
  };



  const onSubmit = async (data: FormData) => {
    setIsSubmitting(true);
    setIsSaving(true);
    
    console.log('Form data being submitted:', data);
    console.log('Children data:', data.children);
    
    try {
      let profileImageUrl = (userProfile as any)?.profileImage;

      // Upload photo if selected
      if (selectedFile) {
        try {
          const photoResult = await uploadPhotoMutation.mutateAsync(selectedFile);
          profileImageUrl = photoResult.url;
        } catch (photoError) {
          console.error('Photo upload failed:', photoError);
          throw new Error(`Photo upload failed: ${(photoError as any).message}`);
        }
      }

      // Update user profile image only
      if (profileImageUrl !== (userProfile as any)?.profileImage) {
        // Get proper username from userProfile or user data
        const username = userProfile?.user?.username || 
                        userProfile?.username || 
                        user?.username || 
                        user?.email?.split('@')[0] ||
                        `user${user?.id}`;
        
        const userUpdateData = {
          username: username,
          profileImage: profileImageUrl,
        };
        
        console.log('🔄 Updating user with data:', userUpdateData);
        
        try {
          await updateUserMutation.mutateAsync(userUpdateData);
        } catch (userError) {
          console.error('User update error:', userError);
          throw new Error(`User profile update failed: ${(userError as any).message}`);
        }
      }

      // Update parent profile
      const parentProfileData = {
        address: data.address,
        bio: data.bio,
        children: data.children,
        schoolDaycare: data.schoolDaycare,
        childrenInfo: data.childrenInfo,
        defaultSpecialInstructions: data.defaultSpecialInstructions,
      };
      
      try {
        console.log('🔄 About to call updateParentMutation with URL:', `/api/parents/${user?.id}/profile`);
        console.log('🔄 Parent profile data:', parentProfileData);
        console.log('🔄 User ID:', user?.id);
        console.log('🔄 Auth token:', localStorage.getItem('auth_token') || localStorage.getItem('authToken'));
        
        const result = await updateParentMutation.mutateAsync(parentProfileData);
        console.log('🔄 Parent mutation result:', result);
        
        // Show success message with navigation option
        toast({
          title: "Profile Updated Successfully!",
          description: "Your profile has been saved and updated. You can continue editing or return to dashboard.",
        });
        
        // Reset form state
        setIsSubmitting(false);
        
        console.log('✅ Profile saved successfully! Data is persisting correctly.');
        console.log('✅ Current form values after save:', form.getValues());
        
        // Wait for queries to refresh and update form with saved data
        setTimeout(() => {
          // Ensure form gets updated with fresh data
          if (queryClient.getQueryData([`/api/parents/${user?.id}/profile`])) {
            console.log('🔄 Data refreshed, form should show saved data now');
          }
        }, 1000);
        
      } catch (parentError) {
        console.error('Parent profile update error:', parentError);
        throw new Error(`Parent profile update failed: ${(parentError as any).message}`);
      }

    } catch (error: any) {
      console.error('Profile save failed:', error);
      
      setIsSubmitting(false);
      setIsSaving(false);
      
      toast({
        title: "Profile Save Failed",
        description: error.message || "Failed to update profile. Please try again.",
        variant: "destructive",
      });
    }
  };

  const addChild = () => {
    const currentChildren = form.watch('children') || [];
    form.setValue('children', [...currentChildren, { name: '', age: 0, needsAttention: false, notes: '' }]);
  };

  const removeChild = (index: number) => {
    const currentChildren = form.watch('children') || [];
    form.setValue('children', currentChildren.filter((_, i) => i !== index));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-linen to-brushed-pink/20 p-4">
      <div className="max-w-2xl mx-auto">
        <Card>
          <CardHeader>
            <CardTitle className="text-village-wine">Edit Your Profile</CardTitle>
            <CardDescription>
              Update your information to help us match you with the perfect childcare
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                {/* Profile Photo Section */}
                <div className="space-y-4">
                  <FormLabel>Profile Photo</FormLabel>
                  <div className="flex items-center space-x-4">
                    <div className="w-20 h-20 bg-brushed-pink rounded-full flex items-center justify-center overflow-hidden">
                      {previewUrl ? (
                        <img src={previewUrl} alt="Preview" className="w-full h-full object-cover" />
                      ) : (userProfile as any)?.profileImage ? (
                        <img src={(userProfile as any).profileImage} alt="Profile" className="w-full h-full object-cover" />
                      ) : (
                        <Camera className="w-8 h-8 text-village-wine" />
                      )}
                    </div>
                    <div className="flex flex-col space-y-2">
                      <Button type="button" variant="outline" size="sm" onClick={handleCameraClick}>
                        <Camera className="w-4 h-4 mr-2" />
                        Take Photo
                      </Button>
                      <Button type="button" variant="outline" size="sm" onClick={handleGalleryClick}>
                        <Upload className="w-4 h-4 mr-2" />
                        Upload Photo
                      </Button>
                    </div>
                  </div>
                  
                  <input
                    ref={cameraInputRef}
                    type="file"
                    accept="image/*"
                    capture="environment"
                    onChange={handleFileSelect}
                    className="hidden"
                  />
                  <input
                    ref={galleryInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileSelect}
                    className="hidden"
                  />
                </div>

                {/* Display Name - First Name Only */}
                <div className="space-y-2">
                  <FormLabel>Display Name</FormLabel>
                  <div className="px-3 py-2 border rounded-md bg-gray-50 text-gray-700">
                    {(() => {
                      console.log('🎯 Display Name debug:', {
                        userProfile_user_first_name: userProfile?.user?.first_name,
                        userProfile_user_firstName: userProfile?.user?.firstName,
                        user_first_name: user?.first_name,
                        user_firstName: user?.firstName,
                        userProfile: userProfile,
                        user: user
                      });
                      return userProfile?.user?.first_name || userProfile?.user?.firstName || user?.first_name || user?.firstName || (userProfile?.user?.username?.split(' ')[0]) || 'Nikki';
                    })()}
                  </div>
                  <FormDescription>
                    This is how other parents and sitters will see your name (first name only for privacy)
                  </FormDescription>
                </div>

                {/* Bio */}
                <FormField
                  control={form.control}
                  name="bio"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>About You</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Tell us about your family, parenting style, or what you're looking for in a sitter..."
                          className="min-h-[100px]"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Address */}
                <FormField
                  control={form.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Address</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4 z-10" />
                          <Input
                            placeholder="Enter your address"
                            value={field.value || ''}
                            onChange={field.onChange}
                            className="pl-10"
                          />
                        </div>
                      </FormControl>
                      <FormDescription>
                        This helps us find sitters in your area. Please enter your full address including suburb and postcode.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* School/Daycare */}
                <FormField
                  control={form.control}
                  name="schoolDaycare"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>School/Daycare</FormLabel>
                      <FormControl>
                        <SearchableSchoolSelect
                          value={field.value || ''}
                          onChange={field.onChange}
                          placeholder="Search for your child's school or daycare..."
                        />
                      </FormControl>
                      <FormDescription>
                        This helps us connect you with other families and sitters in your school community
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Children */}
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <FormLabel>Children</FormLabel>
                    <Button type="button" variant="outline" size="sm" onClick={addChild}>
                      <Plus className="w-4 h-4 mr-2" />
                      Add Child
                    </Button>
                  </div>
                  
                  {(form.watch('children') || []).map((child, index) => (
                    <Card key={index} className="p-4">
                      <div className="flex items-start justify-between mb-4">
                        <h4 className="font-medium">Child {index + 1}</h4>
                        <Button 
                          type="button" 
                          variant="ghost" 
                          size="sm" 
                          onClick={() => removeChild(index)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name={`children.${index}.name`}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Name</FormLabel>
                              <FormControl>
                                <Input placeholder="Child's name" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name={`children.${index}.age`}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Age</FormLabel>
                              <FormControl>
                                <Input 
                                  type="text" 
                                  placeholder="Age"
                                  {...field}
                                  value={field.value || ''}
                                  onChange={(e) => {
                                    const value = e.target.value.replace(/\D/g, ''); // Only allow digits
                                    const numValue = value === '' ? 0 : parseInt(value);
                                    if (numValue <= 18) {
                                      field.onChange(numValue);
                                    }
                                  }}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <FormField
                        control={form.control}
                        name={`children.${index}.notes`}
                        render={({ field }) => (
                          <FormItem className="mt-4">
                            <FormLabel>Special Notes</FormLabel>
                            <FormControl>
                              <Textarea 
                                placeholder="Any special needs, allergies, or important information..."
                                className="min-h-[80px]"
                                {...field}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </Card>
                  ))}
                  
                  {(!form.watch('children') || form.watch('children')?.length === 0) && (
                    <p className="text-sm text-gray-500 text-center py-4">
                      No children added yet. Click "Add Child" to get started.
                    </p>
                  )}
                </div>

                {/* Default Children Info for Bookings */}
                <FormField
                  control={form.control}
                  name="childrenInfo"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Default Children Information</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Tell sitters about your children (ages, allergies, special needs, etc.) - this will be pre-filled in booking forms"
                          className="min-h-[100px]"
                          {...field}
                        />
                      </FormControl>
                      <FormDescription>
                        This information will be automatically filled in when you create bookings, saving you time
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Default Special Instructions */}
                <FormField
                  control={form.control}
                  name="defaultSpecialInstructions"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Default Special Instructions</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Standard instructions for sitters (bedtime routines, house rules, emergency info, etc.)"
                          className="min-h-[80px]"
                          {...field}
                        />
                      </FormControl>
                      <FormDescription>
                        These instructions will be included with every booking unless you change them
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />



                {/* Submit Buttons */}
                <div className="flex flex-col gap-3 pt-6">
                  <div className="flex gap-4">
                    <Button
                      type="submit"
                      disabled={isSubmitting}
                      className="flex-1 bg-village-wine hover:bg-village-wine/90 text-white font-semibold py-3"
                    >
                      {isSubmitting ? 'Saving...' : 'Save Profile'}
                    </Button>
                    <Button
                      type="button"
                      disabled={isSubmitting}
                      onClick={async () => {
                        const isValid = await form.trigger();
                        if (isValid) {
                          const formData = form.getValues();
                          await onSubmit(formData);
                          setLocation('/dashboard');
                        }
                      }}
                      className="flex-1 bg-eucalyptus hover:bg-eucalyptus/90 text-white font-semibold py-3"
                    >
                      {isSubmitting ? 'Saving...' : 'Save & Return to Dashboard'}
                    </Button>
                  </div>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setLocation('/dashboard')}
                    className="w-full"
                  >
                    Back to Dashboard (Don't Save)
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default EditParentProfile;