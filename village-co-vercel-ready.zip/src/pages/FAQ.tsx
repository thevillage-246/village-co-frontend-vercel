import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Phone, Mail, MessageCircle } from "lucide-react";
import { useEffect } from "react";
import SEO, { SEOConfigs } from '@/components/SEO';

function FAQ() {
  const faqs = [
    {
      question: "Need a last-minute sitter but can't find one?",
      answer: "Contact Nikki or Soph directly - we'll sort it out at info@thevillageco.nz or give us a call on 07 807 9114"
    },
    {
      question: "Looking for babysitting jobs?",
      answer: "Join our trusted network today - apply now!"
    },
    {
      question: "Can I request the same sitter again?",
      answer: "Of course! Favourites make life easier - you can rebook them directly through the site."
    },
    {
      question: "Need overnight or special needs care?",
      answer: "We've got sitters for that too - just contact us on info@thevillageco.nz or give us a call on 07 807 9114"
    },
    {
      question: "Are The Village Co. sitters background-checked?",
      answer: "Absolutely! Police checks, identity verification, and interviews are standard."
    },
    {
      question: "Can I meet the sitter before booking?",
      answer: "Yes - it's all built inside the platform. You can start a video call to chat with your sitter after you have requested a booking."
    },
    {
      question: "What if my sitter cancels last minute?",
      answer: "Life happens - we get it. If your sitter cancels, we'll help you find a replacement ASAP or refund your booking. Contact us on info@thevillageco.nz or call us on 07 807 9114"
    },
    {
      question: "What if something goes wrong?",
      answer: "Rest assured, every booking is protected by our comprehensive $2 million liability insurance."
    },
    {
      question: "How do I pay my sitter?",
      answer: "All payments are processed securely through the platform - no need for cash or bank transfers."
    },
    {
      question: "Can I leave special instructions for the sitter?",
      answer: "Of course! Share details like bedtime routines, allergies, and any special care instructions right in your parent portal."
    },
    {
      question: "Can I cancel a booking if my plans change?",
      answer: "Yes, you can cancel or reschedule directly on this platform. Check our cancellation policy for more details."
    },
    {
      question: "Is there a mobile app available?",
      answer: "Yes! Download The Village Co. app for iOS and Android. Book sitters, manage your account, and get real-time updates on the go. Available on the App Store and Google Play."
    },
    {
      question: "How do I download the app?",
      answer: "You can download our mobile app directly from our website or visit the App Store (iOS) or Google Play Store (Android). Search for 'The Village Co.' to find our official app."
    },
    {
      question: "Do I need the app to use The Village Co.?",
      answer: "No, you can use our full service through your web browser. However, the app provides convenient features like push notifications, offline access to sitter details, and faster booking on mobile devices."
    },
    {
      question: "Can I book through the app?",
      answer: "Absolutely! The app includes our complete booking system - browse sitters, check availability, make payments, and communicate with your sitter all from your phone."
    },
    {
      question: "What areas does The Village Co. currently serve?",
      answer: "We are currently available in Auckland, Hamilton, Christchurch and Wellington. We are growing so email us if you would like a sitter in your area and we will look at what's available!"
    }
  ];

  return (
    <>
      <SEO {...SEOConfigs.faq} />
      <div className="min-h-screen bg-[#F9F5F0]">
      {/* Hero Section */}
      <section className="bg-[#6B3E4B] text-white py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6" style={{ fontFamily: 'Satoshi, sans-serif' }}>
            FAQs — Everything You Need to Know
          </h1>
          <p className="text-xl text-[#ebd3cb]" style={{ fontFamily: 'DM Sans, sans-serif' }}>
            Find answers to common questions about The Village Co. babysitting platform
          </p>
        </div>
      </section>

      {/* FAQ Content */}
      <section className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-6">
            {faqs.map((faq, index) => (
              <Card key={index} className="bg-white rounded-xl shadow-lg border-0">
                <CardContent className="p-8">
                  <h3 className="text-xl font-semibold text-[#6B3E4B] mb-4" style={{ fontFamily: 'Satoshi, sans-serif' }}>
                    {faq.question}
                  </h3>
                  <p className="text-gray-700 leading-relaxed" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                    {faq.answer}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-[#6B3E4B] mb-6" style={{ fontFamily: 'Satoshi, sans-serif' }}>
            Have questions or need assistance?
          </h2>
          <p className="text-xl text-gray-700 mb-8" style={{ fontFamily: 'DM Sans, sans-serif' }}>
            Reach out to Nikki & Soph - we're here to help!
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button 
              variant="outline" 
              size="lg"
              className="border-[#6B3E4B] text-[#6B3E4B] hover:bg-[#6B3E4B] hover:text-white px-8 py-4 rounded-xl shadow-lg"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
              onClick={() => window.location.href = "mailto:info@thevillageco.nz"}
            >
              <Mail className="w-5 h-5 mr-2" />
              info@thevillageco.nz
            </Button>
            
            <Button 
              size="lg"
              className="bg-[#6B3E4B] hover:bg-[#6B3E4B]/90 text-white px-8 py-4 rounded-xl shadow-lg"
              style={{ fontFamily: 'DM Sans, sans-serif' }}
              onClick={() => window.location.href = "tel:078079114"}
            >
              <Phone className="w-5 h-5 mr-2" />
              07 807 9114
            </Button>
          </div>
        </div>
      </section>
      </div>
    </>
  );
}

export default FAQ;