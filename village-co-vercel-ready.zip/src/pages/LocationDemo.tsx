import { useState } from 'react';
import LocationSharing from '@/components/location/LocationSharing';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuth } from '@/contexts/AuthContext';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function LocationDemo() {
  // In a real app, this would be retrieved from the booking data
  const [demoDetails] = useState({
    bookingId: 123,
    parentId: 456,
    sitterId: 789,
  });
  
  const { user } = useAuth();
  const userRole = user?.user_metadata?.role || 'parent'; // Default to parent for demo
  
  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-6 text-wine-800">Location Sharing Demo</h1>
      
      <p className="mb-6 text-muted-foreground">
        This page demonstrates the real-time location sharing feature between parents and babysitters.
        In a real implementation, this would be integrated into the booking details page.
      </p>
      
      <div className="mb-8 p-4 bg-amber-50 border border-amber-200 rounded-md">
        <p className="text-amber-800">
          <strong>Demo Note:</strong> For this demo, you can toggle between parent and sitter views to see both perspectives.
          In the actual app, users would only see the view appropriate for their role.
        </p>
      </div>
      
      <Tabs defaultValue="parent" className="mb-8">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="parent">Parent View</TabsTrigger>
          <TabsTrigger value="sitter">Sitter View</TabsTrigger>
        </TabsList>
        <TabsContent value="parent" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Parent Dashboard</CardTitle>
              <CardDescription>
                As a parent, you can view the sitter's real-time location during the babysitting session.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <LocationSharing 
                bookingId={demoDetails.bookingId}
                parentId={demoDetails.parentId}
                sitterId={demoDetails.sitterId}
                isSitter={false}
              />
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="sitter" className="mt-4">
          <Card>
            <CardHeader>
              <CardTitle>Sitter Dashboard</CardTitle>
              <CardDescription>
                As a sitter, you can share your location with parents during the babysitting session.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <LocationSharing 
                bookingId={demoDetails.bookingId}
                parentId={demoDetails.parentId}
                sitterId={demoDetails.sitterId}
                isSitter={true}
              />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
      
      <div className="flex justify-center mt-8">
        <Button 
          variant="outline" 
          onClick={() => window.history.back()}
        >
          Back to Previous Page
        </Button>
      </div>
    </div>
  );
}