import { useEffect } from 'react';

export function FAQPage() {
  useEffect(() => {
    window.location.href = 'https://ittakesavillage.nz/p/faq-page';
  }, []);
  return <p>Redirecting to FAQ…</p>;
}

export function TermsOfServicePage() {
  useEffect(() => {
    window.location.href = 'https://ittakesavillage.nz/terms-of-service';
  }, []);
  return <p>Redirecting to Terms of Service…</p>;
}

export function PrivacyPolicyPage() {
  useEffect(() => {
    window.location.href = 'https://ittakesavillage.nz/privacy-policy';
  }, []);
  return <p>Redirecting to Privacy Policy…</p>;
}