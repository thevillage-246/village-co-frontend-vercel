import { Button } from "@/components/ui/button";
import SEO, { SEOConfigs } from '@/components/SEO';

export default function Employers() {
  return (
    <>
      <SEO {...SEOConfigs.employers} />
      <div className="min-h-screen">
      {/* Hero Section */}
      <section className="px-4 py-20 bg-gradient-to-br from-[#6b3e4b] to-[#5a3340] text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Workplaces that support parents, win.
          </h1>
          <p className="text-xl md:text-2xl mb-8 leading-relaxed max-w-3xl mx-auto">
            Flexible, high-trust care made simple for modern employers.
          </p>
          <p className="text-lg leading-relaxed max-w-3xl mx-auto mb-8">
            Childcare isn't just a personal issue. It's a workplace performance issue.
            That's why we've created a seamless way for forward-thinking companies to support working parents without the red tape of traditional childcare benefits.
          </p>
        </div>
      </section>

      {/* What We Offer */}
      <section className="px-4 py-16 bg-white">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#6b3e4b] mb-12">
            What We Offer
          </h2>
          
          <div className="space-y-6 text-lg text-gray-700">
            <div className="flex items-start">
              <span className="text-[#6b3e4b] mr-3">•</span>
              <span>On-demand care when it matters most: no centres, no paperwork.</span>
            </div>
            <div className="flex items-start">
              <span className="text-[#6b3e4b] mr-3">•</span>
              <span>Trusted, vetted care professionals: the kind you'd leave your own child with.</span>
            </div>
            <div className="flex items-start">
              <span className="text-[#6b3e4b] mr-3">•</span>
              <span>Flexible options to suit teams of all shapes and sizes: from startups to corporates.</span>
            </div>
            <div className="flex items-start">
              <span className="text-[#6b3e4b] mr-3">•</span>
              <span>Custom-built solutions for return-to-work programs, peak periods, and parent wellbeing initiatives.</span>
            </div>
          </div>
        </div>
      </section>

      {/* Why It Works */}
      <section className="px-4 py-16 bg-[#eae1d6]">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-[#6b3e4b] mb-12">
            Why It Works
          </h2>
          
          <div className="space-y-6 text-lg text-gray-700">
            <p className="text-xl font-semibold text-[#6b3e4b] mb-6">The numbers don't lie:</p>
            <div className="flex items-start">
              <span className="text-[#6b3e4b] mr-3">•</span>
              <span>67% of working parents say childcare gaps impact their productivity.</span>
            </div>
            <div className="flex items-start">
              <span className="text-[#6b3e4b] mr-3">•</span>
              <span>The right support reduces absenteeism, boosts morale, and improves retention, especially for women.</span>
            </div>
            <p className="text-xl text-gray-800 mt-8">
              We help employers shift from "we wish we could help" to "we've got you covered."
            </p>
          </div>
        </div>
      </section>

      {/* The Details */}
      <section className="px-4 py-16 bg-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-[#6b3e4b] mb-6">
            The Details? Not Here.
          </h2>
          <p className="text-lg text-gray-700 max-w-3xl mx-auto">
            We're not your average care platform, and we don't publish a menu of services for a reason. 
            Our approach is human-first, tech-powered, and built to evolve with your team's needs.
          </p>
        </div>
      </section>

      {/* CTA Section */}
      <section className="px-4 py-16 bg-[#6b3e4b] text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Curious what this could look like for your workplace?
          </h2>
          <p className="text-xl mb-8">
            Let's chat.
          </p>
          <Button 
            size="lg" 
            className="bg-white text-[#6b3e4b] hover:bg-gray-100 px-8 py-4 text-lg"
            onClick={() => window.location.href = 'mailto:info@thevillageco.nz?subject=Employer Partnership Inquiry'}
          >
            Contact us to start the conversation →
          </Button>
        </div>
      </section>
      </div>
    </>
  );
}