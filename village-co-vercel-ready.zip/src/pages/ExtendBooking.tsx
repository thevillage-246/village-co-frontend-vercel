import React, { useState } from 'react';
import { useParams } from 'wouter';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Clock, DollarSign, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { formatAucklandTime } from '@/utils/timezone';

const ExtendBooking: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const bookingId = parseInt(id!);
  const [selectedMinutes, setSelectedMinutes] = useState<number | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: booking, isLoading } = useQuery({
    queryKey: [`/api/bookings/${bookingId}`],
    enabled: !!bookingId,
  });

  const extendMutation = useMutation({
    mutationFn: async (minutes: number) => {
      return apiRequest('POST', `/api/bookings/${bookingId}/extend`, { minutes });
    },
    onSuccess: () => {
      toast({
        title: "Extension Request Sent! ✨",
        description: "Your sitter will be notified about the extension request.",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/bookings/${bookingId}`] });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to Send Extension Request",
        description: error.message || "Please try again or contact support.",
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#F9F5F0] flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-4 border-[#6B3E4B] border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!booking) {
    return (
      <div className="min-h-screen bg-[#F9F5F0] p-4">
        <div className="max-w-md mx-auto pt-20">
          <Card className="shadow-lg">
            <CardContent className="p-8 text-center">
              <AlertCircle className="h-12 w-12 text-[#6B3E4B] mx-auto mb-4" />
              <h2 className="text-xl font-semibold mb-2">Booking Not Found</h2>
              <p className="text-muted-foreground">This booking could not be found or may have already ended.</p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const hourlyRate = booking.hourlyRate || 25;
  const lateFee = 10;
  
  const timeOptions = [
    { minutes: 15, label: '15 minutes' },
    { minutes: 30, label: '30 minutes' },
    { minutes: 60, label: '1 hour' },
    { minutes: 120, label: '2 hours' }
  ];

  const calculateCost = (minutes: number) => {
    const hourlyCharge = (minutes / 60) * hourlyRate;
    return hourlyCharge + lateFee;
  };

  const endTime = booking.endTime ? formatAucklandTime(new Date(booking.endTime), 'h:mm a') : 'Unknown';

  return (
    <div className="min-h-screen bg-[#F9F5F0] p-4">
      <div className="max-w-2xl mx-auto pt-8">
        <Card className="shadow-lg">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl text-[#6B3E4B] font-satoshi">
              Extend Your Booking ⏰
            </CardTitle>
            <CardDescription className="text-lg">
              Your booking with {booking.sitterName} ends at {endTime}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Current booking info */}
            <div className="bg-[#F9F5F0] rounded-xl p-4">
              <h3 className="font-semibold text-[#6B3E4B] mb-2">Current Booking</h3>
              <div className="space-y-1 text-sm">
                <p><strong>Sitter:</strong> {booking.sitterName}</p>
                <p><strong>Ends at:</strong> {endTime}</p>
                <p><strong>Hourly Rate:</strong> ${hourlyRate}/hour</p>
              </div>
            </div>

            {/* Time options */}
            <div>
              <h3 className="font-semibold text-[#6B3E4B] mb-4">How much extra time do you need?</h3>
              <div className="grid grid-cols-2 gap-3">
                {timeOptions.map((option) => (
                  <button
                    key={option.minutes}
                    onClick={() => setSelectedMinutes(option.minutes)}
                    className={`p-4 rounded-xl border-2 transition-all ${
                      selectedMinutes === option.minutes
                        ? 'border-[#6B3E4B] bg-[#6B3E4B]/5'
                        : 'border-gray-200 hover:border-[#6B3E4B]/50'
                    }`}
                  >
                    <div className="text-center">
                      <div className="flex items-center justify-center mb-2">
                        <Clock className="h-5 w-5 text-[#6B3E4B] mr-1" />
                        <span className="font-medium">{option.label}</span>
                      </div>
                      <div className="text-sm text-gray-600">
                        ${calculateCost(option.minutes).toFixed(2)}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Pricing breakdown */}
            {selectedMinutes && (
              <div className="bg-white rounded-xl border-2 border-[#6B3E4B]/20 p-4">
                <h3 className="font-semibold text-[#6B3E4B] mb-3 flex items-center">
                  <DollarSign className="h-5 w-5 mr-1" />
                  Pricing Breakdown
                </h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Extra time ({selectedMinutes} min @ ${hourlyRate}/hour):</span>
                    <span>${((selectedMinutes / 60) * hourlyRate).toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Late booking fee:</span>
                    <span>${lateFee.toFixed(2)}</span>
                  </div>
                  <div className="border-t pt-2 flex justify-between font-semibold text-[#6B3E4B]">
                    <span>Total:</span>
                    <span>${calculateCost(selectedMinutes).toFixed(2)}</span>
                  </div>
                </div>
              </div>
            )}

            {/* Action buttons */}
            <div className="flex gap-3">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => window.history.back()}
              >
                Cancel
              </Button>
              <Button
                className="flex-1 bg-[#6B3E4B] hover:bg-[#6B3E4B]/90"
                disabled={!selectedMinutes || extendMutation.isPending}
                onClick={() => selectedMinutes && extendMutation.mutate(selectedMinutes)}
              >
                {extendMutation.isPending ? 'Sending...' : 'Request Extension'}
              </Button>
            </div>

            {/* Info note */}
            <div className="bg-blue-50 rounded-xl p-4">
              <div className="flex items-start">
                <AlertCircle className="h-5 w-5 text-blue-600 mr-2 mt-0.5 flex-shrink-0" />
                <div className="text-sm text-blue-800">
                  <p className="font-medium mb-1">How it works:</p>
                  <p>Your sitter will receive a notification asking if they can extend the booking. If they agree, the extra time and late fee will be automatically charged to your payment method.</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ExtendBooking;