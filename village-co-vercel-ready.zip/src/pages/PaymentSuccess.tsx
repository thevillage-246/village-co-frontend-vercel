import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, CreditCard, ArrowRight } from 'lucide-react';

export default function PaymentSuccess() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    // Auto-redirect to dashboard after 5 seconds
    const timer = setTimeout(() => {
      setLocation('/parent/dashboard');
    }, 5000);

    return () => clearTimeout(timer);
  }, [setLocation]);

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-2xl mx-auto px-4">
        <Card className="text-center">
          <CardHeader>
            <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            <CardTitle className="text-village-wine text-2xl">
              Payment Method Added Successfully!
            </CardTitle>
            <p className="text-gray-600">
              Your payment information has been securely saved and you're ready to book trusted sitters.
            </p>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <div className="flex items-center gap-3 justify-center">
                <CreditCard className="w-5 h-5 text-green-600" />
                <div>
                  <h3 className="font-medium text-green-900">Secure & Ready</h3>
                  <p className="text-sm text-green-700">
                    Your payment method is encrypted and ready for quick bookings
                  </p>
                </div>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                onClick={() => setLocation('/find-sitter')}
                className="flex-1 bg-village-wine hover:bg-village-wine/90"
              >
                Find Sitters to Book
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
              <Button
                variant="outline"
                onClick={() => setLocation('/parent/dashboard')}
                className="flex-1"
              >
                Back to Dashboard
              </Button>
            </div>

            <p className="text-sm text-gray-500">
              You'll be automatically redirected to your dashboard in a few seconds...
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}