import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import GoogleAuthButton from '@/components/auth/GoogleAuthButton';
import GoogleAuthStatus from '@/components/auth/GoogleAuthStatus';
import FirebaseDomainGuide from '@/components/auth/FirebaseDomainGuide';
import FirebaseDiagnostic from '@/components/auth/FirebaseDiagnostic';
import { AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { signIn, checkOnboardingStatus } = useAuth();
  const [_, navigate] = useLocation();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !password) {
      setErrorMessage('Please enter both email and password');
      return;
    }
    
    try {
      setIsLoading(true);
      setErrorMessage(null);
      
      const { error } = await signIn(email, password);
      
      if (error) {
        setErrorMessage(error.message);
        return;
      }
      
      toast({
        title: 'Welcome back!',
        description: 'You have successfully logged in.',
      });
      
      // Redirect to dashboard - let the dashboard component handle role-based routing
      navigate('/dashboard');
    } catch (error) {
      console.error('Login error:', error);
      setErrorMessage('An unexpected error occurred. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen bg-gradient-to-br from-bone via-white to-brushed-pink">
      <div className="flex-1 flex items-center justify-center px-4 py-12 sm:px-6 lg:px-8">
        <div className="w-full max-w-md">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-village-wine mb-2">Welcome back</h1>
            <p className="text-almond-frost">Sign in to your Village account</p>
          </div>
          
          <Card className="shadow-xl border-0 rounded-2xl">
            <CardContent className="p-8 space-y-6">
              {errorMessage && (
                <Alert variant="destructive" className="rounded-xl">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{errorMessage}</AlertDescription>
                </Alert>
              )}
              
              <GoogleAuthButton 
                mode="signin" 
                onError={(error) => setErrorMessage(error.message)}
              />
              
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <Separator />
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="bg-white px-4 text-almond-frost">Or continue with email</span>
                </div>
              </div>
              
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email" className="text-village-wine font-medium">Email address</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="Enter your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="rounded-xl border-brushed-pink focus:border-village-wine focus:ring-village-wine"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="password" className="text-village-wine font-medium">Password</Label>
                    <Button 
                      variant="link" 
                      className="px-0 font-normal text-sm text-village-wine hover:text-almond-frost"
                      onClick={() => navigate('/forgot-password')}
                      type="button"
                    >
                      Forgot password?
                    </Button>
                  </div>
                  <Input
                    id="password"
                    type="password"
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="rounded-xl border-brushed-pink focus:border-village-wine focus:ring-village-wine"
                    required
                  />
                </div>
                <Button 
                  type="submit" 
                  className="w-full bg-village-wine hover:bg-village-wine/90 text-white font-semibold py-3 rounded-xl"
                  disabled={isLoading}
                >
                  {isLoading ? (
                    <span className="flex items-center justify-center">
                      <svg 
                        className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" 
                        xmlns="http://www.w3.org/2000/svg" 
                        fill="none" 
                        viewBox="0 0 24 24"
                      >
                        <circle 
                          className="opacity-25" 
                          cx="12" 
                          cy="12" 
                          r="10" 
                          stroke="currentColor" 
                          strokeWidth="4"
                        ></circle>
                        <path 
                          className="opacity-75" 
                          fill="currentColor" 
                          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3042 1.135 5.824 3 7.938l3-2.647z"
                        ></path>
                      </svg>
                      Signing in...
                    </span>
                  ) : (
                    'Sign in'
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
          
          <div className="text-center mt-6">
            <span className="text-almond-frost">Don't have an account? </span>
            <Button 
              variant="link" 
              className="px-0 text-village-wine hover:text-almond-frost font-semibold"
              onClick={() => navigate('/register')}
            >
              Sign up
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}