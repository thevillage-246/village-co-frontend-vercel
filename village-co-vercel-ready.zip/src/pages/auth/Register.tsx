import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import GoogleAuthButton from '@/components/auth/GoogleAuthButton';
import GoogleAuthStatus from '@/components/auth/GoogleAuthStatus';
import FirebaseDomainGuide from '@/components/auth/FirebaseDomainGuide';
import FirebaseDiagnostic from '@/components/auth/FirebaseDiagnostic';
import { AlertCircle } from 'lucide-react';
import { z } from 'zod';
import { useToast } from '@/hooks/use-toast';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { USER_ROLES } from '@shared/schema';
import { Eye, EyeOff } from 'lucide-react';

const registerSchema = z.object({
  email: z.string().email('Please enter a valid email address'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
  firstName: z.string().min(1, 'First name is required'),
  lastName: z.string().min(1, 'Last name is required'),
  role: z.enum([USER_ROLES.PARENT, USER_ROLES.SITTER], {
    errorMap: () => ({ message: 'Please select a role' }),
  }),
});

type RegisterInput = z.infer<typeof registerSchema>;

export default function Register() {
  const [formData, setFormData] = useState<RegisterInput>({
    email: '',
    password: '',
    firstName: '',
    lastName: '',
    role: USER_ROLES.PARENT,
  });
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const { signUp } = useAuth();
  const [_, navigate] = useLocation();
  const { toast } = useToast();

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleRoleChange = (value: string) => {
    if (value === USER_ROLES.PARENT || value === USER_ROLES.SITTER) {
      setFormData((prev) => ({ ...prev, role: value }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      // Validate the form data
      registerSchema.parse(formData);
      
      setIsLoading(true);
      setErrorMessage(null);
      
      const result = await signUp(formData.email, formData.password, {
        firstName: formData.firstName,
        lastName: formData.lastName,
        role: formData.role,
      });
      
      if (result.error) {
        // Make error messages more user-friendly
        const errorMsg = result.error.message;
        if (errorMsg.includes('already exists') || errorMsg.includes('already registered')) {
          setErrorMessage('This email is already registered. Try signing in instead, or use a different email address.');
        } else if (errorMsg.includes('password')) {
          setErrorMessage('Please choose a stronger password with at least 8 characters.');
        } else if (errorMsg.includes('email')) {
          setErrorMessage('Please enter a valid email address.');
        } else {
          setErrorMessage('Something went wrong creating your account. Please try again or contact support if the problem continues.');
        }
        return;
      }
      
      // Check if email confirmation is required
      if (result && 'emailConfirmationRequired' in result && result.emailConfirmationRequired) {
        toast({
          title: 'Check your email!',
          description: ('message' in result ? result.message : undefined) || 'We\'ve sent you a confirmation link to verify your email address.',
        });
        
        // Redirect to confirmation page with email info
        navigate(`/auth/confirmation?email=${encodeURIComponent(formData.email)}`);
      } else {
        // Direct login successful
        toast({
          title: 'Welcome to The Village Co!',
          description: 'Your account has been created and you\'re now signed in.',
        });
        
        // Redirect based on role
        if (formData.role === USER_ROLES.SITTER) {
          navigate('/sitter/onboarding');
        } else {
          navigate('/parent/onboarding');
        }
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        // Handle validation errors with user-friendly messages
        const zodError = error.errors[0];
        if (zodError.path.includes('email')) {
          setErrorMessage('Please enter a valid email address.');
        } else if (zodError.path.includes('password')) {
          setErrorMessage('Password must be at least 8 characters long.');
        } else if (zodError.path.includes('firstName')) {
          setErrorMessage('Please enter your first name.');
        } else if (zodError.path.includes('lastName')) {
          setErrorMessage('Please enter your last name.');
        } else {
          setErrorMessage('Please check your information and try again.');
        }
      } else {
        console.error('Registration error:', error);
        setErrorMessage('Something went wrong creating your account. Please try again or contact support if the problem continues.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-linen-50 flex items-center justify-center px-4 py-8 sm:py-12 sm:px-6 lg:px-8">
      <Card className="w-full max-w-md mx-auto my-8">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl font-bold text-center text-wine-800">Create an account</CardTitle>
          <CardDescription className="text-center">
            Enter your details below to create your account
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4 pb-6">
          {errorMessage && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{errorMessage}</AlertDescription>
            </Alert>
          )}
          
          <GoogleAuthButton 
            mode="signup"
            onError={(error) => setErrorMessage(error.message)}
          />
          
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <Separator />
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-background px-2 text-muted-foreground">Or continue with</span>
            </div>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="firstName">First Name</Label>
                <Input
                  id="firstName"
                  name="firstName"
                  value={formData.firstName}
                  onChange={handleInputChange}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lastName">Last Name</Label>
                <Input
                  id="lastName"
                  name="lastName"
                  value={formData.lastName}
                  onChange={handleInputChange}
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                name="email"
                type="email"
                placeholder="your.email@example.com"
                value={formData.email}
                onChange={handleInputChange}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <div className="relative">
                <Input
                  id="password"
                  name="password"
                  type={showPassword ? "text" : "password"}
                  value={formData.password}
                  onChange={handleInputChange}
                  className="pr-10"
                  required
                />
                <button
                  type="button"
                  className="absolute inset-y-0 right-0 pr-3 flex items-center"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4 text-gray-400 hover:text-gray-600" />
                  ) : (
                    <Eye className="h-4 w-4 text-gray-400 hover:text-gray-600" />
                  )}
                </button>
              </div>
              <p className="text-xs text-muted-foreground">
                Password must be at least 8 characters long
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="role">I am a</Label>
              <Select
                value={formData.role}
                onValueChange={handleRoleChange}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select your role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={USER_ROLES.PARENT}>Parent</SelectItem>
                  <SelectItem value={USER_ROLES.SITTER}>Babysitter</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {/* Submit Button - Ensure it's always visible on mobile */}
            <div className="pt-4 pb-2">
              <Button 
                type="submit" 
                className="w-full bg-village-wine hover:bg-village-wine/90 text-white py-3 text-base font-semibold min-h-[48px] touch-manipulation shadow-lg"
                disabled={isLoading}
              >
              {isLoading ? (
                <span className="flex items-center justify-center">
                  <svg 
                    className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" 
                    xmlns="http://www.w3.org/2000/svg" 
                    fill="none" 
                    viewBox="0 0 24 24"
                  >
                    <circle 
                      className="opacity-25" 
                      cx="12" 
                      cy="12" 
                      r="10" 
                      stroke="currentColor" 
                      strokeWidth="4"
                    ></circle>
                    <path 
                      className="opacity-75" 
                      fill="currentColor" 
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    ></path>
                  </svg>
                  Creating account...
                </span>
              ) : (
                'Create account'
              )}
              </Button>
            </div>
          </form>
        </CardContent>
        <CardFooter className="flex justify-center pb-8">
          <Button 
            variant="link" 
            className="text-sm text-muted-foreground hover:text-rose-700"
            onClick={() => navigate('/login')}
          >
            Already have an account? Sign in
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}