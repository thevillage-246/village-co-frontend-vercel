import { useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, Mail, AlertCircle } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

export default function Confirmation() {
  const [_, navigate] = useLocation();
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [email, setEmail] = useState<string | null>(null);

  useEffect(() => {
    // Check if this is a redirect from email confirmation
    const handleEmailConfirmation = async () => {
      const url = new URL(window.location.href);
      const token_hash = url.searchParams.get('token_hash');
      const type = url.searchParams.get('type');
      const emailParam = url.searchParams.get('email');
      
      // Set email from URL parameter if available
      if (emailParam) {
        setEmail(decodeURIComponent(emailParam));
      }
      
      if (token_hash && type) {
        try {
          const { data, error } = await supabase.auth.verifyOtp({
            token_hash,
            type: type as any,
          });
          
          if (error) {
            setStatus('error');
            setErrorMessage(error.message);
          } else {
            setStatus('success');
            setEmail(data.user?.email || email);
            
            // Remove query parameters from URL without reloading
            window.history.replaceState({}, document.title, window.location.pathname);
            
            // Redirect to dashboard after successful confirmation
            setTimeout(() => {
              navigate('/dashboard');
            }, 2000);
          }
        } catch (error) {
          setStatus('error');
          setErrorMessage('An unexpected error occurred during email confirmation');
          console.error('Confirmation error:', error);
        }
      } else {
        // No token in URL, this is just showing the "check your email" page
        setStatus('success');
      }
    };
    
    handleEmailConfirmation();
  }, []);

  return (
    <div className="flex min-h-screen items-center justify-center px-4 py-12 sm:px-6 lg:px-8 bg-linen-50">
      <Card className="w-full max-w-md">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl font-bold text-center text-wine-800">
            {status === 'loading' ? 'Verifying...' : 
             status === 'success' ? 'Check your email' : 
             'Verification Error'}
          </CardTitle>
          <CardDescription className="text-center">
            {status === 'loading' ? 'We are verifying your email address...' :
             status === 'success' ? 'We\'ve sent you a confirmation link to verify your email address' :
             'There was a problem with your verification link'}
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col items-center justify-center space-y-4 pt-4">
          {status === 'loading' && (
            <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-b-2 border-rose-600"></div>
          )}
          
          {status === 'success' && (
            <>
              <div className="rounded-full bg-green-100 p-3">
                <Mail className="h-10 w-10 text-green-600" />
              </div>
              <p className="text-center text-muted-foreground">
                {email ? 
                  `Your email address ${email} has been verified.` : 
                  'Please check your email inbox and click the confirmation link to verify your account.'}
              </p>
              {email && (
                <Alert className="mt-4 bg-green-50 border-green-100">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <AlertTitle>Success!</AlertTitle>
                  <AlertDescription>
                    Your email has been successfully verified. You can now log in to your account.
                  </AlertDescription>
                </Alert>
              )}
            </>
          )}
          
          {status === 'error' && (
            <>
              <div className="rounded-full bg-red-100 p-3">
                <AlertCircle className="h-10 w-10 text-red-600" />
              </div>
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Verification Failed</AlertTitle>
                <AlertDescription>
                  {errorMessage || 'Your verification link may have expired or is invalid. Please try again.'}
                </AlertDescription>
              </Alert>
            </>
          )}
        </CardContent>
        <CardFooter className="flex flex-col gap-2">
          {status === 'success' && email && (
            <Button 
              className="w-full"
              onClick={() => navigate('/login')}
            >
              Sign in to your account
            </Button>
          )}
          
          {status === 'error' && (
            <Button 
              className="w-full"
              onClick={() => navigate('/register')}
            >
              Back to registration
            </Button>
          )}
          
          <Button 
            variant="outline" 
            className="w-full"
            onClick={() => navigate('/')}
          >
            Return to home page
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}