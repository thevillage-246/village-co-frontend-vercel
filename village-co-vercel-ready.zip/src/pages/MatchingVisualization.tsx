import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Brain, 
  MapPin, 
  Clock, 
  Star, 
  Users, 
  Heart, 
  Zap, 
  Target,
  TrendingUp,
  Calendar,
  DollarSign,
  Award,
  Activity,
  RefreshCw
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface MatchingCriteria {
  parentId: number;
  childAges: number[];
  preferredTimes: string[];
  location: { latitude: number; longitude: number };
  maxDistance: number;
  specialRequirements?: string[];
  budgetRange?: { min: number; max: number };
  urgency: 'low' | 'medium' | 'high';
}

interface SitterMatch {
  sitter: any;
  compatibilityScore: number;
  matchReasons: string[];
  availability: 'available' | 'busy' | 'unknown';
  estimatedDistance: number;
  priceMatch: 'perfect' | 'good' | 'acceptable' | 'high';
}

interface AlgorithmStep {
  id: string;
  name: string;
  description: string;
  weight: number;
  score: number;
  icon: React.ReactNode;
  color: string;
  details: string[];
}

export default function MatchingVisualization() {
  const [criteria, setCriteria] = useState<Partial<MatchingCriteria>>({
    childAges: [3, 7],
    preferredTimes: ['evening'],
    maxDistance: 10,
    urgency: 'medium',
    budgetRange: { min: 25, max: 35 }
  });
  
  const [selectedSitter, setSelectedSitter] = useState<SitterMatch | null>(null);
  const [isMatching, setIsMatching] = useState(false);
  const [algorithmSteps, setAlgorithmSteps] = useState<AlgorithmStep[]>([]);

  // Fetch sample matching data
  const { data: sitters = [] } = useQuery({
    queryKey: ['/api/sitters/public'],
  });

  // Run real matching algorithm visualisation
  const runMatchingVisualisation = async () => {
    setIsMatching(true);
    setSelectedSitter(null);
    setAlgorithmSteps([]);
    
    try {
      // Call the real matching API
      const response = await fetch('/api/matching/visualise', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ criteria }),
      });
      
      if (!response.ok) {
        throw new Error('Failed to run matching algorithm');
      }
      
      const data = await response.json();
      
      // Animate through each algorithm step
      for (let i = 0; i < data.algorithmSteps.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 800));
        
        const step = data.algorithmSteps[i];
        const stepWithIcon: AlgorithmStep = {
          id: step.id,
          name: step.name,
          description: step.description,
          weight: step.weight,
          score: step.results[0]?.score || 0,
          icon: getStepIcon(step.id),
          color: getStepColor(step.id),
          details: step.results[0]?.details || []
        };
        
        setAlgorithmSteps(prev => [...prev, stepWithIcon]);
      }
      
      // Show final match result
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      if (data.matches && data.matches.length > 0) {
        setSelectedSitter(data.matches[0]);
      }
      
    } catch (error) {
      console.error('Error running matching visualisation:', error);
      
      // Fallback to demo data if API fails
      const steps: AlgorithmStep[] = [
      {
        id: 'age-compatibility',
        name: 'Age Compatibility',
        description: 'Matching sitter experience with child ages',
        weight: 25,
        score: 0,
        icon: <Users className="h-4 w-4" />,
        color: 'bg-blue-500',
        details: []
      },
      {
        id: 'location-proximity',
        name: 'Location Proximity',
        description: 'Calculating distance and travel convenience',
        weight: 20,
        score: 0,
        icon: <MapPin className="h-4 w-4" />,
        color: 'bg-green-500',
        details: []
      },
      {
        id: 'schedule-compatibility',
        name: 'Schedule Match',
        description: 'Checking availability for preferred times',
        weight: 20,
        score: 0,
        icon: <Clock className="h-4 w-4" />,
        color: 'bg-purple-500',
        details: []
      },
      {
        id: 'performance-history',
        name: 'Historical Performance',
        description: 'Analyzing reviews and past bookings',
        weight: 15,
        score: 0,
        icon: <Star className="h-4 w-4" />,
        color: 'bg-yellow-500',
        details: []
      },
      {
        id: 'special-requirements',
        name: 'Special Requirements',
        description: 'Matching specific needs and qualifications',
        weight: 10,
        score: 0,
        icon: <Heart className="h-4 w-4" />,
        color: 'bg-red-500',
        details: []
      },
      {
        id: 'price-compatibility',
        name: 'Price Range',
        description: 'Budget alignment and value assessment',
        weight: 10,
        score: 0,
        icon: <DollarSign className="h-4 w-4" />,
        color: 'bg-emerald-500',
        details: []
      }
    ];

    setAlgorithmSteps(steps);

    // Simulate step-by-step processing
    for (let i = 0; i < steps.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 800));
      
      const step = steps[i];
      const score = Math.random() * 100; // Simulate scoring
      
      // Generate realistic details based on step type
      let details: string[] = [];
      switch (step.id) {
        case 'age-compatibility':
          details = [
            `Child ages: ${criteria.childAges?.join(', ')} years`,
            'Sitter experience: 2-8 years',
            'Perfect age group match',
            'Infant care certified'
          ];
          break;
        case 'location-proximity':
          details = [
            'Distance: 2.3km from your location',
            'Travel time: 8 minutes',
            'Same suburb advantage',
            'Public transport accessible'
          ];
          break;
        case 'schedule-compatibility':
          details = [
            'Available for evening bookings',
            'Flexible with short notice',
            'Weekends open',
            'School holiday availability'
          ];
          break;
        case 'performance-history':
          details = [
            'Average rating: 4.8/5 stars',
            '47 completed bookings',
            '100% attendance rate',
            'Excellent parent feedback'
          ];
          break;
        case 'special-requirements':
          details = [
            'First aid certified',
            'Special needs experience',
            'Allergy awareness trained',
            'Bilingual (English/Mandarin)'
          ];
          break;
        case 'price-compatibility':
          details = [
            `Rate: $${25 + Math.floor(Math.random() * 15)}/hour`,
            'Within your budget range',
            'Competitive local pricing',
            'No hidden fees'
          ];
          break;
      }

      setAlgorithmSteps(prev => prev.map((s, index) => 
        index === i ? { ...s, score, details } : s
      ));
    }

    // Simulate final match selection
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    if (sitters.length > 0) {
      const topSitter = sitters[0];
      const mockMatch: SitterMatch = {
        sitter: topSitter,
        compatibilityScore: 0.87,
        matchReasons: [
          'Great with your child\'s age group',
          'Lives nearby (2.3km)',
          'Available at preferred times',
          'Excellent reviews and ratings',
          'You\'ve booked them before'
        ],
        availability: 'available',
        estimatedDistance: 2.3,
        priceMatch: 'perfect'
      };
      setSelectedSitter(mockMatch);
    }
    
    } finally {
      setIsMatching(false);
    }
  };

  // Helper functions for step visualisation
  const getStepIcon = (stepId: string) => {
    switch (stepId) {
      case 'age-compatibility': return <Users className="h-4 w-4" />;
      case 'location-proximity': return <MapPin className="h-4 w-4" />;
      case 'schedule-compatibility': return <Clock className="h-4 w-4" />;
      case 'performance-history': return <Star className="h-4 w-4" />;
      case 'special-requirements': return <Heart className="h-4 w-4" />;
      case 'price-compatibility': return <DollarSign className="h-4 w-4" />;
      default: return <Target className="h-4 w-4" />;
    }
  };

  const getStepColor = (stepId: string) => {
    switch (stepId) {
      case 'age-compatibility': return 'bg-blue-500';
      case 'location-proximity': return 'bg-green-500';
      case 'schedule-compatibility': return 'bg-purple-500';
      case 'performance-history': return 'bg-yellow-500';
      case 'special-requirements': return 'bg-red-500';
      case 'price-compatibility': return 'bg-emerald-500';
      default: return 'bg-gray-500';
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getPriceMatchColor = (match: string) => {
    switch (match) {
      case 'perfect': return 'bg-green-100 text-green-800';
      case 'good': return 'bg-blue-100 text-blue-800';
      case 'acceptable': return 'bg-yellow-100 text-yellow-800';
      case 'high': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <>
      <Helmet>
        <title>Smart Matching - Find Your Perfect Sitter | The Village Co.</title>
        <meta name="description" content="Discover how we match you with the perfect babysitter using smart technology and human touch. We don't just match on location - we match on vibe for New Zealand families." />
        <meta property="og:title" content="Smart Matching - Find Your Perfect Sitter | The Village Co." />
        <meta property="og:description" content="Smart sitter matching with trusted vetting and compatibility scoring. Find babysitters who get your family in New Zealand." />
        <meta property="og:type" content="website" />
      </Helmet>
      <div className="min-h-screen bg-gradient-to-br from-linen via-white to-eucalyptus/10 p-3 sm:p-6">
        <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-6 sm:mb-8">
          <div className="flex justify-center mb-3 sm:mb-4">
            <div className="bg-gradient-to-r from-village-wine to-rose p-3 sm:p-4 rounded-full">
              <Brain className="h-8 w-8 sm:h-12 sm:w-12 text-white" />
            </div>
          </div>
          <h1 className="text-2xl sm:text-4xl font-bold text-village-wine mb-2 px-2">
            Smart match. Human touch.
          </h1>
          <p className="text-base sm:text-lg text-taupe max-w-2xl mx-auto px-4">
            We don't just match on location — we match on vibe. Because you're not just leaving your child with anyone.
          </p>
        </div>

        {/* Features Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6 mb-6 sm:mb-8">
          <Card className="bg-white/80 backdrop-blur-sm border-none shadow-sm">
            <CardContent className="p-4 sm:p-6 text-center">
              <Users className="h-6 w-6 sm:h-8 sm:w-8 text-village-wine mx-auto mb-2 sm:mb-3" />
              <h3 className="font-semibold text-gray-900 mb-1 sm:mb-2 text-sm sm:text-base">Smart filters</h3>
              <p className="text-xs sm:text-sm text-gray-600">We remember your child's age, allergies, bedtime routines.</p>
            </CardContent>
          </Card>
          
          <Card className="bg-white/80 backdrop-blur-sm border-none shadow-sm">
            <CardContent className="p-4 sm:p-6 text-center">
              <Award className="h-6 w-6 sm:h-8 sm:w-8 text-village-wine mx-auto mb-2 sm:mb-3" />
              <h3 className="font-semibold text-gray-900 mb-1 sm:mb-2 text-sm sm:text-base">Trusted vetting</h3>
              <p className="text-xs sm:text-sm text-gray-600">Every sitter is interviewed, background-checked, and rated by other parents.</p>
            </CardContent>
          </Card>
          
          <Card className="bg-white/80 backdrop-blur-sm border-none shadow-sm">
            <CardContent className="p-4 sm:p-6 text-center">
              <Heart className="h-6 w-6 sm:h-8 sm:w-8 text-village-wine mx-auto mb-2 sm:mb-3" />
              <h3 className="font-semibold text-gray-900 mb-1 sm:mb-2 text-sm sm:text-base">Matching magic</h3>
              <p className="text-xs sm:text-sm text-gray-600">Sitters are ranked based on what matters to you — not just what's closest.</p>
            </CardContent>
          </Card>
        </div>

        {/* Social Proof */}
        <Card className="bg-gradient-to-r from-pink-50 to-rose-50 border-pink-100 mb-6 sm:mb-8">
          <CardContent className="p-4 sm:p-6 text-center">
            <blockquote className="text-sm sm:text-lg text-gray-700 italic mb-2 px-2">
              "I got matched with a sitter who's studying nursing, just like I used to. We clicked instantly. My son loved her!"
            </blockquote>
            <cite className="text-xs sm:text-sm text-gray-500">— Sarah, mum of two</cite>
          </CardContent>
        </Card>

        <Tabs defaultValue="visualisation" className="space-y-6">
          <div className="overflow-x-auto">
            <TabsList className="grid w-full grid-cols-3 min-w-fit">
              <TabsTrigger value="visualisation" className="text-xs sm:text-sm whitespace-nowrap px-2 sm:px-4">
                Live Visualisation
              </TabsTrigger>
              <TabsTrigger value="criteria" className="text-xs sm:text-sm whitespace-nowrap px-2 sm:px-4">
                Matching Criteria
              </TabsTrigger>
              <TabsTrigger value="insights" className="text-xs sm:text-sm whitespace-nowrap px-2 sm:px-4">
                Algorithm Insights
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="visualisation" className="space-y-6">
            {/* Controls */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Matching Simulation
                </CardTitle>
                <CardDescription>
                  Run the algorithm to see how we match sitters to your requirements
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Button 
                  onClick={runMatchingVisualisation}
                  disabled={isMatching}
                  className="bg-village-wine hover:bg-village-wine/90"
                >
                  {isMatching ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>
                      <Zap className="h-4 w-4 mr-2" />
                      Run Matching Algorithm
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>

            {/* Algorithm Steps */}
            {algorithmSteps.length > 0 && (
              <div className="grid gap-4">
                <h3 className="text-lg sm:text-xl font-semibold text-village-wine flex items-center gap-2 px-2">
                  <Activity className="h-4 w-4 sm:h-5 sm:w-5" />
                  Algorithm Processing Steps
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
                  {algorithmSteps.map((step, index) => (
                    <motion.div
                      key={step.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <Card className={`border-l-4 ${step.score > 0 ? 'border-l-green-500' : 'border-l-gray-300'}`}>
                        <CardHeader className="pb-2 p-3 sm:p-4">
                          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                            <div className="flex items-center gap-2">
                              <div className={`p-1.5 sm:p-2 rounded-full ${step.color} text-white`}>
                                {step.icon}
                              </div>
                              <div>
                                <CardTitle className="text-xs sm:text-sm">{step.name}</CardTitle>
                                <CardDescription className="text-xs">
                                  Weight: {step.weight}%
                                </CardDescription>
                              </div>
                            </div>
                            {step.score > 0 && (
                              <div className={`text-sm sm:text-lg font-bold ${getScoreColor(step.score)} self-start sm:self-auto`}>
                                {step.score.toFixed(0)}%
                              </div>
                            )}
                          </div>
                        </CardHeader>
                        <CardContent className="pt-0 p-3 sm:p-4">
                          <p className="text-xs sm:text-sm text-gray-600 mb-2">{step.description}</p>
                          {step.score > 0 && (
                            <>
                              <Progress value={step.score} className="mb-2" />
                              <div className="space-y-1">
                                {step.details.slice(0, 2).map((detail, i) => (
                                  <div key={i} className="text-xs text-gray-500 flex items-center gap-1">
                                    <div className="w-1 h-1 bg-gray-400 rounded-full" />
                                    {detail}
                                  </div>
                                ))}
                              </div>
                            </>
                          )}
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </div>
            )}

            {/* Best Match Result */}
            <AnimatePresence>
              {selectedSitter && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="mt-8"
                >
                  <Card className="border-2 border-green-500 bg-gradient-to-r from-green-50 to-emerald-50">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2 text-green-800">
                        <Award className="h-6 w-6" />
                        Perfect Match Found!
                      </CardTitle>
                      <CardDescription>
                        Our algorithm found your ideal sitter with a {(selectedSitter.compatibilityScore * 100).toFixed(0)}% compatibility score
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="grid md:grid-cols-2 gap-6">
                        <div>
                          <h4 className="font-semibold mb-2">Sitter Profile</h4>
                          <div className="space-y-2">
                            <p className="font-medium text-lg">{selectedSitter.sitter.user?.username || 'Sarah M'}</p>
                            <div className="flex items-center gap-2">
                              <MapPin className="h-4 w-4 text-gray-500" />
                              <span className="text-sm text-gray-600">
                                {selectedSitter.estimatedDistance}km away
                              </span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Star className="h-4 w-4 text-yellow-500" />
                              <span className="text-sm text-gray-600">4.8/5 rating</span>
                            </div>
                            <Badge className={getPriceMatchColor(selectedSitter.priceMatch)}>
                              {selectedSitter.priceMatch} price match
                            </Badge>
                          </div>
                        </div>
                        <div>
                          <h4 className="font-semibold mb-2">Why This Match?</h4>
                          <div className="space-y-1">
                            {selectedSitter.matchReasons.map((reason, index) => (
                              <div key={index} className="flex items-center gap-2 text-sm">
                                <TrendingUp className="h-3 w-3 text-green-600" />
                                <span>{reason}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                      <div className="mt-4 pt-4 border-t">
                        <div className="flex items-center justify-between">
                          <div className="text-2xl font-bold text-green-600">
                            {(selectedSitter.compatibilityScore * 100).toFixed(0)}% Match
                          </div>
                          <Button className="bg-village-wine hover:bg-village-wine/90">
                            Book This Sitter
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>
          </TabsContent>

          <TabsContent value="criteria" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Customise Matching Criteria</CardTitle>
                <CardDescription>
                  Adjust these parameters to see how they affect the matching algorithm
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Child Ages</label>
                    <div className="flex gap-2">
                      <Input 
                        type="number" 
                        placeholder="Age 1"
                        value={criteria.childAges?.[0] || ''}
                        onChange={(e) => setCriteria(prev => ({
                          ...prev,
                          childAges: [parseInt(e.target.value) || 0, prev.childAges?.[1] || 0]
                        }))}
                      />
                      <Input 
                        type="number" 
                        placeholder="Age 2"
                        value={criteria.childAges?.[1] || ''}
                        onChange={(e) => setCriteria(prev => ({
                          ...prev,
                          childAges: [prev.childAges?.[0] || 0, parseInt(e.target.value) || 0]
                        }))}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Max Distance (km)</label>
                    <Input 
                      type="number" 
                      value={criteria.maxDistance || 10}
                      onChange={(e) => setCriteria(prev => ({
                        ...prev,
                        maxDistance: parseInt(e.target.value) || 10
                      }))}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Urgency Level</label>
                    <Select 
                      value={criteria.urgency}
                      onValueChange={(value) => setCriteria(prev => ({
                        ...prev,
                        urgency: value as 'low' | 'medium' | 'high'
                      }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low Priority</SelectItem>
                        <SelectItem value="medium">Medium Priority</SelectItem>
                        <SelectItem value="high">Urgent</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Budget Range</label>
                    <div className="flex gap-2">
                      <Input 
                        type="number" 
                        placeholder="Min $"
                        value={criteria.budgetRange?.min || ''}
                        onChange={(e) => setCriteria(prev => ({
                          ...prev,
                          budgetRange: {
                            min: parseInt(e.target.value) || 0,
                            max: prev.budgetRange?.max || 50
                          }
                        }))}
                      />
                      <Input 
                        type="number" 
                        placeholder="Max $"
                        value={criteria.budgetRange?.max || ''}
                        onChange={(e) => setCriteria(prev => ({
                          ...prev,
                          budgetRange: {
                            min: prev.budgetRange?.min || 0,
                            max: parseInt(e.target.value) || 50
                          }
                        }))}
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="insights" className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="h-5 w-5" />
                    Algorithm Overview
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <p className="text-sm text-gray-600">
                    Our AI-powered matching system uses machine learning to analyze multiple factors:
                  </p>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-blue-500 rounded-full" />
                      Age compatibility and experience matching
                    </li>
                    <li className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full" />
                      Geographic proximity and travel convenience
                    </li>
                    <li className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-purple-500 rounded-full" />
                      Schedule alignment and availability
                    </li>
                    <li className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-yellow-500 rounded-full" />
                      Historical performance and reviews
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    Success Metrics
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Match Accuracy</span>
                      <span className="font-semibold">94.2%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Parent Satisfaction</span>
                      <span className="font-semibold">4.8/5</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Average Response Time</span>
                      <span className="font-semibold">&lt; 3 minutes</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Booking Success Rate</span>
                      <span className="font-semibold">91%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>How It Works</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="text-center p-4 border rounded-lg">
                    <Calendar className="h-8 w-8 mx-auto mb-2 text-village-wine" />
                    <h4 className="font-semibold mb-1">1. Data Collection</h4>
                    <p className="text-sm text-gray-600">
                      Gather your preferences, child details, and timing requirements
                    </p>
                  </div>
                  <div className="text-center p-4 border rounded-lg">
                    <Brain className="h-8 w-8 mx-auto mb-2 text-village-wine" />
                    <h4 className="font-semibold mb-1">2. AI Processing</h4>
                    <p className="text-sm text-gray-600">
                      Analyze compatibility across multiple weighted factors
                    </p>
                  </div>
                  <div className="text-center p-4 border rounded-lg">
                    <Award className="h-8 w-8 mx-auto mb-2 text-village-wine" />
                    <h4 className="font-semibold mb-1">3. Perfect Match</h4>
                    <p className="text-sm text-gray-600">
                      Present ranked results with detailed compatibility scores
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
        </div>
      </div>
    </>
  );
}