import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { Clipboard, Send, Check, X, ChevronRight, Users, BookOpen, Shield, Bell, Settings } from 'lucide-react';

export default function StandaloneAdminPage() {
  const [stats, setStats] = useState({
    totalUsers: 156,
    activeParents: 89,
    activeSitters: 42,
    pendingVerifications: 7,
    bookingsToday: 12,
    totalRevenue: 15750,
    averageRating: 4.8
  });
  
  const [activeTab, setActiveTab] = useState('overview');
  const [activeUsers, setActiveUsers] = useState([
    { id: 1, name: 'Sarah Johnson', role: 'parent', lastActive: '10 min ago', status: 'active' },
    { id: 2, name: 'Michael Chen', role: 'sitter', lastActive: '25 min ago', status: 'active' },
    { id: 3, name: 'Jessica Smith', role: 'parent', lastActive: '1 hour ago', status: 'active' },
    { id: 4, name: 'David Wilson', role: 'sitter', lastActive: '3 hours ago', status: 'active' },
    { id: 5, name: 'Emily Davis', role: 'parent', lastActive: '5 hours ago', status: 'inactive' }
  ]);
  
  const [recentBookings, setRecentBookings] = useState([
    { id: 1001, parent: 'Sarah Johnson', sitter: 'Michael Chen', date: '2025-05-13', time: '18:00-22:00', status: 'confirmed' },
    { id: 1002, parent: 'Jessica Smith', sitter: 'David Wilson', date: '2025-05-13', time: '14:00-17:00', status: 'completed' },
    { id: 1003, parent: 'Emma Brown', sitter: 'Sophie Taylor', date: '2025-05-14', time: '09:00-15:00', status: 'pending' },
    { id: 1004, parent: 'James Williams', sitter: 'Oliver Lewis', date: '2025-05-15', time: '17:30-21:30', status: 'confirmed' }
  ]);
  
  const [pendingVerifications, setPendingVerifications] = useState([
    { id: 101, name: 'Olivia Lee', appliedDate: '2025-05-10', status: 'pending_verification' },
    { id: 102, name: 'William Clark', appliedDate: '2025-05-11', status: 'pending_verification' },
    { id: 103, name: 'Sophia Martin', appliedDate: '2025-05-12', status: 'in_progress' },
    { id: 104, name: 'Noah Garcia', appliedDate: '2025-05-12', status: 'pending_verification' }
  ]);
  
  const [selectedNotificationGroup, setSelectedNotificationGroup] = useState('');
  const [notificationMessage, setNotificationMessage] = useState('');
  const { toast } = useToast();
  const [, navigate] = useLocation();
  
  const handleSendNotification = () => {
    if (!selectedNotificationGroup || !notificationMessage.trim()) {
      toast({
        title: 'Missing Information',
        description: 'Please select a user group and enter a message',
        variant: 'destructive'
      });
      return;
    }
    
    toast({
      title: 'Notification Sent',
      description: `Message sent to ${selectedNotificationGroup} users`,
    });
    
    // Clear form
    setSelectedNotificationGroup('');
    setNotificationMessage('');
  };
  
  const handleApprove = (id: number) => {
    setPendingVerifications(prev => prev.map(item => 
      item.id === id ? { ...item, status: 'approved' } : item
    ));
    
    toast({
      title: 'Sitter Approved',
      description: 'Sitter has been approved successfully',
    });
  };
  
  const handleReject = (id: number) => {
    setPendingVerifications(prev => prev.map(item => 
      item.id === id ? { ...item, status: 'rejected' } : item
    ));
    
    toast({
      title: 'Verification Rejected',
      description: 'Sitter verification has been rejected',
      variant: 'destructive'
    });
  };
  
  const handleBackToLogin = () => {
    navigate('/direct-login');
  };
  
  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-wine shadow-md">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-white">Admin Dashboard</h1>
          <Button 
            variant="outline" 
            className="bg-transparent text-white border-white hover:bg-white hover:text-wine"
            onClick={handleBackToLogin}
          >
            Back to Login
          </Button>
        </div>
      </header>
      
      <div className="container mx-auto px-4 py-8 flex flex-col md:flex-row gap-6">
        {/* Sidebar */}
        <div className="w-full md:w-64 flex-shrink-0">
          <Card>
            <CardContent className="p-4">
              <nav className="space-y-2">
                <Button 
                  variant={activeTab === 'overview' ? 'default' : 'ghost'} 
                  className="w-full justify-start" 
                  onClick={() => setActiveTab('overview')}
                >
                  <BookOpen className="mr-2 h-5 w-5" />
                  Dashboard
                </Button>
                <Button 
                  variant={activeTab === 'users' ? 'default' : 'ghost'} 
                  className="w-full justify-start" 
                  onClick={() => setActiveTab('users')}
                >
                  <Users className="mr-2 h-5 w-5" />
                  Users
                </Button>
                <Button 
                  variant={activeTab === 'verifications' ? 'default' : 'ghost'} 
                  className="w-full justify-start" 
                  onClick={() => setActiveTab('verifications')}
                >
                  <Shield className="mr-2 h-5 w-5" />
                  Verifications
                </Button>
                <Button 
                  variant={activeTab === 'notifications' ? 'default' : 'ghost'} 
                  className="w-full justify-start" 
                  onClick={() => setActiveTab('notifications')}
                >
                  <Bell className="mr-2 h-5 w-5" />
                  Notifications
                </Button>
                <Button 
                  variant={activeTab === 'settings' ? 'default' : 'ghost'} 
                  className="w-full justify-start" 
                  onClick={() => setActiveTab('settings')}
                >
                  <Settings className="mr-2 h-5 w-5" />
                  Settings
                </Button>
              </nav>
            </CardContent>
          </Card>
        </div>
        
        {/* Main Content */}
        <div className="flex-1">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex flex-col">
                      <span className="text-sm font-medium text-muted-foreground">Total Users</span>
                      <span className="text-3xl font-bold">{stats.totalUsers}</span>
                      <span className="text-xs text-green-500 mt-1">+12% from last month</span>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-6">
                    <div className="flex flex-col">
                      <span className="text-sm font-medium text-muted-foreground">Active Sitters</span>
                      <span className="text-3xl font-bold">{stats.activeSitters}</span>
                      <span className="text-xs text-green-500 mt-1">+5% from last month</span>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-6">
                    <div className="flex flex-col">
                      <span className="text-sm font-medium text-muted-foreground">Today's Bookings</span>
                      <span className="text-3xl font-bold">{stats.bookingsToday}</span>
                      <span className="text-xs text-green-500 mt-1">+2 from yesterday</span>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-6">
                    <div className="flex flex-col">
                      <span className="text-sm font-medium text-muted-foreground">Total Revenue</span>
                      <span className="text-3xl font-bold">${stats.totalRevenue.toLocaleString()}</span>
                      <span className="text-xs text-green-500 mt-1">+8% from last month</span>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Recent Bookings</CardTitle>
                    <CardDescription>Latest booking activity across the platform</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ID</TableHead>
                          <TableHead>Parent</TableHead>
                          <TableHead>Sitter</TableHead>
                          <TableHead>Date/Time</TableHead>
                          <TableHead>Status</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {recentBookings.map(booking => (
                          <TableRow key={booking.id}>
                            <TableCell className="font-medium">{booking.id}</TableCell>
                            <TableCell>{booking.parent}</TableCell>
                            <TableCell>{booking.sitter}</TableCell>
                            <TableCell>{`${booking.date} ${booking.time}`}</TableCell>
                            <TableCell>
                              <Badge className={
                                booking.status === 'confirmed' ? 'bg-green-100 text-green-800' :
                                booking.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                                'bg-blue-100 text-blue-800'
                              }>
                                {booking.status}
                              </Badge>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                  <CardFooter className="justify-end">
                    <Button variant="ghost" className="text-sm">View All Bookings <ChevronRight className="ml-1 h-4 w-4" /></Button>
                  </CardFooter>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>Pending Verifications</CardTitle>
                    <CardDescription>Sitters waiting for verification</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Name</TableHead>
                          <TableHead>Applied Date</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {pendingVerifications.map(item => (
                          <TableRow key={item.id}>
                            <TableCell className="font-medium">{item.name}</TableCell>
                            <TableCell>{item.appliedDate}</TableCell>
                            <TableCell>
                              <Badge className={
                                item.status === 'approved' ? 'bg-green-100 text-green-800' :
                                item.status === 'rejected' ? 'bg-red-100 text-red-800' :
                                item.status === 'in_progress' ? 'bg-blue-100 text-blue-800' :
                                'bg-yellow-100 text-yellow-800'
                              }>
                                {item.status.replace('_', ' ')}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex space-x-2">
                                {item.status !== 'approved' && item.status !== 'rejected' && (
                                  <>
                                    <Button 
                                      size="sm" 
                                      variant="outline" 
                                      className="h-8 w-8 p-0"
                                      onClick={() => handleApprove(item.id)}
                                    >
                                      <Check className="h-4 w-4" />
                                    </Button>
                                    <Button 
                                      size="sm" 
                                      variant="outline" 
                                      className="h-8 w-8 p-0"
                                      onClick={() => handleReject(item.id)}
                                    >
                                      <X className="h-4 w-4" />
                                    </Button>
                                  </>
                                )}
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                  <CardFooter className="justify-end">
                    <Button variant="ghost" className="text-sm">View All Verifications <ChevronRight className="ml-1 h-4 w-4" /></Button>
                  </CardFooter>
                </Card>
              </div>
            </div>
          )}
          
          {activeTab === 'notifications' && (
            <Card>
              <CardHeader>
                <CardTitle>Send Notifications</CardTitle>
                <CardDescription>Send notifications to users</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="recipient-group">Recipient Group</Label>
                  <Select value={selectedNotificationGroup} onValueChange={setSelectedNotificationGroup}>
                    <SelectTrigger id="recipient-group">
                      <SelectValue placeholder="Select a group" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Users</SelectItem>
                      <SelectItem value="parents">All Parents</SelectItem>
                      <SelectItem value="sitters">All Sitters</SelectItem>
                      <SelectItem value="inactive">Inactive Users</SelectItem>
                      <SelectItem value="new">New Users</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="notification-message">Message</Label>
                  <Input
                    id="notification-message"
                    placeholder="Enter notification message"
                    value={notificationMessage}
                    onChange={(e) => setNotificationMessage(e.target.value)}
                  />
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline">
                  <Clipboard className="mr-2 h-4 w-4" />
                  Save as Template
                </Button>
                <Button onClick={handleSendNotification}>
                  <Send className="mr-2 h-4 w-4" />
                  Send Notification
                </Button>
              </CardFooter>
            </Card>
          )}
          
          {activeTab === 'users' && (
            <Card>
              <CardHeader>
                <CardTitle>Active Users</CardTitle>
                <CardDescription>Currently active users on the platform</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead>Last Active</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {activeUsers.map(user => (
                      <TableRow key={user.id}>
                        <TableCell className="font-medium">{user.name}</TableCell>
                        <TableCell>{user.role}</TableCell>
                        <TableCell>{user.lastActive}</TableCell>
                        <TableCell>
                          <Badge className={user.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>
                            {user.status}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
              <CardFooter className="justify-end">
                <Button variant="ghost" className="text-sm">View All Users <ChevronRight className="ml-1 h-4 w-4" /></Button>
              </CardFooter>
            </Card>
          )}
          
          {activeTab === 'verifications' && (
            <Card>
              <CardHeader>
                <CardTitle>Verification Queue</CardTitle>
                <CardDescription>Sitters waiting for verification</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Applied Date</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {pendingVerifications.map(item => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.name}</TableCell>
                        <TableCell>{item.appliedDate}</TableCell>
                        <TableCell>
                          <Badge className={
                            item.status === 'approved' ? 'bg-green-100 text-green-800' :
                            item.status === 'rejected' ? 'bg-red-100 text-red-800' :
                            item.status === 'in_progress' ? 'bg-blue-100 text-blue-800' :
                            'bg-yellow-100 text-yellow-800'
                          }>
                            {item.status.replace('_', ' ')}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            {item.status !== 'approved' && item.status !== 'rejected' && (
                              <>
                                <Button 
                                  size="sm" 
                                  variant="outline" 
                                  className="h-8 w-8 p-0"
                                  onClick={() => handleApprove(item.id)}
                                >
                                  <Check className="h-4 w-4" />
                                </Button>
                                <Button 
                                  size="sm" 
                                  variant="outline" 
                                  className="h-8 w-8 p-0"
                                  onClick={() => handleReject(item.id)}
                                >
                                  <X className="h-4 w-4" />
                                </Button>
                              </>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          )}
          
          {activeTab === 'settings' && (
            <Card>
              <CardHeader>
                <CardTitle>Platform Settings</CardTitle>
                <CardDescription>Configure system-wide settings</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="general">
                  <TabsList className="grid w-full grid-cols-3">
                    <TabsTrigger value="general">General</TabsTrigger>
                    <TabsTrigger value="payments">Payments</TabsTrigger>
                    <TabsTrigger value="security">Security</TabsTrigger>
                  </TabsList>
                  <TabsContent value="general" className="space-y-4 mt-4">
                    <div className="space-y-2">
                      <Label htmlFor="platform-name">Platform Name</Label>
                      <Input id="platform-name" defaultValue="The Village Co." />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="support-email">Support Email</Label>
                      <Input id="support-email" defaultValue="support@ittakesavillage.nz" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="maintenance-mode">Maintenance Mode</Label>
                      <Select defaultValue="off">
                        <SelectTrigger id="maintenance-mode">
                          <SelectValue placeholder="Select mode" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="off">Off</SelectItem>
                          <SelectItem value="scheduled">Scheduled</SelectItem>
                          <SelectItem value="on">On</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </TabsContent>
                  <TabsContent value="payments" className="space-y-4 mt-4">
                    <div className="space-y-2">
                      <Label htmlFor="platform-fee">Platform Fee (%)</Label>
                      <Input id="platform-fee" type="number" defaultValue="15" />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="payout-schedule">Payout Schedule</Label>
                      <Select defaultValue="weekly">
                        <SelectTrigger id="payout-schedule">
                          <SelectValue placeholder="Select schedule" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="daily">Daily</SelectItem>
                          <SelectItem value="weekly">Weekly</SelectItem>
                          <SelectItem value="biweekly">Bi-weekly</SelectItem>
                          <SelectItem value="monthly">Monthly</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </TabsContent>
                  <TabsContent value="security" className="space-y-4 mt-4">
                    <div className="space-y-2">
                      <Label htmlFor="two-factor">Two-Factor Authentication</Label>
                      <Select defaultValue="optional">
                        <SelectTrigger id="two-factor">
                          <SelectValue placeholder="Select requirement" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="disabled">Disabled</SelectItem>
                          <SelectItem value="optional">Optional</SelectItem>
                          <SelectItem value="required">Required</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="session-timeout">Session Timeout (minutes)</Label>
                      <Input id="session-timeout" type="number" defaultValue="60" />
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
              <CardFooter className="justify-end">
                <Button variant="outline" className="mr-2">Cancel</Button>
                <Button>Save Changes</Button>
              </CardFooter>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}