import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CreditCard, CheckCircle, AlertCircle, RefreshCw, ArrowLeft } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useLocation, Link } from 'wouter';

export default function SitterStripeConnect() {
  const { currentUser } = useAuth();
  const { toast } = useToast();
  const [location] = useLocation();
  const [isSetupInProgress, setIsSetupInProgress] = useState(false);

  // Handle URL parameters for redirect from Stripe
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const setupComplete = urlParams.get('setup');
    const errorMessage = urlParams.get('error');
    
    if (setupComplete === 'complete') {
      toast({
        title: "Payment Setup Complete",
        description: "Your bank account has been connected successfully.",
      });
      // Clean up URL parameters
      window.history.replaceState({}, document.title, window.location.pathname);
    } else if (errorMessage) {
      toast({
        title: "Setup Issue",
        description: "There was an issue with your payment setup. Please try again.",
        variant: "destructive",
      });
      // Clean up URL parameters
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, [toast]);

  // Fetch current Stripe Connect status
  const { data: stripeStatus, isLoading, refetch } = useQuery({
    queryKey: ['/api/sitter/stripe-connect-status'],
    enabled: !!currentUser,
    staleTime: 0, // Always fetch fresh data
    gcTime: 0, // Don't cache (TanStack Query v5 uses gcTime instead of cacheTime)
    refetchOnWindowFocus: true, // Refetch when window is focused
    refetchOnMount: true, // Always refetch on mount
    retry: false, // Don't retry failed requests automatically
    networkMode: 'always', // Always make network requests, even when offline
  });

  // Debug logging
  console.log('Stripe Connect Status:', stripeStatus);

  // Setup Stripe Connect mutation
  const setupMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/sitter/stripe-connect-setup');
      return response;
    },
    onSuccess: (data: any) => {
      // Handle successful setup response
      if (data.success && data.accountId) {
        setIsSetupInProgress(true);
        
        // For test mode (development), simulate completion
        if (data.onboardingUrl?.includes('test=true') || data.message?.includes('Test')) {
          toast({
            title: "Payment Setup Complete",
            description: "Test payment account has been connected successfully.",
          });
          
          // Force immediate refresh of status
          queryClient.removeQueries({ queryKey: ['/api/sitter/stripe-connect-status'] });
          setTimeout(async () => {
            await refetch(); // Force fresh fetch
            setIsSetupInProgress(false);
          }, 500);
        } else if (data.onboardingUrl && !data.onboardingUrl.includes('test=true')) {
          // Redirect to actual Stripe onboarding for production
          window.location.href = data.onboardingUrl;
        } else {
          // Fallback - refresh status immediately since account exists
          toast({
            title: "Payment Account Ready",
            description: "Your payment account is already configured.",
          });
          setTimeout(async () => {
            await queryClient.invalidateQueries({ queryKey: ['/api/sitter/stripe-connect-status'] });
            await refetch(); // Force refresh after a brief delay
            setIsSetupInProgress(false);
          }, 500);
        }
      }
    },
    onError: (error: any) => {
      toast({
        title: "Setup Failed",
        description: error.message || "Failed to set up payment account",
        variant: "destructive",
      });
    }
  });

  const handleSetupPayments = () => {
    setupMutation.mutate();
  };

  if (isLoading) {
    return (
      <div className="container max-w-4xl py-8">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F9F5F0]">
      <div className="container max-w-4xl py-8">
        {/* Back to Dashboard Link */}
        <div className="mb-6">
          <Link href="/sitter/dashboard">
            <Button variant="ghost" className="text-village-wine hover:text-village-wine/80 hover:bg-village-wine/10 p-0 h-auto font-normal">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
        </div>

        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-[#6B3E4B] mb-2" style={{ fontFamily: 'Satoshi, sans-serif' }}>
            Payment Setup
          </h1>
          <p className="text-lg text-gray-600" style={{ fontFamily: 'DM Sans, sans-serif' }}>
            Connect your bank account to receive payments for completed babysitting jobs.
          </p>
        </div>

        {/* Status Card */}
        <Card className="bg-white border-0 rounded-xl shadow-lg mb-6">
          <CardHeader>
            <CardTitle className="flex items-center justify-between" style={{ fontFamily: 'Satoshi, sans-serif' }}>
              <div className="flex items-center gap-3">
                <CreditCard className="h-6 w-6 text-[#6B3E4B]" />
                Payment Account Status
              </div>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => refetch()}
                disabled={isLoading}
                className="text-xs"
              >
                {isLoading ? 'Refreshing...' : 'Refresh'}
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {stripeStatus?.connected ? (
              <div className="space-y-4">
                <div className="flex items-center gap-3 text-green-600">
                  <CheckCircle className="h-5 w-5" />
                  <span className="font-medium">Payment account connected</span>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="text-gray-600">Details Submitted</span>
                    <span className={`font-medium ${stripeStatus.detailsSubmitted ? 'text-green-600' : 'text-orange-500'}`}>
                      {stripeStatus.detailsSubmitted ? 'Complete' : 'Pending'}
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="text-gray-600">Payments Enabled</span>
                    <span className={`font-medium ${stripeStatus.chargesEnabled ? 'text-green-600' : 'text-orange-500'}`}>
                      {stripeStatus.chargesEnabled ? 'Enabled' : 'Disabled'}
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="text-gray-600">Payouts Enabled</span>
                    <span className={`font-medium ${stripeStatus.payoutsEnabled ? 'text-green-600' : 'text-orange-500'}`}>
                      {stripeStatus.payoutsEnabled ? 'Enabled' : 'Disabled'}
                    </span>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="text-gray-600">Account ID</span>
                    <span className="font-mono text-sm text-gray-500">
                      {stripeStatus.accountId?.substring(0, 15)}...
                    </span>
                  </div>
                </div>

                {!stripeStatus.detailsSubmitted && (
                  <div className="mt-4 p-4 bg-orange-50 border border-orange-200 rounded-lg">
                    <div className="flex items-center gap-2 text-orange-600 mb-2">
                      <AlertCircle className="h-4 w-4" />
                      <span className="font-medium">Action Required</span>
                    </div>
                    <p className="text-orange-700 text-sm mb-3">
                      Complete your account setup to start receiving payments.
                    </p>
                    <Button 
                      onClick={handleSetupPayments}
                      disabled={setupMutation.isPending || isSetupInProgress}
                      className="bg-[#6B3E4B] hover:bg-[#5a3340] text-white"
                    >
                      {setupMutation.isPending || isSetupInProgress ? 'Setting up...' : 'Complete Setup'}
                    </Button>
                  </div>
                )}

                {stripeStatus.detailsSubmitted && stripeStatus.chargesEnabled && (
                  <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                    <div className="flex items-center gap-2 text-green-600 mb-2">
                      <CheckCircle className="h-4 w-4" />
                      <span className="font-medium">Ready to Receive Payments</span>
                    </div>
                    <p className="text-green-700 text-sm">
                      Your payment account is fully set up. You can now receive payments for completed babysitting jobs.
                    </p>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-8">
                <CreditCard className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2" style={{ fontFamily: 'Satoshi, sans-serif' }}>
                  No Payment Account Connected
                </h3>
                <p className="text-gray-600 mb-6" style={{ fontFamily: 'DM Sans, sans-serif' }}>
                  Connect your bank account to receive payments for babysitting jobs. This is handled securely through Stripe.
                </p>
                <Button 
                  onClick={handleSetupPayments}
                  disabled={setupMutation.isPending || isSetupInProgress}
                  className="bg-[#6B3E4B] hover:bg-[#5a3340] text-white px-8 py-3 rounded-xl shadow-lg"
                >
                  {setupMutation.isPending || isSetupInProgress ? 'Setting up...' : 'Connect Bank Account'}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Information Card */}
        <Card className="bg-white border-0 rounded-xl shadow-lg">
          <CardContent className="p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4" style={{ fontFamily: 'Satoshi, sans-serif' }}>
              How Payments Work
            </h3>
            <div className="space-y-3 text-gray-600" style={{ fontFamily: 'DM Sans, sans-serif' }}>
              <p>• Payments are processed automatically after each completed babysitting job</p>
              <p>• The Village Co. platform fee (5%) is deducted before payment to you</p>
              <p>• Funds are transferred directly to your bank account within 2-7 business days</p>
              <p>• You'll receive email notifications for all payments and transfers</p>
              <p>• Your banking information is securely handled by Stripe, our payment processor</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}