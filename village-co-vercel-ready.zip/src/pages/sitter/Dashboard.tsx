import React, { useState, useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Link, useLocation } from 'wouter';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { SitterEarnings } from '@/components/dashboard';
import { TrustBar } from '@/components/profiles';
import VerificationStatusDisplay from '@/components/sitters/VerificationStatusDisplay';
import VeriffVerification from '@/components/VeriffVerification';
import QualificationsManager from '@/components/sitters/QualificationsManager';
import SitterOnboardingChecklist from '@/components/sitters/SitterOnboardingChecklist';
import InstantNotifications from '@/components/messaging/InstantNotifications';
import MessageNotificationTester from '@/components/messaging/MessageNotificationTester';
import { Calendar, Users, Clock, Star, MessageSquare, ShieldCheck, User, CreditCard, DollarSign, TrendingUp } from 'lucide-react';

export default function SitterDashboard() {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('upcoming');
  const [, navigate] = useLocation();
  
  // Define types for our data
  interface Booking {
    id: number;
    start_time: string;
    end_time: string;
    sit_notes?: string;
    amount_paid?: number;
    parent: {
      id: number;
      first_name: string;
    };
    review?: {
      rating: number;
    };
    parent_review?: {
      rating: number;
    };
    children?: Array<{
      id: number;
      name: string;
      age: number;
    }>;
  }
  
  interface EarningsData {
    total: number;
    totalEarnings: number;
    completedBookings: number;
    monthlyEarnings?: Array<{month: string, amount: number}>;
    monthly: Array<{month: string, amount: number}>;
  }
  
  interface SitterProfile {
    id: number;
    userId: number;
    bio?: string;
    experience?: string;
    hourlyRate?: string;
    verificationStatus?: string;
    veriffCreatedAt?: string | Date;
    veriffVerificationId?: string;
    lastReminderSentAt?: string | Date;
    identityVerified?: boolean;
    firstAidCertDate?: Date | null;
    valuesQuizComplete?: boolean;
    monthlyTargetEarnings?: string;
    isActive?: boolean;
    profileComplete?: boolean;
    verificationNotes?: string;
  }

  interface Transaction {
    id: number;
    booking_id: number;
    amount: number;
    currency: string;
    status: 'pending' | 'completed' | 'failed';
    created_at: string;
    booking: {
      start_time: string;
      end_time: string;
      parent: {
        first_name: string;
      };
    };
  }
  
  // ALL HOOKS MUST BE CALLED BEFORE ANY CONDITIONAL RETURNS
  // Fetch sitter profile with verification status
  const { data: sitterProfile, isLoading: loadingSitterProfile } = useQuery<SitterProfile>({
    queryKey: ['/api/sitter/profile'],
    enabled: !!user
  });
  
  // Fetch upcoming bookings
  const { data: upcomingBookings = [] as Booking[], isLoading: loadingUpcoming } = useQuery<Booking[]>({
    queryKey: ['/api/sitter/bookings/upcoming'],
    enabled: !!user
  });
  
  // Fetch past bookings
  const { data: pastBookings = [] as Booking[], isLoading: loadingPast } = useQuery<Booking[]>({
    queryKey: ['/api/sitter/bookings/past'],
    enabled: !!user
  });
  
  // Fetch earnings data
  const { data: earningsData = {} as EarningsData, isLoading: loadingEarnings } = useQuery<EarningsData>({
    queryKey: ['/api/sitter/earnings'],
    enabled: !!user
  });

  // Fetch Stripe Connect status
  const { data: stripeStatus } = useQuery<{connected: boolean, detailsSubmitted: boolean}>({
    queryKey: ['/api/sitter/stripe-connect-status'],
    enabled: !!user
  });

  // Fetch transaction history
  const { data: transactions = [] as Transaction[], isLoading: loadingTransactions } = useQuery<Transaction[]>({
    queryKey: ['/api/sitter/transactions'],
    enabled: !!user
  });

  // Fetch sitter reviews
  const { data: reviewsData, isLoading: reviewsLoading } = useQuery<{reviews: any[], averageRating: number, totalReviews: number}>({
    queryKey: ['/api/sitter/reviews'],
    enabled: !!user
  });
  
  const reviewsInfo = reviewsData || { reviews: [], averageRating: 0, totalReviews: 0 };

  // Check if sitter has completed required onboarding steps
  const isOnboardingComplete = sitterProfile && 
    sitterProfile.bio && 
    sitterProfile.hourlyRate && 
    sitterProfile.experience &&
    (sitterProfile.identityVerified || sitterProfile.verificationStatus === 'approved') &&
    stripeStatus?.connected && stripeStatus?.detailsSubmitted;

  // Redirect to onboarding checklist if profile is incomplete
  useEffect(() => {
    if (!loadingSitterProfile && sitterProfile && !isOnboardingComplete) {
      // Check specific missing requirements to redirect appropriately
      const hasBasicProfile = sitterProfile.bio && sitterProfile.hourlyRate && sitterProfile.experience;
      const hasVerification = sitterProfile.identityVerified || sitterProfile.verificationStatus === 'approved';
      const hasStripeConnect = stripeStatus?.connected && stripeStatus?.detailsSubmitted;
      
      if (!hasBasicProfile || !hasVerification) {
        navigate('/sitter/onboarding');
      } else if (!hasStripeConnect) {
        navigate('/sitter/stripe-connect');
      }
    }
  }, [loadingSitterProfile, sitterProfile, isOnboardingComplete, stripeStatus, navigate]);

  // Show onboarding checklist for incomplete profiles - MOVED AFTER ALL HOOKS
  if (!loadingSitterProfile && sitterProfile && !isOnboardingComplete) {
    // Check what specific step is missing
    const hasBasicProfile = sitterProfile.bio && sitterProfile.hourlyRate && sitterProfile.experience;
    const hasVerification = sitterProfile.identityVerified || sitterProfile.verificationStatus === 'approved';
    const hasStripeConnect = stripeStatus?.connected && stripeStatus?.detailsSubmitted;
    
    if (!hasBasicProfile || !hasVerification) {
      return <SitterOnboardingChecklist />;
    } else if (!hasStripeConnect) {
      // This will be handled by the redirect above
      return null;
    }
  }

  // Calculate total earnings and booking count - handle null data
  const safeUpcomingBookings = upcomingBookings || [];
  const safePastBookings = pastBookings || [];
  
  // Use earnings data from API instead of calculating from bookings
  const totalEarned = earningsData?.totalEarnings || 0;
  const completedBookings = earningsData?.completedBookings || safePastBookings.length;
  
  // Get monthly target from sitter profile, default to 1000
  const monthlyTarget = sitterProfile?.monthlyTargetEarnings ? parseFloat(sitterProfile.monthlyTargetEarnings) : 1000;
  
  // Handle monthly target updates
  const handleTargetUpdate = (newTarget: number) => {
    // Invalidate the sitter profile query to refetch with updated target
    queryClient.invalidateQueries({ queryKey: ['/api/sitter/profile'] });
    // Also invalidate earnings query in case it's related
    queryClient.invalidateQueries({ queryKey: ['/api/sitter/earnings'] });
    // Force a refetch of the profile to ensure immediate update
    queryClient.refetchQueries({ queryKey: ['/api/sitter/profile'] });
  };
  
  // Sample monthly data for chart
  const monthlyEarnings = [
    { month: 'Jan', amount: 150 },
    { month: 'Feb', amount: 220 },
    { month: 'Mar', amount: 180 },
    { month: 'Apr', amount: 320 },
    { month: 'May', amount: 410 },
    { month: 'Jun', amount: 280 },
  ];
  
  return (
    <div className="container max-w-6xl py-8">
      <div className="flex flex-col space-y-8">
        {/* Quick Availability Management */}
        <Card className="bg-gradient-to-r from-[#6b3e4b] to-[#8b5a6b] text-white">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-white">
              <Clock className="h-5 w-5" />
              Manage Your Availability
            </CardTitle>
            <CardDescription className="text-white/80">
              Keep your schedule updated to receive more booking requests
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <Button asChild variant="secondary" className="bg-white text-[#6b3e4b] hover:bg-gray-100 h-auto py-3 px-4 border border-white/20">
                <Link to="/availability" className="flex flex-col items-center text-center">
                  <Calendar className="h-5 w-5 mb-1" />
                  <span className="font-semibold text-sm">Update Weekly Schedule</span>
                  <span className="text-xs opacity-75">Set your regular hours</span>
                </Link>
              </Button>
              <Button asChild variant="outline" className="bg-white/90 text-[#6b3e4b] border-white hover:bg-white h-auto py-3 px-4">
                <Link to="/quick-availability" className="flex flex-col items-center text-center">
                  <Clock className="h-5 w-5 mb-1" />
                  <span className="font-semibold text-sm">Quick Availability</span>
                  <span className="text-xs opacity-75">Toggle on/off instantly</span>
                </Link>
              </Button>
              <Button asChild variant="outline" className="bg-white/90 text-[#6b3e4b] border-white hover:bg-white h-auto py-3 px-4">
                <Link to="/sitter/edit-profile" className="flex flex-col items-center text-center">
                  <User className="h-5 w-5 mb-1" />
                  <span className="font-semibold text-sm">Edit Profile</span>
                  <span className="text-xs opacity-75">Update rates & bio</span>
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Founder Welcome Note */}
        <Card className="mb-6 bg-gradient-to-r from-rose/5 to-wine/10 rounded-xl shadow-lg border border-wine/20 overflow-hidden">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="p-3 rounded-full bg-wine/10">
                <span className="text-2xl">🎉</span>
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold text-wine mb-2">
                  You're Live — Welcome to The Village Co.
                </h3>
                <p className="text-gray-700 mb-3 leading-relaxed">
                  You're one of our founding sitters. Families can now view your profile and book you directly.
                </p>
                <p className="text-gray-700 mb-3 leading-relaxed">
                  Keep your availability up to date and check your inbox regularly - first impressions count 😉
                </p>
                <p className="text-gray-700 mb-4 leading-relaxed">
                  Questions? Feedback? We're here.
                </p>
                <div className="flex flex-col sm:flex-row gap-2 items-start">
                  <p className="text-wine font-semibold">
                    — Nikki + Sophia
                  </p>
                  <Button 
                    asChild 
                    variant="outline" 
                    size="sm" 
                    className="text-xs border-wine/30 text-wine hover:bg-wine/10"
                  >
                    <a href="mailto:info@thevillageco.nz">Contact Us at info@thevillageco.nz</a>
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="flex flex-col space-y-4 md:flex-row md:space-y-0 md:space-x-4">
          <Card className="flex-1">
            <CardHeader className="pb-2">
              <CardTitle className="text-xl">Welcome back, {user?.firstName || 'Sitter'}</CardTitle>
              <CardDescription>Here's what's coming up for you.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex flex-col items-center justify-center p-4 bg-rose/10 rounded-md">
                  <Calendar className="h-8 w-8 text-rose mb-2" />
                  <span className="text-2xl font-bold">{safeUpcomingBookings.length}</span>
                  <span className="text-sm text-muted-foreground">Upcoming Sits</span>
                </div>
                <div className="flex flex-col items-center justify-center p-4 bg-wine/10 rounded-md">
                  <Users className="h-8 w-8 text-wine mb-2" />
                  <span className="text-2xl font-bold">{completedBookings}</span>
                  <span className="text-sm text-muted-foreground">Completed Sits</span>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <div className="flex-1">
            <SitterEarnings 
              totalBookings={completedBookings} 
              totalEarned={totalEarned}
              monthlyEarnings={earningsData?.monthlyEarnings || monthlyEarnings}
              targetEarnings={monthlyTarget}
              onTargetUpdate={handleTargetUpdate}
            />
          </div>
        </div>
        
        {/* Instant Message Notifications for Sitters */}
        <InstantNotifications />

        {/* Payment & Transaction History Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Stripe Connect Status */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                Payment Setup
              </CardTitle>
              <CardDescription>
                Your Stripe Connect account status
              </CardDescription>
            </CardHeader>
            <CardContent>
              {/* Check for Stripe Connect ID in verification notes OR user record */}
              {(sitterProfile?.verificationNotes?.includes('Stripe Connect ID:') || (user as any)?.stripe_connect_id) ? (
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="text-sm font-medium text-green-700">Payment Setup Complete</span>
                  </div>
                  <p className="text-sm text-gray-600">
                    Your Stripe Connect account is linked and ready to receive payments.
                  </p>
                  <div className="p-3 bg-green-50 rounded-md">
                    <p className="text-xs text-green-700">
                      ✅ You can now receive payments for completed bookings
                    </p>
                    {(user as any)?.stripe_connect_id && (
                      <p className="text-xs text-gray-500 mt-1">
                        Account ID: {(user as any).stripe_connect_id}
                      </p>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="flex-1">
                      <TrendingUp className="h-4 w-4 mr-2" />
                      View Payment History
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1">
                      <CreditCard className="h-4 w-4 mr-2" />
                      Manage Account
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                    <span className="text-sm font-medium text-orange-700">Payment Setup Required</span>
                  </div>
                  <p className="text-sm text-gray-600">
                    Connect your bank account to receive payments for completed bookings.
                  </p>
                  <div className="p-3 bg-orange-50 rounded-md mb-3">
                    <p className="text-xs text-orange-700">
                      💡 Contact support to link your existing Stripe account or set up a new one
                    </p>
                  </div>
                  <Button 
                    onClick={() => window.open('mailto:info@thevillageco.nz?subject=Stripe Connect Setup Request&body=Hi, I need help setting up my Stripe Connect account for payments. My sitter ID is ' + sitterProfile?.id + '.', '_blank')}
                    className="w-full"
                  >
                    <CreditCard className="h-4 w-4 mr-2" />
                    Contact Support for Setup
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Transaction History */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Recent Transactions
              </CardTitle>
              <CardDescription>
                Your earnings and payment history
              </CardDescription>
            </CardHeader>
            <CardContent>
              {transactions.length > 0 ? (
                <div className="space-y-3">
                  {transactions.slice(0, 3).map((transaction: any) => (
                    <div key={transaction.id} className="p-3 border rounded-lg bg-white">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                            <DollarSign className="w-4 h-4 text-green-600" />
                          </div>
                          <div>
                            <p className="font-medium text-sm">
                              {transaction.description || 'Babysitting session'}
                            </p>
                            <p className="text-xs text-gray-500">
                              {transaction.booking?.parent?.first_name || 'Parent'} • {new Date(transaction.created_at).toLocaleDateString()}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-bold text-green-600 text-sm">
                            ${transaction.amount.toFixed(2)}
                          </p>
                          <p className="text-xs text-gray-500 capitalize">{transaction.status}</p>
                        </div>
                      </div>
                      
                      {/* Show review if available */}
                      {transaction.review && (
                        <div className="mt-3 p-2 bg-yellow-50 rounded border-l-2 border-yellow-200">
                          <div className="flex items-center gap-1 mb-1">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star 
                                key={star} 
                                className={`h-3 w-3 ${star <= transaction.review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
                              />
                            ))}
                            <span className="text-xs text-gray-600 ml-1">{transaction.review.rating}/5</span>
                          </div>
                          <p className="text-xs text-gray-700 italic">"{transaction.review.comment}"</p>
                        </div>
                      )}
                    </div>
                  ))}
                  {transactions.length > 3 && (
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full mt-3"
                      onClick={() => navigate('/sitter/transactions')}
                    >
                      View All Transactions
                    </Button>
                  )}
                </div>
              ) : (
                <div className="text-center py-6 text-gray-500">
                  <div className="w-12 h-12 mx-auto mb-3 bg-gray-100 rounded-full flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-gray-400" />
                  </div>
                  <p className="text-sm font-medium mb-1">No transactions yet</p>
                  <p className="text-xs">Complete your first booking to see earnings here</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Reviews & Ratings Section */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Star className="h-5 w-5" />
                Reviews & Ratings
              </CardTitle>
              <CardDescription>
                Feedback from families you've helped
              </CardDescription>
            </CardHeader>
            <CardContent>
              {reviewsLoading ? (
                <div className="flex justify-center py-6">
                  <div className="animate-spin h-6 w-6 border-2 border-wine border-t-transparent rounded-full"></div>
                </div>
              ) : reviewsInfo.totalReviews > 0 ? (
                <div className="space-y-4">
                  {/* Rating Summary */}
                  <div className="flex items-center gap-4 p-4 bg-yellow-50 rounded-lg border">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-yellow-600">{reviewsInfo.averageRating.toFixed(1)}</div>
                      <div className="flex justify-center mb-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <Star 
                            key={star} 
                            className={`h-4 w-4 ${star <= reviewsInfo.averageRating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
                          />
                        ))}
                      </div>
                      <div className="text-xs text-gray-600">{reviewsInfo.totalReviews} review{reviewsInfo.totalReviews !== 1 ? 's' : ''}</div>
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-yellow-800">Outstanding Performance!</p>
                      <p className="text-xs text-yellow-700">Families love working with you</p>
                    </div>
                  </div>

                  {/* Recent Reviews */}
                  <div className="space-y-3">
                    <h4 className="font-medium text-sm text-gray-700">Recent Reviews</h4>
                    {reviewsInfo.reviews.slice(0, 3).map((review: any) => (
                      <div key={review.id} className="p-3 border rounded-lg bg-white">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <div className="flex items-center gap-1 mb-1">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <Star 
                                  key={star} 
                                  className={`h-3 w-3 ${star <= review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
                                />
                              ))}
                            </div>
                            <p className="text-xs font-medium text-gray-600">{review.parentName}</p>
                          </div>
                          <p className="text-xs text-gray-500">
                            {new Date(review.date).toLocaleDateString()}
                          </p>
                        </div>
                        <p className="text-sm text-gray-700 leading-relaxed">{review.comment}</p>
                        <p className="text-xs text-gray-500 mt-2">{review.bookingDuration} booking</p>
                      </div>
                    ))}
                    
                    {reviewsInfo.reviews.length > 3 && (
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="w-full"
                        onClick={() => navigate('/sitter/reviews')}
                      >
                        View All {reviewsInfo.totalReviews} Reviews
                      </Button>
                    )}
                  </div>
                </div>
              ) : (
                <div className="text-center py-6 text-gray-500">
                  <div className="w-12 h-12 mx-auto mb-3 bg-gray-100 rounded-full flex items-center justify-center">
                    <Star className="w-6 h-6 text-gray-400" />
                  </div>
                  <p className="text-sm font-medium mb-1">No reviews yet</p>
                  <p className="text-xs">Complete your first booking to receive parent feedback</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
        
        {/* Message Testing (for development) */}
        {(user?.role === 'admin' || user?.role === 'sitter') && (
          <MessageNotificationTester />
        )}
        
        {/* Identity Verification */}
        <div className="mb-4">
          <VeriffVerification />
        </div>
        
        {/* Qualifications Manager */}
        {sitterProfile?.id && (
          <QualificationsManager sitterId={sitterProfile.id} />
        )}
        
        <Tabs defaultValue="upcoming" value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-8">
            <TabsTrigger value="upcoming">Upcoming Sits</TabsTrigger>
            <TabsTrigger value="past">Past Sits</TabsTrigger>
          </TabsList>
          
          <TabsContent value="upcoming" className="space-y-4">
            {loadingUpcoming ? (
              <div className="flex justify-center p-8">
                <div className="animate-spin h-8 w-8 border-4 border-wine border-t-transparent rounded-full"></div>
              </div>
            ) : upcomingBookings.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <Calendar className="h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-muted-foreground text-center">
                    You don't have any upcoming sits scheduled.
                  </p>
                  <Button asChild className="mt-4 bg-wine hover:bg-wine/90">
                    <Link to="/availability">Update Availability</Link>
                  </Button>
                </CardContent>
              </Card>
            ) : (
              (upcomingBookings as Booking[]).map((booking) => (
                <Card key={booking.id} className="overflow-hidden">
                  <div className="flex flex-col md:flex-row">
                    <div className="p-4 flex items-center justify-center bg-linen md:w-1/4">
                      <div className="text-center">
                        <p className="text-sm uppercase tracking-wide text-muted-foreground">
                          {new Date(booking.start_time).toLocaleDateString('en-NZ', { weekday: 'short' })}
                        </p>
                        <p className="text-3xl font-bold">
                          {new Date(booking.start_time).getDate()}
                        </p>
                        <p className="text-sm font-medium">
                          {new Date(booking.start_time).toLocaleDateString('en-NZ', { month: 'short' })}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex flex-col justify-between p-4 md:flex-1">
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="text-lg font-semibold">{booking.parent.first_name}'s Family</h3>
                          <div className="flex items-center">
                            <Clock className="h-4 w-4 text-muted-foreground mr-1" />
                            <span className="text-sm text-muted-foreground">
                              {new Date(booking.start_time).toLocaleTimeString('en-NZ', {
                                hour: '2-digit',
                                minute: '2-digit',
                                hour12: true
                              })} - {new Date(booking.end_time).toLocaleTimeString('en-NZ', {
                                hour: '2-digit',
                                minute: '2-digit',
                                hour12: true
                              })}
                            </span>
                          </div>
                        </div>
                        
                        <div className="flex flex-wrap gap-2 mt-2">
                          {booking.children?.map((child: any) => (
                            <Badge key={child.id} variant="outline" className="bg-linen border-rose/20">
                              {child.name} ({child.age} {child.age === 1 ? 'year' : 'years'})
                            </Badge>
                          ))}
                        </div>
                        
                        <p className="mt-4 text-sm">
                          {booking.sit_notes || 'No special instructions provided.'}
                        </p>
                      </div>
                      
                      <div className="flex justify-end mt-4 gap-2">
                        <Button variant="outline" size="sm" className="flex items-center gap-1" asChild>
                          <Link to={`/messages/${booking.parent.id}`}>
                            <MessageSquare className="h-4 w-4" />
                            <span>Message</span>
                          </Link>
                        </Button>
                        <Button size="sm" className="bg-wine hover:bg-wine/90" asChild>
                          <Link to={`/bookings/${booking.id}`}>View Details</Link>
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              ))
            )}
          </TabsContent>
          
          <TabsContent value="past" className="space-y-4">
            {loadingPast ? (
              <div className="flex justify-center p-8">
                <div className="animate-spin h-8 w-8 border-4 border-wine border-t-transparent rounded-full"></div>
              </div>
            ) : pastBookings.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <Clock className="h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-muted-foreground text-center">
                    You haven't completed any sits yet.
                  </p>
                </CardContent>
              </Card>
            ) : (
              (pastBookings as Booking[]).map((booking) => (
                <Card key={booking.id} className="overflow-hidden">
                  <div className="flex flex-col md:flex-row">
                    <div className="p-4 flex items-center justify-center bg-linen md:w-1/4">
                      <div className="text-center">
                        <p className="text-sm uppercase tracking-wide text-muted-foreground">
                          {new Date(booking.start_time).toLocaleDateString('en-NZ', { weekday: 'short' })}
                        </p>
                        <p className="text-3xl font-bold">
                          {new Date(booking.start_time).getDate()}
                        </p>
                        <p className="text-sm font-medium">
                          {new Date(booking.start_time).toLocaleDateString('en-NZ', { month: 'short' })}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex flex-col justify-between p-4 md:flex-1">
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="text-lg font-semibold">{booking.parent.first_name}'s Family</h3>
                          <div className="flex items-center">
                            <Clock className="h-4 w-4 text-muted-foreground mr-1" />
                            <span className="text-sm text-muted-foreground">
                              {new Date(booking.start_time).toLocaleTimeString('en-NZ', {
                                hour: '2-digit',
                                minute: '2-digit',
                                hour12: true
                              })} - {new Date(booking.end_time).toLocaleTimeString('en-NZ', {
                                hour: '2-digit',
                                minute: '2-digit',
                                hour12: true
                              })}
                            </span>
                          </div>
                        </div>
                        
                        {booking.parent_review && (
                          <div className="flex items-center mt-2">
                            <Star className="h-4 w-4 text-amber-500 mr-1" />
                            <span className="text-sm font-medium">Rating: {booking.parent_review.rating}/5</span>
                          </div>
                        )}
                        
                        <p className="mt-2 text-sm text-muted-foreground">
                          Earned: ${booking.amount_paid?.toFixed(2) || '0.00'}
                        </p>
                      </div>
                    </div>
                  </div>
                </Card>
              ))
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}