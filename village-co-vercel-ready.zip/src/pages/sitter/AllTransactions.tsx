import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowLeft, DollarSign, Star } from 'lucide-react';

export default function AllTransactions() {
  const { data: transactions = [], isLoading } = useQuery({
    queryKey: ['/api/sitter/all-transactions'],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#F9F5F0] py-8">
        <div className="max-w-4xl mx-auto px-4">
          <div className="flex justify-center py-12">
            <div className="animate-spin h-8 w-8 border-4 border-wine border-t-transparent rounded-full"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F9F5F0] py-8">
      <div className="max-w-4xl mx-auto px-4">
        {/* Header */}
        <div className="mb-8">
          <Link to="/sitter/dashboard">
            <Button variant="outline" size="sm" className="mb-4">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">All Transactions</h1>
          <p className="text-gray-600">Complete history of your earnings and payments</p>
        </div>

        {/* Transaction Summary */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Transaction Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-green-50 rounded-lg">
                <div className="text-2xl font-bold text-green-600">
                  ${transactions.reduce((sum: number, t: any) => sum + t.amount, 0).toFixed(2)}
                </div>
                <div className="text-sm text-green-700">Total Earned</div>
              </div>
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <div className="text-2xl font-bold text-blue-600">{transactions.length}</div>
                <div className="text-sm text-blue-700">Total Bookings</div>
              </div>
              <div className="text-center p-4 bg-yellow-50 rounded-lg">
                <div className="text-2xl font-bold text-yellow-600">
                  {transactions.length > 0 ? (transactions.reduce((sum: number, t: any) => sum + (t.review?.rating || 0), 0) / transactions.length).toFixed(1) : '0.0'}
                </div>
                <div className="text-sm text-yellow-700">Average Rating</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* All Transactions */}
        <Card>
          <CardHeader>
            <CardTitle>Transaction History</CardTitle>
            <CardDescription>All completed bookings and payments</CardDescription>
          </CardHeader>
          <CardContent>
            {transactions.length > 0 ? (
              <div className="space-y-4">
                {transactions.map((transaction: any) => (
                  <div key={transaction.id} className="p-4 border rounded-lg bg-white">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                          <DollarSign className="w-5 h-5 text-green-600" />
                        </div>
                        <div>
                          <p className="font-medium">
                            {transaction.description || 'Babysitting session'}
                          </p>
                          <p className="text-sm text-gray-500">
                            {transaction.booking?.parent?.first_name || 'Parent'} • {new Date(transaction.created_at).toLocaleDateString()}
                          </p>
                          <p className="text-xs text-gray-400">
                            {new Date(transaction.booking?.start_time).toLocaleDateString()} • {transaction.booking?.start_time && transaction.booking?.end_time ? 
                              `${new Date(transaction.booking.start_time).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})} - ${new Date(transaction.booking.end_time).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}` : 
                              'Time not specified'}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-green-600 text-lg">
                          ${transaction.amount.toFixed(2)}
                        </p>
                        <p className="text-sm text-gray-500 capitalize">{transaction.status}</p>
                      </div>
                    </div>
                    
                    {/* Show review if available */}
                    {transaction.review && (
                      <div className="mt-3 p-3 bg-yellow-50 rounded border-l-4 border-yellow-200">
                        <div className="flex items-center gap-2 mb-2">
                          <div className="flex items-center gap-1">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star 
                                key={star} 
                                className={`h-4 w-4 ${star <= transaction.review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`}
                              />
                            ))}
                          </div>
                          <span className="text-sm font-medium text-yellow-800">{transaction.review.rating}/5</span>
                        </div>
                        <p className="text-sm text-gray-700 italic">"{transaction.review.comment}"</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 text-gray-500">
                <DollarSign className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                <p className="text-lg font-medium mb-2">No transactions yet</p>
                <p>Complete your first booking to see earnings here</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}