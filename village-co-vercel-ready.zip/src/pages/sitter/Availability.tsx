import React from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/contexts/AuthContext';
import { useQuery } from '@tanstack/react-query';
import { Helmet } from 'react-helmet';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Info, Calendar } from 'lucide-react';
import AvailabilityCalendar from '@/components/booking/AvailabilityCalendar';

const Availability: React.FC = () => {
  const { user } = useAuth();
  const [, navigate] = useLocation();

  // Fetch sitter profile
  const { data: sitterProfile, isLoading } = useQuery({
    queryKey: [`/api/sitters/${user?.id}/profile`],
    enabled: !!user?.id,
  });

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!sitterProfile) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card>
          <CardHeader>
            <CardTitle>Complete Your Profile</CardTitle>
            <CardDescription>
              Please complete your sitter profile to manage your availability.
            </CardDescription>
          </CardHeader>
          <CardContent>
          </CardContent>
          <CardFooter>
            <Button onClick={() => navigate(`/profile/${user?.id}`)}>
              Complete Profile
            </Button>
          </CardFooter>
        </Card>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Manage Availability | The Village Co.</title>
        <meta name="description" content="Set your weekly availability to receive booking requests from parents." />
      </Helmet>
      
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h1 className="text-3xl font-bold">Manage Availability</h1>
              <p className="text-gray-500 mt-1">Set your weekly schedule to let parents know when you're available</p>
            </div>
            <Button 
              onClick={() => navigate('/sitter-dashboard')} 
              variant="outline" 
              className="mt-4 sm:mt-0"
            >
              Back to Dashboard
            </Button>
          </div>
        </div>

        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className="bg-blue-50 p-2 rounded-full">
                <Info className="h-6 w-6 text-blue-500" />
              </div>
              <div>
                <h3 className="font-medium text-base mb-1">Availability Tips</h3>
                <p className="text-muted-foreground text-sm">
                  Setting your availability accurately helps parents find times that work for you. You'll only receive booking requests during your available hours.
                </p>
                <div className="bg-muted mt-3 p-3 rounded-md text-sm space-y-2">
                  <p className="font-medium">Pro tips:</p>
                  <ul className="list-disc list-inside space-y-1 text-muted-foreground">
                    <li>Be specific about your available hours to avoid conflicts</li>
                    <li>Update your availability regularly to keep your calendar current</li>
                    <li>Mark yourself as unavailable on days you can't work</li>
                  </ul>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <AvailabilityCalendar sitterProfile={sitterProfile} />
      </div>
    </>
  );
};

export default Availability;
