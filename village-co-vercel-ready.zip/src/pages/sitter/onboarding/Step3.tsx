import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

export default function SitterOnboardingStep3() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    qualifications: [] as string[],
    backgroundCheckConsent: false,
    referees: [
      { name: '', email: '' },
      { name: '', email: '' }
    ],
    codeOfCareAgreement: false,
  });

  // Get current sitter profile data
  const { data: sitterData } = useQuery({
    queryKey: ["/api/sitter/onboarding-status"],
    retry: false,
  });

  const completeMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      return apiRequest('POST', '/api/sitter/complete-onboarding', data);
    },
    onSuccess: () => {
      toast({
        title: "Onboarding Complete!",
        description: "Welcome to The Village Co family!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/sitter/onboarding-status"] });
      setLocation('/sitter-onboarding-thank-you');
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to complete onboarding. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.backgroundCheckConsent || !formData.codeOfCareAgreement) {
      toast({
        title: "Required Consents",
        description: "Please agree to the background check and code of care to continue.",
        variant: "destructive",
      });
      return;
    }
    completeMutation.mutate(formData);
  };

  const updateField = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const updateReferee = (index: number, field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      referees: prev.referees.map((ref, i) => 
        i === index ? { ...ref, [field]: value } : ref
      )
    }));
  };

  const toggleQualification = (qualification: string) => {
    setFormData(prev => ({
      ...prev,
      qualifications: prev.qualifications.includes(qualification)
        ? prev.qualifications.filter(q => q !== qualification)
        : [...prev.qualifications, qualification]
    }));
  };

  const goBack = () => {
    setLocation('/sitter/onboarding/step-2');
  };

  const qualificationOptions = [
    'First Aid Certificate',
    'CPR Certificate', 
    'ECE (Early Childhood Education)',
    'Teaching Qualification',
    'Police Check/Background Check',
    'Working with Children Check',
    'Driver\'s License',
    'Other childcare qualification'
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-linen via-brushed-pink/20 to-white">
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-village-wine">Step 3 of 4</span>
            <span className="text-sm text-taupe">Nearly there...</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div className="bg-gradient-to-r from-village-wine to-rose h-2 rounded-full w-3/4"></div>
          </div>
        </div>

        <Card className="border-2 border-village-wine/20 shadow-lg">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl text-village-wine">Trust Goes Both Ways</CardTitle>
            <p className="text-taupe">Let's make sure everyone feels safe and confident</p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <Label>Do you have any of these qualifications? (Select all that apply)</Label>
                <div className="grid grid-cols-1 gap-3 mt-2">
                  {qualificationOptions.map((qualification) => (
                    <div key={qualification} className="flex items-center space-x-2">
                      <Checkbox
                        id={qualification}
                        checked={formData.qualifications.includes(qualification)}
                        onCheckedChange={() => toggleQualification(qualification)}
                      />
                      <Label htmlFor={qualification}>{qualification}</Label>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <Label>References (2 required)</Label>
                <p className="text-sm text-taupe mb-3">
                  These should be people who can speak to your character and experience with children
                </p>
                {formData.referees.map((referee, index) => (
                  <div key={index} className="grid md:grid-cols-2 gap-4 mb-4 p-4 border rounded-lg">
                    <div>
                      <Label htmlFor={`referee-name-${index}`}>Name</Label>
                      <Input
                        id={`referee-name-${index}`}
                        value={referee.name}
                        onChange={(e) => updateReferee(index, 'name', e.target.value)}
                        placeholder="Full name"
                      />
                    </div>
                    <div>
                      <Label htmlFor={`referee-email-${index}`}>Email</Label>
                      <Input
                        id={`referee-email-${index}`}
                        type="email"
                        value={referee.email}
                        onChange={(e) => updateReferee(index, 'email', e.target.value)}
                        placeholder="email@example.com"
                      />
                    </div>
                  </div>
                ))}
              </div>

              <div className="space-y-4">
                <div className="flex items-start space-x-2">
                  <Checkbox
                    id="backgroundCheck"
                    checked={formData.backgroundCheckConsent}
                    onCheckedChange={(checked) => updateField('backgroundCheckConsent', !!checked)}
                  />
                  <Label htmlFor="backgroundCheck" className="text-sm leading-relaxed">
                    I consent to a background check being conducted. I understand this is for the safety 
                    of families and children on the platform. *
                  </Label>
                </div>

                <div className="flex items-start space-x-2">
                  <Checkbox
                    id="codeOfCare"
                    checked={formData.codeOfCareAgreement}
                    onCheckedChange={(checked) => updateField('codeOfCareAgreement', !!checked)}
                  />
                  <Label htmlFor="codeOfCare" className="text-sm leading-relaxed">
                    I agree to follow The Village Co's Code of Care, which includes providing safe, 
                    respectful, and nurturing care to all children. *
                  </Label>
                </div>
              </div>

              <div className="flex gap-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={goBack}
                  className="flex-1"
                >
                  Back
                </Button>
                <Button 
                  type="submit" 
                  className="flex-1 bg-village-wine hover:bg-village-wine/90 text-white"
                  disabled={completeMutation.isPending}
                >
                  {completeMutation.isPending ? 'Completing...' : 'Complete Onboarding'}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}