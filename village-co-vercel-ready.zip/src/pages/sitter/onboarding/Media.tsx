import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Camera, Upload, User } from 'lucide-react';

export default function SitterOnboardingMedia() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    profilePhoto: null as File | null,
    videoIntro: null as File | null,
  });

  const [profilePhotoPreview, setProfilePhotoPreview] = useState<string | null>(null);

  // Get current sitter profile data
  const { data: sitterData } = useQuery({
    queryKey: ["/api/sitter/onboarding-status"],
    retry: false,
  });

  const saveMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const formDataToSend = new FormData();
      if (data.profilePhoto) {
        formDataToSend.append('profilePhoto', data.profilePhoto);
      }
      if (data.videoIntro) {
        formDataToSend.append('videoIntro', data.videoIntro);
      }
      
      return apiRequest('POST', '/api/sitter/onboarding/media', formDataToSend);
    },
    onSuccess: () => {
      toast({
        title: "Media Saved",
        description: "Your photos and videos have been saved.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/sitter/onboarding-status"] });
      setLocation('/sitter/onboarding/payout');
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to save your media. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    saveMutation.mutate(formData);
  };

  const handleProfilePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFormData(prev => ({ ...prev, profilePhoto: file }));
      const reader = new FileReader();
      reader.onload = (event) => {
        setProfilePhotoPreview(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleVideoIntroChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFormData(prev => ({ ...prev, videoIntro: file }));
    }
  };

  const goBack = () => {
    setLocation('/sitter/onboarding/availability');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-linen via-brushed-pink/20 to-white">
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-village-wine">Step 4 of 7: Photo + Video</span>
            <span className="text-sm text-taupe">Show your personality!</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div className="bg-gradient-to-r from-village-wine to-rose h-2 rounded-full" style={{ width: '57.1%' }}></div>
          </div>
        </div>

        <Card className="border-2 border-village-wine/20 shadow-lg">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl text-village-wine">Share Your Smile</CardTitle>
            <p className="text-taupe">Help parents get to know the real you</p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              
              {/* Profile Photo Section */}
              <div className="space-y-4">
                <div className="text-center">
                  <h3 className="text-lg font-semibold text-village-wine mb-2">Profile Photo</h3>
                  <p className="text-sm text-taupe mb-4">
                    A friendly, clear photo of just you helps build trust with families
                  </p>
                  
                  <div className="flex flex-col items-center space-y-4">
                    {profilePhotoPreview ? (
                      <div className="relative">
                        <img 
                          src={profilePhotoPreview} 
                          alt="Profile preview" 
                          className="w-32 h-32 rounded-full object-cover border-4 border-village-wine/20"
                        />
                        <button
                          type="button"
                          onClick={() => {
                            setProfilePhotoPreview(null);
                            setFormData(prev => ({ ...prev, profilePhoto: null }));
                          }}
                          className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs"
                        >
                          ×
                        </button>
                      </div>
                    ) : (
                      <div className="w-32 h-32 rounded-full bg-gray-100 border-2 border-dashed border-gray-300 flex items-center justify-center">
                        <User className="w-12 h-12 text-gray-400" />
                      </div>
                    )}

                    <Label htmlFor="profilePhoto" className="cursor-pointer">
                      <div className="bg-village-wine text-white px-4 py-2 rounded-md hover:bg-village-wine/90 flex items-center space-x-2">
                        <Camera className="w-4 h-4" />
                        <span>{profilePhotoPreview ? 'Change Photo' : 'Add Photo'}</span>
                      </div>
                      <input
                        id="profilePhoto"
                        type="file"
                        accept="image/*"
                        onChange={handleProfilePhotoChange}
                        className="hidden"
                      />
                    </Label>
                  </div>
                </div>
              </div>

              {/* Video Introduction Section */}
              <div className="space-y-4 border-t pt-6">
                <div className="text-center">
                  <h3 className="text-lg font-semibold text-village-wine mb-2">Video Introduction (Optional)</h3>
                  <p className="text-sm text-taupe mb-4">
                    A short 30-60 second video introducing yourself can really help you stand out
                  </p>
                  
                  <div className="flex flex-col items-center space-y-4">
                    {formData.videoIntro ? (
                      <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-center space-x-3">
                        <div className="bg-green-100 rounded-full p-2">
                          <Upload className="w-5 h-5 text-green-600" />
                        </div>
                        <div className="text-left">
                          <p className="font-medium text-green-800">{formData.videoIntro.name}</p>
                          <p className="text-sm text-green-600">
                            {(formData.videoIntro.size / (1024 * 1024)).toFixed(1)} MB
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={() => setFormData(prev => ({ ...prev, videoIntro: null }))}
                          className="text-red-500 hover:text-red-700"
                        >
                          ×
                        </button>
                      </div>
                    ) : (
                      <div className="w-full max-w-sm">
                        <Label htmlFor="videoIntro" className="cursor-pointer">
                          <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 hover:border-village-wine transition-colors">
                            <div className="text-center">
                              <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                              <p className="text-sm font-medium text-gray-600">Upload Video</p>
                              <p className="text-xs text-gray-500">MP4, MOV up to 50MB</p>
                            </div>
                          </div>
                          <input
                            id="videoIntro"
                            type="file"
                            accept="video/*"
                            onChange={handleVideoIntroChange}
                            className="hidden"
                          />
                        </Label>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="bg-linen/50 rounded-lg p-4">
                <h4 className="font-semibold text-village-wine mb-2">Tips for Great Photos & Videos:</h4>
                <ul className="text-sm text-taupe space-y-1">
                  <li>• Use natural lighting and smile genuinely</li>
                  <li>• Keep your video brief and friendly</li>
                  <li>• Share what you love about working with kids</li>
                  <li>• Be yourself - authenticity builds trust!</li>
                </ul>
              </div>

              <div className="flex gap-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={goBack}
                  className="flex-1"
                >
                  Back
                </Button>
                <Button 
                  type="submit" 
                  className="flex-1 bg-village-wine hover:bg-village-wine/90 text-white"
                  disabled={saveMutation.isPending}
                >
                  {saveMutation.isPending ? 'Saving...' : 'Continue to Payout'}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}