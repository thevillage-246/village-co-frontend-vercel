import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

export default function SitterOnboardingStep1() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    firstName: '',
    email: '',
    mobile: '',
    howHeardAbout: '',
    whyBabysit: '',
  });

  // Get current sitter profile data
  const { data: sitterData } = useQuery({
    queryKey: ["/api/sitter/onboarding-status"],
    retry: false,
  });

  // Pre-populate form with existing data
  useEffect(() => {
    if (sitterData?.user && sitterData?.sitterProfile) {
      setFormData(prev => ({
        ...prev,
        firstName: sitterData.user.firstName || '',
        email: sitterData.user.email || '',
        // Add other fields from sitter profile if they exist
      }));
    }
  }, [sitterData]);

  const saveMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      return apiRequest('POST', '/api/sitter/onboarding/step1', data);
    },
    onSuccess: () => {
      toast({
        title: "Step 1 Complete",
        description: "Your basic information has been saved.",
      });
      // Invalidate onboarding status to refresh guard
      queryClient.invalidateQueries({ queryKey: ["/api/sitter/onboarding-status"] });
      // Move to step 2
      setLocation('/sitter/onboarding/qualifications');
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to save your information. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.firstName || !formData.email || !formData.mobile) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }
    saveMutation.mutate(formData);
  };

  const updateField = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-linen via-brushed-pink/20 to-white">
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-village-wine">Step 1 of 7: Bio + Rate</span>
            <span className="text-sm text-taupe">You've got this!</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div className="bg-gradient-to-r from-village-wine to-rose h-2 rounded-full w-1/7"></div>
          </div>
        </div>

        <Card className="border-2 border-village-wine/20 shadow-lg">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl text-village-wine">So, you love kids?</CardTitle>
            <p className="text-taupe">Let's get to know you a little better. This part takes 2 mins tops!</p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="firstName">First Name *</Label>
                  <Input
                    id="firstName"
                    value={formData.firstName}
                    onChange={(e) => updateField('firstName', e.target.value)}
                    placeholder="Your first name"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => updateField('email', e.target.value)}
                    placeholder="your.email@example.com"
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="mobile">Mobile Number *</Label>
                <Input
                  id="mobile"
                  type="tel"
                  value={formData.mobile}
                  onChange={(e) => updateField('mobile', e.target.value)}
                  placeholder="021 123 4567"
                  required
                />
              </div>

              <div>
                <Label htmlFor="howHeardAbout">How did you hear about The Village Co?</Label>
                <Select value={formData.howHeardAbout} onValueChange={(value) => updateField('howHeardAbout', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose an option" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="friend">Friend or family recommendation</SelectItem>
                    <SelectItem value="social-media">Social media</SelectItem>
                    <SelectItem value="google">Google search</SelectItem>
                    <SelectItem value="university">University/college</SelectItem>
                    <SelectItem value="job-board">Job board</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="whyBabysit">Why do you want to babysit?</Label>
                <Textarea
                  id="whyBabysit"
                  value={formData.whyBabysit}
                  onChange={(e) => updateField('whyBabysit', e.target.value)}
                  placeholder="Share what draws you to childcare... (optional)"
                  rows={4}
                />
              </div>

              <Button 
                type="submit" 
                className="w-full bg-village-wine hover:bg-village-wine/90 text-white"
                disabled={saveMutation.isPending}
              >
                {saveMutation.isPending ? 'Saving...' : 'Continue to Qualifications'}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}