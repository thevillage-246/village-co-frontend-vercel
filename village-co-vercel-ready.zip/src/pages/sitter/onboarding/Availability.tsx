import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

export default function SitterOnboardingAvailability() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    availability: {
      monday: false,
      tuesday: false,
      wednesday: false,
      thursday: false,
      friday: false,
      saturday: false,
      sunday: false,
    },
    preferredTimes: [] as string[],
    okWithPets: false,
    languagesSpoken: '',
  });

  // Get current sitter profile data
  const { data: sitterData } = useQuery({
    queryKey: ["/api/sitter/onboarding-status"],
    retry: false,
  });

  // Pre-populate form with existing data
  useEffect(() => {
    if (sitterData?.sitterProfile) {
      const profile = sitterData.sitterProfile;
      setFormData(prev => ({
        ...prev,
        availability: profile.availability ? 
          (typeof profile.availability === 'string' ? JSON.parse(profile.availability) : profile.availability) 
          : prev.availability,
        preferredTimes: profile.preferredTimes ? 
          (typeof profile.preferredTimes === 'string' ? JSON.parse(profile.preferredTimes) : profile.preferredTimes) 
          : [],
        okWithPets: profile.okWithPets || false,
        languagesSpoken: profile.languagesSpoken || '',
      }));
    }
  }, [sitterData]);

  const saveMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      return apiRequest('POST', '/api/sitter/onboarding/availability', data);
    },
    onSuccess: () => {
      toast({
        title: "Availability Saved",
        description: "Your availability and preferences have been saved.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/sitter/onboarding-status"] });
      setLocation('/sitter/onboarding/media');
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to save your availability. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    saveMutation.mutate(formData);
  };

  const updateAvailability = (day: string, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      availability: { ...prev.availability, [day]: checked }
    }));
  };

  const togglePreferredTime = (time: string) => {
    setFormData(prev => ({
      ...prev,
      preferredTimes: prev.preferredTimes.includes(time)
        ? prev.preferredTimes.filter(t => t !== time)
        : [...prev.preferredTimes, time]
    }));
  };

  const goBack = () => {
    setLocation('/sitter/onboarding/qualifications');
  };

  const timeOptions = [
    'Early Morning (6am-9am)',
    'Morning (9am-12pm)',
    'Afternoon (12pm-5pm)',
    'Evening (5pm-8pm)',
    'Night (8pm-11pm)',
    'Late Night (11pm+)',
    'Overnight'
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-linen via-brushed-pink/20 to-white">
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-village-wine">Step 3 of 7: Availability</span>
            <span className="text-sm text-taupe">When can you help?</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div className="bg-gradient-to-r from-village-wine to-rose h-2 rounded-full" style={{ width: '42.9%' }}></div>
          </div>
        </div>

        <Card className="border-2 border-village-wine/20 shadow-lg">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl text-village-wine">Your Availability</CardTitle>
            <p className="text-taupe">Let parents know when you're available to babysit</p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              
              <div>
                <Label>Which days are you available? (Select all that apply)</Label>
                <div className="grid grid-cols-2 gap-3 mt-2">
                  {Object.entries(formData.availability).map(([day, checked]) => (
                    <div key={day} className="flex items-center space-x-2">
                      <Checkbox
                        id={day}
                        checked={checked}
                        onCheckedChange={(checked) => updateAvailability(day, !!checked)}
                      />
                      <Label htmlFor={day} className="capitalize">{day}</Label>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <Label>Preferred Times (Select all that apply)</Label>
                <div className="grid grid-cols-1 gap-3 mt-2">
                  {timeOptions.map((time) => (
                    <div key={time} className="flex items-center space-x-2">
                      <Checkbox
                        id={time}
                        checked={formData.preferredTimes.includes(time)}
                        onCheckedChange={() => togglePreferredTime(time)}
                      />
                      <Label htmlFor={time}>{time}</Label>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-4 border-t pt-6">
                <h3 className="text-lg font-semibold text-village-wine">Preferences</h3>
                
                <div className="flex items-start space-x-2">
                  <Checkbox
                    id="okWithPets"
                    checked={formData.okWithPets}
                    onCheckedChange={(checked) => setFormData(prev => ({ ...prev, okWithPets: !!checked }))}
                  />
                  <Label htmlFor="okWithPets" className="text-sm leading-relaxed">
                    I'm comfortable babysitting in homes with pets
                  </Label>
                </div>

                <div>
                  <Label htmlFor="languagesSpoken">Languages Spoken</Label>
                  <input
                    id="languagesSpoken"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-village-wine"
                    value={formData.languagesSpoken}
                    onChange={(e) => setFormData(prev => ({ ...prev, languagesSpoken: e.target.value }))}
                    placeholder="e.g., English, Mandarin, Te Reo Māori"
                    maxLength={200}
                  />
                  <p className="text-sm text-taupe mt-1">
                    Share any languages you speak that might be helpful for families
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={goBack}
                  className="flex-1"
                >
                  Back
                </Button>
                <Button 
                  type="submit" 
                  className="flex-1 bg-village-wine hover:bg-village-wine/90 text-white"
                  disabled={saveMutation.isPending}
                >
                  {saveMutation.isPending ? 'Saving...' : 'Continue to Media'}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}