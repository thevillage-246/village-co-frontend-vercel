import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

export default function SitterOnboardingStep2() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    bio: '',
    experienceLevel: '',
    hourlyRate: '',
    availability: {
      monday: false,
      tuesday: false,
      wednesday: false,
      thursday: false,
      friday: false,
      saturday: false,
      sunday: false,
    },
    preferredTimes: [] as string[],
    suburbs: [] as string[],
  });

  // Get current sitter profile data
  const { data: sitterData } = useQuery({
    queryKey: ["/api/sitter/onboarding-status"],
    retry: false,
  });

  // Pre-populate form with existing data
  useEffect(() => {
    if (sitterData?.sitterProfile) {
      const profile = sitterData.sitterProfile;
      setFormData(prev => ({
        ...prev,
        bio: profile.bio || '',
        experienceLevel: profile.experienceLevel || '',
        hourlyRate: profile.hourlyRate?.toString() || '',
        // Parse JSON fields if they exist
        availability: profile.availability ? 
          (typeof profile.availability === 'string' ? JSON.parse(profile.availability) : profile.availability) 
          : prev.availability,
        preferredTimes: profile.preferredTimes ? 
          (typeof profile.preferredTimes === 'string' ? JSON.parse(profile.preferredTimes) : profile.preferredTimes) 
          : [],
        suburbs: profile.suburbs ? 
          (typeof profile.suburbs === 'string' ? JSON.parse(profile.suburbs) : profile.suburbs) 
          : [],
      }));
    }
  }, [sitterData]);

  const saveMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      return apiRequest('POST', '/api/sitter/onboarding/step2', data);
    },
    onSuccess: () => {
      toast({
        title: "Step 2 Complete",
        description: "Your profile information has been saved.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/sitter/onboarding-status"] });
      setLocation('/sitter/onboarding/step-3');
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to save your profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.bio || !formData.experienceLevel) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }
    saveMutation.mutate(formData);
  };

  const updateField = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const updateAvailability = (day: string, checked: boolean) => {
    setFormData(prev => ({
      ...prev,
      availability: { ...prev.availability, [day]: checked }
    }));
  };

  const goBack = () => {
    setLocation('/sitter/onboarding/step-1');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-linen via-brushed-pink/20 to-white">
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-village-wine">Step 2 of 4</span>
            <span className="text-sm text-taupe">Looking good...</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div className="bg-gradient-to-r from-village-wine to-rose h-2 rounded-full w-2/4"></div>
          </div>
        </div>

        <Card className="border-2 border-village-wine/20 shadow-lg">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl text-village-wine">Build Your Profile</CardTitle>
            <p className="text-taupe">Help parents get to know the amazing sitter you are!</p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <Label htmlFor="bio">Tell us about yourself *</Label>
                <Textarea
                  id="bio"
                  value={formData.bio}
                  onChange={(e) => updateField('bio', e.target.value)}
                  placeholder="Share your personality, what you love about kids, your hobbies..."
                  rows={4}
                  required
                />
              </div>

              <div>
                <Label htmlFor="experienceLevel">Experience Level *</Label>
                <Select value={formData.experienceLevel} onValueChange={(value) => updateField('experienceLevel', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose your experience level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="beginner">New to babysitting (but eager to learn!)</SelectItem>
                    <SelectItem value="some-experience">Some experience with kids</SelectItem>
                    <SelectItem value="experienced">Experienced babysitter</SelectItem>
                    <SelectItem value="professional">Professional childcare background</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="hourlyRate">Hourly Rate (NZD)</Label>
                <Input
                  id="hourlyRate"
                  type="number"
                  min="15"
                  max="50"
                  value={formData.hourlyRate}
                  onChange={(e) => updateField('hourlyRate', e.target.value)}
                  placeholder="25"
                />
                <p className="text-sm text-taupe mt-1">Minimum wage in NZ is $22.70/hour</p>
              </div>

              <div>
                <Label>When are you available? (Select all that apply)</Label>
                <div className="grid grid-cols-2 gap-3 mt-2">
                  {Object.entries(formData.availability).map(([day, checked]) => (
                    <div key={day} className="flex items-center space-x-2">
                      <Checkbox
                        id={day}
                        checked={checked}
                        onCheckedChange={(checked) => updateAvailability(day, !!checked)}
                      />
                      <Label htmlFor={day} className="capitalize">{day}</Label>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex gap-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={goBack}
                  className="flex-1"
                >
                  Back
                </Button>
                <Button 
                  type="submit" 
                  className="flex-1 bg-village-wine hover:bg-village-wine/90 text-white"
                  disabled={saveMutation.isPending}
                >
                  {saveMutation.isPending ? 'Saving...' : 'Continue to Step 3'}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}