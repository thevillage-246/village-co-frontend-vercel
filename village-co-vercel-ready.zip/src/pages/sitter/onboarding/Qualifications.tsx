import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

export default function SitterOnboardingQualifications() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    qualifications: [] as string[],
  });

  // Get current sitter profile data
  const { data: sitterData } = useQuery({
    queryKey: ["/api/sitter/onboarding-status"],
    retry: false,
  });

  // Pre-populate form with existing data
  useEffect(() => {
    if (sitterData?.sitterProfile?.qualifications) {
      setFormData(prev => ({
        ...prev,
        qualifications: Array.isArray(sitterData.sitterProfile.qualifications) 
          ? sitterData.sitterProfile.qualifications 
          : [],
      }));
    }
  }, [sitterData]);

  const saveMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      return apiRequest('POST', '/api/sitter/onboarding/qualifications', data);
    },
    onSuccess: () => {
      toast({
        title: "Qualifications Saved",
        description: "Your qualifications have been saved.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/sitter/onboarding-status"] });
      setLocation('/sitter/onboarding/availability');
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to save your qualifications. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    saveMutation.mutate(formData);
  };

  const toggleQualification = (qualification: string) => {
    setFormData(prev => ({
      ...prev,
      qualifications: prev.qualifications.includes(qualification)
        ? prev.qualifications.filter(q => q !== qualification)
        : [...prev.qualifications, qualification]
    }));
  };

  const goBack = () => {
    setLocation('/sitter/onboarding/profile');
  };

  const qualificationOptions = [
    { id: 'first-aid', label: 'First Aid Certificate', category: 'Health & Safety' },
    { id: 'cpr', label: 'CPR Certificate', category: 'Health & Safety' },
    { id: 'infant-cpr', label: 'Infant/Child CPR', category: 'Health & Safety' },
    { id: 'police-check', label: 'Police/Background Check', category: 'Health & Safety' },
    { id: 'ece', label: 'ECE (Early Childhood Education)', category: 'Education & Professional' },
    { id: 'teaching', label: 'Teaching Qualification', category: 'Education & Professional' },
    { id: 'childcare-degree', label: 'Childcare/Education Degree', category: 'Education & Professional' },
    { id: 'working-with-children', label: 'Working with Children Check', category: 'Education & Professional' },
    { id: 'autism-adhd', label: 'Autism/ADHD Training', category: 'Specialized Training' },
    { id: 'medical-needs', label: 'Medical Needs Experience', category: 'Specialized Training' },
    { id: 'child-development', label: 'Child Development', category: 'Specialized Training' },
    { id: 'drivers-license', label: 'Driver\'s License', category: 'Practical Skills' },
    { id: 'cooking', label: 'Cooking/Meal Prep', category: 'Practical Skills' },
    { id: 'homework-help', label: 'Homework Help', category: 'Practical Skills' },
    { id: 'swimming', label: 'Swimming Supervision', category: 'Practical Skills' },
  ];

  const categories = [...new Set(qualificationOptions.map(q => q.category))];

  return (
    <div className="min-h-screen bg-gradient-to-br from-linen via-brushed-pink/20 to-white">
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-village-wine">Step 2 of 7: Qualifications</span>
            <span className="text-sm text-taupe">Show your skills!</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div className="bg-gradient-to-r from-village-wine to-rose h-2 rounded-full" style={{ width: '28.6%' }}></div>
          </div>
        </div>

        <Card className="border-2 border-village-wine/20 shadow-lg">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl text-village-wine">Your Qualifications</CardTitle>
            <p className="text-taupe">Select any qualifications or certifications you have</p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {categories.map((category) => (
                <div key={category} className="space-y-3">
                  <h3 className="text-lg font-semibold text-village-wine border-b border-village-wine/20 pb-2">
                    {category}
                  </h3>
                  <div className="grid grid-cols-1 gap-3">
                    {qualificationOptions
                      .filter(q => q.category === category)
                      .map((qualification) => (
                        <div key={qualification.id} className="flex items-center space-x-2">
                          <Checkbox
                            id={qualification.id}
                            checked={formData.qualifications.includes(qualification.id)}
                            onCheckedChange={() => toggleQualification(qualification.id)}
                          />
                          <Label htmlFor={qualification.id} className="text-sm leading-relaxed">
                            {qualification.label}
                          </Label>
                        </div>
                      ))}
                  </div>
                </div>
              ))}

              {formData.qualifications.length === 0 && (
                <div className="bg-linen/50 rounded-lg p-4">
                  <p className="text-sm text-taupe">
                    No qualifications yet? That's okay! Many great sitters start with enthusiasm and learn as they go. 
                    You can always add qualifications later as you gain them.
                  </p>
                </div>
              )}

              <div className="flex gap-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={goBack}
                  className="flex-1"
                >
                  Back
                </Button>
                <Button 
                  type="submit" 
                  className="flex-1 bg-village-wine hover:bg-village-wine/90 text-white"
                  disabled={saveMutation.isPending}
                >
                  {saveMutation.isPending ? 'Saving...' : 'Continue to Availability'}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}