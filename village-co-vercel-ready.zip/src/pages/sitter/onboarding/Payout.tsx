import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { CreditCard, Shield, DollarSign } from 'lucide-react';

export default function SitterOnboardingPayout() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    bankAccountNumber: '',
    accountHolderName: '',
    bankName: '',
    taxNumber: '',
    preferredPaymentMethod: 'bank_transfer',
  });

  // Get current sitter profile data
  const { data: sitterData } = useQuery({
    queryKey: ["/api/sitter/onboarding-status"],
    retry: false,
  });

  const saveMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      return apiRequest('POST', '/api/sitter/onboarding/payout', data);
    },
    onSuccess: () => {
      toast({
        title: "Payout Details Saved",
        description: "Your payment information has been securely saved.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/sitter/onboarding-status"] });
      setLocation('/sitter/onboarding/verify');
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to save your payout details. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.bankAccountNumber || !formData.accountHolderName) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }
    saveMutation.mutate(formData);
  };

  const updateField = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const goBack = () => {
    setLocation('/sitter/onboarding/media');
  };

  const bankOptions = [
    'ANZ',
    'ASB',
    'BNZ',
    'Westpac',
    'Kiwibank',
    'TSB',
    'Co-operative Bank',
    'SBS Bank',
    'Heartland Bank',
    'Other'
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-linen via-brushed-pink/20 to-white">
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-village-wine">Step 5 of 7: Payout Setup</span>
            <span className="text-sm text-taupe">Almost ready to earn!</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div className="bg-gradient-to-r from-village-wine to-rose h-2 rounded-full" style={{ width: '71.4%' }}></div>
          </div>
        </div>

        <Card className="border-2 border-village-wine/20 shadow-lg">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl text-village-wine">Payment Setup</CardTitle>
            <p className="text-taupe">How would you like to receive payments?</p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              
              {/* Security Notice */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start space-x-3">
                <Shield className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold text-blue-800 mb-1">Your Information is Secure</h4>
                  <p className="text-sm text-blue-700">
                    We use bank-level encryption to protect your payment details. This information is only used to pay you for your babysitting services.
                  </p>
                </div>
              </div>

              {/* Payment Method Selection */}
              <div>
                <Label htmlFor="preferredPaymentMethod">Preferred Payment Method</Label>
                <Select value={formData.preferredPaymentMethod} onValueChange={(value) => updateField('preferredPaymentMethod', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose payment method" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="bank_transfer">Direct Bank Transfer (Recommended)</SelectItem>
                    <SelectItem value="stripe_connect">Stripe Connect (Coming Soon)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Bank Details Section */}
              {formData.preferredPaymentMethod === 'bank_transfer' && (
                <div className="space-y-4 border-t pt-6">
                  <div className="flex items-center space-x-2 mb-4">
                    <CreditCard className="w-5 h-5 text-village-wine" />
                    <h3 className="text-lg font-semibold text-village-wine">Bank Account Details</h3>
                  </div>

                  <div>
                    <Label htmlFor="accountHolderName">Account Holder Name *</Label>
                    <Input
                      id="accountHolderName"
                      value={formData.accountHolderName}
                      onChange={(e) => updateField('accountHolderName', e.target.value)}
                      placeholder="Full name as it appears on your bank account"
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="bankName">Bank *</Label>
                    <Select value={formData.bankName} onValueChange={(value) => updateField('bankName', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select your bank" />
                      </SelectTrigger>
                      <SelectContent>
                        {bankOptions.map((bank) => (
                          <SelectItem key={bank} value={bank}>{bank}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="bankAccountNumber">Bank Account Number *</Label>
                    <Input
                      id="bankAccountNumber"
                      value={formData.bankAccountNumber}
                      onChange={(e) => updateField('bankAccountNumber', e.target.value)}
                      placeholder="12-3456-7890123-00"
                      required
                    />
                    <p className="text-sm text-taupe mt-1">
                      Include all digits and hyphens (e.g., 12-3456-7890123-00)
                    </p>
                  </div>

                  <div>
                    <Label htmlFor="taxNumber">IRD Number (Optional)</Label>
                    <Input
                      id="taxNumber"
                      value={formData.taxNumber}
                      onChange={(e) => updateField('taxNumber', e.target.value)}
                      placeholder="123-456-789"
                    />
                    <p className="text-sm text-taupe mt-1">
                      Required for payments over $200. You can add this later if needed.
                    </p>
                  </div>
                </div>
              )}

              {/* Stripe Connect Option */}
              {formData.preferredPaymentMethod === 'stripe_connect' && (
                <div className="border border-gray-200 rounded-lg p-6 text-center">
                  <DollarSign className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-600 mb-2">Stripe Connect</h3>
                  <p className="text-gray-500 mb-4">
                    Fast, secure payments directly to your bank account or debit card. This feature is coming soon!
                  </p>
                  <Button 
                    type="button" 
                    variant="outline" 
                    disabled
                    className="opacity-50"
                  >
                    Set Up Stripe Connect (Coming Soon)
                  </Button>
                </div>
              )}

              <div className="bg-linen/50 rounded-lg p-4">
                <h4 className="font-semibold text-village-wine mb-2">How Payments Work:</h4>
                <ul className="text-sm text-taupe space-y-1">
                  <li>• Parents pay through the platform when booking</li>
                  <li>• Payments are released after each completed babysitting session</li>
                  <li>• Bank transfers typically take 1-2 business days</li>
                  <li>• You'll receive an email confirmation for each payment</li>
                </ul>
              </div>

              <div className="flex gap-4">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={goBack}
                  className="flex-1"
                >
                  Back
                </Button>
                <Button 
                  type="submit" 
                  className="flex-1 bg-village-wine hover:bg-village-wine/90 text-white"
                  disabled={saveMutation.isPending}
                >
                  {saveMutation.isPending ? 'Saving...' : 'Continue to Verification'}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}