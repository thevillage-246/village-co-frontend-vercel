import { useState, useEffect } from 'react';
import { useLocation, Link } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { ArrowLeft } from 'lucide-react';

export default function SitterOnboardingProfile() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    firstName: '',
    email: '',
    mobile: '',
    howHeardAbout: '',
    whyBabysit: '',
    bio: '',
    experienceLevel: '',
    hourlyRate: '',
  });

  // Get current sitter profile data
  const { data: sitterData } = useQuery({
    queryKey: ["/api/sitter/onboarding-status"],
    retry: false,
  });

  // Pre-populate form with existing data
  useEffect(() => {
    if (sitterData?.user && sitterData?.sitterProfile) {
      setFormData(prev => ({
        ...prev,
        firstName: sitterData.user.firstName || '',
        email: sitterData.user.email || '',
        bio: sitterData.sitterProfile.bio || '',
        experienceLevel: sitterData.sitterProfile.experienceLevel || '',
        hourlyRate: sitterData.sitterProfile.hourlyRate?.toString() || '',
      }));
    }
  }, [sitterData]);

  const saveMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      // Save both basic info and profile data
      await apiRequest('POST', '/api/sitter/onboarding/step1', {
        firstName: data.firstName,
        email: data.email,
        mobile: data.mobile,
        howHeardAbout: data.howHeardAbout,
        whyBabysit: data.whyBabysit,
      });
      
      await apiRequest('POST', '/api/sitter/onboarding/step2', {
        bio: data.bio,
        experienceLevel: data.experienceLevel,
        hourlyRate: data.hourlyRate,
      });
      
      return { success: true };
    },
    onSuccess: () => {
      toast({
        title: "Profile Saved",
        description: "Your bio and rate information has been saved.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/sitter/onboarding-status"] });
      setLocation('/sitter/onboarding/qualifications');
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to save your profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.firstName || !formData.email || !formData.bio || !formData.experienceLevel) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }
    saveMutation.mutate(formData);
  };

  const updateField = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-linen via-brushed-pink/20 to-white">
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        {/* Back to Dashboard Link */}
        <div className="mb-6">
          <Link href="/sitter/dashboard">
            <Button variant="ghost" className="text-village-wine hover:text-village-wine/80 hover:bg-village-wine/10 p-0 h-auto font-normal">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-village-wine">Step 1 of 7: Bio + Rate</span>
            <span className="text-sm text-taupe">Let's build your profile!</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div className="bg-gradient-to-r from-village-wine to-rose h-2 rounded-full" style={{ width: '14.3%' }}></div>
          </div>
        </div>

        <Card className="border-2 border-village-wine/20 shadow-lg">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl text-village-wine">Tell Us About You</CardTitle>
            <p className="text-taupe">Share your story and set your rate</p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Basic Info Section */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-village-wine">Basic Information</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="firstName">First Name *</Label>
                    <Input
                      id="firstName"
                      value={formData.firstName}
                      onChange={(e) => updateField('firstName', e.target.value)}
                      placeholder="Your first name"
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="email">Email *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => updateField('email', e.target.value)}
                      placeholder="your.email@example.com"
                      required
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="mobile">Mobile Number</Label>
                  <Input
                    id="mobile"
                    type="tel"
                    value={formData.mobile}
                    onChange={(e) => updateField('mobile', e.target.value)}
                    placeholder="021 123 4567"
                  />
                </div>

                <div>
                  <Label htmlFor="howHeardAbout">How did you hear about The Village Co?</Label>
                  <Select value={formData.howHeardAbout} onValueChange={(value) => updateField('howHeardAbout', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose an option" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="friend">Friend or family recommendation</SelectItem>
                      <SelectItem value="social-media">Social media</SelectItem>
                      <SelectItem value="google">Google search</SelectItem>
                      <SelectItem value="university">University/college</SelectItem>
                      <SelectItem value="job-board">Job board</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Profile Section */}
              <div className="space-y-4 border-t pt-6">
                <h3 className="text-lg font-semibold text-village-wine">Your Profile</h3>
                
                <div>
                  <Label htmlFor="bio">Tell us about yourself *</Label>
                  <Textarea
                    id="bio"
                    value={formData.bio}
                    onChange={(e) => updateField('bio', e.target.value)}
                    placeholder="Share your personality, what you love about kids, your hobbies..."
                    rows={4}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="experienceLevel">Experience Level *</Label>
                  <Select value={formData.experienceLevel} onValueChange={(value) => updateField('experienceLevel', value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose your experience level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="beginner">New to babysitting (but eager to learn!)</SelectItem>
                      <SelectItem value="some-experience">Some experience with kids</SelectItem>
                      <SelectItem value="experienced">Experienced babysitter</SelectItem>
                      <SelectItem value="professional">Professional childcare background</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="hourlyRate">Hourly Rate (NZD)</Label>
                  <Input
                    id="hourlyRate"
                    type="number"
                    min="15"
                    max="50"
                    value={formData.hourlyRate}
                    onChange={(e) => updateField('hourlyRate', e.target.value)}
                    placeholder="25"
                  />
                  <p className="text-sm text-taupe mt-1">Minimum wage in NZ is $22.70/hour</p>
                </div>

                <div>
                  <Label htmlFor="whyBabysit">Why do you want to babysit?</Label>
                  <Textarea
                    id="whyBabysit"
                    value={formData.whyBabysit}
                    onChange={(e) => updateField('whyBabysit', e.target.value)}
                    placeholder="Share what draws you to childcare... (optional)"
                    rows={3}
                  />
                </div>
              </div>

              <Button 
                type="submit" 
                className="w-full bg-village-wine hover:bg-village-wine/90 text-white"
                disabled={saveMutation.isPending}
              >
                {saveMutation.isPending ? 'Saving...' : 'Continue to Qualifications'}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}