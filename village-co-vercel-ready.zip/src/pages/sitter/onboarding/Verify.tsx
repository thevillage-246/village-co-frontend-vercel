import { useState } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Shield, Clock, Phone, Mail, AlertTriangle } from 'lucide-react';

export default function SitterOnboardingVerify() {
  const [, setLocation] = useLocation();

  const handleContinue = () => {
    setLocation('/sitter/onboarding/done');
  };

  const goBack = () => {
    setLocation('/sitter/onboarding/payout');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-linen via-brushed-pink/20 to-white">
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-village-wine">Step 6 of 7: Verification Status</span>
            <span className="text-sm text-taupe">Almost done!</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div className="bg-gradient-to-r from-village-wine to-rose h-2 rounded-full" style={{ width: '85.7%' }}></div>
          </div>
        </div>

        <Card className="border-2 border-village-wine/20 shadow-lg">
          <CardHeader className="text-center">
            <div className="w-20 h-20 bg-village-wine/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <Shield className="w-10 h-10 text-village-wine" />
            </div>
            <CardTitle className="text-2xl text-village-wine">Verification Process</CardTitle>
            <p className="text-taupe">Understanding our verification requirements</p>
          </CardHeader>
          <CardContent className="space-y-6">
            
            <div className="text-center py-4">
              <h3 className="text-xl font-semibold text-village-wine mb-2">
                Your Safety & Security Verification
              </h3>
              <p className="text-taupe">
                The Village Co takes safety seriously. Here's what our verification process includes to protect both families and sitters.
              </p>
            </div>

            {/* Verification Requirements */}
            <div className="space-y-4">
              <h4 className="text-lg font-semibold text-village-wine">Verification Process Includes:</h4>
              
              <div className="space-y-3">
                <div className="flex items-start space-x-3 p-3 bg-blue-50 rounded-lg">
                  <Shield className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0" />
                  <div>
                    <h5 className="font-semibold text-blue-800">Identity Verification</h5>
                    <p className="text-sm text-blue-700">
                      Government-issued ID verification to confirm your identity and age (18+).
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3 p-3 bg-green-50 rounded-lg">
                  <Shield className="w-5 h-5 text-green-600 mt-1 flex-shrink-0" />
                  <div>
                    <h5 className="font-semibold text-green-800">Background Check</h5>
                    <p className="text-sm text-green-700">
                      Police background check to ensure you have no history that would make you unsuitable for childcare.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3 p-3 bg-purple-50 rounded-lg">
                  <Phone className="w-5 h-5 text-purple-600 mt-1 flex-shrink-0" />
                  <div>
                    <h5 className="font-semibold text-purple-800">Reference Checks</h5>
                    <p className="text-sm text-purple-700">
                      We'll contact your provided references to verify your character and experience with children.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3 p-3 bg-orange-50 rounded-lg">
                  <Clock className="w-5 h-5 text-orange-600 mt-1 flex-shrink-0" />
                  <div>
                    <h5 className="font-semibold text-orange-800">Timeline</h5>
                    <p className="text-sm text-orange-700">
                      The complete verification process typically takes 5-7 business days once all documents are submitted.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Important Notice */}
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 flex items-start space-x-3">
              <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
              <div>
                <h4 className="font-semibold text-yellow-800 mb-1">Important Notice</h4>
                <p className="text-sm text-yellow-700">
                  You cannot start babysitting until all verification steps are complete and approved. We'll guide you through each step after you submit your application.
                </p>
              </div>
            </div>

            {/* Contact Information */}
            <div className="bg-linen/50 rounded-lg p-4">
              <h4 className="font-semibold text-village-wine mb-3">Need help or have questions?</h4>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Mail className="w-4 h-4 text-village-wine" />
                  <span className="text-sm">
                    Email us at <a href="mailto:info@thevillageco.nz" className="text-village-wine underline">info@thevillageco.nz</a>
                  </span>
                </div>
                <div className="flex items-center space-x-2">
                  <Phone className="w-4 h-4 text-village-wine" />
                  <span className="text-sm">
                    Call us on <a href="tel:+64272074206" className="text-village-wine underline">027 207 4206</a>
                  </span>
                </div>
              </div>
            </div>

            {/* Motivational Message */}
            <div className="text-center py-4 border-t">
              <p className="text-village-wine font-medium mb-2">
                "Every family needs their village, and you're about to become part of it."
              </p>
              <p className="text-sm text-taupe">
                - Nikki & Sophia, Founders of The Village Co
              </p>
            </div>

            <div className="flex gap-4">
              <Button 
                type="button" 
                variant="outline" 
                onClick={goBack}
                className="flex-1"
              >
                Back
              </Button>
              <Button 
                onClick={handleContinue}
                className="flex-1 bg-village-wine hover:bg-village-wine/90 text-white"
              >
                I Understand - Continue
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}