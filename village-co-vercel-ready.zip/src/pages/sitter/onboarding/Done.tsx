import { useState } from 'react';
import { useLocation } from 'wouter';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { CheckCircle, Clock, Phone, Mail, Heart } from 'lucide-react';

export default function SitterOnboardingDone() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const finalizeMutation = useMutation({
    mutationFn: async () => {
      return apiRequest('POST', '/api/sitter/finalize-onboarding', {});
    },
    onSuccess: () => {
      toast({
        title: "Application Submitted!",
        description: "Welcome to The Village Co family!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/sitter/onboarding-status"] });
      setLocation('/sitter-onboarding-thank-you');
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to submit application. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = () => {
    finalizeMutation.mutate();
  };

  const goBack = () => {
    setLocation('/sitter/onboarding/verify');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-linen via-brushed-pink/20 to-white">
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-village-wine">Step 7 of 7: Complete</span>
            <span className="text-sm text-taupe">You made it!</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div className="bg-gradient-to-r from-village-wine to-rose h-2 rounded-full w-full"></div>
          </div>
        </div>

        <Card className="border-2 border-village-wine/20 shadow-lg">
          <CardHeader className="text-center">
            <div className="w-20 h-20 bg-village-wine/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <Heart className="w-10 h-10 text-village-wine" />
            </div>
            <CardTitle className="text-2xl text-village-wine">You're Almost There!</CardTitle>
            <p className="text-taupe">Ready to join The Village Co family?</p>
          </CardHeader>
          <CardContent className="space-y-6">
            
            <div className="text-center py-4">
              <h3 className="text-xl font-semibold text-village-wine mb-2">
                🎉 Congratulations on completing your application!
              </h3>
              <p className="text-taupe">
                You've taken the first step towards making a real difference in families' lives while earning great money doing what you love.
              </p>
            </div>

            {/* What's Next Section */}
            <div className="space-y-4">
              <h4 className="text-lg font-semibold text-village-wine">What happens next:</h4>
              
              <div className="space-y-3">
                <div className="flex items-start space-x-3 p-3 bg-blue-50 rounded-lg">
                  <CheckCircle className="w-5 h-5 text-blue-600 mt-1 flex-shrink-0" />
                  <div>
                    <h5 className="font-semibold text-blue-800">Application Review</h5>
                    <p className="text-sm text-blue-700">
                      Our team will review your application within 24-48 hours and send you an update.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3 p-3 bg-green-50 rounded-lg">
                  <Phone className="w-5 h-5 text-green-600 mt-1 flex-shrink-0" />
                  <div>
                    <h5 className="font-semibold text-green-800">Welcome Call</h5>
                    <p className="text-sm text-green-700">
                      We'll schedule a friendly 15-minute welcome call to get to know you better and answer any questions.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3 p-3 bg-purple-50 rounded-lg">
                  <CheckCircle className="w-5 h-5 text-purple-600 mt-1 flex-shrink-0" />
                  <div>
                    <h5 className="font-semibold text-purple-800">Identity Verification</h5>
                    <p className="text-sm text-purple-700">
                      Complete a quick identity verification process (usually takes 3-5 business days).
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3 p-3 bg-rose-50 rounded-lg">
                  <Heart className="w-5 h-5 text-rose-600 mt-1 flex-shrink-0" />
                  <div>
                    <h5 className="font-semibold text-rose-800">Start Babysitting!</h5>
                    <p className="text-sm text-rose-700">
                      Once verified, your profile goes live and families can book you for babysitting.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Information */}
            <div className="bg-linen/50 rounded-lg p-4">
              <h4 className="font-semibold text-village-wine mb-3">Need help or have questions?</h4>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Mail className="w-4 h-4 text-village-wine" />
                  <span className="text-sm">
                    Email us at <a href="mailto:info@thevillageco.nz" className="text-village-wine underline">info@thevillageco.nz</a>
                  </span>
                </div>
                <div className="flex items-center space-x-2">
                  <Phone className="w-4 h-4 text-village-wine" />
                  <span className="text-sm">
                    Call us on <a href="tel:+64272074206" className="text-village-wine underline">027 207 4206</a>
                  </span>
                </div>
              </div>
            </div>

            {/* Motivational Message */}
            <div className="text-center py-4 border-t">
              <p className="text-village-wine font-medium mb-2">
                "Every family needs their village, and you're about to become part of it."
              </p>
              <p className="text-sm text-taupe">
                - Nikki & Sophia, Founders of The Village Co
              </p>
            </div>

            <div className="flex gap-4">
              <Button 
                type="button" 
                variant="outline" 
                onClick={goBack}
                className="flex-1"
              >
                Back
              </Button>
              <Button 
                onClick={handleSubmit}
                className="flex-1 bg-village-wine hover:bg-village-wine/90 text-white text-lg py-3"
                disabled={finalizeMutation.isPending}
              >
                {finalizeMutation.isPending ? 'Submitting...' : '🎉 Submit My Application!'}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}