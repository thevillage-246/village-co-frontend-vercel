import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Shield, CheckCircle, AlertCircle, Clock, ArrowLeft } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Link } from 'wouter';

export default function SitterVerification() {
  const { currentUser } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isStartingVerification, setIsStartingVerification] = useState(false);

  // Fetch current verification status
  const { data: verificationStatus, isLoading } = useQuery({
    queryKey: ['/api/sitter/verification-status'],
    enabled: !!currentUser
  });

  // Start verification mutation
  const startVerificationMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/sitter/veriff-start');
      return response;
    },
    onSuccess: (data: any) => {
      if (data.verificationUrl) {
        setIsStartingVerification(true);
        // Open verification in new window
        window.open(data.verificationUrl, '_blank', 'width=800,height=600');
        
        // Refresh status after a delay
        setTimeout(() => {
          queryClient.invalidateQueries({ queryKey: ['/api/sitter/verification-status'] });
          setIsStartingVerification(false);
        }, 2000);
      }
    },
    onError: (error: any) => {
      toast({
        title: "Verification Failed",
        description: error.message || "Failed to start verification process",
        variant: "destructive",
      });
      setIsStartingVerification(false);
    }
  });

  const handleStartVerification = () => {
    startVerificationMutation.mutate();
  };

  const getStatusInfo = () => {
    console.log('Verification status data:', verificationStatus);
    
    if (!verificationStatus || !verificationStatus.status || verificationStatus.status === 'not_started') {
      return {
        icon: <Clock className="h-6 w-6 text-gray-400" />,
        title: "Not Started",
        description: "Identity verification has not been started yet",
        color: "text-gray-600",
        bgColor: "bg-gray-50",
        borderColor: "border-gray-200"
      };
    }

    switch (verificationStatus?.status) {
      case 'approved':
        return {
          icon: <CheckCircle className="h-6 w-6 text-green-600" />,
          title: "Verified",
          description: "Your identity has been successfully verified",
          color: "text-green-600",
          bgColor: "bg-green-50",
          borderColor: "border-green-200"
        };
      case 'pending':
        return {
          icon: <Clock className="h-6 w-6 text-orange-500" />,
          title: "Under Review",
          description: "Your verification is being processed. This usually takes 1-2 business days.",
          color: "text-orange-600",
          bgColor: "bg-orange-50",
          borderColor: "border-orange-200"
        };
      case 'rejected':
        return {
          icon: <AlertCircle className="h-6 w-6 text-red-500" />,
          title: "Verification Failed",
          description: "Please try again or contact support for assistance",
          color: "text-red-600",
          bgColor: "bg-red-50",
          borderColor: "border-red-200"
        };
      default:
        return {
          icon: <Clock className="h-6 w-6 text-gray-400" />,
          title: "Unknown Status",
          description: "Unable to determine verification status",
          color: "text-gray-600",
          bgColor: "bg-gray-50",
          borderColor: "border-gray-200"
        };
    }
  };

  if (isLoading) {
    return (
      <div className="container max-w-4xl py-8">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
        </div>
      </div>
    );
  }

  const statusInfo = getStatusInfo();

  return (
    <div className="min-h-screen bg-[#F9F5F0]">
      <div className="container max-w-4xl py-8">
        {/* Back to Dashboard Link */}
        <div className="mb-6">
          <Link href="/sitter/dashboard">
            <Button variant="ghost" className="text-village-wine hover:text-village-wine/80 hover:bg-village-wine/10 p-0 h-auto font-normal">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </Link>
        </div>

        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-[#6B3E4B] mb-2" style={{ fontFamily: 'Satoshi, sans-serif' }}>
            Identity Verification
          </h1>
          <p className="text-lg text-gray-600" style={{ fontFamily: 'DM Sans, sans-serif' }}>
            Verify your identity to build trust with families and start accepting bookings.
          </p>
        </div>

        {/* Status Card */}
        <Card className={`bg-white border-0 rounded-xl shadow-lg mb-6 ${statusInfo.borderColor}`}>
          <CardHeader>
            <CardTitle className="flex items-center gap-3" style={{ fontFamily: 'Satoshi, sans-serif' }}>
              <Shield className="h-6 w-6 text-[#6B3E4B]" />
              Verification Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`p-4 rounded-lg ${statusInfo.bgColor} ${statusInfo.borderColor} border`}>
              <div className="flex items-center gap-3 mb-2">
                {statusInfo.icon}
                <span className={`font-medium ${statusInfo.color}`} style={{ fontFamily: 'Satoshi, sans-serif' }}>
                  {statusInfo.title}
                </span>
              </div>
              <p className={`${statusInfo.color} text-sm`} style={{ fontFamily: 'DM Sans, sans-serif' }}>
                {statusInfo.description}
              </p>
              
              {verificationStatus?.verificationDate && (
                <p className="text-gray-500 text-xs mt-2">
                  Verified on: {new Date(verificationStatus.verificationDate).toLocaleDateString()}
                </p>
              )}
            </div>

            {(!verificationStatus || !verificationStatus.status || verificationStatus.status === 'not_started' || verificationStatus.status === 'rejected') && (
              <div className="mt-6 text-center">
                <Button 
                  onClick={handleStartVerification}
                  disabled={startVerificationMutation.isPending || isStartingVerification}
                  className="bg-[#6B3E4B] hover:bg-[#5a3340] text-white px-8 py-3 rounded-xl shadow-lg"
                >
                  {startVerificationMutation.isPending || isStartingVerification 
                    ? 'Starting Verification...' 
                    : 'Start Identity Verification'
                  }
                </Button>
              </div>
            )}

            {verificationStatus?.status === 'pending' && (
              <div className="mt-6 text-center">
                <Button 
                  onClick={() => queryClient.invalidateQueries({ queryKey: ['/api/sitter/verification-status'] })}
                  variant="outline"
                  className="border-[#6B3E4B] text-[#6B3E4B] hover:bg-[#6B3E4B] hover:text-white"
                >
                  Check Status
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Information Card */}
        <Card className="bg-white border-0 rounded-xl shadow-lg">
          <CardContent className="p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4" style={{ fontFamily: 'Satoshi, sans-serif' }}>
              Why Identity Verification?
            </h3>
            <div className="space-y-3 text-gray-600" style={{ fontFamily: 'DM Sans, sans-serif' }}>
              <p>• Builds trust with families by confirming your identity</p>
              <p>• Required to receive booking requests from parents</p>
              <p>• Ensures a safe community for children and families</p>
              <p>• Quick process taking only 3-5 minutes to complete</p>
              <p>• Uses bank-grade security to protect your information</p>
            </div>
            
            <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
              <h4 className="font-medium text-blue-900 mb-2">What You'll Need:</h4>
              <ul className="text-blue-800 text-sm space-y-1">
                <li>• Government-issued photo ID (driver's licence, passport)</li>
                <li>• Clear lighting and camera access</li>
                <li>• About 3-5 minutes of your time</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}