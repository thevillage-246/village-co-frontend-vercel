import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { BOOKING_STATUS } from '@shared/schema';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  CalendarX, 
  Filter, 
  ArrowLeftCircle 
} from 'lucide-react';
import BookingRequestCard from '@/components/booking/BookingRequestCard';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle 
} from '@/components/ui/dialog';

const BookingRequests: React.FC = () => {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState('pending');
  const [confirmationDialog, setConfirmationDialog] = useState<{
    isOpen: boolean;
    bookingId?: number;
    action: 'accept' | 'decline';
  }>({
    isOpen: false,
    action: 'accept',
  });

  // Fetch sitter profile
  const { data: sitterProfile, isLoading: loadingProfile } = useQuery({
    queryKey: [`/api/sitters/${user?.id}/profile`],
    enabled: !!user?.id,
  });

  // Fetch pending booking requests
  const { data: pendingRequests, isLoading: loadingPending } = useQuery({
    queryKey: [`/api/sitters/${sitterProfile?.id}/booking-requests`],
    enabled: !!sitterProfile?.id,
  });

  // Fetch all bookings
  const { data: allBookings, isLoading: loadingBookings } = useQuery({
    queryKey: [`/api/sitters/${sitterProfile?.id}/bookings`],
    enabled: !!sitterProfile?.id,
  });

  // Accept booking mutation
  const acceptBooking = useMutation({
    mutationFn: async (bookingId: number) => {
      const response = await apiRequest('POST', `/api/bookings/${bookingId}/accept`);
      return response.json();
    },
    onSuccess: () => {
      // Invalidate both requests and bookings queries
      queryClient.invalidateQueries({ queryKey: [`/api/sitters/${sitterProfile?.id}/booking-requests`] });
      queryClient.invalidateQueries({ queryKey: [`/api/sitters/${sitterProfile?.id}/bookings`] });
      
      toast({
        title: 'Booking Accepted',
        description: 'You have successfully accepted the booking request. The parent has been notified and will be charged for the booking.',
      });
      
      setConfirmationDialog({ isOpen: false, action: 'accept' });
    },
    onError: (error: any) => {
      toast({
        title: 'Error Accepting Booking',
        description: error.message || 'Failed to accept the booking. Please try again.',
        variant: 'destructive',
      });
    },
  });

  // Decline booking mutation
  const declineBooking = useMutation({
    mutationFn: async (bookingId: number) => {
      const response = await apiRequest('POST', `/api/bookings/${bookingId}/decline`);
      return response.json();
    },
    onSuccess: () => {
      // Invalidate both requests and bookings queries
      queryClient.invalidateQueries({ queryKey: [`/api/sitters/${sitterProfile?.id}/booking-requests`] });
      queryClient.invalidateQueries({ queryKey: [`/api/sitters/${sitterProfile?.id}/bookings`] });
      
      toast({
        title: 'Booking Declined',
        description: 'You have declined the booking request. The parent has been notified.',
      });
      
      setConfirmationDialog({ isOpen: false, action: 'accept' });
    },
    onError: (error: any) => {
      toast({
        title: 'Error Declining Booking',
        description: error.message || 'Failed to decline the booking. Please try again.',
        variant: 'destructive',
      });
    },
  });

  // Check if sitter has a Stripe Connect account
  const { data: sitterUser } = useQuery({
    queryKey: [`/api/users/${user?.id}`],
    enabled: !!user?.id,
  });

  // If sitter doesn't have a Stripe Connect account, create one on load
  const createStripeAccount = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', `/api/users/${user?.id}/create-stripe-account`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/users/${user?.id}`] });
    },
  });

  React.useEffect(() => {
    if (sitterUser && !sitterUser.stripeConnectId) {
      createStripeAccount.mutate();
    }
  }, [sitterUser]);

  const handleAccept = (bookingId: number) => {
    // Check if the sitter has a Stripe Connect account
    if (!sitterUser?.stripeConnectId) {
      // If no Stripe Connect account, we need to create one first
      toast({
        title: 'Stripe Connect Required',
        description: 'You need to set up your Stripe Connect account to receive payments. We\'ll help you set that up first.',
      });
      
      // Create Stripe Connect account
      createStripeAccount.mutate();
      return;
    }
    
    setConfirmationDialog({
      isOpen: true,
      bookingId,
      action: 'accept',
    });
  };

  const handleDecline = (bookingId: number) => {
    setConfirmationDialog({
      isOpen: true,
      bookingId,
      action: 'decline',
    });
  };

  const confirmAction = () => {
    if (!confirmationDialog.bookingId) return;
    
    if (confirmationDialog.action === 'accept') {
      acceptBooking.mutate(confirmationDialog.bookingId);
    } else {
      declineBooking.mutate(confirmationDialog.bookingId);
    }
  };

  const handleViewDetails = (bookingId: number) => {
    navigate(`/booking/${bookingId}`);
  };

  if (loadingProfile || loadingPending || loadingBookings) {
    return (
      <div className="flex justify-center items-center min-h-[60vh]">
        <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!sitterProfile) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card>
          <CardHeader>
            <CardTitle>Complete Your Profile</CardTitle>
            <CardDescription>
              Please complete your sitter profile to view booking requests.
            </CardDescription>
          </CardHeader>
          <CardContent>
          </CardContent>
          <Button onClick={() => navigate(`/profile/${user?.id}`)}>
            Complete Profile
          </Button>
        </Card>
      </div>
    );
  }

  // Filter bookings for the different tabs
  const pastBookings = allBookings
    ? allBookings.filter(b => 
        [BOOKING_STATUS.COMPLETED, BOOKING_STATUS.DECLINED, BOOKING_STATUS.CANCELLED].includes(b.status)
      )
    : [];
  
  const upcomingBookings = allBookings
    ? allBookings.filter(b => b.status === BOOKING_STATUS.ACCEPTED)
    : [];

  const hasPendingRequests = pendingRequests && pendingRequests.length > 0;
  const hasUpcomingBookings = upcomingBookings && upcomingBookings.length > 0;
  const hasPastBookings = pastBookings && pastBookings.length > 0;

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h1 className="text-3xl font-bold">Booking Requests</h1>
            <p className="text-gray-500 mt-1">Manage your incoming booking requests and view your booking history</p>
          </div>
          <Button 
            onClick={() => navigate('/sitter-dashboard')} 
            variant="outline" 
            className="mt-4 sm:mt-0 flex items-center"
          >
            <ArrowLeftCircle className="mr-2 h-4 w-4" />
            Back to Dashboard
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="pending" className="relative">
            Pending
            {hasPendingRequests && (
              <span className="absolute top-0 right-0 -mt-2 -mr-2 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[10px] font-medium text-white">
                {pendingRequests.length}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
          <TabsTrigger value="past">Past</TabsTrigger>
        </TabsList>
        
        <TabsContent value="pending" className="mt-6">
          {hasPendingRequests ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {pendingRequests.map((request: any) => (
                <BookingRequestCard 
                  key={request.id}
                  booking={request}
                  onAccept={handleAccept}
                  onDecline={handleDecline}
                  onViewDetails={handleViewDetails}
                />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-16">
                <CalendarX className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">No Pending Requests</h3>
                <p className="text-muted-foreground text-center max-w-md mb-6">
                  You don't have any pending booking requests. Make sure your availability is up to date to receive more requests.
                </p>
                <Button onClick={() => navigate('/availability')} variant="outline">
                  Manage Availability
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>
        
        <TabsContent value="upcoming" className="mt-6">
          {hasUpcomingBookings ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {upcomingBookings.map((booking: any) => (
                <BookingRequestCard 
                  key={booking.id}
                  booking={booking}
                  onViewDetails={handleViewDetails}
                />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-16">
                <CalendarX className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">No Upcoming Bookings</h3>
                <p className="text-muted-foreground text-center max-w-md">
                  You don't have any upcoming bookings. Check your pending requests or update your availability.
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
        
        <TabsContent value="past" className="mt-6">
          {hasPastBookings ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {pastBookings.map((booking: any) => (
                <BookingRequestCard 
                  key={booking.id}
                  booking={booking}
                  onViewDetails={handleViewDetails}
                />
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-16">
                <CalendarX className="h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium mb-2">No Past Bookings</h3>
                <p className="text-muted-foreground text-center max-w-md">
                  Your booking history will appear here once you've completed bookings.
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
      
      {/* Confirmation Dialog */}
      <Dialog open={confirmationDialog.isOpen} onOpenChange={(open) => setConfirmationDialog({ ...confirmationDialog, isOpen: open })}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {confirmationDialog.action === 'accept' ? 'Accept Booking Request' : 'Decline Booking Request'}
            </DialogTitle>
            <DialogDescription>
              {confirmationDialog.action === 'accept'
                ? 'Are you sure you want to accept this booking request? You will be responsible for providing care at the scheduled time.'
                : 'Are you sure you want to decline this booking request? The parent will be notified and the request will be removed from your queue.'}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setConfirmationDialog({ ...confirmationDialog, isOpen: false })}
            >
              Cancel
            </Button>
            <Button
              variant={confirmationDialog.action === 'accept' ? 'default' : 'destructive'}
              onClick={confirmAction}
              disabled={confirmationDialog.action === 'accept' ? acceptBooking.isPending : declineBooking.isPending}
            >
              {(confirmationDialog.action === 'accept' ? acceptBooking.isPending : declineBooking.isPending)
                ? 'Processing...'
                : confirmationDialog.action === 'accept'
                  ? 'Accept'
                  : 'Decline'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default BookingRequests;
