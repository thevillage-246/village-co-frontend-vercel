import React from 'react';
import StreamlinedProfileManager from '@/components/sitters/StreamlinedProfileManager';

export default function NewSitterProfile() {
  return <StreamlinedProfileManager />;
}