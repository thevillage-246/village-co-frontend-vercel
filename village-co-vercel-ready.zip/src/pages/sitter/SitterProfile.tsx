import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { useUser } from '@/hooks/use-user';
import { Edit3, Camera, MapPin, Clock, Star, Shield, Award, Phone, Mail, Calendar, Video } from 'lucide-react';
import StreamlinedProfileManager from '@/components/sitters/StreamlinedProfileManager';

interface SitterProfile {
  id: number;
  userId: number;
  bio: string;
  experience: string;
  hourlyRate: number;
  photoUrl: string | null;
  photoUrls?: string[];
  aboutVideoUrl: string | null;
  introVideoUrl: string | null;
  age: number;
  badge: string | null;
  identityVerified: boolean;
  verificationStatus: string;
  backgroundCheckDate: string | null;
  firstAidCertDate: string | null;
  availabilityTags: string[];
  whyKidsQuote: string | null;
  isActive: boolean;
  profileComplete: boolean;
  // Pet preferences and additional info
  okWithPets?: boolean;
  languagesSpoken?: string;
  qualifications?: string[];
  // Address and emergency contact - ADMIN ACCESS ONLY
  streetAddress?: string;
  suburb?: string;
  city?: string;
  postcode?: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  emergencyContactRelationship?: string;
}

export default function SitterProfile() {
  const [activeTab, setActiveTab] = useState('overview');
  const [isEditMode, setIsEditMode] = useState(false);
  const [, navigate] = useLocation();
  const { user } = useUser();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: profile, isLoading } = useQuery({
    queryKey: ['/api/sitter/profile'],
    queryFn: () => apiRequest('GET', '/api/sitter/profile').then(res => res.json())
  });

  const { data: userProfile } = useQuery({
    queryKey: ['/api/auth/user'],
    queryFn: () => apiRequest('GET', '/api/auth/user').then(res => res.json())
  });

  const toggleActiveMutation = useMutation({
    mutationFn: (isActive: boolean) => 
      apiRequest('PUT', '/api/sitter/profile', { isActive }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sitter/profile'] });
      toast({
        title: "Profile Updated",
        description: "Your availability status has been updated.",
      });
    },
    onError: (error) => {
      toast({
        title: "Update Failed",
        description: "Failed to update availability status. Please try again.",
        variant: "destructive",
      });
    }
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-village-linen to-white p-4">
        <div className="max-w-4xl mx-auto">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-gray-200 rounded w-1/3"></div>
            <div className="h-64 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-village-linen to-white p-4">
        <div className="max-w-4xl mx-auto text-center py-12">
          <h1 className="text-2xl font-bold text-village-wine mb-4">Profile Not Found</h1>
          <p className="text-gray-600">Unable to load your sitter profile.</p>
        </div>
      </div>
    );
  }

  const getVerificationStatus = () => {
    if (profile.identityVerified) {
      return { status: 'Verified', color: 'bg-green-100 text-green-800', icon: Shield };
    }
    return { status: 'Pending', color: 'bg-yellow-100 text-yellow-800', icon: Clock };
  };

  const verificationStatus = getVerificationStatus();

  return (
    <div className="min-h-screen bg-gradient-to-br from-village-linen to-white">
      <div className="max-w-4xl mx-auto p-4 space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-village-wine">My Profile</h1>
            <p className="text-gray-600">Manage your sitter profile and verification status</p>
          </div>
          <div className="flex items-center gap-3">
            <Badge variant={profile.isActive ? "default" : "secondary"} className="px-3 py-1">
              {profile.isActive ? "Available" : "Unavailable"}
            </Badge>
            <Button
              variant="outline"
              size="sm"
              onClick={() => toggleActiveMutation.mutate(!profile.isActive)}
              disabled={toggleActiveMutation.isPending}
            >
              {profile.isActive ? "Set Unavailable" : "Set Available"}
            </Button>
          </div>
        </div>

        {/* Profile Overview Card */}
        <Card>
          <CardContent className="p-6">
            <div className="flex items-start gap-6">
              <div className="relative">
                <Avatar className="w-24 h-24">
                  <AvatarImage src={profile.photoUrl || undefined} />
                  <AvatarFallback className="text-lg">
                    {(userProfile?.user?.firstName || userProfile?.user?.first_name || 'S')?.[0]}{(userProfile?.user?.lastName || userProfile?.user?.last_name || 'B')?.[0]}
                  </AvatarFallback>
                </Avatar>
                <Button
                  size="sm"
                  variant="outline"
                  className="absolute -bottom-2 -right-2 rounded-full w-8 h-8 p-0"
                  onClick={() => navigate('/sitter/edit-profile')}
                >
                  <Camera className="w-4 h-4" />
                </Button>
              </div>
              
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <h2 className="text-2xl font-bold text-village-wine">
                    {userProfile?.user?.firstName || userProfile?.user?.first_name || 'Shavaughn'} {userProfile?.user?.lastName || userProfile?.user?.last_name || 'Buckley'}
                  </h2>
                  {profile.badge && (
                    <Badge variant="outline" className="bg-village-rose/10 text-village-wine border-village-rose">
                      <Award className="w-3 h-3 mr-1" />
                      {profile.badge}
                    </Badge>
                  )}
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                  <div className="flex items-center gap-2 text-gray-600">
                    <MapPin className="w-4 h-4" />
                    <span>Christchurch, NZ</span>
                    <Button variant="ghost" size="sm" className="p-0 h-auto text-village-wine">
                      <Edit3 className="w-3 h-3 ml-1" />
                    </Button>
                  </div>
                  <div className="flex items-center gap-2 text-gray-600">
                    <Calendar className="w-4 h-4" />
                    <span>{profile.age ? `${profile.age} years old` : 'Add age'}</span>
                  </div>
                  <div className="flex items-center gap-2 text-gray-600">
                    <Star className="w-4 h-4" />
                    <span>{profile.hourlyRate ? `${profile.hourlyRate}/hour` : 'Set rate'}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2 mb-4">
                  <Badge className={verificationStatus.color}>
                    <verificationStatus.icon className="w-3 h-3 mr-1" />
                    {verificationStatus.status}
                    {verificationStatus.status === 'Pending' && (
                      <span className="ml-1 text-xs">(Identity verification in review)</span>
                    )}
                  </Badge>
                  <Badge variant="outline" className={`${profile.profileComplete ? 'bg-green-50 text-green-700' : 'bg-orange-50 text-orange-700'}`}>
                    Profile {profile.profileComplete ? 'Complete' : 'Incomplete'}
                  </Badge>
                </div>

                <p className="text-gray-700 leading-relaxed">{profile.bio}</p>
              </div>

              <Button
                variant="outline"
                onClick={() => navigate('/sitter/edit-profile')}
                className="flex items-center gap-2"
              >
                <Edit3 className="w-4 h-4" />
                Edit Profile
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Contact Information */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-village-wine">Contact Information</CardTitle>
              <CardDescription>Your contact details for platform communications</CardDescription>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/sitter/edit-profile')}
              className="flex items-center gap-2"
            >
              <Edit3 className="w-4 h-4" />
              Edit Profile
            </Button>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-gray-500" />
                <div>
                  <p className="font-medium">{userProfile?.user?.email || user?.email}</p>
                  <p className="text-sm text-gray-500">Primary email</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-gray-500" />
                <div>
                  <p className="font-medium">{userProfile?.user?.phone || user?.phone || 'Not provided'}</p>
                  <div className="flex items-center gap-2">
                    <p className="text-sm text-gray-500">Contact number</p>
                    {(userProfile?.user?.phone || user?.phone) && (
                      <Badge variant="outline" className="bg-green-50 text-green-700 text-xs">
                        <Shield className="w-3 h-3 mr-1" />
                        Verified
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Tabs for detailed sections */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-7">
            <TabsTrigger value="overview">Experience</TabsTrigger>
            <TabsTrigger value="photos">Photos</TabsTrigger>
            <TabsTrigger value="videos">Videos</TabsTrigger>
            <TabsTrigger value="qualifications">Qualifications</TabsTrigger>
            <TabsTrigger value="preferences">Preferences</TabsTrigger>
            <TabsTrigger value="contact">Contact Info</TabsTrigger>
            <TabsTrigger value="availability">Availability</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-village-wine">Experience & Background</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium mb-2">Experience</h4>
                    <p className="text-gray-700">{profile.experience}</p>
                  </div>
                  
                  {profile.whyKidsQuote && (
                    <div>
                      <h4 className="font-medium mb-2">Why I Love Working with Kids</h4>
                      <p className="text-gray-700 italic">"{profile.whyKidsQuote}"</p>
                    </div>
                  )}

                  {profile.availabilityTags && profile.availabilityTags.length > 0 && (
                    <div>
                      <h4 className="font-medium mb-2">Availability</h4>
                      <div className="flex flex-wrap gap-2">
                        {profile.availabilityTags.map((tag, index) => (
                          <Badge key={index} variant="outline">{tag}</Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="photos">
            <MultiPhotoUpload 
              currentPhotos={profile.photoUrls || []}
              primaryPhoto={profile.photoUrl}
              sitterId={profile.id}
              onPhotosUpdated={() => {
                queryClient.invalidateQueries({ queryKey: ['/api/sitter/profile'] });
              }}
            />
          </TabsContent>

          <TabsContent value="videos">
            <Card>
              <CardHeader>
                <CardTitle className="text-village-wine">About Me Video</CardTitle>
                <CardDescription>Share a quick introduction about yourself and why you love working with children. This video appears on your public profile.</CardDescription>
              </CardHeader>
              <CardContent>
                <VideoUploadManager 
                  currentAboutVideo={profile.aboutVideoUrl}
                  currentIntroVideo={null}
                  onVideoUpdate={() => {
                    queryClient.invalidateQueries({ queryKey: ['/api/sitter/profile'] });
                  }}
                  hideIntroVideo={true}
                />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="qualifications">
            <QualificationsManager sitterId={profile.id} />
          </TabsContent>

          <TabsContent value="preferences">
            <PetPreferencesForm 
              profile={profile}
              onSuccess={() => {
                queryClient.invalidateQueries({ queryKey: ['/api/sitter/profile'] });
              }}
            />
          </TabsContent>

          <TabsContent value="contact">
            <AddressEmergencyForm 
              profile={profile}
              onSuccess={() => {
                queryClient.invalidateQueries({ queryKey: ['/api/sitter/profile'] });
              }}
            />
          </TabsContent>

          <TabsContent value="availability" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-village-wine">Availability Settings</CardTitle>
                <CardDescription>Manage when you're available for babysitting</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <Clock className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                  <p className="text-gray-600 mb-4">Set your weekly availability schedule</p>
                  <Button variant="outline" onClick={() => navigate('/availability')}>Manage Availability</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Edit Profile Modal/Form */}
        {isEditMode && (
          <EditSitterProfileForm
            profile={profile}
            userProfile={userProfile?.user}
            onClose={() => setIsEditMode(false)}
            onSuccess={() => {
              setIsEditMode(false);
              queryClient.invalidateQueries({ queryKey: ['/api/sitter/profile'] });
            }}
          />
        )}
      </div>
    </div>
  );
}