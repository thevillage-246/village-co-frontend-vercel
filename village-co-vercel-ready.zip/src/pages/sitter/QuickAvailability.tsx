import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/contexts/AuthContext';
import { useMutation } from '@tanstack/react-query';
import { Helmet } from 'react-helmet';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { 
  Clock, 
  Calendar, 
  Zap, 
  ArrowLeft, 
  CheckCircle, 
  AlertCircle,
  Coffee,
  Moon,
  Sunrise
} from 'lucide-react';

export default function QuickAvailability() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  
  const [availableToday, setAvailableToday] = useState(false);
  const [availableThisWeekend, setAvailableThisWeekend] = useState(false);
  const [availableNextWeek, setAvailableNextWeek] = useState(false);
  const [emergencyAvailable, setEmergencyAvailable] = useState(false);

  const quickAvailabilityMutation = useMutation({
    mutationFn: async (data: {
      availableToday: boolean;
      availableThisWeekend: boolean;
      availableNextWeek: boolean;
      emergencyAvailable: boolean;
    }) => {
      const response = await apiRequest('POST', '/api/sitter/quick-availability', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Availability Updated",
        description: "Your quick availability settings have been saved successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Update Failed",
        description: error.message || "Failed to update availability. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSave = () => {
    quickAvailabilityMutation.mutate({
      availableToday,
      availableThisWeekend,
      availableNextWeek,
      emergencyAvailable
    });
  };

  const getCurrentTime = () => {
    const now = new Date();
    return now.toLocaleTimeString('en-NZ', { 
      hour: '2-digit', 
      minute: '2-digit',
      hour12: true 
    });
  };

  return (
    <>
      <Helmet>
        <title>Quick Availability | The Village Co.</title>
        <meta name="description" content="Quickly toggle your availability for immediate booking opportunities." />
      </Helmet>
      
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-4 mb-4">
            <Button 
              onClick={() => navigate('/sitter-dashboard')} 
              variant="outline"
              size="sm"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <div>
              <h1 className="text-3xl font-bold flex items-center gap-2">
                <Zap className="h-8 w-8 text-yellow-500" />
                Quick Availability
              </h1>
              <p className="text-gray-600 mt-1">
                Toggle your availability for instant booking opportunities
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Quick Toggles */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Instant Availability
              </CardTitle>
              <CardDescription>
                Let parents know you're available for immediate or short-notice bookings
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Available Today */}
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-orange-100 rounded-lg">
                    <Sunrise className="h-5 w-5 text-orange-600" />
                  </div>
                  <div>
                    <Label htmlFor="today" className="text-base font-medium">
                      Available Today
                    </Label>
                    <p className="text-sm text-gray-600">
                      Available for bookings from now ({getCurrentTime()}) onwards
                    </p>
                  </div>
                </div>
                <Switch
                  id="today"
                  checked={availableToday}
                  onCheckedChange={setAvailableToday}
                />
              </div>

              {/* Available This Weekend */}
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <Coffee className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <Label htmlFor="weekend" className="text-base font-medium">
                      Available This Weekend
                    </Label>
                    <p className="text-sm text-gray-600">
                      Saturday or Sunday evening availability
                    </p>
                  </div>
                </div>
                <Switch
                  id="weekend"
                  checked={availableThisWeekend}
                  onCheckedChange={setAvailableThisWeekend}
                />
              </div>

              {/* Available Next Week */}
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-green-100 rounded-lg">
                    <Calendar className="h-5 w-5 text-green-600" />
                  </div>
                  <div>
                    <Label htmlFor="nextweek" className="text-base font-medium">
                      Available Next Week
                    </Label>
                    <p className="text-sm text-gray-600">
                      Open to bookings for the upcoming week
                    </p>
                  </div>
                </div>
                <Switch
                  id="nextweek"
                  checked={availableNextWeek}
                  onCheckedChange={setAvailableNextWeek}
                />
              </div>

              {/* Emergency Available */}
              <div className="flex items-center justify-between p-4 border-2 border-red-200 rounded-lg bg-red-50">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-red-100 rounded-lg">
                    <AlertCircle className="h-5 w-5 text-red-600" />
                  </div>
                  <div>
                    <Label htmlFor="emergency" className="text-base font-medium text-red-900">
                      Emergency Available
                    </Label>
                    <p className="text-sm text-red-700">
                      Available for urgent, last-minute childcare needs
                    </p>
                  </div>
                </div>
                <Switch
                  id="emergency"
                  checked={emergencyAvailable}
                  onCheckedChange={setEmergencyAvailable}
                />
              </div>

              {/* Save Button */}
              <div className="pt-4">
                <Button 
                  onClick={handleSave}
                  disabled={quickAvailabilityMutation.isPending}
                  className="w-full"
                  size="lg"
                >
                  {quickAvailabilityMutation.isPending ? (
                    <>
                      <div className="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full mr-2" />
                      Updating...
                    </>
                  ) : (
                    <>
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Save Availability Settings
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Help & Tips */}
          <Card>
            <CardHeader>
              <CardTitle>How Quick Availability Works</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="p-3 bg-blue-50 rounded-lg">
                  <h4 className="font-medium text-blue-900 mb-1">Instant Notifications</h4>
                  <p className="text-sm text-blue-800">
                    When you toggle on, parents searching for immediate childcare will see you as available
                  </p>
                </div>

                <div className="p-3 bg-green-50 rounded-lg">
                  <h4 className="font-medium text-green-900 mb-1">Priority Matching</h4>
                  <p className="text-sm text-green-800">
                    Available sitters get priority in search results and receive booking requests first
                  </p>
                </div>

                <div className="p-3 bg-purple-50 rounded-lg">
                  <h4 className="font-medium text-purple-900 mb-1">Flexible Control</h4>
                  <p className="text-sm text-purple-800">
                    Turn availability on/off anytime. Changes take effect immediately
                  </p>
                </div>

                <div className="p-3 bg-yellow-50 rounded-lg">
                  <h4 className="font-medium text-yellow-900 mb-1">Emergency Bookings</h4>
                  <p className="text-sm text-yellow-800">
                    Emergency availability helps families in urgent situations and often pays premium rates
                  </p>
                </div>
              </div>

              <div className="pt-4 border-t">
                <h4 className="font-medium mb-2">Pro Tips:</h4>
                <ul className="space-y-1 text-sm text-gray-600">
                  <li>• Turn on weekend availability for date night bookings</li>
                  <li>• Emergency availability can earn 20-30% premium rates</li>
                  <li>• Update regularly to maximise booking opportunities</li>
                  <li>• Use alongside your weekly schedule for best results</li>
                </ul>
              </div>

              <div className="pt-4">
                <Button 
                  variant="outline" 
                  onClick={() => navigate('/availability')}
                  className="w-full"
                >
                  <Calendar className="h-4 w-4 mr-2" />
                  Set Weekly Schedule
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}