import React, { useEffect } from 'react';
import { useLocation, useRoute } from 'wouter';
import { useAuth } from '@/contexts/AuthContext';
import AuthForm from '@/components/auth/AuthForm';

const Auth: React.FC = () => {
  const [, params] = useRoute('/auth');
  const [location, navigate] = useLocation();
  const { user, checkOnboardingStatus } = useAuth();

  // If user is already logged in, redirect based on role
  useEffect(() => {
    const checkUserStatus = async () => {
      if (user) {
        // Redirect based on user role - skip onboarding for parents
        switch(user.role) {
          case 'parent':
            navigate('/dashboard');
            break;
          case 'sitter':
            navigate('/sitter/dashboard');
            break;
          case 'admin':
            navigate('/admin');
            break;
          default:
            navigate('/dashboard');
        }
      }
    };
    
    checkUserStatus();
  }, [user, navigate]);
  
  if (user) {
    return null; // Don't render anything while redirecting
  }

  return <AuthForm />;
};

export default Auth;
