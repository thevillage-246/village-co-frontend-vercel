import { useLocation } from 'wouter';
import GiftSitter from '@/components/parents/GiftSitter';

export default function GiftSitterPage() {
  const [location] = useLocation();
  const urlParams = new URLSearchParams(location.split('?')[1] || '');
  const sitterId = urlParams.get('sitterId');
  const sitterName = urlParams.get('sitterName');

  return (
    <div className="container mx-auto px-4 py-8">
      <GiftSitter sitterId={sitterId || undefined} sitterName={sitterName || undefined} />
    </div>
  );
}