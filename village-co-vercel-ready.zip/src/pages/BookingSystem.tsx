import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Calendar, Clock, DollarSign, User } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface Subscription {
  id: string;
  user_id: string;
  included_hours: number;
  hours_used_this_period: number;
  overage_rate: number;
  renewal_date: string;
  stripe_customer_id?: string;
}

interface BookingData {
  sitter_id: string;
  start_time: string;
  end_time: string;
  hours: number;
  covered_by_subscription: boolean;
  overage_charge: number;
}

export default function BookingSystem() {
  const [selectedSitter, setSelectedSitter] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [bookingResult, setBookingResult] = useState<any>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Get user's subscription details
  const { data: subscription, isLoading: subscriptionLoading } = useQuery({
    queryKey: ['/api/subscription/status'],
    retry: false,
  });

  // Get available sitters
  const { data: sitters, isLoading: sittersLoading } = useQuery({
    queryKey: ['/api/sitters/available'],
    retry: false,
  });

  // Calculate booking hours and costs
  const calculateBooking = () => {
    if (!startTime || !endTime) return null;
    
    const start = new Date(startTime);
    const end = new Date(endTime);
    const hours = (end.getTime() - start.getTime()) / (1000 * 60 * 60);
    
    if (hours <= 0) return null;
    
    const remainingHours = subscription 
      ? Math.max(0, subscription.included_hours - subscription.hours_used_this_period)
      : 0;
    
    const coveredHours = Math.min(hours, remainingHours);
    const overageHours = Math.max(0, hours - remainingHours);
    const overageCharge = overageHours * (subscription?.overage_rate || 25);
    
    return {
      totalHours: hours,
      coveredHours,
      overageHours,
      overageCharge,
      coveredBySubscription: overageHours === 0
    };
  };

  const bookingCalc = calculateBooking();

  // Create booking mutation
  const createBookingMutation = useMutation({
    mutationFn: async (bookingData: any) => {
      const response = await apiRequest('POST', '/api/bookings/create-subscription-booking', bookingData);
      return response.json();
    },
    onSuccess: (data) => {
      setBookingResult(data);
      toast({
        title: "Booking Created",
        description: `Successfully booked ${bookingCalc?.totalHours} hours with ${selectedSitter}`,
      });
      queryClient.invalidateQueries({ queryKey: ['/api/subscription/status'] });
    },
    onError: (error: any) => {
      toast({
        title: "Booking Failed",
        description: error.message || "Unable to create booking",
        variant: "destructive",
      });
    },
  });

  const handleCreateBooking = () => {
    if (!selectedSitter || !startTime || !endTime || !bookingCalc) {
      toast({
        title: "Missing Information",
        description: "Please fill in all booking details",
        variant: "destructive",
      });
      return;
    }

    const bookingData = {
      sitter_id: selectedSitter,
      start_time: startTime,
      end_time: endTime,
      hours: bookingCalc.totalHours,
      covered_by_subscription: bookingCalc.coveredBySubscription,
      overage_charge: bookingCalc.overageCharge
    };

    createBookingMutation.mutate(bookingData);
  };

  if (subscriptionLoading) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="h-32 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Subscription Booking System</h1>
        <p className="text-gray-600">Book babysitting with your subscription hours</p>
      </div>

      {/* Subscription Status */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <DollarSign className="w-5 h-5" />
            Your Subscription
          </CardTitle>
        </CardHeader>
        <CardContent>
          {subscription ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-eucalyptus">{subscription.included_hours}</div>
                <div className="text-sm text-gray-600">Monthly Hours</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-wine">
                  {subscription.included_hours - subscription.hours_used_this_period}
                </div>
                <div className="text-sm text-gray-600">Hours Remaining</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-rose">${subscription.overage_rate}</div>
                <div className="text-sm text-gray-600">Per Overage Hour</div>
              </div>
            </div>
          ) : (
            <Alert>
              <AlertDescription>
                No active subscription found. Please contact support to set up your subscription.
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {/* Booking Form */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Create New Booking
          </CardTitle>
          <CardDescription>
            Schedule your babysitting session using subscription hours
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="sitter">Select Sitter</Label>
              <select
                id="sitter"
                value={selectedSitter}
                onChange={(e) => setSelectedSitter(e.target.value)}
                className="w-full mt-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-eucalyptus"
              >
                <option value="">Choose a sitter...</option>
                <option value="sitter_1">Sarah - $25/hour</option>
                <option value="sitter_2">Emma - $28/hour</option>
                <option value="sitter_3">Jessica - $30/hour</option>
              </select>
            </div>

            <div>
              <Label htmlFor="start">Start Time</Label>
              <Input
                id="start"
                type="datetime-local"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
              />
            </div>

            <div>
              <Label htmlFor="end">End Time</Label>
              <Input
                id="end"
                type="datetime-local"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
              />
            </div>
          </div>

          {/* Booking Calculation */}
          {bookingCalc && (
            <Card className="bg-gray-50">
              <CardContent className="pt-6">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                  <div>
                    <div className="text-lg font-semibold">{bookingCalc.totalHours}h</div>
                    <div className="text-xs text-gray-600">Total Time</div>
                  </div>
                  <div>
                    <div className="text-lg font-semibold text-eucalyptus">{bookingCalc.coveredHours}h</div>
                    <div className="text-xs text-gray-600">Covered by Subscription</div>
                  </div>
                  <div>
                    <div className="text-lg font-semibold text-wine">{bookingCalc.overageHours}h</div>
                    <div className="text-xs text-gray-600">Overage Hours</div>
                  </div>
                  <div>
                    <div className="text-lg font-semibold text-rose">${bookingCalc.overageCharge.toFixed(2)}</div>
                    <div className="text-xs text-gray-600">Additional Cost</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          <Button 
            onClick={handleCreateBooking}
            disabled={!selectedSitter || !startTime || !endTime || createBookingMutation.isPending}
            className="w-full"
          >
            {createBookingMutation.isPending ? 'Creating Booking...' : 'Book Now'}
          </Button>
        </CardContent>
      </Card>

      {/* Booking Result */}
      {bookingResult && (
        <Card className="border-green-200 bg-green-50">
          <CardHeader>
            <CardTitle className="text-green-800">Booking Confirmed!</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm">
              <div><strong>Booking ID:</strong> {bookingResult.booking_id}</div>
              <div><strong>Hours Used:</strong> {bookingResult.hours_used}</div>
              <div><strong>Covered by Subscription:</strong> {bookingResult.covered_by_subscription ? 'Yes' : 'No'}</div>
              {bookingResult.overage_charge > 0 && (
                <div><strong>Additional Charge:</strong> ${bookingResult.overage_charge}</div>
              )}
              <div className="mt-3 p-3 bg-green-100 rounded">
                {bookingResult.message}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}