import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { Download, RefreshCw, Calendar, CreditCard, User, Clock, AlertCircle, CheckCircle, ExternalLink } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

interface StripeTransaction {
  id: number;
  stripeTransactionId: string;
  customerEmail: string;
  amount: number;
  currency: string;
  status: string;
  description: string;
  stripeCreatedAt: string;
  syncedAt: string;
  linkedUser: {
    id: number;
    firstName: string;
    lastName: string;
    email: string;
  } | null;
  linkedBooking: {
    id: number;
    startTime: string;
    endTime: string;
    status: string;
  } | null;
  amountDisplayed: string;
  receiptUrl?: string;
  refunded?: boolean;
}

interface TransactionSummary {
  totalTransactions: number;
  totalAmount: number;
  linkedToUsers: number;
  linkedToBookings: number;
  unlinkedTransactions: number;
  successfulTransactions: number;
  refundedTransactions: number;
}

interface SyncResult {
  success: boolean;
  message: string;
  details: {
    total: number;
    synced: number;
    linked: number;
    errors: string[];
    summary: {
      newTransactions: number;
      existingTransactions: number;
      linkedToUsers: number;
      unlinkedTransactions: number;
    };
  };
}

export default function AdminStripeSync() {
  const [syncResult, setSyncResult] = useState<SyncResult | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch transactions
  const { data: transactionData, isLoading: isLoadingTransactions, refetch } = useQuery({
    queryKey: ['/api/admin/stripe/transactions'],
    retry: false,
  });

  const transactions = transactionData?.transactions || [];
  const summary = transactionData?.summary || {} as TransactionSummary;

  // Historical sync mutation
  const historicalSyncMutation = useMutation({
    mutationFn: () => apiRequest('POST', '/api/admin/stripe/sync-historical'),
    onSuccess: (data) => {
      setSyncResult(data);
      toast({
        title: "Historical Sync Complete",
        description: `Synced ${data.details.synced} transactions from November 2024 to present`,
      });
      refetch();
    },
    onError: (error) => {
      toast({
        title: "Sync Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Recent sync mutation
  const recentSyncMutation = useMutation({
    mutationFn: () => apiRequest('POST', '/api/admin/stripe/sync-recent'),
    onSuccess: (data) => {
      setSyncResult(data);
      toast({
        title: "Recent Sync Complete",
        description: `Synced ${data.details.synced} recent transactions`,
      });
      refetch();
    },
    onError: (error) => {
      toast({
        title: "Sync Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const formatCurrency = (amountInCents: number, currency: string = 'NZD') => {
    return `$${(amountInCents / 100).toFixed(2)} ${currency.toUpperCase()}`;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-NZ', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'succeeded': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'failed': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Stripe Transaction Sync</h1>
          <p className="text-muted-foreground">
            Import and manage historical payment data from Stripe
          </p>
        </div>
      </div>

      {/* Sync Controls */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Historical Sync
            </CardTitle>
            <CardDescription>
              Import all transactions from November 2024 to present
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              onClick={() => historicalSyncMutation.mutate()}
              disabled={historicalSyncMutation.isPending}
              className="w-full"
            >
              {historicalSyncMutation.isPending ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Syncing Historical Data...
                </>
              ) : (
                <>
                  <Download className="w-4 h-4 mr-2" />
                  Sync Historical Transactions
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5" />
              Recent Sync
            </CardTitle>
            <CardDescription>
              Import the latest 100 transactions from Stripe
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              onClick={() => recentSyncMutation.mutate()}
              disabled={recentSyncMutation.isPending}
              variant="outline"
              className="w-full"
            >
              {recentSyncMutation.isPending ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Syncing Recent Data...
                </>
              ) : (
                <>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Sync Recent Transactions
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Sync Results */}
      {syncResult && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {syncResult.success ? (
                <CheckCircle className="w-5 h-5 text-green-600" />
              ) : (
                <AlertCircle className="w-5 h-5 text-red-600" />
              )}
              Sync Results
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">{syncResult.message}</p>
            
            <div className="grid gap-2 md:grid-cols-4">
              <div className="bg-blue-50 p-3 rounded-lg">
                <div className="text-2xl font-bold text-blue-700">{syncResult.details.total}</div>
                <div className="text-sm text-blue-600">Total Found</div>
              </div>
              <div className="bg-green-50 p-3 rounded-lg">
                <div className="text-2xl font-bold text-green-700">{syncResult.details.synced}</div>
                <div className="text-sm text-green-600">Successfully Synced</div>
              </div>
              <div className="bg-purple-50 p-3 rounded-lg">
                <div className="text-2xl font-bold text-purple-700">{syncResult.details.linked}</div>
                <div className="text-sm text-purple-600">Linked to Users</div>
              </div>
              <div className="bg-orange-50 p-3 rounded-lg">
                <div className="text-2xl font-bold text-orange-700">{syncResult.details.summary.unlinkedTransactions}</div>
                <div className="text-sm text-orange-600">Unlinked</div>
              </div>
            </div>

            {syncResult.details.errors.length > 0 && (
              <div className="bg-red-50 p-4 rounded-lg">
                <h4 className="font-medium text-red-800 mb-2">Errors:</h4>
                <ul className="text-sm text-red-700 space-y-1">
                  {syncResult.details.errors.map((error, index) => (
                    <li key={index}>• {error}</li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Transaction Summary */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CreditCard className="w-5 h-5" />
            Transaction Summary
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <div className="text-center">
              <div className="text-2xl font-bold">{summary.totalTransactions || 0}</div>
              <div className="text-sm text-muted-foreground">Total Transactions</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">{formatCurrency(summary.totalAmount || 0)}</div>
              <div className="text-sm text-muted-foreground">Total Value</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">{summary.linkedToUsers || 0}</div>
              <div className="text-sm text-muted-foreground">Linked to Users</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold">{summary.unlinkedTransactions || 0}</div>
              <div className="text-sm text-muted-foreground">Unlinked</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Transaction List */}
      <Card>
        <CardHeader>
          <CardTitle>Transaction History</CardTitle>
          <CardDescription>
            Recent Stripe transactions imported to the platform
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoadingTransactions ? (
            <div className="flex items-center justify-center py-8">
              <RefreshCw className="w-6 h-6 animate-spin mr-2" />
              Loading transactions...
            </div>
          ) : transactions.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <CreditCard className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No transactions found. Sync from Stripe to get started.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {transactions.slice(0, 20).map((transaction: StripeTransaction) => (
                <div key={transaction.id} className="border rounded-lg p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="font-medium">{transaction.amountDisplayed}</div>
                      <Badge className={getStatusColor(transaction.status)}>
                        {transaction.status}
                      </Badge>
                      {transaction.refunded && (
                        <Badge variant="destructive">Refunded</Badge>
                      )}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {formatDate(transaction.stripeCreatedAt)}
                    </div>
                  </div>

                  <div className="grid gap-2 md:grid-cols-2">
                    <div>
                      <div className="text-sm font-medium">Customer</div>
                      <div className="text-sm text-muted-foreground">{transaction.customerEmail}</div>
                    </div>
                    <div>
                      <div className="text-sm font-medium">Transaction ID</div>
                      <div className="text-xs text-muted-foreground font-mono">
                        {transaction.stripeTransactionId}
                      </div>
                    </div>
                  </div>

                  {transaction.description && (
                    <div>
                      <div className="text-sm font-medium">Description</div>
                      <div className="text-sm text-muted-foreground">{transaction.description}</div>
                    </div>
                  )}

                  <div className="flex items-center gap-4 text-sm">
                    {transaction.linkedUser ? (
                      <div className="flex items-center gap-1 text-green-600">
                        <User className="w-4 h-4" />
                        Linked to {transaction.linkedUser.firstName} {transaction.linkedUser.lastName}
                      </div>
                    ) : (
                      <div className="flex items-center gap-1 text-orange-600">
                        <AlertCircle className="w-4 h-4" />
                        Not linked to user
                      </div>
                    )}

                    {transaction.linkedBooking && (
                      <div className="flex items-center gap-1 text-blue-600">
                        <Calendar className="w-4 h-4" />
                        Booking #{transaction.linkedBooking.id}
                      </div>
                    )}

                    {transaction.receiptUrl && (
                      <a
                        href={transaction.receiptUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1 text-purple-600 hover:text-purple-800"
                      >
                        <ExternalLink className="w-4 h-4" />
                        Receipt
                      </a>
                    )}
                  </div>
                </div>
              ))}

              {transactions.length > 20 && (
                <div className="text-center py-4 text-muted-foreground">
                  Showing first 20 of {transactions.length} transactions
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}