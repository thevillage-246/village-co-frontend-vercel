import React, { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { Message } from '@shared/schema';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { User, Video, Copy } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useLocation } from 'wouter';

const MessagesPage = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [recipients, setRecipients] = useState<any[]>([]);
  const [selectedRecipientId, setSelectedRecipientId] = useState<number | null>(null);
  const { user } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  
  useEffect(() => {
    const fetchContactsAndHandleSitter = async () => {
      if (!user) return;

      // Check if there's a sitterId in the URL query for direct messaging from sitter cards
      const params = new URLSearchParams(window.location.search);
      const sitterId = params.get('sitterId');
      
      if (sitterId) {
        try {
          // Fetch the specific sitter's information
          const sitterIdNum = parseInt(sitterId, 10);
          if (!isNaN(sitterIdNum)) {
            const response = await fetch(`/api/users/${sitterIdNum}`);
            if (response.ok) {
              const sitterUser = await response.json();
              
              // Create contact list with the specific sitter and Admin
              const sitterContact = {
                id: sitterUser.id,
                firstName: sitterUser.firstName,
                lastName: sitterUser.lastName,
                email: sitterUser.email,
                role: sitterUser.role
              };
              
              const adminContact = {
                id: 15, // Use actual admin user ID (Sophia)
                firstName: 'Admin',
                lastName: '',
                email: 'soph@thevillageco.nz',
                role: 'admin'
              };
              
              setRecipients([sitterContact, adminContact]);
              setSelectedRecipientId(sitterIdNum); // Select the sitter
              return;
            }
          }
        } catch (error) {
          console.error('Error fetching sitter information:', error);
        }
      }
      
      // Default case: only show Admin
      const adminContact = {
        id: 15, // Use actual admin user ID (Sophia)
        firstName: 'Admin',
        lastName: '',
        email: 'soph@thevillageco.nz',
        role: 'admin'
      };
      
      setRecipients([adminContact]);
      setSelectedRecipientId(15);
    };

    fetchContactsAndHandleSitter();
  }, [user, toast]);

  useEffect(() => {
    // Fetch messages for the selected recipient
    const fetchMessages = async () => {
      if (!user?.id || !selectedRecipientId) return;
      
      try {
        const response = await fetch(`/api/messages/thread/${user.id}/${selectedRecipientId}`);
        const messagesData = await response.json();
        setMessages(Array.isArray(messagesData) ? messagesData : []);
      } catch (error) {
        console.error('Error fetching messages:', error);
        toast({
          title: 'Error',
          description: 'Could not load messages. Please try again later.',
          variant: 'destructive',
        });
      }
    };

    if (selectedRecipientId) {
      fetchMessages();
      
      // Mark messages as read
      fetch(`/api/messages/direct/read`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          recipientId: user?.id,
          senderId: selectedRecipientId
        })
      }).catch(err => console.error('Error marking messages as read:', err));
    }
    
    // Set up WebSocket listener for new messages
    const setupWebSocket = () => {
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/ws`;
      const socket = new WebSocket(wsUrl);
      
      socket.onopen = () => {
        // Authenticate with the WebSocket server
        if (user?.id) {
          socket.send(JSON.stringify({
            type: 'auth',
            userId: user.id
          }));
        }
      };
      
      socket.onmessage = (event) => {
        const data = JSON.parse(event.data);
        
        // Handle different types of messages
        if (data.type === 'new_message' && 
            ((data.message.senderId === user?.id && data.message.recipientId === selectedRecipientId) ||
             (data.message.senderId === selectedRecipientId && data.message.recipientId === user?.id))) {
          setMessages(prev => Array.isArray(prev) ? [...prev, data.message] : [data.message]);
        }
      };
      
      socket.onerror = (error) => {
        console.error('WebSocket error:', error);
      };
      
      return socket;
    };
    
    const socket = setupWebSocket();
    
    return () => {
      if (socket.readyState === WebSocket.OPEN) {
        socket.close();
      }
    };
  }, [selectedRecipientId, user, toast]);

  const sendMessage = async () => {
    if (!newMessage.trim() || !selectedRecipientId || !user) return;
    
    try {
      const response = await fetch('/api/messages/direct', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          senderId: user.id,
          recipientId: selectedRecipientId,
          content: newMessage,
        }),
      });
      
      if (response.ok) {
        setNewMessage('');
      } else {
        const errorData = await response.json().catch(() => ({}));
        const errorMessage = errorData.message || 'Could not send message. Please try again.';
        
        toast({
          title: response.status === 403 ? 'Messaging Restricted' : 'Error',
          description: errorMessage,
          variant: 'destructive',
        });
      }
    } catch (error) {
      console.error('Error sending message:', error);
      toast({
        title: 'Error',
        description: 'Could not send message. Please try again.',
        variant: 'destructive',
      });
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const getRecipientName = (id: number) => {
    const recipient = recipients.find(r => r.id === id);
    if (!recipient) return 'User';
    
    // Clean up firstName if it looks like a username (contains numbers, @, or is too long)
    let displayName = recipient.firstName;
    if (displayName && (displayName.includes('@') || /\d/.test(displayName) || displayName.length > 15)) {
      // Extract proper name from username-like string
      const cleanName = displayName.replace(/\d+/g, '').split(/[._@]/)[0];
      displayName = cleanName.charAt(0).toUpperCase() + cleanName.slice(1).toLowerCase();
    }
    
    return displayName || 'User';
  };

  // Generate unique Jitsi room URL
  const generateJitsiRoomUrl = () => {
    if (!user?.id || !selectedRecipientId) return '';
    
    // Create a unique room identifier using both user IDs
    const roomId = `thevillageco_${Math.min(user.id, selectedRecipientId)}_${Math.max(user.id, selectedRecipientId)}`;
    return `https://meet.jit.si/${roomId}`;
  };

  // Start video call
  const startVideoCall = async () => {
    const jitsiUrl = generateJitsiRoomUrl();
    if (!jitsiUrl) return;

    // Open Jitsi in new tab
    window.open(jitsiUrl, '_blank');

    // Send video call link in the chat
    try {
      const videoCallMessage = `🎥 Video call started: ${jitsiUrl}`;
      
      const response = await fetch('/api/messages/direct', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          senderId: user?.id,
          recipientId: selectedRecipientId,
          content: videoCallMessage,
        }),
      });

      if (!response.ok) {
        toast({
          title: 'Warning',
          description: 'Video call started but could not send link in chat',
          variant: 'default',
        });
      }
    } catch (error) {
      console.error('Error sending video call message:', error);
    }

    toast({
      title: 'Video Call Started',
      description: 'Opening Jitsi Meet in a new tab',
    });
  };

  // Copy video call link to clipboard
  const copyVideoCallLink = async () => {
    const jitsiUrl = generateJitsiRoomUrl();
    if (!jitsiUrl) return;

    try {
      await navigator.clipboard.writeText(jitsiUrl);
      toast({
        title: 'Link Copied',
        description: 'Video call link copied to clipboard',
      });
    } catch (error) {
      console.error('Error copying to clipboard:', error);
      toast({
        title: 'Error',
        description: 'Could not copy link to clipboard',
        variant: 'destructive',
      });
    }
  };

  // Show login prompt if user is not authenticated
  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-bone to-brushed-pink flex items-center justify-center">
        <Card className="w-full max-w-md border-village-wine/20 shadow-lg bg-white">
          <CardContent className="p-8 text-center">
            <h1 className="text-2xl font-bold text-village-wine mb-4">Messages</h1>
            <p className="text-gray-600 mb-6">
              Please log in to access your messages and connect with your Village Co. community.
            </p>
            <Button 
              onClick={() => navigate('/login')}
              className="bg-village-wine hover:bg-village-wine/90 text-white"
            >
              Log In to Continue
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-bone to-brushed-pink">
      <div className="container py-8 max-w-6xl">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-village-wine mb-4">Stay Connected</h1>
          <p className="text-xl text-almond-frost max-w-3xl mx-auto">
            Build trust and communicate safely with your Village Co. community
          </p>
        </div>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {/* Recipients list */}
        <Card className="md:col-span-1 border-village-wine/20 shadow-lg bg-white">
          <CardContent className="p-4">
            <h2 className="font-semibold mb-3 text-village-wine">Your Village</h2>
            <div className="space-y-2">
              {recipients.length > 0 ? (
                recipients.map(recipient => (
                  <div 
                    key={recipient.id}
                    className={`flex items-center gap-2 p-2 rounded-md cursor-pointer hover:bg-village-wine/10 ${selectedRecipientId === recipient.id ? 'bg-village-wine/20' : ''}`}
                    onClick={() => setSelectedRecipientId(recipient.id)}
                  >
                    <div className="bg-village-wine text-white rounded-full p-2">
                      <User size={16} />
                    </div>
                    <div>
                      <span className="font-medium">{getRecipientName(recipient.id)}</span>
                      <p className="text-xs text-gray-500">{recipient.role}</p>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-gray-500 text-center">No contacts available</p>
              )}
            </div>
          </CardContent>
        </Card>
        
        {/* Chat area */}
        <Card className="md:col-span-3 border-village-wine/20 shadow-lg bg-white">
          <CardContent className="p-4 flex flex-col h-[600px]">
            {selectedRecipientId ? (
              <>
                <div className="border-b border-village-wine/20 pb-3 mb-3">
                  <div className="flex items-center justify-between">
                    <h2 className="font-semibold text-village-wine">Chat with {getRecipientName(selectedRecipientId)}</h2>
                    <div className="flex flex-col items-end gap-1">
                      <p className="text-xs text-gray-600 italic max-w-xs text-right">
                        Prefer to talk face-to-face? Arrange a quick video call to chat before your first sit.
                      </p>
                      <div className="flex gap-2">
                        <Button
                          onClick={copyVideoCallLink}
                          variant="outline"
                          size="sm"
                          className="text-xs"
                          title="Copy video call link"
                        >
                          <Copy size={14} className="mr-1" />
                          Copy Link
                        </Button>
                        <Button
                          onClick={startVideoCall}
                          variant="default"
                          size="sm"
                          className="bg-village-wine hover:bg-village-wine/90 text-white"
                          title="Start video call with Jitsi Meet"
                        >
                          <Video size={14} className="mr-1" />
                          Video Call
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="flex-1 overflow-y-auto mb-4 pr-2">
                  {messages.length > 0 ? (
                    <div className="space-y-3">
                      {messages.map(msg => (
                        <div 
                          key={msg.id} 
                          className={`flex ${msg.senderId === user?.id ? 'justify-end' : 'justify-start'}`}
                        >
                          <div 
                            className={`max-w-[75%] px-3 py-2 rounded-lg ${
                              msg.senderId === user?.id 
                                ? 'bg-village-wine text-white rounded-tr-none' 
                                : 'bg-brushed-pink rounded-tl-none'
                            }`}
                          >
                            <div className="whitespace-pre-wrap break-words">{msg.content}</div>
                            <div className={`text-xs mt-1 ${msg.senderId === user?.id ? 'text-primary-foreground/70' : 'text-gray-500'}`}>
                              {new Date(msg.createdAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="h-full flex items-center justify-center">
                      <p className="text-gray-500">No messages yet. Start the conversation!</p>
                    </div>
                  )}
                </div>
                
                <div className="flex gap-2">
                  <Input
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyDown={handleKeyPress}
                    placeholder="Type your message..."
                    className="flex-1"
                  />
                  <Button onClick={sendMessage} disabled={!newMessage.trim()}>
                    Send
                  </Button>
                </div>
              </>
            ) : (
              <div className="h-full flex items-center justify-center">
                <div className="text-center">
                  <h3 className="text-xl font-medium mb-2 text-village-wine">Welcome to Your Village Messaging</h3>
                  <p className="text-almond-frost mb-4">Select a contact to start building trust through conversation</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      </div>
    </div>
  );
};

export default MessagesPage;