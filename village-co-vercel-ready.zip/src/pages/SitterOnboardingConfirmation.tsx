import React from 'react';
import { Button } from '@/components/ui/button';
import { useLocation } from 'wouter';
import { CheckCircle2, Calendar, Mail, Heart, Users } from 'lucide-react';

export default function SitterOnboardingConfirmation() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-br from-linen via-brushed-pink/20 to-white">
      <div className="container mx-auto px-4 py-12 max-w-2xl">
        <div className="bg-white rounded-2xl shadow-xl p-8 border border-brushed-pink/20 text-center">
          {/* Success Icon */}
          <div className="flex justify-center mb-6">
            <div className="bg-gradient-to-br from-eucalyptus to-green-500 p-4 rounded-full">
              <CheckCircle2 className="h-12 w-12 text-white" />
            </div>
          </div>

          {/* Main Heading */}
          <h1 className="text-4xl font-bold text-village-wine mb-4">
            🎉 You're nearly there!
          </h1>
          
          <p className="text-xl text-taupe mb-8 leading-relaxed">
            We've received your application. Our team will reach out to schedule a short video call — where we'll get to know you better and answer any questions.
          </p>

          {/* Status Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {/* Verification Status */}
            <div className="bg-gradient-to-br from-village-wine/5 to-rose/5 rounded-xl p-6 border border-village-wine/20">
              <div className="flex items-center justify-center mb-4">
                <div className="bg-village-wine/10 p-3 rounded-full">
                  <Users className="h-6 w-6 text-village-wine" />
                </div>
              </div>
              <h3 className="font-semibold text-village-wine mb-2">Verification in Progress</h3>
              <p className="text-sm text-gray-600">
                We're reviewing your application and will be in touch within 24 hours
              </p>
            </div>

            {/* Next Steps */}
            <div className="bg-gradient-to-br from-eucalyptus/5 to-green-100/5 rounded-xl p-6 border border-eucalyptus/20">
              <div className="flex items-center justify-center mb-4">
                <div className="bg-eucalyptus/10 p-3 rounded-full">
                  <Calendar className="h-6 w-6 text-eucalyptus" />
                </div>
              </div>
              <h3 className="font-semibold text-eucalyptus mb-2">Welcome Call Coming</h3>
              <p className="text-sm text-gray-600">
                Once verified, you'll be visible to families and ready to start babysitting
              </p>
            </div>
          </div>

          {/* What's Next Section */}
          <div className="bg-gray-50 rounded-xl p-6 mb-8 text-left">
            <h3 className="font-semibold text-village-wine mb-4 flex items-center">
              <Mail className="h-5 w-5 mr-2" />
              What happens next?
            </h3>
            <ul className="space-y-3 text-sm text-gray-700">
              <li className="flex items-start">
                <div className="bg-village-wine rounded-full w-2 h-2 mt-2 mr-3 flex-shrink-0"></div>
                <span><strong>Check your inbox</strong> for next steps and welcome information</span>
              </li>
              <li className="flex items-start">
                <div className="bg-village-wine rounded-full w-2 h-2 mt-2 mr-3 flex-shrink-0"></div>
                <span><strong>We'll call your references</strong> to verify your background</span>
              </li>
              <li className="flex items-start">
                <div className="bg-village-wine rounded-full w-2 h-2 mt-2 mr-3 flex-shrink-0"></div>
                <span><strong>Schedule a welcome call</strong> with our team (15 minutes max)</span>
              </li>
              <li className="flex items-start">
                <div className="bg-eucalyptus rounded-full w-2 h-2 mt-2 mr-3 flex-shrink-0"></div>
                <span><strong>Start receiving booking requests</strong> from families in your area</span>
              </li>
            </ul>
          </div>

          {/* Trust Badge */}
          <div className="bg-gradient-to-r from-village-wine/5 to-rose/5 rounded-xl p-6 border border-village-wine/10 mb-8">
            <div className="flex items-center justify-center gap-3">
              <Heart className="h-6 w-6 text-village-wine" />
              <div className="text-left">
                <p className="font-semibold text-village-wine">Welcome to The Village Co. family</p>
                <p className="text-sm text-gray-600">You're about to join a trusted community of amazing sitters</p>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-4">
            <Button 
              onClick={() => setLocation('/')}
              className="w-full h-12 bg-gradient-to-r from-village-wine to-rose hover:from-village-wine/90 hover:to-rose/90 text-white font-semibold rounded-xl transition-all duration-300"
            >
              Return to Homepage
            </Button>
            
            <Button 
              variant="outline"
              onClick={() => setLocation('/support')}
              className="w-full h-12 border-2 border-village-wine text-village-wine hover:bg-village-wine hover:text-white rounded-xl"
            >
              Have Questions? Contact Support
            </Button>
          </div>

          {/* Contact Info */}
          <div className="mt-8 pt-6 border-t border-gray-200">
            <p className="text-sm text-gray-600">
              Questions? Email us at <a href="mailto:hello@thevillageco.nz" className="text-village-wine font-semibold hover:underline">hello@thevillageco.nz</a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}