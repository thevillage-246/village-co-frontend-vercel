import React from 'react';
import VerificationTest from '@/components/testing/VerificationTest';
import { Container } from '@/components/ui/container';
import { Button } from '@/components/ui/button';
import { Link } from 'wouter';
import { ArrowLeft } from 'lucide-react';

export default function VerificationTestPage() {
  return (
    <Container className="py-8">
      <div className="flex flex-col space-y-6">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" asChild>
            <Link to="/">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Home
            </Link>
          </Button>
          <h1 className="text-3xl font-bold tracking-tight">Verification Test</h1>
        </div>

        <p className="text-muted-foreground">
          This page allows you to test the Veriff verification integration. 
          Click the button below to test the verification API endpoints.
        </p>

        <VerificationTest />
      </div>
    </Container>
  );
}