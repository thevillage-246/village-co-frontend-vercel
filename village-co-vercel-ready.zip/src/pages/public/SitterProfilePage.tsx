import React from 'react';
import { useParams } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { ArrowLeft, Star, MapPin, Clock, BadgeCheck, MessageCircle } from 'lucide-react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';

const SitterProfilePage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const sitterId = parseInt(id!);

  // Fetch sitter profile data
  const { data: sitter, isLoading, error } = useQuery({
    queryKey: [`/api/sitters/${sitterId}`],
    enabled: !!sitterId,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-linen">
        <div className="container mx-auto px-4 py-8">
          <div className="flex justify-center items-center min-h-[60vh]">
            <div className="animate-spin h-8 w-8 border-4 border-village-wine border-t-transparent rounded-full"></div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !sitter) {
    return (
      <div className="min-h-screen bg-linen">
        <div className="container mx-auto px-4 py-8">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/find-sitter')}
            className="mb-6"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Find Sitter
          </Button>
          
          <Card>
            <CardContent className="p-8 text-center">
              <h2 className="text-xl font-semibold mb-2">Sitter Not Found</h2>
              <p className="text-muted-foreground mb-4">
                The sitter profile you're looking for could not be found.
              </p>
              <Button onClick={() => navigate('/find-sitter')}>
                Browse All Sitters
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const getDisplayName = () => {
    // Show first name + last initial for privacy 
    if (sitter.firstName && sitter.lastName) {
      const lastInitial = sitter.lastName.charAt(0).toUpperCase();
      return `${sitter.firstName} ${lastInitial}.`;
    }
    if (sitter.firstName) {
      return sitter.firstName;
    }
    if (sitter.full_name) {
      const nameParts = sitter.full_name.split(' ');
      if (nameParts.length > 1) {
        const lastInitial = nameParts[nameParts.length - 1].charAt(0).toUpperCase();
        return `${nameParts[0]} ${lastInitial}.`;
      }
      return nameParts[0]; // Take only first name if no last name
    }
    if (sitter.title) {
      return sitter.title.split(' - ')[0] || sitter.title.split(' ')[0];
    }
    return 'Village Sitter';
  };

  const getInitials = () => {
    const name = getDisplayName();
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const profileImage = sitter.photoUrl || sitter.avatar_url || sitter.profileImage || 
    (sitter.image_urls && sitter.image_urls[0]);

  const hourlyRate = sitter.hourlyRate || sitter.hourly_rate || 
    (sitter.price_amount ? (sitter.price_amount / 100).toString() : '25');

  const location = sitter.location || 'Hamilton, Waikato';
  const experience = sitter.experience || '3+ years';
  const bio = sitter.bio || sitter.description || 'Experienced and reliable babysitter ready to help your family.';

  return (
    <div className="min-h-screen bg-linen">
      <div className="container mx-auto px-4 py-8">
        <Button 
          variant="ghost" 
          onClick={() => navigate('/find-sitter')}
          className="mb-6"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Find Sitter
        </Button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Profile Card */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader className="text-center">
                <Avatar className="h-32 w-32 mx-auto mb-4">
                  <AvatarImage 
                    src={profileImage} 
                    alt={getDisplayName()}
                    className="object-cover"
                  />
                  <AvatarFallback className="bg-village-wine text-white text-2xl">
                    {getInitials()}
                  </AvatarFallback>
                </Avatar>
                
                <CardTitle className="text-2xl text-village-wine">
                  {getDisplayName()}
                </CardTitle>
                
                <div className="flex items-center justify-center gap-2 text-muted-foreground">
                  <MapPin className="h-4 w-4" />
                  <span>{location}</span>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Rate */}
                <div className="text-center">
                  <div className="text-3xl font-bold text-village-wine mb-1">
                    {hourlyRate}/hr
                  </div>
                  <p className="text-sm text-muted-foreground">Hourly rate</p>
                </div>

                {/* Rating */}
                {sitter.rating && (
                  <div className="flex items-center justify-center gap-2">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span className="font-medium">{sitter.rating.toFixed(1)}</span>
                    <span className="text-muted-foreground">
                      ({sitter.reviewCount || 0} reviews)
                    </span>
                  </div>
                )}

                {/* Verification Badges */}
                <div className="space-y-2">
                  {sitter.villageVerified && (
                    <div className="flex items-center gap-2 text-sm">
                      <BadgeCheck className="h-4 w-4 text-green-500" />
                      <span>Village Verified</span>
                    </div>
                  )}
                  {sitter.backgroundChecked && (
                    <div className="flex items-center gap-2 text-sm">
                      <BadgeCheck className="h-4 w-4 text-green-500" />
                      <span>Background Checked</span>
                    </div>
                  )}
                  {sitter.firstAidCertified && (
                    <div className="flex items-center gap-2 text-sm">
                      <BadgeCheck className="h-4 w-4 text-green-500" />
                      <span>First Aid Certified</span>
                    </div>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="space-y-2">
                  <Button 
                    className="w-full bg-village-wine hover:bg-village-wine/90"
                    onClick={() => navigate(`/book-sitter/${sitterId}`)}
                  >
                    Book Now
                  </Button>
                  <Button 
                    variant="outline" 
                    className="w-full border-village-wine text-village-wine hover:bg-village-wine/10"
                    onClick={() => navigate(`/messages?sitterId=${sitterId}`)}
                  >
                    <MessageCircle className="h-4 w-4 mr-2" />
                    Send Message
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Profile Details */}
          <div className="lg:col-span-2 space-y-6">
            {/* About */}
            <Card>
              <CardHeader>
                <CardTitle>About {getDisplayName().split(' ')[0]}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 leading-relaxed">{bio}</p>
              </CardContent>
            </Card>

            {/* Experience & Qualifications */}
            <Card>
              <CardHeader>
                <CardTitle>Experience & Qualifications</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-village-wine" />
                  <span className="font-medium">Experience:</span>
                  <span>{experience}</span>
                </div>

                {/* Qualifications */}
                {sitter.qualifications && sitter.qualifications.length > 0 && (
                  <div>
                    <p className="font-medium mb-2">Qualifications:</p>
                    <div className="flex flex-wrap gap-2">
                      {sitter.qualifications.map((qual: string, index: number) => (
                        <Badge key={index} variant="secondary">
                          {qual}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Skills from public_data */}
                {sitter.public_data?.qualifications && (
                  <div>
                    <p className="font-medium mb-2">Additional Qualifications:</p>
                    <div className="flex flex-wrap gap-2">
                      {sitter.public_data.qualifications.map((qual: string, index: number) => (
                        <Badge key={index} variant="secondary">
                          {qual}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Reviews */}
            {sitter.reviews && sitter.reviews.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Reviews</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {sitter.reviews.slice(0, 3).map((review: any, index: number) => (
                    <div key={index} className="border-b border-gray-200 last:border-b-0 pb-4 last:pb-0">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="flex items-center">
                          {[...Array(5)].map((_, i) => (
                            <Star 
                              key={i} 
                              className={`h-4 w-4 ${
                                i < review.rating 
                                  ? 'fill-yellow-400 text-yellow-400' 
                                  : 'text-gray-300'
                              }`} 
                            />
                          ))}
                        </div>
                        <span className="font-medium">{review.authorName || 'Village Parent'}</span>
                      </div>
                      <p className="text-gray-700">{review.content}</p>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SitterProfilePage;