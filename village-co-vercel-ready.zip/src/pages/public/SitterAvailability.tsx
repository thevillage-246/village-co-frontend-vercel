import React from 'react';
import { useParams } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Helmet } from 'react-helmet';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Clock, Calendar as CalendarIcon, User, Star, MapPin } from 'lucide-react';
import { cn } from '@/lib/utils';

const DAYS_OF_WEEK = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

interface Availability {
  id: number;
  sitterId: number;
  dayOfWeek: number;
  startTime: string;
  endTime: string;
}

interface SitterProfile {
  id: number;
  userId: number;
  bio: string;
  experience: string;
  hourlyRate: number;
  qualifications: string[];
  location: string;
  user: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
  };
  reviews: {
    rating: number;
    count: number;
  };
}

const SitterAvailability: React.FC = () => {
  const { sitterId } = useParams<{ sitterId: string }>();

  // Fetch sitter profile
  const { data: sitterProfile, isLoading: loadingProfile } = useQuery({
    queryKey: [`/api/sitters/${sitterId}/profile`],
    enabled: !!sitterId,
  });

  // Fetch availability
  const { data: availability, isLoading: loadingAvailability } = useQuery({
    queryKey: [`/api/sitters/${sitterId}/availability`],
    enabled: !!sitterId,
  });

  if (loadingProfile || loadingAvailability) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="container mx-auto px-4 py-8">
          <div className="flex justify-center items-center min-h-[60vh]">
            <div className="animate-spin h-8 w-8 border-4 border-village-wine border-t-transparent rounded-full"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!sitterProfile) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="container mx-auto px-4 py-8">
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-lg font-medium mb-2">Sitter Not Found</p>
              <p className="text-muted-foreground">This sitter profile could not be found.</p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Group availability by day of week
  const availabilityByDay: Record<number, Availability[]> = {};
  if (availability) {
    availability.forEach((slot: Availability) => {
      if (!availabilityByDay[slot.dayOfWeek]) {
        availabilityByDay[slot.dayOfWeek] = [];
      }
      availabilityByDay[slot.dayOfWeek].push(slot);
    });
  }

  // Format time helper
  const formatTime = (time24: string) => {
    const [hour, minute] = time24.split(':').map(Number);
    const period = hour >= 12 ? 'PM' : 'AM';
    const hour12 = hour % 12 || 12;
    return `${hour12}:${minute.toString().padStart(2, '0')} ${period}`;
  };

  const fullName = `${sitterProfile.user.firstName} ${sitterProfile.user.lastName}`;

  return (
    <>
      <Helmet>
        <title>{`${fullName}'s Availability | The Village Co.`}</title>
        <meta name="description" content={`View ${fullName}'s weekly availability for babysitting bookings through The Village Co.`} />
      </Helmet>
      
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-village-wine text-white py-8">
          <div className="container mx-auto px-4">
            <div className="text-center">
              <h1 className="text-3xl font-bold mb-2">{fullName}'s Availability</h1>
              <p className="text-brushed-pink">Book trusted babysitting through The Village Co.</p>
            </div>
          </div>
        </div>

        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Sitter Profile */}
            <div className="lg:col-span-1">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <User className="h-5 w-5 text-village-wine" />
                    About {sitterProfile.user.firstName}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Rating */}
                  {sitterProfile.reviews.count > 0 && (
                    <div className="flex items-center gap-2">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                      <span className="font-medium">{sitterProfile.reviews.rating.toFixed(1)}</span>
                      <span className="text-muted-foreground">({sitterProfile.reviews.count} reviews)</span>
                    </div>
                  )}

                  {/* Rate */}
                  <div className="text-2xl font-bold text-village-wine">
                    ${sitterProfile.hourlyRate}/hour
                  </div>

                  {/* Location */}
                  {sitterProfile.location && (
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="h-4 w-4" />
                      <span>{sitterProfile.location}</span>
                    </div>
                  )}

                  {/* Bio */}
                  {sitterProfile.bio && (
                    <div>
                      <h4 className="font-medium mb-2">About</h4>
                      <p className="text-sm text-muted-foreground">{sitterProfile.bio}</p>
                    </div>
                  )}

                  {/* Experience */}
                  {sitterProfile.experience && (
                    <div>
                      <h4 className="font-medium mb-2">Experience</h4>
                      <p className="text-sm text-muted-foreground">{sitterProfile.experience}</p>
                    </div>
                  )}

                  {/* Qualifications */}
                  {sitterProfile.qualifications && sitterProfile.qualifications.length > 0 && (
                    <div>
                      <h4 className="font-medium mb-2">Qualifications</h4>
                      <div className="flex flex-wrap gap-2">
                        {sitterProfile.qualifications.map((qualification, index) => (
                          <Badge key={index} variant="outline" className="border-village-wine text-village-wine">
                            {qualification}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Book Now CTA */}
                  <div className="pt-4">
                    <Button 
                      className="w-full bg-village-wine hover:bg-village-wine/90"
                      onClick={() => window.location.href = `/book/${sitterId}`}
                    >
                      Book {sitterProfile.user.firstName}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Availability */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CalendarIcon className="h-5 w-5 text-village-wine" />
                    Weekly Availability
                  </CardTitle>
                  <CardDescription>
                    {sitterProfile.user.firstName}'s available times for babysitting bookings
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {!availability || availability.length === 0 ? (
                    <div className="text-center p-8 text-muted-foreground">
                      <CalendarIcon className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                      <p className="text-lg font-medium mb-2">No availability set</p>
                      <p className="text-sm">{sitterProfile.user.firstName} is currently updating their availability.</p>
                    </div>
                  ) : (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Day</TableHead>
                          <TableHead>Available Hours</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {DAYS_OF_WEEK.map((day, index) => (
                          <TableRow key={index} className={cn(index % 2 === 0 ? 'bg-muted/50' : '')}>
                            <TableCell className="font-medium">{day}</TableCell>
                            <TableCell>
                              {availabilityByDay[index] && availabilityByDay[index].length > 0 ? (
                                <div className="flex flex-wrap gap-2">
                                  {availabilityByDay[index].map((slot) => {
                                    const startFormatted = formatTime(slot.startTime);
                                    const endFormatted = formatTime(slot.endTime);
                                    
                                    return (
                                      <Badge 
                                        key={slot.id} 
                                        variant="outline"
                                        className="border-brushed-pink bg-brushed-pink/20 text-village-wine"
                                      >
                                        {startFormatted} - {endFormatted}
                                      </Badge>
                                    );
                                  })}
                                </div>
                              ) : (
                                <span className="text-muted-foreground text-sm">Not available</span>
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </CardContent>
              </Card>

              {/* Contact Information */}
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle>Ready to Book?</CardTitle>
                  <CardDescription>
                    Join The Village Co. to book {sitterProfile.user.firstName} for your babysitting needs
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Button 
                      className="bg-village-wine hover:bg-village-wine/90"
                      onClick={() => window.location.href = `/book/${sitterId}`}
                    >
                      Book Now
                    </Button>
                    <Button 
                      variant="outline"
                      className="border-village-wine text-village-wine hover:bg-village-wine/10"
                      onClick={() => window.location.href = '/signup'}
                    >
                      Join The Village Co.
                    </Button>
                  </div>
                  <div className="mt-4 p-4 bg-brushed-pink/20 rounded-lg">
                    <p className="text-sm text-village-wine">
                      <strong>The Village Co.</strong> provides secure, trusted babysitting connections with verified sitters, 
                      safe payment processing, and peace of mind for Kiwi families.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default SitterAvailability;