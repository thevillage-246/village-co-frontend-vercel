import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "./contexts/AuthContext";
import ErrorBoundary from "@/components/ErrorBoundary";

import ProtectedRoute from "./components/auth/ProtectedRoute";
import RoleProtectedRoute from "./components/auth/RoleProtectedRoute";
import MainLayout from "./components/layout/MainLayout";
import { NotificationManager } from "@/components/ui/NotificationManager";
import InstallBanner from "@/components/ui/InstallBanner";
import NotificationSubscriber from "@/components/ui/NotificationSubscriber";
import FloatingIntercomButton from "@/components/support/FloatingIntercomButton";
import GrowSurfTracker from "@/components/tracking/GrowSurfTracker";
import { crossPlatformManager } from "@/utils/crossPlatformSync";
import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { SessionExpiryHandler, NetworkStatusIndicator, BookingFlowProtection } from "@/components/EdgeCaseHandler";
import SEO, { SEOConfigs } from "@/components/SEO";
import { PWAWrapper } from "@/components/PWAWrapper";
import { SitterOnboardingGuard } from "@/components/auth/SitterOnboardingGuard";
import Home from "./pages/Home";
import WelcomeRealUsers from "./pages/WelcomeRealUsers";
import Auth from "./pages/Auth";
import Login from "./pages/auth/Login";
import Register from "./pages/auth/Register";
import Confirmation from "./pages/auth/Confirmation";
import Dashboard from "./pages/Dashboard";
import ParentDashboard from "./pages/parent/Dashboard";
import SitterDashboard from "./pages/sitter/Dashboard";
import SitterProfile from "./pages/sitter/SitterProfile";
import NewSitterProfile from "./pages/sitter/NewSitterProfile";
import SitterOnboardingChecklist from "./components/sitters/SitterOnboardingChecklist";
import SitterStripeConnect from "./pages/sitter/StripeConnect";
import SitterVerification from "./pages/sitter/Verification";
import AdminDashboard from "./pages/admin/Dashboard";
import SitterApprovals from "./pages/admin/SitterApprovals";
import SitterPhotoManager from "./pages/admin/SitterPhotoManager";
import ConciergeRequests from "./pages/admin/ConciergeRequests";
import PolicySettings from "./pages/admin/PolicySettings";
import LateFeeManagement from "./pages/admin/LateFeeManagement";
import BadgeManagement from "./pages/admin/BadgeManagement";
import EventManagement from "./pages/admin/EventManagement";
import StripeTransactions from "./pages/admin/StripeTransactions";
import AdminStripeSync from "./pages/AdminStripeSync";
import SecurityDashboardPage from "./pages/admin/SecurityDashboard";
import AccountSettings from "./pages/AccountSettings";
import AdminNotify from "./pages/admin/AdminNotify";
import AdminInactive from "./pages/admin/AdminInactive";
import AdminInactiveParents from "./pages/admin/AdminInactiveParents";
import AdminAtRisk from "./pages/admin/AdminAtRisk";
import NotificationDashboard from "./pages/admin/NotificationDashboard";
import AdminNotificationsPage from "./pages/admin/Notifications";
import BookingReviewPage from "./pages/admin/BookingReviewPage";

import VillageMetrics from "./pages/admin/VillageMetrics";
import AdminSitterUpload from "./pages/AdminSitterUpload";
import AdminParentUpload from "./pages/admin/AdminParentUpload";
import AuthenticationLogsPage from "./pages/admin/AuthenticationLogs";
import LoopsContentManager from "./pages/admin/LoopsContentManager";
import HubSpotDataManager from "./pages/admin/HubSpotDataManager";
import SMSDashboardPage from "./pages/admin/SMSDashboardPage";
import AdminSitters from "./pages/admin/Sitters";
import FindSitterPage from "./pages/parent/FindSitter";
import InstantBooking from "./pages/parent/InstantBooking";
import UnifiedBooking from "./pages/parent/UnifiedBooking";
import BookRecurringPage from "./pages/parent/BookRecurring";
import BookingSummary from "./pages/parent/BookingSummary";
import BookingFeedback from "./pages/parent/BookingFeedback";
import MapSearch from "./pages/parent/MapSearch";
import SitterProfilePage from "./pages/public/SitterProfilePage";
import Onboarding from "./pages/Onboarding";
import SitterOnboarding from "./pages/SitterOnboarding";
import SitterOnboardingConfirmation from "./pages/SitterOnboardingConfirmation";
import SitterOnboardingThankYou from "./pages/SitterOnboardingThankYou";
import Availability from "./pages/sitter/Availability";
import QuickAvailability from "./pages/sitter/QuickAvailability";
import BookingRequests from "./pages/sitter/BookingRequests";
import AllTransactions from "./pages/sitter/AllTransactions";
import AllReviews from "./pages/sitter/AllReviews";
import TrustedPartnerAccess from "./pages/TrustedPartnerAccess";
import Booking from "./pages/Booking";
import Profile from "./pages/Profile";
import Messages from "./pages/Messages";
import PostSignupRedirect from "./pages/PostSignupRedirect";
import Book from "./pages/Book";
import BookingConfirmed from "./pages/BookingConfirmed";
import BookingConfirmationPage from "./pages/BookingConfirmationPage";
import ReviewBooking from "./pages/ReviewBooking";
import Support from "./pages/Support";
import Terms from "./pages/Terms";
import Privacy from "./pages/Privacy";
import LocationDemo from "./pages/LocationDemo";
import FAQ from "./pages/FAQ";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import TermsOfService from "./pages/TermsOfService";
import { FAQPage, TermsOfServicePage, PrivacyPolicyPage } from "./pages/StaticPages";
import NotFound from "./pages/not-found";
import BetaWelcome from "./pages/BetaWelcome";
import BetaRoadmap from "./pages/BetaRoadmap";
import MobileAppTest from "./pages/MobileAppTest";
import ParentEmergencyContactsPage from "./pages/ParentEmergencyContactsPage";
import TestLogin from "./pages/TestLogin";
import SimpleTestLogin from "./pages/SimpleTestLogin";
import ApiLogin from "./pages/api-login";

import DirectAdminRoute from "./pages/DirectAdminRoute";
import StandaloneAdminPage from "./pages/StandaloneAdminPage";
import VerificationTestPage from "./pages/VerificationTestPage";
import AcceptInvite from "./pages/AcceptInvite";
import GiftSitterPage from "./pages/GiftSitter";
import PlanMyNightPage from "./pages/PlanMyNight";
import MatchingVisualization from "./pages/MatchingVisualization";
import CreateProfile from "./pages/CreateProfile";
import EditProfile from "./pages/EditProfile";
import Hotels from "./pages/Hotels";
import BookHotelSitter from "./pages/BookHotelSitter";
import Employers from "./pages/Employers";
import PlansPerks from "./pages/PlansPerks";
import Events from "./pages/Events";
import PlansEvents from "./pages/PlansEvents";
import BookingSystem from "./pages/BookingSystem";
import EditParentProfile from "./pages/EditParentProfile";
import ProfileRepair from "./pages/ProfileRepair";
import Subscribe from "./pages/Subscribe";
import AIAssistantPage from "./pages/AIAssistantPage";
import ParentVerificationPage from "./pages/parent/Verification";
import ParentPaymentPage from "./pages/parent/Payment";
import PaymentSuccess from "./pages/PaymentSuccess";
import ExtendBooking from "./pages/ExtendBooking";
import TipSitter from "./pages/TipSitter";
import { USER_ROLES } from "@shared/schema";

// Sitter onboarding step pages (old numbered steps)
import SitterOnboardingStep1 from "./pages/sitter/onboarding/Step1";
import SitterOnboardingStep2 from "./pages/sitter/onboarding/Step2";
import SitterOnboardingStep3 from "./pages/sitter/onboarding/Step3";
import SitterOnboardingStep4 from "./pages/sitter/onboarding/Step4";

// New descriptive onboarding pages  
import SitterOnboardingProfile from "./pages/sitter/onboarding/Profile";
import SitterOnboardingQualifications from "./pages/sitter/onboarding/Qualifications";
import SitterOnboardingAvailability from "./pages/sitter/onboarding/Availability";
import SitterOnboardingMedia from "./pages/sitter/onboarding/Media";
import SitterOnboardingPayout from "./pages/sitter/onboarding/Payout";
import SitterOnboardingVerify from "./pages/sitter/onboarding/Verify";
import SitterOnboardingDone from "./pages/sitter/onboarding/Done";

// Profile redirect component - moved inside Router to be within AuthProvider
function ProfileRedirect() {
  const { user } = useAuth();
  const [, navigate] = useLocation();
  
  useEffect(() => {
    if (user) {
      // Redirect to the user's own profile
      navigate(`/profile/${user.id}`);
    } else {
      // Not authenticated, redirect to login
      navigate('/login');
    }
  }, [user, navigate]);
  
  return <div>Redirecting to your profile...</div>;
}

function Router() {
  return (
    <SitterOnboardingGuard>
      <Switch>
      <Route path="/" component={Home} />
      <Route path="/welcome" component={WelcomeRealUsers} />
      <Route path="/auth" component={Auth} />
      <Route path="/login" component={Login} />

      <Route path="/register" component={Register} />
      <Route path="/signup" component={Register} />
      <Route path="/auth/confirmation" component={Confirmation} />
      <Route path="/accept-invite/:token" component={AcceptInvite} />
      <Route path="/onboarding" component={Onboarding} />
      <Route path="/sitter-onboarding" component={SitterOnboarding} />
      <Route path="/sitter-onboarding-confirmation" component={SitterOnboardingConfirmation} />
      <Route path="/sitter-onboarding-thank-you" component={SitterOnboardingThankYou} />
      
      {/* Sitter Onboarding Checklist - accessible to sitters only */}
      <Route path="/sitter/onboarding">
        {() => (
          <RoleProtectedRoute allowedRoles={['sitter']}>
            <SitterOnboardingChecklist />
          </RoleProtectedRoute>
        )}
      </Route>

      {/* 7-Step Descriptive Sitter Onboarding Route Group */}
      <Route path="/sitter/onboarding/profile">
        {() => (
          <RoleProtectedRoute allowedRoles={['sitter']}>
            <SitterOnboardingProfile />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/sitter/onboarding/qualifications">
        {() => (
          <RoleProtectedRoute allowedRoles={['sitter']}>
            <SitterOnboardingQualifications />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/sitter/onboarding/availability">
        {() => (
          <RoleProtectedRoute allowedRoles={['sitter']}>
            <SitterOnboardingAvailability />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/sitter/onboarding/media">
        {() => (
          <RoleProtectedRoute allowedRoles={['sitter']}>
            <SitterOnboardingMedia />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/sitter/onboarding/payout">
        {() => (
          <RoleProtectedRoute allowedRoles={['sitter']}>
            <SitterOnboardingPayout />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/sitter/onboarding/verify">
        {() => (
          <RoleProtectedRoute allowedRoles={['sitter']}>
            <SitterOnboardingVerify />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/sitter/onboarding/done">
        {() => (
          <RoleProtectedRoute allowedRoles={['sitter']}>
            <SitterOnboardingDone />
          </RoleProtectedRoute>
        )}
      </Route>

      {/* Legacy numbered onboarding steps - kept for compatibility */}
      <Route path="/sitter/onboarding/step-1">
        {() => (
          <RoleProtectedRoute allowedRoles={['sitter']}>
            <SitterOnboardingStep1 />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/sitter/onboarding/step-2">
        {() => (
          <RoleProtectedRoute allowedRoles={['sitter']}>
            <SitterOnboardingStep2 />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/sitter/onboarding/step-3">
        {() => (
          <RoleProtectedRoute allowedRoles={['sitter']}>
            <SitterOnboardingStep3 />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/sitter/onboarding/step-4">
        {() => (
          <RoleProtectedRoute allowedRoles={['sitter']}>
            <SitterOnboardingStep4 />
          </RoleProtectedRoute>
        )}
      </Route>

      {/* New 7-Step Onboarding with Descriptive Routes */}
      <Route path="/sitter/onboarding/profile">
        {() => (
          <RoleProtectedRoute allowedRoles={['sitter']}>
            <SitterOnboardingProfile />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/sitter/onboarding/qualifications">
        {() => (
          <RoleProtectedRoute allowedRoles={['sitter']}>
            <SitterOnboardingQualifications />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/sitter/onboarding/availability">
        {() => (
          <RoleProtectedRoute allowedRoles={['sitter']}>
            <SitterOnboardingAvailability />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/sitter/onboarding/media">
        {() => (
          <RoleProtectedRoute allowedRoles={['sitter']}>
            <SitterOnboardingMedia />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/sitter/onboarding/payout">
        {() => (
          <RoleProtectedRoute allowedRoles={['sitter']}>
            <SitterOnboardingPayout />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/sitter/onboarding/verify">
        {() => (
          <RoleProtectedRoute allowedRoles={['sitter']}>
            <SitterOnboardingVerify />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/sitter/onboarding/done">
        {() => (
          <RoleProtectedRoute allowedRoles={['sitter']}>
            <SitterOnboardingDone />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/sitter/stripe-connect">
        {() => (
          <RoleProtectedRoute allowedRoles={['sitter']}>
            <SitterStripeConnect />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/sitter/verification">
        {() => (
          <RoleProtectedRoute allowedRoles={['sitter']}>
            <SitterVerification />
          </RoleProtectedRoute>
        )}
      </Route>
      
      {/* Dashboard redirect */}
      <Route path="/dashboard" component={Dashboard} />
      
      {/* Parent routes - protected for parents only */}
      <Route path="/parent">
        {() => {
          // Redirect to parent dashboard
          window.location.href = '/parent/dashboard';
          return null;
        }}
      </Route>
      <Route path="/parent/onboarding">
        {() => {
          // Redirect to main onboarding page
          window.location.href = '/onboarding';
          return null;
        }}
      </Route>
      <Route path="/parent/dashboard">
        {() => (
          <RoleProtectedRoute allowedRoles={['parent']}>
            <ParentDashboard />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/edit-parent-profile">
        {() => {
          // Redirect to unified parent edit profile page
          window.location.href = '/parent/edit-profile';
          return null;
        }}
      </Route>
      <Route path="/edit-profile">
        {() => (
          <ProtectedRoute>
            <EditProfile />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/profile-repair">
        {() => (
          <RoleProtectedRoute allowedRoles={['parent']}>
            <ProfileRepair />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/create-profile">
        {() => (
          <RoleProtectedRoute allowedRoles={['parent']}>
            <CreateProfile />
          </RoleProtectedRoute>
        )}
      </Route>
      {/* Main booking route - unified experience */}
      <Route path="/book">
        {() => (
          <RoleProtectedRoute allowedRoles={['parent']} fallbackMessage="This page is for parents looking to book sitters.">
            <UnifiedBooking />
          </RoleProtectedRoute>
        )}
      </Route>
      {/* Find Sitter route with favorites section */}
      <Route path="/find-sitter">
        {() => (
          <RoleProtectedRoute allowedRoles={['parent']} fallbackMessage="This page is for parents looking to find sitters.">
            <FindSitterPage />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/instant-booking">
        {() => (
          <RoleProtectedRoute allowedRoles={['parent']}>
            <InstantBooking />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/book-recurring">
        {() => (
          <RoleProtectedRoute allowedRoles={['parent']}>
            <BookRecurringPage />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/booking/:id/extend">
        {(params) => (
          <RoleProtectedRoute allowedRoles={['parent']}>
            <ExtendBooking />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/booking/:id/tip">
        {(params) => (
          <RoleProtectedRoute allowedRoles={['parent']}>
            <TipSitter />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/plan-my-night">
        {() => (
          <RoleProtectedRoute allowedRoles={['parent']}>
            <PlanMyNightPage />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/gift-sitter">
        {() => (
          <RoleProtectedRoute allowedRoles={['parent']}>
            <GiftSitterPage />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/plans-perks">
        {() => (
          <RoleProtectedRoute allowedRoles={['parent']}>
            <PlansPerks />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/events">
        {() => (
          <RoleProtectedRoute allowedRoles={['parent']}>
            <Events />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/plans-events" component={PlansEvents} />
      <Route path="/booking-system" component={BookingSystem} />
      <Route path="/booking-system-demo" component={BookingSystem} />
      <Route path="/map-search/:location?">
        {() => (
          <RoleProtectedRoute allowedRoles={['parent']}>
            <MapSearch />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/booking-summary/:id">
        {() => (
          <RoleProtectedRoute allowedRoles={['parent']}>
            <BookingSummary />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/parent/booking/:id/feedback">
        {() => (
          <RoleProtectedRoute allowedRoles={['parent']}>
            <BookingFeedback />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/parent/:parentId/emergency-contacts">
        {() => (
          <RoleProtectedRoute allowedRoles={['parent']}>
            <ParentEmergencyContactsPage />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/parent/edit-profile">
        {() => (
          <RoleProtectedRoute allowedRoles={['parent']}>
            <EditParentProfile />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/parent/verification">
        {() => (
          <RoleProtectedRoute allowedRoles={['parent']}>
            <ParentVerificationPage />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/parent/payment">
        {() => (
          <RoleProtectedRoute allowedRoles={['parent']}>
            <ParentPaymentPage />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/payment-success" component={PaymentSuccess} />
      
      {/* Sitter routes */}
      <Route path="/sitter/dashboard">
        {() => (
          <RoleProtectedRoute allowedRoles={['sitter']}>
            <SitterDashboard />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/sitter/profile">
        {() => (
          <RoleProtectedRoute allowedRoles={['sitter']}>
            <NewSitterProfile />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/sitter/edit-profile">
        {() => (
          <RoleProtectedRoute allowedRoles={['sitter']}>
            <EditProfile />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/sitter/transactions">
        {() => (
          <RoleProtectedRoute allowedRoles={['sitter']}>
            <AllTransactions />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/sitter/reviews">
        {() => (
          <RoleProtectedRoute allowedRoles={['sitter']}>
            <AllReviews />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/sitter/verification">
        {() => (
          <RoleProtectedRoute allowedRoles={['sitter']}>
            <SitterVerification />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/sitter/stripe-connect">
        {() => (
          <RoleProtectedRoute allowedRoles={['sitter']}>
            <SitterStripeConnect />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/sitter/profile">
        {() => (
          <RoleProtectedRoute allowedRoles={['sitter']}>
            <SitterProfile />
          </RoleProtectedRoute>
        )}
      </Route>
      <Route path="/sitter/:id" component={SitterProfilePage} />
      <Route path="/sitter-dashboard" component={SitterDashboard} /> {/* legacy route */}
      <Route path="/availability" component={Availability} />
      <Route path="/quick-availability" component={QuickAvailability} />
      <Route path="/booking-requests" component={BookingRequests} />
      
      {/* Admin routes - protected with admin role check */}
      <Route path="/admin">
        {() => (
          <ProtectedRoute requiredRoles={[USER_ROLES.ADMIN]}>
            <AdminDashboard />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin/notifications">
        {() => (
          <ProtectedRoute requiredRoles={[USER_ROLES.ADMIN]}>
            <AdminNotificationsPage />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin/sitter-approvals">
        {() => (
          <ProtectedRoute requiredRoles={[USER_ROLES.ADMIN]}>
            <SitterApprovals />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin/sitter-photos">
        {() => (
          <ProtectedRoute requiredRoles={[USER_ROLES.ADMIN]}>
            <SitterPhotoManager />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin/concierge-requests">
        {() => (
          <ProtectedRoute requiredRoles={[USER_ROLES.ADMIN]}>
            <ConciergeRequests />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin/policy-settings">
        {() => (
          <ProtectedRoute requiredRoles={[USER_ROLES.ADMIN]}>
            <PolicySettings />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin/stripe-transactions">
        {() => (
          <ProtectedRoute requiredRoles={[USER_ROLES.ADMIN]}>
            <StripeTransactions />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin/stripe-sync">
        {() => (
          <ProtectedRoute requiredRoles={[USER_ROLES.ADMIN]}>
            <AdminStripeSync />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin/late-fee-management">
        {() => (
          <ProtectedRoute requiredRoles={[USER_ROLES.ADMIN]}>
            <LateFeeManagement />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin/badge-management">
        {() => (
          <ProtectedRoute requiredRoles={[USER_ROLES.ADMIN]}>
            <BadgeManagement />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin/event-management">
        {() => (
          <ProtectedRoute requiredRoles={[USER_ROLES.ADMIN]}>
            <EventManagement />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin-dashboard">
        {() => (
          <ProtectedRoute requiredRoles={[USER_ROLES.ADMIN]}>
            <NotificationDashboard />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin-notify">
        {() => (
          <ProtectedRoute requiredRoles={[USER_ROLES.ADMIN]}>
            <AdminNotify />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin-inactive">
        {() => (
          <ProtectedRoute requiredRoles={[USER_ROLES.ADMIN]}>
            <AdminInactive />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin-inactive-parents">
        {() => (
          <ProtectedRoute requiredRoles={[USER_ROLES.ADMIN]}>
            <AdminInactiveParents />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin-at-risk">
        {() => (
          <ProtectedRoute requiredRoles={[USER_ROLES.ADMIN]}>
            <AdminAtRisk />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin/booking-review">
        {() => (
          <ProtectedRoute requiredRoles={[USER_ROLES.ADMIN]}>
            <BookingReviewPage />
          </ProtectedRoute>
        )}
      </Route>

      <Route path="/admin/village-metrics">
        {() => (
          <ProtectedRoute requiredRoles={[USER_ROLES.ADMIN]}>
            <VillageMetrics />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin/security">
        {() => (
          <ProtectedRoute requiredRoles={[USER_ROLES.ADMIN]}>
            <SecurityDashboardPage />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin/upload-sitters">
        {() => (
          <ProtectedRoute requiredRoles={[USER_ROLES.ADMIN]}>
            <AdminSitterUpload />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin/upload-parents">
        {() => (
          <ProtectedRoute requiredRoles={[USER_ROLES.ADMIN]}>
            <AdminParentUpload />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin/auth-logs">
        {() => (
          <ProtectedRoute requiredRoles={[USER_ROLES.ADMIN]}>
            <AuthenticationLogsPage />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin/loops-content">
        {() => (
          <ProtectedRoute requiredRoles={[USER_ROLES.ADMIN]}>
            <LoopsContentManager />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin/events">
        {() => (
          <ProtectedRoute requiredRoles={[USER_ROLES.ADMIN]}>
            <EventManagement />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin/hubspot-data">
        {() => (
          <ProtectedRoute requiredRoles={[USER_ROLES.ADMIN]}>
            <HubSpotDataManager />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin/sms-dashboard">
        {() => (
          <ProtectedRoute requiredRoles={[USER_ROLES.ADMIN]}>
            <SMSDashboardPage />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/admin/sitters">
        {() => (
          <ProtectedRoute requiredRoles={[USER_ROLES.ADMIN]}>
            <AdminSitters />
          </ProtectedRoute>
        )}
      </Route>
      
      {/* Shared routes */}
      <Route path="/booking/:id" component={Booking} />
      <Route path="/profile/:id" component={Profile} />
      <Route path="/profile">
        {() => (
          <ProtectedRoute>
            <ProfileRedirect />
          </ProtectedRoute>
        )}
      </Route>
      <Route path="/messages" component={Messages} />

      <Route path="/book-sitter/:id" component={Book} />
      <Route path="/book/:sitterId" component={Book} />
      <Route path="/onboarding" component={Onboarding} />
      <Route path="/post-signup" component={PostSignupRedirect} />
      <Route path="/booking-confirmed" component={BookingConfirmed} />
      <Route path="/booking-confirmation/:id" component={BookingConfirmationPage} />
      <Route path="/review/:bookingId" component={ReviewBooking} />
      <Route path="/support" component={Support} />
      <Route path="/terms" component={TermsOfService} />
      <Route path="/privacy" component={PrivacyPolicy} />
      <Route path="/account-settings" component={AccountSettings} />

      
      {/* Hotel and Employer Services */}
      <Route path="/hotels" component={Hotels} />
      <Route path="/employers" component={Employers} />
      
      {/* External redirect pages */}
      <Route path="/subscribe" component={Subscribe} />
      <Route path="/faq" component={FAQ} />
      <Route path="/terms-of-service" component={TermsOfService} />
      <Route path="/privacy-policy" component={PrivacyPolicy} />
      <Route path="/old-terms" component={Terms} />
      <Route path="/old-privacy" component={Privacy} />
      
      {/* Beta Launch Pages */}
      <Route path="/beta-welcome" component={BetaWelcome} />
      <Route path="/roadmap" component={BetaRoadmap} />
      
      {/* Mobile App Test Page */}
      <Route path="/mobile-app-test" component={MobileAppTest} />
      
      {/* Trusted Partner Access - No authentication required, validates via token */}
      <Route path="/trusted-partner/:token" component={TrustedPartnerAccess} />
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
    </SitterOnboardingGuard>
  );
}

function App() {
  // Initialize cross-platform connectivity on app load
  useEffect(() => {
    crossPlatformManager.initialize();
  }, []);

  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <AuthProvider>
            <PWAWrapper>
              <MainLayout>
                <Router />
              </MainLayout>
              <NotificationManager />
              <InstallBanner />
              <NotificationSubscriber />
              <FloatingIntercomButton />
              <GrowSurfTracker />
              <SessionExpiryHandler />
              <NetworkStatusIndicator />
              <BookingFlowProtection />
              <Toaster />
            </PWAWrapper>
          </AuthProvider>
        </TooltipProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  );
}

export default App;
