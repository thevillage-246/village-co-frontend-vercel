import React from 'react';
import { Switch, Route } from 'wouter';

const TestRouter: React.FC = () => {
  return (
    <div>
      <Switch>
        <Route path="/">
          <div>Home Route</div>
        </Route>
        <Route path="/test">
          <div>Test Route</div>
        </Route>
      </Switch>
    </div>
  );
};

export default TestRouter;