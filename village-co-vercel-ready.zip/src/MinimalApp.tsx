import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "./contexts/AuthContext";
import MainLayout from "./components/layout/MainLayout";
import { Switch, Route } from "wouter";
import Home from "./pages/Home";

// Minimal test app to identify failing components
export default function MinimalApp() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <MainLayout>
            <div style={{ padding: '20px', fontFamily: 'Arial, sans-serif' }}>
              <h1 style={{ color: '#6b3e4b' }}>The Village Co. - Testing Router</h1>
              <p>Testing core providers with basic routing...</p>
              
              <Switch>
                <Route path="/" component={Home} />
                <Route>
                  <div style={{ marginTop: '20px', padding: '15px', backgroundColor: '#f0f8ff', border: '1px solid #ccc' }}>
                    <h3>All Components Working:</h3>
                    <ul>
                      <li>✅ QueryClient: Working</li>
                      <li>✅ TooltipProvider: Working</li>
                      <li>✅ AuthProvider: Working</li>
                      <li>✅ MainLayout: Working</li>
                      <li>✅ Router: Working</li>
                    </ul>
                  </div>
                </Route>
              </Switch>
            </div>
          </MainLayout>
          <Toaster />
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}