import React, { useState } from 'react';
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "./contexts/AuthContext";
import { Toaster } from "@/components/ui/toaster";

// Simple app for component testing without dependencies
function SimpleApp() {
  const [activeTest, setActiveTest] = useState<string>('none');
  
  return (
    <div style={{ 
      padding: '20px', 
      maxWidth: '800px', 
      margin: '0 auto', 
      fontFamily: 'sans-serif', 
      backgroundColor: 'white',
      minHeight: '100vh'
    }}>
      <h1 style={{ color: '#6B3E4B' }}>Village Co - Simple Test App</h1>
      <p>This app provides simplified components for testing without complex dependencies.</p>
      
      <div style={{ 
        padding: '15px',
        background: '#f7f7f7',
        border: '1px solid #ddd',
        borderRadius: '4px',
        marginTop: '20px',
        marginBottom: '20px'
      }}>
        <h2>Component Tests</h2>
        <p>Click on each test to render a simple version of that component.</p>
      </div>
      
      <div style={{ display: 'flex', gap: '10px', marginBottom: '20px', flexWrap: 'wrap' }}>
        {['none', 'navbar', 'layout', 'page'].map(test => (
          <button
            key={test}
            onClick={() => setActiveTest(test)}
            style={{
              padding: '8px 16px',
              background: activeTest === test ? '#6B3E4B' : '#eee',
              color: activeTest === test ? 'white' : '#333',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            Test: {test}
          </button>
        ))}
      </div>
      
      <div style={{ 
        padding: '20px', 
        border: '1px solid #ddd', 
        borderRadius: '4px',
        backgroundColor: '#fafafa', 
        minHeight: '300px'
      }}>
        <h3>Test Result: {activeTest}</h3>
        
        {activeTest === 'none' && (
          <p>Select a test above to begin.</p>
        )}
        
        {activeTest === 'navbar' && (
          <div>
            <h4>Simple Navbar Test</h4>
            <div className="bg-white shadow-md">
              <div className="container mx-auto px-4 py-3">
                <div className="flex justify-between items-center">
                  <div className="text-xl font-bold text-wine">
                    The Village Co.
                  </div>
                  <div className="flex items-center space-x-4">
                    <button 
                      className="px-4 py-2 bg-rose text-wine rounded-md hover:bg-opacity-80"
                    >
                      Sign In
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {activeTest === 'layout' && (
          <div>
            <h4>Simple Layout Test</h4>
            <div className="min-h-screen bg-linen">
              <div className="bg-white shadow-md">
                <div className="container mx-auto px-4 py-3">
                  <div className="flex justify-between items-center">
                    <div className="text-xl font-bold text-wine">The Village Co.</div>
                    <button className="px-4 py-2 bg-rose text-wine rounded-md">Sign In</button>
                  </div>
                </div>
              </div>
              <main className="container mx-auto px-4 py-8">
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <h2 className="text-2xl font-bold text-wine mb-4">Test Content</h2>
                  <p>This is test content inside a simplified layout.</p>
                </div>
              </main>
              <footer className="mt-auto py-4 bg-taupe text-white">
                <div className="container mx-auto px-4">
                  <p>© 2025 The Village Co. All rights reserved.</p>
                </div>
              </footer>
            </div>
          </div>
        )}
        
        {activeTest === 'page' && (
          <div>
            <h4>Simple Page Test</h4>
            <div className="min-h-screen bg-linen">
              <header className="bg-white shadow-md">
                <div className="container mx-auto px-4 py-3">
                  <h1 className="text-2xl font-bold text-wine">Test Page</h1>
                </div>
              </header>
              <main className="container mx-auto px-4 py-8">
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <h2 className="text-2xl font-bold text-wine mb-4">Welcome</h2>
                  <p className="mb-4">This is a simple test page with minimal dependencies.</p>
                  <button className="px-4 py-2 bg-rose text-wine rounded-md">
                    Get Started
                  </button>
                </div>
              </main>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// Full simple app with providers
export default function FullSimpleApp() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <SimpleApp />
          <Toaster />
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}