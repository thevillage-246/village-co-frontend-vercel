import { createContext, useState, useEffect, useContext, ReactNode } from 'react';
import { apiRequest } from '@/lib/queryClient';
import { supabase } from '@/lib/supabase';
import * as authUtils from '@/lib/auth';

// Custom user type for our application
interface CustomUser {
  id: number;
  email: string;
  role: string;
  firstName: string;
  lastName: string;
  phone?: string;
  mustChangePassword?: boolean;
}

type AuthContextType = {
  currentUser: CustomUser | null;
  user: CustomUser | null; // Added back for compatibility with existing components
  isLoading: boolean;
  isAuthenticated: boolean;
  signIn: (email: string, password: string) => Promise<{ error: any | null }>;
  signUp: (email: string, password: string, userData?: Record<string, any>) => Promise<{ error: any | null, user: CustomUser | null }>;
  signOut: () => Promise<void>;
  logout: () => Promise<void>; // Add logout alias for backward compatibility
  forgotPassword: (email: string) => Promise<{ error: any | null }>;
  resetPassword: (newPassword: string) => Promise<{ error: any | null }>;
  checkOnboardingStatus: () => Promise<boolean>;
  getCurrentUser: () => Promise<CustomUser | null>;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

interface AuthProviderProps {
  children: ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const [currentUser, setCurrentUser] = useState<CustomUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  // Alias currentUser as user for backward compatibility 
  const user = currentUser;

  // Initialize auth state when component mounts
  useEffect(() => {
    const initializeAuth = async () => {
      console.log('🔄 Starting auth initialization...');
      setIsLoading(true);
      
      try {
        // Check for stored JWT token first (most reliable for session persistence)
        const storedToken = localStorage.getItem('auth_token') || localStorage.getItem('authToken');
        console.log('🔍 Checking for stored token:', !!storedToken);
        
        if (storedToken) {
          try {
            console.log('🔑 Found stored token, attempting to restore session...');
            
            // Verify token with our API - set headers manually to ensure Bearer token is sent
            const response = await fetch('/api/auth/user', {
              method: 'GET',
              headers: {
                'Authorization': `Bearer ${storedToken}`,
                'Content-Type': 'application/json'
              },
              credentials: 'include'
            });
            
            console.log('📡 Token verification response status:', response.status);
            
            if (response.ok) {
              const userData = await response.json();
              console.log('👤 Received user data from token verification:', userData);
              
              // Handle direct user data response (our API returns user directly)
              if (userData.id && userData.email) {
                setCurrentUser(userData);
                setIsAuthenticated(true);
                console.log('✅ Session successfully restored for user:', userData.email);
                setIsLoading(false); // Set loading to false immediately
                return; // Exit early if token auth succeeds
              }
            }
            
            // If we get here, token verification failed
            console.log('❌ Token verification failed, clearing stored tokens. Status:', response.status);
            localStorage.removeItem('auth_token');
            localStorage.removeItem('authToken');
            localStorage.removeItem('user_data');
          } catch (apiError) {
            console.warn('❌ Token verification failed with error:', apiError);
            localStorage.removeItem('auth_token');
            localStorage.removeItem('authToken');
            localStorage.removeItem('user_data');
          }
        }

        // If no token or token failed, user is not authenticated
        console.log('🚫 No valid token found, user not authenticated');
        setCurrentUser(null);
        setIsAuthenticated(false);
        
      } catch (error) {
        console.error('💥 Error initializing auth:', error);
        setCurrentUser(null);
        setIsAuthenticated(false);
        localStorage.removeItem('auth_token');
        localStorage.removeItem('authToken');
      } finally {
        console.log('🏁 Auth initialization complete, setting isLoading to false');
        setIsLoading(false);
      }
    };
    
    initializeAuth();
    
    // Set up Supabase auth state listener for session changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      console.log('Supabase auth state changed:', event, session?.user?.email);
      
      if (event === 'SIGNED_IN' && session?.user) {
        // User signed in through Supabase, update our state
        try {
          const response = await apiRequest('GET', '/api/auth/me');
          if (response.ok) {
            const userData = await response.json();
            setCurrentUser(userData);
            setIsAuthenticated(true);
            if (session.access_token) {
              localStorage.setItem('authToken', session.access_token);
            }
          }
        } catch (error) {
          console.error('Error syncing user data after Supabase sign in:', error);
        }
      } else if (event === 'SIGNED_OUT') {
        // User signed out, clear our state
        setCurrentUser(null);
        setIsAuthenticated(false);
        localStorage.removeItem('authToken');
        localStorage.removeItem('userData');
      }
    });
    
    // Cleanup subscription on unmount
    return () => {
      subscription.unsubscribe();
    };
  }, []);
  
  // Get current user info
  const getCurrentUser = async (): Promise<CustomUser | null> => {
    if (currentUser) return currentUser;
    
    try {
      const token = localStorage.getItem('authToken');
      
      if (!token) return null;
      
      const response = await apiRequest('GET', '/api/auth/me');
      
      if (!response.ok) {
        throw new Error('Failed to fetch current user');
      }
      
      const userData = await response.json();
      setCurrentUser(userData);
      setIsAuthenticated(true);
      return userData;
    } catch (error) {
      console.error('Error getting current user:', error);
      return null;
    }
  };
  
  // Sign in with email and password
  const signIn = async (email: string, password: string) => {
    try {
      console.log('🔑 Attempting login for:', email);
      
      // Use direct API authentication (this is working)
      const response = await fetch('/api/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });
      
      console.log('📡 Login response status:', response.status);
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Login failed');
      }
      
      const data = await response.json();
      console.log('✅ Login successful:', data.user);
      
      if (data.success && data.user && data.token) {
        // Store the JWT token
        localStorage.setItem('auth_token', data.token);
        localStorage.setItem('authToken', data.token); // Keep both for compatibility
        
        // Update our auth state
        setCurrentUser(data.user);
        setIsAuthenticated(true);
        
        return { error: null };
      } else {
        throw new Error('Invalid response from server');
      }
    } catch (error) {
      console.error('Sign in error:', error);
      return { error };
    }
  };
  
  // Sign up with email and password
  const signUp = async (email: string, password: string, userData?: Record<string, any>) => {
    try {
      // First create the user in Supabase for proper email handling
      const { data: supabaseData, error: supabaseError } = await authUtils.signUpWithEmail(email, password);
      
      if (supabaseError) {
        console.warn('Supabase signup failed, trying internal API:', supabaseError.message);
      } else if (supabaseData?.user) {
        console.log('Supabase signup successful, user needs to confirm email');
        // Supabase will send confirmation email automatically
      }
      
      // Also create user in our internal system
      const username = `${userData?.firstName || 'user'}_${userData?.lastName || 'name'}`.toLowerCase().replace(/\s+/g, '_');
      const registerData = {
        email,
        username,
        firstName: userData?.firstName || '',
        lastName: userData?.lastName || '',
        role: userData?.role || 'parent',
        password,
        supabaseId: supabaseData?.user?.id || null
      };
      
      const response = await apiRequest('POST', '/api/register', registerData);
      
      if (!response.ok) {
        const errorData = await response.json();
        
        // If Supabase succeeded but our API failed, clean up Supabase user
        if (supabaseData?.user && !supabaseError) {
          try {
            await authUtils.signOut(); // This will clean up the Supabase session
          } catch (cleanupError) {
            console.warn('Failed to cleanup Supabase user after API failure:', cleanupError);
          }
        }
        
        throw new Error(errorData.error || 'Registration failed');
      }
      
      const newUser = await response.json();
      
      // If Supabase signup succeeded, inform user about email confirmation
      if (supabaseData?.user && !supabaseError) {
        return { 
          error: null, 
          user: newUser,
          emailConfirmationRequired: true,
          message: 'Please check your email to confirm your account before signing in.'
        };
      }
      
      // If Supabase failed but internal API succeeded, sign in immediately
      const loginResult = await signIn(email, password);
      if (loginResult.error) {
        throw new Error('Account created but login failed. Please try signing in.');
      }
      
      return { error: null, user: newUser };
    } catch (error) {
      console.error('Sign up error:', error);
      return { error, user: null };
    }
  };
  
  // Sign out
  const signOut = async () => {
    try {
      // Sign out from Supabase first
      await authUtils.signOut();
      
      // Call our logout endpoint
      try {
        await apiRequest('POST', '/api/auth/logout');
      } catch (apiError) {
        console.warn('API logout failed, continuing with local cleanup:', apiError);
      }
      
      // Clear all stored tokens and data
      localStorage.removeItem('auth_token');
      localStorage.removeItem('authToken');
      localStorage.removeItem('userData');
      
      // Reset state
      setCurrentUser(null);
      setIsAuthenticated(false);
    } catch (error) {
      console.error('Sign out error:', error);
      
      // Force cleanup even if sign out fails
      localStorage.removeItem('auth_token');
      localStorage.removeItem('authToken');
      localStorage.removeItem('userData');
      setCurrentUser(null);
      setIsAuthenticated(false);
    }
  };
  
  // Forgot password (send reset email)
  const forgotPassword = async (email: string) => {
    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/reset-password`,
      });
      
      if (error) throw error;
      
      return { error: null };
    } catch (error) {
      console.error('Forgot password error:', error);
      return { error };
    }
  };
  
  // Reset password (with new password)
  const resetPassword = async (newPassword: string) => {
    try {
      const { error } = await supabase.auth.updateUser({
        password: newPassword
      });
      
      if (error) throw error;
      
      return { error: null };
    } catch (error) {
      console.error('Reset password error:', error);
      return { error };
    }
  };
  
  // Check if the user has completed onboarding
  const checkOnboardingStatus = async (): Promise<boolean> => {
    if (!currentUser) return false;
    
    try {
      // Check onboarding status based on user role
      if (currentUser.role === 'parent') {
        const response = await apiRequest('GET', '/api/parent/onboarding-status');
        if (response.ok) {
          const status = await response.json();
          return status.profileComplete === true;
        }
      } else if (currentUser.role === 'sitter') {
        const response = await apiRequest('GET', '/api/sitter/onboarding-status');
        if (response.ok) {
          const status = await response.json();
          // For sitters, just check if profile is complete - verification can be pending
          return status.profileComplete === true;
        }
      }
      
      // For admin or other roles, consider onboarding complete
      return currentUser.role === 'admin';
    } catch (error) {
      console.error('Error checking onboarding status:', error);
      // If there's an error, assume onboarding is needed
      return false;
    }
  };
  
  const value = {
    currentUser,
    user: currentUser, // Include user as an alias for currentUser
    isLoading,
    isAuthenticated,
    signIn,
    signUp,
    signOut,
    logout: signOut, // Add logout alias for backward compatibility
    forgotPassword,
    resetPassword,
    checkOnboardingStatus,
    getCurrentUser,
  };
  
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

// Custom hook to use the auth context
export function useAuth() {
  const context = useContext(AuthContext);
  
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  
  return context;
}