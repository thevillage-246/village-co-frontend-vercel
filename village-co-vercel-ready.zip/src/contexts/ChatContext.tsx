import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "./AuthContext";
import { WebSocketStatus } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";
import { Bell, AlertTriangle, CheckCircle, DollarSign } from "lucide-react";

// Define the type for message objects
interface Message {
  id: number;
  senderId: number;
  recipientId: number | null;
  bookingId: number | null;
  content: string;
  createdAt: Date;
  isRead: boolean;
  sender?: {
    id: number;
    firstName: string;
    lastName: string;
  };
  recipient?: {
    id: number;
    firstName: string;
    lastName: string;
  };
}

// Define the interface for the Chat context
interface ChatContextValue {
  messages: Message[];
  loadMessages: (userId: number) => Promise<void>;
  loadMessageThread: (userId1: number, userId2: number) => Promise<void>;
  sendMessage: (content: string, recipientId: number, bookingId?: number) => Promise<void>;
  markAsRead: (recipientId: number, senderId: number) => Promise<void>;
  activeThread: {
    userId1: number | null;
    userId2: number | null;
  };
  setActiveThread: (userId1: number | null, userId2: number | null) => void;
  wsStatus: WebSocketStatus;
}

// Create the Chat context
const ChatContext = createContext<ChatContextValue | undefined>(undefined);

// Chat context provider component
export const ChatProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [activeThread, setActiveThreadState] = useState<{
    userId1: number | null;
    userId2: number | null;
  }>({
    userId1: null,
    userId2: null,
  });
  const [wsStatus, setWsStatus] = useState<WebSocketStatus>("disconnected");
  const { user } = useAuth();
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const { toast } = useToast();

  // Load all direct messages for a user
  const loadMessages = async (userId: number) => {
    try {
      const response = await apiRequest(
        "GET", 
        `/api/users/${userId}/direct-messages`
      );
      
      if (response.ok) {
        const data = await response.json();
        setMessages(data);
      }
    } catch (error) {
      console.error("Error loading messages:", error);
    }
  };

  // Load message thread between two users
  const loadMessageThread = async (userId1: number, userId2: number) => {
    try {
      const response = await apiRequest(
        "GET", 
        `/api/messages/thread/${userId1}/${userId2}`
      );
      
      if (response.ok) {
        const data = await response.json();
        setMessages(data);
        setActiveThreadState({
          userId1,
          userId2
        });
      }
    } catch (error) {
      console.error("Error loading message thread:", error);
    }
  };

  // Send a direct message
  const sendMessage = async (content: string, recipientId: number, bookingId?: number) => {
    if (!user) return;
    
    try {
      const endpoint = bookingId 
        ? `/api/bookings/${bookingId}/messages` 
        : '/api/messages/direct';
      
      const body = {
        senderId: user.id,
        recipientId: bookingId ? undefined : recipientId,
        content
      };
      
      const response = await apiRequest("POST", endpoint, body);
      
      if (response.ok) {
        const newMessage = await response.json();
        console.log("Message sent via API, adding to state:", newMessage);
        // Don't add to state here - let WebSocket handle it to avoid duplicates
        // The backend now broadcasts to both sender and recipient
      }
    } catch (error) {
      console.error("Error sending message:", error);
    }
  };

  // Mark messages as read
  const markAsRead = async (recipientId: number, senderId: number) => {
    try {
      await apiRequest("POST", "/api/messages/direct/read", {
        recipientId,
        senderId
      });
      
      // Update local message state
      setMessages(prev => 
        prev.map(msg => 
          msg.recipientId === recipientId && msg.senderId === senderId
            ? { ...msg, isRead: true }
            : msg
        )
      );
    } catch (error) {
      console.error("Error marking messages as read:", error);
    }
  };

  // Set active thread
  const setActiveThread = (userId1: number | null, userId2: number | null) => {
    setActiveThreadState({ userId1, userId2 });
    
    if (userId1 && userId2) {
      loadMessageThread(userId1, userId2);
    }
  };

  // Initialize WebSocket connection
  useEffect(() => {
    if (!user) return;

    // Create WebSocket connection
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const newSocket = new WebSocket(wsUrl);

    newSocket.onopen = () => {
      setWsStatus("connected");
      console.log("WebSocket connected");
      
      // Authenticate with the WebSocket server
      newSocket.send(JSON.stringify({
        type: 'auth',
        userId: user.id
      }));
      
      // Request notification permission for sitters
      if (user.role === 'sitter' && 'Notification' in window && Notification.permission === 'default') {
        Notification.requestPermission().then(permission => {
          if (permission === 'granted') {
            toast({
              title: "🔔 Instant Notifications Enabled",
              description: "You'll now get instant alerts when parents message you!",
              variant: "default",
            });
          }
        });
      }
    };

    newSocket.onclose = () => {
      setWsStatus("disconnected");
      console.log("WebSocket disconnected");
    };

    newSocket.onerror = (error) => {
      setWsStatus("error");
      console.error("WebSocket error:", error);
    };

    newSocket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        // Handle different notification types
        switch (data.type) {
          case 'new_message':
            // Handle new messages
            const message = data.message;
            console.log("WebSocket received new_message:", message);
            
            // Add message to state if it's related to current user
            if (
              message.senderId === user.id || 
              message.recipientId === user.id
            ) {
              console.log("Adding message to state:", message);
              setMessages(prev => {
                // Check for duplicates but be more lenient for real-time updates
                const existingMessage = prev.find(m => m.id === message.id);
                if (existingMessage) {
                  console.log("Message already exists, skipping:", message.id);
                  return prev;
                }
                const newMessages = [...prev, message];
                console.log("Updated messages array length:", newMessages.length);
                return newMessages;
              });
              
              // Show enhanced notifications for incoming messages (not sent by current user)
              if (message.senderId !== user.id && message.sender) {
                const senderName = `${message.sender.firstName} ${message.sender.lastName}`;
                
                // Show toast notification
                toast({
                  title: `💬 New message from ${senderName}`,
                  description: message.content.substring(0, 50) + (message.content.length > 50 ? '...' : ''),
                  variant: "default",
                });
                
                // Show browser notification for sitters
                if (user.role === 'sitter' && 'Notification' in window && Notification.permission === 'granted') {
                  const notification = new Notification(`Message from ${senderName}`, {
                    body: message.content.substring(0, 100),
                    icon: '/favicon.ico',
                    requireInteraction: true,
                  });
                  
                  notification.onclick = () => {
                    window.focus();
                    window.location.href = `/messages?sitterId=${message.senderId}`;
                    notification.close();
                  };
                  
                  // Auto-close after 5 seconds
                  setTimeout(() => notification.close(), 5000);
                }
                
                // Play notification sound for sitters
                if (user.role === 'sitter') {
                  try {
                    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
                    const oscillator = audioContext.createOscillator();
                    const gainNode = audioContext.createGain();
                    
                    oscillator.connect(gainNode);
                    gainNode.connect(audioContext.destination);
                    
                    oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
                    oscillator.frequency.setValueAtTime(600, audioContext.currentTime + 0.1);
                    
                    gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
                    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
                    
                    oscillator.start(audioContext.currentTime);
                    oscillator.stop(audioContext.currentTime + 0.5);
                  } catch (error) {
                    console.log('Could not play notification sound:', error);
                  }
                }
              }
            }
            break;
            
          case 'message_read':
            // Handle message read receipts
            const { recipientId, senderId } = data.data;
            if (user.id === senderId) {
              // Update local messages to mark them as read
              setMessages(prev => 
                prev.map(msg => 
                  msg.senderId === senderId && msg.recipientId === recipientId
                    ? { ...msg, isRead: true }
                    : msg
                )
              );
            }
            break;
            
          case 'booking_status_update':
            // Handle booking status updates
            const { bookingId, status } = data.data;
            console.log(`Booking #${bookingId} status updated to: ${status}`);
            
            // Show toast notification for booking status changes
            let statusTitle = "";
            let statusDescription = "";
            
            switch (status) {
              case 'ACCEPTED':
                statusTitle = "Booking Accepted";
                statusDescription = `Your booking #${bookingId} has been accepted!`;
                break;
              case 'DECLINED':
                statusTitle = "Booking Declined";
                statusDescription = `Your booking #${bookingId} has been declined.`;
                break;
              case 'COMPLETED':
                statusTitle = "Booking Completed";
                statusDescription = `Your booking #${bookingId} has been marked as completed.`;
                break;
              default:
                statusTitle = "Booking Updated";
                statusDescription = `Your booking #${bookingId} status has changed to ${status}.`;
            }
            
            toast({
              title: statusTitle,
              description: statusDescription,
              variant: status === 'DECLINED' ? "destructive" : "default",
            });
            break;
            
          case 'late_fee_applied':
            // Handle late fee notifications
            const feeData = data.data;
            console.log(`Late fee of $${feeData.amount} applied to booking #${feeData.bookingId}: ${feeData.reason}`);
            
            // Show notification to the parent about the late fee
            toast({
              title: "Late Fee Applied",
              description: `A late fee of $${feeData.amount.toFixed(2)} has been applied to booking #${feeData.bookingId}. Reason: ${feeData.reason}`,
              variant: "destructive",
              action: (
                <div className="flex items-center mt-2">
                  <DollarSign className="h-4 w-4 mr-1" />
                </div>
              ),
            });
            break;
            
          case 'late_fee_overridden':
            // Handle late fee override notifications
            const overrideData = data.data;
            console.log(`Late fee for booking #${overrideData.bookingId} has been overridden by ${overrideData.overriddenBy}`);
            
            // Show notification to the parent about the fee being waived
            toast({
              title: "Late Fee Waived",
              description: `Your late fee for booking #${overrideData.bookingId} has been waived by ${overrideData.overriddenBy}.`,
              variant: "default",
              action: (
                <div className="flex items-center mt-2">
                  <CheckCircle className="h-4 w-4 mr-1 text-green-500" />
                </div>
              ),
            });
            break;
            
          default:
            console.log("Received unknown notification type:", data.type);
        }
      } catch (error) {
        console.error("Error parsing WebSocket message:", error);
      }
    };

    setSocket(newSocket);

    // Cleanup
    return () => {
      if (newSocket && newSocket.readyState === WebSocket.OPEN) {
        newSocket.close();
      }
    };
  }, [user, toast]);

  // Context value
  const value: ChatContextValue = {
    messages,
    loadMessages,
    loadMessageThread,
    sendMessage,
    markAsRead,
    activeThread,
    setActiveThread,
    wsStatus
  };

  return <ChatContext.Provider value={value}>{children}</ChatContext.Provider>;
};

// Hook for using the Chat context
export const useChat = () => {
  const context = useContext(ChatContext);
  if (context === undefined) {
    throw new Error("useChat must be used within a ChatProvider");
  }
  return context;
};