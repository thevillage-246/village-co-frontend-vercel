import React, { createContext, useContext, useState } from 'react';
import { WebSocketStatus } from "@/lib/types";

// Define the type for message objects (matching the real implementation)
interface Message {
  id: number;
  senderId: number;
  recipientId: number | null;
  bookingId: number | null;
  content: string;
  createdAt: Date;
  isRead: boolean;
  sender?: {
    id: number;
    firstName: string;
    lastName: string;
  };
  recipient?: {
    id: number;
    firstName: string;
    lastName: string;
  };
}

// Define the interface to match the real ChatContext
interface ChatContextValue {
  messages: Message[];
  loadMessages: (userId: number) => Promise<void>;
  loadMessageThread: (userId1: number, userId2: number) => Promise<void>;
  sendMessage: (content: string, recipientId: number, bookingId?: number) => Promise<void>;
  markAsRead: (recipientId: number, senderId: number) => Promise<void>;
  activeThread: {
    userId1: number | null;
    userId2: number | null;
  };
  setActiveThread: (userId1: number | null, userId2: number | null) => void;
  wsStatus: WebSocketStatus;
}

// Create the Chat context (undefined by default to match real implementation)
const ChatContext = createContext<ChatContextValue | undefined>(undefined);

// Provider component that wraps parts of our app that need chat functionality
export const MockChatProvider: React.FC<React.PropsWithChildren<{}>> = ({ children }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [activeThread, setActiveThreadState] = useState<{
    userId1: number | null;
    userId2: number | null;
  }>({
    userId1: null,
    userId2: null,
  });
  const [wsStatus, setWsStatus] = useState<WebSocketStatus>("connected");

  // Mock implementations
  const loadMessages = async (userId: number) => {
    console.log('Mock loadMessages called with userId:', userId);
    return Promise.resolve();
  };

  const loadMessageThread = async (userId1: number, userId2: number) => {
    console.log('Mock loadMessageThread called with:', userId1, userId2);
    return Promise.resolve();
  };

  const sendMessage = async (content: string, recipientId: number, bookingId?: number) => {
    console.log('Mock sendMessage called:', content, recipientId, bookingId);
    return Promise.resolve();
  };

  const markAsRead = async (recipientId: number, senderId: number) => {
    console.log('Mock markAsRead called:', recipientId, senderId);
    return Promise.resolve();
  };

  const setActiveThread = (userId1: number | null, userId2: number | null) => {
    setActiveThreadState({ userId1, userId2 });
  };

  // Value object that will be passed to consumers (matching the real implementation)
  const value: ChatContextValue = {
    messages,
    loadMessages,
    loadMessageThread,
    sendMessage,
    markAsRead,
    activeThread,
    setActiveThread,
    wsStatus
  };

  return <ChatContext.Provider value={value}>{children}</ChatContext.Provider>;
};

// Hook for using the Chat context - this MUST match the implementation in ChatContext.tsx
export const useChat = () => {
  const context = useContext(ChatContext);
  if (context === undefined) {
    throw new Error("useChat must be used within a ChatProvider");
  }
  return context;
};