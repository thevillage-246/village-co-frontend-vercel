import React, { createContext, useContext, useEffect, useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { 
  subscribeToBookings, 
  subscribeToBookingUpdates,
  subscribeToConciergeRequests 
} from '@/lib/supabase';
import { useAuth } from './AuthContext';
import { BOOKING_STATUS } from '@shared/schema';

// Notification type definition
export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'booking' | 'update' | 'message' | 'support' | 'payment';
  read: boolean;
  createdAt: Date;
  data?: Record<string, any>;
}

interface NotificationContextValue {
  notifications: Notification[];
  unreadCount: number;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  clearNotifications: () => void;
}

const NotificationContext = createContext<NotificationContextValue | undefined>(undefined);

export const useNotifications = () => {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
};

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const { toast } = useToast();
  const { user, userProfile } = useAuth();

  // Calculate unread count
  const unreadCount = notifications.filter(n => !n.read).length;

  // Mark a notification as read
  const markAsRead = (id: string) => {
    setNotifications(prev => 
      prev.map(n => n.id === id ? { ...n, read: true } : n)
    );
  };

  // Mark all notifications as read
  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  // Clear all notifications
  const clearNotifications = () => {
    setNotifications([]);
  };

  // Subscribe to booking notifications
  useEffect(() => {
    if (!user) return;

    // Only sitters should get booking notifications
    if (userProfile?.role === 'sitter') {
      const subscription = subscribeToBookings((payload) => {
        const { new: newBooking } = payload;
        
        // Check if this booking is for the current sitter
        if (userProfile.id === newBooking.sitterId) {
          // Create notification
          const notification: Notification = {
            id: `booking-${Date.now()}`,
            title: 'New Booking Request',
            message: 'You have received a new babysitting request!',
            type: 'booking',
            read: false,
            createdAt: new Date(),
            data: newBooking
          };
          
          setNotifications(prev => [notification, ...prev]);
          
          // Show toast
          toast({
            title: 'New Booking Request',
            description: 'You have received a new babysitting request!',
            duration: 5000,
          });
        }
      });

      return () => {
        subscription.unsubscribe();
      };
    }
  }, [user, userProfile, toast]);

  // Subscribe to booking status updates
  useEffect(() => {
    if (!user) return;

    const subscription = subscribeToBookingUpdates((payload) => {
      const { old: oldBooking, new: updatedBooking } = payload;
      
      // Only trigger on status changes
      if (oldBooking.status === updatedBooking.status) return;
      
      // Create notification based on user role and booking change
      if (userProfile?.role === 'parent' && updatedBooking.parentId === userProfile.id) {
        // For parents when sitters accept/decline
        let title = '';
        let message = '';
        let type: Notification['type'] = 'update';
        
        if (updatedBooking.status === BOOKING_STATUS.CONFIRMED) {
          title = 'Booking Confirmed';
          message = 'Your booking request has been accepted by the sitter.';
        } else if (updatedBooking.status === BOOKING_STATUS.DECLINED) {
          title = 'Booking Declined';
          message = 'Your booking request has been declined by the sitter.';
        } else if (updatedBooking.status === BOOKING_STATUS.COMPLETED) {
          title = 'Booking Completed';
          message = 'Your booking has been marked as completed.';
        } else if (updatedBooking.status === BOOKING_STATUS.CANCELLED) {
          title = 'Booking Cancelled';
          message = 'Your booking has been cancelled.';
        }
        
        if (title) {
          const notification: Notification = {
            id: `update-${Date.now()}`,
            title,
            message,
            type,
            read: false,
            createdAt: new Date(),
            data: updatedBooking
          };
          
          setNotifications(prev => [notification, ...prev]);
          
          // Show toast
          toast({
            title,
            description: message,
            duration: 5000,
          });
        }
      } 
      else if (userProfile?.role === 'sitter' && updatedBooking.sitterId === userProfile.id) {
        // For sitters when parents pay or cancel
        let title = '';
        let message = '';
        let type: Notification['type'] = 'update';
        
        if (updatedBooking.status === BOOKING_STATUS.PAID) {
          title = 'Payment Received';
          message = 'The parent has completed payment for a booking.';
          type = 'payment';
        } else if (updatedBooking.status === BOOKING_STATUS.CANCELLED) {
          title = 'Booking Cancelled';
          message = 'A booking has been cancelled by the parent.';
        }
        
        if (title) {
          const notification: Notification = {
            id: `update-${Date.now()}`,
            title,
            message,
            type,
            read: false,
            createdAt: new Date(),
            data: updatedBooking
          };
          
          setNotifications(prev => [notification, ...prev]);
          
          // Show toast
          toast({
            title,
            description: message,
            duration: 5000,
          });
        }
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, [user, userProfile, toast]);

  // Subscribe to concierge requests (admin only)
  useEffect(() => {
    if (!user || userProfile?.role !== 'admin') return;

    const subscription = subscribeToConciergeRequests((payload) => {
      const { new: newRequest } = payload;
      
      const notification: Notification = {
        id: `support-${Date.now()}`,
        title: 'New Support Request',
        message: `New ${newRequest.category} request received.`,
        type: 'support',
        read: false,
        createdAt: new Date(),
        data: newRequest
      };
      
      setNotifications(prev => [notification, ...prev]);
      
      // Show toast for urgent requests
      if (newRequest.category === 'urgent' || newRequest.category === 'insurance_claim') {
        toast({
          title: 'Urgent Support Request',
          description: `New ${newRequest.category} request received.`,
          variant: 'destructive',
          duration: 10000,
        });
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, [user, userProfile, toast]);

  // Value to provide to consumers
  const value: NotificationContextValue = {
    notifications,
    unreadCount,
    markAsRead,
    markAllAsRead,
    clearNotifications
  };

  return (
    <NotificationContext.Provider value={value}>
      {children}
    </NotificationContext.Provider>
  );
};