// Initialize GrowSurf on app startup
// This ensures the tracking script is loaded early for better attribution

declare global {
  interface Window {
    grsfSettings?: {
      campaignId: string;
      version: string;
    };
    grsfInit?: boolean;
  }
}

export function initializeGrowSurf() {
  if (typeof window === 'undefined' || window.grsfInit) return;
  
  // Set up GrowSurf configuration
  window.grsfSettings = {
    campaignId: "2irxbh",
    version: "2.0.0"
  };

  // Load the GrowSurf tracking script
  const head = document.getElementsByTagName("head")[0];
  const script = document.createElement("script");
  script.async = true;
  script.src = `https://app.growsurf.com/growsurf.js?v=${window.grsfSettings.version}`;
  script.setAttribute("grsf-campaign", window.grsfSettings.campaignId);
  
  // Mark as initialized to prevent duplicate loading
  script.onload = () => {
    window.grsfInit = true;
    console.log('GrowSurf initialized with campaign ID: 2irxbh');
  };
  
  head.appendChild(script);
}

// Track GrowSurf events
export function trackGrowSurfEvent(event: string, data?: any) {
  if (typeof window === 'undefined' || !window.growsurf) {
    console.log('GrowSurf not ready, queueing event:', event);
    return;
  }

  try {
    if (typeof window.growsurf === 'function') {
      window.growsurf(event, data);
    }
  } catch (error) {
    console.error('GrowSurf tracking error:', error);
  }
}