import { createClient } from '@supabase/supabase-js';

// Initialize the Supabase client with environment variables
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase credentials. Please set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in your environment.');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Auth helper functions
export const getCurrentUser = async () => {
  const { data: { user } } = await supabase.auth.getUser();
  return user;
};

export const getUserSession = async () => {
  const { data: { session } } = await supabase.auth.getSession();
  return session;
};

export const signOut = async () => {
  return await supabase.auth.signOut();
};

// Listen for auth state changes
export const setupAuthListener = (callback: (event: 'SIGNED_IN' | 'SIGNED_OUT' | 'USER_UPDATED', session: any) => void) => {
  return supabase.auth.onAuthStateChange((event, session) => {
    callback(event as any, session);
  });
};

// Function to handle auth redirect
export const handleAuthRedirect = async () => {
  const { data: { session } } = await supabase.auth.getSession();
  
  // If we have a session, the user has been successfully logged in
  if (session) {
    return { success: true, session };
  }
  
  // Check for errors in the URL
  const url = new URL(window.location.href);
  const errorDescription = url.searchParams.get('error_description');
  
  if (errorDescription) {
    return { success: false, error: errorDescription };
  }
  
  return { success: false };
};