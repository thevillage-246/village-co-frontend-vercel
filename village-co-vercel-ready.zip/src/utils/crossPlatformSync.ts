/**
 * Cross-Platform Synchronization Utilities
 * Handles session management and data sync between web and mobile apps
 */

interface CrossPlatformConfig {
  enableSessionSync: boolean;
  enableDeepLinking: boolean;
  mobileAppScheme: string;
  webAppUrl: string;
}

class CrossPlatformManager {
  private config: CrossPlatformConfig = {
    enableSessionSync: true,
    enableDeepLinking: true,
    mobileAppScheme: 'villageco',
    webAppUrl: window.location.origin
  };

  // Detect if user is on mobile device
  isMobileDevice(): boolean {
    return /Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  }

  // Check if mobile app is installed
  async isMobileAppInstalled(): Promise<boolean> {
    if (!this.isMobileDevice()) return false;
    
    try {
      // Try to open app scheme - if it fails, app isn't installed
      const testLink = `${this.config.mobileAppScheme}://test`;
      window.location.href = testLink;
      
      // If we get here after a delay, app probably isn't installed
      return new Promise(resolve => {
        setTimeout(() => resolve(false), 2000);
        // If app opens successfully, this won't execute
        setTimeout(() => resolve(true), 500);
      });
    } catch {
      return false;
    }
  }

  // Generate deep link for specific page/action
  generateDeepLink(path: string, params?: Record<string, string>): string {
    const baseUrl = `${this.config.mobileAppScheme}://`;
    const queryString = params ? '?' + new URLSearchParams(params).toString() : '';
    return `${baseUrl}${path}${queryString}`;
  }

  // Smart redirect - mobile app if available, otherwise web
  async smartRedirect(path: string, params?: Record<string, string>): Promise<void> {
    if (this.isMobileDevice() && await this.isMobileAppInstalled()) {
      const deepLink = this.generateDeepLink(path, params);
      window.location.href = deepLink;
    } else {
      const webUrl = `${this.config.webAppUrl}${path}`;
      const queryString = params ? '?' + new URLSearchParams(params).toString() : '';
      window.location.href = `${webUrl}${queryString}`;
    }
  }

  // Sync user session across platforms
  syncUserSession(token: string, userInfo: any): void {
    if (!this.config.enableSessionSync) return;

    // Store in localStorage for web app persistence
    localStorage.setItem('village_auth_token', token);
    localStorage.setItem('village_user_info', JSON.stringify(userInfo));

    // If on mobile web, prepare data for app handoff
    if (this.isMobileDevice()) {
      sessionStorage.setItem('pending_mobile_sync', JSON.stringify({
        token,
        userInfo,
        timestamp: Date.now()
      }));
    }
  }

  // Handle incoming deep link or shared state
  handleIncomingLink(): void {
    const urlParams = new URLSearchParams(window.location.search);
    
    // Check for shared session from mobile app
    const sharedToken = urlParams.get('shared_token');
    const sharedUser = urlParams.get('shared_user');
    
    if (sharedToken && sharedUser) {
      try {
        const userInfo = JSON.parse(decodeURIComponent(sharedUser));
        this.syncUserSession(sharedToken, userInfo);
        
        // Clean URL
        const cleanUrl = window.location.pathname;
        window.history.replaceState({}, document.title, cleanUrl);
      } catch (error) {
        console.warn('Failed to process shared session:', error);
      }
    }
  }

  // Show smart app banner if mobile user without app
  async showAppBanner(): Promise<void> {
    if (!this.isMobileDevice()) return;
    
    const hasApp = await this.isMobileAppInstalled();
    if (hasApp) return;

    // Create app banner
    const banner = document.createElement('div');
    banner.className = 'app-banner';
    banner.innerHTML = `
      <div style="
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        background: #6b3e4b;
        color: white;
        padding: 12px 16px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        z-index: 9999;
        font-family: system-ui;
      ">
        <div style="display: flex; align-items: center; gap: 12px;">
          <div style="font-size: 24px;">📱</div>
          <div>
            <div style="font-weight: bold; font-size: 14px;">The Village Co. App</div>
            <div style="font-size: 12px; opacity: 0.9;">Get the full experience on mobile</div>
          </div>
        </div>
        <div style="display: flex; gap: 8px;">
          <button onclick="window.open('${this.getAppStoreUrl()}', '_blank')" style="
            background: #ebd3cb;
            color: #6b3e4b;
            border: none;
            padding: 8px 12px;
            border-radius: 6px;
            font-size: 12px;
            font-weight: bold;
          ">Get App</button>
          <button onclick="this.closest('.app-banner').remove()" style="
            background: transparent;
            color: white;
            border: none;
            padding: 8px;
            font-size: 16px;
          ">×</button>
        </div>
      </div>
    `;

    document.body.appendChild(banner);
    
    // Add top margin to body to prevent content overlap
    document.body.style.paddingTop = '72px';
  }

  // Get appropriate app store URL based on device
  private getAppStoreUrl(): string {
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
    
    if (isIOS) {
      return 'https://apps.apple.com/nz/app/the-village-co/id123456789';
    } else {
      return 'https://play.google.com/store/apps/details?id=nz.thevillageco.app';
    }
  }

  // Initialize cross-platform features
  initialize(): void {
    // Handle any incoming deep links or shared state
    this.handleIncomingLink();
    
    // Show app banner for mobile users
    setTimeout(() => this.showAppBanner(), 2000);
    
    // Set up event listeners for session sync
    window.addEventListener('storage', (e) => {
      if (e.key === 'village_auth_token' && e.newValue) {
        // Session updated in another tab - refresh current state
        window.location.reload();
      }
    });
  }
}

export const crossPlatformManager = new CrossPlatformManager();