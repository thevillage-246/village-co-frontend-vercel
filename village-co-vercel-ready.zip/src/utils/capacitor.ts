import { Capacitor } from '@capacitor/core';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';
import { Geolocation } from '@capacitor/geolocation';
import { Share } from '@capacitor/share';
import { StatusBar, Style } from '@capacitor/status-bar';
import { SplashScreen } from '@capacitor/splash-screen';
import { LocalNotifications } from '@capacitor/local-notifications';
import { App } from '@capacitor/app';
import { Device } from '@capacitor/device';
import { Network } from '@capacitor/network';

export class CapacitorIntegration {
  private static instance: CapacitorIntegration;

  public static getInstance(): CapacitorIntegration {
    if (!CapacitorIntegration.instance) {
      CapacitorIntegration.instance = new CapacitorIntegration();
    }
    return CapacitorIntegration.instance;
  }

  // Check if running in native mobile app
  public isNative(): boolean {
    return Capacitor.isNativePlatform();
  }

  public getPlatform(): string {
    return Capacitor.getPlatform();
  }

  // Initialize mobile app features
  public async initialize(): Promise<void> {
    if (!this.isNative()) return;

    try {
      // Set status bar style
      await StatusBar.setStyle({ style: Style.Light });
      await StatusBar.setBackgroundColor({ color: '#6B3E4B' });

      // Hide splash screen after app is ready
      await SplashScreen.hide();

      // Register for app state changes
      App.addListener('appStateChange', ({ isActive }) => {
        console.log('App state changed. Is active?', isActive);
      });

      // Monitor network status
      Network.addListener('networkStatusChange', status => {
        console.log('Network status changed', status);
      });

      console.log('✅ Capacitor initialized successfully');
    } catch (error) {
      console.error('❌ Error initializing Capacitor:', error);
    }
  }

  // Camera functionality
  public async takePicture(): Promise<string | null> {
    if (!this.isNative()) {
      console.warn('Camera not available in web environment');
      return null;
    }

    try {
      const image = await Camera.getPhoto({
        quality: 90,
        allowEditing: false,
        resultType: CameraResultType.DataUrl,
        source: CameraSource.Camera
      });

      return image.dataUrl || null;
    } catch (error) {
      console.error('Error taking picture:', error);
      return null;
    }
  }

  // Get current location
  public async getCurrentPosition(): Promise<{lat: number, lng: number} | null> {
    try {
      const coordinates = await Geolocation.getCurrentPosition({
        enableHighAccuracy: true,
        timeout: 10000
      });

      return {
        lat: coordinates.coords.latitude,
        lng: coordinates.coords.longitude
      };
    } catch (error) {
      console.error('Error getting location:', error);
      return null;
    }
  }

  // Share content
  public async shareContent(title: string, text: string, url?: string): Promise<boolean> {
    if (!this.isNative()) {
      // Fallback to Web Share API
      if (navigator.share) {
        try {
          await navigator.share({ title, text, url });
          return true;
        } catch (error) {
          console.error('Error sharing:', error);
          return false;
        }
      }
      return false;
    }

    try {
      await Share.share({
        title,
        text,
        url,
        dialogTitle: 'Share with'
      });
      return true;
    } catch (error) {
      console.error('Error sharing:', error);
      return false;
    }
  }

  // Local notifications
  public async scheduleNotification(
    title: string, 
    body: string, 
    id: number,
    schedule?: Date
  ): Promise<boolean> {
    if (!this.isNative()) return false;

    try {
      // Request permission first
      const permission = await LocalNotifications.requestPermissions();
      if (permission.display !== 'granted') {
        return false;
      }

      await LocalNotifications.schedule({
        notifications: [{
          title,
          body,
          id,
          schedule: schedule ? { at: schedule } : undefined,
          sound: 'beep.wav',
          attachments: undefined,
          actionTypeId: '',
          extra: null
        }]
      });

      return true;
    } catch (error) {
      console.error('Error scheduling notification:', error);
      return false;
    }
  }

  // Get device info
  public async getDeviceInfo(): Promise<any> {
    try {
      const info = await Device.getInfo();
      return info;
    } catch (error) {
      console.error('Error getting device info:', error);
      return null;
    }
  }

  // Network status
  public async getNetworkStatus(): Promise<any> {
    try {
      const status = await Network.getStatus();
      return status;
    } catch (error) {
      console.error('Error getting network status:', error);
      return null;
    }
  }

  // App info
  public async getAppInfo(): Promise<any> {
    if (!this.isNative()) return null;

    try {
      const info = await App.getInfo();
      return info;
    } catch (error) {
      console.error('Error getting app info:', error);
      return null;
    }
  }
}

// Export singleton instance
export const capacitorIntegration = CapacitorIntegration.getInstance();