interface ReminderEmailProps {
  sitterName: string;
  parentName: string;
  childName: string;
  startTime: string;
  address: string;
}

/**
 * Generates a reminder email template for upcoming sits
 */
export const generateReminderEmail = ({
  sitterName,
  parentName,
  childName,
  startTime,
  address
}: ReminderEmailProps): string => `
<!DOCTYPE html>
<html>
<head>
  <style>
    body {
      font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
      line-height: 1.6;
      color: #333;
      max-width: 600px;
      margin: 0 auto;
      padding: 20px;
    }
    .header {
      text-align: center;
      margin-bottom: 30px;
    }
    .logo {
      max-width: 180px;
      margin-bottom: 15px;
    }
    h1 {
      color: #6B3E4B;
      font-size: 24px;
      margin-bottom: 20px;
    }
    .content {
      background-color: #F9F5F0;
      padding: 25px;
      border-radius: 8px;
      margin-bottom: 25px;
    }
    .details {
      margin: 20px 0;
      padding: 15px;
      background-color: white;
      border-radius: 8px;
      border-left: 4px solid #EBD3CB;
    }
    .details p {
      margin: 8px 0;
    }
    .detail-label {
      font-weight: bold;
      color: #6B3E4B;
    }
    .cta {
      text-align: center;
      margin: 30px 0;
    }
    .button {
      display: inline-block;
      background-color: #6B3E4B;
      color: white;
      text-decoration: none;
      padding: 12px 25px;
      border-radius: 6px;
      font-weight: bold;
    }
    .footer {
      font-size: 12px;
      text-align: center;
      color: #777;
      margin-top: 30px;
      padding-top: 15px;
      border-top: 1px solid #EBD3CB;
    }
  </style>
</head>
<body>
  <div class="header">
    <img src="https://thevillageco.nz/attached_assets/IMG_4964_1751883228689.png" alt="Village Co" class="logo" />
    <h1>Your Upcoming Sit Reminder</h1>
  </div>
  
  <div class="content">
    <p>Hi ${parentName},</p>
    
    <p>This is a friendly reminder that ${sitterName} is scheduled to look after ${childName} soon.</p>
    
    <div class="details">
      <p><span class="detail-label">When:</span> ${startTime}</p>
      <p><span class="detail-label">Where:</span> ${address}</p>
      <p><span class="detail-label">Sitter:</span> ${sitterName}</p>
    </div>
    
    <p>Please ensure your home is ready and you've left any specific instructions for the sitter. Remember to add any special notes about meals, bedtime routines, or activities in the Village app.</p>
    
    <div class="cta">
      <a href="https://village-co.com/bookings" class="button">View Booking Details</a>
    </div>
    
    <p>If you need to make any changes, please do so at least 6 hours before the scheduled time.</p>
    
    <p>Thank you for being part of our Village!</p>
  </div>
  
  <div class="footer">
    <p>© 2025 The Village Co. All rights reserved.</p>
    <p>123 Main St, Auckland, New Zealand</p>
    <p><a href="%unsubscribe_url%">Unsubscribe</a> | <a href="https://village-co.com/privacy">Privacy Policy</a></p>
  </div>
</body>
</html>
`;

interface BookingConfirmationEmailProps {
  parentName: string;
  sitterName: string;
  bookingDate: string;
  startTime: string;
  endTime: string;
  totalAmount: string;
}

/**
 * Generates a booking confirmation email template
 */
export const generateBookingConfirmationEmail = ({
  parentName,
  sitterName,
  bookingDate,
  startTime,
  endTime,
  totalAmount
}: BookingConfirmationEmailProps): string => `
<!DOCTYPE html>
<html>
<head>
  <style>
    body {
      font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
      line-height: 1.6;
      color: #333;
      max-width: 600px;
      margin: 0 auto;
      padding: 20px;
    }
    .header {
      text-align: center;
      margin-bottom: 30px;
    }
    .logo {
      max-width: 180px;
      margin-bottom: 15px;
    }
    h1 {
      color: #6B3E4B;
      font-size: 24px;
      margin-bottom: 20px;
    }
    .content {
      background-color: #F9F5F0;
      padding: 25px;
      border-radius: 8px;
      margin-bottom: 25px;
    }
    .details {
      margin: 20px 0;
      padding: 15px;
      background-color: white;
      border-radius: 8px;
      border-left: 4px solid #EBD3CB;
    }
    .details p {
      margin: 8px 0;
    }
    .detail-label {
      font-weight: bold;
      color: #6B3E4B;
    }
    .cta {
      text-align: center;
      margin: 30px 0;
    }
    .button {
      display: inline-block;
      background-color: #6B3E4B;
      color: white;
      text-decoration: none;
      padding: 12px 25px;
      border-radius: 6px;
      font-weight: bold;
    }
    .footer {
      font-size: 12px;
      text-align: center;
      color: #777;
      margin-top: 30px;
      padding-top: 15px;
      border-top: 1px solid #EBD3CB;
    }
  </style>
</head>
<body>
  <div class="header">
    <img src="https://thevillageco.nz/attached_assets/IMG_4964_1751883228689.png" alt="Village Co" class="logo" />
    <h1>Booking Confirmation</h1>
  </div>
  
  <div class="content">
    <p>Hi ${parentName},</p>
    
    <p>Your booking with ${sitterName} has been confirmed!</p>
    
    <div class="details">
      <p><span class="detail-label">Date:</span> ${bookingDate}</p>
      <p><span class="detail-label">Time:</span> ${startTime} - ${endTime}</p>
      <p><span class="detail-label">Sitter:</span> ${sitterName}</p>
      <p><span class="detail-label">Total Amount:</span> ${totalAmount}</p>
    </div>
    
    <p>You can view all the details and any special notes for this booking in your Village app. Your payment has been processed successfully.</p>
    
    <div class="cta">
      <a href="https://village-co.com/bookings" class="button">View Booking</a>
    </div>
    
    <p>If you need to make any changes to this booking, please do so at least 6 hours in advance to avoid any cancellation fees.</p>
    
    <p>Thank you for trusting The Village Co with your childcare needs!</p>
  </div>
  
  <div class="footer">
    <p>© 2025 The Village Co. All rights reserved.</p>
    <p>123 Main St, Auckland, New Zealand</p>
    <p><a href="%unsubscribe_url%">Unsubscribe</a> | <a href="https://village-co.com/privacy">Privacy Policy</a></p>
  </div>
</body>
</html>
`;