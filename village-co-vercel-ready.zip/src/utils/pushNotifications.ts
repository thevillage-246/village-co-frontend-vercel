import { apiRequest } from '@/lib/queryClient';

// VAPID public key for push notifications
const VAPID_PUBLIC_KEY = 'BBXx9_OU1gRDzQJu_ve4URCQ7PdER9EYPhLTVhBqmv1wM_dKPeygVLhbO_HHB-X4oH4FncYUe8rcMupuJaxXG4w';

export class PushNotificationService {
  private registration: ServiceWorkerRegistration | null = null;
  private subscription: PushSubscription | null = null;

  async initialize(): Promise<boolean> {
    if (!('serviceWorker' in navigator) || !('PushManager' in window)) {
      console.warn('Push notifications not supported in this browser');
      return false;
    }

    try {
      // Register service worker
      this.registration = await navigator.serviceWorker.register('/service-worker.js');
      console.log('Service worker registered for push notifications');

      // Wait for service worker to be ready
      await navigator.serviceWorker.ready;

      return true;
    } catch (error) {
      console.error('Failed to register service worker:', error);
      return false;
    }
  }

  async requestPermission(): Promise<NotificationPermission> {
    if (!('Notification' in window)) {
      throw new Error('This browser does not support notifications');
    }

    let permission = Notification.permission;

    if (permission === 'default') {
      permission = await Notification.requestPermission();
    }

    return permission;
  }

  async subscribeToPushNotifications(userId: number): Promise<boolean> {
    try {
      const permission = await this.requestPermission();
      
      if (permission !== 'granted') {
        console.log('Push notification permission denied');
        return false;
      }

      if (!this.registration) {
        throw new Error('Service worker not registered');
      }

      // Subscribe to push notifications
      this.subscription = await this.registration.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: this.urlBase64ToUint8Array(VAPID_PUBLIC_KEY)
      });

      // Send subscription to server
      await apiRequest('POST', '/api/notifications/subscribe', {
        userId,
        subscription: this.subscription.toJSON()
      });

      console.log('Successfully subscribed to push notifications');
      return true;

    } catch (error) {
      console.error('Failed to subscribe to push notifications:', error);
      return false;
    }
  }

  async unsubscribeFromPushNotifications(userId: number): Promise<boolean> {
    try {
      if (!this.subscription) {
        return true; // Already unsubscribed
      }

      // Unsubscribe from push manager
      await this.subscription.unsubscribe();

      // Remove subscription from server
      await apiRequest('POST', '/api/notifications/unsubscribe', {
        userId,
        subscription: this.subscription.toJSON()
      });

      this.subscription = null;
      console.log('Successfully unsubscribed from push notifications');
      return true;

    } catch (error) {
      console.error('Failed to unsubscribe from push notifications:', error);
      return false;
    }
  }

  async sendTestNotification(): Promise<void> {
    if (Notification.permission === 'granted') {
      new Notification('The Village Co.', {
        body: 'Push notifications are working!',
        icon: '/icon-192.png',
        tag: 'test-notification'
      });
    }
  }

  private urlBase64ToUint8Array(base64String: string): Uint8Array {
    const padding = '='.repeat((4 - base64String.length % 4) % 4);
    const base64 = (base64String + padding)
      .replace(/-/g, '+')
      .replace(/_/g, '/');

    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);

    for (let i = 0; i < rawData.length; ++i) {
      outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray;
  }

  getSubscriptionStatus(): boolean {
    return this.subscription !== null;
  }

  async checkExistingSubscription(): Promise<boolean> {
    try {
      if (!this.registration) {
        return false;
      }

      this.subscription = await this.registration.pushManager.getSubscription();
      return this.subscription !== null;
    } catch (error) {
      console.error('Failed to check existing subscription:', error);
      return false;
    }
  }
}

// Global instance
export const pushNotificationService = new PushNotificationService();