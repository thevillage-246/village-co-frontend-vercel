/**
 * Timezone utilities for Auckland/Pacific timezone handling
 * Ensures consistent date formatting throughout the platform
 */

/**
 * Format a date in Auckland timezone
 */
export function formatAucklandTime(date: Date | string | null | undefined): string {
  try {
    if (!date) return 'Not available';
    
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    
    if (isNaN(dateObj.getTime())) {
      return 'Invalid date';
    }
    
    return dateObj.toLocaleString('en-NZ', {
      timeZone: 'Pacific/Auckland',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  } catch (error) {
    console.error('Error formatting Auckland time:', error);
    return 'Date formatting error';
  }
}

/**
 * Format a date as Auckland date only
 */
export function formatAucklandDate(date: Date | string | null | undefined): string {
  try {
    if (!date) return 'Not available';
    
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    
    if (isNaN(dateObj.getTime())) {
      return 'Invalid date';
    }
    
    return dateObj.toLocaleDateString('en-NZ', {
      timeZone: 'Pacific/Auckland',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  } catch (error) {
    console.error('Error formatting Auckland date:', error);
    return 'Date formatting error';
  }
}

/**
 * Format time only in Auckland timezone
 */
export function formatAucklandTimeOnly(date: Date | string | null | undefined): string {
  try {
    if (!date) return 'Not available';
    
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    
    if (isNaN(dateObj.getTime())) {
      return 'Invalid time';
    }
    
    return dateObj.toLocaleTimeString('en-NZ', {
      timeZone: 'Pacific/Auckland',
      hour: '2-digit',
      minute: '2-digit'
    });
  } catch (error) {
    console.error('Error formatting Auckland time only:', error);
    return 'Time formatting error';
  }
}