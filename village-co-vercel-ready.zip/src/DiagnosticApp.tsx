import React, { useState, Component, ErrorInfo, ReactNode } from 'react';
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "./contexts/AuthContext";
import { Toaster } from "@/components/ui/toaster";

// Error boundary component to catch errors in React components
interface ErrorBoundaryProps {
  children: ReactNode;
  componentName: string;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
  errorInfo: ErrorInfo | null;
}

class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      errorInfo: null
    };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {
      hasError: true,
      error,
      errorInfo: null
    };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo): void {
    console.error(`Error in ${this.props.componentName}:`, error, errorInfo);
    this.setState({
      error,
      errorInfo
    });
  }

  render(): ReactNode {
    if (this.state.hasError) {
      return (
        <div style={{ 
          padding: '15px',
          backgroundColor: '#ffefef',
          border: '1px solid #f5c2c7',
          borderRadius: '4px',
          color: '#842029'
        }}>
          <h3>Error in {this.props.componentName}</h3>
          <details style={{ whiteSpace: 'pre-wrap', marginTop: '10px' }}>
            <summary>Show Error Details</summary>
            <p>{this.state.error?.toString()}</p>
            <p>Component Stack: {this.state.errorInfo?.componentStack}</p>
          </details>
        </div>
      );
    }

    return this.props.children;
  }
}

// Diagnostic component to help us identify what's breaking
function DiagnosticApp() {
  const [activeTest, setActiveTest] = useState('none');
  
  return (
    <div style={{ 
      padding: '20px', 
      maxWidth: '800px', 
      margin: '0 auto', 
      fontFamily: 'sans-serif', 
      backgroundColor: 'white',
      minHeight: '100vh'
    }}>
      <h1 style={{ color: '#6B3E4B' }}>Village Co - Diagnostic Page</h1>
      <p>This page will help us identify what part of the application is breaking.</p>
      
      <div style={{ 
        padding: '15px',
        background: '#f7f7f7',
        border: '1px solid #ddd',
        borderRadius: '4px',
        marginTop: '20px',
        marginBottom: '20px'
      }}>
        <h2>Component Tests</h2>
        <p>Click on each test to render just that part of the application.</p>
      </div>
      
      <div style={{ display: 'flex', gap: '10px', marginBottom: '20px', flexWrap: 'wrap' }}>
        {['none', 'navbar', 'home', 'mainLayout', 'protected', 'router'].map(test => (
          <button
            key={test}
            onClick={() => setActiveTest(test)}
            style={{
              padding: '8px 16px',
              background: activeTest === test ? '#6B3E4B' : '#eee',
              color: activeTest === test ? 'white' : '#333',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
          >
            Test: {test}
          </button>
        ))}
      </div>
      
      <div style={{ 
        padding: '20px', 
        border: '1px solid #ddd', 
        borderRadius: '4px',
        backgroundColor: '#fafafa', 
        minHeight: '300px'
      }}>
        <h3>Test Result: {activeTest}</h3>
        
        {activeTest === 'none' && (
          <p>Select a test above to begin diagnosing the application.</p>
        )}
        
        {activeTest === 'navbar' && (
          <div>
            <h4>Testing Navbar Component</h4>
            <p>If the Navbar is rendered below, it's working correctly:</p>
            <div style={{ border: '1px dashed #ccc', padding: '10px', marginTop: '10px' }}>
              <ErrorBoundary componentName="Navbar">
                <React.Suspense fallback={<div>Loading Navbar...</div>}>
                  {(() => {
                    try {
                      // Using dynamic import to load the component
                      const NavbarModule = await import('./components/layout/Navbar');
                      const Navbar = NavbarModule.default;
                      return <Navbar />;
                    } catch (error) {
                      console.error("Error in Navbar:", error);
                      return <div>Error loading Navbar: {error instanceof Error ? error.message : String(error)}</div>;
                    }
                  })()}
                </React.Suspense>
              </ErrorBoundary>
            </div>
          </div>
        )}
        
        {activeTest === 'home' && (
          <div>
            <h4>Testing Home Component</h4>
            <p>If the Home component is rendered below, it's working correctly:</p>
            <div style={{ border: '1px dashed #ccc', padding: '10px', marginTop: '10px' }}>
              <ErrorBoundary componentName="Home">
                <React.Suspense fallback={<div>Loading Home...</div>}>
                  {(() => {
                    try {
                      // Directly importing component to avoid lazy loading which hides errors
                      const Home = require('./pages/Home').default;
                      return <Home />;
                    } catch (error) {
                      console.error("Error in Home:", error);
                      return <div>Error loading Home: {error instanceof Error ? error.message : String(error)}</div>;
                    }
                  })()}
                </React.Suspense>
              </ErrorBoundary>
            </div>
          </div>
        )}
        
        {activeTest === 'mainLayout' && (
          <div>
            <h4>Testing MainLayout Component</h4>
            <p>If the MainLayout is rendered below, it's working correctly:</p>
            <div style={{ border: '1px dashed #ccc', padding: '10px', marginTop: '10px' }}>
              <ErrorBoundary componentName="MainLayout">
                <React.Suspense fallback={<div>Loading MainLayout...</div>}>
                  {(() => {
                    try {
                      // Directly importing component to avoid lazy loading which hides errors
                      const MainLayout = require('./components/layout/MainLayout').default;
                      return <MainLayout>
                        <div>Test content inside MainLayout</div>
                      </MainLayout>;
                    } catch (error) {
                      console.error("Error in MainLayout:", error);
                      return <div>Error loading MainLayout: {error instanceof Error ? error.message : String(error)}</div>;
                    }
                  })()}
                </React.Suspense>
              </ErrorBoundary>
            </div>
          </div>
        )}
        
        {activeTest === 'protected' && (
          <div>
            <h4>Testing ProtectedRoute Component</h4>
            <p>If the ProtectedRoute doesn't redirect, it's working correctly:</p>
            <div style={{ border: '1px dashed #ccc', padding: '10px', marginTop: '10px' }}>
              <ErrorBoundary componentName="ProtectedRoute">
                <React.Suspense fallback={<div>Loading ProtectedRoute...</div>}>
                  {(() => {
                    try {
                      // Directly importing component to avoid lazy loading which hides errors
                      const ProtectedRoute = require('./components/auth/ProtectedRoute').default;
                      return <ProtectedRoute>
                        <div>Test content inside ProtectedRoute</div>
                      </ProtectedRoute>;
                    } catch (error) {
                      console.error("Error in ProtectedRoute:", error);
                      return <div>Error loading ProtectedRoute: {error instanceof Error ? error.message : String(error)}</div>;
                    }
                  })()}
                </React.Suspense>
              </ErrorBoundary>
            </div>
          </div>
        )}
        
        {activeTest === 'router' && (
          <div>
            <h4>Testing Router Component</h4>
            <p>This will test the Router component in isolation:</p>
            <div style={{ border: '1px dashed #ccc', padding: '10px', marginTop: '10px' }}>
              <ErrorBoundary componentName="Router">
                <React.Suspense fallback={<div>Loading Router...</div>}>
                  {(() => {
                    try {
                      // Let's create a temporary Router component to test routing
                      const { Switch, Route } = require('wouter');
                      
                      const TestRouter = () => (
                        <Switch>
                          <Route path="/">
                            <div>Home Route</div>
                          </Route>
                          <Route path="/test">
                            <div>Test Route</div>
                          </Route>
                        </Switch>
                      );
                      
                      return <TestRouter />;
                    } catch (error) {
                      console.error("Error in Router:", error);
                      return <div>Error testing Router: {error instanceof Error ? error.message : String(error)}</div>;
                    }
                  })()}
                </React.Suspense>
              </ErrorBoundary>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// Full diagnostic app with providers
export default function FullDiagnosticApp() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <DiagnosticApp />
          <Toaster />
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}