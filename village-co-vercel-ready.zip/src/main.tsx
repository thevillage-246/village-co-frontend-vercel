import { createRoot } from "react-dom/client";
import App from "./App";
import MinimalApp from "./MinimalApp";
import ErrorBoundary from "./ErrorBoundary";
import "./index.css";
import { capacitorIntegration } from "./utils/capacitor";

// Register service worker for PWA support
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/service-worker.js')
    .then(() => console.log('✅ Service worker registered'))
    .catch(err => console.error('❌ SW registration failed', err));
}

// Initialize Capacitor for mobile app functionality
capacitorIntegration.initialize().catch(err => 
  console.error('❌ Capacitor initialization failed', err)
);

try {
  console.log("Attempting to render main application...");
  const rootElement = document.getElementById("root");
  if (!rootElement) {
    throw new Error("Root element not found in the DOM");
  }
  
  // Render the full application
  const root = createRoot(rootElement);
  
  // Add a global error handler for React errors
  window.addEventListener('error', (event) => {
    console.error('Global error caught:', event.error);
  });
  
  // Add an unhandled promise rejection handler
  window.addEventListener('unhandledrejection', (event) => {
    console.error('Unhandled promise rejection:', event.reason);
    event.preventDefault(); // Prevent default logging
  });
  
  root.render(
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  );
  console.log("Main application rendered successfully");
} catch (error) {
  console.error("Error rendering the app:", error);
  // Display error directly in the DOM for debugging
  const rootElement = document.getElementById("root");
  if (rootElement) {
    rootElement.innerHTML = `
      <div style="padding: 20px; background-color: #ffefef; color: #d32f2f; border: 1px solid #d32f2f;">
        <h1>Error Rendering Application</h1>
        <p>${error instanceof Error ? error.message : String(error)}</p>
        <p>Stack: ${error instanceof Error ? error.stack : 'No stack trace'}</p>
        <p>See console for more details.</p>
      </div>
    `;
  }
}
