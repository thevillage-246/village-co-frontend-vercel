/**
 * The Village Co brand colors
 * Used for consistent theming across the application
 */

export const colors = {
  linen: '#F9F5F0',
  rose: '#EBD3CB',
  wine: '#6B3E4B',
  taupe: '#B8A89F',
  eucalyptus: '#C7D1C5',
};

/**
 * Formats a color with opacity
 * @param color The color to format
 * @param opacity The opacity (0-100)
 * @returns The formatted color string with opacity
 */
export const withOpacity = (color: string, opacity: number): string => {
  return `${color}${Math.floor(opacity / 100 * 255).toString(16).padStart(2, '0')}`;
};

/**
 * CSS color variables for use in styled components or inline styles
 */
export const cssVars = {
  linen: 'var(--color-linen)',
  rose: 'var(--color-rose)',
  wine: 'var(--color-wine)',
  taupe: 'var(--color-taupe)',
  eucalyptus: 'var(--color-eucalyptus)',
};