import React from 'react';
import { Switch, Route, Link, useLocation } from 'wouter';
import SimpleUI from './SimpleUI';

// Navigation component to be included on all pages
const Navigation = () => {
  const [location] = useLocation();
  
  return (
    <div style={{ marginBottom: '20px' }}>
      <div style={{ 
        padding: '10px', 
        background: '#f0f0f0', 
        borderRadius: '4px',
        marginBottom: '10px'
      }}>
        <strong>Current Path:</strong> {location}
      </div>
      
      <nav>
        <ul style={{ display: 'flex', gap: '15px', listStyle: 'none', padding: 0 }}>
          <li>
            <Link href="/">
              <span style={{ color: '#6B3E4B', textDecoration: 'underline', cursor: 'pointer' }}>Home</span>
            </Link>
          </li>
          <li>
            <Link href="/about">
              <span style={{ color: '#6B3E4B', textDecoration: 'underline', cursor: 'pointer' }}>About</span>
            </Link>
          </li>
          <li>
            <Link href="/ui-test">
              <span style={{ color: '#6B3E4B', textDecoration: 'underline', cursor: 'pointer' }}>UI Test</span>
            </Link>
          </li>
        </ul>
      </nav>
    </div>
  );
};

const HomePage = () => (
  <div style={{ 
    padding: '20px', 
    maxWidth: '800px', 
    margin: '0 auto', 
    fontFamily: 'sans-serif', 
    color: '#333' 
  }}>
    <Navigation />
    <h1 style={{ color: '#6B3E4B' }}>Home Page</h1>
    <p>This is the home page of the Simple Router test.</p>
    <div style={{ 
      padding: '15px',
      background: '#f7f7f7',
      border: '1px solid #ddd',
      borderRadius: '4px',
      marginTop: '20px'
    }}>
      <h2>Router Testing</h2>
      <p>✅ The router is working if you can see this message on the home page</p>
    </div>
  </div>
);

const AboutPage = () => (
  <div style={{ 
    padding: '20px', 
    maxWidth: '800px', 
    margin: '0 auto', 
    fontFamily: 'sans-serif', 
    color: '#333' 
  }}>
    <Navigation />
    <h1 style={{ color: '#6B3E4B' }}>About Page</h1>
    <p>This is the about page of the Simple Router test.</p>
    <div style={{ 
      padding: '15px',
      background: '#f7f7f7',
      border: '1px solid #ddd',
      borderRadius: '4px',
      marginTop: '20px'
    }}>
      <h2>Router Testing</h2>
      <p>✅ The router navigation is working if you can see this message on the about page</p>
    </div>
  </div>
);

const SimpleRouter: React.FC = () => {
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/about" component={AboutPage} />
      <Route path="/ui-test" component={SimpleUI} />
    </Switch>
  );
};

export default SimpleRouter;