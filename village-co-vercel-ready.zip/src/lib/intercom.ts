/**
 * Intercom Chat Integration for The Village Co
 * Provides customer support chat functionality using official Intercom SDK
 */

import Intercom from '@intercom/messenger-js-sdk';

// Declare global types for Intercom
declare global {
  interface Window {
    Intercom?: (...args: any[]) => void;
  }
}

export interface IntercomUser {
  user_id?: string;
  email?: string;
  name?: string;
  created_at?: number;
  custom_attributes?: {
    role?: 'parent' | 'sitter' | 'admin';
    location?: string;
    subscription_plan?: string;
    verification_status?: string;
    total_bookings?: number;
  };
}

export class IntercomService {
  private static instance: IntercomService;
  private appId: string;

  constructor() {
    this.appId = import.meta.env.VITE_INTERCOM_APP_ID || 'y1niyht1';
  }

  static getInstance(): IntercomService {
    if (!IntercomService.instance) {
      IntercomService.instance = new IntercomService();
    }
    return IntercomService.instance;
  }

  /**
   * Initialize Intercom with user data and JWT authentication
   */
  async initialize(user?: IntercomUser): Promise<void> {
    if (!this.appId) {
      console.warn('Intercom App ID not found');
      return;
    }

    try {
      // Check for any existing Intercom instances and log them
      if (typeof window !== 'undefined' && window.Intercom) {
        console.log('Existing Intercom instance detected, shutting down...');
      }
      
      // Clear any DOM elements from other Intercom instances
      this.forceCleanupExistingIntercom();
      
      // First, ensure any existing Intercom instances are shut down
      this.shutdown();
      
      // Small delay to ensure cleanup is complete
      await new Promise(resolve => setTimeout(resolve, 200));
      
      // Detect mobile device
      const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
      
      const baseConfig = {
        app_id: this.appId,
        custom_attributes: {
          device_type: isMobile ? 'mobile' : 'desktop',
          platform: this.getPlatformInfo(),
          screen_size: `${window.screen.width}x${window.screen.height}`,
          user_agent: navigator.userAgent
        }
      };

      // Use the official SDK method with mobile optimizations
      if (user && user.user_id && user.email) {
        const intercomConfig: any = {
          ...baseConfig,
          user_id: user.user_id,
          name: user.name,
          email: user.email,
          created_at: user.created_at,
          custom_attributes: {
            ...baseConfig.custom_attributes,
            ...user.custom_attributes
          }
        };

        // Get JWT token for authenticated users
        try {
          const token = localStorage.getItem('token');
          if (token) {
            const response = await fetch('/api/auth/intercom-token', {
              headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
              }
            });

            if (response.ok) {
              const tokenData = await response.json();
              intercomConfig.user_hash = tokenData.token;
              console.log('Intercom JWT authentication enabled');
            }
          }
        } catch (tokenError) {
          console.warn('Could not obtain Intercom JWT token:', tokenError);
          // Continue without JWT - Intercom will work in identified mode without signature verification
        }

        Intercom(intercomConfig);
      } else {
        // Initialize for anonymous users with mobile detection
        Intercom(baseConfig);
      }

      // Set mobile-specific configurations
      if (isMobile) {
        this.configureMobileSettings();
      }
    } catch (error) {
      console.warn('Intercom initialization failed:', error);
    }
  }

  /**
   * Show Intercom messenger
   */
  show(): void {
    if (typeof window !== 'undefined' && window.Intercom) {
      window.Intercom('show');
    }
  }

  /**
   * Hide Intercom messenger
   */
  hide(): void {
    if (typeof window !== 'undefined' && window.Intercom) {
      window.Intercom('hide');
    }
  }

  /**
   * Show new message composer
   */
  showNewMessage(message?: string): void {
    if (typeof window !== 'undefined' && window.Intercom) {
      if (message) {
        window.Intercom('showNewMessage', message);
      } else {
        window.Intercom('showNewMessage');
      }
    }
  }

  /**
   * Track custom events
   */
  trackEvent(eventName: string, metadata?: Record<string, any>): void {
    if (typeof window !== 'undefined' && window.Intercom) {
      window.Intercom('trackEvent', eventName, metadata);
    }
  }

  /**
   * Update user information
   */
  update(userData: Partial<IntercomUser>): void {
    if (typeof window !== 'undefined' && window.Intercom) {
      window.Intercom('update', userData);
    }
  }

  /**
   * Shutdown Intercom (for logout) - Enhanced cleanup
   */
  shutdown(): void {
    if (typeof window !== 'undefined' && window.Intercom) {
      try {
        // Multiple shutdown attempts to ensure cleanup
        window.Intercom('shutdown');
        window.Intercom('hide');
        
        // Force cleanup of global Intercom reference
        const intercomElement = document.querySelector('#intercom-frame');
        if (intercomElement) {
          intercomElement.remove();
        }
        
        // Clear any launcher elements
        const launcherElements = document.querySelectorAll('[id*="intercom"]');
        launcherElements.forEach(el => el.remove());
        
        console.log('Intercom cleanup completed for app ID:', this.appId);
      } catch (error) {
        console.warn('Intercom shutdown error (continuing):', error);
      }
    }
  }

  /**
   * Check if Intercom is ready
   */
  isReady(): boolean {
    return !!this.appId && typeof window !== 'undefined' && !!window.Intercom;
  }

  /**
   * Force cleanup of any existing Intercom instances from other sources
   */
  private forceCleanupExistingIntercom(): void {
    try {
      // Remove all Intercom-related DOM elements
      const selectors = [
        '#intercom-frame',
        '[id*="intercom"]',
        '[class*="intercom"]',
        '.intercom-launcher',
        '.intercom-messenger-frame',
        '.intercom-container'
      ];
      
      selectors.forEach(selector => {
        const elements = document.querySelectorAll(selector);
        elements.forEach(el => {
          console.log(`Removing conflicting Intercom element: ${selector}`);
          el.remove();
        });
      });
      
      // Also clear any scripts that might be loading conflicting instances
      const scripts = document.querySelectorAll('script[src*="intercom"]');
      scripts.forEach(script => {
        const src = script.getAttribute('src');
        if (src && !src.includes(this.appId)) {
          console.log(`Removing conflicting Intercom script: ${src}`);
          script.remove();
        }
      });
      
    } catch (error) {
      console.warn('Error during force cleanup:', error);
    }
  }

  /**
   * Get platform information for mobile optimization
   */
  private getPlatformInfo(): string {
    const userAgent = navigator.userAgent;
    
    if (/iPhone|iPad|iPod/i.test(userAgent)) {
      return 'iOS';
    } else if (/Android/i.test(userAgent)) {
      return 'Android';
    } else if (/Windows/i.test(userAgent)) {
      return 'Windows';
    } else if (/Mac/i.test(userAgent)) {
      return 'macOS';
    } else {
      return 'Unknown';
    }
  }

  /**
   * Configure mobile-specific Intercom settings
   */
  private configureMobileSettings(): void {
    if (typeof window !== 'undefined' && window.Intercom) {
      // Enable mobile-optimized features
      window.Intercom('update', {
        hide_default_launcher: false,
        horizontal_padding: 20,
        vertical_padding: 20
      });

      // Set launcher visibility for mobile
      this.setLauncherVisibility(true);
    }
  }

  /**
   * Set launcher visibility (mobile-friendly)
   */
  setLauncherVisibility(visible: boolean): void {
    if (typeof window !== 'undefined' && window.Intercom) {
      if (visible) {
        window.Intercom('update', { hide_default_launcher: false });
      } else {
        window.Intercom('update', { hide_default_launcher: true });
      }
    }
  }

  /**
   * Open help article (mobile-optimized)
   */
  showArticle(articleId: string): void {
    if (typeof window !== 'undefined' && window.Intercom) {
      window.Intercom('showArticle', articleId);
    }
  }

  /**
   * Check if device is mobile
   */
  isMobileDevice(): boolean {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
  }

  /**
   * Initialize with unidentified user (mobile equivalent)
   */
  loginUnidentifiedUser(): void {
    try {
      Intercom({
        app_id: this.appId,
        custom_attributes: {
          device_type: this.isMobileDevice() ? 'mobile' : 'desktop',
          platform: this.getPlatformInfo(),
          session_type: 'unidentified'
        }
      });

      if (this.isMobileDevice()) {
        this.configureMobileSettings();
      }
    } catch (error) {
      console.warn('Intercom unidentified login failed:', error);
    }
  }
}

// Export singleton instance
export const intercom = IntercomService.getInstance();

// Export utility functions
export const initializeIntercom = (user?: IntercomUser) => intercom.initialize(user);
export const showIntercomMessenger = () => intercom.show();
export const trackIntercomEvent = (event: string, metadata?: Record<string, any>) => 
  intercom.trackEvent(event, metadata);

// Mobile-specific exports (matching React Native API)
export const loginUnidentifiedUser = () => intercom.loginUnidentifiedUser();
export const setLauncherVisibility = (visible: boolean) => intercom.setLauncherVisibility(visible);
export const isMobileDevice = () => intercom.isMobileDevice();
export const showNewMessage = (message?: string) => intercom.showNewMessage(message);
export const updateUser = (userData: Partial<IntercomUser>) => intercom.update(userData);

// Visibility enum for React Native compatibility
export enum Visibility {
  VISIBLE = 'VISIBLE',
  GONE = 'GONE'
}