// User and badge types
export interface User {
  id: number;
  email: string;
  firstName: string;
  lastName: string;
  role: string;
  createdAt: string;
  updatedAt: string;
  referredBy?: number | null;
  badge?: string | null;
  referralBadge?: string | null;
  stripeCustomerId?: string | null;
  stripeConnectId?: string | null;
}

// WebSocket connection status
export type WebSocketStatus = "connected" | "disconnected" | "error" | "connecting";

// Badge configuration
export const BADGE_TYPES = {
  SITTER_BADGES: ['Super Sitter', 'Elite Caregiver', 'Trusted Expert'],
  REFERRAL_BADGES: ['Bronze Referrer', 'Silver Referrer', 'Gold Referrer']
};

// Badge type mapping to descriptions
export const BADGE_DESCRIPTIONS = {
  'Super Sitter': 'Consistently high-rated babysitter',
  'Elite Caregiver': '10+ completed bookings with 4.7+ average rating',
  'Trusted Expert': '20+ completed bookings with 4.8+ average rating',
  'Bronze Referrer': '3+ successful referrals',
  'Silver Referrer': '5+ successful referrals',
  'Gold Referrer': '10+ successful referrals'
};