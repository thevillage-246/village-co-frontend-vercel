import { Loader } from '@googlemaps/js-api-loader';

let googleMapsLoader: Loader | null = null;
let isLoaded = false;

export const initializeGoogleMaps = async () => {
  if (isLoaded) return;
  
  if (!import.meta.env.VITE_GOOGLE_MAPS_API_KEY) {
    throw new Error('Google Maps API key not found');
  }

  if (!googleMapsLoader) {
    googleMapsLoader = new Loader({
      apiKey: import.meta.env.VITE_GOOGLE_MAPS_API_KEY,
      version: "weekly",
      libraries: ["places", "geometry"]
    });
  }

  try {
    await googleMapsLoader.load();
    isLoaded = true;
  } catch (error) {
    console.error('Failed to load Google Maps:', error);
    throw error;
  }
};

export const isGoogleMapsLoaded = () => isLoaded;

// Geocode an address to get coordinates
export const geocodeAddress = async (address: string): Promise<google.maps.LatLngLiteral | null> => {
  if (!isLoaded) await initializeGoogleMaps();
  
  const geocoder = new google.maps.Geocoder();
  
  return new Promise((resolve) => {
    geocoder.geocode({ address }, (results, status) => {
      if (status === 'OK' && results?.[0]) {
        const location = results[0].geometry.location;
        resolve({
          lat: location.lat(),
          lng: location.lng()
        });
      } else {
        resolve(null);
      }
    });
  });
};

// Get address from coordinates
export const reverseGeocode = async (lat: number, lng: number): Promise<string | null> => {
  if (!isLoaded) await initializeGoogleMaps();
  
  const geocoder = new google.maps.Geocoder();
  
  return new Promise((resolve) => {
    geocoder.geocode({ location: { lat, lng } }, (results, status) => {
      if (status === 'OK' && results?.[0]) {
        resolve(results[0].formatted_address);
      } else {
        resolve(null);
      }
    });
  });
};

// Calculate distance between two points
export const calculateDistance = (
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number => {
  const R = 6371; // Earth's radius in kilometers
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLng = (lng2 - lng1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLng/2) * Math.sin(dLng/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c;
};