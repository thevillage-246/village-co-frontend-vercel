import { loadStripe } from '@stripe/stripe-js';

const stripePublicKey = import.meta.env.VITE_STRIPE_PUBLIC_KEY || '';

if (!stripePublicKey) {
  console.warn('Missing Stripe public key. Make sure to set VITE_STRIPE_PUBLIC_KEY.');
}

let stripePromise: Promise<any> | null = null;

export const getStripe = () => {
  if (!stripePromise) {
    stripePromise = loadStripe(stripePublicKey);
  }
  return stripePromise;
};

export async function createCustomerAndConnectAccount(userId: number) {
  try {
    const response = await fetch(`/api/users/${userId}/create-stripe-account`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      credentials: 'include',
    });

    if (!response.ok) {
      throw new Error('Failed to create Stripe account');
    }

    const data = await response.json();
    return data;
  } catch (error) {
    console.error('Error creating Stripe account:', error);
    throw error;
  }
}

export async function createConnectLoginLink(userId: number, returnUrl?: string) {
  try {
    const response = await fetch(`/api/users/${userId}/create-connect-login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ returnUrl }),
      credentials: 'include',
    });

    if (!response.ok) {
      throw new Error('Failed to create Connect login link');
    }

    const data = await response.json();
    return data.url;
  } catch (error) {
    console.error('Error creating Connect login link:', error);
    throw error;
  }
}

export async function createPaymentIntent(bookingId: number) {
  try {
    const response = await fetch('/api/create-payment-intent', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ bookingId }),
      credentials: 'include',
    });

    if (!response.ok) {
      throw new Error('Failed to create payment intent');
    }

    const data = await response.json();
    return data.clientSecret;
  } catch (error) {
    console.error('Error creating payment intent:', error);
    throw error;
  }
}
