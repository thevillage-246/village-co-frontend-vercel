// GrowSurf Integration for The Village Co.
// Campaign ID: 2irxbh

declare global {
  interface Window {
    grsfSettings: {
      campaignId: string;
      version: string;
    };
    growsurf: any;
    grsfInit?: boolean;
  }
}

// Initialize GrowSurf tracking script
export function initGrowSurf() {
  if (typeof window === 'undefined') return;
  
  // Set up GrowSurf settings
  window.grsfSettings = {
    campaignId: "2irxbh",
    version: "2.0.0"
  };

  // Load GrowSurf script if not already loaded
  if (!window.grsfInit) {
    const head = document.getElementsByTagName("head")[0];
    const script = document.createElement("script");
    script.async = true;
    script.src = `https://app.growsurf.com/growsurf.js?v=${window.grsfSettings.version}`;
    script.setAttribute("grsf-campaign", window.grsfSettings.campaignId);
    head.appendChild(script);
    window.grsfInit = true;
  }
}

// Track referral events
export function trackGrowSurfEvent(event: string, participantId?: string, data?: any) {
  if (typeof window === 'undefined' || !window.growsurf) {
    console.log('GrowSurf not loaded yet, queueing event:', event);
    return;
  }

  try {
    window.growsurf(event, participantId, data);
  } catch (error) {
    console.error('GrowSurf tracking error:', error);
  }
}

// Create participant (when user signs up)
export function createGrowSurfParticipant(email: string, firstName?: string, lastName?: string) {
  trackGrowSurfEvent('createParticipant', email, {
    email,
    firstName,
    lastName,
    campaignId: "2irxbh"
  });
}

// Track conversion (when referred user completes desired action)
export function trackGrowSurfConversion(email: string, conversionId?: string) {
  trackGrowSurfEvent('conversion', email, {
    conversionId: conversionId || 'signup',
    campaignId: "2irxbh"
  });
}

// Get referral link for a participant
export function getGrowSurfReferralLink(email: string): string {
  return `https://thevillageco.nz/signup?grsf=${email}`;
}