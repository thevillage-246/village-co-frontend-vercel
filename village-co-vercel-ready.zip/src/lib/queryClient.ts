import { QueryClient, QueryFunction } from "@tanstack/react-query";

async function throwIfResNotOk(res: Response) {
  if (!res.ok) {
    const text = (await res.text()) || res.statusText;
    throw new Error(`${res.status}: ${text}`);
  }
}

// Get API base URL from environment variable
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000';

export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
  options?: RequestInit
): Promise<Response> {
  console.log('🔍 ApiRequest called with:', {
    method: method,
    methodType: typeof method,
    url: url,
    urlType: typeof url,
    data: data,
    dataType: typeof data
  });
  
  // Validate parameters
  if (typeof method !== 'string') {
    throw new Error(`Invalid method parameter: ${typeof method}, value: ${method}`);
  }
  if (typeof url !== 'string') {
    throw new Error(`Invalid url parameter: ${typeof url}, value: ${url}`);
  }

  // Get JWT token from localStorage if available (check both locations)
  const token = localStorage.getItem('auth_token') || localStorage.getItem('authToken');
  console.log('apiRequest token check:', { 
    token: !!token, 
    tokenValue: token ? `${token.substring(0, 20)}...` : 'none',
    method, 
    url 
  });
  
  const headers = {
    ...(data ? { "Content-Type": "application/json" } : {}),
    ...(token ? { "Authorization": `Bearer ${token}` } : {}),
    ...(options?.headers || {})
  };
  
  console.log('apiRequest headers:', { 
    hasAuth: !!headers.Authorization, 
    hasContent: !!headers['Content-Type'],
    authHeader: headers.Authorization ? `${headers.Authorization.substring(0, 20)}...` : 'none',
    tokenUsed: !!token,
    url 
  });

  // Create a new options object without the headers property
  const { headers: _, ...otherOptions } = options || {};

  const fetchOptions = {
    method,
    headers,  // Use our merged headers
    body: data ? JSON.stringify(data) : undefined,
    credentials: "include" as RequestCredentials,
    ...otherOptions  // Spread the rest of the options
  };

  // Construct full URL if it's a relative path
  const fullUrl = url.startsWith('http') ? url : `${API_BASE_URL}${url}`;
  
  const res = await fetch(fullUrl, fetchOptions);

  // Skip throwing errors if skipErrorCheck is true
  if (!options?.signal?.aborted) {
    await throwIfResNotOk(res);
  }
  
  return res;
}

type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    // Get JWT token from localStorage if available (check both locations)
    const token = localStorage.getItem('auth_token') || localStorage.getItem('authToken');
    
    const headers: Record<string, string> = {};
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    // Construct full URL for query key
    const queryUrl = queryKey[0] as string;
    const fullQueryUrl = queryUrl.startsWith('http') ? queryUrl : `${API_BASE_URL}${queryUrl}`;
    
    const res = await fetch(fullQueryUrl, {
      credentials: "include",
      headers,
    });

    if (unauthorizedBehavior === "returnNull" && res.status === 401) {
      return null;
    }

    await throwIfResNotOk(res);
    return await res.json();
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "returnNull" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});
