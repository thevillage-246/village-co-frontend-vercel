import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, signInWithRedirect, getRedirectResult, signOut } from "firebase/auth";

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: `${import.meta.env.VITE_FIREBASE_PROJECT_ID}.firebaseapp.com`,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: `${import.meta.env.VITE_FIREBASE_PROJECT_ID}.firebasestorage.app`,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

// Configure Google provider
googleProvider.setCustomParameters({
  prompt: 'select_account'
});

export const signInWithGoogle = async () => {
  try {
    // Use redirect instead of popup for better Replit compatibility
    await signInWithRedirect(auth, googleProvider);
  } catch (error) {
    console.error('Google sign-in error:', error);
    throw error;
  }
};

export const handleRedirectResult = async () => {
  try {
    // Clear any previous error flags since we're attempting auth again
    window.localStorage.removeItem('firebase-operation-error');
    window.localStorage.removeItem('firebase-domain-error');
    
    // Check if we're in a redirect scenario first
    if (window.location.search.includes('apiKey') || window.location.search.includes('authDomain')) {
      console.log('🔥 Firebase: Detected redirect parameters, processing...');
    }
    
    const result = await getRedirectResult(auth);
    
    if (result?.user) {
      console.log('🔥 Firebase: Redirect result successful for user:', result.user.email);
    } else {
      console.log('🔥 Firebase: No redirect result found');
    }
    
    return result?.user || null;
  } catch (error: any) {
    console.error('🔥 Firebase: Redirect result error:', error);
    
    // Handle specific Firebase auth errors
    if (error.code === 'auth/unauthorized-domain') {
      console.error('🔥 Firebase: Domain not authorized. Current domain needs to be added to Firebase Console.');
      window.localStorage.setItem('firebase-domain-error', 'true');
    } else if (error.code === 'auth/operation-not-allowed') {
      console.error('🔥 Firebase: Google sign-in not enabled in Firebase Console.');
      window.localStorage.setItem('firebase-operation-error', 'true');
    }
    
    throw error;
  }
};

export const signOutFromFirebase = async () => {
  try {
    await signOut(auth);
  } catch (error) {
    console.error('Sign out error:', error);
    throw error;
  }
};