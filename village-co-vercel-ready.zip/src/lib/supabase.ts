import { createClient } from '@supabase/supabase-js';

// Get Supabase credentials from environment variables
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

// Production fallback for deployment - use secrets when available
const productionUrl = supabaseUrl || 'https://phfkjgonezwsradgnmij.supabase.co';
const productionKey = supabaseAnonKey || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBoZmtqZ29uZXp3c3JhZGdubWlqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDY3NDM4MDcsImV4cCI6MjA2MjMxOTgwN30.StwNAit03gGyCH5i8xuywpOQH0I5JEsLgbyStjl3CyI';

// Create a single supabase client for interacting with your database
export const supabase = createClient(productionUrl, productionKey, {
  auth: {
    // Enable session persistence in localStorage
    storage: window.localStorage,
    storageKey: 'village-co-auth-token',
    // Auto refresh tokens before they expire
    autoRefreshToken: true,
    // Persist sessions across browser tabs
    persistSession: true,
    // Detect session in other tabs
    detectSessionInUrl: true,
  },
  // Configure for production deployment
  global: {
    headers: {
      'X-Client-Info': 'the-village-co-web@1.0.0',
    },
  },
});