import React from 'react';
import { useAuth } from '@/contexts/AuthContext';

interface SimpleLayoutProps {
  children: React.ReactNode;
}

const SimpleLayout: React.FC<SimpleLayoutProps> = ({ children }) => {
  const { user, isLoading } = useAuth();

  // Show auth state in the layout
  const authStatus = isLoading 
    ? 'Loading auth state...' 
    : user 
      ? `Logged in as: ${user.email || 'Unknown User'}` 
      : 'Not logged in';

  return (
    <div style={{ 
      display: 'flex', 
      flexDirection: 'column', 
      minHeight: '100vh'
    }}>
      <header style={{ 
        background: '#6B3E4B', 
        color: 'white', 
        padding: '1rem',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }}>
        <h1>The Village Co</h1>
        <div>{authStatus}</div>
      </header>
      <main style={{ 
        flex: '1', 
        padding: '1rem' 
      }}>
        {children}
      </main>
      <footer style={{ 
        background: '#6B3E4B', 
        color: 'white', 
        padding: '1rem',
        textAlign: 'center'
      }}>
        &copy; {new Date().getFullYear()} The Village Co.
      </footer>
    </div>
  );
};

export default SimpleLayout;