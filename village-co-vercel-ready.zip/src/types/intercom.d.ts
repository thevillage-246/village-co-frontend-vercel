declare global {
  interface Window {
    Intercom?: (method: string, ...args: any[]) => void;
    intercomSettings?: any;
  }
}

export interface IntercomUser {
  user_id?: string;
  name?: string;
  email?: string;
  created_at?: number;
  custom_attributes?: Record<string, any>;
}

export {};