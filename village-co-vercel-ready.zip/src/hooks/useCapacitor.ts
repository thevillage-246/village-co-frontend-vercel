import { useState, useEffect } from 'react';
import { capacitorIntegration } from '@/utils/capacitor';

interface CapacitorState {
  isNative: boolean;
  platform: string;
  isReady: boolean;
  deviceInfo: any;
  networkStatus: any;
  appInfo: any;
}

export const useCapacitor = () => {
  const [state, setState] = useState<CapacitorState>({
    isNative: false,
    platform: 'web',
    isReady: false,
    deviceInfo: null,
    networkStatus: null,
    appInfo: null
  });

  useEffect(() => {
    const initializeCapacitor = async () => {
      try {
        // Initialize Capacitor
        await capacitorIntegration.initialize();

        // Get platform info
        const isNative = capacitorIntegration.isNative();
        const platform = capacitorIntegration.getPlatform();

        // Get device info (if native)
        const deviceInfo = isNative ? await capacitorIntegration.getDeviceInfo() : null;
        const networkStatus = await capacitorIntegration.getNetworkStatus();
        const appInfo = isNative ? await capacitorIntegration.getAppInfo() : null;

        setState({
          isNative,
          platform,
          isReady: true,
          deviceInfo,
          networkStatus,
          appInfo
        });

        console.log('Capacitor state initialized:', {
          isNative,
          platform,
          deviceInfo,
          networkStatus,
          appInfo
        });
      } catch (error) {
        console.error('Error initializing Capacitor:', error);
        setState(prev => ({ ...prev, isReady: true }));
      }
    };

    initializeCapacitor();
  }, []);

  const takePicture = async (): Promise<string | null> => {
    return await capacitorIntegration.takePicture();
  };

  const getCurrentLocation = async (): Promise<{lat: number, lng: number} | null> => {
    return await capacitorIntegration.getCurrentPosition();
  };

  const shareContent = async (title: string, text: string, url?: string): Promise<boolean> => {
    return await capacitorIntegration.shareContent(title, text, url);
  };

  const scheduleNotification = async (
    title: string, 
    body: string, 
    id: number,
    schedule?: Date
  ): Promise<boolean> => {
    return await capacitorIntegration.scheduleNotification(title, body, id, schedule);
  };

  return {
    ...state,
    takePicture,
    getCurrentLocation,
    shareContent,
    scheduleNotification,
    capacitor: capacitorIntegration
  };
};