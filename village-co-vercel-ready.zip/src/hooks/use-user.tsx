import { useAuth } from '@/contexts/AuthContext';

export function useUser() {
  const { user, isAuthenticated, isLoading } = useAuth();
  
  return {
    user,
    isAuthenticated,
    isLoading
  };
}