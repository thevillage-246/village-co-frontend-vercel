import { useState, useEffect } from 'react';
import { signInWithGoogle, handleRedirectResult } from '@/lib/firebase';
import { useAuth } from '@/contexts/AuthContext';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

export function useGoogleAuth() {
  const [isLoading, setIsLoading] = useState(false);
  const { login } = useAuth();
  const { toast } = useToast();

  // Check for redirect result on component mount
  useEffect(() => {
    const checkRedirectResult = async () => {
      try {
        const firebaseUser = await handleRedirectResult();
        
        if (firebaseUser && firebaseUser.email) {
          console.log('🔥 Google Auth: Processing redirect for user:', firebaseUser.email);
          setIsLoading(true);
          
          // Try to sign in with existing account first
          try {
            const loginResponse = await apiRequest("POST", "/api/auth/google-login", {
              email: firebaseUser.email,
              googleId: firebaseUser.uid,
              name: firebaseUser.displayName || '',
              photoUrl: firebaseUser.photoURL || null,
            });

            if (loginResponse.ok) {
              const data = await loginResponse.json();
              login(data.user);
              toast({
                title: "Welcome back!",
                description: "Successfully signed in with Google.",
              });
              setIsLoading(false);
              return;
            }
          } catch (loginError) {
            // Account doesn't exist, so create new one
            console.log('🔥 Google Auth: Account not found, creating new account');
          }

          // Create new account
          const registerResponse = await apiRequest("POST", "/api/auth/google-register", {
            email: firebaseUser.email,
            googleId: firebaseUser.uid,
            name: firebaseUser.displayName || '',
            photoUrl: firebaseUser.photoURL || null,
          });

          if (registerResponse.ok) {
            const data = await registerResponse.json();
            login(data.user);
            toast({
              title: "Welcome to The Village Co!",
              description: "Your account has been created successfully.",
            });
            setIsLoading(false);
          } else {
            const errorData = await registerResponse.json();
            throw new Error(errorData.message || 'Failed to create account');
          }
        }
      } catch (error: any) {
        console.error('Google redirect authentication error:', error);
        
        let errorMessage = "Failed to complete Google sign-in.";
        let errorTitle = "Authentication Failed";
        
        if (error.code === 'auth/operation-not-allowed') {
          errorTitle = "Google Sign-in Not Enabled";
          errorMessage = "Google sign-in method needs to be enabled in Firebase Console. Please check the setup guide below.";
          window.localStorage.setItem('firebase-operation-error', 'true');
        } else if (error.code === 'auth/unauthorized-domain') {
          errorTitle = "Domain Not Authorized";
          errorMessage = "This domain needs to be added to Firebase authorized domains. Please check the setup guide below.";
          window.localStorage.setItem('firebase-domain-error', 'true');
        }
        
        toast({
          title: errorTitle,
          description: errorMessage,
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    };

    checkRedirectResult();
  }, [login, toast]);

  const handleGoogleSignIn = async () => {
    console.log('🔥 Google Auth: Starting sign-in process');
    setIsLoading(true);
    
    try {
      // This will redirect to Google
      console.log('🔥 Google Auth: Initiating Firebase redirect');
      await signInWithGoogle();
      console.log('🔥 Google Auth: Redirect initiated successfully');
    } catch (error: any) {
      console.error('🔥 Google Auth: Sign-in error:', error);
      toast({
        title: "Authentication Failed",
        description: error.message || "Failed to start Google sign-in. Please try again.",
        variant: "destructive",
      });
      setIsLoading(false);
    }
  };

  return {
    handleGoogleSignIn,
    isLoading,
  };
}