import { useState } from 'react';
import { apiRequest } from '@/lib/queryClient';

interface TestAuthResponse {
  id: number;
  email: string;
  role: string;
  firstName: string;
  lastName: string;
  token: string;
}

export function useTestLogin() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const login = async (email: string, password: string): Promise<TestAuthResponse | null> => {
    setIsLoading(true);
    setError(null);
    
    try {
      const response = await apiRequest('POST', '/api/auth/login', { email, password });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Login failed');
      }
      
      const userData = await response.json();
      
      // Store auth token in localStorage
      localStorage.setItem('authToken', userData.token);
      
      return userData;
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred');
      return null;
    } finally {
      setIsLoading(false);
    }
  };
  
  const logout = () => {
    localStorage.removeItem('authToken');
  };
  
  return {
    login,
    logout,
    isLoading,
    error
  };
}