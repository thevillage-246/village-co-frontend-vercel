import { useEffect, useState } from 'react';
import { intercom } from '@/lib/intercom';
import { useAuth } from '@/contexts/AuthContext';

export const useIntercom = () => {
  const [isReady, setIsReady] = useState(false);
  const { user } = useAuth();

  useEffect(() => {
    const initializeIntercom = async () => {
      try {
        // Initialize Intercom when the hook is first used
        if (user && user.id && user.firstName && user.lastName && user.email && user.createdAt) {
          const intercomUser = {
            user_id: user.id.toString(),
            name: `${user.firstName} ${user.lastName}`,
            email: user.email,
            created_at: Math.floor(new Date(user.createdAt).getTime() / 1000),
            custom_attributes: {
              role: user.role,
            },
          };
          
          await intercom.initialize(intercomUser);
        } else {
          // Initialize for anonymous users
          await intercom.initialize();
        }

        // Set ready state after initialization
        setTimeout(() => {
          setIsReady(intercom.isReady());
        }, 1000);
      } catch (error) {
        console.warn('useIntercom initialization error:', error);
        // Always show the button even if Intercom fails
        setIsReady(false);
      }
    };

    initializeIntercom();
  }, [user]);

  return {
    isReady,
    showMessenger: () => {
      try {
        intercom.show();
      } catch (error) {
        console.warn('Failed to show Intercom messenger:', error);
      }
    },
    hideMessenger: () => {
      try {
        intercom.hide();
      } catch (error) {
        console.warn('Failed to hide Intercom messenger:', error);
      }
    },
    showNewMessage: (message?: string) => {
      try {
        intercom.showNewMessage(message);
      } catch (error) {
        console.warn('Failed to show new message:', error);
      }
    },
    trackEvent: (eventName: string, metadata?: Record<string, any>) => {
      try {
        intercom.trackEvent(eventName, metadata);
      } catch (error) {
        console.warn('Failed to track event:', error);
      }
    },
    updateUser: (userData: any) => {
      try {
        intercom.update(userData);
      } catch (error) {
        console.warn('Failed to update user:', error);
      }
    },
    shutdown: () => {
      try {
        intercom.shutdown();
      } catch (error) {
        console.warn('Failed to shutdown Intercom:', error);
      }
    },
  };
};