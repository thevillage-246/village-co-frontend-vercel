import { useState, useEffect } from 'react';

interface PWAUpdateHook {
  updateAvailable: boolean;
  updateApp: () => Promise<void>;
  skipUpdate: () => void;
}

export const usePWAUpdate = (): PWAUpdateHook => {
  const [updateAvailable, setUpdateAvailable] = useState(false);
  const [registration, setRegistration] = useState<ServiceWorkerRegistration | null>(null);

  useEffect(() => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.ready.then((reg) => {
        setRegistration(reg);

        // Check for updates every 60 seconds
        const checkForUpdates = () => {
          reg.update().catch(console.error);
        };

        const interval = setInterval(checkForUpdates, 60000);

        return () => clearInterval(interval);
      });

      // Listen for new service worker installations
      navigator.serviceWorker.addEventListener('controllerchange', () => {
        // This will trigger when a new service worker takes control
        // We should reload the page to get the latest content
        window.location.reload();
      });

      // Listen for update found events
      const handleUpdateFound = () => {
        const installing = registration?.installing;
        if (installing) {
          installing.addEventListener('statechange', () => {
            if (installing.state === 'installed') {
              if (navigator.serviceWorker.controller) {
                // New content is available; show update prompt
                setUpdateAvailable(true);
              }
            }
          });
        }
      };

      // Check for waiting service worker
      navigator.serviceWorker.ready.then((reg) => {
        if (reg.waiting) {
          setUpdateAvailable(true);
        }

        reg.addEventListener('updatefound', handleUpdateFound);
      });
    }
  }, [registration]);

  const updateApp = async (): Promise<void> => {
    if (!registration?.waiting) {
      return;
    }

    // Tell the waiting service worker to skip waiting and become active
    registration.waiting.postMessage({ type: 'SKIP_WAITING' });
    
    // The page will reload automatically when the new service worker takes control
    setUpdateAvailable(false);
  };

  const skipUpdate = (): void => {
    setUpdateAvailable(false);
    // Store that user skipped this update
    localStorage.setItem('pwa-update-skipped', Date.now().toString());
  };

  return {
    updateAvailable,
    updateApp,
    skipUpdate
  };
};

export default usePWAUpdate;