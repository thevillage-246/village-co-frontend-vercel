import { useState, useCallback } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { SitterProfile } from '@shared/schema';

interface VerificationStatus {
  status: string;
  verificationId?: string | null;
  identityVerified?: boolean;
  verificationDate?: string | null;
  verificationUrl?: string;
}

/**
 * Hook to manage the sitter verification process
 */
export function useSitterVerification(userId: number) {
  const [isInitiating, setIsInitiating] = useState(false);
  const [verificationUrl, setVerificationUrl] = useState<string | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Query for getting the current verification status
  const { data, isLoading, error } = useQuery<VerificationStatus>({
    queryKey: ['/api/sitter-verification/status'],
    queryFn: async () => {
      const response = await apiRequest('GET', '/api/sitter-verification/status');
      return response.json();
    },
    enabled: !!userId,
  });

  // Mutation for initiating the verification process
  const { mutate: startVerification } = useMutation({
    mutationFn: async () => {
      setIsInitiating(true);
      try {
        const response = await apiRequest('POST', '/api/sitter-verification/start', {});
        const data = await response.json();
        
        if (data.url) {
          setVerificationUrl(data.url);
          return data;
        } else {
          throw new Error('No verification URL returned');
        }
      } finally {
        setIsInitiating(false);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/sitter-verification/status'] });
      queryClient.invalidateQueries({ queryKey: ['/api/sitters', userId] });
      
      toast({
        title: 'Verification Started',
        description: 'Please complete the verification process in the new window.',
      });
    },
    onError: (error: any) => {
      toast({
        variant: 'destructive',
        title: 'Verification Error',
        description: error.message || 'Failed to start verification process',
      });
    },
  });

  // Helper to check verification status
  const verificationStatus = data?.status ?? 'not_started';
  const isVerified = verificationStatus === 'approved' || (data?.identityVerified === true);
  const isPending = verificationStatus === 'pending' || verificationStatus === 'initiated';
  const isRejected = verificationStatus === 'declined' || verificationStatus === 'rejected';

  // Helper to handle the verification completion
  const handleVerificationComplete = useCallback(() => {
    queryClient.invalidateQueries({ queryKey: ['/api/sitter-verification/status'] });
    queryClient.invalidateQueries({ queryKey: ['/api/sitters', userId] });
    
    toast({
      title: 'Verification Submitted',
      description: 'Your verification has been submitted for review.',
    });
    
    setVerificationUrl(null);
  }, [queryClient, toast, userId]);

  return {
    verificationStatus,
    isVerified,
    isPending,
    isRejected,
    isLoading,
    error,
    startVerification,
    isInitiating,
    verificationUrl,
    handleVerificationComplete,
    verificationData: data,
  };
}