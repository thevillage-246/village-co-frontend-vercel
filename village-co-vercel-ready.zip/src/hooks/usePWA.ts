import { useState, useEffect } from 'react';

interface PWAPromptEvent extends Event {
  prompt(): Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

interface PWACapabilities {
  isInstallable: boolean;
  isInstalled: boolean;
  isOnline: boolean;
  canShare: boolean;
  canNotify: boolean;
  hasCamera: boolean;
  hasGeolocation: boolean;
}

interface PWAHook {
  installPrompt: PWAPromptEvent | null;
  capabilities: PWACapabilities;
  promptInstall: () => Promise<boolean>;
  shareContent: (data: ShareData) => Promise<void>;
  requestNotificationPermission: () => Promise<NotificationPermission>;
  getLocation: () => Promise<GeolocationPosition>;
}

export const usePWA = (): PWAHook => {
  const [installPrompt, setInstallPrompt] = useState<PWAPromptEvent | null>(null);
  const [capabilities, setCapabilities] = useState<PWACapabilities>({
    isInstallable: false,
    isInstalled: false,
    isOnline: navigator.onLine,
    canShare: 'share' in navigator,
    canNotify: 'Notification' in window,
    hasCamera: 'mediaDevices' in navigator && 'getUserMedia' in navigator.mediaDevices,
    hasGeolocation: 'geolocation' in navigator
  });

  useEffect(() => {
    // Listen for install prompt
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setInstallPrompt(e as PWAPromptEvent);
      setCapabilities(prev => ({ ...prev, isInstallable: true }));
    };

    // Listen for app installed
    const handleAppInstalled = () => {
      setInstallPrompt(null);
      setCapabilities(prev => ({ 
        ...prev, 
        isInstalled: true, 
        isInstallable: false 
      }));
    };

    // Listen for online/offline status
    const handleOnline = () => {
      setCapabilities(prev => ({ ...prev, isOnline: true }));
    };

    const handleOffline = () => {
      setCapabilities(prev => ({ ...prev, isOnline: false }));
    };

    // Check if app is already installed
    const checkInstallStatus = () => {
      const isStandalone = window.matchMedia('(display-mode: standalone)').matches;
      const isInWebAppiOS = (window.navigator as any).standalone === true;
      const isInstalled = isStandalone || isInWebAppiOS;
      
      setCapabilities(prev => ({ ...prev, isInstalled }));
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    checkInstallStatus();

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const promptInstall = async (): Promise<boolean> => {
    if (!installPrompt) {
      return false;
    }

    try {
      await installPrompt.prompt();
      const choiceResult = await installPrompt.userChoice;
      setInstallPrompt(null);
      
      return choiceResult.outcome === 'accepted';
    } catch (error) {
      console.error('Error prompting install:', error);
      return false;
    }
  };

  const shareContent = async (data: ShareData): Promise<void> => {
    if (!capabilities.canShare) {
      throw new Error('Web Share API not supported');
    }

    try {
      await navigator.share(data);
    } catch (error) {
      if ((error as Error).name !== 'AbortError') {
        console.error('Error sharing:', error);
        throw error;
      }
    }
  };

  const requestNotificationPermission = async (): Promise<NotificationPermission> => {
    if (!capabilities.canNotify) {
      throw new Error('Notifications not supported');
    }

    return await Notification.requestPermission();
  };

  const getLocation = async (): Promise<GeolocationPosition> => {
    if (!capabilities.hasGeolocation) {
      throw new Error('Geolocation not supported');
    }

    return new Promise((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(resolve, reject, {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 300000 // 5 minutes
      });
    });
  };

  return {
    installPrompt,
    capabilities,
    promptInstall,
    shareContent,
    requestNotificationPermission,
    getLocation
  };
};

// Utility hook for offline detection with better UX
export const useOfflineStatus = () => {
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const [wasOffline, setWasOffline] = useState(false);

  useEffect(() => {
    const handleOnline = () => {
      setIsOffline(false);
      if (wasOffline) {
        // Show "back online" message
        console.log('✅ Connection restored');
        setWasOffline(false);
      }
    };

    const handleOffline = () => {
      setIsOffline(true);
      setWasOffline(true);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [wasOffline]);

  return { isOffline, wasOffline };
};

export default usePWA;