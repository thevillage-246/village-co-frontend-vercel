import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { useEffect } from "react";
import { apiRequest } from "@/lib/queryClient";

interface SitterProfile {
  id: number;
  userId: number;
  onboardingStep?: number;
  isOnboardingComplete?: boolean;
  bio?: string;
  experience?: string;
  hourlyRate?: number;
}

interface User {
  id: number;
  role: string;
  firstName?: string;
  lastName?: string;
}

interface SitterOnboardingData {
  user: User;
  sitterProfile: SitterProfile | null;
}

export function useSitterOnboardingGuard() {
  const [location, setLocation] = useLocation();

  // Get current user and sitter profile data
  const { data: userData, isLoading: userLoading } = useQuery({
    queryKey: ["/api/auth/user"],
    retry: false,
  });

  const { data: sitterData, isLoading: sitterLoading } = useQuery<SitterOnboardingData>({
    queryKey: ["/api/sitter/onboarding-status"],
    enabled: !!userData && userData.role === 'sitter',
    retry: false,
  });

  useEffect(() => {
    // Skip guard if data is still loading
    if (userLoading || sitterLoading) return;

    // Skip guard if user is not a sitter
    if (!userData || userData.role !== 'sitter') return;

    // Skip guard if already on onboarding pages
    if (location.startsWith('/sitter/onboarding')) return;

    // Skip guard for certain allowed pages
    const allowedPages = [
      '/auth/login', '/auth/register', '/logout', '/profile',
      '/sitter-onboarding-thank-you', '/sitter-onboarding-confirmation'
    ];
    if (allowedPages.some(page => location.startsWith(page))) return;

    // Check if sitter profile exists and onboarding status
    if (!sitterData?.sitterProfile) {
      // No sitter profile exists - redirect to step 1
      console.log('🔄 Redirecting to onboarding profile step - no sitter profile');
      setLocation('/sitter/onboarding/profile');
      return;
    }

    const profile = sitterData.sitterProfile;

    // Check if onboarding is complete
    if (profile.onboardingComplete) {
      // Onboarding complete - allow access to all pages
      return;
    }

    // Determine which step to redirect to based on profile completion
    let targetStep = 1;
    let targetPath = '/sitter/onboarding/profile';

    if (profile.onboardingStep) {
      // Use the stored onboarding step, but ensure we don't go beyond step 7
      targetStep = Math.min(profile.onboardingStep, 7);
    } else {
      // Determine step based on profile data completion
      if (!profile.bio || !profile.experience || !profile.hourlyRate) {
        targetStep = 1; // Bio + Rate
      } else if (!profile.qualifications || profile.qualifications.length === 0) {
        targetStep = 2; // Qualifications
      } else if (!profile.availability) {
        targetStep = 3; // Availability
      } else if (profile.onboardingStep < 5) {
        targetStep = 4; // Media
      } else if (profile.onboardingStep < 6) {
        targetStep = 5; // Payout
      } else if (profile.onboardingStep < 7) {
        targetStep = 6; // Verify
      } else {
        targetStep = 7; // Done
      }
    }

    // Map step numbers to route paths
    const stepRoutes = {
      1: '/sitter/onboarding/profile',
      2: '/sitter/onboarding/qualifications', 
      3: '/sitter/onboarding/availability',
      4: '/sitter/onboarding/media',
      5: '/sitter/onboarding/payout',
      6: '/sitter/onboarding/verify',
      7: '/sitter/onboarding/done'
    };

    targetPath = stepRoutes[targetStep] || '/sitter/onboarding/profile';
    console.log(`🔄 Redirecting to ${targetPath} (step ${targetStep}) - onboarding incomplete`);
    setLocation(targetPath);

  }, [userData, sitterData, userLoading, sitterLoading, location, setLocation]);

  return {
    isLoading: userLoading || sitterLoading,
    user: userData,
    sitterProfile: sitterData?.sitterProfile,
    shouldRedirect: userData?.role === 'sitter' && !sitterData?.sitterProfile?.onboardingComplete,
  };
}