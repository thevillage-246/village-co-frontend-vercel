/**
 * Mobile-optimized Intercom React Hook
 * Provides React Native-like API for web platform with mobile optimizations
 */

import { useEffect, useCallback } from 'react';
import { 
  intercom, 
  loginUnidentifiedUser, 
  setLauncherVisibility, 
  showNewMessage,
  updateUser,
  isMobileDevice,
  Visibility,
  type IntercomUser
} from '@/lib/intercom';

interface UseIntercomMobileOptions {
  autoInitialize?: boolean;
  user?: IntercomUser;
  mobileOptimized?: boolean;
}

export const useIntercomMobile = (options: UseIntercomMobileOptions = {}) => {
  const { autoInitialize = true, user, mobileOptimized = true } = options;

  // Initialize Intercom on mount (React Native equivalent)
  useEffect(() => {
    const initializeIntercomMobile = async () => {
      if (autoInitialize) {
        if (user && user.user_id && user.email) {
          // Initialize with identified user
          await intercom.initialize(user);
        } else {
          // Login as unidentified user (React Native API)
          loginUnidentifiedUser();
        }

        // Set launcher visibility for mobile devices
        if (mobileOptimized && isMobileDevice()) {
          setLauncherVisibility(true);
        }
      }
    };

    initializeIntercomMobile();

    // Cleanup on unmount
    return () => {
      if (autoInitialize) {
        intercom.shutdown();
      }
    };
  }, [autoInitialize, user, mobileOptimized]);

  // React Native-like API methods
  const showMessenger = useCallback(() => {
    intercom.show();
  }, []);

  const hideMessenger = useCallback(() => {
    intercom.hide();
  }, []);

  const displayNewMessage = useCallback((message?: string) => {
    showNewMessage(message);
  }, []);

  const updateUserAttributes = useCallback((userData: Partial<IntercomUser>) => {
    updateUser(userData);
  }, []);

  const trackEvent = useCallback((eventName: string, metadata?: Record<string, any>) => {
    intercom.trackEvent(eventName, metadata);
  }, []);

  const setVisibility = useCallback((visibility: Visibility) => {
    setLauncherVisibility(visibility === Visibility.VISIBLE);
  }, []);

  const loginUser = useCallback((userData: IntercomUser) => {
    intercom.initialize(userData);
  }, []);

  const logout = useCallback(() => {
    intercom.shutdown();
  }, []);

  // Mobile device detection
  const isOnMobile = useCallback(() => {
    return isMobileDevice();
  }, []);

  // Check if Intercom is ready
  const isReady = useCallback(() => {
    return intercom.isReady();
  }, []);

  return {
    // React Native-compatible API
    loginUnidentifiedUser,
    setLauncherVisibility: setVisibility,
    showMessenger,
    hideMessenger,
    displayMessage: displayNewMessage,
    updateUser: updateUserAttributes,
    trackEvent,
    loginUser,
    logout,
    
    // Additional utilities
    isOnMobile,
    isReady,
    
    // Direct access to service
    intercom
  };
};

// Export constants for React Native compatibility
export { Visibility };

// Export types
export type { IntercomUser };