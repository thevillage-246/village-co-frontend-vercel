import React from 'react';
import { Switch, Route, Link, useLocation } from 'wouter';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";

// Navigation component to be included on all pages
const Navigation = () => {
  const [location] = useLocation();
  
  return (
    <div style={{ marginBottom: '20px' }}>
      <div style={{ 
        padding: '10px', 
        background: '#f0f0f0', 
        borderRadius: '4px',
        marginBottom: '10px'
      }}>
        <strong>Current Path:</strong> {location}
      </div>
      
      <nav>
        <ul style={{ display: 'flex', gap: '15px', listStyle: 'none', padding: 0 }}>
          <li>
            <Link href="/ui-test">
              <span style={{ color: '#6B3E4B', textDecoration: 'underline', cursor: 'pointer' }}>UI Components</span>
            </Link>
          </li>
          <li>
            <Link href="/">
              <span style={{ color: '#6B3E4B', textDecoration: 'underline', cursor: 'pointer' }}>Home</span>
            </Link>
          </li>
        </ul>
      </nav>
    </div>
  );
};

const UIComponentsPage = () => {
  const { toast } = useToast();
  
  const showToast = () => {
    toast({
      title: "Toast Notification",
      description: "This is a test toast notification from the UI Components page.",
    });
  };
  
  return (
    <div style={{ 
      padding: '20px', 
      maxWidth: '800px', 
      margin: '0 auto', 
      fontFamily: 'sans-serif', 
      color: '#333' 
    }}>
      <Navigation />
      <h1 style={{ color: '#6B3E4B' }}>UI Components Test</h1>
      <p>This page tests various UI components from shadcn/ui library.</p>
      
      <Card className="mt-4">
        <CardHeader>
          <CardTitle>ShadCN Components Test</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="text-lg font-medium mb-2">Button Component</h3>
            <div className="flex flex-wrap gap-2">
              <Button>Default Button</Button>
              <Button variant="secondary">Secondary</Button>
              <Button variant="destructive">Destructive</Button>
              <Button variant="outline">Outline</Button>
              <Button variant="ghost">Ghost</Button>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-medium mb-2">Dialog Component</h3>
            <Dialog>
              <DialogTrigger asChild>
                <Button>Open Dialog</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Dialog Test</DialogTitle>
                  <DialogDescription>
                    This is a test dialog component to verify that UI components are working correctly.
                  </DialogDescription>
                </DialogHeader>
                <div className="py-4">
                  <p>Dialog content goes here. This should be visible when the dialog is open.</p>
                </div>
                <DialogClose asChild>
                  <Button>Close</Button>
                </DialogClose>
              </DialogContent>
            </Dialog>
          </div>
          
          <div>
            <h3 className="text-lg font-medium mb-2">Toast Component</h3>
            <Button onClick={showToast}>Show Toast</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

const SimpleUI: React.FC = () => {
  return (
    <Switch>
      <Route path="/ui-test" component={UIComponentsPage} />
    </Switch>
  );
};

export default SimpleUI;