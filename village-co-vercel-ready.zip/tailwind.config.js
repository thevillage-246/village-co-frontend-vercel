/** @type {import('tailwindcss').Config} */
export default {
  darkMode: ["class"],
  content: [
    './pages/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
    './app/**/*.{ts,tsx}',
    './src/**/*.{ts,tsx}',
    './index.html',
  ],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        // Village Co. Custom Colors
        linen: {
          50: '#fefcf9',
          100: '#fdf8f0',
          200: '#fbf0e1',
          300: '#f8e8d2',
          400: '#f5e0c3',
          500: '#f2d8b4', // Primary linen
          600: '#efd0a5',
          700: '#ecc896',
          800: '#e9c087',
          900: '#e6b878',
        },
        rose: {
          50: '#fef7f7',
          100: '#fdeef0',
          200: '#fce7ea',
          300: '#f9d5db',
          400: '#f5b7c4',
          500: '#f0a0b0', // Primary rose
          600: '#eb899c',
          700: '#e67288',
          800: '#e15b74',
          900: '#dc4460',
        },
        wine: {
          50: '#f8f4f6',
          100: '#f1e9ed',
          200: '#e9dde4',
          300: '#d4c1cc',
          400: '#b8969e',
          500: '#9c6b70', // Primary wine
          600: '#8b5a5f',
          700: '#7a494e',
          800: '#69383d',
          900: '#58272c',
        },
        taupe: {
          50: '#f9f8f7',
          100: '#f3f1ef',
          200: '#ede9e6',
          300: '#ddd5d0',
          400: '#c4b7af',
          500: '#ab998e', // Primary taupe
          600: '#9a897e',
          700: '#89796e',
          800: '#78695e',
          900: '#67594e',
        },
        eucalyptus: {
          50: '#f6f9f7',
          100: '#edf3ef',
          200: '#e4ede6',
          300: '#cfddd2',
          400: '#a6bdaa',
          500: '#7d9d82', // Primary eucalyptus
          600: '#708e75',
          700: '#637f68',
          800: '#56705b',
          900: '#49614e',
        },
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
}