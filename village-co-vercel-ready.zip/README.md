# Village Co. Frontend - Vercel Deployment Ready

## Overview
This is your Village Co. frontend package configured for Vercel deployment, connected to your Railway backend.

## Quick Setup

### 1. Local Development
```bash
npm install
npm run dev
```
Access at: http://localhost:5000

### 2. Deploy to Vercel

#### Option A: Using Vercel CLI
```bash
npm install -g vercel
vercel
```

#### Option B: Using Vercel Dashboard
1. Go to [vercel.com](https://vercel.com)
2. Click "New Project"
3. Import this folder
4. Deploy automatically

## Configuration

### Environment Variables
Add these to your Vercel project settings:

```env
VITE_API_URL=https://village-co-backend-production.up.railway.app
VITE_STRIPE_PUBLIC_KEY=pk_test_your_actual_stripe_key
VITE_GOOGLE_MAPS_API_KEY=your_actual_google_maps_key
VITE_NODE_ENV=production
```

### Railway Backend Connection
- **Backend URL**: https://village-co-backend-production.up.railway.app
- **API Proxy**: All `/api/*` routes automatically forward to Railway
- **CORS**: Configured for cross-origin requests

## Features Included

✅ Complete Village Co. frontend application  
✅ Railway backend integration  
✅ Vercel deployment configuration  
✅ Production-ready build setup  
✅ Custom domain support  
✅ API proxying for Railway backend  
✅ All existing pages and components  
✅ Email system disabled (customer protection)  

## Test Accounts
- **Admin**: admin@thevillageco.nz / admin2025!
- **User 1**: S.Phieros@gmail.com / password
- **User 2**: Nikki.paknz@gmail.com / password

## Production Setup

1. **Deploy to Vercel**: Upload this folder to Vercel
2. **Add Environment Variables**: Set your actual Stripe and Google Maps keys
3. **Custom Domain**: Configure your domain in Vercel settings
4. **SSL**: Automatic with Vercel

Your Village Co. platform will be live with full functionality connected to your Railway backend.

## File Structure
```
vercel-frontend/
├── src/                 # All your React components and pages
├── package.json         # Dependencies and scripts
├── vite.config.js       # Build configuration
├── vercel.json          # Vercel deployment settings
├── .env                 # Environment variables
└── tailwind.config.js   # Styling configuration
```